
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_CHR 13
#define CID_TRANSACTION_TX 14
#define CID_STORAGE_WORLD 15
#define CID_TYPES_HEALTHSCHEMA 16
#define CID_CACHE_CACHE 17
#define CID_TYPES_VITALS 18
#define CID_TYPES_VITALSVIEW 19
#define CID_TYPES_ARMOR 20
#define CID_TYPES_TRACKED 21
#define CID_TYPES_HEALTHLEDGER 22
#define CID_TYPES_LEDGERVIEW 23
#define CID_TYPES_HEALTHON 24
#define CID_TYPES_HEALTHOFF 25
#define CID_STORAGE_HANDLE 26
#define CID_STORAGE_SPAWN 27
#define CID_STORAGE_INSERTMAIN 28
#define CID_STORAGE_INSERTFLAG 29
#define CID_STORAGE_REMOVEMAIN 30
#define CID_STORAGE_REMOVEFLAG 31
#define CID_STORAGE_DESPAWN 32
#define CID_NIL 33
#define CID_CON 34
#define CID_TRANSACTION_MAININVERSE 35
#define CID_TRANSACTION_LEDGERINVERSE 36
#define CID_STORAGE_ROWS 37
#define CID_TYPES_FOUR 38
#define CID_STORAGE_BUNDLE 39
#define CID_HEALTHCARRY 40
#define CID_OBSERVATIONS_SPAWNVIEW 41
#define CID_OBSERVATIONS_MAINVIEW 42
#define CID_OBSERVATIONS_FLAGVIEW 43
#define CID_OBSERVATIONS_REMOVEMAINVIEW 44
#define CID_OBSERVATIONS_REMOVEFLAGVIEW 45
#define CID_OBSERVATIONS_DESPAWNVIEW 46
#define CID_TYPES_ARMORVIEW 47
#define CID_STORAGE_METADATACOLUMNS 48
#define CID_TRANSACTION_COMMITTED 49
#define CID_TRANSACTION_REVERTED 50
#define CID_OBSERVATIONS_BUNDLEVIEW 51
#define CID_TYPES_FOUND 52
#define CID_TYPES_MISMATCH 53
#define CID_TYPES_MISSING 54
#define CID_TYPES_VITALSTOKEN 55
#define CID_WNIL 56
#define CID_OBSERVATIONS_WORLDVIEW 57
#define CID_STORAGE_TAKEN 58
#define CID_STORAGE_NOMAIN 59
#define CID_STORAGE_NOENTITY 60
#define CID_HEALTHINSPECT 61
#define CID_TYPES_HEALTHLEDGERTOKEN 62
#define CID_OBSERVATIONS_ROWVIEW 63
#define CID_HELD_ADAPTER_PROTOTYPEROWOWNER 64
#define CID_STORAGE_ROW 65
#define CID_STORAGE_METADATA 66
#define CID_IO_PRINT 67
#define FID_OBSERVATIONS_ROW_0 0
#define FID_OBSERVATIONS_ROW_0_K33 1
#define FID_HOST_RENDER_RENDER_TRACKED 2
#define FID_HOST_RENDER_RENDER_TRACKED_K58 3
#define FID_HOST_RENDER_RENDER_VITALS 4
#define FID_HOST_RENDER_RENDER_VITALS_K60 5
#define FID_HOST_RENDER_RENDER_VITALS_K61 6
#define FID_HOST_RENDER_RENDER_VITALS_K62 7
#define FID_HOST_RENDER_RENDER_BUNDLE_1 8
#define FID_HOST_RENDER_RENDER_BUNDLE_1_K64 9
#define FID_HOST_RENDER_RENDER_BUNDLE_1_K65 10
#define FID_HOST_RENDER_RENDER_BUNDLE_1_K66 11
#define FID_HOST_RENDER_RENDER_OPTIONAL_5 12
#define FID_HOST_RENDER_RENDER_OPTIONAL_4 13
#define FID_HOST_RENDER_RENDER_OPTIONAL_4_K69 14
#define FID_HOST_RENDER_RENDER_OPTIONAL_4_K70 15
#define FID_HOST_RENDER_RENDER_OPTIONAL_6 16
#define FID_OBSERVATIONS_ROWS_ADVANCE_0 17
#define FID_OBSERVATIONS_ROWS_ADVANCE_0_K89 18
#define FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET 19
#define FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_C92 20
#define FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_K93 21
#define FID_HOST_RENDER_RENDER_FOUR 22
#define FID_HOST_RENDER_RENDER_FOUR_K95 23
#define FID_HOST_RENDER_RENDER_FOUR_K96 24
#define FID_HOST_RENDER_RENDER_FOUR_K97 25
#define FID_HOST_RENDER_RENDER_FOUR_K98 26
#define FID_HOST_RENDER_RENDER_PENDING_1 27
#define FID_HOST_RENDER_RENDER_PENDING_1_K100 28
#define FID_HOST_RENDER_RENDER_PENDING_1_K101 29
#define FID_HOST_RENDER_RENDER_PENDING_1_K102 30
#define FID_HOST_RENDER_RENDER_PENDING_1_K103 31
#define FID_HOST_RENDER_RENDER_PENDING_1_K104 32
#define FID_HOST_RENDER_RENDER_PENDING_1_K105 33
#define FID_HOST_RENDER_RENDER_PENDING_1_K106 34
#define FID_HOST_RENDER_RENDER_PENDING_1_K107 35
#define FID_HOST_RENDER_RENDER_PENDING_1_K108 36
#define FID_HOST_RENDER_RENDER_ROW_1 37
#define FID_HOST_RENDER_RENDER_ROW_1_K110 38
#define FID_HOST_RENDER_RENDER_ROW_1_K111 39
#define FID_HOST_RENDER_RENDER_ROW_1_K112 40
#define FID_HOST_RENDER_RENDER_ROW_1_K113 41
#define FID_HOST_RENDER_RENDER_ROW_1_K114 42
#define FID_HOST_RENDER_RENDER_ROW_1_K115 43
#define FID_U32_SHOW_GO 44
#define FID_TRANSACTION_STORAGE_SET_LEDGER0_1 45
#define FID_TRANSACTION_STORAGE_SET_LEDGER0_1_C125 46
#define FID_TRANSACTION_STORAGE_SET_LEDGER0_1_K126 47
#define FID_HOST_RENDER_RENDER_LIST_TAIL_11 48
#define FID_HOST_RENDER_RENDER_LIST_TAIL_11_K131 49
#define FID_HEALTH_HANDLE 50
#define FID_HEALTH_HANDLE_K133 51
#define FID_HEALTH_HANDLE_K134 52
#define FID_HEALTH_HANDLE_K135 53
#define FID_OBSERVATIONS_ROWS_GO_0 54
#define FID_OBSERVATIONS_ROWS_GO_0_K146 55
#define FID_OBSERVATIONS_MAYBE_GET_0 56
#define FID_OBSERVATIONS_MAYBE_GET_0_K148 57
#define FID_HOST_RENDER_RENDER_LIST_TAIL_14 58
#define FID_HOST_RENDER_RENDER_LIST_TAIL_14_K154 59
#define FID_HOST_RENDER_RENDER_LIST_TAIL_13 60
#define FID_HOST_RENDER_RENDER_LIST_TAIL_13_K156 61
#define FID_TRANSACTION_STORAGE_SET_MAIN0_1 62
#define FID_TRANSACTION_STORAGE_SET_MAIN0_1_C165 63
#define FID_TRANSACTION_STORAGE_SET_MAIN0_1_K166 64
#define FID_STORAGE_WITH_LEDGER 65
#define FID_STORAGE_WITH_LEDGER_K170 66
#define FID_HOST_RENDER_RENDER_LIST_11 67
#define FID_HOST_RENDER_RENDER_LIST_11_K183 68
#define FID_UNDO_TEXT_0 69
#define FID_UNDO_TEXT_0_K185 70
#define FID_UNDO_TEXT_0_K186 71
#define FID_UNDO_TEXT_0_K187 72
#define FID_UNDO_TEXT_0_K188 73
#define FID_UNDO_TEXT_0_K189 74
#define FID_UNDO_TEXT_0_K190 75
#define FID_UNDO_TEXT_0_K191 76
#define FID_UNDO_TEXT_0_K192 77
#define FID_UNDO_TEXT_0_K193 78
#define FID_UNDO_TEXT_0_K194 79
#define FID_UNDO_TEXT_0_K195 80
#define FID_HOST_RENDER_RENDER_HANDLE 81
#define FID_HOST_RENDER_RENDER_HANDLE_K198 82
#define FID_HOST_RENDER_RENDER_HANDLE_K199 83
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE 84
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE_K203 85
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE 86
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE_K205 87
#define FID_HOST_RENDER_RENDER_OPTIONAL_0 88
#define FID_HOST_RENDER_RENDER_OPTIONAL_0_K213 89
#define FID_HOST_RENDER_RENDER_OPTIONAL_0_K214 90
#define FID_HOST_RENDER_RENDER_LIST_14 91
#define FID_HOST_RENDER_RENDER_LIST_14_K216 92
#define FID_HOST_RENDER_RENDER_LIST_13 93
#define FID_HOST_RENDER_RENDER_LIST_13_K218 94
#define FID_U32_SHOW 95
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16 96
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16_K221 97
#define FID_STORAGE_WITH_MAIN 98
#define FID_STORAGE_WITH_MAIN_K228 99
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0 100
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C241 101
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C242 102
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K243 103
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K244 104
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K245 105
#define FID_ORIGINAL_RAW_OBSERVER_OBSERVE 106
#define FID_ORIGINAL_RAW_OBSERVER_OBSERVE_K248 107
#define FID_OBSERVATIONS_MAYBE_GET_2 108
#define FID_OBSERVATIONS_MAYBE_GET_2_K250 109
#define FID_TRANSACTION_UNWIND_1 110
#define FID_TRANSACTION_UNWIND_1_K282 111
#define FID_TRANSACTION_UNWIND_1_K283 112
#define FID_OBSERVATIONS_ROWS_0 113
#define FID_HOST_RENDER_RENDER_WORLD_1 114
#define FID_HOST_RENDER_RENDER_WORLD_1_K291 115
#define FID_HOST_RENDER_RENDER_WORLD_1_K292 116
#define FID_HOST_RENDER_RENDER_WORLD_1_K293 117
#define FID_HOST_RENDER_RENDER_WORLD_1_K294 118
#define FID_HOST_RENDER_RENDER_WORLD_1_K295 119
#define FID_HOST_RENDER_RENDER_LIST_16 120
#define FID_HOST_RENDER_RENDER_LIST_16_K297 121
#define FID_STRING_APPEND 122
#define FID_STRING_APPEND_K299 123
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0 124
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C311 125
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C312 126
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C313 127
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K314 128
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K315 129
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K316 130
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K317 131
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER 132
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C319 133
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C320 134
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K321 135
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K322 136
#define FID_ORIGINAL_RAW_OBSERVER_VITALS_GET 137
#define FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_C327 138
#define FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_K328 139
#define FID_OBSERVATIONS_BUNDLE_0 140
#define FID_OBSERVATIONS_BUNDLE_0_K331 141
#define FID_OBSERVATIONS_WORLD_0 142
#define FID_OBSERVATIONS_WORLD_0_K367 143
#define FID_OBSERVATIONS_WORLD_0_K368 144
#define FID_OBSERVATIONS_WORLD_0_K369 145
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN 146
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C380 147
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C381 148
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C382 149
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K383 150
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K384 151
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K385 152
#define FID_OBSERVATIONS_COMMAND_0 153
#define FID_OBSERVATIONS_COMMAND_0_K391 154
#define FID_OBSERVATIONS_COMMAND_0_K392 155
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE 156
#define FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE_K422 157
#define FID_HEALTH_POST 158
#define FID_HEALTH_POST_K426 159
#define FID_HEALTH_POST_K427 160
#define FID_HEALTH_POST_K428 161
#define FID_HEALTH_POST_K429 162
#define FID_HEALTH_POST_K430 163
#define FID_HEALTH_POST_K431 164
#define FID_HEALTH_POST_K432 165
#define FID_GATE_CALLBACKS_HEALTH_BODY_0 166
#define FID_GATE_CALLBACKS_HEALTH_BODY_0_K441 167
#define FID_GATE_CALLBACKS_HEALTH_BODY_0_K442 168
#define FID_GATE_CALLBACKS_HEALTH_BODY_0_K443 169
#define FID_GATE_CALLBACKS_HEALTH_BODY_0_K444 170
#define FID_OBSERVATIONS_COMMANDS_0 171
#define FID_OBSERVATIONS_COMMANDS_0_K446 172
#define FID_OBSERVATIONS_COMMANDS_0_K447 173
#define FID_HELD_ADAPTER_HEALTH_ROW_0 174
#define FID_HEALTH_FINISH 175
#define FID_HEALTH_FINISH_K476 176
#define FID_HEALTH_BODY 177
#define FID_HEALTH_PRE 178
#define FID_HEALTH_PRE_K480 179
#define FID_HEALTH_PRE_K481 180
#define FID_HEALTH_PRE_K482 181
#define FID_HEALTH_PRE_K483 182
#define FID_HEALTH_PRE_K484 183
#define FID_HEALTH_PRE_K485 184
#define FID_HEALTH_PRE_K486 185
#define FID_HEALTH_PRE_K487 186
#define FID_HEALTH_PRE_K488 187
#define FID_HEALTH_PRE_K489 188
#define FID_HEALTH_PRE_K490 189
#define FID_HEALTH_PRE_K491 190
#define FID_HEALTH_PRE_K492 191
#define FID_HEALTH_PRE_K493 192
#define FID_HEALTH_PRE_K494 193
#define FID_HEALTH_PRE_K495 194
#define FID_HEALTH_PRE_K496 195
#define FID_HEALTH_PRE_K497 196
#define FID_HEALTH_PRE_K498 197
#define FID_HEALTH_PRE_K499 198
#define FID_HEALTH_PRE_K500 199
#define FID_HEALTH_PRE_K501 200
#define FID_HEALTH_PRE_K502 201
#define FID_HEALTH_PRE_C503 202
#define FID_HEALTH_PRE_C504 203
#define FID_HEALTH_PRE_C505 204
#define FID_HEALTH_PAIR 205
#define FID_HEALTH_PAIR_K507 206
#define FID_HEALTH_PAIR_K508 207
#define FID_HEALTH_PAIR_C509 208
#define FID_HEALTH_PAIR_C510 209
#define FID_HEALTH_PAIR_K511 210
#define FID_HEALTH_PAIR_C512 211
#define FID_HEALTH_PAIR_C513 212
#define FID_HEALTH_PAIR_K514 213
#define FID_HEALTH_PAIR_K515 214
#define FID_HEALTH_PAIR_C516 215
#define FID_HEALTH_PAIR_C517 216
#define FID_IO_BIND 217
#define FID_IO_BIND_C519 218
#define FID_IO_BIND_K520 219
#define FID_IO_PURE 220
#define FID_CASES 221
#define FID_CASES_C523 222
#define FID_CASES_K524 223
#define FID_CASES_C525 224
#define FID_CASES_C526 225
#define FID_CASES_K527 226
#define FID_CASES_C528 227
#define FID_CASES_C529 228
#define FID_MAIN 229
#define FID_IO_PRINT 230
#define FID_IO_EMIT 231
#define FID_CLO_APPLY 232
#define FID_EXIT 233
#define FID_ENTER 234
CONSTV u8 FID_T[][3] = { { 18, 0, 2 }, { 25, 17, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 6, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 15, 0, 2 }, { 9, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 6, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 7, 0, 2 }, { 11, 0, 2 }, { 46, 36, 2 }, { 7, 0, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 17, 0, 2 }, { 16, 1, 2 }, { 2, 1, 2 }, { 7, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 18, 0, 2 }, { 18, 1, 2 }, { 12, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 3, 0, 2 }, { 22, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 12, 0, 2 }, { 12, 10, 2 }, { 8, 0, 2 }, { 12, 12, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 24, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 16, 0, 2 }, { 14, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 22, 0, 2 }, { 23, 23, 2 }, { 24, 0, 2 }, { 23, 23, 2 }, { 6, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 18, 0, 2 }, { 17, 1, 2 }, { 28, 0, 2 }, { 1, 0, 2 }, { 22, 0, 2 }, { 23, 23, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 10, 0, 2 }, { 15, 15, 2 }, { 22, 0, 2 }, { 22, 21, 2 }, { 22, 21, 2 }, { 9, 0, 2 }, { 11, 0, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 6, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 28, 0, 2 }, { 1, 0, 2 }, { 22, 0, 2 }, { 24, 0, 2 }, { 23, 23, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 27, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 17, 17, 2 }, { 6, 1, 2 }, { 9, 0, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 15, 0, 2 }, { 22, 17, 2 }, { 21, 0, 2 }, { 22, 10, 2 }, { 23, 2, 2 }, { 29, 14, 2 }, { 27, 0, 2 }, { 1, 0, 2 }, { 22, 0, 2 }, { 1, 0, 2 }, { 17, 17, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 17, 0, 2 }, { 31, 30, 2 }, { 16, 15, 2 }, { 27, 0, 2 }, { 21, 21, 2 }, { 22, 0, 2 }, { 33, 32, 2 }, { 12, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 27, 0, 2 }, { 34, 34, 2 }, { 31, 27, 2 }, { 37, 33, 2 }, { 28, 27, 2 }, { 1, 0, 2 }, { 35, 34, 2 }, { 36, 2, 2 }, { 27, 0, 2 }, { 28, 0, 2 }, { 25, 25, 2 }, { 27, 0, 2 }, { 28, 0, 2 }, { 29, 2, 2 }, { 40, 32, 2 }, { 40, 1, 2 }, { 41, 1, 2 }, { 42, 1, 2 }, { 42, 1, 2 }, { 43, 1, 2 }, { 44, 1, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 32, 1, 2 }, { 32, 1, 2 }, { 31, 1, 2 }, { 31, 1, 2 }, { 30, 1, 2 }, { 30, 1, 2 }, { 29, 1, 2 }, { 29, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 29, 0, 2 }, { 28, 0, 2 }, { 28, 0, 2 }, { 2, 0, 2 }, { 30, 28, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 29, 28, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 0, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 6, 1 }, { 15, 1 }, { 0, 1 }, { 2, 1 }, { 3, 1 }, { 6, 1 }, { 2, 1 }, { 1, 1 }, { 2, 1 }, { 5, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 7, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 9, 1 }, { 4, 1 }, { 6, 1 }, { 27, 1 }, { 7, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 5, 1 }, { 4, 1 }, { 4, 1 }, { 1, 1 }, { 6, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 0 }, { 0, 0 }, { 7, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 8, 1 }, { 0, 0 }, { 9, 1 }, { 7, 1 }, { 9, 1 }, { 5, 1 }, { 2, 0 } };
#define STAT_LEN 672

#define WL_RESW 36
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
    if ((N) <= 29) break; r29 = e.mem[(A) + 29]; \
    if ((N) <= 30) break; r30 = e.mem[(A) + 30]; \
    if ((N) <= 31) break; r31 = e.mem[(A) + 31]; \
    if ((N) <= 32) break; r32 = e.mem[(A) + 32]; \
    if ((N) <= 33) break; r33 = e.mem[(A) + 33]; \
    if ((N) <= 34) break; r34 = e.mem[(A) + 34]; \
    if ((N) <= 35) break; r35 = e.mem[(A) + 35]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
    case 29: r29 = (X); \
      break; \
    case 30: r30 = (X); \
      break; \
    case 31: r31 = (X); \
      break; \
    case 32: r32 = (X); \
      break; \
    case 33: r33 = (X); \
      break; \
    case 34: r34 = (X); \
      break; \
    case 35: r35 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25; (V)[26] = r26; (V)[27] = r27; (V)[28] = r28; (V)[29] = r29; (V)[30] = r30; (V)[31] = r31; (V)[32] = r32; (V)[33] = r33; (V)[34] = r34; (V)[35] = r35;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25]; r26 = (V)[26]; r27 = (V)[27]; r28 = (V)[28]; r29 = (V)[29]; r30 = (V)[30]; r31 = (V)[31]; r32 = (V)[32]; r33 = (V)[33]; r34 = (V)[34]; r35 = (V)[35];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35

#define WL_TABLE WL_X(FID_OBSERVATIONS_ROW_0) WL_X(FID_OBSERVATIONS_ROW_0_K33) WL_X(FID_HOST_RENDER_RENDER_TRACKED) WL_X(FID_HOST_RENDER_RENDER_TRACKED_K58) WL_X(FID_HOST_RENDER_RENDER_VITALS) WL_X(FID_HOST_RENDER_RENDER_VITALS_K60) WL_X(FID_HOST_RENDER_RENDER_VITALS_K61) WL_X(FID_HOST_RENDER_RENDER_VITALS_K62) WL_X(FID_HOST_RENDER_RENDER_BUNDLE_1) WL_X(FID_HOST_RENDER_RENDER_BUNDLE_1_K64) WL_X(FID_HOST_RENDER_RENDER_BUNDLE_1_K65) WL_X(FID_HOST_RENDER_RENDER_BUNDLE_1_K66) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_5) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_4) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_4_K69) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_4_K70) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_6) WL_X(FID_OBSERVATIONS_ROWS_ADVANCE_0) WL_X(FID_OBSERVATIONS_ROWS_ADVANCE_0_K89) WL_X(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET) WL_X(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_C92) WL_X(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_K93) WL_X(FID_HOST_RENDER_RENDER_FOUR) WL_X(FID_HOST_RENDER_RENDER_FOUR_K95) WL_X(FID_HOST_RENDER_RENDER_FOUR_K96) WL_X(FID_HOST_RENDER_RENDER_FOUR_K97) WL_X(FID_HOST_RENDER_RENDER_FOUR_K98) WL_X(FID_HOST_RENDER_RENDER_PENDING_1) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K100) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K101) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K102) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K103) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K104) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K105) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K106) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K107) WL_X(FID_HOST_RENDER_RENDER_PENDING_1_K108) WL_X(FID_HOST_RENDER_RENDER_ROW_1) WL_X(FID_HOST_RENDER_RENDER_ROW_1_K110) WL_X(FID_HOST_RENDER_RENDER_ROW_1_K111) WL_X(FID_HOST_RENDER_RENDER_ROW_1_K112) WL_X(FID_HOST_RENDER_RENDER_ROW_1_K113) WL_X(FID_HOST_RENDER_RENDER_ROW_1_K114) WL_X(FID_HOST_RENDER_RENDER_ROW_1_K115) WL_X(FID_U32_SHOW_GO) WL_X(FID_TRANSACTION_STORAGE_SET_LEDGER0_1) WL_X(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_C125) WL_X(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_K126) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_11) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_11_K131) WL_X(FID_HEALTH_HANDLE) WL_X(FID_HEALTH_HANDLE_K133) WL_X(FID_HEALTH_HANDLE_K134) WL_X(FID_HEALTH_HANDLE_K135) WL_X(FID_OBSERVATIONS_ROWS_GO_0) WL_X(FID_OBSERVATIONS_ROWS_GO_0_K146) WL_X(FID_OBSERVATIONS_MAYBE_GET_0) WL_X(FID_OBSERVATIONS_MAYBE_GET_0_K148) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_14) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_14_K154) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_13) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_13_K156) WL_X(FID_TRANSACTION_STORAGE_SET_MAIN0_1) WL_X(FID_TRANSACTION_STORAGE_SET_MAIN0_1_C165) WL_X(FID_TRANSACTION_STORAGE_SET_MAIN0_1_K166) WL_X(FID_STORAGE_WITH_LEDGER) WL_X(FID_STORAGE_WITH_LEDGER_K170) WL_X(FID_HOST_RENDER_RENDER_LIST_11) WL_X(FID_HOST_RENDER_RENDER_LIST_11_K183) WL_X(FID_UNDO_TEXT_0) WL_X(FID_UNDO_TEXT_0_K185) WL_X(FID_UNDO_TEXT_0_K186) WL_X(FID_UNDO_TEXT_0_K187) WL_X(FID_UNDO_TEXT_0_K188) WL_X(FID_UNDO_TEXT_0_K189) WL_X(FID_UNDO_TEXT_0_K190) WL_X(FID_UNDO_TEXT_0_K191) WL_X(FID_UNDO_TEXT_0_K192) WL_X(FID_UNDO_TEXT_0_K193) WL_X(FID_UNDO_TEXT_0_K194) WL_X(FID_UNDO_TEXT_0_K195) WL_X(FID_HOST_RENDER_RENDER_HANDLE) WL_X(FID_HOST_RENDER_RENDER_HANDLE_K198) WL_X(FID_HOST_RENDER_RENDER_HANDLE_K199) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE_K203) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE_K205) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_0) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_0_K213) WL_X(FID_HOST_RENDER_RENDER_OPTIONAL_0_K214) WL_X(FID_HOST_RENDER_RENDER_LIST_14) WL_X(FID_HOST_RENDER_RENDER_LIST_14_K216) WL_X(FID_HOST_RENDER_RENDER_LIST_13) WL_X(FID_HOST_RENDER_RENDER_LIST_13_K218) WL_X(FID_U32_SHOW) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K221) WL_X(FID_STORAGE_WITH_MAIN) WL_X(FID_STORAGE_WITH_MAIN_K228) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C241) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C242) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K243) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K244) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K245) WL_X(FID_ORIGINAL_RAW_OBSERVER_OBSERVE) WL_X(FID_ORIGINAL_RAW_OBSERVER_OBSERVE_K248) WL_X(FID_OBSERVATIONS_MAYBE_GET_2) WL_X(FID_OBSERVATIONS_MAYBE_GET_2_K250) WL_X(FID_TRANSACTION_UNWIND_1) WL_X(FID_TRANSACTION_UNWIND_1_K282) WL_X(FID_TRANSACTION_UNWIND_1_K283) WL_X(FID_OBSERVATIONS_ROWS_0) WL_X(FID_HOST_RENDER_RENDER_WORLD_1) WL_X(FID_HOST_RENDER_RENDER_WORLD_1_K291) WL_X(FID_HOST_RENDER_RENDER_WORLD_1_K292) WL_X(FID_HOST_RENDER_RENDER_WORLD_1_K293) WL_X(FID_HOST_RENDER_RENDER_WORLD_1_K294) WL_X(FID_HOST_RENDER_RENDER_WORLD_1_K295) WL_X(FID_HOST_RENDER_RENDER_LIST_16) WL_X(FID_HOST_RENDER_RENDER_LIST_16_K297) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K299) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C311) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C312) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C313) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K314) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K315) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K316) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K317) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C319) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C320) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K321) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K322) WL_X(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET) WL_X(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_C327) WL_X(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_K328) WL_X(FID_OBSERVATIONS_BUNDLE_0) WL_X(FID_OBSERVATIONS_BUNDLE_0_K331) WL_X(FID_OBSERVATIONS_WORLD_0) WL_X(FID_OBSERVATIONS_WORLD_0_K367) WL_X(FID_OBSERVATIONS_WORLD_0_K368) WL_X(FID_OBSERVATIONS_WORLD_0_K369) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C380) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C381) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C382) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K383) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K384) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K385) WL_X(FID_OBSERVATIONS_COMMAND_0) WL_X(FID_OBSERVATIONS_COMMAND_0_K391) WL_X(FID_OBSERVATIONS_COMMAND_0_K392) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE_K422) WL_X(FID_HEALTH_POST) WL_X(FID_HEALTH_POST_K426) WL_X(FID_HEALTH_POST_K427) WL_X(FID_HEALTH_POST_K428) WL_X(FID_HEALTH_POST_K429) WL_X(FID_HEALTH_POST_K430) WL_X(FID_HEALTH_POST_K431) WL_X(FID_HEALTH_POST_K432) WL_X(FID_GATE_CALLBACKS_HEALTH_BODY_0) WL_X(FID_GATE_CALLBACKS_HEALTH_BODY_0_K441) WL_X(FID_GATE_CALLBACKS_HEALTH_BODY_0_K442) WL_X(FID_GATE_CALLBACKS_HEALTH_BODY_0_K443) WL_X(FID_GATE_CALLBACKS_HEALTH_BODY_0_K444) WL_X(FID_OBSERVATIONS_COMMANDS_0) WL_X(FID_OBSERVATIONS_COMMANDS_0_K446) WL_X(FID_OBSERVATIONS_COMMANDS_0_K447) WL_X(FID_HELD_ADAPTER_HEALTH_ROW_0) WL_X(FID_HEALTH_FINISH) WL_X(FID_HEALTH_FINISH_K476) WL_X(FID_HEALTH_BODY) WL_X(FID_HEALTH_PRE) WL_X(FID_HEALTH_PRE_K480) WL_X(FID_HEALTH_PRE_K481) WL_X(FID_HEALTH_PRE_K482) WL_X(FID_HEALTH_PRE_K483) WL_X(FID_HEALTH_PRE_K484) WL_X(FID_HEALTH_PRE_K485) WL_X(FID_HEALTH_PRE_K486) WL_X(FID_HEALTH_PRE_K487) WL_X(FID_HEALTH_PRE_K488) WL_X(FID_HEALTH_PRE_K489) WL_X(FID_HEALTH_PRE_K490) WL_X(FID_HEALTH_PRE_K491) WL_X(FID_HEALTH_PRE_K492) WL_X(FID_HEALTH_PRE_K493) WL_X(FID_HEALTH_PRE_K494) WL_X(FID_HEALTH_PRE_K495) WL_X(FID_HEALTH_PRE_K496) WL_X(FID_HEALTH_PRE_K497) WL_X(FID_HEALTH_PRE_K498) WL_X(FID_HEALTH_PRE_K499) WL_X(FID_HEALTH_PRE_K500) WL_X(FID_HEALTH_PRE_K501) WL_X(FID_HEALTH_PRE_K502) WL_X(FID_HEALTH_PRE_C503) WL_X(FID_HEALTH_PRE_C504) WL_X(FID_HEALTH_PRE_C505) WL_X(FID_HEALTH_PAIR) WL_X(FID_HEALTH_PAIR_K507) WL_X(FID_HEALTH_PAIR_K508) WL_X(FID_HEALTH_PAIR_C509) WL_X(FID_HEALTH_PAIR_C510) WL_X(FID_HEALTH_PAIR_K511) WL_X(FID_HEALTH_PAIR_C512) WL_X(FID_HEALTH_PAIR_C513) WL_X(FID_HEALTH_PAIR_K514) WL_X(FID_HEALTH_PAIR_K515) WL_X(FID_HEALTH_PAIR_C516) WL_X(FID_HEALTH_PAIR_C517) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C519) WL_X(FID_IO_BIND_K520) WL_X(FID_IO_PURE) WL_X(FID_CASES) WL_X(FID_CASES_C523) WL_X(FID_CASES_K524) WL_X(FID_CASES_C525) WL_X(FID_CASES_C526) WL_X(FID_CASES_K527) WL_X(FID_CASES_C528) WL_X(FID_CASES_C529) WL_X(FID_MAIN) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 48ull, term_pak(CID_SNIL, 0), 63ull, term_pak(CID_SNIL, 0), 56ull, term_pak(CID_SNIL, 0), 52ull, term_pak(CID_SNIL, 0), 99ull, term_pak(CID_SNIL, 0), 50ull, term_pak(CID_SNIL, 0), 97ull, term_pak(CID_SNIL, 0), 54ull, term_pak(CID_SNIL, 0), 101ull, term_pak(CID_SNIL, 0), 49ull, term_pak(CID_SNIL, 0), 57ull, term_pak(CID_SNIL, 0), 53ull, term_pak(CID_SNIL, 0), 100ull, term_pak(CID_SNIL, 0), 51ull, term_pak(CID_SNIL, 0), 98ull, term_pak(CID_SNIL, 0), 55ull, term_pak(CID_SNIL, 0), 102ull, term_pak(CID_SNIL, 0), 48ull, term_ctr(CID_SCON, STAT_OFF + 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 34), 92ull, term_ctr(CID_SCON, STAT_OFF + 36), 58ull, term_pak(CID_SNIL, 0), 34ull, term_ctr(CID_SCON, STAT_OFF + 40), 115ull, term_ctr(CID_SCON, STAT_OFF + 42), 114ull, term_ctr(CID_SCON, STAT_OFF + 44), 101ull, term_ctr(CID_SCON, STAT_OFF + 46), 121ull, term_ctr(CID_SCON, STAT_OFF + 48), 97ull, term_ctr(CID_SCON, STAT_OFF + 50), 108ull, term_ctr(CID_SCON, STAT_OFF + 52), 34ull, term_ctr(CID_SCON, STAT_OFF + 54), 123ull, term_ctr(CID_SCON, STAT_OFF + 56), 101ull, term_ctr(CID_SCON, STAT_OFF + 42), 100ull, term_ctr(CID_SCON, STAT_OFF + 60), 97ull, term_ctr(CID_SCON, STAT_OFF + 62), 114ull, term_ctr(CID_SCON, STAT_OFF + 64), 103ull, term_ctr(CID_SCON, STAT_OFF + 66), 34ull, term_ctr(CID_SCON, STAT_OFF + 68), 44ull, term_ctr(CID_SCON, STAT_OFF + 70), 125ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 74), term_pak(CID_NIL, 0), 34ull, term_pak(CID_SNIL, 0), 92ull, term_ctr(CID_SCON, STAT_OFF + 78), 92ull, term_pak(CID_SNIL, 0), 92ull, term_ctr(CID_SCON, STAT_OFF + 82), 112ull, term_ctr(CID_SCON, STAT_OFF + 42), 117ull, term_ctr(CID_SCON, STAT_OFF + 86), 111ull, term_ctr(CID_SCON, STAT_OFF + 88), 114ull, term_ctr(CID_SCON, STAT_OFF + 90), 103ull, term_ctr(CID_SCON, STAT_OFF + 92), 34ull, term_ctr(CID_SCON, STAT_OFF + 94), 123ull, term_ctr(CID_SCON, STAT_OFF + 96), 108ull, term_ctr(CID_SCON, STAT_OFF + 44), 101ull, term_ctr(CID_SCON, STAT_OFF + 100), 118ull, term_ctr(CID_SCON, STAT_OFF + 102), 101ull, term_ctr(CID_SCON, STAT_OFF + 104), 108ull, term_ctr(CID_SCON, STAT_OFF + 106), 34ull, term_ctr(CID_SCON, STAT_OFF + 108), 123ull, term_ctr(CID_SCON, STAT_OFF + 110), 118ull, term_ctr(CID_SCON, STAT_OFF + 60), 114ull, term_ctr(CID_SCON, STAT_OFF + 114), 101ull, term_ctr(CID_SCON, STAT_OFF + 116), 115ull, term_ctr(CID_SCON, STAT_OFF + 118), 101ull, term_ctr(CID_SCON, STAT_OFF + 120), 114ull, term_ctr(CID_SCON, STAT_OFF + 122), 34ull, term_ctr(CID_SCON, STAT_OFF + 124), 44ull, term_ctr(CID_SCON, STAT_OFF + 126), 115ull, term_ctr(CID_SCON, STAT_OFF + 44), 97ull, term_ctr(CID_SCON, STAT_OFF + 130), 108ull, term_ctr(CID_SCON, STAT_OFF + 132), 99ull, term_ctr(CID_SCON, STAT_OFF + 134), 34ull, term_ctr(CID_SCON, STAT_OFF + 136), 44ull, term_ctr(CID_SCON, STAT_OFF + 138), 110ull, term_ctr(CID_SCON, STAT_OFF + 42), 105ull, term_ctr(CID_SCON, STAT_OFF + 142), 97ull, term_ctr(CID_SCON, STAT_OFF + 144), 109ull, term_ctr(CID_SCON, STAT_OFF + 146), 34ull, term_ctr(CID_SCON, STAT_OFF + 148), 123ull, term_ctr(CID_SCON, STAT_OFF + 150), 120ull, term_ctr(CID_SCON, STAT_OFF + 42), 117ull, term_ctr(CID_SCON, STAT_OFF + 154), 97ull, term_ctr(CID_SCON, STAT_OFF + 156), 34ull, term_ctr(CID_SCON, STAT_OFF + 158), 44ull, term_ctr(CID_SCON, STAT_OFF + 160), 103ull, term_ctr(CID_SCON, STAT_OFF + 42), 97ull, term_ctr(CID_SCON, STAT_OFF + 164), 108ull, term_ctr(CID_SCON, STAT_OFF + 166), 102ull, term_ctr(CID_SCON, STAT_OFF + 168), 34ull, term_ctr(CID_SCON, STAT_OFF + 170), 44ull, term_ctr(CID_SCON, STAT_OFF + 172), 108ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 176), 117ull, term_ctr(CID_SCON, STAT_OFF + 178), 110ull, term_ctr(CID_SCON, STAT_OFF + 180), 97ull, term_ctr(CID_SCON, STAT_OFF + 42), 34ull, term_ctr(CID_SCON, STAT_OFF + 184), 123ull, term_ctr(CID_SCON, STAT_OFF + 186), 98ull, term_ctr(CID_SCON, STAT_OFF + 42), 34ull, term_ctr(CID_SCON, STAT_OFF + 190), 44ull, term_ctr(CID_SCON, STAT_OFF + 192), 99ull, term_ctr(CID_SCON, STAT_OFF + 42), 34ull, term_ctr(CID_SCON, STAT_OFF + 196), 44ull, term_ctr(CID_SCON, STAT_OFF + 198), 100ull, term_ctr(CID_SCON, STAT_OFF + 42), 34ull, term_ctr(CID_SCON, STAT_OFF + 202), 44ull, term_ctr(CID_SCON, STAT_OFF + 204), 110ull, term_ctr(CID_SCON, STAT_OFF + 202), 105ull, term_ctr(CID_SCON, STAT_OFF + 208), 107ull, term_ctr(CID_SCON, STAT_OFF + 210), 34ull, term_ctr(CID_SCON, STAT_OFF + 212), 123ull, term_ctr(CID_SCON, STAT_OFF + 214), 119ull, term_ctr(CID_SCON, STAT_OFF + 78), 101ull, term_ctr(CID_SCON, STAT_OFF + 218), 105ull, term_ctr(CID_SCON, STAT_OFF + 220), 86ull, term_ctr(CID_SCON, STAT_OFF + 222), 110ull, term_ctr(CID_SCON, STAT_OFF + 224), 119ull, term_ctr(CID_SCON, STAT_OFF + 226), 97ull, term_ctr(CID_SCON, STAT_OFF + 228), 112ull, term_ctr(CID_SCON, STAT_OFF + 230), 83ull, term_ctr(CID_SCON, STAT_OFF + 232), 34ull, term_ctr(CID_SCON, STAT_OFF + 234), 105ull, term_ctr(CID_SCON, STAT_OFF + 202), 34ull, term_ctr(CID_SCON, STAT_OFF + 238), 44ull, term_ctr(CID_SCON, STAT_OFF + 240), 108ull, term_ctr(CID_SCON, STAT_OFF + 60), 100ull, term_ctr(CID_SCON, STAT_OFF + 244), 110ull, term_ctr(CID_SCON, STAT_OFF + 246), 117ull, term_ctr(CID_SCON, STAT_OFF + 248), 98ull, term_ctr(CID_SCON, STAT_OFF + 250), 34ull, term_ctr(CID_SCON, STAT_OFF + 252), 44ull, term_ctr(CID_SCON, STAT_OFF + 254), 105ull, term_ctr(CID_SCON, STAT_OFF + 226), 97ull, term_ctr(CID_SCON, STAT_OFF + 258), 77ull, term_ctr(CID_SCON, STAT_OFF + 260), 34ull, term_ctr(CID_SCON, STAT_OFF + 262), 44ull, term_ctr(CID_SCON, STAT_OFF + 150), 103ull, term_ctr(CID_SCON, STAT_OFF + 224), 97ull, term_ctr(CID_SCON, STAT_OFF + 268), 108ull, term_ctr(CID_SCON, STAT_OFF + 270), 70ull, term_ctr(CID_SCON, STAT_OFF + 272), 34ull, term_ctr(CID_SCON, STAT_OFF + 274), 101ull, term_ctr(CID_SCON, STAT_OFF + 262), 118ull, term_ctr(CID_SCON, STAT_OFF + 278), 111ull, term_ctr(CID_SCON, STAT_OFF + 280), 109ull, term_ctr(CID_SCON, STAT_OFF + 282), 101ull, term_ctr(CID_SCON, STAT_OFF + 284), 82ull, term_ctr(CID_SCON, STAT_OFF + 286), 34ull, term_ctr(CID_SCON, STAT_OFF + 288), 101ull, term_ctr(CID_SCON, STAT_OFF + 274), 118ull, term_ctr(CID_SCON, STAT_OFF + 292), 111ull, term_ctr(CID_SCON, STAT_OFF + 294), 109ull, term_ctr(CID_SCON, STAT_OFF + 296), 101ull, term_ctr(CID_SCON, STAT_OFF + 298), 82ull, term_ctr(CID_SCON, STAT_OFF + 300), 34ull, term_ctr(CID_SCON, STAT_OFF + 302), 115ull, term_ctr(CID_SCON, STAT_OFF + 232), 101ull, term_ctr(CID_SCON, STAT_OFF + 306), 68ull, term_ctr(CID_SCON, STAT_OFF + 308), 34ull, term_ctr(CID_SCON, STAT_OFF + 310), 123ull, term_ctr(CID_SCON, STAT_OFF + 240), 101ull, term_ctr(CID_SCON, STAT_OFF + 202), 100ull, term_ctr(CID_SCON, STAT_OFF + 316), 100ull, term_ctr(CID_SCON, STAT_OFF + 318), 97ull, term_ctr(CID_SCON, STAT_OFF + 320), 34ull, term_ctr(CID_SCON, STAT_OFF + 322), 44ull, term_ctr(CID_SCON, STAT_OFF + 324), 103ull, term_ctr(CID_SCON, STAT_OFF + 316), 110ull, term_ctr(CID_SCON, STAT_OFF + 328), 97ull, term_ctr(CID_SCON, STAT_OFF + 330), 104ull, term_ctr(CID_SCON, STAT_OFF + 332), 99ull, term_ctr(CID_SCON, STAT_OFF + 334), 34ull, term_ctr(CID_SCON, STAT_OFF + 336), 44ull, term_ctr(CID_SCON, STAT_OFF + 338), 44ull, term_pak(CID_SNIL, 0), 47ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 100), 116ull, term_ctr(CID_SCON, STAT_OFF + 346), 111ull, term_ctr(CID_SCON, STAT_OFF + 348), 116ull, term_ctr(CID_SCON, STAT_OFF + 350), 34ull, term_ctr(CID_SCON, STAT_OFF + 352), 123ull, term_ctr(CID_SCON, STAT_OFF + 354), 104ull, term_ctr(CID_SCON, STAT_OFF + 42), 99ull, term_ctr(CID_SCON, STAT_OFF + 358), 111ull, term_ctr(CID_SCON, STAT_OFF + 360), 112ull, term_ctr(CID_SCON, STAT_OFF + 362), 101ull, term_ctr(CID_SCON, STAT_OFF + 364), 34ull, term_ctr(CID_SCON, STAT_OFF + 366), 44ull, term_ctr(CID_SCON, STAT_OFF + 368), 91ull, term_pak(CID_SNIL, 0), 93ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 374), term_pak(CID_NIL, 0), 59ull, term_pak(CID_SNIL, 0), 77ull, term_pak(CID_SNIL, 0), 76ull, term_ctr(CID_SCON, STAT_OFF + 40), term_ctr(CID_SCON, STAT_OFF + 78), term_pak(CID_NIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 60), 97ull, term_ctr(CID_SCON, STAT_OFF + 386), 112ull, term_ctr(CID_SCON, STAT_OFF + 388), 115ull, term_ctr(CID_SCON, STAT_OFF + 390), 101ull, term_ctr(CID_SCON, STAT_OFF + 392), 109ull, term_ctr(CID_SCON, STAT_OFF + 394), 97ull, term_ctr(CID_SCON, STAT_OFF + 396), 110ull, term_ctr(CID_SCON, STAT_OFF + 398), 34ull, term_ctr(CID_SCON, STAT_OFF + 400), 123ull, term_ctr(CID_SCON, STAT_OFF + 402), 110ull, term_ctr(CID_SCON, STAT_OFF + 78), 79ull, term_ctr(CID_SCON, STAT_OFF + 406), 104ull, term_ctr(CID_SCON, STAT_OFF + 408), 116ull, term_ctr(CID_SCON, STAT_OFF + 410), 108ull, term_ctr(CID_SCON, STAT_OFF + 412), 97ull, term_ctr(CID_SCON, STAT_OFF + 414), 101ull, term_ctr(CID_SCON, STAT_OFF + 416), 72ull, term_ctr(CID_SCON, STAT_OFF + 418), 34ull, term_ctr(CID_SCON, STAT_OFF + 420), 102ull, term_ctr(CID_SCON, STAT_OFF + 78), 102ull, term_ctr(CID_SCON, STAT_OFF + 424), 79ull, term_ctr(CID_SCON, STAT_OFF + 426), 104ull, term_ctr(CID_SCON, STAT_OFF + 428), 116ull, term_ctr(CID_SCON, STAT_OFF + 430), 108ull, term_ctr(CID_SCON, STAT_OFF + 432), 97ull, term_ctr(CID_SCON, STAT_OFF + 434), 101ull, term_ctr(CID_SCON, STAT_OFF + 436), 72ull, term_ctr(CID_SCON, STAT_OFF + 438), 34ull, term_ctr(CID_SCON, STAT_OFF + 440), 108ull, term_ctr(CID_SCON, STAT_OFF + 202), 114ull, term_ctr(CID_SCON, STAT_OFF + 444), 111ull, term_ctr(CID_SCON, STAT_OFF + 446), 119ull, term_ctr(CID_SCON, STAT_OFF + 448), 34ull, term_ctr(CID_SCON, STAT_OFF + 450), 44ull, term_ctr(CID_SCON, STAT_OFF + 452), 107ull, term_ctr(CID_SCON, STAT_OFF + 44), 114ull, term_ctr(CID_SCON, STAT_OFF + 456), 97ull, term_ctr(CID_SCON, STAT_OFF + 458), 109ull, term_ctr(CID_SCON, STAT_OFF + 460), 34ull, term_ctr(CID_SCON, STAT_OFF + 462), 44ull, term_ctr(CID_SCON, STAT_OFF + 464), 103ull, term_ctr(CID_SCON, STAT_OFF + 44), 110ull, term_ctr(CID_SCON, STAT_OFF + 468), 105ull, term_ctr(CID_SCON, STAT_OFF + 470), 112ull, term_ctr(CID_SCON, STAT_OFF + 472), 34ull, term_ctr(CID_SCON, STAT_OFF + 474), 44ull, term_ctr(CID_SCON, STAT_OFF + 476), 100ull, term_ctr(CID_SCON, STAT_OFF + 44), 110ull, term_ctr(CID_SCON, STAT_OFF + 480), 97ull, term_ctr(CID_SCON, STAT_OFF + 482), 109ull, term_ctr(CID_SCON, STAT_OFF + 484), 109ull, term_ctr(CID_SCON, STAT_OFF + 486), 111ull, term_ctr(CID_SCON, STAT_OFF + 488), 99ull, term_ctr(CID_SCON, STAT_OFF + 490), 34ull, term_ctr(CID_SCON, STAT_OFF + 492), 44ull, term_ctr(CID_SCON, STAT_OFF + 494), 111ull, term_ctr(CID_SCON, STAT_OFF + 42), 100ull, term_ctr(CID_SCON, STAT_OFF + 498), 110ull, term_ctr(CID_SCON, STAT_OFF + 500), 117ull, term_ctr(CID_SCON, STAT_OFF + 502), 34ull, term_ctr(CID_SCON, STAT_OFF + 504), 44ull, term_ctr(CID_SCON, STAT_OFF + 506), 116ull, term_ctr(CID_SCON, STAT_OFF + 316), 99ull, term_ctr(CID_SCON, STAT_OFF + 510), 101ull, term_ctr(CID_SCON, STAT_OFF + 512), 108ull, term_ctr(CID_SCON, STAT_OFF + 514), 101ull, term_ctr(CID_SCON, STAT_OFF + 516), 115ull, term_ctr(CID_SCON, STAT_OFF + 518), 34ull, term_ctr(CID_SCON, STAT_OFF + 520), 44ull, term_ctr(CID_SCON, STAT_OFF + 522), 117ull, term_ctr(CID_SCON, STAT_OFF + 60), 108ull, term_ctr(CID_SCON, STAT_OFF + 526), 97ull, term_ctr(CID_SCON, STAT_OFF + 528), 118ull, term_ctr(CID_SCON, STAT_OFF + 530), 34ull, term_ctr(CID_SCON, STAT_OFF + 532), 44ull, term_ctr(CID_SCON, STAT_OFF + 534), 34ull, term_ctr(CID_SCON, STAT_OFF + 536), 101ull, term_ctr(CID_SCON, STAT_OFF + 538), 114ull, term_ctr(CID_SCON, STAT_OFF + 540), 112ull, term_ctr(CID_SCON, STAT_OFF + 542), 34ull, term_ctr(CID_SCON, STAT_OFF + 544), 58ull, term_ctr(CID_SCON, STAT_OFF + 546), 34ull, term_ctr(CID_SCON, STAT_OFF + 548), 101ull, term_ctr(CID_SCON, STAT_OFF + 550), 115ull, term_ctr(CID_SCON, STAT_OFF + 552), 97ull, term_ctr(CID_SCON, STAT_OFF + 554), 104ull, term_ctr(CID_SCON, STAT_OFF + 556), 112ull, term_ctr(CID_SCON, STAT_OFF + 558), 34ull, term_ctr(CID_SCON, STAT_OFF + 560), 123ull, term_ctr(CID_SCON, STAT_OFF + 562), 116ull, term_ctr(CID_SCON, STAT_OFF + 42), 120ull, term_ctr(CID_SCON, STAT_OFF + 566), 101ull, term_ctr(CID_SCON, STAT_OFF + 568), 110ull, term_ctr(CID_SCON, STAT_OFF + 570), 34ull, term_ctr(CID_SCON, STAT_OFF + 572), 44ull, term_ctr(CID_SCON, STAT_OFF + 574), 119ull, term_ctr(CID_SCON, STAT_OFF + 44), 111ull, term_ctr(CID_SCON, STAT_OFF + 578), 114ull, term_ctr(CID_SCON, STAT_OFF + 580), 34ull, term_ctr(CID_SCON, STAT_OFF + 582), 44ull, term_ctr(CID_SCON, STAT_OFF + 584), 110ull, term_ctr(CID_SCON, STAT_OFF + 164), 105ull, term_ctr(CID_SCON, STAT_OFF + 588), 100ull, term_ctr(CID_SCON, STAT_OFF + 590), 110ull, term_ctr(CID_SCON, STAT_OFF + 592), 101ull, term_ctr(CID_SCON, STAT_OFF + 594), 112ull, term_ctr(CID_SCON, STAT_OFF + 596), 34ull, term_ctr(CID_SCON, STAT_OFF + 598), 44ull, term_ctr(CID_SCON, STAT_OFF + 600), 114ull, term_ctr(CID_SCON, STAT_OFF + 42), 101ull, term_ctr(CID_SCON, STAT_OFF + 604), 103ull, term_ctr(CID_SCON, STAT_OFF + 606), 100ull, term_ctr(CID_SCON, STAT_OFF + 608), 101ull, term_ctr(CID_SCON, STAT_OFF + 610), 108ull, term_ctr(CID_SCON, STAT_OFF + 612), 34ull, term_ctr(CID_SCON, STAT_OFF + 614), 44ull, term_ctr(CID_SCON, STAT_OFF + 616), 111ull, term_ctr(CID_SCON, STAT_OFF + 62), 109ull, term_ctr(CID_SCON, STAT_OFF + 620), 34ull, term_ctr(CID_SCON, STAT_OFF + 622), 44ull, term_ctr(CID_SCON, STAT_OFF + 624), 34ull, term_ctr(CID_SCON, STAT_OFF + 478), 116ull, term_ctr(CID_SCON, STAT_OFF + 628), 115ull, term_ctr(CID_SCON, STAT_OFF + 630), 111ull, term_ctr(CID_SCON, STAT_OFF + 632), 112ull, term_ctr(CID_SCON, STAT_OFF + 634), 34ull, term_ctr(CID_SCON, STAT_OFF + 636), 58ull, term_ctr(CID_SCON, STAT_OFF + 638), 34ull, term_ctr(CID_SCON, STAT_OFF + 640), 101ull, term_ctr(CID_SCON, STAT_OFF + 642), 115ull, term_ctr(CID_SCON, STAT_OFF + 644), 97ull, term_ctr(CID_SCON, STAT_OFF + 646), 104ull, term_ctr(CID_SCON, STAT_OFF + 648), 112ull, term_ctr(CID_SCON, STAT_OFF + 650), 34ull, term_ctr(CID_SCON, STAT_OFF + 652), 123ull, term_ctr(CID_SCON, STAT_OFF + 654), term_pak(CID_TRANSACTION_LEDGERINVERSE, 77ull), term_pak(CID_NIL, 0), term_pak(CID_STORAGE_DESPAWN, 2ull), term_pak(CID_NIL, 0), term_pak(CID_STORAGE_REMOVEFLAG, 1ull), term_ctr(CID_CON, STAT_OFF + 660), 11ull, term_pak(CID_NIL, 0), 12ull, term_ctr(CID_CON, STAT_OFF + 664), 7ull, 2ull, term_ctr(CID_STORAGE_HANDLE, STAT_OFF + 668), term_pak(CID_NIL, 0) };

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  Term _aux_2 = r2;
  Term _metadata_8 = r3;
  Term _metadata_9 = r4;
  Term _metadata_10 = r5;
  Term _metadata_11 = r6;
  u32 _capacity_2 = r7;
  Term _depth_2 = r8;
  u32 _high_2 = r9;
  Term _pending_2 = r10;
  u32 _ledger_4 = r11;
  Term _ledger_5 = r12;
  Term _mode_2 = r13;
  Term _main_0 = r14;
  u32 _index_2 = r15;
  Term _result_4 = r16;
  Term _result_5 = r17;
  WL_SPIN
    Term _at_0 = _main_0 == h14 ? q14 : blk_loc(e.mem, _main_0);
    Term _at_1 = blk_at(_main_0, _index_2, 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, 1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _result_4);
    term_sink(e, _c_1);
    _v_17 = _namespace_2;
    _v_18 = _next_2;
    _v_19 = _main_0;
    _v_20 = _aux_2;
    _v_21 = _metadata_8;
    _v_22 = _metadata_9;
    _v_23 = _metadata_10;
    _v_24 = _metadata_11;
    _v_25 = _capacity_2;
    _v_26 = _depth_2;
    _v_27 = _high_2;
    _v_28 = _pending_2;
    _v_29 = _ledger_4;
    _v_30 = _ledger_5;
    _v_31 = _mode_2;
    _v_32 = 0;
    _v_33 = _result_5;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_122 = 0;
  u32 _v_123 = 0;
  u32 _v_124 = 0;
  u32 _v_125 = 0;
  u32 _v_126 = 0;
  u32 _a_2 = r0;
  u32 _b_1 = r1;
  u32 _c_4 = r2;
  Term _result_23 = r3;
  u32 _result_24 = r4;
  WL_SPIN
    _v_122 = _result_23;
    _v_123 = _a_2;
    _v_124 = _b_1;
    _v_125 = _c_4;
    _v_126 = _result_24;
  break;
  }
  o[0] = _v_122;
  o[1] = _v_123;
  o[2] = _v_124;
  o[3] = _v_125;
  o[4] = _v_126;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_112 = 0;
  u32 _v_113 = 0;
  u32 _v_114 = 0;
  u32 _v_115 = 0;
  u32 _v_116 = 0;
  u32 _a_1 = r0;
  u32 _b_0 = r1;
  Term _result_21 = r2;
  u32 _result_22 = r3;
  WL_SPIN
    Term _at_6 = _result_21 == h2 ? q2 : blk_loc(e.mem, _result_21);
    Term _at_7 = blk_at(_result_21, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    Term _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    Term _o_0[5];
    if (spin_16(e, _o_0, _a_1, _b_0, _result_22, _result_21, _result_21 == h2 ? q2 : blk_loc(e.mem, _result_21), _c_3) == 0) {
      return 0;
    }
    _v_117 = _o_0[0];
    _v_118 = _o_0[1];
    _v_119 = _o_0[2];
    _v_120 = _o_0[3];
    _v_121 = _o_0[4];
    _v_112 = _v_117;
    _v_113 = _v_118;
    _v_114 = _v_119;
    _v_115 = _v_120;
    _v_116 = _v_121;
  break;
  }
  o[0] = _v_112;
  o[1] = _v_113;
  o[2] = _v_114;
  o[3] = _v_115;
  o[4] = _v_116;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _v_105 = 0;
  u32 _v_106 = 0;
  u32 _a_0 = r0;
  Term _result_19 = r1;
  u32 _result_20 = r2;
  WL_SPIN
    Term _at_4 = _result_19 == h1 ? q1 : blk_loc(e.mem, _result_19);
    Term _at_5 = blk_at(_result_19, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    Term _o_1[5];
    if (spin_15(e, _o_1, _a_0, _result_20, _result_19, _result_19 == h1 ? q1 : blk_loc(e.mem, _result_19), _c_2) == 0) {
      return 0;
    }
    _v_107 = _o_1[0];
    _v_108 = _o_1[1];
    _v_109 = _o_1[2];
    _v_110 = _o_1[3];
    _v_111 = _o_1[4];
    _v_102 = _v_107;
    _v_103 = _v_108;
    _v_104 = _v_109;
    _v_105 = _v_110;
    _v_106 = _v_111;
  break;
  }
  o[0] = _v_102;
  o[1] = _v_103;
  o[2] = _v_104;
  o[3] = _v_105;
  o[4] = _v_106;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _v_96 = 0;
  Term _result_17 = r0;
  u32 _result_18 = r1;
  WL_SPIN
    Term _at_2 = _result_17 == h0 ? q0 : blk_loc(e.mem, _result_17);
    Term _at_3 = blk_at(_result_17, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    Term _o_2[5];
    if (spin_14(e, _o_2, _result_18, _result_17, _result_17 == h0 ? q0 : blk_loc(e.mem, _result_17), _c_1) == 0) {
      return 0;
    }
    _v_97 = _o_2[0];
    _v_98 = _o_2[1];
    _v_99 = _o_2[2];
    _v_100 = _o_2[3];
    _v_101 = _o_2[4];
    _v_92 = _v_97;
    _v_93 = _v_98;
    _v_94 = _v_99;
    _v_95 = _v_100;
    _v_96 = _v_101;
  break;
  }
  o[0] = _v_92;
  o[1] = _v_93;
  o[2] = _v_94;
  o[3] = _v_95;
  o[4] = _v_96;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  Term _array_1 = r0;
  WL_SPIN
    Term _at_0 = _array_1 == h0 ? q0 : blk_loc(e.mem, _array_1);
    Term _at_1 = blk_at(_array_1, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    Term _o_3[5];
    if (spin_13(e, _o_3, _array_1, _array_1 == h0 ? q0 : blk_loc(e.mem, _array_1), _c_0) == 0) {
      return 0;
    }
    _v_87 = _o_3[0];
    _v_88 = _o_3[1];
    _v_89 = _o_3[2];
    _v_90 = _o_3[3];
    _v_91 = _o_3[4];
    _v_82 = _v_87;
    _v_83 = _v_88;
    _v_84 = _v_89;
    _v_85 = _v_90;
    _v_86 = _v_91;
  break;
  }
  o[0] = _v_82;
  o[1] = _v_83;
  o[2] = _v_84;
  o[3] = _v_85;
  o[4] = _v_86;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  Term _array_0 = r0;
  WL_SPIN
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _o_4[5];
    if (spin_12(e, _o_4, _array_0, _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0)) == 0) {
      return 0;
    }
    _v_77 = _o_4[0];
    _v_78 = _o_4[1];
    _v_79 = _o_4[2];
    _v_80 = _o_4[3];
    _v_81 = _o_4[4];
    _v_72 = _v_77;
    _v_73 = _v_78;
    _v_74 = _v_79;
    _v_75 = _v_80;
    _v_76 = _v_81;
  break;
  }
  o[0] = _v_72;
  o[1] = _v_73;
  o[2] = _v_74;
  o[3] = _v_75;
  o[4] = _v_76;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_134 = 0;
  u32 _v_135 = 0;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  u32 _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  u32 _grade_0 = r0;
  Term _result_25 = r1;
  u32 _result_26 = r2;
  u32 _result_27 = r3;
  u32 _result_28 = r4;
  u32 _result_29 = r5;
  WL_SPIN
    _v_134 = _result_25;
    _v_135 = _grade_0;
    _v_136 = _result_26;
    _v_137 = _result_27;
    _v_138 = _result_28;
    _v_139 = _result_29;
    _v_140 = _grade_0;
  break;
  }
  o[0] = _v_134;
  o[1] = _v_135;
  o[2] = _v_136;
  o[3] = _v_137;
  o[4] = _v_138;
  o[5] = _v_139;
  o[6] = _v_140;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  Term _owner_5 = r0;
  u32 _owner_6 = r1;
  WL_SPIN
    Term _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    Term _o_5[5];
    if (spin_11(e, _o_5, _owner_5, _owner_5 == h0 ? q0 : blk_loc(e.mem, _owner_5)) == 0) {
      return 0;
    }
    _v_67 = _o_5[0];
    _v_68 = _o_5[1];
    _v_69 = _o_5[2];
    _v_70 = _o_5[3];
    _v_71 = _o_5[4];
    _v_62 = _v_67;
    _v_63 = _v_68;
    _v_64 = _v_69;
    _v_65 = _v_70;
    _v_66 = _v_71;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    Term _o_6[7];
    if (spin_17(e, _o_6, _owner_6, _v_62, _v_62 == h0 ? q0 : blk_loc(e.mem, _v_62), _v_63, _v_64, _v_65, _v_66) == 0) {
      return 0;
    }
    _v_127 = _o_6[0];
    _v_128 = _o_6[1];
    _v_129 = _o_6[2];
    _v_130 = _o_6[3];
    _v_131 = _o_6[4];
    _v_132 = _o_6[5];
    _v_133 = _o_6[6];
    _v_55 = _v_127;
    _v_56 = _v_128;
    _v_57 = _v_129;
    _v_58 = _v_130;
    _v_59 = _v_131;
    _v_60 = _v_132;
    _v_61 = _v_133;
  break;
  }
  o[0] = _v_55;
  o[1] = _v_56;
  o[2] = _v_57;
  o[3] = _v_58;
  o[4] = _v_59;
  o[5] = _v_60;
  o[6] = _v_61;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _owner_3 = r0;
  u32 _owner_4 = r1;
  WL_SPIN
    Term _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    Term _o_7[7];
    if (spin_10(e, _o_7, _owner_3, _owner_3 == h0 ? q0 : blk_loc(e.mem, _owner_3), _owner_4) == 0) {
      return 0;
    }
    _v_48 = _o_7[0];
    _v_49 = _o_7[1];
    _v_50 = _o_7[2];
    _v_51 = _o_7[3];
    _v_52 = _o_7[4];
    _v_53 = _o_7[5];
    _v_54 = _o_7[6];
    _v_41 = _v_48;
    _v_42 = _v_49;
    _v_43 = _v_50;
    _v_44 = _v_51;
    _v_45 = _v_52;
    _v_46 = _v_53;
    _v_47 = _v_54;
  break;
  }
  o[0] = _v_41;
  o[1] = _v_42;
  o[2] = _v_43;
  o[3] = _v_44;
  o[4] = _v_45;
  o[5] = _v_46;
  o[6] = _v_47;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_145 = 0;
  Term _v_146 = 0;
  u32 _v_147 = 0;
  Term _v_148 = 0;
  Term _result_30 = r0;
  Term _result_31 = r1;
  WL_SPIN
    _v_145 = 1;
    _v_146 = _result_30;
    _v_147 = 1;
    _v_148 = _result_31;
  break;
  }
  o[0] = _v_145;
  o[1] = _v_146;
  o[2] = _v_147;
  o[3] = _v_148;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _owner_0 = r0;
  Term _owner_1 = r1;
  u32 _owner_2 = r2;
  WL_SPIN
    if (_owner_0 == 0) {
      _v_18 = 0;
      _v_19 = 0;
      _v_20 = 0;
      _v_21 = 0;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
      _v_26 = 0;
    } else {
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      u32 _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      u32 _v_33 = 0;
      Term _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      Term _o_8[7];
      if (spin_9(e, _o_8, _owner_1, _owner_1 == h1 ? q1 : blk_loc(e.mem, _owner_1), _owner_2) == 0) {
        return 0;
      }
      _v_34 = _o_8[0];
      _v_35 = _o_8[1];
      _v_36 = _o_8[2];
      _v_37 = _o_8[3];
      _v_38 = _o_8[4];
      _v_39 = _o_8[5];
      _v_40 = _o_8[6];
      _v_27 = _v_34;
      _v_28 = _v_35;
      _v_29 = _v_36;
      _v_30 = _v_37;
      _v_31 = _v_38;
      _v_32 = _v_39;
      _v_33 = _v_40;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _v_27);
      e.mem[_nd_0 + 1] = rfc_seal(e, _v_28);
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_29);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_30);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_31);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_32);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_33);
      u32 _v_141 = 0;
      Term _v_142 = 0;
      u32 _v_143 = 0;
      Term _v_144 = 0;
      Term _o_9[4];
      Term _a_3 = term_ctr(CID_TYPES_ARMOR, _nd_0);
      Term _a_4 = term_ctr(CID_TYPES_ARMORVIEW, _nd_1);
      if (spin_18(e, _o_9, _a_3, _a_3 == h1 ? q1 : blk_loc(e.mem, _a_3), _a_4, _a_4 == h1 ? q1 : blk_loc(e.mem, _a_4)) == 0) {
        return 0;
      }
      _v_141 = _o_9[0];
      _v_142 = _o_9[1];
      _v_143 = _o_9[2];
      _v_144 = _o_9[3];
      u32 _o_10 = 0;
      Term _o_11 = 0;
      u32 _o_12 = 0;
      if (_v_141 == 0) {
        _o_10 = 0;
      } else {
        _o_10 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _v_142, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        u32 _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        _o_11 = _f_0;
        _o_12 = _f_1;
      }
      u32 _o_13 = 0;
      u32 _o_14 = 0;
      u32 _o_15 = 0;
      u32 _o_16 = 0;
      u32 _o_17 = 0;
      u32 _o_18 = 0;
      if (_v_143 == 0) {
        _o_13 = 0;
      } else {
        _o_13 = 1;
        Term _fb_1[5];
        u64 _sp_1 = ctr_take(e, _v_144, 5, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        u32 _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        u32 _f_6 = _fb_1[4];
        spare_free(e, cls_fit(5), _sp_1);
        _o_14 = _f_2;
        _o_15 = _f_3;
        _o_16 = _f_4;
        _o_17 = _f_5;
        _o_18 = _f_6;
      }
      _v_18 = _o_10;
      _v_19 = _o_11;
      _v_20 = _o_12;
      _v_21 = _o_13;
      _v_22 = _o_14;
      _v_23 = _o_15;
      _v_24 = _o_16;
      _v_25 = _o_17;
      _v_26 = _o_18;
    }
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, u32 r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  u32 _v_167 = 0;
  u32 _v_168 = 0;
  Term _v_169 = 0;
  u32 _v_170 = 0;
  Term _v_171 = 0;
  u32 _v_172 = 0;
  Term _v_173 = 0;
  u32 _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  u32 _v_177 = 0;
  Term _v_178 = 0;
  u32 _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  u32 _v_184 = 0;
  u32 _id_1 = r0;
  u32 _main_0 = r1;
  Term _main_1 = r2;
  u32 _mainView_0 = r3;
  Term _mainView_1 = r4;
  u32 _flag_2 = r5;
  Term _flag_3 = r6;
  u32 _added_1 = r7;
  u32 _changed_1 = r8;
  u32 _result_32 = r9;
  Term _result_33 = r10;
  u32 _result_34 = r11;
  Term _result_35 = r12;
  WL_SPIN
    _flag_3 = term_keep(e, _flag_3, 1);
    _v_167 = _id_1;
    _v_168 = _main_0;
    _v_169 = _main_1;
    _v_170 = _result_32;
    _v_171 = _result_33;
    _v_172 = _flag_2;
    _v_173 = _flag_3;
    _v_174 = _added_1;
    _v_175 = _changed_1;
    _v_176 = _id_1;
    _v_177 = _mainView_0;
    _v_178 = _mainView_1;
    _v_179 = _result_34;
    _v_180 = _result_35;
    _v_181 = _flag_2;
    _v_182 = _flag_3;
    _v_183 = _added_1;
    _v_184 = _changed_1;
  break;
  }
  o[0] = _v_167;
  o[1] = _v_168;
  o[2] = _v_169;
  o[3] = _v_170;
  o[4] = _v_171;
  o[5] = _v_172;
  o[6] = _v_173;
  o[7] = _v_174;
  o[8] = _v_175;
  o[9] = _v_176;
  o[10] = _v_177;
  o[11] = _v_178;
  o[12] = _v_179;
  o[13] = _v_180;
  o[14] = _v_181;
  o[15] = _v_182;
  o[16] = _v_183;
  o[17] = _v_184;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_3 = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  u32 _epoch_0 = r0;
  u32 _value_1 = r1;
  Term _result_0 = r2;
  u32 _result_1 = r3;
  WL_SPIN
    Term _at_2 = _result_0 == h2 ? q2 : blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 0ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _value_1);
    _v_3 = _result_0;
    _v_4 = _epoch_0;
    _v_5 = _result_1;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _view_0 = r0;
  u32 _view_1 = r1;
  u32 _view_2 = r2;
  u32 _view_3 = r3;
  u32 _view_4 = r4;
  u32 _value_1 = r5;
  WL_SPIN
    _v_10 = _value_1;
    _v_11 = _view_1;
    _v_12 = _view_2;
    _v_13 = _view_3;
    _v_14 = _view_4;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

FAR Term spin_23(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _value_0 = r0;
  WL_SPIN
    if (_value_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 0);
    } else if ((_value_0 & 15) == 0) {
      u32 _14_0 = ((_value_0 >> 4) & 1);
      u32 _15_0 = ((_value_0 >> 5) & 1);
      u32 _15_1 = ((_value_0 >> 6) & 1);
      u32 _15_2 = ((_value_0 >> 7) & 1);
      u32 _15_3 = ((_value_0 >> 8) & 1);
      u32 _15_4 = ((_value_0 >> 9) & 1);
      u32 _15_5 = ((_value_0 >> 10) & 1);
      u32 _15_6 = ((_value_0 >> 11) & 1);
      u32 _15_7 = ((_value_0 >> 12) & 1);
      u32 _15_8 = ((_value_0 >> 13) & 1);
      u32 _15_9 = ((_value_0 >> 14) & 1);
      u32 _15_10 = ((_value_0 >> 15) & 1);
      u32 _15_11 = ((_value_0 >> 16) & 1);
      u32 _15_12 = ((_value_0 >> 17) & 1);
      u32 _15_13 = ((_value_0 >> 18) & 1);
      u32 _15_14 = ((_value_0 >> 19) & 1);
      u32 _15_15 = ((_value_0 >> 20) & 1);
      u32 _15_16 = ((_value_0 >> 21) & 1);
      u32 _15_17 = ((_value_0 >> 22) & 1);
      u32 _15_18 = ((_value_0 >> 23) & 1);
      u32 _15_19 = ((_value_0 >> 24) & 1);
      u32 _15_20 = ((_value_0 >> 25) & 1);
      u32 _15_21 = ((_value_0 >> 26) & 1);
      u32 _15_22 = ((_value_0 >> 27) & 1);
      u32 _15_23 = ((_value_0 >> 28) & 1);
      u32 _15_24 = ((_value_0 >> 29) & 1);
      u32 _15_25 = ((_value_0 >> 30) & 1);
      u32 _15_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 8) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 4);
    } else if ((_value_0 & 15) == 8) {
      u32 _70_0 = ((_value_0 >> 4) & 1);
      u32 _71_0 = ((_value_0 >> 5) & 1);
      u32 _71_1 = ((_value_0 >> 6) & 1);
      u32 _71_2 = ((_value_0 >> 7) & 1);
      u32 _71_3 = ((_value_0 >> 8) & 1);
      u32 _71_4 = ((_value_0 >> 9) & 1);
      u32 _71_5 = ((_value_0 >> 10) & 1);
      u32 _71_6 = ((_value_0 >> 11) & 1);
      u32 _71_7 = ((_value_0 >> 12) & 1);
      u32 _71_8 = ((_value_0 >> 13) & 1);
      u32 _71_9 = ((_value_0 >> 14) & 1);
      u32 _71_10 = ((_value_0 >> 15) & 1);
      u32 _71_11 = ((_value_0 >> 16) & 1);
      u32 _71_12 = ((_value_0 >> 17) & 1);
      u32 _71_13 = ((_value_0 >> 18) & 1);
      u32 _71_14 = ((_value_0 >> 19) & 1);
      u32 _71_15 = ((_value_0 >> 20) & 1);
      u32 _71_16 = ((_value_0 >> 21) & 1);
      u32 _71_17 = ((_value_0 >> 22) & 1);
      u32 _71_18 = ((_value_0 >> 23) & 1);
      u32 _71_19 = ((_value_0 >> 24) & 1);
      u32 _71_20 = ((_value_0 >> 25) & 1);
      u32 _71_21 = ((_value_0 >> 26) & 1);
      u32 _71_22 = ((_value_0 >> 27) & 1);
      u32 _71_23 = ((_value_0 >> 28) & 1);
      u32 _71_24 = ((_value_0 >> 29) & 1);
      u32 _71_25 = ((_value_0 >> 30) & 1);
      u32 _71_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 4) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 6);
    } else if ((_value_0 & 15) == 4) {
      u32 _128_0 = ((_value_0 >> 4) & 1);
      u32 _129_0 = ((_value_0 >> 5) & 1);
      u32 _129_1 = ((_value_0 >> 6) & 1);
      u32 _129_2 = ((_value_0 >> 7) & 1);
      u32 _129_3 = ((_value_0 >> 8) & 1);
      u32 _129_4 = ((_value_0 >> 9) & 1);
      u32 _129_5 = ((_value_0 >> 10) & 1);
      u32 _129_6 = ((_value_0 >> 11) & 1);
      u32 _129_7 = ((_value_0 >> 12) & 1);
      u32 _129_8 = ((_value_0 >> 13) & 1);
      u32 _129_9 = ((_value_0 >> 14) & 1);
      u32 _129_10 = ((_value_0 >> 15) & 1);
      u32 _129_11 = ((_value_0 >> 16) & 1);
      u32 _129_12 = ((_value_0 >> 17) & 1);
      u32 _129_13 = ((_value_0 >> 18) & 1);
      u32 _129_14 = ((_value_0 >> 19) & 1);
      u32 _129_15 = ((_value_0 >> 20) & 1);
      u32 _129_16 = ((_value_0 >> 21) & 1);
      u32 _129_17 = ((_value_0 >> 22) & 1);
      u32 _129_18 = ((_value_0 >> 23) & 1);
      u32 _129_19 = ((_value_0 >> 24) & 1);
      u32 _129_20 = ((_value_0 >> 25) & 1);
      u32 _129_21 = ((_value_0 >> 26) & 1);
      u32 _129_22 = ((_value_0 >> 27) & 1);
      u32 _129_23 = ((_value_0 >> 28) & 1);
      u32 _129_24 = ((_value_0 >> 29) & 1);
      u32 _129_25 = ((_value_0 >> 30) & 1);
      u32 _129_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 12) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 8);
    } else if ((_value_0 & 15) == 12) {
      u32 _184_0 = ((_value_0 >> 4) & 1);
      u32 _185_0 = ((_value_0 >> 5) & 1);
      u32 _185_1 = ((_value_0 >> 6) & 1);
      u32 _185_2 = ((_value_0 >> 7) & 1);
      u32 _185_3 = ((_value_0 >> 8) & 1);
      u32 _185_4 = ((_value_0 >> 9) & 1);
      u32 _185_5 = ((_value_0 >> 10) & 1);
      u32 _185_6 = ((_value_0 >> 11) & 1);
      u32 _185_7 = ((_value_0 >> 12) & 1);
      u32 _185_8 = ((_value_0 >> 13) & 1);
      u32 _185_9 = ((_value_0 >> 14) & 1);
      u32 _185_10 = ((_value_0 >> 15) & 1);
      u32 _185_11 = ((_value_0 >> 16) & 1);
      u32 _185_12 = ((_value_0 >> 17) & 1);
      u32 _185_13 = ((_value_0 >> 18) & 1);
      u32 _185_14 = ((_value_0 >> 19) & 1);
      u32 _185_15 = ((_value_0 >> 20) & 1);
      u32 _185_16 = ((_value_0 >> 21) & 1);
      u32 _185_17 = ((_value_0 >> 22) & 1);
      u32 _185_18 = ((_value_0 >> 23) & 1);
      u32 _185_19 = ((_value_0 >> 24) & 1);
      u32 _185_20 = ((_value_0 >> 25) & 1);
      u32 _185_21 = ((_value_0 >> 26) & 1);
      u32 _185_22 = ((_value_0 >> 27) & 1);
      u32 _185_23 = ((_value_0 >> 28) & 1);
      u32 _185_24 = ((_value_0 >> 29) & 1);
      u32 _185_25 = ((_value_0 >> 30) & 1);
      u32 _185_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 2) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 10);
    } else if ((_value_0 & 15) == 2) {
      u32 _244_0 = ((_value_0 >> 4) & 1);
      u32 _245_0 = ((_value_0 >> 5) & 1);
      u32 _245_1 = ((_value_0 >> 6) & 1);
      u32 _245_2 = ((_value_0 >> 7) & 1);
      u32 _245_3 = ((_value_0 >> 8) & 1);
      u32 _245_4 = ((_value_0 >> 9) & 1);
      u32 _245_5 = ((_value_0 >> 10) & 1);
      u32 _245_6 = ((_value_0 >> 11) & 1);
      u32 _245_7 = ((_value_0 >> 12) & 1);
      u32 _245_8 = ((_value_0 >> 13) & 1);
      u32 _245_9 = ((_value_0 >> 14) & 1);
      u32 _245_10 = ((_value_0 >> 15) & 1);
      u32 _245_11 = ((_value_0 >> 16) & 1);
      u32 _245_12 = ((_value_0 >> 17) & 1);
      u32 _245_13 = ((_value_0 >> 18) & 1);
      u32 _245_14 = ((_value_0 >> 19) & 1);
      u32 _245_15 = ((_value_0 >> 20) & 1);
      u32 _245_16 = ((_value_0 >> 21) & 1);
      u32 _245_17 = ((_value_0 >> 22) & 1);
      u32 _245_18 = ((_value_0 >> 23) & 1);
      u32 _245_19 = ((_value_0 >> 24) & 1);
      u32 _245_20 = ((_value_0 >> 25) & 1);
      u32 _245_21 = ((_value_0 >> 26) & 1);
      u32 _245_22 = ((_value_0 >> 27) & 1);
      u32 _245_23 = ((_value_0 >> 28) & 1);
      u32 _245_24 = ((_value_0 >> 29) & 1);
      u32 _245_25 = ((_value_0 >> 30) & 1);
      u32 _245_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 10) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 12);
    } else if ((_value_0 & 15) == 10) {
      u32 _300_0 = ((_value_0 >> 4) & 1);
      u32 _301_0 = ((_value_0 >> 5) & 1);
      u32 _301_1 = ((_value_0 >> 6) & 1);
      u32 _301_2 = ((_value_0 >> 7) & 1);
      u32 _301_3 = ((_value_0 >> 8) & 1);
      u32 _301_4 = ((_value_0 >> 9) & 1);
      u32 _301_5 = ((_value_0 >> 10) & 1);
      u32 _301_6 = ((_value_0 >> 11) & 1);
      u32 _301_7 = ((_value_0 >> 12) & 1);
      u32 _301_8 = ((_value_0 >> 13) & 1);
      u32 _301_9 = ((_value_0 >> 14) & 1);
      u32 _301_10 = ((_value_0 >> 15) & 1);
      u32 _301_11 = ((_value_0 >> 16) & 1);
      u32 _301_12 = ((_value_0 >> 17) & 1);
      u32 _301_13 = ((_value_0 >> 18) & 1);
      u32 _301_14 = ((_value_0 >> 19) & 1);
      u32 _301_15 = ((_value_0 >> 20) & 1);
      u32 _301_16 = ((_value_0 >> 21) & 1);
      u32 _301_17 = ((_value_0 >> 22) & 1);
      u32 _301_18 = ((_value_0 >> 23) & 1);
      u32 _301_19 = ((_value_0 >> 24) & 1);
      u32 _301_20 = ((_value_0 >> 25) & 1);
      u32 _301_21 = ((_value_0 >> 26) & 1);
      u32 _301_22 = ((_value_0 >> 27) & 1);
      u32 _301_23 = ((_value_0 >> 28) & 1);
      u32 _301_24 = ((_value_0 >> 29) & 1);
      u32 _301_25 = ((_value_0 >> 30) & 1);
      u32 _301_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 6) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 14);
    } else if ((_value_0 & 15) == 6) {
      u32 _358_0 = ((_value_0 >> 4) & 1);
      u32 _359_0 = ((_value_0 >> 5) & 1);
      u32 _359_1 = ((_value_0 >> 6) & 1);
      u32 _359_2 = ((_value_0 >> 7) & 1);
      u32 _359_3 = ((_value_0 >> 8) & 1);
      u32 _359_4 = ((_value_0 >> 9) & 1);
      u32 _359_5 = ((_value_0 >> 10) & 1);
      u32 _359_6 = ((_value_0 >> 11) & 1);
      u32 _359_7 = ((_value_0 >> 12) & 1);
      u32 _359_8 = ((_value_0 >> 13) & 1);
      u32 _359_9 = ((_value_0 >> 14) & 1);
      u32 _359_10 = ((_value_0 >> 15) & 1);
      u32 _359_11 = ((_value_0 >> 16) & 1);
      u32 _359_12 = ((_value_0 >> 17) & 1);
      u32 _359_13 = ((_value_0 >> 18) & 1);
      u32 _359_14 = ((_value_0 >> 19) & 1);
      u32 _359_15 = ((_value_0 >> 20) & 1);
      u32 _359_16 = ((_value_0 >> 21) & 1);
      u32 _359_17 = ((_value_0 >> 22) & 1);
      u32 _359_18 = ((_value_0 >> 23) & 1);
      u32 _359_19 = ((_value_0 >> 24) & 1);
      u32 _359_20 = ((_value_0 >> 25) & 1);
      u32 _359_21 = ((_value_0 >> 26) & 1);
      u32 _359_22 = ((_value_0 >> 27) & 1);
      u32 _359_23 = ((_value_0 >> 28) & 1);
      u32 _359_24 = ((_value_0 >> 29) & 1);
      u32 _359_25 = ((_value_0 >> 30) & 1);
      u32 _359_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 14) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 16);
    } else if ((_value_0 & 15) == 14) {
      u32 _414_0 = ((_value_0 >> 4) & 1);
      u32 _415_0 = ((_value_0 >> 5) & 1);
      u32 _415_1 = ((_value_0 >> 6) & 1);
      u32 _415_2 = ((_value_0 >> 7) & 1);
      u32 _415_3 = ((_value_0 >> 8) & 1);
      u32 _415_4 = ((_value_0 >> 9) & 1);
      u32 _415_5 = ((_value_0 >> 10) & 1);
      u32 _415_6 = ((_value_0 >> 11) & 1);
      u32 _415_7 = ((_value_0 >> 12) & 1);
      u32 _415_8 = ((_value_0 >> 13) & 1);
      u32 _415_9 = ((_value_0 >> 14) & 1);
      u32 _415_10 = ((_value_0 >> 15) & 1);
      u32 _415_11 = ((_value_0 >> 16) & 1);
      u32 _415_12 = ((_value_0 >> 17) & 1);
      u32 _415_13 = ((_value_0 >> 18) & 1);
      u32 _415_14 = ((_value_0 >> 19) & 1);
      u32 _415_15 = ((_value_0 >> 20) & 1);
      u32 _415_16 = ((_value_0 >> 21) & 1);
      u32 _415_17 = ((_value_0 >> 22) & 1);
      u32 _415_18 = ((_value_0 >> 23) & 1);
      u32 _415_19 = ((_value_0 >> 24) & 1);
      u32 _415_20 = ((_value_0 >> 25) & 1);
      u32 _415_21 = ((_value_0 >> 26) & 1);
      u32 _415_22 = ((_value_0 >> 27) & 1);
      u32 _415_23 = ((_value_0 >> 28) & 1);
      u32 _415_24 = ((_value_0 >> 29) & 1);
      u32 _415_25 = ((_value_0 >> 30) & 1);
      u32 _415_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 18);
    } else if ((_value_0 & 15) == 1) {
      u32 _476_0 = ((_value_0 >> 4) & 1);
      u32 _477_0 = ((_value_0 >> 5) & 1);
      u32 _477_1 = ((_value_0 >> 6) & 1);
      u32 _477_2 = ((_value_0 >> 7) & 1);
      u32 _477_3 = ((_value_0 >> 8) & 1);
      u32 _477_4 = ((_value_0 >> 9) & 1);
      u32 _477_5 = ((_value_0 >> 10) & 1);
      u32 _477_6 = ((_value_0 >> 11) & 1);
      u32 _477_7 = ((_value_0 >> 12) & 1);
      u32 _477_8 = ((_value_0 >> 13) & 1);
      u32 _477_9 = ((_value_0 >> 14) & 1);
      u32 _477_10 = ((_value_0 >> 15) & 1);
      u32 _477_11 = ((_value_0 >> 16) & 1);
      u32 _477_12 = ((_value_0 >> 17) & 1);
      u32 _477_13 = ((_value_0 >> 18) & 1);
      u32 _477_14 = ((_value_0 >> 19) & 1);
      u32 _477_15 = ((_value_0 >> 20) & 1);
      u32 _477_16 = ((_value_0 >> 21) & 1);
      u32 _477_17 = ((_value_0 >> 22) & 1);
      u32 _477_18 = ((_value_0 >> 23) & 1);
      u32 _477_19 = ((_value_0 >> 24) & 1);
      u32 _477_20 = ((_value_0 >> 25) & 1);
      u32 _477_21 = ((_value_0 >> 26) & 1);
      u32 _477_22 = ((_value_0 >> 27) & 1);
      u32 _477_23 = ((_value_0 >> 28) & 1);
      u32 _477_24 = ((_value_0 >> 29) & 1);
      u32 _477_25 = ((_value_0 >> 30) & 1);
      u32 _477_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 9) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 20);
    } else if ((_value_0 & 15) == 9) {
      u32 _532_0 = ((_value_0 >> 4) & 1);
      u32 _533_0 = ((_value_0 >> 5) & 1);
      u32 _533_1 = ((_value_0 >> 6) & 1);
      u32 _533_2 = ((_value_0 >> 7) & 1);
      u32 _533_3 = ((_value_0 >> 8) & 1);
      u32 _533_4 = ((_value_0 >> 9) & 1);
      u32 _533_5 = ((_value_0 >> 10) & 1);
      u32 _533_6 = ((_value_0 >> 11) & 1);
      u32 _533_7 = ((_value_0 >> 12) & 1);
      u32 _533_8 = ((_value_0 >> 13) & 1);
      u32 _533_9 = ((_value_0 >> 14) & 1);
      u32 _533_10 = ((_value_0 >> 15) & 1);
      u32 _533_11 = ((_value_0 >> 16) & 1);
      u32 _533_12 = ((_value_0 >> 17) & 1);
      u32 _533_13 = ((_value_0 >> 18) & 1);
      u32 _533_14 = ((_value_0 >> 19) & 1);
      u32 _533_15 = ((_value_0 >> 20) & 1);
      u32 _533_16 = ((_value_0 >> 21) & 1);
      u32 _533_17 = ((_value_0 >> 22) & 1);
      u32 _533_18 = ((_value_0 >> 23) & 1);
      u32 _533_19 = ((_value_0 >> 24) & 1);
      u32 _533_20 = ((_value_0 >> 25) & 1);
      u32 _533_21 = ((_value_0 >> 26) & 1);
      u32 _533_22 = ((_value_0 >> 27) & 1);
      u32 _533_23 = ((_value_0 >> 28) & 1);
      u32 _533_24 = ((_value_0 >> 29) & 1);
      u32 _533_25 = ((_value_0 >> 30) & 1);
      u32 _533_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 5) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 22);
    } else if ((_value_0 & 15) == 5) {
      u32 _590_0 = ((_value_0 >> 4) & 1);
      u32 _591_0 = ((_value_0 >> 5) & 1);
      u32 _591_1 = ((_value_0 >> 6) & 1);
      u32 _591_2 = ((_value_0 >> 7) & 1);
      u32 _591_3 = ((_value_0 >> 8) & 1);
      u32 _591_4 = ((_value_0 >> 9) & 1);
      u32 _591_5 = ((_value_0 >> 10) & 1);
      u32 _591_6 = ((_value_0 >> 11) & 1);
      u32 _591_7 = ((_value_0 >> 12) & 1);
      u32 _591_8 = ((_value_0 >> 13) & 1);
      u32 _591_9 = ((_value_0 >> 14) & 1);
      u32 _591_10 = ((_value_0 >> 15) & 1);
      u32 _591_11 = ((_value_0 >> 16) & 1);
      u32 _591_12 = ((_value_0 >> 17) & 1);
      u32 _591_13 = ((_value_0 >> 18) & 1);
      u32 _591_14 = ((_value_0 >> 19) & 1);
      u32 _591_15 = ((_value_0 >> 20) & 1);
      u32 _591_16 = ((_value_0 >> 21) & 1);
      u32 _591_17 = ((_value_0 >> 22) & 1);
      u32 _591_18 = ((_value_0 >> 23) & 1);
      u32 _591_19 = ((_value_0 >> 24) & 1);
      u32 _591_20 = ((_value_0 >> 25) & 1);
      u32 _591_21 = ((_value_0 >> 26) & 1);
      u32 _591_22 = ((_value_0 >> 27) & 1);
      u32 _591_23 = ((_value_0 >> 28) & 1);
      u32 _591_24 = ((_value_0 >> 29) & 1);
      u32 _591_25 = ((_value_0 >> 30) & 1);
      u32 _591_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 13) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 24);
    } else if ((_value_0 & 15) == 13) {
      u32 _646_0 = ((_value_0 >> 4) & 1);
      u32 _647_0 = ((_value_0 >> 5) & 1);
      u32 _647_1 = ((_value_0 >> 6) & 1);
      u32 _647_2 = ((_value_0 >> 7) & 1);
      u32 _647_3 = ((_value_0 >> 8) & 1);
      u32 _647_4 = ((_value_0 >> 9) & 1);
      u32 _647_5 = ((_value_0 >> 10) & 1);
      u32 _647_6 = ((_value_0 >> 11) & 1);
      u32 _647_7 = ((_value_0 >> 12) & 1);
      u32 _647_8 = ((_value_0 >> 13) & 1);
      u32 _647_9 = ((_value_0 >> 14) & 1);
      u32 _647_10 = ((_value_0 >> 15) & 1);
      u32 _647_11 = ((_value_0 >> 16) & 1);
      u32 _647_12 = ((_value_0 >> 17) & 1);
      u32 _647_13 = ((_value_0 >> 18) & 1);
      u32 _647_14 = ((_value_0 >> 19) & 1);
      u32 _647_15 = ((_value_0 >> 20) & 1);
      u32 _647_16 = ((_value_0 >> 21) & 1);
      u32 _647_17 = ((_value_0 >> 22) & 1);
      u32 _647_18 = ((_value_0 >> 23) & 1);
      u32 _647_19 = ((_value_0 >> 24) & 1);
      u32 _647_20 = ((_value_0 >> 25) & 1);
      u32 _647_21 = ((_value_0 >> 26) & 1);
      u32 _647_22 = ((_value_0 >> 27) & 1);
      u32 _647_23 = ((_value_0 >> 28) & 1);
      u32 _647_24 = ((_value_0 >> 29) & 1);
      u32 _647_25 = ((_value_0 >> 30) & 1);
      u32 _647_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 3) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 26);
    } else if ((_value_0 & 15) == 3) {
      u32 _706_0 = ((_value_0 >> 4) & 1);
      u32 _707_0 = ((_value_0 >> 5) & 1);
      u32 _707_1 = ((_value_0 >> 6) & 1);
      u32 _707_2 = ((_value_0 >> 7) & 1);
      u32 _707_3 = ((_value_0 >> 8) & 1);
      u32 _707_4 = ((_value_0 >> 9) & 1);
      u32 _707_5 = ((_value_0 >> 10) & 1);
      u32 _707_6 = ((_value_0 >> 11) & 1);
      u32 _707_7 = ((_value_0 >> 12) & 1);
      u32 _707_8 = ((_value_0 >> 13) & 1);
      u32 _707_9 = ((_value_0 >> 14) & 1);
      u32 _707_10 = ((_value_0 >> 15) & 1);
      u32 _707_11 = ((_value_0 >> 16) & 1);
      u32 _707_12 = ((_value_0 >> 17) & 1);
      u32 _707_13 = ((_value_0 >> 18) & 1);
      u32 _707_14 = ((_value_0 >> 19) & 1);
      u32 _707_15 = ((_value_0 >> 20) & 1);
      u32 _707_16 = ((_value_0 >> 21) & 1);
      u32 _707_17 = ((_value_0 >> 22) & 1);
      u32 _707_18 = ((_value_0 >> 23) & 1);
      u32 _707_19 = ((_value_0 >> 24) & 1);
      u32 _707_20 = ((_value_0 >> 25) & 1);
      u32 _707_21 = ((_value_0 >> 26) & 1);
      u32 _707_22 = ((_value_0 >> 27) & 1);
      u32 _707_23 = ((_value_0 >> 28) & 1);
      u32 _707_24 = ((_value_0 >> 29) & 1);
      u32 _707_25 = ((_value_0 >> 30) & 1);
      u32 _707_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 11) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 28);
    } else if ((_value_0 & 15) == 11) {
      u32 _762_0 = ((_value_0 >> 4) & 1);
      u32 _763_0 = ((_value_0 >> 5) & 1);
      u32 _763_1 = ((_value_0 >> 6) & 1);
      u32 _763_2 = ((_value_0 >> 7) & 1);
      u32 _763_3 = ((_value_0 >> 8) & 1);
      u32 _763_4 = ((_value_0 >> 9) & 1);
      u32 _763_5 = ((_value_0 >> 10) & 1);
      u32 _763_6 = ((_value_0 >> 11) & 1);
      u32 _763_7 = ((_value_0 >> 12) & 1);
      u32 _763_8 = ((_value_0 >> 13) & 1);
      u32 _763_9 = ((_value_0 >> 14) & 1);
      u32 _763_10 = ((_value_0 >> 15) & 1);
      u32 _763_11 = ((_value_0 >> 16) & 1);
      u32 _763_12 = ((_value_0 >> 17) & 1);
      u32 _763_13 = ((_value_0 >> 18) & 1);
      u32 _763_14 = ((_value_0 >> 19) & 1);
      u32 _763_15 = ((_value_0 >> 20) & 1);
      u32 _763_16 = ((_value_0 >> 21) & 1);
      u32 _763_17 = ((_value_0 >> 22) & 1);
      u32 _763_18 = ((_value_0 >> 23) & 1);
      u32 _763_19 = ((_value_0 >> 24) & 1);
      u32 _763_20 = ((_value_0 >> 25) & 1);
      u32 _763_21 = ((_value_0 >> 26) & 1);
      u32 _763_22 = ((_value_0 >> 27) & 1);
      u32 _763_23 = ((_value_0 >> 28) & 1);
      u32 _763_24 = ((_value_0 >> 29) & 1);
      u32 _763_25 = ((_value_0 >> 30) & 1);
      u32 _763_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 7) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 30);
    } else if ((_value_0 & 15) == 7) {
      u32 _820_0 = ((_value_0 >> 4) & 1);
      u32 _821_0 = ((_value_0 >> 5) & 1);
      u32 _821_1 = ((_value_0 >> 6) & 1);
      u32 _821_2 = ((_value_0 >> 7) & 1);
      u32 _821_3 = ((_value_0 >> 8) & 1);
      u32 _821_4 = ((_value_0 >> 9) & 1);
      u32 _821_5 = ((_value_0 >> 10) & 1);
      u32 _821_6 = ((_value_0 >> 11) & 1);
      u32 _821_7 = ((_value_0 >> 12) & 1);
      u32 _821_8 = ((_value_0 >> 13) & 1);
      u32 _821_9 = ((_value_0 >> 14) & 1);
      u32 _821_10 = ((_value_0 >> 15) & 1);
      u32 _821_11 = ((_value_0 >> 16) & 1);
      u32 _821_12 = ((_value_0 >> 17) & 1);
      u32 _821_13 = ((_value_0 >> 18) & 1);
      u32 _821_14 = ((_value_0 >> 19) & 1);
      u32 _821_15 = ((_value_0 >> 20) & 1);
      u32 _821_16 = ((_value_0 >> 21) & 1);
      u32 _821_17 = ((_value_0 >> 22) & 1);
      u32 _821_18 = ((_value_0 >> 23) & 1);
      u32 _821_19 = ((_value_0 >> 24) & 1);
      u32 _821_20 = ((_value_0 >> 25) & 1);
      u32 _821_21 = ((_value_0 >> 26) & 1);
      u32 _821_22 = ((_value_0 >> 27) & 1);
      u32 _821_23 = ((_value_0 >> 28) & 1);
      u32 _821_24 = ((_value_0 >> 29) & 1);
      u32 _821_25 = ((_value_0 >> 30) & 1);
      u32 _821_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    } else if (_value_0 == 15) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 32);
    } else {
      u32 _876_0 = ((_value_0 >> 4) & 1);
      u32 _877_0 = ((_value_0 >> 5) & 1);
      u32 _877_1 = ((_value_0 >> 6) & 1);
      u32 _877_2 = ((_value_0 >> 7) & 1);
      u32 _877_3 = ((_value_0 >> 8) & 1);
      u32 _877_4 = ((_value_0 >> 9) & 1);
      u32 _877_5 = ((_value_0 >> 10) & 1);
      u32 _877_6 = ((_value_0 >> 11) & 1);
      u32 _877_7 = ((_value_0 >> 12) & 1);
      u32 _877_8 = ((_value_0 >> 13) & 1);
      u32 _877_9 = ((_value_0 >> 14) & 1);
      u32 _877_10 = ((_value_0 >> 15) & 1);
      u32 _877_11 = ((_value_0 >> 16) & 1);
      u32 _877_12 = ((_value_0 >> 17) & 1);
      u32 _877_13 = ((_value_0 >> 18) & 1);
      u32 _877_14 = ((_value_0 >> 19) & 1);
      u32 _877_15 = ((_value_0 >> 20) & 1);
      u32 _877_16 = ((_value_0 >> 21) & 1);
      u32 _877_17 = ((_value_0 >> 22) & 1);
      u32 _877_18 = ((_value_0 >> 23) & 1);
      u32 _877_19 = ((_value_0 >> 24) & 1);
      u32 _877_20 = ((_value_0 >> 25) & 1);
      u32 _877_21 = ((_value_0 >> 26) & 1);
      u32 _877_22 = ((_value_0 >> 27) & 1);
      u32 _877_23 = ((_value_0 >> 28) & 1);
      u32 _877_24 = ((_value_0 >> 29) & 1);
      u32 _877_25 = ((_value_0 >> 30) & 1);
      u32 _877_26 = ((_value_0 >> 31) & 1);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 2);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_12 = 0;
  Term _s_1 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_s_1) == CID_SNIL) {
      _v_12 = _acc_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _s_1, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_3 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_1;
      r1 = term_ctr(CID_SCON, _nd_3);
      _s_1 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_27);
    }
  break;
  }
  o[0] = _v_12;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  Term _s_0 = r0;
  WL_SPIN
    Term _v_11 = 0;
    Term _o_2[1];
    Term _a_2 = term_pak(CID_SNIL, 0);
    if (spin_27(e, _o_2, _s_0, _s_0 == h0 ? q0 : blk_loc(e.mem, _s_0), _a_2, _a_2 == h0 ? q0 : blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_11 = _o_2[0];
    _v_10 = _v_11;
  break;
  }
  o[0] = _v_10;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_15 = 0;
  Term _value_1 = r0;
  Term _acc_2 = r1;
  WL_SPIN
    if (term_aux(_value_1) == CID_SNIL) {
      _v_15 = _acc_2;
    } else {
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _value_1, 2, _fb_2);
      u32 _f_4 = _fb_2[0];
      Term _f_5 = _fb_2[1];
      u64 _nd_4 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _f_4);
      e.mem[_nd_4 + 1] = rfc_seal(e, _acc_2);
      r0 = _f_5;
      r1 = term_ctr(CID_SCON, _nd_4);
      _value_1 = r0;
      _acc_2 = r1;
      WL_AGAIN(spin_28);
    }
  break;
  }
  o[0] = _v_15;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_8 = 0;
  Term _values_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_values_1) == CID_NIL) {
      Term _v_9 = 0;
      Term _o_3[1];
      if (spin_26(e, _o_3, _acc_0, _acc_0 == h1 ? q1 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_9 = _o_3[0];
      _v_8 = _v_9;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _values_1, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _v_13 = 0;
      Term _v_14 = 0;
      Term _o_4[1];
      if (spin_28(e, _o_4, _f_2, _f_2 == h1 ? q1 : _f_2 == h0 ? q0 : blk_loc(e.mem, _f_2), _acc_0, _acc_0 == h1 ? q1 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_14 = _o_4[0];
      _v_13 = _v_14;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _v_13;
      _values_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_25);
    }
  break;
  }
  o[0] = _v_8;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_6 = 0;
  Term _values_0 = r0;
  WL_SPIN
    Term _v_7 = 0;
    Term _o_5[1];
    Term _a_3 = term_pak(CID_SNIL, 0);
    if (spin_25(e, _o_5, _values_0, _values_0 == h0 ? q0 : blk_loc(e.mem, _values_0), _a_3, _a_3 == h0 ? q0 : blk_loc(e.mem, _a_3)) == 0) {
      return 0;
    }
    _v_7 = _o_5[0];
    _v_6 = _v_7;
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_18 = 0;
  u32 _x_0 = r0;
  WL_SPIN
    _v_18 = _x_0;
  break;
  }
  o[0] = _v_18;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_3 = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  Term _owner_2 = r0;
  u32 _owner_3 = r1;
  u32 _value_1 = r2;
  WL_SPIN
    Term _at_0 = _owner_2 == h0 ? q0 : blk_loc(e.mem, _owner_2);
    Term _at_1 = blk_at(_owner_2, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _o_0[3];
    if (spin_21(e, _o_0, _owner_3, _value_1, _owner_2, _owner_2 == h0 ? q0 : blk_loc(e.mem, _owner_2), _c_0) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_8 = _o_0[2];
    _v_3 = _v_6;
    _v_4 = _v_7;
    _v_5 = _v_8;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

FAR Term spin_33(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h9 = r9;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  u32 _v_71 = 0;
  u32 _id_0 = r0;
  u32 _aux_0 = r1;
  Term _aux_1 = r2;
  u32 _aux_2 = r3;
  u32 _flag_0 = r4;
  u32 _flag_1 = r5;
  u32 _added_0 = r6;
  u32 _changed_0 = r7;
  u32 _result_0 = r8;
  Term _result_1 = r9;
  u32 _result_2 = r10;
  u32 _result_3 = r11;
  u32 _result_4 = r12;
  u32 _result_5 = r13;
  u32 _result_6 = r14;
  u32 _result_7 = r15;
  u32 _result_8 = r16;
  u32 _result_9 = r17;
  u32 _result_10 = r18;
  u32 _result_11 = r19;
  u32 _result_12 = r20;
  u32 _result_13 = r21;
  u32 _result_14 = r22;
  u32 _result_15 = r23;
  u32 _result_16 = r24;
  WL_SPIN
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    Term _o_0[9];
    if (spin_8(e, _o_0, _aux_0, _aux_1, _aux_1 == h2 ? q2 : blk_loc(e.mem, _aux_1), _aux_2) == 0) {
      return 0;
    }
    _v_81 = _o_0[0];
    _v_82 = _o_0[1];
    _v_83 = _o_0[2];
    _v_84 = _o_0[3];
    _v_85 = _o_0[4];
    _v_86 = _o_0[5];
    _v_87 = _o_0[6];
    _v_88 = _o_0[7];
    _v_89 = _o_0[8];
    _v_72 = _v_81;
    _v_73 = _v_82;
    _v_74 = _v_83;
    _v_75 = _v_84;
    _v_76 = _v_85;
    _v_77 = _v_86;
    _v_78 = _v_87;
    _v_79 = _v_88;
    _v_80 = _v_89;
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_result_0 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _result_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _result_2);
      e.mem[_nd_0 + 2] = rfc_seal(e, _result_3);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_4);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_5);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_6);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_7);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_8);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_9);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
      _o_2 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    u32 _o_3 = 0;
    Term _o_4 = 0;
    if (_result_10 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_3 + 0] = rfc_seal(e, _result_11);
      e.mem[_nd_3 + 1] = rfc_seal(e, _result_12);
      e.mem[_nd_3 + 2] = rfc_seal(e, _result_13);
      e.mem[_nd_3 + 3] = rfc_seal(e, _result_14);
      e.mem[_nd_3 + 4] = rfc_seal(e, _result_15);
      e.mem[_nd_3 + 5] = rfc_seal(e, _result_16);
      _o_4 = term_ctr(CID_TYPES_VITALSVIEW, _nd_3);
    }
    u32 _o_5 = 0;
    Term _o_6 = 0;
    if (_flag_0 == 0) {
      _o_5 = 0;
    } else {
      _o_5 = 1;
      _o_6 = term_pak(CID_TYPES_TRACKED, _flag_1);
    }
    u32 _o_7 = 0;
    Term _o_8 = 0;
    if (_v_72 == 0) {
      _o_7 = 0;
    } else {
      _o_7 = 1;
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _v_73);
      e.mem[_nd_4 + 1] = rfc_seal(e, _v_74);
      _o_8 = term_ctr(CID_TYPES_ARMOR, _nd_4);
    }
    u32 _o_9 = 0;
    Term _o_10 = 0;
    if (_v_75 == 0) {
      _o_9 = 0;
    } else {
      _o_9 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_5 + 0] = rfc_seal(e, _v_76);
      e.mem[_nd_5 + 1] = rfc_seal(e, _v_77);
      e.mem[_nd_5 + 2] = rfc_seal(e, _v_78);
      e.mem[_nd_5 + 3] = rfc_seal(e, _v_79);
      e.mem[_nd_5 + 4] = rfc_seal(e, _v_80);
      _o_10 = term_ctr(CID_TYPES_ARMORVIEW, _nd_5);
    }
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    Term _v_92 = 0;
    u32 _v_93 = 0;
    Term _v_94 = 0;
    u32 _v_95 = 0;
    Term _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    Term _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    Term _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    Term _o_11[18];
    if (spin_19(e, _o_11, _id_0, _o_1, _o_2, _o_2 == h9 ? q9 : _o_2 == h2 ? q2 : blk_loc(e.mem, _o_2), _o_3, _o_4, _o_4 == h9 ? q9 : _o_4 == h2 ? q2 : blk_loc(e.mem, _o_4), _o_5, _o_6, _o_6 == h9 ? q9 : _o_6 == h2 ? q2 : blk_loc(e.mem, _o_6), _added_0, _changed_0, _o_7, _o_8, _o_8 == h9 ? q9 : _o_8 == h2 ? q2 : blk_loc(e.mem, _o_8), _o_9, _o_10, _o_10 == h9 ? q9 : _o_10 == h2 ? q2 : blk_loc(e.mem, _o_10)) == 0) {
      return 0;
    }
    _v_90 = _o_11[0];
    _v_91 = _o_11[1];
    _v_92 = _o_11[2];
    _v_93 = _o_11[3];
    _v_94 = _o_11[4];
    _v_95 = _o_11[5];
    _v_96 = _o_11[6];
    _v_97 = _o_11[7];
    _v_98 = _o_11[8];
    _v_99 = _o_11[9];
    _v_100 = _o_11[10];
    _v_101 = _o_11[11];
    _v_102 = _o_11[12];
    _v_103 = _o_11[13];
    _v_104 = _o_11[14];
    _v_105 = _o_11[15];
    _v_106 = _o_11[16];
    _v_107 = _o_11[17];
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    if (_v_91 == 0) {
      _o_12 = 0;
    } else {
      _o_12 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_92, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      Term _fb_2[6];
      u64 _sp_2 = ctr_take(e, _f_1, 6, _fb_2);
      u32 _f_5 = _fb_2[0];
      u32 _f_6 = _fb_2[1];
      u32 _f_7 = _fb_2[2];
      u32 _f_8 = _fb_2[3];
      u32 _f_9 = _fb_2[4];
      u32 _f_10 = _fb_2[5];
      spare_free(e, cls_fit(6), _sp_2);
      _o_13 = _f_2;
      _o_14 = _f_3;
      _o_15 = _f_4;
      _o_16 = _f_5;
      _o_17 = _f_6;
      _o_18 = _f_7;
      _o_19 = _f_8;
      _o_20 = _f_9;
      _o_21 = _f_10;
    }
    u32 _o_22 = 0;
    Term _o_23 = 0;
    u32 _o_24 = 0;
    if (_v_93 == 0) {
      _o_22 = 0;
    } else {
      _o_22 = 1;
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _v_94, 2, _fb_3);
      Term _f_11 = _fb_3[0];
      u32 _f_12 = _fb_3[1];
      spare_free(e, cls_fit(2), _sp_3);
      _o_23 = _f_11;
      _o_24 = _f_12;
    }
    u32 _o_25 = 0;
    u32 _o_26 = 0;
    if (_v_95 == 0) {
      _o_25 = 0;
    } else {
      _o_25 = 1;
      _o_26 = term_loc(_v_96);
    }
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    if (_v_100 == 0) {
      _o_27 = 0;
    } else {
      _o_27 = 1;
      Term _fb_4[6];
      u64 _sp_4 = ctr_take(e, _v_101, 6, _fb_4);
      u32 _f_13 = _fb_4[0];
      u32 _f_14 = _fb_4[1];
      u32 _f_15 = _fb_4[2];
      u32 _f_16 = _fb_4[3];
      u32 _f_17 = _fb_4[4];
      u32 _f_18 = _fb_4[5];
      spare_free(e, cls_fit(6), _sp_4);
      _o_28 = _f_13;
      _o_29 = _f_14;
      _o_30 = _f_15;
      _o_31 = _f_16;
      _o_32 = _f_17;
      _o_33 = _f_18;
    }
    u32 _o_34 = 0;
    u32 _o_35 = 0;
    u32 _o_36 = 0;
    u32 _o_37 = 0;
    u32 _o_38 = 0;
    u32 _o_39 = 0;
    if (_v_102 == 0) {
      _o_34 = 0;
    } else {
      _o_34 = 1;
      Term _fb_5[5];
      u64 _sp_5 = ctr_take(e, _v_103, 5, _fb_5);
      u32 _f_19 = _fb_5[0];
      u32 _f_20 = _fb_5[1];
      u32 _f_21 = _fb_5[2];
      u32 _f_22 = _fb_5[3];
      u32 _f_23 = _fb_5[4];
      spare_free(e, cls_fit(5), _sp_5);
      _o_35 = _f_19;
      _o_36 = _f_20;
      _o_37 = _f_21;
      _o_38 = _f_22;
      _o_39 = _f_23;
    }
    u32 _o_40 = 0;
    u32 _o_41 = 0;
    if (_v_104 == 0) {
      _o_40 = 0;
    } else {
      _o_40 = 1;
      _o_41 = term_loc(_v_105);
    }
    _v_36 = _v_90;
    _v_37 = _o_12;
    _v_38 = _o_13;
    _v_39 = _o_14;
    _v_40 = _o_15;
    _v_41 = _o_16;
    _v_42 = _o_17;
    _v_43 = _o_18;
    _v_44 = _o_19;
    _v_45 = _o_20;
    _v_46 = _o_21;
    _v_47 = _o_22;
    _v_48 = _o_23;
    _v_49 = _o_24;
    _v_50 = _o_25;
    _v_51 = _o_26;
    _v_52 = _v_97;
    _v_53 = _v_98;
    _v_54 = _v_99;
    _v_55 = _o_27;
    _v_56 = _o_28;
    _v_57 = _o_29;
    _v_58 = _o_30;
    _v_59 = _o_31;
    _v_60 = _o_32;
    _v_61 = _o_33;
    _v_62 = _o_34;
    _v_63 = _o_35;
    _v_64 = _o_36;
    _v_65 = _o_37;
    _v_66 = _o_38;
    _v_67 = _o_39;
    _v_68 = _o_40;
    _v_69 = _o_41;
    _v_70 = _v_106;
    _v_71 = _v_107;
  break;
  }
  o[0] = _v_36;
  o[1] = _v_37;
  o[2] = _v_38;
  o[3] = _v_39;
  o[4] = _v_40;
  o[5] = _v_41;
  o[6] = _v_42;
  o[7] = _v_43;
  o[8] = _v_44;
  o[9] = _v_45;
  o[10] = _v_46;
  o[11] = _v_47;
  o[12] = _v_48;
  o[13] = _v_49;
  o[14] = _v_50;
  o[15] = _v_51;
  o[16] = _v_52;
  o[17] = _v_53;
  o[18] = _v_54;
  o[19] = _v_55;
  o[20] = _v_56;
  o[21] = _v_57;
  o[22] = _v_58;
  o[23] = _v_59;
  o[24] = _v_60;
  o[25] = _v_61;
  o[26] = _v_62;
  o[27] = _v_63;
  o[28] = _v_64;
  o[29] = _v_65;
  o[30] = _v_66;
  o[31] = _v_67;
  o[32] = _v_68;
  o[33] = _v_69;
  o[34] = _v_70;
  o[35] = _v_71;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _reserve_0 = r0;
  u32 _class_0 = r1;
  u32 _value_1 = r2;
  Term _result_0 = r3;
  u32 _result_1 = r4;
  WL_SPIN
    Term _at_2 = _result_0 == h3 ? q3 : blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 0ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _value_1);
    _v_4 = _result_0;
    _v_5 = _reserve_0;
    _v_6 = _class_0;
    _v_7 = _result_1;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _view_0 = r0;
  u32 _view_1 = r1;
  u32 _view_2 = r2;
  u32 _view_3 = r3;
  u32 _view_4 = r4;
  u32 _view_5 = r5;
  u32 _value_1 = r6;
  WL_SPIN
    _v_12 = _value_1;
    _v_13 = _view_1;
    _v_14 = _view_2;
    _v_15 = _view_3;
    _v_16 = _view_4;
    _v_17 = _view_5;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, u32 r7, u32 r8) {
  u32 wpoll = 0;
  Term h6 = r6;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _cached_0 = r0;
  u32 _cached_1 = r1;
  u32 _cached_2 = r2;
  u32 _cached_3 = r3;
  u32 _cached_4 = r4;
  u32 _value_1 = r5;
  Term _result_0 = r6;
  u32 _result_1 = r7;
  u32 _result_2 = r8;
  WL_SPIN
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_1[5];
    if (spin_22(e, _o_1, _cached_0, _cached_1, _cached_2, _cached_3, _cached_4, _value_1) == 0) {
      return 0;
    }
    _v_27 = _o_1[0];
    _v_28 = _o_1[1];
    _v_29 = _o_1[2];
    _v_30 = _o_1[3];
    _v_31 = _o_1[4];
    _v_22 = _v_27;
    _v_23 = _v_28;
    _v_24 = _v_29;
    _v_25 = _v_30;
    _v_26 = _v_31;
    _v_14 = _result_0;
    _v_15 = _result_1;
    _v_16 = _v_22;
    _v_17 = _v_23;
    _v_18 = _v_24;
    _v_19 = _v_25;
    _v_20 = _v_26;
    _v_21 = _result_2;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  u32 _c_1 = r2;
  Term _result_2 = r3;
  u32 _result_3 = r4;
  WL_SPIN
    _v_5 = _result_2;
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = _c_1;
    _v_9 = _result_3;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  u32 _code_1 = r0;
  u32 _control_0 = r1;
  WL_SPIN
    if (_control_0 == 1) {
      Term _v_2 = 0;
      Term _a_0 = 16ull;
      Term _v_3 = 0;
      Term _o_0[1];
      if (spin_23(e, _o_0, ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_code_1), (u32)(_a_0)))) == 0) {
        return 0;
      }
      _v_3 = _o_0[0];
      _v_2 = _v_3;
      Term _v_4 = 0;
      Term _a_1 = 16ull;
      Term _v_5 = 0;
      Term _o_1[1];
      if (spin_23(e, _o_1, ((u32)(_a_1) == 0 ? _code_1 : U32_BIN(_code_1, -, U32_QUO((u32)(_code_1), (u32)(_a_1)) * _a_1))) == 0) {
        return 0;
      }
      _v_5 = _o_1[0];
      _v_4 = _v_5;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _v_4);
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 38));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
      Term _v_6 = 0;
      Term _o_2[1];
      Term _a_2 = term_ctr(CID_CON, _nd_2);
      if (spin_24(e, _o_2, _a_2, blk_loc(e.mem, _a_2)) == 0) {
        return 0;
      }
      _v_6 = _o_2[0];
      _v_1 = _v_6;
    } else {
      u32 _v_7 = 0;
      u32 _v_8 = 0;
      Term _o_3[1];
      if (spin_29(e, _o_3, _code_1) == 0) {
        return 0;
      }
      _v_8 = _o_3[0];
      _v_7 = _v_8;
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_7);
      e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_SNIL, 0));
      _v_1 = term_ctr(CID_SCON, _nd_3);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  Term _owner_3 = r0;
  u32 _owner_4 = r1;
  u32 _owner_5 = r2;
  u32 _value_1 = r3;
  WL_SPIN
    Term _at_0 = _owner_3 == h0 ? q0 : blk_loc(e.mem, _owner_3);
    Term _at_1 = blk_at(_owner_3, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_0[4];
    if (spin_35(e, _o_0, _owner_4, _owner_5, _value_1, _owner_3, _owner_3 == h0 ? q0 : blk_loc(e.mem, _owner_3), _c_0) == 0) {
      return 0;
    }
    _v_8 = _o_0[0];
    _v_9 = _o_0[1];
    _v_10 = _o_0[2];
    _v_11 = _o_0[3];
    _v_4 = _v_8;
    _v_5 = _v_9;
    _v_6 = _v_10;
    _v_7 = _v_11;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  Term _owner_20 = r0;
  u32 _owner_21 = r1;
  u32 _value_1 = r2;
  WL_SPIN
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_0[3];
    if (spin_30(e, _o_0, _owner_20, _owner_20 == h0 ? q0 : blk_loc(e.mem, _owner_20), _owner_21, _value_1) == 0) {
      return 0;
    }
    _v_9 = _o_0[0];
    _v_10 = _o_0[1];
    _v_11 = _o_0[2];
    _v_6 = _v_9;
    _v_7 = _v_10;
    _v_8 = _v_11;
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, u32 r20, u32 r21) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h11 = r11;
  Term h12 = r12;
  Term h19 = r19;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _main_raw_0 = r0;
  u32 _main_raw_1 = r1;
  u32 _main_raw_2 = r2;
  u32 _main_cached_0 = r3;
  u32 _main_cached_1 = r4;
  u32 _main_cached_2 = r5;
  u32 _main_cached_3 = r6;
  u32 _main_cached_4 = r7;
  u32 _main_cached_5 = r8;
  u32 _handle_0 = r9;
  u32 _handle_1 = r10;
  Term _undo_0 = r11;
  Term _marks_0 = r12;
  u32 _cached_0 = r13;
  u32 _cached_1 = r14;
  u32 _cached_2 = r15;
  u32 _cached_3 = r16;
  u32 _cached_4 = r17;
  u32 _value_2 = r18;
  Term _result_0 = r19;
  u32 _result_1 = r20;
  u32 _result_2 = r21;
  WL_SPIN
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    Term _o_2[5];
    if (spin_22(e, _o_2, _cached_0, _cached_1, _cached_2, _cached_3, _cached_4, _value_2) == 0) {
      return 0;
    }
    _v_57 = _o_2[0];
    _v_58 = _o_2[1];
    _v_59 = _o_2[2];
    _v_60 = _o_2[3];
    _v_61 = _o_2[4];
    _v_52 = _v_57;
    _v_53 = _v_58;
    _v_54 = _v_59;
    _v_55 = _v_60;
    _v_56 = _v_61;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, term_pak(CID_TRANSACTION_LEDGERINVERSE, _result_2));
    e.mem[_nd_0 + 1] = rfc_seal(e, _undo_0);
    _v_32 = _main_raw_0;
    _v_33 = _main_raw_1;
    _v_34 = _main_raw_2;
    _v_35 = _main_cached_0;
    _v_36 = _main_cached_1;
    _v_37 = _main_cached_2;
    _v_38 = _main_cached_3;
    _v_39 = _main_cached_4;
    _v_40 = _main_cached_5;
    _v_41 = _result_0;
    _v_42 = _result_1;
    _v_43 = _v_52;
    _v_44 = _v_53;
    _v_45 = _v_54;
    _v_46 = _v_55;
    _v_47 = _v_56;
    _v_48 = _handle_0;
    _v_49 = _handle_1;
    _v_50 = term_ctr(CID_CON, _nd_0);
    _v_51 = _marks_0;
  break;
  }
  o[0] = _v_32;
  o[1] = _v_33;
  o[2] = _v_34;
  o[3] = _v_35;
  o[4] = _v_36;
  o[5] = _v_37;
  o[6] = _v_38;
  o[7] = _v_39;
  o[8] = _v_40;
  o[9] = _v_41;
  o[10] = _v_42;
  o[11] = _v_43;
  o[12] = _v_44;
  o[13] = _v_45;
  o[14] = _v_46;
  o[15] = _v_47;
  o[16] = _v_48;
  o[17] = _v_49;
  o[18] = _v_50;
  o[19] = _v_51;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_3 = 0;
    } else {
      _v_3 = _b_0;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_4 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_5 = blk_at(_columns_0, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_0);
    Term _at_6 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_7 = blk_at(_columns_1, _index_0, 1);
    u32 _c_5 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_6 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _meta_1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _meta_2);
    term_sink(e, _c_6);
    Term _at_8 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_9 = blk_at(_columns_2, _index_0, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _meta_3);
    Term _at_10 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_11 = blk_at(_columns_3, _index_0, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _meta_4);
    _v_55 = _columns_0;
    _v_56 = _columns_1;
    _v_57 = _columns_2;
    _v_58 = _columns_3;
  break;
  }
  o[0] = _v_55;
  o[1] = _v_56;
  o[2] = _v_57;
  o[3] = _v_58;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _row_0 = r9;
  u32 _row_1 = r10;
  Term _row_2 = r11;
  u32 _row_3 = r12;
  Term _row_4 = r13;
  u32 _row_5 = r14;
  Term _row_6 = r15;
  u32 _row_7 = r16;
  u32 _row_8 = r17;
  WL_SPIN
    Term _at_0 = _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0);
    Term _at_1 = blk_at(_rows_0, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_2);
    term_sink(e, _c_1);
    Term _at_2 = _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1);
    Term _at_3 = blk_at(_rows_1, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_3);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_4);
    term_sink(e, _c_3);
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _o_12[4];
    if (spin_47(e, _o_12, _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), U32_BIN(_row_0, -, 1ull), 1, _row_5, _row_6, _row_6 == h15 ? q15 : blk_loc(e.mem, _row_6), _row_7, _row_8) == 0) {
      return 0;
    }
    _v_51 = _o_12[0];
    _v_52 = _o_12[1];
    _v_53 = _o_12[2];
    _v_54 = _o_12[3];
    _v_47 = _v_51;
    _v_48 = _v_52;
    _v_49 = _v_53;
    _v_50 = _v_54;
    _v_38 = _rows_0;
    _v_39 = _rows_1;
    _v_40 = _v_47;
    _v_41 = _v_48;
    _v_42 = _v_49;
    _v_43 = _v_50;
    _v_44 = _rows_6;
    _v_45 = _rows_7;
    _v_46 = _rows_8;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18, u32 r19, u32 r20, Term r21, u64 q21, u32 r22, Term r23, u64 q23, u32 r24, Term r25, u64 q25, u32 r26, u32 r27) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h9 = r9;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term h21 = r21;
  Term h23 = r23;
  Term h25 = r25;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _owners_0 = r0;
  Term _owners_1 = r1;
  Term _owners_2 = r2;
  Term _owners_3 = r3;
  Term _owners_4 = r4;
  Term _owners_5 = r5;
  u32 _owners_6 = r6;
  Term _owners_7 = r7;
  u32 _owners_8 = r8;
  Term _values_2 = r9;
  u32 _result_37 = r10;
  u32 _result_38 = r11;
  Term _result_39 = r12;
  u32 _result_40 = r13;
  Term _result_41 = r14;
  u32 _result_42 = r15;
  Term _result_43 = r16;
  u32 _result_44 = r17;
  u32 _result_45 = r18;
  u32 _result_46 = r19;
  u32 _result_47 = r20;
  Term _result_48 = r21;
  u32 _result_49 = r22;
  Term _result_50 = r23;
  u32 _result_51 = r24;
  Term _result_52 = r25;
  u32 _result_53 = r26;
  u32 _result_54 = r27;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_13[9];
    if (spin_46(e, _o_13, _owners_0, _owners_0 == h0 ? q0 : blk_loc(e.mem, _owners_0), _owners_1, _owners_1 == h1 ? q1 : blk_loc(e.mem, _owners_1), _owners_2, _owners_2 == h2 ? q2 : blk_loc(e.mem, _owners_2), _owners_3, _owners_3 == h3 ? q3 : blk_loc(e.mem, _owners_3), _owners_4, _owners_4 == h4 ? q4 : blk_loc(e.mem, _owners_4), _owners_5, _owners_5 == h5 ? q5 : blk_loc(e.mem, _owners_5), _owners_6, _owners_7, _owners_8, _result_37, _result_38, _result_39, _result_39 == h12 ? q12 : blk_loc(e.mem, _result_39), _result_40, _result_41, _result_41 == h14 ? q14 : blk_loc(e.mem, _result_41), _result_42, _result_43, _result_43 == h16 ? q16 : blk_loc(e.mem, _result_43), _result_44, _result_45) == 0) {
      return 0;
    }
    _v_29 = _o_13[0];
    _v_30 = _o_13[1];
    _v_31 = _o_13[2];
    _v_32 = _o_13[3];
    _v_33 = _o_13[4];
    _v_34 = _o_13[5];
    _v_35 = _o_13[6];
    _v_36 = _o_13[7];
    _v_37 = _o_13[8];
    _v_20 = _v_29;
    _v_21 = _v_30;
    _v_22 = _v_31;
    _v_23 = _v_32;
    _v_24 = _v_33;
    _v_25 = _v_34;
    _v_26 = _v_35;
    _v_27 = _v_36;
    _v_28 = _v_37;
    u64 _nd_6 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_6 + 0] = rfc_seal(e, _result_46);
    e.mem[_nd_6 + 1] = rfc_seal(e, _result_47);
    e.mem[_nd_6 + 2] = rfc_seal(e, _result_48);
    e.mem[_nd_6 + 3] = rfc_seal(e, _result_49);
    e.mem[_nd_6 + 4] = rfc_seal(e, _result_50);
    e.mem[_nd_6 + 5] = rfc_seal(e, _result_51);
    e.mem[_nd_6 + 6] = rfc_seal(e, _result_52);
    e.mem[_nd_6 + 7] = rfc_seal(e, _result_53);
    e.mem[_nd_6 + 8] = rfc_seal(e, _result_54);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_OBSERVATIONS_ROWVIEW, _nd_6));
    e.mem[_nd_7 + 1] = rfc_seal(e, _values_2);
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = term_ctr(CID_CON, _nd_7);
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _a_1 = r0;
  u32 _b_0 = r1;
  Term _result_4 = r2;
  u32 _result_5 = r3;
  WL_SPIN
    Term _at_6 = _result_4 == h2 ? q2 : blk_loc(e.mem, _result_4);
    Term _at_7 = blk_at(_result_4, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _o_0[5];
    if (spin_38(e, _o_0, _a_1, _b_0, _result_5, _result_4, _result_4 == h2 ? q2 : blk_loc(e.mem, _result_4), _c_3) == 0) {
      return 0;
    }
    _v_45 = _o_0[0];
    _v_46 = _o_0[1];
    _v_47 = _o_0[2];
    _v_48 = _o_0[3];
    _v_49 = _o_0[4];
    _v_40 = _v_45;
    _v_41 = _v_46;
    _v_42 = _v_47;
    _v_43 = _v_48;
    _v_44 = _v_49;
  break;
  }
  o[0] = _v_40;
  o[1] = _v_41;
  o[2] = _v_42;
  o[3] = _v_43;
  o[4] = _v_44;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _a_0 = r0;
  Term _result_2 = r1;
  u32 _result_3 = r2;
  WL_SPIN
    Term _at_4 = _result_2 == h1 ? q1 : blk_loc(e.mem, _result_2);
    Term _at_5 = blk_at(_result_2, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_1[5];
    if (spin_51(e, _o_1, _a_0, _result_3, _result_2, _result_2 == h1 ? q1 : blk_loc(e.mem, _result_2), _c_2) == 0) {
      return 0;
    }
    _v_35 = _o_1[0];
    _v_36 = _o_1[1];
    _v_37 = _o_1[2];
    _v_38 = _o_1[3];
    _v_39 = _o_1[4];
    _v_30 = _v_35;
    _v_31 = _v_36;
    _v_32 = _v_37;
    _v_33 = _v_38;
    _v_34 = _v_39;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  WL_SPIN
    Term _at_2 = _result_0 == h0 ? q0 : blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_2[5];
    if (spin_50(e, _o_2, _result_1, _result_0, _result_0 == h0 ? q0 : blk_loc(e.mem, _result_0), _c_1) == 0) {
      return 0;
    }
    _v_25 = _o_2[0];
    _v_26 = _o_2[1];
    _v_27 = _o_2[2];
    _v_28 = _o_2[3];
    _v_29 = _o_2[4];
    _v_20 = _v_25;
    _v_21 = _v_26;
    _v_22 = _v_27;
    _v_23 = _v_28;
    _v_24 = _v_29;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _array_0 = r0;
  WL_SPIN
    Term _at_0 = _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0);
    Term _at_1 = blk_at(_array_0, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_3[5];
    if (spin_49(e, _o_3, _array_0, _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0), _c_0) == 0) {
      return 0;
    }
    _v_15 = _o_3[0];
    _v_16 = _o_3[1];
    _v_17 = _o_3[2];
    _v_18 = _o_3[3];
    _v_19 = _o_3[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _epoch_0 = r0;
  Term _result_6 = r1;
  u32 _result_7 = r2;
  u32 _result_8 = r3;
  u32 _result_9 = r4;
  u32 _result_10 = r5;
  WL_SPIN
    _v_57 = _result_6;
    _v_58 = _epoch_0;
    _v_59 = _result_7;
    _v_60 = _result_8;
    _v_61 = _result_9;
    _v_62 = _result_10;
    _v_63 = _epoch_0;
  break;
  }
  o[0] = _v_57;
  o[1] = _v_58;
  o[2] = _v_59;
  o[3] = _v_60;
  o[4] = _v_61;
  o[5] = _v_62;
  o[6] = _v_63;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h7 = r7;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _cached_0 = r0;
  u32 _cached_1 = r1;
  u32 _cached_2 = r2;
  u32 _cached_3 = r3;
  u32 _cached_4 = r4;
  u32 _cached_5 = r5;
  u32 _value_1 = r6;
  Term _result_0 = r7;
  u32 _result_1 = r8;
  u32 _result_2 = r9;
  u32 _result_3 = r10;
  WL_SPIN
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_1[6];
    if (spin_36(e, _o_1, _cached_0, _cached_1, _cached_2, _cached_3, _cached_4, _cached_5, _value_1) == 0) {
      return 0;
    }
    _v_34 = _o_1[0];
    _v_35 = _o_1[1];
    _v_36 = _o_1[2];
    _v_37 = _o_1[3];
    _v_38 = _o_1[4];
    _v_39 = _o_1[5];
    _v_28 = _v_34;
    _v_29 = _v_35;
    _v_30 = _v_36;
    _v_31 = _v_37;
    _v_32 = _v_38;
    _v_33 = _v_39;
    _v_18 = _result_0;
    _v_19 = _result_1;
    _v_20 = _result_2;
    _v_21 = _v_28;
    _v_22 = _v_29;
    _v_23 = _v_30;
    _v_24 = _v_31;
    _v_25 = _v_32;
    _v_26 = _v_33;
    _v_27 = _result_3;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  o[9] = _v_27;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _owner_7 = r0;
  u32 _owner_8 = r1;
  u32 _owner_9 = r2;
  u32 _owner_10 = r3;
  u32 _owner_11 = r4;
  u32 _owner_12 = r5;
  u32 _owner_13 = r6;
  u32 _value_1 = r7;
  WL_SPIN
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_0[3];
    if (spin_30(e, _o_0, _owner_7, _owner_7 == h0 ? q0 : blk_loc(e.mem, _owner_7), _owner_8, _value_1) == 0) {
      return 0;
    }
    _v_19 = _o_0[0];
    _v_20 = _o_0[1];
    _v_21 = _o_0[2];
    _v_16 = _v_19;
    _v_17 = _v_20;
    _v_18 = _v_21;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_1[8];
    if (spin_37(e, _o_1, _owner_9, _owner_10, _owner_11, _owner_12, _owner_13, _value_1, _v_16, _v_16 == h0 ? q0 : blk_loc(e.mem, _v_16), _v_17, _v_18) == 0) {
      return 0;
    }
    _v_22 = _o_1[0];
    _v_23 = _o_1[1];
    _v_24 = _o_1[2];
    _v_25 = _o_1[3];
    _v_26 = _o_1[4];
    _v_27 = _o_1[5];
    _v_28 = _o_1[6];
    _v_29 = _o_1[7];
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    _v_14 = _v_28;
    _v_15 = _v_29;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _c_0 = r0;
  WL_SPIN
    _v_5 = _c_0;
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_7 = 0;
  u32 _code_0 = r0;
  WL_SPIN
    if (_code_0 == 34) {
      _v_7 = term_ctr(CID_SCON, STAT_OFF + 80);
    } else if (_code_0 == 92) {
      _v_7 = term_ctr(CID_SCON, STAT_OFF + 84);
    } else {
      u32 _9_0 = ((_code_0 >> 0) & 1);
      u32 _10_0 = ((_code_0 >> 1) & 1);
      u32 _10_1 = ((_code_0 >> 2) & 1);
      u32 _10_2 = ((_code_0 >> 3) & 1);
      u32 _10_3 = ((_code_0 >> 4) & 1);
      u32 _10_4 = ((_code_0 >> 5) & 1);
      u32 _10_5 = ((_code_0 >> 6) & 1);
      u32 _10_6 = ((_code_0 >> 7) & 1);
      u32 _10_7 = ((_code_0 >> 8) & 1);
      u32 _10_8 = ((_code_0 >> 9) & 1);
      u32 _10_9 = ((_code_0 >> 10) & 1);
      u32 _10_10 = ((_code_0 >> 11) & 1);
      u32 _10_11 = ((_code_0 >> 12) & 1);
      u32 _10_12 = ((_code_0 >> 13) & 1);
      u32 _10_13 = ((_code_0 >> 14) & 1);
      u32 _10_14 = ((_code_0 >> 15) & 1);
      u32 _10_15 = ((_code_0 >> 16) & 1);
      u32 _10_16 = ((_code_0 >> 17) & 1);
      u32 _10_17 = ((_code_0 >> 18) & 1);
      u32 _10_18 = ((_code_0 >> 19) & 1);
      u32 _10_19 = ((_code_0 >> 20) & 1);
      u32 _10_20 = ((_code_0 >> 21) & 1);
      u32 _10_21 = ((_code_0 >> 22) & 1);
      u32 _10_22 = ((_code_0 >> 23) & 1);
      u32 _10_23 = ((_code_0 >> 24) & 1);
      u32 _10_24 = ((_code_0 >> 25) & 1);
      u32 _10_25 = ((_code_0 >> 26) & 1);
      u32 _10_26 = ((_code_0 >> 27) & 1);
      u32 _10_27 = ((_code_0 >> 28) & 1);
      u32 _10_28 = ((_code_0 >> 29) & 1);
      u32 _10_29 = ((_code_0 >> 30) & 1);
      u32 _10_30 = ((_code_0 >> 31) & 1);
      Term _v_8 = 0;
      Term _o_2[1];
      if (spin_39(e, _o_2, (((u64)_9_0 << 0) | ((u64)_10_0 << 1) | ((u64)_10_1 << 2) | ((u64)_10_2 << 3) | ((u64)_10_3 << 4) | ((u64)_10_4 << 5) | ((u64)_10_5 << 6) | ((u64)_10_6 << 7) | ((u64)_10_7 << 8) | ((u64)_10_8 << 9) | ((u64)_10_9 << 10) | ((u64)_10_10 << 11) | ((u64)_10_11 << 12) | ((u64)_10_12 << 13) | ((u64)_10_13 << 14) | ((u64)_10_14 << 15) | ((u64)_10_15 << 16) | ((u64)_10_16 << 17) | ((u64)_10_17 << 18) | ((u64)_10_18 << 19) | ((u64)_10_19 << 20) | ((u64)_10_20 << 21) | ((u64)_10_21 << 22) | ((u64)_10_22 << 23) | ((u64)_10_23 << 24) | ((u64)_10_24 << 25) | ((u64)_10_25 << 26) | ((u64)_10_26 << 27) | ((u64)_10_27 << 28) | ((u64)_10_28 << 29) | ((u64)_10_29 << 30) | ((u64)_10_30 << 31)), U32_BIN((((u64)_9_0 << 0) | ((u64)_10_0 << 1) | ((u64)_10_1 << 2) | ((u64)_10_2 << 3) | ((u64)_10_3 << 4) | ((u64)_10_4 << 5) | ((u64)_10_5 << 6) | ((u64)_10_6 << 7) | ((u64)_10_7 << 8) | ((u64)_10_8 << 9) | ((u64)_10_9 << 10) | ((u64)_10_10 << 11) | ((u64)_10_11 << 12) | ((u64)_10_12 << 13) | ((u64)_10_13 << 14) | ((u64)_10_14 << 15) | ((u64)_10_15 << 16) | ((u64)_10_16 << 17) | ((u64)_10_17 << 18) | ((u64)_10_18 << 19) | ((u64)_10_19 << 20) | ((u64)_10_20 << 21) | ((u64)_10_21 << 22) | ((u64)_10_22 << 23) | ((u64)_10_23 << 24) | ((u64)_10_24 << 25) | ((u64)_10_25 << 26) | ((u64)_10_26 << 27) | ((u64)_10_27 << 28) | ((u64)_10_28 << 29) | ((u64)_10_29 << 30) | ((u64)_10_30 << 31)), <, 32ull)) == 0) {
        return 0;
      }
      _v_8 = _o_2[0];
      _v_7 = _v_8;
    }
  break;
  }
  o[0] = _v_7;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  Term _owner_20 = r0;
  u32 _owner_21 = r1;
  u32 _owner_22 = r2;
  u32 _value_1 = r3;
  WL_SPIN
    Term _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _o_0[4];
    if (spin_40(e, _o_0, _owner_20, _owner_20 == h0 ? q0 : blk_loc(e.mem, _owner_20), _owner_21, _owner_22, _value_1) == 0) {
      return 0;
    }
    _v_12 = _o_0[0];
    _v_13 = _o_0[1];
    _v_14 = _o_0[2];
    _v_15 = _o_0[3];
    _v_8 = _v_12;
    _v_9 = _v_13;
    _v_10 = _v_14;
    _v_11 = _v_15;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, u32 r19, u32 r20, u32 r21) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h10 = r10;
  Term h18 = r18;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _ledger_raw_0 = r0;
  u32 _ledger_raw_1 = r1;
  u32 _ledger_cached_0 = r2;
  u32 _ledger_cached_1 = r3;
  u32 _ledger_cached_2 = r4;
  u32 _ledger_cached_3 = r5;
  u32 _ledger_cached_4 = r6;
  u32 _handle_0 = r7;
  u32 _handle_1 = r8;
  Term _undo_0 = r9;
  Term _marks_0 = r10;
  u32 _cached_0 = r11;
  u32 _cached_1 = r12;
  u32 _cached_2 = r13;
  u32 _cached_3 = r14;
  u32 _cached_4 = r15;
  u32 _cached_5 = r16;
  u32 _value_2 = r17;
  Term _result_0 = r18;
  u32 _result_1 = r19;
  u32 _result_2 = r20;
  u32 _result_3 = r21;
  WL_SPIN
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    Term _o_2[6];
    if (spin_36(e, _o_2, _cached_0, _cached_1, _cached_2, _cached_3, _cached_4, _cached_5, _value_2) == 0) {
      return 0;
    }
    _v_62 = _o_2[0];
    _v_63 = _o_2[1];
    _v_64 = _o_2[2];
    _v_65 = _o_2[3];
    _v_66 = _o_2[4];
    _v_67 = _o_2[5];
    _v_56 = _v_62;
    _v_57 = _v_63;
    _v_58 = _v_64;
    _v_59 = _v_65;
    _v_60 = _v_66;
    _v_61 = _v_67;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _handle_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _handle_1);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_HANDLE, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _result_3);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TRANSACTION_MAININVERSE, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _undo_0);
    _v_36 = _result_0;
    _v_37 = _result_1;
    _v_38 = _result_2;
    _v_39 = _v_56;
    _v_40 = _v_57;
    _v_41 = _v_58;
    _v_42 = _v_59;
    _v_43 = _v_60;
    _v_44 = _v_61;
    _v_45 = _ledger_raw_0;
    _v_46 = _ledger_raw_1;
    _v_47 = _ledger_cached_0;
    _v_48 = _ledger_cached_1;
    _v_49 = _ledger_cached_2;
    _v_50 = _ledger_cached_3;
    _v_51 = _ledger_cached_4;
    _v_52 = _handle_0;
    _v_53 = _handle_1;
    _v_54 = term_ctr(CID_CON, _nd_2);
    _v_55 = _marks_0;
  break;
  }
  o[0] = _v_36;
  o[1] = _v_37;
  o[2] = _v_38;
  o[3] = _v_39;
  o[4] = _v_40;
  o[5] = _v_41;
  o[6] = _v_42;
  o[7] = _v_43;
  o[8] = _v_44;
  o[9] = _v_45;
  o[10] = _v_46;
  o[11] = _v_47;
  o[12] = _v_48;
  o[13] = _v_49;
  o[14] = _v_50;
  o[15] = _v_51;
  o[16] = _v_52;
  o[17] = _v_53;
  o[18] = _v_54;
  o[19] = _v_55;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  u32 _v_22 = 0;
  u32 _value_0 = r0;
  u32 _value_1 = r1;
  u32 _value_2 = r2;
  u32 _value_3 = r3;
  WL_SPIN
    _v_22 = _value_0;
  break;
  }
  o[0] = _v_22;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, u32 r20) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _owner_7 = r7;
  u32 _owner_8 = r8;
  Term _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  u32 _owner_16 = r16;
  u32 _owner_17 = r17;
  Term _owner_18 = r18;
  Term _owner_19 = r19;
  u32 _value_4 = r20;
  WL_SPIN
    Term _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _o_1[3];
    if (spin_41(e, _o_1, _owner_9, _owner_9 == h9 ? q9 : blk_loc(e.mem, _owner_9), _owner_10, _value_4) == 0) {
      return 0;
    }
    _v_66 = _o_1[0];
    _v_67 = _o_1[1];
    _v_68 = _o_1[2];
    _v_63 = _v_66;
    _v_64 = _v_67;
    _v_65 = _v_68;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _o_2[20];
    if (spin_42(e, _o_2, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0), _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _owner_7, _owner_8, _owner_16, _owner_17, _owner_18, _owner_18 == h18 ? q18 : blk_loc(e.mem, _owner_18), _owner_19, _owner_19 == h19 ? q19 : blk_loc(e.mem, _owner_19), _owner_11, _owner_12, _owner_13, _owner_14, _owner_15, _value_4, _v_63, _v_63 == h19 ? q19 : _v_63 == h18 ? q18 : _v_63 == h9 ? q9 : _v_63 == h0 ? q0 : blk_loc(e.mem, _v_63), _v_64, _v_65) == 0) {
      return 0;
    }
    _v_69 = _o_2[0];
    _v_70 = _o_2[1];
    _v_71 = _o_2[2];
    _v_72 = _o_2[3];
    _v_73 = _o_2[4];
    _v_74 = _o_2[5];
    _v_75 = _o_2[6];
    _v_76 = _o_2[7];
    _v_77 = _o_2[8];
    _v_78 = _o_2[9];
    _v_79 = _o_2[10];
    _v_80 = _o_2[11];
    _v_81 = _o_2[12];
    _v_82 = _o_2[13];
    _v_83 = _o_2[14];
    _v_84 = _o_2[15];
    _v_85 = _o_2[16];
    _v_86 = _o_2[17];
    _v_87 = _o_2[18];
    _v_88 = _o_2[19];
    _v_43 = _v_69;
    _v_44 = _v_70;
    _v_45 = _v_71;
    _v_46 = _v_72;
    _v_47 = _v_73;
    _v_48 = _v_74;
    _v_49 = _v_75;
    _v_50 = _v_76;
    _v_51 = _v_77;
    _v_52 = _v_78;
    _v_53 = _v_79;
    _v_54 = _v_80;
    _v_55 = _v_81;
    _v_56 = _v_82;
    _v_57 = _v_83;
    _v_58 = _v_84;
    _v_59 = _v_85;
    _v_60 = _v_86;
    _v_61 = _v_87;
    _v_62 = _v_88;
  break;
  }
  o[0] = _v_43;
  o[1] = _v_44;
  o[2] = _v_45;
  o[3] = _v_46;
  o[4] = _v_47;
  o[5] = _v_48;
  o[6] = _v_49;
  o[7] = _v_50;
  o[8] = _v_51;
  o[9] = _v_52;
  o[10] = _v_53;
  o[11] = _v_54;
  o[12] = _v_55;
  o[13] = _v_56;
  o[14] = _v_57;
  o[15] = _v_58;
  o[16] = _v_59;
  o[17] = _v_60;
  o[18] = _v_61;
  o[19] = _v_62;
  return 1;
}

INLINE Term spin_68(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_189 = 0;
  Term _v_190 = 0;
  Term _v_191 = 0;
  Term _v_192 = 0;
  u32 _v_193 = 0;
  u32 _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  u32 _v_197 = 0;
  Term _live_2 = r0;
  Term _flags_2 = r1;
  Term _added_2 = r2;
  u32 _l_2 = r3;
  u32 _f_2 = r4;
  Term _f_3 = r5;
  u32 _a_0 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  WL_SPIN
    _v_189 = _live_2;
    _v_190 = _flags_2;
    _v_191 = _added_2;
    _v_192 = _result_7;
    _v_193 = _l_2;
    _v_194 = _f_2;
    _v_195 = _f_3;
    _v_196 = _a_0;
    _v_197 = _result_8;
  break;
  }
  o[0] = _v_189;
  o[1] = _v_190;
  o[2] = _v_191;
  o[3] = _v_192;
  o[4] = _v_193;
  o[5] = _v_194;
  o[6] = _v_195;
  o[7] = _v_196;
  o[8] = _v_197;
  return 1;
}

INLINE Term spin_67(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  Term _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  Term _live_1 = r0;
  Term _flags_1 = r1;
  Term _changed_2 = r2;
  u32 _index_3 = r3;
  u32 _l_1 = r4;
  u32 _f_0 = r5;
  Term _f_1 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  WL_SPIN
    Term _at_6 = _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2);
    Term _at_7 = blk_at(_changed_2, _index_3, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    Term _v_180 = 0;
    Term _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    u32 _v_184 = 0;
    u32 _v_185 = 0;
    Term _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    Term _o_2[9];
    if (spin_68(e, _o_2, _live_1, _live_1 == h0 ? q0 : blk_loc(e.mem, _live_1), _flags_1, _flags_1 == h1 ? q1 : blk_loc(e.mem, _flags_1), _result_5, _result_5 == h7 ? q7 : blk_loc(e.mem, _result_5), _l_1, _f_0, _f_1, _f_1 == h6 ? q6 : blk_loc(e.mem, _f_1), _result_6, _changed_2, _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2), _c_4) == 0) {
      return 0;
    }
    _v_180 = _o_2[0];
    _v_181 = _o_2[1];
    _v_182 = _o_2[2];
    _v_183 = _o_2[3];
    _v_184 = _o_2[4];
    _v_185 = _o_2[5];
    _v_186 = _o_2[6];
    _v_187 = _o_2[7];
    _v_188 = _o_2[8];
    _v_171 = _v_180;
    _v_172 = _v_181;
    _v_173 = _v_182;
    _v_174 = _v_183;
    _v_175 = _v_184;
    _v_176 = _v_185;
    _v_177 = _v_186;
    _v_178 = _v_187;
    _v_179 = _v_188;
  break;
  }
  o[0] = _v_171;
  o[1] = _v_172;
  o[2] = _v_173;
  o[3] = _v_174;
  o[4] = _v_175;
  o[5] = _v_176;
  o[6] = _v_177;
  o[7] = _v_178;
  o[8] = _v_179;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_153 = 0;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  Term _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  Term _live_0 = r0;
  Term _added_1 = r1;
  Term _changed_1 = r2;
  u32 _index_2 = r3;
  u32 _l_0 = r4;
  Term _result_2 = r5;
  u32 _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    Term _at_4 = _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1);
    Term _at_5 = blk_at(_added_1, _index_2, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_162 = 0;
    Term _v_163 = 0;
    Term _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    Term _o_3[9];
    if (spin_67(e, _o_3, _live_0, _live_0 == h0 ? q0 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h5 ? q5 : blk_loc(e.mem, _result_2), _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _index_2, _l_0, _result_3, _result_4, _result_4 == h7 ? q7 : blk_loc(e.mem, _result_4), _added_1, _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1), _c_3) == 0) {
      return 0;
    }
    _v_162 = _o_3[0];
    _v_163 = _o_3[1];
    _v_164 = _o_3[2];
    _v_165 = _o_3[3];
    _v_166 = _o_3[4];
    _v_167 = _o_3[5];
    _v_168 = _o_3[6];
    _v_169 = _o_3[7];
    _v_170 = _o_3[8];
    _v_153 = _v_162;
    _v_154 = _v_163;
    _v_155 = _v_164;
    _v_156 = _v_165;
    _v_157 = _v_166;
    _v_158 = _v_167;
    _v_159 = _v_168;
    _v_160 = _v_169;
    _v_161 = _v_170;
  break;
  }
  o[0] = _v_153;
  o[1] = _v_154;
  o[2] = _v_155;
  o[3] = _v_156;
  o[4] = _v_157;
  o[5] = _v_158;
  o[6] = _v_159;
  o[7] = _v_160;
  o[8] = _v_161;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term _v_135 = 0;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  Term _v_141 = 0;
  u32 _v_142 = 0;
  u32 _v_143 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  u32 _index_1 = r3;
  Term _result_0 = r4;
  u32 _result_1 = r5;
  WL_SPIN
    Term _at_2 = _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0);
    Term _at_3 = blk_at(_flags_0, _index_1, 1);
    u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
    Term _v_144 = 0;
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    Term _o_4[9];
    if (spin_66(e, _o_4, _result_0, _result_0 == h4 ? q4 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h1 ? q1 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), _index_1, _result_1, _flags_0, _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0), _c_1, _c_2, _c_2 == h4 ? q4 : _c_2 == h2 ? q2 : _c_2 == h1 ? q1 : _c_2 == h0 ? q0 : blk_loc(e.mem, _c_2)) == 0) {
      return 0;
    }
    _v_144 = _o_4[0];
    _v_145 = _o_4[1];
    _v_146 = _o_4[2];
    _v_147 = _o_4[3];
    _v_148 = _o_4[4];
    _v_149 = _o_4[5];
    _v_150 = _o_4[6];
    _v_151 = _o_4[7];
    _v_152 = _o_4[8];
    _v_135 = _v_144;
    _v_136 = _v_145;
    _v_137 = _v_146;
    _v_138 = _v_147;
    _v_139 = _v_148;
    _v_140 = _v_149;
    _v_141 = _v_150;
    _v_142 = _v_151;
    _v_143 = _v_152;
  break;
  }
  o[0] = _v_135;
  o[1] = _v_136;
  o[2] = _v_137;
  o[3] = _v_138;
  o[4] = _v_139;
  o[5] = _v_140;
  o[6] = _v_141;
  o[7] = _v_142;
  o[8] = _v_143;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  u32 _v_121 = 0;
  u32 _v_122 = 0;
  Term _v_123 = 0;
  u32 _v_124 = 0;
  u32 _v_125 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_126 = 0;
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    Term _o_5[9];
    if (spin_65(e, _o_5, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _index_0, _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_126 = _o_5[0];
    _v_127 = _o_5[1];
    _v_128 = _o_5[2];
    _v_129 = _o_5[3];
    _v_130 = _o_5[4];
    _v_131 = _o_5[5];
    _v_132 = _o_5[6];
    _v_133 = _o_5[7];
    _v_134 = _o_5[8];
    _v_117 = _v_126;
    _v_118 = _v_127;
    _v_119 = _v_128;
    _v_120 = _v_129;
    _v_121 = _v_130;
    _v_122 = _v_131;
    _v_123 = _v_132;
    _v_124 = _v_133;
    _v_125 = _v_134;
  break;
  }
  o[0] = _v_117;
  o[1] = _v_118;
  o[2] = _v_119;
  o[3] = _v_120;
  o[4] = _v_121;
  o[5] = _v_122;
  o[6] = _v_123;
  o[7] = _v_124;
  o[8] = _v_125;
  return 1;
}

INLINE Term spin_72(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, Term r12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h16 = r16;
  Term _v_331 = 0;
  Term _v_332 = 0;
  Term _v_333 = 0;
  Term _v_334 = 0;
  Term _v_335 = 0;
  Term _v_336 = 0;
  u32 _v_337 = 0;
  Term _v_338 = 0;
  u32 _v_339 = 0;
  u32 _v_340 = 0;
  u32 _v_341 = 0;
  u32 _v_342 = 0;
  Term _v_343 = 0;
  u32 _v_344 = 0;
  Term _v_345 = 0;
  u32 _v_346 = 0;
  Term _v_347 = 0;
  u32 _v_348 = 0;
  u32 _v_349 = 0;
  u32 _id_6 = r0;
  Term _main_2 = r1;
  u32 _value_2 = r2;
  Term _value_3 = r3;
  Term _aux_2 = r4;
  u32 _av_0 = r5;
  Term _av_1 = r6;
  Term _metadata_8 = r7;
  Term _metadata_9 = r8;
  Term _metadata_10 = r9;
  Term _metadata_11 = r10;
  u32 _capacity_3 = r11;
  Term _depth_3 = r12;
  u32 _high_3 = r13;
  u32 _meta_10 = r14;
  u32 _meta_11 = r15;
  Term _meta_12 = r16;
  u32 _meta_13 = r17;
  u32 _meta_14 = r18;
  WL_SPIN
    _v_331 = _main_2;
    _v_332 = _aux_2;
    _v_333 = _metadata_8;
    _v_334 = _metadata_9;
    _v_335 = _metadata_10;
    _v_336 = _metadata_11;
    _v_337 = _capacity_3;
    _v_338 = _depth_3;
    _v_339 = _high_3;
    _v_340 = 1;
    _v_341 = _id_6;
    _v_342 = _value_2;
    _v_343 = _value_3;
    _v_344 = _av_0;
    _v_345 = _av_1;
    _v_346 = _meta_11;
    _v_347 = _meta_12;
    _v_348 = _meta_13;
    _v_349 = _meta_14;
  break;
  }
  o[0] = _v_331;
  o[1] = _v_332;
  o[2] = _v_333;
  o[3] = _v_334;
  o[4] = _v_335;
  o[5] = _v_336;
  o[6] = _v_337;
  o[7] = _v_338;
  o[8] = _v_339;
  o[9] = _v_340;
  o[10] = _v_341;
  o[11] = _v_342;
  o[12] = _v_343;
  o[13] = _v_344;
  o[14] = _v_345;
  o[15] = _v_346;
  o[16] = _v_347;
  o[17] = _v_348;
  o[18] = _v_349;
  return 1;
}

INLINE Term spin_71(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_293 = 0;
  Term _v_294 = 0;
  Term _v_295 = 0;
  Term _v_296 = 0;
  Term _v_297 = 0;
  Term _v_298 = 0;
  u32 _v_299 = 0;
  Term _v_300 = 0;
  u32 _v_301 = 0;
  u32 _v_302 = 0;
  u32 _v_303 = 0;
  u32 _v_304 = 0;
  Term _v_305 = 0;
  u32 _v_306 = 0;
  Term _v_307 = 0;
  u32 _v_308 = 0;
  Term _v_309 = 0;
  u32 _v_310 = 0;
  u32 _v_311 = 0;
  u32 _id_5 = r0;
  Term _main_1 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_2 = r8;
  Term _depth_2 = r9;
  u32 _high_2 = r10;
  u32 _meta_5 = r11;
  u32 _meta_6 = r12;
  Term _meta_7 = r13;
  u32 _meta_8 = r14;
  u32 _meta_9 = r15;
  Term _result_21 = r16;
  u32 _result_22 = r17;
  Term _result_23 = r18;
  WL_SPIN
    Term _v_312 = 0;
    Term _v_313 = 0;
    Term _v_314 = 0;
    Term _v_315 = 0;
    Term _v_316 = 0;
    Term _v_317 = 0;
    u32 _v_318 = 0;
    Term _v_319 = 0;
    u32 _v_320 = 0;
    u32 _v_321 = 0;
    u32 _v_322 = 0;
    u32 _v_323 = 0;
    Term _v_324 = 0;
    u32 _v_325 = 0;
    Term _v_326 = 0;
    u32 _v_327 = 0;
    Term _v_328 = 0;
    u32 _v_329 = 0;
    u32 _v_330 = 0;
    Term _o_7[19];
    if (spin_72(e, _o_7, _id_5, _main_1, _main_1 == h1 ? q1 : blk_loc(e.mem, _main_1), _value_0, _value_1, _value_1 == h3 ? q3 : blk_loc(e.mem, _value_1), _result_21, _result_21 == h16 ? q16 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h18 ? q18 : blk_loc(e.mem, _result_23), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_2, _depth_2, _high_2, _meta_5, _meta_6, _meta_7, _meta_7 == h13 ? q13 : blk_loc(e.mem, _meta_7), _meta_8, _meta_9) == 0) {
      return 0;
    }
    _v_312 = _o_7[0];
    _v_313 = _o_7[1];
    _v_314 = _o_7[2];
    _v_315 = _o_7[3];
    _v_316 = _o_7[4];
    _v_317 = _o_7[5];
    _v_318 = _o_7[6];
    _v_319 = _o_7[7];
    _v_320 = _o_7[8];
    _v_321 = _o_7[9];
    _v_322 = _o_7[10];
    _v_323 = _o_7[11];
    _v_324 = _o_7[12];
    _v_325 = _o_7[13];
    _v_326 = _o_7[14];
    _v_327 = _o_7[15];
    _v_328 = _o_7[16];
    _v_329 = _o_7[17];
    _v_330 = _o_7[18];
    _v_293 = _v_312;
    _v_294 = _v_313;
    _v_295 = _v_314;
    _v_296 = _v_315;
    _v_297 = _v_316;
    _v_298 = _v_317;
    _v_299 = _v_318;
    _v_300 = _v_319;
    _v_301 = _v_320;
    _v_302 = _v_321;
    _v_303 = _v_322;
    _v_304 = _v_323;
    _v_305 = _v_324;
    _v_306 = _v_325;
    _v_307 = _v_326;
    _v_308 = _v_327;
    _v_309 = _v_328;
    _v_310 = _v_329;
    _v_311 = _v_330;
  break;
  }
  o[0] = _v_293;
  o[1] = _v_294;
  o[2] = _v_295;
  o[3] = _v_296;
  o[4] = _v_297;
  o[5] = _v_298;
  o[6] = _v_299;
  o[7] = _v_300;
  o[8] = _v_301;
  o[9] = _v_302;
  o[10] = _v_303;
  o[11] = _v_304;
  o[12] = _v_305;
  o[13] = _v_306;
  o[14] = _v_307;
  o[15] = _v_308;
  o[16] = _v_309;
  o[17] = _v_310;
  o[18] = _v_311;
  return 1;
}

INLINE Term spin_70(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_255 = 0;
  Term _v_256 = 0;
  Term _v_257 = 0;
  Term _v_258 = 0;
  Term _v_259 = 0;
  Term _v_260 = 0;
  u32 _v_261 = 0;
  Term _v_262 = 0;
  u32 _v_263 = 0;
  u32 _v_264 = 0;
  u32 _v_265 = 0;
  u32 _v_266 = 0;
  Term _v_267 = 0;
  u32 _v_268 = 0;
  Term _v_269 = 0;
  u32 _v_270 = 0;
  Term _v_271 = 0;
  u32 _v_272 = 0;
  u32 _v_273 = 0;
  u32 _id_4 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _meta_0 = r9;
  u32 _meta_1 = r10;
  Term _meta_2 = r11;
  u32 _meta_3 = r12;
  u32 _meta_4 = r13;
  Term _result_18 = r14;
  u32 _result_19 = r15;
  Term _result_20 = r16;
  WL_SPIN
    Term _at_10 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
    Term _at_11 = blk_at(_aux_1, U32_BIN(_id_4, -, 1ull), 1);
    u32 _c_7 = blk_read(e.mem, 1, _at_10, _at_11 + 0);
    Term _c_8 = e.mem[_at_10 + _at_11 + 1];
    blk_write(e.mem, 1, _at_10, _at_11 + 0, 0);
    blk_write(e.mem, 1, _at_10, _at_11 + 1, 0);
    Term _v_274 = 0;
    Term _v_275 = 0;
    Term _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    u32 _v_280 = 0;
    Term _v_281 = 0;
    u32 _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    Term _v_286 = 0;
    u32 _v_287 = 0;
    Term _v_288 = 0;
    u32 _v_289 = 0;
    Term _v_290 = 0;
    u32 _v_291 = 0;
    u32 _v_292 = 0;
    Term _o_8[19];
    if (spin_71(e, _o_8, _id_4, _result_18, _result_18 == h14 ? q14 : blk_loc(e.mem, _result_18), _result_19, _result_20, _result_20 == h16 ? q16 : blk_loc(e.mem, _result_20), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _meta_1, _meta_2, _meta_2 == h11 ? q11 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _c_7, _c_8, _c_8 == h16 ? q16 : _c_8 == h14 ? q14 : _c_8 == h11 ? q11 : _c_8 == h5 ? q5 : _c_8 == h4 ? q4 : _c_8 == h3 ? q3 : _c_8 == h2 ? q2 : _c_8 == h1 ? q1 : blk_loc(e.mem, _c_8)) == 0) {
      return 0;
    }
    _v_274 = _o_8[0];
    _v_275 = _o_8[1];
    _v_276 = _o_8[2];
    _v_277 = _o_8[3];
    _v_278 = _o_8[4];
    _v_279 = _o_8[5];
    _v_280 = _o_8[6];
    _v_281 = _o_8[7];
    _v_282 = _o_8[8];
    _v_283 = _o_8[9];
    _v_284 = _o_8[10];
    _v_285 = _o_8[11];
    _v_286 = _o_8[12];
    _v_287 = _o_8[13];
    _v_288 = _o_8[14];
    _v_289 = _o_8[15];
    _v_290 = _o_8[16];
    _v_291 = _o_8[17];
    _v_292 = _o_8[18];
    _v_255 = _v_274;
    _v_256 = _v_275;
    _v_257 = _v_276;
    _v_258 = _v_277;
    _v_259 = _v_278;
    _v_260 = _v_279;
    _v_261 = _v_280;
    _v_262 = _v_281;
    _v_263 = _v_282;
    _v_264 = _v_283;
    _v_265 = _v_284;
    _v_266 = _v_285;
    _v_267 = _v_286;
    _v_268 = _v_287;
    _v_269 = _v_288;
    _v_270 = _v_289;
    _v_271 = _v_290;
    _v_272 = _v_291;
    _v_273 = _v_292;
  break;
  }
  o[0] = _v_255;
  o[1] = _v_256;
  o[2] = _v_257;
  o[3] = _v_258;
  o[4] = _v_259;
  o[5] = _v_260;
  o[6] = _v_261;
  o[7] = _v_262;
  o[8] = _v_263;
  o[9] = _v_264;
  o[10] = _v_265;
  o[11] = _v_266;
  o[12] = _v_267;
  o[13] = _v_268;
  o[14] = _v_269;
  o[15] = _v_270;
  o[16] = _v_271;
  o[17] = _v_272;
  o[18] = _v_273;
  return 1;
}

INLINE Term spin_69(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term _v_217 = 0;
  Term _v_218 = 0;
  Term _v_219 = 0;
  Term _v_220 = 0;
  Term _v_221 = 0;
  Term _v_222 = 0;
  u32 _v_223 = 0;
  Term _v_224 = 0;
  u32 _v_225 = 0;
  u32 _v_226 = 0;
  u32 _v_227 = 0;
  u32 _v_228 = 0;
  Term _v_229 = 0;
  u32 _v_230 = 0;
  Term _v_231 = 0;
  u32 _v_232 = 0;
  Term _v_233 = 0;
  u32 _v_234 = 0;
  u32 _v_235 = 0;
  u32 _id_3 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  u32 _capacity_0 = r3;
  Term _depth_0 = r4;
  u32 _high_0 = r5;
  Term _result_9 = r6;
  Term _result_10 = r7;
  Term _result_11 = r8;
  Term _result_12 = r9;
  u32 _result_13 = r10;
  u32 _result_14 = r11;
  Term _result_15 = r12;
  u32 _result_16 = r13;
  u32 _result_17 = r14;
  WL_SPIN
    if (_result_13 == 0) {
      term_sink(e, _result_15);
      _v_217 = _main_0;
      _v_218 = _aux_0;
      _v_219 = _result_9;
      _v_220 = _result_10;
      _v_221 = _result_11;
      _v_222 = _result_12;
      _v_223 = _capacity_0;
      _v_224 = _depth_0;
      _v_225 = _high_0;
      _v_226 = 0;
      _v_227 = 0;
      _v_228 = 0;
      _v_229 = 0;
      _v_230 = 0;
      _v_231 = 0;
      _v_232 = 0;
      _v_233 = 0;
      _v_234 = 0;
      _v_235 = 0;
    } else {
      Term _at_8 = _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0);
      Term _at_9 = blk_at(_main_0, U32_BIN(_id_3, -, 1ull), 1);
      u32 _c_5 = blk_read(e.mem, 1, _at_8, _at_9 + 0);
      Term _c_6 = e.mem[_at_8 + _at_9 + 1];
      blk_write(e.mem, 1, _at_8, _at_9 + 0, 0);
      blk_write(e.mem, 1, _at_8, _at_9 + 1, 0);
      Term _v_236 = 0;
      Term _v_237 = 0;
      Term _v_238 = 0;
      Term _v_239 = 0;
      Term _v_240 = 0;
      Term _v_241 = 0;
      u32 _v_242 = 0;
      Term _v_243 = 0;
      u32 _v_244 = 0;
      u32 _v_245 = 0;
      u32 _v_246 = 0;
      u32 _v_247 = 0;
      Term _v_248 = 0;
      u32 _v_249 = 0;
      Term _v_250 = 0;
      u32 _v_251 = 0;
      Term _v_252 = 0;
      u32 _v_253 = 0;
      u32 _v_254 = 0;
      Term _o_9[19];
      if (spin_70(e, _o_9, _id_3, _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _result_9, _result_9 == h6 ? q6 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h7 ? q7 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h8 ? q8 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h9 ? q9 : blk_loc(e.mem, _result_12), _capacity_0, _depth_0, _high_0, 1, _result_14, _result_15, _result_15 == h12 ? q12 : blk_loc(e.mem, _result_15), _result_16, _result_17, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _c_5, _c_6, _c_6 == h12 ? q12 : _c_6 == h9 ? q9 : _c_6 == h8 ? q8 : _c_6 == h7 ? q7 : _c_6 == h6 ? q6 : _c_6 == h2 ? q2 : _c_6 == h1 ? q1 : blk_loc(e.mem, _c_6)) == 0) {
        return 0;
      }
      _v_236 = _o_9[0];
      _v_237 = _o_9[1];
      _v_238 = _o_9[2];
      _v_239 = _o_9[3];
      _v_240 = _o_9[4];
      _v_241 = _o_9[5];
      _v_242 = _o_9[6];
      _v_243 = _o_9[7];
      _v_244 = _o_9[8];
      _v_245 = _o_9[9];
      _v_246 = _o_9[10];
      _v_247 = _o_9[11];
      _v_248 = _o_9[12];
      _v_249 = _o_9[13];
      _v_250 = _o_9[14];
      _v_251 = _o_9[15];
      _v_252 = _o_9[16];
      _v_253 = _o_9[17];
      _v_254 = _o_9[18];
      _v_217 = _v_236;
      _v_218 = _v_237;
      _v_219 = _v_238;
      _v_220 = _v_239;
      _v_221 = _v_240;
      _v_222 = _v_241;
      _v_223 = _v_242;
      _v_224 = _v_243;
      _v_225 = _v_244;
      _v_226 = _v_245;
      _v_227 = _v_246;
      _v_228 = _v_247;
      _v_229 = _v_248;
      _v_230 = _v_249;
      _v_231 = _v_250;
      _v_232 = _v_251;
      _v_233 = _v_252;
      _v_234 = _v_253;
      _v_235 = _v_254;
    }
  break;
  }
  o[0] = _v_217;
  o[1] = _v_218;
  o[2] = _v_219;
  o[3] = _v_220;
  o[4] = _v_221;
  o[5] = _v_222;
  o[6] = _v_223;
  o[7] = _v_224;
  o[8] = _v_225;
  o[9] = _v_226;
  o[10] = _v_227;
  o[11] = _v_228;
  o[12] = _v_229;
  o[13] = _v_230;
  o[14] = _v_231;
  o[15] = _v_232;
  o[16] = _v_233;
  o[17] = _v_234;
  o[18] = _v_235;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  Term _v_94 = 0;
  u32 _v_95 = 0;
  Term _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _valid_0 = r0;
  u32 _id_2 = r1;
  Term _rows_9 = r2;
  Term _rows_10 = r3;
  Term _rows_11 = r4;
  Term _rows_12 = r5;
  Term _rows_13 = r6;
  Term _rows_14 = r7;
  u32 _rows_15 = r8;
  Term _rows_16 = r9;
  u32 _rows_17 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_80 = _rows_9;
      _v_81 = _rows_10;
      _v_82 = _rows_11;
      _v_83 = _rows_12;
      _v_84 = _rows_13;
      _v_85 = _rows_14;
      _v_86 = _rows_15;
      _v_87 = _rows_16;
      _v_88 = _rows_17;
      _v_89 = 0;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
    } else {
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      u32 _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_6[9];
      if (spin_64(e, _o_6, _rows_11, _rows_11 == h4 ? q4 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h5 ? q5 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h6 ? q6 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h7 ? q7 : blk_loc(e.mem, _rows_14), U32_BIN(_id_2, -, 1ull)) == 0) {
        return 0;
      }
      _v_108 = _o_6[0];
      _v_109 = _o_6[1];
      _v_110 = _o_6[2];
      _v_111 = _o_6[3];
      _v_112 = _o_6[4];
      _v_113 = _o_6[5];
      _v_114 = _o_6[6];
      _v_115 = _o_6[7];
      _v_116 = _o_6[8];
      _v_99 = _v_108;
      _v_100 = _v_109;
      _v_101 = _v_110;
      _v_102 = _v_111;
      _v_103 = _v_112;
      _v_104 = _v_113;
      _v_105 = _v_114;
      _v_106 = _v_115;
      _v_107 = _v_116;
      Term _v_198 = 0;
      Term _v_199 = 0;
      Term _v_200 = 0;
      Term _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      u32 _v_204 = 0;
      Term _v_205 = 0;
      u32 _v_206 = 0;
      u32 _v_207 = 0;
      u32 _v_208 = 0;
      u32 _v_209 = 0;
      Term _v_210 = 0;
      u32 _v_211 = 0;
      Term _v_212 = 0;
      u32 _v_213 = 0;
      Term _v_214 = 0;
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      Term _o_10[19];
      if (spin_69(e, _o_10, _id_2, _rows_9, _rows_9 == h2 ? q2 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h3 ? q3 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _v_99, _v_99 == h7 ? q7 : _v_99 == h6 ? q6 : _v_99 == h5 ? q5 : _v_99 == h4 ? q4 : _v_99 == h3 ? q3 : _v_99 == h2 ? q2 : blk_loc(e.mem, _v_99), _v_100, _v_100 == h7 ? q7 : _v_100 == h6 ? q6 : _v_100 == h5 ? q5 : _v_100 == h4 ? q4 : _v_100 == h3 ? q3 : _v_100 == h2 ? q2 : blk_loc(e.mem, _v_100), _v_101, _v_101 == h7 ? q7 : _v_101 == h6 ? q6 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : blk_loc(e.mem, _v_101), _v_102, _v_102 == h7 ? q7 : _v_102 == h6 ? q6 : _v_102 == h5 ? q5 : _v_102 == h4 ? q4 : _v_102 == h3 ? q3 : _v_102 == h2 ? q2 : blk_loc(e.mem, _v_102), _v_103, _v_104, _v_105, _v_105 == h7 ? q7 : _v_105 == h6 ? q6 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_198 = _o_10[0];
      _v_199 = _o_10[1];
      _v_200 = _o_10[2];
      _v_201 = _o_10[3];
      _v_202 = _o_10[4];
      _v_203 = _o_10[5];
      _v_204 = _o_10[6];
      _v_205 = _o_10[7];
      _v_206 = _o_10[8];
      _v_207 = _o_10[9];
      _v_208 = _o_10[10];
      _v_209 = _o_10[11];
      _v_210 = _o_10[12];
      _v_211 = _o_10[13];
      _v_212 = _o_10[14];
      _v_213 = _o_10[15];
      _v_214 = _o_10[16];
      _v_215 = _o_10[17];
      _v_216 = _o_10[18];
      _v_80 = _v_198;
      _v_81 = _v_199;
      _v_82 = _v_200;
      _v_83 = _v_201;
      _v_84 = _v_202;
      _v_85 = _v_203;
      _v_86 = _v_204;
      _v_87 = _v_205;
      _v_88 = _v_206;
      _v_89 = _v_207;
      _v_90 = _v_208;
      _v_91 = _v_209;
      _v_92 = _v_210;
      _v_93 = _v_211;
      _v_94 = _v_212;
      _v_95 = _v_213;
      _v_96 = _v_214;
      _v_97 = _v_215;
      _v_98 = _v_216;
    }
  break;
  }
  o[0] = _v_80;
  o[1] = _v_81;
  o[2] = _v_82;
  o[3] = _v_83;
  o[4] = _v_84;
  o[5] = _v_85;
  o[6] = _v_86;
  o[7] = _v_87;
  o[8] = _v_88;
  o[9] = _v_89;
  o[10] = _v_90;
  o[11] = _v_91;
  o[12] = _v_92;
  o[13] = _v_93;
  o[14] = _v_94;
  o[15] = _v_95;
  o[16] = _v_96;
  o[17] = _v_97;
  o[18] = _v_98;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_0[1];
    if (spin_43(e, _o_0, U32_BIN(_id_1, <=, _rows_6), U32_BIN(_id_1, <=, _rows_8)) == 0) {
      return 0;
    }
    _v_59 = _o_0[0];
    _v_58 = _v_59;
    u32 _v_60 = 0;
    Term _o_1[1];
    if (spin_43(e, _o_1, U32_BIN(0ull, <, _id_1), _v_58) == 0) {
      return 0;
    }
    _v_60 = _o_1[0];
    _v_57 = _v_60;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_11[19];
    if (spin_63(e, _o_11, _v_57, _id_1, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8) == 0) {
      return 0;
    }
    _v_61 = _o_11[0];
    _v_62 = _o_11[1];
    _v_63 = _o_11[2];
    _v_64 = _o_11[3];
    _v_65 = _o_11[4];
    _v_66 = _o_11[5];
    _v_67 = _o_11[6];
    _v_68 = _o_11[7];
    _v_69 = _o_11[8];
    _v_70 = _o_11[9];
    _v_71 = _o_11[10];
    _v_72 = _o_11[11];
    _v_73 = _o_11[12];
    _v_74 = _o_11[13];
    _v_75 = _o_11[14];
    _v_76 = _o_11[15];
    _v_77 = _o_11[16];
    _v_78 = _o_11[17];
    _v_79 = _o_11[18];
    _v_38 = _v_61;
    _v_39 = _v_62;
    _v_40 = _v_63;
    _v_41 = _v_64;
    _v_42 = _v_65;
    _v_43 = _v_66;
    _v_44 = _v_67;
    _v_45 = _v_68;
    _v_46 = _v_69;
    _v_47 = _v_70;
    _v_48 = _v_71;
    _v_49 = _v_72;
    _v_50 = _v_73;
    _v_51 = _v_74;
    _v_52 = _v_75;
    _v_53 = _v_76;
    _v_54 = _v_77;
    _v_55 = _v_78;
    _v_56 = _v_79;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

INLINE Term spin_75(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _owner_7 = r0;
  u32 _owner_8 = r1;
  WL_SPIN
    Term _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[5];
    if (spin_48(e, _o_0, _owner_7, _owner_7 == h0 ? q0 : blk_loc(e.mem, _owner_7)) == 0) {
      return 0;
    }
    _v_19 = _o_0[0];
    _v_20 = _o_0[1];
    _v_21 = _o_0[2];
    _v_22 = _o_0[3];
    _v_23 = _o_0[4];
    _v_14 = _v_19;
    _v_15 = _v_20;
    _v_16 = _v_21;
    _v_17 = _v_22;
    _v_18 = _v_23;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _o_1[7];
    if (spin_52(e, _o_1, _owner_8, _v_14, _v_14 == h0 ? q0 : blk_loc(e.mem, _v_14), _v_15, _v_16, _v_17, _v_18) == 0) {
      return 0;
    }
    _v_24 = _o_1[0];
    _v_25 = _o_1[1];
    _v_26 = _o_1[2];
    _v_27 = _o_1[3];
    _v_28 = _o_1[4];
    _v_29 = _o_1[5];
    _v_30 = _o_1[6];
    _v_7 = _v_24;
    _v_8 = _v_25;
    _v_9 = _v_26;
    _v_10 = _v_27;
    _v_11 = _v_28;
    _v_12 = _v_29;
    _v_13 = _v_30;
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_76(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _owner_9 = r0;
  u32 _owner_10 = r1;
  u32 _owner_11 = r2;
  u32 _owner_12 = r3;
  u32 _owner_13 = r4;
  u32 _owner_14 = r5;
  u32 _owner_15 = r6;
  u32 _owner_16 = r7;
  u32 _owner_17 = r8;
  u32 _value_1 = r9;
  WL_SPIN
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[4];
    if (spin_40(e, _o_0, _owner_9, _owner_9 == h0 ? q0 : blk_loc(e.mem, _owner_9), _owner_10, _owner_11, _value_1) == 0) {
      return 0;
    }
    _v_24 = _o_0[0];
    _v_25 = _o_0[1];
    _v_26 = _o_0[2];
    _v_27 = _o_0[3];
    _v_20 = _v_24;
    _v_21 = _v_25;
    _v_22 = _v_26;
    _v_23 = _v_27;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_1[10];
    if (spin_53(e, _o_1, _owner_12, _owner_13, _owner_14, _owner_15, _owner_16, _owner_17, _value_1, _v_20, _v_20 == h0 ? q0 : blk_loc(e.mem, _v_20), _v_21, _v_22, _v_23) == 0) {
      return 0;
    }
    _v_28 = _o_1[0];
    _v_29 = _o_1[1];
    _v_30 = _o_1[2];
    _v_31 = _o_1[3];
    _v_32 = _o_1[4];
    _v_33 = _o_1[5];
    _v_34 = _o_1[6];
    _v_35 = _o_1[7];
    _v_36 = _o_1[8];
    _v_37 = _o_1[9];
    _v_10 = _v_28;
    _v_11 = _v_29;
    _v_12 = _v_30;
    _v_13 = _v_31;
    _v_14 = _v_32;
    _v_15 = _v_33;
    _v_16 = _v_34;
    _v_17 = _v_35;
    _v_18 = _v_36;
    _v_19 = _v_37;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_77(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _value_2 = r7;
  WL_SPIN
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[8];
    if (spin_54(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0), _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _value_2) == 0) {
      return 0;
    }
    _v_16 = _o_0[0];
    _v_17 = _o_0[1];
    _v_18 = _o_0[2];
    _v_19 = _o_0[3];
    _v_20 = _o_0[4];
    _v_21 = _o_0[5];
    _v_22 = _o_0[6];
    _v_23 = _o_0[7];
    _v_8 = _v_16;
    _v_9 = _v_17;
    _v_10 = _v_18;
    _v_11 = _v_19;
    _v_12 = _v_20;
    _v_13 = _v_21;
    _v_14 = _v_22;
    _v_15 = _v_23;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_79(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_3 = 0;
  Term _xs_1 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_3 = _acc_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_79);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_78(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_79(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_80(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _value_0 = r0;
  Term _acc_3 = r1;
  u32 _first_2 = r2;
  WL_SPIN
    if (_first_2 == 1) {
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _value_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_3);
      _v_6 = term_ctr(CID_CON, _nd_1);
    } else {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 342));
      e.mem[_nd_2 + 1] = rfc_seal(e, _acc_3);
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _value_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
      _v_6 = term_ctr(CID_CON, _nd_3);
    }
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_81(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _value_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_value_1) == CID_SNIL) {
      Term _v_2 = 0;
      Term _o_0[1];
      if (spin_26(e, _o_0, _acc_0, _acc_0 == h1 ? q1 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _value_1, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _v_3 = 0;
      Term _v_4 = 0;
      u32 _v_5 = 0;
      u32 _v_6 = 0;
      Term _o_1[1];
      if (spin_55(e, _o_1, _f_0) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_5 = _v_6;
      Term _v_7 = 0;
      Term _o_2[1];
      if (spin_56(e, _o_2, _v_5) == 0) {
        return 0;
      }
      _v_7 = _o_2[0];
      _v_4 = _v_7;
      Term _v_8 = 0;
      Term _o_3[1];
      if (spin_28(e, _o_3, _v_4, _v_4 == h1 ? q1 : _v_4 == h0 ? q0 : blk_loc(e.mem, _v_4), _acc_0, _acc_0 == h1 ? q1 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_8 = _o_3[0];
      _v_3 = _v_8;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_3;
      _value_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_81);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_83(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _value_0 = r0;
  u32 _value_1 = r1;
  u32 _value_2 = r2;
  u32 _value_3 = r3;
  WL_SPIN
    _v_2 = U32_BIN(U32_BIN(_value_0, +, _value_1), +, U32_BIN(_value_2, +, _value_3));
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_84(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, u32 r20) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  u32 _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  Term _v_90 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _owner_7 = r7;
  u32 _owner_8 = r8;
  Term _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  u32 _owner_16 = r16;
  u32 _owner_17 = r17;
  Term _owner_18 = r18;
  Term _owner_19 = r19;
  u32 _value_4 = r20;
  WL_SPIN
    Term _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    Term _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    Term _o_2[4];
    if (spin_58(e, _o_2, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0), _owner_1, _owner_2, _value_4) == 0) {
      return 0;
    }
    _v_95 = _o_2[0];
    _v_96 = _o_2[1];
    _v_97 = _o_2[2];
    _v_98 = _o_2[3];
    _v_91 = _v_95;
    _v_92 = _v_96;
    _v_93 = _v_97;
    _v_94 = _v_98;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    u32 _v_116 = 0;
    Term _v_117 = 0;
    Term _v_118 = 0;
    Term _o_3[20];
    if (spin_59(e, _o_3, _owner_9, _owner_9 == h9 ? q9 : blk_loc(e.mem, _owner_9), _owner_10, _owner_11, _owner_12, _owner_13, _owner_14, _owner_15, _owner_16, _owner_17, _owner_18, _owner_18 == h18 ? q18 : blk_loc(e.mem, _owner_18), _owner_19, _owner_19 == h19 ? q19 : blk_loc(e.mem, _owner_19), _owner_3, _owner_4, _owner_5, _owner_6, _owner_7, _owner_8, _value_4, _v_91, _v_91 == h19 ? q19 : _v_91 == h18 ? q18 : _v_91 == h9 ? q9 : _v_91 == h0 ? q0 : blk_loc(e.mem, _v_91), _v_92, _v_93, _v_94) == 0) {
      return 0;
    }
    _v_99 = _o_3[0];
    _v_100 = _o_3[1];
    _v_101 = _o_3[2];
    _v_102 = _o_3[3];
    _v_103 = _o_3[4];
    _v_104 = _o_3[5];
    _v_105 = _o_3[6];
    _v_106 = _o_3[7];
    _v_107 = _o_3[8];
    _v_108 = _o_3[9];
    _v_109 = _o_3[10];
    _v_110 = _o_3[11];
    _v_111 = _o_3[12];
    _v_112 = _o_3[13];
    _v_113 = _o_3[14];
    _v_114 = _o_3[15];
    _v_115 = _o_3[16];
    _v_116 = _o_3[17];
    _v_117 = _o_3[18];
    _v_118 = _o_3[19];
    _v_71 = _v_99;
    _v_72 = _v_100;
    _v_73 = _v_101;
    _v_74 = _v_102;
    _v_75 = _v_103;
    _v_76 = _v_104;
    _v_77 = _v_105;
    _v_78 = _v_106;
    _v_79 = _v_107;
    _v_80 = _v_108;
    _v_81 = _v_109;
    _v_82 = _v_110;
    _v_83 = _v_111;
    _v_84 = _v_112;
    _v_85 = _v_113;
    _v_86 = _v_114;
    _v_87 = _v_115;
    _v_88 = _v_116;
    _v_89 = _v_117;
    _v_90 = _v_118;
  break;
  }
  o[0] = _v_71;
  o[1] = _v_72;
  o[2] = _v_73;
  o[3] = _v_74;
  o[4] = _v_75;
  o[5] = _v_76;
  o[6] = _v_77;
  o[7] = _v_78;
  o[8] = _v_79;
  o[9] = _v_80;
  o[10] = _v_81;
  o[11] = _v_82;
  o[12] = _v_83;
  o[13] = _v_84;
  o[14] = _v_85;
  o[15] = _v_86;
  o[16] = _v_87;
  o[17] = _v_88;
  o[18] = _v_89;
  o[19] = _v_90;
  return 1;
}

INLINE Term spin_85(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_145 = 0;
  u32 _v_146 = 0;
  u32 _v_147 = 0;
  u32 _v_148 = 0;
  u32 _v_149 = 0;
  u32 _v_150 = 0;
  u32 _v_151 = 0;
  u32 _v_152 = 0;
  u32 _v_153 = 0;
  Term _v_154 = 0;
  u32 _v_155 = 0;
  u32 _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  u32 _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  u32 _v_162 = 0;
  Term _v_163 = 0;
  Term _v_164 = 0;
  u32 _v_165 = 0;
  u32 _v_166 = 0;
  u32 _v_167 = 0;
  u32 _v_168 = 0;
  u32 _v_169 = 0;
  u32 _v_170 = 0;
  Term _owner_20 = r0;
  u32 _owner_21 = r1;
  u32 _owner_22 = r2;
  u32 _owner_23 = r3;
  u32 _owner_24 = r4;
  u32 _owner_25 = r5;
  u32 _owner_26 = r6;
  u32 _owner_27 = r7;
  u32 _owner_28 = r8;
  Term _owner_29 = r9;
  u32 _owner_30 = r10;
  u32 _owner_31 = r11;
  u32 _owner_32 = r12;
  u32 _owner_33 = r13;
  u32 _owner_34 = r14;
  u32 _owner_35 = r15;
  u32 _owner_36 = r16;
  u32 _owner_37 = r17;
  Term _owner_38 = r18;
  Term _owner_39 = r19;
  WL_SPIN
    _v_145 = _owner_20;
    _v_146 = _owner_21;
    _v_147 = _owner_22;
    _v_148 = _owner_23;
    _v_149 = _owner_24;
    _v_150 = _owner_25;
    _v_151 = _owner_26;
    _v_152 = _owner_27;
    _v_153 = _owner_28;
    _v_154 = _owner_29;
    _v_155 = _owner_30;
    _v_156 = _owner_31;
    _v_157 = _owner_32;
    _v_158 = _owner_33;
    _v_159 = _owner_34;
    _v_160 = _owner_35;
    _v_161 = _owner_36;
    _v_162 = _owner_37;
    _v_163 = _owner_38;
    _v_164 = _owner_39;
    _v_165 = 1;
    _v_166 = _owner_31;
    _v_167 = _owner_32;
    _v_168 = _owner_33;
    _v_169 = _owner_34;
    _v_170 = _owner_35;
  break;
  }
  o[0] = _v_145;
  o[1] = _v_146;
  o[2] = _v_147;
  o[3] = _v_148;
  o[4] = _v_149;
  o[5] = _v_150;
  o[6] = _v_151;
  o[7] = _v_152;
  o[8] = _v_153;
  o[9] = _v_154;
  o[10] = _v_155;
  o[11] = _v_156;
  o[12] = _v_157;
  o[13] = _v_158;
  o[14] = _v_159;
  o[15] = _v_160;
  o[16] = _v_161;
  o[17] = _v_162;
  o[18] = _v_163;
  o[19] = _v_164;
  o[20] = _v_165;
  o[21] = _v_166;
  o[22] = _v_167;
  o[23] = _v_168;
  o[24] = _v_169;
  o[25] = _v_170;
  return 1;
}

INLINE Term spin_86(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, Term r10, u64 q10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, u32 r21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h10 = r10;
  Term h19 = r19;
  Term h20 = r20;
  Term _v_192 = 0;
  u32 _v_193 = 0;
  u32 _v_194 = 0;
  u32 _v_195 = 0;
  u32 _v_196 = 0;
  u32 _v_197 = 0;
  u32 _v_198 = 0;
  u32 _v_199 = 0;
  u32 _v_200 = 0;
  Term _v_201 = 0;
  u32 _v_202 = 0;
  u32 _v_203 = 0;
  u32 _v_204 = 0;
  u32 _v_205 = 0;
  u32 _v_206 = 0;
  u32 _v_207 = 0;
  u32 _v_208 = 0;
  u32 _v_209 = 0;
  Term _v_210 = 0;
  Term _v_211 = 0;
  u32 _v_212 = 0;
  u32 _readsum_0 = r0;
  Term _pair_27 = r1;
  u32 _pair_28 = r2;
  u32 _pair_29 = r3;
  u32 _pair_30 = r4;
  u32 _pair_31 = r5;
  u32 _pair_32 = r6;
  u32 _pair_33 = r7;
  u32 _pair_34 = r8;
  u32 _pair_35 = r9;
  Term _pair_36 = r10;
  u32 _pair_37 = r11;
  u32 _pair_38 = r12;
  u32 _pair_39 = r13;
  u32 _pair_40 = r14;
  u32 _pair_41 = r15;
  u32 _pair_42 = r16;
  u32 _pair_43 = r17;
  u32 _pair_44 = r18;
  Term _pair_45 = r19;
  Term _pair_46 = r20;
  u32 _pair_47 = r21;
  u32 _pair_48 = r22;
  u32 _pair_49 = r23;
  u32 _pair_50 = r24;
  u32 _pair_51 = r25;
  u32 _pair_52 = r26;
  WL_SPIN
    if (_pair_47 == 1) {
      Term _v_213 = 0;
      u32 _v_214 = 0;
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      u32 _v_217 = 0;
      u32 _v_218 = 0;
      u32 _v_219 = 0;
      u32 _v_220 = 0;
      u32 _v_221 = 0;
      Term _v_222 = 0;
      u32 _v_223 = 0;
      u32 _v_224 = 0;
      u32 _v_225 = 0;
      u32 _v_226 = 0;
      u32 _v_227 = 0;
      u32 _v_228 = 0;
      u32 _v_229 = 0;
      u32 _v_230 = 0;
      Term _v_231 = 0;
      Term _v_232 = 0;
      u32 _v_233 = 0;
      u32 _v_234 = 0;
      Term _o_6[1];
      if (spin_60(e, _o_6, _pair_48, _pair_49, _pair_50, _pair_51) == 0) {
        return 0;
      }
      _v_234 = _o_6[0];
      _v_233 = _v_234;
      Term _v_235 = 0;
      u32 _v_236 = 0;
      u32 _v_237 = 0;
      u32 _v_238 = 0;
      u32 _v_239 = 0;
      u32 _v_240 = 0;
      u32 _v_241 = 0;
      u32 _v_242 = 0;
      u32 _v_243 = 0;
      Term _v_244 = 0;
      u32 _v_245 = 0;
      u32 _v_246 = 0;
      u32 _v_247 = 0;
      u32 _v_248 = 0;
      u32 _v_249 = 0;
      u32 _v_250 = 0;
      u32 _v_251 = 0;
      u32 _v_252 = 0;
      Term _v_253 = 0;
      Term _v_254 = 0;
      Term _o_7[20];
      if (spin_61(e, _o_7, _pair_27, _pair_27 == h1 ? q1 : blk_loc(e.mem, _pair_27), _pair_28, _pair_29, _pair_30, _pair_31, _pair_32, _pair_33, _pair_34, _pair_35, _pair_36, _pair_36 == h10 ? q10 : blk_loc(e.mem, _pair_36), _pair_37, _pair_38, _pair_39, _pair_40, _pair_41, _pair_42, _pair_43, _pair_44, _pair_45, _pair_45 == h19 ? q19 : blk_loc(e.mem, _pair_45), _pair_46, _pair_46 == h20 ? q20 : blk_loc(e.mem, _pair_46), U32_BIN(_v_233, +, 1ull)) == 0) {
        return 0;
      }
      _v_235 = _o_7[0];
      _v_236 = _o_7[1];
      _v_237 = _o_7[2];
      _v_238 = _o_7[3];
      _v_239 = _o_7[4];
      _v_240 = _o_7[5];
      _v_241 = _o_7[6];
      _v_242 = _o_7[7];
      _v_243 = _o_7[8];
      _v_244 = _o_7[9];
      _v_245 = _o_7[10];
      _v_246 = _o_7[11];
      _v_247 = _o_7[12];
      _v_248 = _o_7[13];
      _v_249 = _o_7[14];
      _v_250 = _o_7[15];
      _v_251 = _o_7[16];
      _v_252 = _o_7[17];
      _v_253 = _o_7[18];
      _v_254 = _o_7[19];
      _v_213 = _v_235;
      _v_214 = _v_236;
      _v_215 = _v_237;
      _v_216 = _v_238;
      _v_217 = _v_239;
      _v_218 = _v_240;
      _v_219 = _v_241;
      _v_220 = _v_242;
      _v_221 = _v_243;
      _v_222 = _v_244;
      _v_223 = _v_245;
      _v_224 = _v_246;
      _v_225 = _v_247;
      _v_226 = _v_248;
      _v_227 = _v_249;
      _v_228 = _v_250;
      _v_229 = _v_251;
      _v_230 = _v_252;
      _v_231 = _v_253;
      _v_232 = _v_254;
      _v_192 = _v_213;
      _v_193 = _v_214;
      _v_194 = _v_215;
      _v_195 = _v_216;
      _v_196 = _v_217;
      _v_197 = _v_218;
      _v_198 = _v_219;
      _v_199 = _v_220;
      _v_200 = _v_221;
      _v_201 = _v_222;
      _v_202 = _v_223;
      _v_203 = _v_224;
      _v_204 = _v_225;
      _v_205 = _v_226;
      _v_206 = _v_227;
      _v_207 = _v_228;
      _v_208 = _v_229;
      _v_209 = _v_230;
      _v_210 = _v_231;
      _v_211 = _v_232;
      _v_212 = _readsum_0;
    } else {
      _v_192 = _pair_27;
      _v_193 = _pair_28;
      _v_194 = _pair_29;
      _v_195 = _pair_30;
      _v_196 = _pair_31;
      _v_197 = _pair_32;
      _v_198 = _pair_33;
      _v_199 = _pair_34;
      _v_200 = _pair_35;
      _v_201 = _pair_36;
      _v_202 = _pair_37;
      _v_203 = _pair_38;
      _v_204 = _pair_39;
      _v_205 = _pair_40;
      _v_206 = _pair_41;
      _v_207 = _pair_42;
      _v_208 = _pair_43;
      _v_209 = _pair_44;
      _v_210 = _pair_45;
      _v_211 = _pair_46;
      _v_212 = 4294967295ull;
    }
  break;
  }
  o[0] = _v_192;
  o[1] = _v_193;
  o[2] = _v_194;
  o[3] = _v_195;
  o[4] = _v_196;
  o[5] = _v_197;
  o[6] = _v_198;
  o[7] = _v_199;
  o[8] = _v_200;
  o[9] = _v_201;
  o[10] = _v_202;
  o[11] = _v_203;
  o[12] = _v_204;
  o[13] = _v_205;
  o[14] = _v_206;
  o[15] = _v_207;
  o[16] = _v_208;
  o[17] = _v_209;
  o[18] = _v_210;
  o[19] = _v_211;
  o[20] = _v_212;
  return 1;
}

INLINE Term spin_87(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  WL_SPIN
    _v_1 = _result_0;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_88(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  WL_SPIN
    _v_1 = _result_0;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_91(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_24 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_24 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_91);
    }
  break;
  }
  o[0] = _v_24;
  return 1;
}

INLINE Term spin_90(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_22 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_23 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_91(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_23 = _o_0[0];
    _v_22 = _v_23;
  break;
  }
  o[0] = _v_22;
  return 1;
}

INLINE Term spin_89(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h9 = r9;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _state_10 = r0;
  Term _state_11 = r1;
  Term _state_12 = r2;
  Term _state_13 = r3;
  Term _state_14 = r4;
  Term _state_15 = r5;
  u32 _state_16 = r6;
  Term _state_17 = r7;
  u32 _state_18 = r8;
  Term _state_19 = r9;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _o_1[1];
    if (spin_90(e, _o_1, _state_19, _state_19 == h9 ? q9 : blk_loc(e.mem, _state_19)) == 0) {
      return 0;
    }
    _v_21 = _o_1[0];
    _v_20 = _v_21;
    _v_10 = _state_10;
    _v_11 = _state_11;
    _v_12 = _state_12;
    _v_13 = _state_13;
    _v_14 = _state_14;
    _v_15 = _state_15;
    _v_16 = _state_16;
    _v_17 = _state_17;
    _v_18 = _state_18;
    _v_19 = _v_20;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_92(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _result_0;
    _v_6 = 1;
    _v_7 = _result_1;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_95(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _owner_7 = r7;
  u32 _owner_8 = r8;
  u32 _value_2 = r9;
  WL_SPIN
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[10];
    if (spin_76(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0), _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _owner_7, _owner_8, _value_2) == 0) {
      return 0;
    }
    _v_20 = _o_0[0];
    _v_21 = _o_0[1];
    _v_22 = _o_0[2];
    _v_23 = _o_0[3];
    _v_24 = _o_0[4];
    _v_25 = _o_0[5];
    _v_26 = _o_0[6];
    _v_27 = _o_0[7];
    _v_28 = _o_0[8];
    _v_29 = _o_0[9];
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_96(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _namespace_0 = r0;
  u32 _next_0 = r1;
  Term _rows_0 = r2;
  Term _rows_1 = r3;
  Term _rows_2 = r4;
  Term _rows_3 = r5;
  Term _rows_4 = r6;
  Term _rows_5 = r7;
  u32 _rows_6 = r8;
  Term _rows_7 = r9;
  u32 _rows_8 = r10;
  Term _pending_0 = r11;
  Term _mode_0 = r12;
  Term _result_0 = r13;
  Term _result_1 = r14;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _next_0;
    _v_19 = _rows_0;
    _v_20 = _rows_1;
    _v_21 = _rows_2;
    _v_22 = _rows_3;
    _v_23 = _rows_4;
    _v_24 = _rows_5;
    _v_25 = _rows_6;
    _v_26 = _rows_7;
    _v_27 = _rows_8;
    _v_28 = _pending_0;
    _v_29 = 1;
    _v_30 = _result_0;
    _v_31 = _mode_0;
    _v_32 = 1;
    _v_33 = _result_1;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_98(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _value_1 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_SNIL, 0);
    if (spin_81(e, _o_0, _value_1, _value_1 == h0 ? q0 : blk_loc(e.mem, _value_1), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_100(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  u32 _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  u32 _v_78 = 0;
  u32 _v_79 = 0;
  u32 _v_80 = 0;
  Term _owner_20 = r0;
  u32 _owner_21 = r1;
  u32 _owner_22 = r2;
  u32 _owner_23 = r3;
  u32 _owner_24 = r4;
  u32 _owner_25 = r5;
  u32 _owner_26 = r6;
  u32 _owner_27 = r7;
  u32 _owner_28 = r8;
  Term _owner_29 = r9;
  u32 _owner_30 = r10;
  u32 _owner_31 = r11;
  u32 _owner_32 = r12;
  u32 _owner_33 = r13;
  u32 _owner_34 = r14;
  u32 _owner_35 = r15;
  u32 _owner_36 = r16;
  u32 _owner_37 = r17;
  Term _owner_38 = r18;
  Term _owner_39 = r19;
  WL_SPIN
    _v_54 = _owner_20;
    _v_55 = _owner_21;
    _v_56 = _owner_22;
    _v_57 = _owner_23;
    _v_58 = _owner_24;
    _v_59 = _owner_25;
    _v_60 = _owner_26;
    _v_61 = _owner_27;
    _v_62 = _owner_28;
    _v_63 = _owner_29;
    _v_64 = _owner_30;
    _v_65 = _owner_31;
    _v_66 = _owner_32;
    _v_67 = _owner_33;
    _v_68 = _owner_34;
    _v_69 = _owner_35;
    _v_70 = _owner_36;
    _v_71 = _owner_37;
    _v_72 = _owner_38;
    _v_73 = _owner_39;
    _v_74 = 0;
    _v_75 = _owner_23;
    _v_76 = _owner_24;
    _v_77 = _owner_25;
    _v_78 = _owner_26;
    _v_79 = _owner_27;
    _v_80 = _owner_28;
  break;
  }
  o[0] = _v_54;
  o[1] = _v_55;
  o[2] = _v_56;
  o[3] = _v_57;
  o[4] = _v_58;
  o[5] = _v_59;
  o[6] = _v_60;
  o[7] = _v_61;
  o[8] = _v_62;
  o[9] = _v_63;
  o[10] = _v_64;
  o[11] = _v_65;
  o[12] = _v_66;
  o[13] = _v_67;
  o[14] = _v_68;
  o[15] = _v_69;
  o[16] = _v_70;
  o[17] = _v_71;
  o[18] = _v_72;
  o[19] = _v_73;
  o[20] = _v_74;
  o[21] = _v_75;
  o[22] = _v_76;
  o[23] = _v_77;
  o[24] = _v_78;
  o[25] = _v_79;
  o[26] = _v_80;
  return 1;
}

FAR Term spin_101(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _v_105 = 0;
  u32 _v_106 = 0;
  u32 _v_107 = 0;
  u32 _v_108 = 0;
  u32 _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  u32 _v_113 = 0;
  u32 _v_114 = 0;
  u32 _v_115 = 0;
  u32 _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  u32 _v_122 = 0;
  Term _pair_0 = r0;
  u32 _pair_1 = r1;
  u32 _pair_2 = r2;
  u32 _pair_3 = r3;
  u32 _pair_4 = r4;
  u32 _pair_5 = r5;
  u32 _pair_6 = r6;
  u32 _pair_7 = r7;
  u32 _pair_8 = r8;
  Term _pair_9 = r9;
  u32 _pair_10 = r10;
  u32 _pair_11 = r11;
  u32 _pair_12 = r12;
  u32 _pair_13 = r13;
  u32 _pair_14 = r14;
  u32 _pair_15 = r15;
  u32 _pair_16 = r16;
  u32 _pair_17 = r17;
  Term _pair_18 = r18;
  Term _pair_19 = r19;
  u32 _pair_20 = r20;
  u32 _pair_21 = r21;
  u32 _pair_22 = r22;
  u32 _pair_23 = r23;
  u32 _pair_24 = r24;
  u32 _pair_25 = r25;
  u32 _pair_26 = r26;
  WL_SPIN
    if (_pair_20 == 0) {
      u32 _v_123 = 0;
      u32 _v_124 = 0;
      Term _o_1[1];
      if (spin_83(e, _o_1, _pair_21, _pair_22, _pair_23, _pair_24) == 0) {
        return 0;
      }
      _v_124 = _o_1[0];
      _v_123 = _v_124;
      Term _v_125 = 0;
      u32 _v_126 = 0;
      u32 _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      u32 _v_130 = 0;
      u32 _v_131 = 0;
      u32 _v_132 = 0;
      u32 _v_133 = 0;
      Term _v_134 = 0;
      u32 _v_135 = 0;
      u32 _v_136 = 0;
      u32 _v_137 = 0;
      u32 _v_138 = 0;
      u32 _v_139 = 0;
      u32 _v_140 = 0;
      u32 _v_141 = 0;
      u32 _v_142 = 0;
      Term _v_143 = 0;
      Term _v_144 = 0;
      u32 _v_145 = 0;
      u32 _v_146 = 0;
      u32 _v_147 = 0;
      u32 _v_148 = 0;
      u32 _v_149 = 0;
      u32 _v_150 = 0;
      Term _v_151 = 0;
      u32 _v_152 = 0;
      u32 _v_153 = 0;
      u32 _v_154 = 0;
      u32 _v_155 = 0;
      u32 _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      u32 _v_159 = 0;
      Term _v_160 = 0;
      u32 _v_161 = 0;
      u32 _v_162 = 0;
      u32 _v_163 = 0;
      u32 _v_164 = 0;
      u32 _v_165 = 0;
      u32 _v_166 = 0;
      u32 _v_167 = 0;
      u32 _v_168 = 0;
      Term _v_169 = 0;
      Term _v_170 = 0;
      u32 _v_171 = 0;
      u32 _v_172 = 0;
      Term _o_2[1];
      if (spin_60(e, _o_2, _pair_21, _pair_22, _pair_23, _pair_24) == 0) {
        return 0;
      }
      _v_172 = _o_2[0];
      _v_171 = _v_172;
      Term _v_173 = 0;
      u32 _v_174 = 0;
      u32 _v_175 = 0;
      u32 _v_176 = 0;
      u32 _v_177 = 0;
      u32 _v_178 = 0;
      u32 _v_179 = 0;
      u32 _v_180 = 0;
      u32 _v_181 = 0;
      Term _v_182 = 0;
      u32 _v_183 = 0;
      u32 _v_184 = 0;
      u32 _v_185 = 0;
      u32 _v_186 = 0;
      u32 _v_187 = 0;
      u32 _v_188 = 0;
      u32 _v_189 = 0;
      u32 _v_190 = 0;
      Term _v_191 = 0;
      Term _v_192 = 0;
      Term _o_3[20];
      if (spin_84(e, _o_3, _pair_0, _pair_0 == h0 ? q0 : blk_loc(e.mem, _pair_0), _pair_1, _pair_2, _pair_3, _pair_4, _pair_5, _pair_6, _pair_7, _pair_8, _pair_9, _pair_9 == h9 ? q9 : blk_loc(e.mem, _pair_9), _pair_10, _pair_11, _pair_12, _pair_13, _pair_14, _pair_15, _pair_16, _pair_17, _pair_18, _pair_18 == h18 ? q18 : blk_loc(e.mem, _pair_18), _pair_19, _pair_19 == h19 ? q19 : blk_loc(e.mem, _pair_19), U32_BIN(_v_171, +, 1ull)) == 0) {
        return 0;
      }
      _v_173 = _o_3[0];
      _v_174 = _o_3[1];
      _v_175 = _o_3[2];
      _v_176 = _o_3[3];
      _v_177 = _o_3[4];
      _v_178 = _o_3[5];
      _v_179 = _o_3[6];
      _v_180 = _o_3[7];
      _v_181 = _o_3[8];
      _v_182 = _o_3[9];
      _v_183 = _o_3[10];
      _v_184 = _o_3[11];
      _v_185 = _o_3[12];
      _v_186 = _o_3[13];
      _v_187 = _o_3[14];
      _v_188 = _o_3[15];
      _v_189 = _o_3[16];
      _v_190 = _o_3[17];
      _v_191 = _o_3[18];
      _v_192 = _o_3[19];
      _v_151 = _v_173;
      _v_152 = _v_174;
      _v_153 = _v_175;
      _v_154 = _v_176;
      _v_155 = _v_177;
      _v_156 = _v_178;
      _v_157 = _v_179;
      _v_158 = _v_180;
      _v_159 = _v_181;
      _v_160 = _v_182;
      _v_161 = _v_183;
      _v_162 = _v_184;
      _v_163 = _v_185;
      _v_164 = _v_186;
      _v_165 = _v_187;
      _v_166 = _v_188;
      _v_167 = _v_189;
      _v_168 = _v_190;
      _v_169 = _v_191;
      _v_170 = _v_192;
      Term _v_193 = 0;
      u32 _v_194 = 0;
      u32 _v_195 = 0;
      u32 _v_196 = 0;
      u32 _v_197 = 0;
      u32 _v_198 = 0;
      u32 _v_199 = 0;
      u32 _v_200 = 0;
      u32 _v_201 = 0;
      Term _v_202 = 0;
      u32 _v_203 = 0;
      u32 _v_204 = 0;
      u32 _v_205 = 0;
      u32 _v_206 = 0;
      u32 _v_207 = 0;
      u32 _v_208 = 0;
      u32 _v_209 = 0;
      u32 _v_210 = 0;
      Term _v_211 = 0;
      Term _v_212 = 0;
      u32 _v_213 = 0;
      u32 _v_214 = 0;
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      u32 _v_217 = 0;
      u32 _v_218 = 0;
      Term _o_4[26];
      if (spin_85(e, _o_4, _v_151, _v_151 == h19 ? q19 : _v_151 == h18 ? q18 : _v_151 == h9 ? q9 : _v_151 == h0 ? q0 : blk_loc(e.mem, _v_151), _v_152, _v_153, _v_154, _v_155, _v_156, _v_157, _v_158, _v_159, _v_160, _v_160 == h19 ? q19 : _v_160 == h18 ? q18 : _v_160 == h9 ? q9 : _v_160 == h0 ? q0 : blk_loc(e.mem, _v_160), _v_161, _v_162, _v_163, _v_164, _v_165, _v_166, _v_167, _v_168, _v_169, _v_169 == h19 ? q19 : _v_169 == h18 ? q18 : _v_169 == h9 ? q9 : _v_169 == h0 ? q0 : blk_loc(e.mem, _v_169), _v_170, _v_170 == h19 ? q19 : _v_170 == h18 ? q18 : _v_170 == h9 ? q9 : _v_170 == h0 ? q0 : blk_loc(e.mem, _v_170)) == 0) {
        return 0;
      }
      _v_193 = _o_4[0];
      _v_194 = _o_4[1];
      _v_195 = _o_4[2];
      _v_196 = _o_4[3];
      _v_197 = _o_4[4];
      _v_198 = _o_4[5];
      _v_199 = _o_4[6];
      _v_200 = _o_4[7];
      _v_201 = _o_4[8];
      _v_202 = _o_4[9];
      _v_203 = _o_4[10];
      _v_204 = _o_4[11];
      _v_205 = _o_4[12];
      _v_206 = _o_4[13];
      _v_207 = _o_4[14];
      _v_208 = _o_4[15];
      _v_209 = _o_4[16];
      _v_210 = _o_4[17];
      _v_211 = _o_4[18];
      _v_212 = _o_4[19];
      _v_213 = _o_4[20];
      _v_214 = _o_4[21];
      _v_215 = _o_4[22];
      _v_216 = _o_4[23];
      _v_217 = _o_4[24];
      _v_218 = _o_4[25];
      _v_125 = _v_193;
      _v_126 = _v_194;
      _v_127 = _v_195;
      _v_128 = _v_196;
      _v_129 = _v_197;
      _v_130 = _v_198;
      _v_131 = _v_199;
      _v_132 = _v_200;
      _v_133 = _v_201;
      _v_134 = _v_202;
      _v_135 = _v_203;
      _v_136 = _v_204;
      _v_137 = _v_205;
      _v_138 = _v_206;
      _v_139 = _v_207;
      _v_140 = _v_208;
      _v_141 = _v_209;
      _v_142 = _v_210;
      _v_143 = _v_211;
      _v_144 = _v_212;
      _v_145 = _v_213;
      _v_146 = _v_214;
      _v_147 = _v_215;
      _v_148 = _v_216;
      _v_149 = _v_217;
      _v_150 = _v_218;
      Term _v_219 = 0;
      u32 _v_220 = 0;
      u32 _v_221 = 0;
      u32 _v_222 = 0;
      u32 _v_223 = 0;
      u32 _v_224 = 0;
      u32 _v_225 = 0;
      u32 _v_226 = 0;
      u32 _v_227 = 0;
      Term _v_228 = 0;
      u32 _v_229 = 0;
      u32 _v_230 = 0;
      u32 _v_231 = 0;
      u32 _v_232 = 0;
      u32 _v_233 = 0;
      u32 _v_234 = 0;
      u32 _v_235 = 0;
      u32 _v_236 = 0;
      Term _v_237 = 0;
      Term _v_238 = 0;
      u32 _v_239 = 0;
      Term _o_5[21];
      if (spin_86(e, _o_5, _v_123, _v_125, _v_125 == h19 ? q19 : _v_125 == h18 ? q18 : _v_125 == h9 ? q9 : _v_125 == h0 ? q0 : blk_loc(e.mem, _v_125), _v_126, _v_127, _v_128, _v_129, _v_130, _v_131, _v_132, _v_133, _v_134, _v_134 == h19 ? q19 : _v_134 == h18 ? q18 : _v_134 == h9 ? q9 : _v_134 == h0 ? q0 : blk_loc(e.mem, _v_134), _v_135, _v_136, _v_137, _v_138, _v_139, _v_140, _v_141, _v_142, _v_143, _v_143 == h19 ? q19 : _v_143 == h18 ? q18 : _v_143 == h9 ? q9 : _v_143 == h0 ? q0 : blk_loc(e.mem, _v_143), _v_144, _v_144 == h19 ? q19 : _v_144 == h18 ? q18 : _v_144 == h9 ? q9 : _v_144 == h0 ? q0 : blk_loc(e.mem, _v_144), _v_145, _v_146, _v_147, _v_148, _v_149, _v_150) == 0) {
        return 0;
      }
      _v_219 = _o_5[0];
      _v_220 = _o_5[1];
      _v_221 = _o_5[2];
      _v_222 = _o_5[3];
      _v_223 = _o_5[4];
      _v_224 = _o_5[5];
      _v_225 = _o_5[6];
      _v_226 = _o_5[7];
      _v_227 = _o_5[8];
      _v_228 = _o_5[9];
      _v_229 = _o_5[10];
      _v_230 = _o_5[11];
      _v_231 = _o_5[12];
      _v_232 = _o_5[13];
      _v_233 = _o_5[14];
      _v_234 = _o_5[15];
      _v_235 = _o_5[16];
      _v_236 = _o_5[17];
      _v_237 = _o_5[18];
      _v_238 = _o_5[19];
      _v_239 = _o_5[20];
      _v_102 = _v_219;
      _v_103 = _v_220;
      _v_104 = _v_221;
      _v_105 = _v_222;
      _v_106 = _v_223;
      _v_107 = _v_224;
      _v_108 = _v_225;
      _v_109 = _v_226;
      _v_110 = _v_227;
      _v_111 = _v_228;
      _v_112 = _v_229;
      _v_113 = _v_230;
      _v_114 = _v_231;
      _v_115 = _v_232;
      _v_116 = _v_233;
      _v_117 = _v_234;
      _v_118 = _v_235;
      _v_119 = _v_236;
      _v_120 = _v_237;
      _v_121 = _v_238;
      _v_122 = _v_239;
    } else {
      _v_102 = _pair_0;
      _v_103 = _pair_1;
      _v_104 = _pair_2;
      _v_105 = _pair_3;
      _v_106 = _pair_4;
      _v_107 = _pair_5;
      _v_108 = _pair_6;
      _v_109 = _pair_7;
      _v_110 = _pair_8;
      _v_111 = _pair_9;
      _v_112 = _pair_10;
      _v_113 = _pair_11;
      _v_114 = _pair_12;
      _v_115 = _pair_13;
      _v_116 = _pair_14;
      _v_117 = _pair_15;
      _v_118 = _pair_16;
      _v_119 = _pair_17;
      _v_120 = _pair_18;
      _v_121 = _pair_19;
      _v_122 = 4294967295ull;
    }
  break;
  }
  o[0] = _v_102;
  o[1] = _v_103;
  o[2] = _v_104;
  o[3] = _v_105;
  o[4] = _v_106;
  o[5] = _v_107;
  o[6] = _v_108;
  o[7] = _v_109;
  o[8] = _v_110;
  o[9] = _v_111;
  o[10] = _v_112;
  o[11] = _v_113;
  o[12] = _v_114;
  o[13] = _v_115;
  o[14] = _v_116;
  o[15] = _v_117;
  o[16] = _v_118;
  o[17] = _v_119;
  o[18] = _v_120;
  o[19] = _v_121;
  o[20] = _v_122;
  return 1;
}

INLINE Term spin_102(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h3 = r3;
  Term _v_2 = 0;
  Term _v_3 = 0;
  Term _changed_1 = r0;
  u32 _index_0 = r1;
  u32 _tick_1 = r2;
  Term _result_0 = r3;
  u32 _result_1 = r4;
  WL_SPIN
    if (_result_1 == 0) {
      _v_2 = _result_0;
      _v_3 = _changed_1;
    } else {
      Term _at_2 = _changed_1 == h0 ? q0 : blk_loc(e.mem, _changed_1);
      Term _at_3 = blk_at(_changed_1, _index_0, 0);
      u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
      blk_write(e.mem, 0, _at_2, _at_3 + 0, _tick_1);
      _v_2 = _result_0;
      _v_3 = _changed_1;
    }
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_105(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_48 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_48 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_4 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_4 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_4);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_105);
    }
  break;
  }
  o[0] = _v_48;
  return 1;
}

INLINE Term spin_104(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_46 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_47 = 0;
    Term _o_4[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_105(e, _o_4, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_47 = _o_4[0];
    _v_46 = _v_47;
  break;
  }
  o[0] = _v_46;
  return 1;
}

INLINE Term spin_103(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  Term _rowViews_2 = r11;
  Term _pending_0 = r12;
  Term _pendingViews_0 = r13;
  Term _mode_2 = r14;
  u32 _result_4 = r15;
  Term _result_5 = r16;
  u32 _result_6 = r17;
  Term _result_7 = r18;
  WL_SPIN
    _mode_2 = term_keep(e, _mode_2, 1);
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _o_5[1];
    if (spin_104(e, _o_5, _pendingViews_0, _pendingViews_0 == h13 ? q13 : blk_loc(e.mem, _pendingViews_0)) == 0) {
      return 0;
    }
    _v_45 = _o_5[0];
    _v_44 = _v_45;
    _v_22 = _namespace_2;
    _v_23 = _next_2;
    _v_24 = _rows_18;
    _v_25 = _rows_19;
    _v_26 = _rows_20;
    _v_27 = _rows_21;
    _v_28 = _rows_22;
    _v_29 = _rows_23;
    _v_30 = _rows_24;
    _v_31 = _rows_25;
    _v_32 = _rows_26;
    _v_33 = _pending_0;
    _v_34 = _result_4;
    _v_35 = _result_5;
    _v_36 = _mode_2;
    _v_37 = _namespace_2;
    _v_38 = _next_2;
    _v_39 = _rowViews_2;
    _v_40 = _v_44;
    _v_41 = _result_6;
    _v_42 = _result_7;
    _v_43 = _mode_2;
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  o[11] = _v_33;
  o[12] = _v_34;
  o[13] = _v_35;
  o[14] = _v_36;
  o[15] = _v_37;
  o[16] = _v_38;
  o[17] = _v_39;
  o[18] = _v_40;
  o[19] = _v_41;
  o[20] = _v_42;
  o[21] = _v_43;
  return 1;
}

INLINE Term spin_106(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _epoch_0 = r0;
  Term _result_0 = r1;
  u32 _result_1 = r2;
  u32 _result_2 = r3;
  u32 _result_3 = r4;
  u32 _result_4 = r5;
  WL_SPIN
    _v_17 = _result_0;
    _v_18 = _epoch_0;
    _v_19 = _result_1;
    _v_20 = _result_2;
    _v_21 = _result_3;
    _v_22 = _result_4;
    _v_23 = _epoch_0;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  return 1;
}

INLINE Term spin_108(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  WL_SPIN
    _v_12 = _owner_0;
    _v_13 = _owner_1;
    _v_14 = _owner_2;
    _v_15 = _owner_3;
    _v_16 = _owner_4;
    _v_17 = _owner_5;
    _v_18 = _owner_6;
    _v_19 = _owner_2;
    _v_20 = _owner_3;
    _v_21 = _owner_4;
    _v_22 = _owner_5;
    _v_23 = _owner_6;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  o[6] = _v_18;
  o[7] = _v_19;
  o[8] = _v_20;
  o[9] = _v_21;
  o[10] = _v_22;
  o[11] = _v_23;
  return 1;
}

INLINE Term spin_110(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _selected_0 = r0;
  Term _undo_0 = r1;
  Term _commands_0 = r2;
  Term _pings_0 = r3;
  Term _marks_0 = r4;
  Term _result_0 = r5;
  u32 _result_1 = r6;
  u32 _result_2 = r7;
  WL_SPIN
    if (_result_1 == 1) {
      u64 _nd_12 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_12 + 0] = rfc_seal(e, term_pak(CID_TRANSACTION_LEDGERINVERSE, _result_2));
      e.mem[_nd_12 + 1] = rfc_seal(e, _undo_0);
      _v_6 = _result_0;
      _v_7 = _selected_0;
      _v_8 = term_ctr(CID_CON, _nd_12);
      _v_9 = _commands_0;
      _v_10 = _pings_0;
      _v_11 = _marks_0;
    } else {
      _v_6 = _result_0;
      _v_7 = _selected_0;
      _v_8 = _undo_0;
      _v_9 = _commands_0;
      _v_10 = _pings_0;
      _v_11 = _marks_0;
    }
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  o[3] = _v_9;
  o[4] = _v_10;
  o[5] = _v_11;
  return 1;
}

INLINE Term spin_111(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _reserve_0 = r0;
  u32 _class_0 = r1;
  Term _result_0 = r2;
  u32 _result_1 = r3;
  u32 _result_2 = r4;
  u32 _result_3 = r5;
  u32 _result_4 = r6;
  WL_SPIN
    _v_19 = _result_0;
    _v_20 = _reserve_0;
    _v_21 = _class_0;
    _v_22 = _result_1;
    _v_23 = _result_2;
    _v_24 = _result_3;
    _v_25 = _result_4;
    _v_26 = _reserve_0;
    _v_27 = _class_0;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  return 1;
}

INLINE Term spin_112(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_3 = 0;
  Term _v_4 = 0;
  Term _v_5 = 0;
  Term _cached_0 = r0;
  Term _result_0 = r1;
  Term _result_1 = r2;
  WL_SPIN
    _v_3 = _result_0;
    _v_4 = _cached_0;
    _v_5 = _result_1;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_113(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _result_0;
    _v_6 = 1;
    _v_7 = _result_1;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_114(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h5 = r5;
  Term h7 = r7;
  Term h9 = r9;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _main_0 = r0;
  Term _main_1 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  u32 _flag_2 = r4;
  Term _flag_3 = r5;
  u32 _result_17 = r6;
  Term _result_18 = r7;
  u32 _result_19 = r8;
  Term _result_20 = r9;
  WL_SPIN
    _flag_3 = term_keep(e, _flag_3, 1);
    _v_30 = _main_0;
    _v_31 = _main_1;
    _v_32 = _result_17;
    _v_33 = _result_18;
    _v_34 = _flag_2;
    _v_35 = _flag_3;
    _v_36 = _value_0;
    _v_37 = _value_1;
    _v_38 = _result_19;
    _v_39 = _result_20;
    _v_40 = _flag_2;
    _v_41 = _flag_3;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  return 1;
}

INLINE Term spin_115(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _value_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[1];
    if (spin_98(e, _o_0, _value_0, _value_0 == h0 ? q0 : blk_loc(e.mem, _value_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_3);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 384));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 78));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_5 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_24(e, _o_1, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_2 = _v_5;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_117(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _owner_20 = r0;
  u32 _owner_21 = r1;
  u32 _owner_22 = r2;
  u32 _owner_23 = r3;
  u32 _owner_24 = r4;
  u32 _owner_25 = r5;
  u32 _owner_26 = r6;
  u32 _owner_27 = r7;
  u32 _owner_28 = r8;
  Term _owner_29 = r9;
  u32 _owner_30 = r10;
  u32 _owner_31 = r11;
  u32 _owner_32 = r12;
  u32 _owner_33 = r13;
  u32 _owner_34 = r14;
  u32 _owner_35 = r15;
  u32 _owner_36 = r16;
  u32 _owner_37 = r17;
  Term _owner_38 = r18;
  Term _owner_39 = r19;
  WL_SPIN
    Term _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    Term _o_0[27];
    if (spin_100(e, _o_0, _owner_20, _owner_20 == h0 ? q0 : blk_loc(e.mem, _owner_20), _owner_21, _owner_22, _owner_23, _owner_24, _owner_25, _owner_26, _owner_27, _owner_28, _owner_29, _owner_29 == h9 ? q9 : blk_loc(e.mem, _owner_29), _owner_30, _owner_31, _owner_32, _owner_33, _owner_34, _owner_35, _owner_36, _owner_37, _owner_38, _owner_38 == h18 ? q18 : blk_loc(e.mem, _owner_38), _owner_39, _owner_39 == h19 ? q19 : blk_loc(e.mem, _owner_39)) == 0) {
      return 0;
    }
    _v_69 = _o_0[0];
    _v_70 = _o_0[1];
    _v_71 = _o_0[2];
    _v_72 = _o_0[3];
    _v_73 = _o_0[4];
    _v_74 = _o_0[5];
    _v_75 = _o_0[6];
    _v_76 = _o_0[7];
    _v_77 = _o_0[8];
    _v_78 = _o_0[9];
    _v_79 = _o_0[10];
    _v_80 = _o_0[11];
    _v_81 = _o_0[12];
    _v_82 = _o_0[13];
    _v_83 = _o_0[14];
    _v_84 = _o_0[15];
    _v_85 = _o_0[16];
    _v_86 = _o_0[17];
    _v_87 = _o_0[18];
    _v_88 = _o_0[19];
    _v_89 = _o_0[20];
    _v_90 = _o_0[21];
    _v_91 = _o_0[22];
    _v_92 = _o_0[23];
    _v_93 = _o_0[24];
    _v_94 = _o_0[25];
    _v_95 = _o_0[26];
    _v_42 = _v_69;
    _v_43 = _v_70;
    _v_44 = _v_71;
    _v_45 = _v_72;
    _v_46 = _v_73;
    _v_47 = _v_74;
    _v_48 = _v_75;
    _v_49 = _v_76;
    _v_50 = _v_77;
    _v_51 = _v_78;
    _v_52 = _v_79;
    _v_53 = _v_80;
    _v_54 = _v_81;
    _v_55 = _v_82;
    _v_56 = _v_83;
    _v_57 = _v_84;
    _v_58 = _v_85;
    _v_59 = _v_86;
    _v_60 = _v_87;
    _v_61 = _v_88;
    _v_62 = _v_89;
    _v_63 = _v_90;
    _v_64 = _v_91;
    _v_65 = _v_92;
    _v_66 = _v_93;
    _v_67 = _v_94;
    _v_68 = _v_95;
    Term _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    Term _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    u32 _v_116 = 0;
    Term _o_1[21];
    if (spin_101(e, _o_1, _v_42, _v_42 == h19 ? q19 : _v_42 == h18 ? q18 : _v_42 == h9 ? q9 : _v_42 == h0 ? q0 : blk_loc(e.mem, _v_42), _v_43, _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_50, _v_51, _v_51 == h19 ? q19 : _v_51 == h18 ? q18 : _v_51 == h9 ? q9 : _v_51 == h0 ? q0 : blk_loc(e.mem, _v_51), _v_52, _v_53, _v_54, _v_55, _v_56, _v_57, _v_58, _v_59, _v_60, _v_60 == h19 ? q19 : _v_60 == h18 ? q18 : _v_60 == h9 ? q9 : _v_60 == h0 ? q0 : blk_loc(e.mem, _v_60), _v_61, _v_61 == h19 ? q19 : _v_61 == h18 ? q18 : _v_61 == h9 ? q9 : _v_61 == h0 ? q0 : blk_loc(e.mem, _v_61), _v_62, _v_63, _v_64, _v_65, _v_66, _v_67, _v_68) == 0) {
      return 0;
    }
    _v_96 = _o_1[0];
    _v_97 = _o_1[1];
    _v_98 = _o_1[2];
    _v_99 = _o_1[3];
    _v_100 = _o_1[4];
    _v_101 = _o_1[5];
    _v_102 = _o_1[6];
    _v_103 = _o_1[7];
    _v_104 = _o_1[8];
    _v_105 = _o_1[9];
    _v_106 = _o_1[10];
    _v_107 = _o_1[11];
    _v_108 = _o_1[12];
    _v_109 = _o_1[13];
    _v_110 = _o_1[14];
    _v_111 = _o_1[15];
    _v_112 = _o_1[16];
    _v_113 = _o_1[17];
    _v_114 = _o_1[18];
    _v_115 = _o_1[19];
    _v_116 = _o_1[20];
    _v_21 = _v_96;
    _v_22 = _v_97;
    _v_23 = _v_98;
    _v_24 = _v_99;
    _v_25 = _v_100;
    _v_26 = _v_101;
    _v_27 = _v_102;
    _v_28 = _v_103;
    _v_29 = _v_104;
    _v_30 = _v_105;
    _v_31 = _v_106;
    _v_32 = _v_107;
    _v_33 = _v_108;
    _v_34 = _v_109;
    _v_35 = _v_110;
    _v_36 = _v_111;
    _v_37 = _v_112;
    _v_38 = _v_113;
    _v_39 = _v_114;
    _v_40 = _v_115;
    _v_41 = _v_116;
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_118(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _valid_0 = r0;
  Term _live_0 = r1;
  Term _changed_0 = r2;
  u32 _id_0 = r3;
  u32 _tick_1 = r4;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_10 = _live_0;
      _v_11 = _changed_0;
    } else {
      Term _at_0 = _live_0 == h1 ? q1 : blk_loc(e.mem, _live_0);
      Term _at_1 = blk_at(_live_0, U32_BIN(_id_0, -, 1ull), 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      Term _v_12 = 0;
      Term _v_13 = 0;
      Term _o_3[2];
      if (spin_102(e, _o_3, _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), U32_BIN(_id_0, -, 1ull), _tick_1, _live_0, _live_0 == h1 ? q1 : blk_loc(e.mem, _live_0), _c_0) == 0) {
        return 0;
      }
      _v_12 = _o_3[0];
      _v_13 = _o_3[1];
      _v_10 = _v_12;
      _v_11 = _v_13;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  return 1;
}

INLINE Term spin_119(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  WL_SPIN
    _v_20 = _rows_0;
    _v_21 = _rows_1;
    _v_22 = _rows_2;
    _v_23 = _rows_3;
    _v_24 = _rows_4;
    _v_25 = _rows_5;
    _v_26 = _rows_6;
    _v_27 = _rows_7;
    _v_28 = _rows_8;
    _v_29 = _rows_8;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  return 1;
}

INLINE Term spin_120(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _value_46 = r0;
  WL_SPIN
    if (_value_46 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 422);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 442);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_121(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  WL_SPIN
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _o_0[5];
    if (spin_11(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0)) == 0) {
      return 0;
    }
    _v_26 = _o_0[0];
    _v_27 = _o_0[1];
    _v_28 = _o_0[2];
    _v_29 = _o_0[3];
    _v_30 = _o_0[4];
    _v_21 = _v_26;
    _v_22 = _v_27;
    _v_23 = _v_28;
    _v_24 = _v_29;
    _v_25 = _v_30;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_1[7];
    if (spin_106(e, _o_1, _owner_1, _v_21, _v_21 == h0 ? q0 : blk_loc(e.mem, _v_21), _v_22, _v_23, _v_24, _v_25) == 0) {
      return 0;
    }
    _v_31 = _o_1[0];
    _v_32 = _o_1[1];
    _v_33 = _o_1[2];
    _v_34 = _o_1[3];
    _v_35 = _o_1[4];
    _v_36 = _o_1[5];
    _v_37 = _o_1[6];
    _v_14 = _v_31;
    _v_15 = _v_32;
    _v_16 = _v_33;
    _v_17 = _v_34;
    _v_18 = _v_35;
    _v_19 = _v_36;
    _v_20 = _v_37;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  return 1;
}

INLINE Term spin_122(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  WL_SPIN
    _v_40 = _result_0;
    _v_41 = _result_1;
  break;
  }
  o[0] = _v_40;
  o[1] = _v_41;
  return 1;
}

INLINE Term spin_123(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _reserve_0 = r0;
  u32 _class_0 = r1;
  Term _result_0 = r2;
  u32 _result_1 = r3;
  u32 _result_2 = r4;
  u32 _result_3 = r5;
  u32 _result_4 = r6;
  WL_SPIN
    _v_19 = _result_0;
    _v_20 = _reserve_0;
    _v_21 = _class_0;
    _v_22 = _result_1;
    _v_23 = _result_2;
    _v_24 = _result_3;
    _v_25 = _result_4;
    _v_26 = _reserve_0;
    _v_27 = _class_0;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  return 1;
}

INLINE Term spin_124(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _owner_7 = r7;
  u32 _owner_8 = r8;
  WL_SPIN
    _v_15 = _owner_0;
    _v_16 = _owner_1;
    _v_17 = _owner_2;
    _v_18 = _owner_3;
    _v_19 = _owner_4;
    _v_20 = _owner_5;
    _v_21 = _owner_6;
    _v_22 = _owner_7;
    _v_23 = _owner_8;
    _v_24 = _owner_3;
    _v_25 = _owner_4;
    _v_26 = _owner_5;
    _v_27 = _owner_6;
    _v_28 = _owner_7;
    _v_29 = _owner_8;
  break;
  }
  o[0] = _v_15;
  o[1] = _v_16;
  o[2] = _v_17;
  o[3] = _v_18;
  o[4] = _v_19;
  o[5] = _v_20;
  o[6] = _v_21;
  o[7] = _v_22;
  o[8] = _v_23;
  o[9] = _v_24;
  o[10] = _v_25;
  o[11] = _v_26;
  o[12] = _v_27;
  o[13] = _v_28;
  o[14] = _v_29;
  return 1;
}

INLINE Term spin_126(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _handle_0 = r0;
  Term _undo_0 = r1;
  Term _commands_0 = r2;
  Term _pings_0 = r3;
  Term _marks_0 = r4;
  Term _result_0 = r5;
  u32 _result_1 = r6;
  u32 _result_2 = r7;
  WL_SPIN
    if (_result_1 == 0) {
      _handle_0 = term_keep(e, _handle_0, 1);
      _handle_0 = term_keep(e, _handle_0, 1);
      u64 _nd_13 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_13 + 0] = rfc_seal(e, _handle_0);
      e.mem[_nd_13 + 1] = rfc_seal(e, _result_2);
      u64 _nd_14 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_14 + 0] = rfc_seal(e, term_ctr(CID_TRANSACTION_MAININVERSE, _nd_13));
      e.mem[_nd_14 + 1] = rfc_seal(e, _undo_0);
      u64 _nd_15 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_15 + 0] = rfc_seal(e, _handle_0);
      e.mem[_nd_15 + 1] = rfc_seal(e, _marks_0);
      _v_6 = _result_0;
      _v_7 = _handle_0;
      _v_8 = term_ctr(CID_CON, _nd_14);
      _v_9 = _commands_0;
      _v_10 = _pings_0;
      _v_11 = term_ctr(CID_CON, _nd_15);
    } else {
      _v_6 = _result_0;
      _v_7 = _handle_0;
      _v_8 = _undo_0;
      _v_9 = _commands_0;
      _v_10 = _pings_0;
      _v_11 = _marks_0;
    }
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  o[3] = _v_9;
  o[4] = _v_10;
  o[5] = _v_11;
  return 1;
}

INLINE Term spin_127(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  Term _selected_0 = r0;
  Term _undo_0 = r1;
  Term _commands_0 = r2;
  Term _pings_0 = r3;
  Term _marks_0 = r4;
  Term _result_0 = r5;
  u32 _result_1 = r6;
  Term _result_2 = r7;
  WL_SPIN
    _v_20 = _result_0;
    _v_21 = _selected_0;
    _v_22 = _undo_0;
    _v_23 = _commands_0;
    _v_24 = _pings_0;
    _v_25 = _marks_0;
    _v_26 = _result_1;
    _v_27 = _result_2;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  return 1;
}

INLINE Term spin_128(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _owner_9 = r0;
  u32 _owner_10 = r1;
  u32 _owner_11 = r2;
  WL_SPIN
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[5];
    if (spin_48(e, _o_0, _owner_9, _owner_9 == h0 ? q0 : blk_loc(e.mem, _owner_9)) == 0) {
      return 0;
    }
    _v_23 = _o_0[0];
    _v_24 = _o_0[1];
    _v_25 = _o_0[2];
    _v_26 = _o_0[3];
    _v_27 = _o_0[4];
    _v_18 = _v_23;
    _v_19 = _v_24;
    _v_20 = _v_25;
    _v_21 = _v_26;
    _v_22 = _v_27;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    Term _o_1[9];
    if (spin_111(e, _o_1, _owner_10, _owner_11, _v_18, _v_18 == h0 ? q0 : blk_loc(e.mem, _v_18), _v_19, _v_20, _v_21, _v_22) == 0) {
      return 0;
    }
    _v_28 = _o_1[0];
    _v_29 = _o_1[1];
    _v_30 = _o_1[2];
    _v_31 = _o_1[3];
    _v_32 = _o_1[4];
    _v_33 = _o_1[5];
    _v_34 = _o_1[6];
    _v_35 = _o_1[7];
    _v_36 = _o_1[8];
    _v_9 = _v_28;
    _v_10 = _v_29;
    _v_11 = _v_30;
    _v_12 = _v_31;
    _v_13 = _v_32;
    _v_14 = _v_33;
    _v_15 = _v_34;
    _v_16 = _v_35;
    _v_17 = _v_36;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

FAR Term spin_129(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h6 = r6;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _aux_0 = r0;
  Term _aux_1 = r1;
  u32 _aux_2 = r2;
  u32 _flag_0 = r3;
  u32 _flag_1 = r4;
  u32 _result_0 = r5;
  Term _result_1 = r6;
  u32 _result_2 = r7;
  u32 _result_3 = r8;
  u32 _result_4 = r9;
  u32 _result_5 = r10;
  u32 _result_6 = r11;
  u32 _result_7 = r12;
  u32 _result_8 = r13;
  u32 _result_9 = r14;
  u32 _result_10 = r15;
  u32 _result_11 = r16;
  u32 _result_12 = r17;
  u32 _result_13 = r18;
  u32 _result_14 = r19;
  u32 _result_15 = r20;
  u32 _result_16 = r21;
  WL_SPIN
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _o_0[9];
    if (spin_8(e, _o_0, _aux_0, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _aux_2) == 0) {
      return 0;
    }
    _v_69 = _o_0[0];
    _v_70 = _o_0[1];
    _v_71 = _o_0[2];
    _v_72 = _o_0[3];
    _v_73 = _o_0[4];
    _v_74 = _o_0[5];
    _v_75 = _o_0[6];
    _v_76 = _o_0[7];
    _v_77 = _o_0[8];
    _v_60 = _v_69;
    _v_61 = _v_70;
    _v_62 = _v_71;
    _v_63 = _v_72;
    _v_64 = _v_73;
    _v_65 = _v_74;
    _v_66 = _v_75;
    _v_67 = _v_76;
    _v_68 = _v_77;
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_result_0 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _result_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _result_2);
      e.mem[_nd_0 + 2] = rfc_seal(e, _result_3);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_4);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_5);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_6);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_7);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_8);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_9);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
      _o_2 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    u32 _o_3 = 0;
    Term _o_4 = 0;
    if (_result_10 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_3 + 0] = rfc_seal(e, _result_11);
      e.mem[_nd_3 + 1] = rfc_seal(e, _result_12);
      e.mem[_nd_3 + 2] = rfc_seal(e, _result_13);
      e.mem[_nd_3 + 3] = rfc_seal(e, _result_14);
      e.mem[_nd_3 + 4] = rfc_seal(e, _result_15);
      e.mem[_nd_3 + 5] = rfc_seal(e, _result_16);
      _o_4 = term_ctr(CID_TYPES_VITALSVIEW, _nd_3);
    }
    u32 _o_5 = 0;
    Term _o_6 = 0;
    if (_flag_0 == 0) {
      _o_5 = 0;
    } else {
      _o_5 = 1;
      _o_6 = term_pak(CID_TYPES_TRACKED, _flag_1);
    }
    u32 _o_7 = 0;
    Term _o_8 = 0;
    if (_v_60 == 0) {
      _o_7 = 0;
    } else {
      _o_7 = 1;
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _v_61);
      e.mem[_nd_4 + 1] = rfc_seal(e, _v_62);
      _o_8 = term_ctr(CID_TYPES_ARMOR, _nd_4);
    }
    u32 _o_9 = 0;
    Term _o_10 = 0;
    if (_v_63 == 0) {
      _o_9 = 0;
    } else {
      _o_9 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_5 + 0] = rfc_seal(e, _v_64);
      e.mem[_nd_5 + 1] = rfc_seal(e, _v_65);
      e.mem[_nd_5 + 2] = rfc_seal(e, _v_66);
      e.mem[_nd_5 + 3] = rfc_seal(e, _v_67);
      e.mem[_nd_5 + 4] = rfc_seal(e, _v_68);
      _o_10 = term_ctr(CID_TYPES_ARMORVIEW, _nd_5);
    }
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    Term _v_83 = 0;
    u32 _v_84 = 0;
    Term _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    u32 _v_88 = 0;
    Term _v_89 = 0;
    Term _o_11[12];
    if (spin_114(e, _o_11, _o_1, _o_2, _o_2 == h6 ? q6 : _o_2 == h1 ? q1 : blk_loc(e.mem, _o_2), _o_3, _o_4, _o_4 == h6 ? q6 : _o_4 == h1 ? q1 : blk_loc(e.mem, _o_4), _o_5, _o_6, _o_6 == h6 ? q6 : _o_6 == h1 ? q1 : blk_loc(e.mem, _o_6), _o_7, _o_8, _o_8 == h6 ? q6 : _o_8 == h1 ? q1 : blk_loc(e.mem, _o_8), _o_9, _o_10, _o_10 == h6 ? q6 : _o_10 == h1 ? q1 : blk_loc(e.mem, _o_10)) == 0) {
      return 0;
    }
    _v_78 = _o_11[0];
    _v_79 = _o_11[1];
    _v_80 = _o_11[2];
    _v_81 = _o_11[3];
    _v_82 = _o_11[4];
    _v_83 = _o_11[5];
    _v_84 = _o_11[6];
    _v_85 = _o_11[7];
    _v_86 = _o_11[8];
    _v_87 = _o_11[9];
    _v_88 = _o_11[10];
    _v_89 = _o_11[11];
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    if (_v_78 == 0) {
      _o_12 = 0;
    } else {
      _o_12 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_79, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      Term _fb_2[6];
      u64 _sp_2 = ctr_take(e, _f_1, 6, _fb_2);
      u32 _f_5 = _fb_2[0];
      u32 _f_6 = _fb_2[1];
      u32 _f_7 = _fb_2[2];
      u32 _f_8 = _fb_2[3];
      u32 _f_9 = _fb_2[4];
      u32 _f_10 = _fb_2[5];
      spare_free(e, cls_fit(6), _sp_2);
      _o_13 = _f_2;
      _o_14 = _f_3;
      _o_15 = _f_4;
      _o_16 = _f_5;
      _o_17 = _f_6;
      _o_18 = _f_7;
      _o_19 = _f_8;
      _o_20 = _f_9;
      _o_21 = _f_10;
    }
    u32 _o_22 = 0;
    Term _o_23 = 0;
    u32 _o_24 = 0;
    if (_v_80 == 0) {
      _o_22 = 0;
    } else {
      _o_22 = 1;
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _v_81, 2, _fb_3);
      Term _f_11 = _fb_3[0];
      u32 _f_12 = _fb_3[1];
      spare_free(e, cls_fit(2), _sp_3);
      _o_23 = _f_11;
      _o_24 = _f_12;
    }
    u32 _o_25 = 0;
    u32 _o_26 = 0;
    if (_v_82 == 0) {
      _o_25 = 0;
    } else {
      _o_25 = 1;
      _o_26 = term_loc(_v_83);
    }
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    if (_v_84 == 0) {
      _o_27 = 0;
    } else {
      _o_27 = 1;
      Term _fb_4[6];
      u64 _sp_4 = ctr_take(e, _v_85, 6, _fb_4);
      u32 _f_13 = _fb_4[0];
      u32 _f_14 = _fb_4[1];
      u32 _f_15 = _fb_4[2];
      u32 _f_16 = _fb_4[3];
      u32 _f_17 = _fb_4[4];
      u32 _f_18 = _fb_4[5];
      spare_free(e, cls_fit(6), _sp_4);
      _o_28 = _f_13;
      _o_29 = _f_14;
      _o_30 = _f_15;
      _o_31 = _f_16;
      _o_32 = _f_17;
      _o_33 = _f_18;
    }
    u32 _o_34 = 0;
    u32 _o_35 = 0;
    u32 _o_36 = 0;
    u32 _o_37 = 0;
    u32 _o_38 = 0;
    u32 _o_39 = 0;
    if (_v_86 == 0) {
      _o_34 = 0;
    } else {
      _o_34 = 1;
      Term _fb_5[5];
      u64 _sp_5 = ctr_take(e, _v_87, 5, _fb_5);
      u32 _f_19 = _fb_5[0];
      u32 _f_20 = _fb_5[1];
      u32 _f_21 = _fb_5[2];
      u32 _f_22 = _fb_5[3];
      u32 _f_23 = _fb_5[4];
      spare_free(e, cls_fit(5), _sp_5);
      _o_35 = _f_19;
      _o_36 = _f_20;
      _o_37 = _f_21;
      _o_38 = _f_22;
      _o_39 = _f_23;
    }
    u32 _o_40 = 0;
    u32 _o_41 = 0;
    if (_v_88 == 0) {
      _o_40 = 0;
    } else {
      _o_40 = 1;
      _o_41 = term_loc(_v_89);
    }
    _v_30 = _o_12;
    _v_31 = _o_13;
    _v_32 = _o_14;
    _v_33 = _o_15;
    _v_34 = _o_16;
    _v_35 = _o_17;
    _v_36 = _o_18;
    _v_37 = _o_19;
    _v_38 = _o_20;
    _v_39 = _o_21;
    _v_40 = _o_22;
    _v_41 = _o_23;
    _v_42 = _o_24;
    _v_43 = _o_25;
    _v_44 = _o_26;
    _v_45 = _o_27;
    _v_46 = _o_28;
    _v_47 = _o_29;
    _v_48 = _o_30;
    _v_49 = _o_31;
    _v_50 = _o_32;
    _v_51 = _o_33;
    _v_52 = _o_34;
    _v_53 = _o_35;
    _v_54 = _o_36;
    _v_55 = _o_37;
    _v_56 = _o_38;
    _v_57 = _o_39;
    _v_58 = _o_40;
    _v_59 = _o_41;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  o[15] = _v_45;
  o[16] = _v_46;
  o[17] = _v_47;
  o[18] = _v_48;
  o[19] = _v_49;
  o[20] = _v_50;
  o[21] = _v_51;
  o[22] = _v_52;
  o[23] = _v_53;
  o[24] = _v_54;
  o[25] = _v_55;
  o[26] = _v_56;
  o[27] = _v_57;
  o[28] = _v_58;
  o[29] = _v_59;
  return 1;
}

INLINE Term spin_131(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _owner_7 = r7;
  u32 _owner_8 = r8;
  Term _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  u32 _owner_16 = r16;
  u32 _owner_17 = r17;
  Term _owner_18 = r18;
  Term _owner_19 = r19;
  WL_SPIN
    Term _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    u32 _v_83 = 0;
    Term _o_0[21];
    if (spin_117(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0), _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _owner_7, _owner_8, _owner_9, _owner_9 == h9 ? q9 : blk_loc(e.mem, _owner_9), _owner_10, _owner_11, _owner_12, _owner_13, _owner_14, _owner_15, _owner_16, _owner_17, _owner_18, _owner_18 == h18 ? q18 : blk_loc(e.mem, _owner_18), _owner_19, _owner_19 == h19 ? q19 : blk_loc(e.mem, _owner_19)) == 0) {
      return 0;
    }
    _v_63 = _o_0[0];
    _v_64 = _o_0[1];
    _v_65 = _o_0[2];
    _v_66 = _o_0[3];
    _v_67 = _o_0[4];
    _v_68 = _o_0[5];
    _v_69 = _o_0[6];
    _v_70 = _o_0[7];
    _v_71 = _o_0[8];
    _v_72 = _o_0[9];
    _v_73 = _o_0[10];
    _v_74 = _o_0[11];
    _v_75 = _o_0[12];
    _v_76 = _o_0[13];
    _v_77 = _o_0[14];
    _v_78 = _o_0[15];
    _v_79 = _o_0[16];
    _v_80 = _o_0[17];
    _v_81 = _o_0[18];
    _v_82 = _o_0[19];
    _v_83 = _o_0[20];
    _v_42 = _v_63;
    _v_43 = _v_64;
    _v_44 = _v_65;
    _v_45 = _v_66;
    _v_46 = _v_67;
    _v_47 = _v_68;
    _v_48 = _v_69;
    _v_49 = _v_70;
    _v_50 = _v_71;
    _v_51 = _v_72;
    _v_52 = _v_73;
    _v_53 = _v_74;
    _v_54 = _v_75;
    _v_55 = _v_76;
    _v_56 = _v_77;
    _v_57 = _v_78;
    _v_58 = _v_79;
    _v_59 = _v_80;
    _v_60 = _v_81;
    _v_61 = _v_82;
    _v_62 = _v_83;
  break;
  }
  o[0] = _v_42;
  o[1] = _v_43;
  o[2] = _v_44;
  o[3] = _v_45;
  o[4] = _v_46;
  o[5] = _v_47;
  o[6] = _v_48;
  o[7] = _v_49;
  o[8] = _v_50;
  o[9] = _v_51;
  o[10] = _v_52;
  o[11] = _v_53;
  o[12] = _v_54;
  o[13] = _v_55;
  o[14] = _v_56;
  o[15] = _v_57;
  o[16] = _v_58;
  o[17] = _v_59;
  o[18] = _v_60;
  o[19] = _v_61;
  o[20] = _v_62;
  return 1;
}

INLINE Term spin_132(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, u32 r20, u32 r21, u32 r22, Term r23, u64 q23, Term r24, u64 q24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, Term r28, u64 q28, u32 r29, Term r30, u32 r31, Term r32, u64 q32, u32 r33, Term r34, u64 q34, Term r35, u64 q35) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  Term h18 = r18;
  Term h19 = r19;
  Term h23 = r23;
  Term h24 = r24;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  Term h28 = r28;
  Term h32 = r32;
  Term h34 = r34;
  Term h35 = r35;
  u32 _v_112 = 0;
  u32 _v_113 = 0;
  Term _v_114 = 0;
  Term _v_115 = 0;
  Term _v_116 = 0;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  u32 _v_120 = 0;
  Term _v_121 = 0;
  u32 _v_122 = 0;
  Term _v_123 = 0;
  u32 _v_124 = 0;
  Term _v_125 = 0;
  u32 _v_126 = 0;
  u32 _v_127 = 0;
  u32 _v_128 = 0;
  u32 _v_129 = 0;
  u32 _v_130 = 0;
  u32 _v_131 = 0;
  u32 _v_132 = 0;
  u32 _v_133 = 0;
  u32 _v_134 = 0;
  Term _v_135 = 0;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  u32 _result_14 = r14;
  u32 _result_15 = r15;
  u32 _result_16 = r16;
  u32 _result_17 = r17;
  Term _result_18 = r18;
  Term _result_19 = r19;
  u32 _result_20 = r20;
  u32 _ns_1 = r21;
  u32 _next_1 = r22;
  Term _rows_0 = r23;
  Term _rows_1 = r24;
  Term _rows_2 = r25;
  Term _rows_3 = r26;
  Term _rows_4 = r27;
  Term _rows_5 = r28;
  u32 _rows_6 = r29;
  Term _rows_7 = r30;
  u32 _rows_8 = r31;
  Term _pending_1 = r32;
  u32 _mode_1 = r33;
  Term _commands_1 = r34;
  Term _pings_1 = r35;
  WL_SPIN
    Term _at_0 = _rows_0 == h23 ? q23 : blk_loc(e.mem, _rows_0);
    Term _at_1 = blk_at(_rows_0, U32_BIN(_result_17, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _t_0 = 1;
    if (_t_0 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _result_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _result_1);
      e.mem[_nd_0 + 2] = rfc_seal(e, _result_2);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_3);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_4);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_5);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_6);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_7);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_8);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
      _o_3 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _o_2);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _o_3);
    term_sink(e, _c_1);
    _v_112 = _ns_1;
    _v_113 = _next_1;
    _v_114 = _rows_0;
    _v_115 = _rows_1;
    _v_116 = _rows_2;
    _v_117 = _rows_3;
    _v_118 = _rows_4;
    _v_119 = _rows_5;
    _v_120 = _rows_6;
    _v_121 = _rows_7;
    _v_122 = _rows_8;
    _v_123 = _pending_1;
    _v_124 = 1;
    _v_125 = _result_9;
    _v_126 = _result_10;
    _v_127 = _result_11;
    _v_128 = _result_12;
    _v_129 = _result_13;
    _v_130 = _result_14;
    _v_131 = _result_15;
    _v_132 = _mode_1;
    _v_133 = _result_16;
    _v_134 = _result_17;
    _v_135 = _result_18;
    _v_136 = _commands_1;
    _v_137 = _pings_1;
    _v_138 = _result_19;
    _v_139 = _result_20;
  break;
  }
  o[0] = _v_112;
  o[1] = _v_113;
  o[2] = _v_114;
  o[3] = _v_115;
  o[4] = _v_116;
  o[5] = _v_117;
  o[6] = _v_118;
  o[7] = _v_119;
  o[8] = _v_120;
  o[9] = _v_121;
  o[10] = _v_122;
  o[11] = _v_123;
  o[12] = _v_124;
  o[13] = _v_125;
  o[14] = _v_126;
  o[15] = _v_127;
  o[16] = _v_128;
  o[17] = _v_129;
  o[18] = _v_130;
  o[19] = _v_131;
  o[20] = _v_132;
  o[21] = _v_133;
  o[22] = _v_134;
  o[23] = _v_135;
  o[24] = _v_136;
  o[25] = _v_137;
  o[26] = _v_138;
  o[27] = _v_139;
  return 1;
}

INLINE Term spin_136(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _raw_2 = r0;
  u32 _raw_3 = r1;
  WL_SPIN
    Term _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[7];
    if (spin_121(e, _o_0, _raw_2, _raw_2 == h0 ? q0 : blk_loc(e.mem, _raw_2), _raw_3) == 0) {
      return 0;
    }
    _v_21 = _o_0[0];
    _v_22 = _o_0[1];
    _v_23 = _o_0[2];
    _v_24 = _o_0[3];
    _v_25 = _o_0[4];
    _v_26 = _o_0[5];
    _v_27 = _o_0[6];
    _v_14 = _v_21;
    _v_15 = _v_22;
    _v_16 = _v_23;
    _v_17 = _v_24;
    _v_18 = _v_25;
    _v_19 = _v_26;
    _v_20 = _v_27;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_14);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_15);
    u64 _nd_1 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_16);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_17);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_18);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_19);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_20);
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _o_1[2];
    Term _a_0 = term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0);
    Term _a_1 = term_ctr(CID_TYPES_LEDGERVIEW, _nd_1);
    if (spin_122(e, _o_1, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _a_1, _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_28 = _o_1[0];
    _v_29 = _o_1[1];
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _v_28, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[5];
    u64 _sp_1 = ctr_take(e, _v_29, 5, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    u32 _f_4 = _fb_1[2];
    u32 _f_5 = _fb_1[3];
    u32 _f_6 = _fb_1[4];
    spare_free(e, cls_fit(5), _sp_1);
    _v_7 = _f_0;
    _v_8 = _f_1;
    _v_9 = _f_2;
    _v_10 = _f_3;
    _v_11 = _f_4;
    _v_12 = _f_5;
    _v_13 = _f_6;
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_137(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  WL_SPIN
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    Term _o_0[5];
    if (spin_11(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0)) == 0) {
      return 0;
    }
    _v_32 = _o_0[0];
    _v_33 = _o_0[1];
    _v_34 = _o_0[2];
    _v_35 = _o_0[3];
    _v_36 = _o_0[4];
    _v_27 = _v_32;
    _v_28 = _v_33;
    _v_29 = _v_34;
    _v_30 = _v_35;
    _v_31 = _v_36;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    Term _o_1[9];
    if (spin_123(e, _o_1, _owner_1, _owner_2, _v_27, _v_27 == h0 ? q0 : blk_loc(e.mem, _v_27), _v_28, _v_29, _v_30, _v_31) == 0) {
      return 0;
    }
    _v_37 = _o_1[0];
    _v_38 = _o_1[1];
    _v_39 = _o_1[2];
    _v_40 = _o_1[3];
    _v_41 = _o_1[4];
    _v_42 = _o_1[5];
    _v_43 = _o_1[6];
    _v_44 = _o_1[7];
    _v_45 = _o_1[8];
    _v_18 = _v_37;
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_138(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  WL_SPIN
    _v_48 = _result_0;
    _v_49 = _result_1;
  break;
  }
  o[0] = _v_48;
  o[1] = _v_49;
  return 1;
}

INLINE Term spin_139(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _selected_0 = r0;
  Term _undo_0 = r1;
  Term _commands_0 = r2;
  Term _pings_0 = r3;
  Term _marks_0 = r4;
  Term _result_0 = r5;
  u32 _result_1 = r6;
  Term _result_2 = r7;
  WL_SPIN
    _v_23 = _result_0;
    _v_24 = _selected_0;
    _v_25 = _undo_0;
    _v_26 = _commands_0;
    _v_27 = _pings_0;
    _v_28 = _marks_0;
    _v_29 = _result_1;
    _v_30 = _result_2;
  break;
  }
  o[0] = _v_23;
  o[1] = _v_24;
  o[2] = _v_25;
  o[3] = _v_26;
  o[4] = _v_27;
  o[5] = _v_28;
  o[6] = _v_29;
  o[7] = _v_30;
  return 1;
}

INLINE Term spin_140(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h12 = r12;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _id_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  u32 _result_2 = r3;
  Term _result_3 = r4;
  u32 _result_4 = r5;
  Term _result_5 = r6;
  u32 _result_6 = r7;
  Term _result_7 = r8;
  u32 _result_8 = r9;
  Term _result_9 = r10;
  u32 _result_10 = r11;
  Term _result_11 = r12;
  WL_SPIN
    _v_16 = 0;
    _v_17 = _id_0;
    _v_18 = _result_0;
    _v_19 = _result_1;
    _v_20 = _result_2;
    _v_21 = _result_3;
    _v_22 = _result_4;
    _v_23 = _result_5;
    _v_24 = 0;
    _v_25 = _id_0;
    _v_26 = _result_6;
    _v_27 = _result_7;
    _v_28 = _result_8;
    _v_29 = _result_9;
    _v_30 = _result_10;
    _v_31 = _result_11;
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  o[8] = _v_24;
  o[9] = _v_25;
  o[10] = _v_26;
  o[11] = _v_27;
  o[12] = _v_28;
  o[13] = _v_29;
  o[14] = _v_30;
  o[15] = _v_31;
  return 1;
}

INLINE Term spin_141(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _id_1 = r0;
  Term _result_12 = r1;
  Term _result_13 = r2;
  WL_SPIN
    _v_48 = 1;
    _v_49 = _id_1;
    _v_50 = _result_12;
    _v_51 = 0;
    _v_52 = 0;
    _v_53 = 0;
    _v_54 = 0;
    _v_55 = 0;
    _v_56 = 1;
    _v_57 = _id_1;
    _v_58 = _result_13;
    _v_59 = 0;
    _v_60 = 0;
    _v_61 = 0;
    _v_62 = 0;
    _v_63 = 0;
  break;
  }
  o[0] = _v_48;
  o[1] = _v_49;
  o[2] = _v_50;
  o[3] = _v_51;
  o[4] = _v_52;
  o[5] = _v_53;
  o[6] = _v_54;
  o[7] = _v_55;
  o[8] = _v_56;
  o[9] = _v_57;
  o[10] = _v_58;
  o[11] = _v_59;
  o[12] = _v_60;
  o[13] = _v_61;
  o[14] = _v_62;
  o[15] = _v_63;
  return 1;
}

INLINE Term spin_148(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h8 = r8;
  Term h10 = r10;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  Term _v_139 = 0;
  Term _v_140 = 0;
  Term _v_141 = 0;
  u32 _v_142 = 0;
  Term _v_143 = 0;
  u32 _v_144 = 0;
  u32 _v_145 = 0;
  Term _v_146 = 0;
  Term _aux_3 = r0;
  Term _metadata_8 = r1;
  Term _metadata_9 = r2;
  Term _metadata_10 = r3;
  Term _metadata_11 = r4;
  u32 _capacity_3 = r5;
  Term _depth_3 = r6;
  u32 _high_3 = r7;
  Term _result_2 = r8;
  u32 _result_3 = r9;
  Term _result_4 = r10;
  WL_SPIN
    if (_result_3 == 0) {
      _v_136 = _result_2;
      _v_137 = _aux_3;
      _v_138 = _metadata_8;
      _v_139 = _metadata_9;
      _v_140 = _metadata_10;
      _v_141 = _metadata_11;
      _v_142 = _capacity_3;
      _v_143 = _depth_3;
      _v_144 = _high_3;
      _v_145 = 1;
      _v_146 = 0;
    } else {
      _v_136 = _result_2;
      _v_137 = _aux_3;
      _v_138 = _metadata_8;
      _v_139 = _metadata_9;
      _v_140 = _metadata_10;
      _v_141 = _metadata_11;
      _v_142 = _capacity_3;
      _v_143 = _depth_3;
      _v_144 = _high_3;
      _v_145 = 0;
      _v_146 = _result_4;
    }
  break;
  }
  o[0] = _v_136;
  o[1] = _v_137;
  o[2] = _v_138;
  o[3] = _v_139;
  o[4] = _v_140;
  o[5] = _v_141;
  o[6] = _v_142;
  o[7] = _v_143;
  o[8] = _v_144;
  o[9] = _v_145;
  o[10] = _v_146;
  return 1;
}

INLINE Term spin_147(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_114 = 0;
  Term _v_115 = 0;
  Term _v_116 = 0;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  u32 _v_120 = 0;
  Term _v_121 = 0;
  u32 _v_122 = 0;
  u32 _v_123 = 0;
  Term _v_124 = 0;
  u32 _id_4 = r0;
  Term _main_2 = r1;
  Term _aux_2 = r2;
  Term _metadata_4 = r3;
  Term _metadata_5 = r4;
  Term _metadata_6 = r5;
  Term _metadata_7 = r6;
  u32 _capacity_2 = r7;
  Term _depth_2 = r8;
  u32 _high_2 = r9;
  u32 _meta_0 = r10;
  WL_SPIN
    if (_meta_0 == 0) {
      _v_114 = _main_2;
      _v_115 = _aux_2;
      _v_116 = _metadata_4;
      _v_117 = _metadata_5;
      _v_118 = _metadata_6;
      _v_119 = _metadata_7;
      _v_120 = _capacity_2;
      _v_121 = _depth_2;
      _v_122 = _high_2;
      _v_123 = 2;
      _v_124 = 0;
    } else {
      Term _at_2 = _main_2 == h1 ? q1 : blk_loc(e.mem, _main_2);
      Term _at_3 = blk_at(_main_2, U32_BIN(_id_4, -, 1ull), 1);
      u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_2 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, 0);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, 0);
      Term _v_125 = 0;
      Term _v_126 = 0;
      Term _v_127 = 0;
      Term _v_128 = 0;
      Term _v_129 = 0;
      Term _v_130 = 0;
      u32 _v_131 = 0;
      Term _v_132 = 0;
      u32 _v_133 = 0;
      u32 _v_134 = 0;
      Term _v_135 = 0;
      Term _o_2[11];
      if (spin_148(e, _o_2, _aux_2, _aux_2 == h2 ? q2 : blk_loc(e.mem, _aux_2), _metadata_4, _metadata_4 == h3 ? q3 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h4 ? q4 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h5 ? q5 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h6 ? q6 : blk_loc(e.mem, _metadata_7), _capacity_2, _depth_2, _high_2, _main_2, _main_2 == h1 ? q1 : blk_loc(e.mem, _main_2), _c_1, _c_2, _c_2 == h6 ? q6 : _c_2 == h5 ? q5 : _c_2 == h4 ? q4 : _c_2 == h3 ? q3 : _c_2 == h2 ? q2 : _c_2 == h1 ? q1 : blk_loc(e.mem, _c_2)) == 0) {
        return 0;
      }
      _v_125 = _o_2[0];
      _v_126 = _o_2[1];
      _v_127 = _o_2[2];
      _v_128 = _o_2[3];
      _v_129 = _o_2[4];
      _v_130 = _o_2[5];
      _v_131 = _o_2[6];
      _v_132 = _o_2[7];
      _v_133 = _o_2[8];
      _v_134 = _o_2[9];
      _v_135 = _o_2[10];
      _v_114 = _v_125;
      _v_115 = _v_126;
      _v_116 = _v_127;
      _v_117 = _v_128;
      _v_118 = _v_129;
      _v_119 = _v_130;
      _v_120 = _v_131;
      _v_121 = _v_132;
      _v_122 = _v_133;
      _v_123 = _v_134;
      _v_124 = _v_135;
    }
  break;
  }
  o[0] = _v_114;
  o[1] = _v_115;
  o[2] = _v_116;
  o[3] = _v_117;
  o[4] = _v_118;
  o[5] = _v_119;
  o[6] = _v_120;
  o[7] = _v_121;
  o[8] = _v_122;
  o[9] = _v_123;
  o[10] = _v_124;
  return 1;
}

INLINE Term spin_146(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, Term r9, u64 q9, u32 r10) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h9 = r9;
  Term _v_92 = 0;
  Term _v_93 = 0;
  Term _v_94 = 0;
  Term _v_95 = 0;
  Term _v_96 = 0;
  Term _v_97 = 0;
  u32 _v_98 = 0;
  Term _v_99 = 0;
  u32 _v_100 = 0;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  u32 _id_3 = r0;
  Term _main_1 = r1;
  Term _aux_1 = r2;
  Term _flags_0 = r3;
  Term _added_0 = r4;
  Term _changed_0 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  Term _result_0 = r9;
  u32 _result_1 = r10;
  WL_SPIN
    Term _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    Term _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    Term _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    Term _o_3[11];
    if (spin_147(e, _o_3, _id_3, _main_1, _main_1 == h1 ? q1 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h2 ? q2 : blk_loc(e.mem, _aux_1), _result_0, _result_0 == h9 ? q9 : blk_loc(e.mem, _result_0), _flags_0, _flags_0 == h3 ? q3 : blk_loc(e.mem, _flags_0), _added_0, _added_0 == h4 ? q4 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h5 ? q5 : blk_loc(e.mem, _changed_0), _capacity_1, _depth_1, _high_1, _result_1) == 0) {
      return 0;
    }
    _v_103 = _o_3[0];
    _v_104 = _o_3[1];
    _v_105 = _o_3[2];
    _v_106 = _o_3[3];
    _v_107 = _o_3[4];
    _v_108 = _o_3[5];
    _v_109 = _o_3[6];
    _v_110 = _o_3[7];
    _v_111 = _o_3[8];
    _v_112 = _o_3[9];
    _v_113 = _o_3[10];
    _v_92 = _v_103;
    _v_93 = _v_104;
    _v_94 = _v_105;
    _v_95 = _v_106;
    _v_96 = _v_107;
    _v_97 = _v_108;
    _v_98 = _v_109;
    _v_99 = _v_110;
    _v_100 = _v_111;
    _v_101 = _v_112;
    _v_102 = _v_113;
  break;
  }
  o[0] = _v_92;
  o[1] = _v_93;
  o[2] = _v_94;
  o[3] = _v_95;
  o[4] = _v_96;
  o[5] = _v_97;
  o[6] = _v_98;
  o[7] = _v_99;
  o[8] = _v_100;
  o[9] = _v_101;
  o[10] = _v_102;
  return 1;
}

INLINE Term spin_145(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  Term _v_75 = 0;
  u32 _v_76 = 0;
  Term _v_77 = 0;
  u32 _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _id_2 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  Term _metadata_0 = r3;
  Term _metadata_1 = r4;
  Term _metadata_2 = r5;
  Term _metadata_3 = r6;
  u32 _capacity_0 = r7;
  Term _depth_0 = r8;
  u32 _high_0 = r9;
  WL_SPIN
    Term _at_0 = _metadata_0 == h3 ? q3 : blk_loc(e.mem, _metadata_0);
    Term _at_1 = blk_at(_metadata_0, U32_BIN(_id_2, -, 1ull), 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    Term _v_91 = 0;
    Term _o_4[11];
    if (spin_146(e, _o_4, _id_2, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _metadata_1, _metadata_1 == h4 ? q4 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h5 ? q5 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h6 ? q6 : blk_loc(e.mem, _metadata_3), _capacity_0, _depth_0, _high_0, _metadata_0, _metadata_0 == h3 ? q3 : blk_loc(e.mem, _metadata_0), _c_0) == 0) {
      return 0;
    }
    _v_81 = _o_4[0];
    _v_82 = _o_4[1];
    _v_83 = _o_4[2];
    _v_84 = _o_4[3];
    _v_85 = _o_4[4];
    _v_86 = _o_4[5];
    _v_87 = _o_4[6];
    _v_88 = _o_4[7];
    _v_89 = _o_4[8];
    _v_90 = _o_4[9];
    _v_91 = _o_4[10];
    _v_70 = _v_81;
    _v_71 = _v_82;
    _v_72 = _v_83;
    _v_73 = _v_84;
    _v_74 = _v_85;
    _v_75 = _v_86;
    _v_76 = _v_87;
    _v_77 = _v_88;
    _v_78 = _v_89;
    _v_79 = _v_90;
    _v_80 = _v_91;
  break;
  }
  o[0] = _v_70;
  o[1] = _v_71;
  o[2] = _v_72;
  o[3] = _v_73;
  o[4] = _v_74;
  o[5] = _v_75;
  o[6] = _v_76;
  o[7] = _v_77;
  o[8] = _v_78;
  o[9] = _v_79;
  o[10] = _v_80;
  return 1;
}

INLINE Term spin_144(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  u32 _valid_1 = r0;
  u32 _id_1 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  WL_SPIN
    if (_valid_1 == 0) {
      _v_48 = _rows_18;
      _v_49 = _rows_19;
      _v_50 = _rows_20;
      _v_51 = _rows_21;
      _v_52 = _rows_22;
      _v_53 = _rows_23;
      _v_54 = _rows_24;
      _v_55 = _rows_25;
      _v_56 = _rows_26;
      _v_57 = 2;
      _v_58 = 0;
    } else {
      Term _v_59 = 0;
      Term _v_60 = 0;
      Term _v_61 = 0;
      Term _v_62 = 0;
      Term _v_63 = 0;
      Term _v_64 = 0;
      u32 _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      Term _v_69 = 0;
      Term _o_5[11];
      if (spin_145(e, _o_5, _id_1, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26) == 0) {
        return 0;
      }
      _v_59 = _o_5[0];
      _v_60 = _o_5[1];
      _v_61 = _o_5[2];
      _v_62 = _o_5[3];
      _v_63 = _o_5[4];
      _v_64 = _o_5[5];
      _v_65 = _o_5[6];
      _v_66 = _o_5[7];
      _v_67 = _o_5[8];
      _v_68 = _o_5[9];
      _v_69 = _o_5[10];
      _v_48 = _v_59;
      _v_49 = _v_60;
      _v_50 = _v_61;
      _v_51 = _v_62;
      _v_52 = _v_63;
      _v_53 = _v_64;
      _v_54 = _v_65;
      _v_55 = _v_66;
      _v_56 = _v_67;
      _v_57 = _v_68;
      _v_58 = _v_69;
    }
  break;
  }
  o[0] = _v_48;
  o[1] = _v_49;
  o[2] = _v_50;
  o[3] = _v_51;
  o[4] = _v_52;
  o[5] = _v_53;
  o[6] = _v_54;
  o[7] = _v_55;
  o[8] = _v_56;
  o[9] = _v_57;
  o[10] = _v_58;
  return 1;
}

INLINE Term spin_143(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _target_0 = r9;
  WL_SPIN
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_0[1];
    if (spin_43(e, _o_0, U32_BIN(_target_0, <=, _rows_15), U32_BIN(_target_0, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_35 = _o_0[0];
    _v_34 = _v_35;
    u32 _v_36 = 0;
    Term _o_1[1];
    if (spin_43(e, _o_1, U32_BIN(0ull, <, _target_0), _v_34) == 0) {
      return 0;
    }
    _v_36 = _o_1[0];
    _v_33 = _v_36;
    Term _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _o_6[11];
    if (spin_144(e, _o_6, _v_33, _target_0, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17) == 0) {
      return 0;
    }
    _v_37 = _o_6[0];
    _v_38 = _o_6[1];
    _v_39 = _o_6[2];
    _v_40 = _o_6[3];
    _v_41 = _o_6[4];
    _v_42 = _o_6[5];
    _v_43 = _o_6[6];
    _v_44 = _o_6[7];
    _v_45 = _o_6[8];
    _v_46 = _o_6[9];
    _v_47 = _o_6[10];
    _v_22 = _v_37;
    _v_23 = _v_38;
    _v_24 = _v_39;
    _v_25 = _v_40;
    _v_26 = _v_41;
    _v_27 = _v_42;
    _v_28 = _v_43;
    _v_29 = _v_44;
    _v_30 = _v_45;
    _v_31 = _v_46;
    _v_32 = _v_47;
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_150(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_6 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_150);
    }
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_149(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_5 = 0;
    Term _o_1[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_150(e, _o_1, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_4 = _v_5;
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_155(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _raw_0 = r0;
  u32 _raw_1 = r1;
  WL_SPIN
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[7];
    if (spin_136(e, _o_0, _raw_0, _raw_0 == h0 ? q0 : blk_loc(e.mem, _raw_0), _raw_1) == 0) {
      return 0;
    }
    _v_21 = _o_0[0];
    _v_22 = _o_0[1];
    _v_23 = _o_0[2];
    _v_24 = _o_0[3];
    _v_25 = _o_0[4];
    _v_26 = _o_0[5];
    _v_27 = _o_0[6];
    _v_14 = _v_21;
    _v_15 = _v_22;
    _v_16 = _v_23;
    _v_17 = _v_24;
    _v_18 = _v_25;
    _v_19 = _v_26;
    _v_20 = _v_27;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  return 1;
}

INLINE Term spin_156(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _raw_3 = r0;
  u32 _raw_4 = r1;
  u32 _raw_5 = r2;
  WL_SPIN
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_0[9];
    if (spin_137(e, _o_0, _raw_3, _raw_3 == h0 ? q0 : blk_loc(e.mem, _raw_3), _raw_4, _raw_5) == 0) {
      return 0;
    }
    _v_27 = _o_0[0];
    _v_28 = _o_0[1];
    _v_29 = _o_0[2];
    _v_30 = _o_0[3];
    _v_31 = _o_0[4];
    _v_32 = _o_0[5];
    _v_33 = _o_0[6];
    _v_34 = _o_0[7];
    _v_35 = _o_0[8];
    _v_18 = _v_27;
    _v_19 = _v_28;
    _v_20 = _v_29;
    _v_21 = _v_30;
    _v_22 = _v_31;
    _v_23 = _v_32;
    _v_24 = _v_33;
    _v_25 = _v_34;
    _v_26 = _v_35;
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_18);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_19);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_20);
    u64 _nd_1 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_21);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_22);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_23);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_24);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_25);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_26);
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _o_1[2];
    Term _a_0 = term_ctr(CID_TYPES_VITALS, _nd_0);
    Term _a_1 = term_ctr(CID_TYPES_VITALSVIEW, _nd_1);
    if (spin_138(e, _o_1, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _a_1, _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_36 = _o_1[0];
    _v_37 = _o_1[1];
    Term _fb_0[3];
    u64 _sp_0 = ctr_take(e, _v_36, 3, _fb_0);
    Term _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_0);
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _v_37, 6, _fb_1);
    u32 _f_3 = _fb_1[0];
    u32 _f_4 = _fb_1[1];
    u32 _f_5 = _fb_1[2];
    u32 _f_6 = _fb_1[3];
    u32 _f_7 = _fb_1[4];
    u32 _f_8 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    _v_9 = _f_0;
    _v_10 = _f_1;
    _v_11 = _f_2;
    _v_12 = _f_3;
    _v_13 = _f_4;
    _v_14 = _f_5;
    _v_15 = _f_6;
    _v_16 = _f_7;
    _v_17 = _f_8;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_157(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _raw_0 = r0;
  u32 _raw_1 = r1;
  u32 _raw_2 = r2;
  WL_SPIN
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_0[9];
    if (spin_156(e, _o_0, _raw_0, _raw_0 == h0 ? q0 : blk_loc(e.mem, _raw_0), _raw_1, _raw_2) == 0) {
      return 0;
    }
    _v_27 = _o_0[0];
    _v_28 = _o_0[1];
    _v_29 = _o_0[2];
    _v_30 = _o_0[3];
    _v_31 = _o_0[4];
    _v_32 = _o_0[5];
    _v_33 = _o_0[6];
    _v_34 = _o_0[7];
    _v_35 = _o_0[8];
    _v_18 = _v_27;
    _v_19 = _v_28;
    _v_20 = _v_29;
    _v_21 = _v_30;
    _v_22 = _v_31;
    _v_23 = _v_32;
    _v_24 = _v_33;
    _v_25 = _v_34;
    _v_26 = _v_35;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_159(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h7 = r7;
  Term h10 = r10;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  Term _v_6 = 0;
  Term _v_7 = 0;
  u32 _owner_0 = r0;
  u32 _owner_1 = r1;
  Term _owner_2 = r2;
  Term _owner_3 = r3;
  u32 _owner_4 = r4;
  Term _owner_5 = r5;
  u32 _owner_6 = r6;
  Term _owner_7 = r7;
  u32 _value_0 = r8;
  u32 _value_1 = r9;
  Term _value_2 = r10;
  Term _value_3 = r11;
  u32 _value_4 = r12;
  Term _value_5 = r13;
  u32 _value_6 = r14;
  Term _value_7 = r15;
  Term _result_0 = r16;
  Term _result_1 = r17;
  WL_SPIN
    Term _b_0 = 0;
    if (_owner_0 == 0) {
      u64 _nd_10 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_10 + 0] = rfc_seal(e, _owner_1);
      e.mem[_nd_10 + 1] = rfc_seal(e, _owner_2);
      e.mem[_nd_10 + 2] = rfc_seal(e, _owner_3);
      e.mem[_nd_10 + 3] = rfc_seal(e, _owner_4);
      e.mem[_nd_10 + 4] = rfc_seal(e, _owner_5);
      e.mem[_nd_10 + 5] = rfc_seal(e, _owner_6);
      e.mem[_nd_10 + 6] = rfc_seal(e, _owner_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_10);
    } else if (_owner_0 == 1) {
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, _owner_1);
      e.mem[_nd_11 + 1] = rfc_seal(e, _owner_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_11);
    } else if (_owner_0 == 2) {
      u64 _nd_12 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_12 + 0] = rfc_seal(e, _owner_1);
      e.mem[_nd_12 + 1] = rfc_seal(e, _owner_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_12);
    } else if (_owner_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _owner_1);
    } else if (_owner_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _owner_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _owner_1);
    }
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_13 + 1] = rfc_seal(e, _result_0);
    Term _b_1 = 0;
    if (_value_0 == 0) {
      u64 _nd_14 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_14 + 0] = rfc_seal(e, _value_1);
      e.mem[_nd_14 + 1] = rfc_seal(e, _value_2);
      e.mem[_nd_14 + 2] = rfc_seal(e, _value_3);
      e.mem[_nd_14 + 3] = rfc_seal(e, _value_4);
      e.mem[_nd_14 + 4] = rfc_seal(e, _value_5);
      e.mem[_nd_14 + 5] = rfc_seal(e, _value_6);
      e.mem[_nd_14 + 6] = rfc_seal(e, _value_7);
      _b_1 = term_ctr(CID_OBSERVATIONS_SPAWNVIEW, _nd_14);
    } else if (_value_0 == 1) {
      u64 _nd_15 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_15 + 0] = rfc_seal(e, _value_1);
      e.mem[_nd_15 + 1] = rfc_seal(e, _value_2);
      _b_1 = term_ctr(CID_OBSERVATIONS_MAINVIEW, _nd_15);
    } else if (_value_0 == 2) {
      u64 _nd_16 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_16 + 0] = rfc_seal(e, _value_1);
      e.mem[_nd_16 + 1] = rfc_seal(e, _value_2);
      _b_1 = term_ctr(CID_OBSERVATIONS_FLAGVIEW, _nd_16);
    } else if (_value_0 == 3) {
      _b_1 = term_pak(CID_OBSERVATIONS_REMOVEMAINVIEW, _value_1);
    } else if (_value_0 == 4) {
      _b_1 = term_pak(CID_OBSERVATIONS_REMOVEFLAGVIEW, _value_1);
    } else {
      _b_1 = term_pak(CID_OBSERVATIONS_DESPAWNVIEW, _value_1);
    }
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = rfc_seal(e, _b_1);
    e.mem[_nd_17 + 1] = rfc_seal(e, _result_1);
    _v_6 = term_ctr(CID_CON, _nd_13);
    _v_7 = term_ctr(CID_CON, _nd_17);
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  return 1;
}

INLINE Term spin_158(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h7 = r7;
  Term h10 = r10;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  Term _v_2 = 0;
  Term _v_3 = 0;
  u32 _head_0 = r0;
  u32 _head_1 = r1;
  Term _head_2 = r2;
  Term _head_3 = r3;
  u32 _head_4 = r4;
  Term _head_5 = r5;
  u32 _head_6 = r6;
  Term _head_7 = r7;
  u32 _head_8 = r8;
  u32 _head_9 = r9;
  Term _head_10 = r10;
  Term _head_11 = r11;
  u32 _head_12 = r12;
  Term _head_13 = r13;
  u32 _head_14 = r14;
  Term _head_15 = r15;
  Term _tail_0 = r16;
  Term _tail_1 = r17;
  WL_SPIN
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_60[2];
    if (spin_159(e, _o_60, _head_0, _head_1, _head_2, _head_2 == h2 ? q2 : blk_loc(e.mem, _head_2), _head_3, _head_3 == h3 ? q3 : blk_loc(e.mem, _head_3), _head_4, _head_5, _head_5 == h5 ? q5 : blk_loc(e.mem, _head_5), _head_6, _head_7, _head_7 == h7 ? q7 : blk_loc(e.mem, _head_7), _head_8, _head_9, _head_10, _head_10 == h10 ? q10 : blk_loc(e.mem, _head_10), _head_11, _head_11 == h11 ? q11 : blk_loc(e.mem, _head_11), _head_12, _head_13, _head_13 == h13 ? q13 : blk_loc(e.mem, _head_13), _head_14, _head_15, _head_15 == h15 ? q15 : blk_loc(e.mem, _head_15), _tail_0, _tail_0 == h16 ? q16 : blk_loc(e.mem, _tail_0), _tail_1, _tail_1 == h17 ? q17 : blk_loc(e.mem, _tail_1)) == 0) {
      return 0;
    }
    _v_4 = _o_60[0];
    _v_5 = _o_60[1];
    _v_2 = _v_4;
    _v_3 = _v_5;
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_162(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_35 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_35 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_5 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_5 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_5);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_162);
    }
  break;
  }
  o[0] = _v_35;
  return 1;
}

INLINE Term spin_161(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_33 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_34 = 0;
    Term _o_2[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_162(e, _o_2, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_34 = _o_2[0];
    _v_33 = _v_34;
  break;
  }
  o[0] = _v_33;
  return 1;
}

INLINE Term spin_160(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _t_0 = r0;
  Term _t_1 = r1;
  Term _t_2 = r2;
  Term _t_3 = r3;
  Term _t_4 = r4;
  Term _t_5 = r5;
  WL_SPIN
    term_sink(e, _t_1);
    term_sink(e, _t_2);
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _o_3[1];
    if (spin_161(e, _o_3, _t_3, _t_3 == h3 ? q3 : blk_loc(e.mem, _t_3)) == 0) {
      return 0;
    }
    _v_32 = _o_3[0];
    _v_31 = _v_32;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _o_4[1];
    if (spin_149(e, _o_4, _t_4, _t_4 == h4 ? q4 : blk_loc(e.mem, _t_4)) == 0) {
      return 0;
    }
    _v_37 = _o_4[0];
    _v_36 = _v_37;
    _v_26 = 0;
    _v_27 = _t_0;
    _v_28 = _v_31;
    _v_29 = _v_36;
    _v_30 = _t_5;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  return 1;
}

INLINE Term spin_165(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_145 = 0;
  u32 _v_146 = 0;
  Term _v_147 = 0;
  Term _v_148 = 0;
  Term _v_149 = 0;
  Term _v_150 = 0;
  Term _v_151 = 0;
  Term _v_152 = 0;
  u32 _v_153 = 0;
  Term _v_154 = 0;
  u32 _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  Term _v_158 = 0;
  Term _v_159 = 0;
  Term _marks_1 = r0;
  u32 _namespace_0 = r1;
  u32 _next_0 = r2;
  Term _main_0 = r3;
  Term _aux_0 = r4;
  Term _flags_0 = r5;
  Term _added_0 = r6;
  Term _transport_0 = r7;
  Term _transport_1 = r8;
  u32 _capacity_0 = r9;
  Term _depth_0 = r10;
  u32 _high_0 = r11;
  Term _pending_0 = r12;
  u32 _ledger_0 = r13;
  Term _ledger_1 = r14;
  Term _mode_0 = r15;
  u32 _tick_2 = r16;
  WL_SPIN
    if (term_aux(_marks_1) == CID_NIL) {
      _v_145 = _namespace_0;
      _v_146 = _next_0;
      _v_147 = _main_0;
      _v_148 = _aux_0;
      _v_149 = _transport_0;
      _v_150 = _flags_0;
      _v_151 = _added_0;
      _v_152 = _transport_1;
      _v_153 = _capacity_0;
      _v_154 = _depth_0;
      _v_155 = _high_0;
      _v_156 = _pending_0;
      _v_157 = _ledger_0;
      _v_158 = _ledger_1;
      _v_159 = _mode_0;
    } else {
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _marks_1, 2, _fb_3);
      Term _f_32 = _fb_3[0];
      Term _f_33 = _fb_3[1];
      Term _fb_4[2];
      u64 _sp_4 = ctr_take(e, _f_32, 2, _fb_4);
      u32 _f_34 = _fb_4[0];
      u32 _f_35 = _fb_4[1];
      spare_free(e, cls_fit(2), _sp_4);
      Term _v_160 = 0;
      Term _v_161 = 0;
      u32 _v_162 = 0;
      u32 _v_163 = 0;
      u32 _v_164 = 0;
      u32 _v_165 = 0;
      Term _o_25[1];
      if (spin_43(e, _o_25, U32_BIN(_f_35, <=, _capacity_0), U32_BIN(_f_35, <=, _high_0)) == 0) {
        return 0;
      }
      _v_165 = _o_25[0];
      _v_164 = _v_165;
      u32 _v_166 = 0;
      Term _o_26[1];
      if (spin_43(e, _o_26, U32_BIN(0ull, <, _f_35), _v_164) == 0) {
        return 0;
      }
      _v_166 = _o_26[0];
      _v_163 = _v_166;
      u32 _v_167 = 0;
      Term _o_27[1];
      if (spin_43(e, _o_27, U32_BIN(_namespace_0, ==, _f_34), _v_163) == 0) {
        return 0;
      }
      _v_167 = _o_27[0];
      _v_162 = _v_167;
      Term _v_168 = 0;
      Term _v_169 = 0;
      Term _o_28[2];
      if (spin_118(e, _o_28, _v_162, _transport_0, _transport_0 == h7 ? q7 : blk_loc(e.mem, _transport_0), _transport_1, _transport_1 == h8 ? q8 : blk_loc(e.mem, _transport_1), _f_35, _tick_2) == 0) {
        return 0;
      }
      _v_168 = _o_28[0];
      _v_169 = _o_28[1];
      _v_160 = _v_168;
      _v_161 = _v_169;
      spare_free(e, cls_fit(2), _sp_3);
      r0 = _f_33;
      r1 = _namespace_0;
      r2 = _next_0;
      r3 = _main_0;
      r4 = _aux_0;
      r5 = _flags_0;
      r6 = _added_0;
      r7 = _v_160;
      r8 = _v_161;
      r9 = _capacity_0;
      r10 = _depth_0;
      r11 = _high_0;
      r12 = _pending_0;
      r13 = _ledger_0;
      r14 = _ledger_1;
      r15 = _mode_0;
      r16 = _tick_2;
      _marks_1 = r0;
      _namespace_0 = r1;
      _next_0 = r2;
      _main_0 = r3;
      _aux_0 = r4;
      _flags_0 = r5;
      _added_0 = r6;
      _transport_0 = r7;
      _transport_1 = r8;
      _capacity_0 = r9;
      _depth_0 = r10;
      _high_0 = r11;
      _pending_0 = r12;
      _ledger_0 = r13;
      _ledger_1 = r14;
      _mode_0 = r15;
      _tick_2 = r16;
      WL_AGAIN(spin_165);
    }
  break;
  }
  o[0] = _v_145;
  o[1] = _v_146;
  o[2] = _v_147;
  o[3] = _v_148;
  o[4] = _v_149;
  o[5] = _v_150;
  o[6] = _v_151;
  o[7] = _v_152;
  o[8] = _v_153;
  o[9] = _v_154;
  o[10] = _v_155;
  o[11] = _v_156;
  o[12] = _v_157;
  o[13] = _v_158;
  o[14] = _v_159;
  return 1;
}

INLINE Term spin_164(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_115 = 0;
  u32 _v_116 = 0;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  Term _v_122 = 0;
  u32 _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  Term _v_126 = 0;
  u32 _v_127 = 0;
  Term _v_128 = 0;
  Term _v_129 = 0;
  Term _marks_0 = r0;
  u32 _world_0 = r1;
  u32 _world_1 = r2;
  Term _world_2 = r3;
  Term _world_3 = r4;
  Term _world_4 = r5;
  Term _world_5 = r6;
  Term _world_6 = r7;
  Term _world_7 = r8;
  u32 _world_8 = r9;
  Term _world_9 = r10;
  u32 _world_10 = r11;
  Term _world_11 = r12;
  u32 _world_12 = r13;
  Term _world_13 = r14;
  Term _world_14 = r15;
  u32 _tick_1 = r16;
  WL_SPIN
    if (term_aux(_marks_0) == CID_NIL) {
      _v_115 = _world_0;
      _v_116 = _world_1;
      _v_117 = _world_2;
      _v_118 = _world_3;
      _v_119 = _world_4;
      _v_120 = _world_5;
      _v_121 = _world_6;
      _v_122 = _world_7;
      _v_123 = _world_8;
      _v_124 = _world_9;
      _v_125 = _world_10;
      _v_126 = _world_11;
      _v_127 = _world_12;
      _v_128 = _world_13;
      _v_129 = _world_14;
    } else {
      u32 _v_130 = 0;
      u32 _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      Term _v_134 = 0;
      Term _v_135 = 0;
      Term _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      Term _v_139 = 0;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      u32 _v_142 = 0;
      Term _v_143 = 0;
      Term _v_144 = 0;
      Term _o_29[15];
      if (spin_165(e, _o_29, _marks_0, _marks_0 == h0 ? q0 : blk_loc(e.mem, _marks_0), _world_0, _world_1, _world_2, _world_2 == h3 ? q3 : blk_loc(e.mem, _world_2), _world_3, _world_3 == h4 ? q4 : blk_loc(e.mem, _world_3), _world_5, _world_5 == h6 ? q6 : blk_loc(e.mem, _world_5), _world_6, _world_6 == h7 ? q7 : blk_loc(e.mem, _world_6), _world_4, _world_4 == h5 ? q5 : blk_loc(e.mem, _world_4), _world_7, _world_7 == h8 ? q8 : blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, _world_11 == h12 ? q12 : blk_loc(e.mem, _world_11), _world_12, _world_13, _world_13 == h14 ? q14 : blk_loc(e.mem, _world_13), _world_14, _world_14 == h15 ? q15 : blk_loc(e.mem, _world_14), _tick_1) == 0) {
        return 0;
      }
      _v_130 = _o_29[0];
      _v_131 = _o_29[1];
      _v_132 = _o_29[2];
      _v_133 = _o_29[3];
      _v_134 = _o_29[4];
      _v_135 = _o_29[5];
      _v_136 = _o_29[6];
      _v_137 = _o_29[7];
      _v_138 = _o_29[8];
      _v_139 = _o_29[9];
      _v_140 = _o_29[10];
      _v_141 = _o_29[11];
      _v_142 = _o_29[12];
      _v_143 = _o_29[13];
      _v_144 = _o_29[14];
      _v_115 = _v_130;
      _v_116 = _v_131;
      _v_117 = _v_132;
      _v_118 = _v_133;
      _v_119 = _v_134;
      _v_120 = _v_135;
      _v_121 = _v_136;
      _v_122 = _v_137;
      _v_123 = _v_138;
      _v_124 = _v_139;
      _v_125 = _v_140;
      _v_126 = _v_141;
      _v_127 = _v_142;
      _v_128 = _v_143;
      _v_129 = _v_144;
    }
  break;
  }
  o[0] = _v_115;
  o[1] = _v_116;
  o[2] = _v_117;
  o[3] = _v_118;
  o[4] = _v_119;
  o[5] = _v_120;
  o[6] = _v_121;
  o[7] = _v_122;
  o[8] = _v_123;
  o[9] = _v_124;
  o[10] = _v_125;
  o[11] = _v_126;
  o[12] = _v_127;
  o[13] = _v_128;
  o[14] = _v_129;
  return 1;
}

INLINE Term spin_167(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_174 = 0;
  Term _xs_3 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_xs_3) == CID_NIL) {
      _v_174 = _acc_1;
    } else {
      Term _fb_5[2];
      u64 _sp_5 = ctr_take(e, _xs_3, 2, _fb_5);
      Term _f_36 = _fb_5[0];
      Term _f_37 = _fb_5[1];
      u64 _nd_6 = _sp_5 >= HEAP_OFF ? _sp_5 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, _f_36);
      e.mem[_nd_6 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_37;
      r1 = term_ctr(CID_CON, _nd_6);
      _xs_3 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_167);
    }
  break;
  }
  o[0] = _v_174;
  return 1;
}

INLINE Term spin_166(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_172 = 0;
  Term _xs_2 = r0;
  WL_SPIN
    Term _v_173 = 0;
    Term _o_31[1];
    Term _a_3 = term_pak(CID_NIL, 0);
    if (spin_167(e, _o_31, _xs_2, _xs_2 == h0 ? q0 : blk_loc(e.mem, _xs_2), _a_3, _a_3 == h0 ? q0 : blk_loc(e.mem, _a_3)) == 0) {
      return 0;
    }
    _v_173 = _o_31[0];
    _v_172 = _v_173;
  break;
  }
  o[0] = _v_172;
  return 1;
}

INLINE Term spin_170(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_210 = 0;
  Term _xs_5 = r0;
  Term _acc_2 = r1;
  WL_SPIN
    if (term_aux(_xs_5) == CID_NIL) {
      _v_210 = _acc_2;
    } else {
      Term _fb_6[2];
      u64 _sp_6 = ctr_take(e, _xs_5, 2, _fb_6);
      Term _f_38 = _fb_6[0];
      Term _f_39 = _fb_6[1];
      u64 _nd_7 = _sp_6 >= HEAP_OFF ? _sp_6 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, _f_38);
      e.mem[_nd_7 + 1] = rfc_seal(e, _acc_2);
      r0 = _f_39;
      r1 = term_ctr(CID_CON, _nd_7);
      _xs_5 = r0;
      _acc_2 = r1;
      WL_AGAIN(spin_170);
    }
  break;
  }
  o[0] = _v_210;
  return 1;
}

INLINE Term spin_169(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_208 = 0;
  Term _xs_4 = r0;
  WL_SPIN
    Term _v_209 = 0;
    Term _o_33[1];
    Term _a_4 = term_pak(CID_NIL, 0);
    if (spin_170(e, _o_33, _xs_4, _xs_4 == h0 ? q0 : blk_loc(e.mem, _xs_4), _a_4, _a_4 == h0 ? q0 : blk_loc(e.mem, _a_4)) == 0) {
      return 0;
    }
    _v_209 = _o_33[0];
    _v_208 = _v_209;
  break;
  }
  o[0] = _v_208;
  return 1;
}

INLINE Term spin_168(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_190 = 0;
  u32 _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  Term _v_194 = 0;
  Term _v_195 = 0;
  Term _v_196 = 0;
  Term _v_197 = 0;
  u32 _v_198 = 0;
  Term _v_199 = 0;
  u32 _v_200 = 0;
  Term _v_201 = 0;
  u32 _v_202 = 0;
  Term _v_203 = 0;
  Term _v_204 = 0;
  u32 _world_15 = r0;
  u32 _world_16 = r1;
  Term _world_17 = r2;
  Term _world_18 = r3;
  Term _world_19 = r4;
  Term _world_20 = r5;
  Term _world_21 = r6;
  Term _world_22 = r7;
  u32 _world_23 = r8;
  Term _world_24 = r9;
  u32 _world_25 = r10;
  Term _world_26 = r11;
  u32 _world_27 = r12;
  Term _world_28 = r13;
  Term _world_29 = r14;
  Term _staged_0 = r15;
  WL_SPIN
    Term _v_205 = 0;
    Term _v_206 = 0;
    Term _v_207 = 0;
    Term _o_34[1];
    if (spin_169(e, _o_34, _staged_0, _staged_0 == h15 ? q15 : blk_loc(e.mem, _staged_0)) == 0) {
      return 0;
    }
    _v_207 = _o_34[0];
    _v_206 = _v_207;
    Term _v_211 = 0;
    Term _o_35[1];
    if (spin_170(e, _o_35, _v_206, _v_206 == h15 ? q15 : _v_206 == h14 ? q14 : _v_206 == h13 ? q13 : _v_206 == h11 ? q11 : _v_206 == h7 ? q7 : _v_206 == h6 ? q6 : _v_206 == h5 ? q5 : _v_206 == h4 ? q4 : _v_206 == h3 ? q3 : _v_206 == h2 ? q2 : blk_loc(e.mem, _v_206), _world_26, _world_26 == h11 ? q11 : blk_loc(e.mem, _world_26)) == 0) {
      return 0;
    }
    _v_211 = _o_35[0];
    _v_205 = _v_211;
    _v_190 = _world_15;
    _v_191 = _world_16;
    _v_192 = _world_17;
    _v_193 = _world_18;
    _v_194 = _world_19;
    _v_195 = _world_20;
    _v_196 = _world_21;
    _v_197 = _world_22;
    _v_198 = _world_23;
    _v_199 = _world_24;
    _v_200 = _world_25;
    _v_201 = _v_205;
    _v_202 = _world_27;
    _v_203 = _world_28;
    _v_204 = _world_29;
  break;
  }
  o[0] = _v_190;
  o[1] = _v_191;
  o[2] = _v_192;
  o[3] = _v_193;
  o[4] = _v_194;
  o[5] = _v_195;
  o[6] = _v_196;
  o[7] = _v_197;
  o[8] = _v_198;
  o[9] = _v_199;
  o[10] = _v_200;
  o[11] = _v_201;
  o[12] = _v_202;
  o[13] = _v_203;
  o[14] = _v_204;
  return 1;
}

INLINE Term spin_163(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  Term h18 = r18;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  u32 _result_9 = r9;
  Term _result_10 = r10;
  u32 _result_11 = r11;
  Term _result_12 = r12;
  u32 _result_13 = r13;
  Term _result_14 = r14;
  Term _result_15 = r15;
  Term _result_16 = r16;
  Term _result_17 = r17;
  Term _result_18 = r18;
  u32 _tick_0 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      u32 _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      Term _v_88 = 0;
      Term _v_89 = 0;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      Term _v_98 = 0;
      Term _v_99 = 0;
      u32 _v_100 = 0;
      u32 _v_101 = 0;
      Term _v_102 = 0;
      Term _v_103 = 0;
      Term _v_104 = 0;
      Term _v_105 = 0;
      Term _v_106 = 0;
      Term _v_107 = 0;
      u32 _v_108 = 0;
      Term _v_109 = 0;
      u32 _v_110 = 0;
      Term _v_111 = 0;
      u32 _v_112 = 0;
      Term _v_113 = 0;
      Term _v_114 = 0;
      Term _o_30[15];
      if (spin_164(e, _o_30, _result_18, _result_18 == h18 ? q18 : blk_loc(e.mem, _result_18), _result_1, _result_2, _result_3, _result_3 == h3 ? q3 : blk_loc(e.mem, _result_3), _result_4, _result_4 == h4 ? q4 : blk_loc(e.mem, _result_4), _result_5, _result_5 == h5 ? q5 : blk_loc(e.mem, _result_5), _result_6, _result_6 == h6 ? q6 : blk_loc(e.mem, _result_6), _result_7, _result_7 == h7 ? q7 : blk_loc(e.mem, _result_7), _result_8, _result_8 == h8 ? q8 : blk_loc(e.mem, _result_8), _result_9, _result_10, _result_11, _result_12, _result_12 == h12 ? q12 : blk_loc(e.mem, _result_12), _result_13, _result_14, _result_14 == h14 ? q14 : blk_loc(e.mem, _result_14), _result_15, _result_15 == h15 ? q15 : blk_loc(e.mem, _result_15), _tick_0) == 0) {
        return 0;
      }
      _v_100 = _o_30[0];
      _v_101 = _o_30[1];
      _v_102 = _o_30[2];
      _v_103 = _o_30[3];
      _v_104 = _o_30[4];
      _v_105 = _o_30[5];
      _v_106 = _o_30[6];
      _v_107 = _o_30[7];
      _v_108 = _o_30[8];
      _v_109 = _o_30[9];
      _v_110 = _o_30[10];
      _v_111 = _o_30[11];
      _v_112 = _o_30[12];
      _v_113 = _o_30[13];
      _v_114 = _o_30[14];
      _v_85 = _v_100;
      _v_86 = _v_101;
      _v_87 = _v_102;
      _v_88 = _v_103;
      _v_89 = _v_104;
      _v_90 = _v_105;
      _v_91 = _v_106;
      _v_92 = _v_107;
      _v_93 = _v_108;
      _v_94 = _v_109;
      _v_95 = _v_110;
      _v_96 = _v_111;
      _v_97 = _v_112;
      _v_98 = _v_113;
      _v_99 = _v_114;
      Term _v_170 = 0;
      Term _v_171 = 0;
      Term _o_32[1];
      if (spin_166(e, _o_32, _result_16, _result_16 == h16 ? q16 : blk_loc(e.mem, _result_16)) == 0) {
        return 0;
      }
      _v_171 = _o_32[0];
      _v_170 = _v_171;
      u32 _v_175 = 0;
      u32 _v_176 = 0;
      Term _v_177 = 0;
      Term _v_178 = 0;
      Term _v_179 = 0;
      Term _v_180 = 0;
      Term _v_181 = 0;
      Term _v_182 = 0;
      u32 _v_183 = 0;
      Term _v_184 = 0;
      u32 _v_185 = 0;
      Term _v_186 = 0;
      u32 _v_187 = 0;
      Term _v_188 = 0;
      Term _v_189 = 0;
      Term _o_36[15];
      if (spin_168(e, _o_36, _v_85, _v_86, _v_87, _v_87 == h18 ? q18 : _v_87 == h17 ? q17 : _v_87 == h16 ? q16 : _v_87 == h15 ? q15 : _v_87 == h14 ? q14 : _v_87 == h12 ? q12 : _v_87 == h8 ? q8 : _v_87 == h7 ? q7 : _v_87 == h6 ? q6 : _v_87 == h5 ? q5 : _v_87 == h4 ? q4 : _v_87 == h3 ? q3 : blk_loc(e.mem, _v_87), _v_88, _v_88 == h18 ? q18 : _v_88 == h17 ? q17 : _v_88 == h16 ? q16 : _v_88 == h15 ? q15 : _v_88 == h14 ? q14 : _v_88 == h12 ? q12 : _v_88 == h8 ? q8 : _v_88 == h7 ? q7 : _v_88 == h6 ? q6 : _v_88 == h5 ? q5 : _v_88 == h4 ? q4 : _v_88 == h3 ? q3 : blk_loc(e.mem, _v_88), _v_89, _v_89 == h18 ? q18 : _v_89 == h17 ? q17 : _v_89 == h16 ? q16 : _v_89 == h15 ? q15 : _v_89 == h14 ? q14 : _v_89 == h12 ? q12 : _v_89 == h8 ? q8 : _v_89 == h7 ? q7 : _v_89 == h6 ? q6 : _v_89 == h5 ? q5 : _v_89 == h4 ? q4 : _v_89 == h3 ? q3 : blk_loc(e.mem, _v_89), _v_90, _v_90 == h18 ? q18 : _v_90 == h17 ? q17 : _v_90 == h16 ? q16 : _v_90 == h15 ? q15 : _v_90 == h14 ? q14 : _v_90 == h12 ? q12 : _v_90 == h8 ? q8 : _v_90 == h7 ? q7 : _v_90 == h6 ? q6 : _v_90 == h5 ? q5 : _v_90 == h4 ? q4 : _v_90 == h3 ? q3 : blk_loc(e.mem, _v_90), _v_91, _v_91 == h18 ? q18 : _v_91 == h17 ? q17 : _v_91 == h16 ? q16 : _v_91 == h15 ? q15 : _v_91 == h14 ? q14 : _v_91 == h12 ? q12 : _v_91 == h8 ? q8 : _v_91 == h7 ? q7 : _v_91 == h6 ? q6 : _v_91 == h5 ? q5 : _v_91 == h4 ? q4 : _v_91 == h3 ? q3 : blk_loc(e.mem, _v_91), _v_92, _v_92 == h18 ? q18 : _v_92 == h17 ? q17 : _v_92 == h16 ? q16 : _v_92 == h15 ? q15 : _v_92 == h14 ? q14 : _v_92 == h12 ? q12 : _v_92 == h8 ? q8 : _v_92 == h7 ? q7 : _v_92 == h6 ? q6 : _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : blk_loc(e.mem, _v_92), _v_93, _v_94, _v_95, _v_96, _v_96 == h18 ? q18 : _v_96 == h17 ? q17 : _v_96 == h16 ? q16 : _v_96 == h15 ? q15 : _v_96 == h14 ? q14 : _v_96 == h12 ? q12 : _v_96 == h8 ? q8 : _v_96 == h7 ? q7 : _v_96 == h6 ? q6 : _v_96 == h5 ? q5 : _v_96 == h4 ? q4 : _v_96 == h3 ? q3 : blk_loc(e.mem, _v_96), _v_97, _v_98, _v_98 == h18 ? q18 : _v_98 == h17 ? q17 : _v_98 == h16 ? q16 : _v_98 == h15 ? q15 : _v_98 == h14 ? q14 : _v_98 == h12 ? q12 : _v_98 == h8 ? q8 : _v_98 == h7 ? q7 : _v_98 == h6 ? q6 : _v_98 == h5 ? q5 : _v_98 == h4 ? q4 : _v_98 == h3 ? q3 : blk_loc(e.mem, _v_98), _v_99, _v_99 == h18 ? q18 : _v_99 == h17 ? q17 : _v_99 == h16 ? q16 : _v_99 == h15 ? q15 : _v_99 == h14 ? q14 : _v_99 == h12 ? q12 : _v_99 == h8 ? q8 : _v_99 == h7 ? q7 : _v_99 == h6 ? q6 : _v_99 == h5 ? q5 : _v_99 == h4 ? q4 : _v_99 == h3 ? q3 : blk_loc(e.mem, _v_99), _v_170, _v_170 == h18 ? q18 : _v_170 == h17 ? q17 : _v_170 == h16 ? q16 : _v_170 == h15 ? q15 : _v_170 == h14 ? q14 : _v_170 == h12 ? q12 : _v_170 == h8 ? q8 : _v_170 == h7 ? q7 : _v_170 == h6 ? q6 : _v_170 == h5 ? q5 : _v_170 == h4 ? q4 : _v_170 == h3 ? q3 : blk_loc(e.mem, _v_170)) == 0) {
        return 0;
      }
      _v_175 = _o_36[0];
      _v_176 = _o_36[1];
      _v_177 = _o_36[2];
      _v_178 = _o_36[3];
      _v_179 = _o_36[4];
      _v_180 = _o_36[5];
      _v_181 = _o_36[6];
      _v_182 = _o_36[7];
      _v_183 = _o_36[8];
      _v_184 = _o_36[9];
      _v_185 = _o_36[10];
      _v_186 = _o_36[11];
      _v_187 = _o_36[12];
      _v_188 = _o_36[13];
      _v_189 = _o_36[14];
      _v_70 = _v_175;
      _v_71 = _v_176;
      _v_72 = _v_177;
      _v_73 = _v_178;
      _v_74 = _v_179;
      _v_75 = _v_180;
      _v_76 = _v_181;
      _v_77 = _v_182;
      _v_78 = _v_183;
      _v_79 = _v_184;
      _v_80 = _v_185;
      _v_81 = _v_186;
      _v_82 = _v_187;
      _v_83 = _v_188;
      _v_84 = _v_189;
      _v_54 = _v_70;
      _v_55 = _v_71;
      _v_56 = _v_72;
      _v_57 = _v_73;
      _v_58 = _v_74;
      _v_59 = _v_75;
      _v_60 = _v_76;
      _v_61 = _v_77;
      _v_62 = _v_78;
      _v_63 = _v_79;
      _v_64 = _v_80;
      _v_65 = _v_81;
      _v_66 = _v_82;
      _v_67 = _v_83;
      _v_68 = _v_84;
      _v_69 = _result_17;
    } else {
      _v_54 = _result_1;
      _v_55 = _result_2;
      _v_56 = _result_3;
      _v_57 = _result_4;
      _v_58 = _result_5;
      _v_59 = _result_6;
      _v_60 = _result_7;
      _v_61 = _result_8;
      _v_62 = _result_9;
      _v_63 = _result_10;
      _v_64 = _result_11;
      _v_65 = _result_12;
      _v_66 = _result_13;
      _v_67 = _result_14;
      _v_68 = _result_15;
      _v_69 = term_pak(CID_NIL, 0);
    }
  break;
  }
  o[0] = _v_54;
  o[1] = _v_55;
  o[2] = _v_56;
  o[3] = _v_57;
  o[4] = _v_58;
  o[5] = _v_59;
  o[6] = _v_60;
  o[7] = _v_61;
  o[8] = _v_62;
  o[9] = _v_63;
  o[10] = _v_64;
  o[11] = _v_65;
  o[12] = _v_66;
  o[13] = _v_67;
  o[14] = _v_68;
  o[15] = _v_69;
  return 1;
}

INLINE Term spin_171(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _scenario_1 = r0;
  WL_SPIN
    if (_scenario_1 == 4) {
      _v_20 = 0;
      _v_21 = 0;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
      _v_26 = 0;
      _v_27 = 0;
      _v_28 = 0;
      _v_29 = 0;
    } else {
      u32 _7_0 = ((_scenario_1 >> 0) & 1);
      u32 _8_0 = ((_scenario_1 >> 1) & 1);
      u32 _8_1 = ((_scenario_1 >> 2) & 1);
      u32 _8_2 = ((_scenario_1 >> 3) & 1);
      u32 _8_3 = ((_scenario_1 >> 4) & 1);
      u32 _8_4 = ((_scenario_1 >> 5) & 1);
      u32 _8_5 = ((_scenario_1 >> 6) & 1);
      u32 _8_6 = ((_scenario_1 >> 7) & 1);
      u32 _8_7 = ((_scenario_1 >> 8) & 1);
      u32 _8_8 = ((_scenario_1 >> 9) & 1);
      u32 _8_9 = ((_scenario_1 >> 10) & 1);
      u32 _8_10 = ((_scenario_1 >> 11) & 1);
      u32 _8_11 = ((_scenario_1 >> 12) & 1);
      u32 _8_12 = ((_scenario_1 >> 13) & 1);
      u32 _8_13 = ((_scenario_1 >> 14) & 1);
      u32 _8_14 = ((_scenario_1 >> 15) & 1);
      u32 _8_15 = ((_scenario_1 >> 16) & 1);
      u32 _8_16 = ((_scenario_1 >> 17) & 1);
      u32 _8_17 = ((_scenario_1 >> 18) & 1);
      u32 _8_18 = ((_scenario_1 >> 19) & 1);
      u32 _8_19 = ((_scenario_1 >> 20) & 1);
      u32 _8_20 = ((_scenario_1 >> 21) & 1);
      u32 _8_21 = ((_scenario_1 >> 22) & 1);
      u32 _8_22 = ((_scenario_1 >> 23) & 1);
      u32 _8_23 = ((_scenario_1 >> 24) & 1);
      u32 _8_24 = ((_scenario_1 >> 25) & 1);
      u32 _8_25 = ((_scenario_1 >> 26) & 1);
      u32 _8_26 = ((_scenario_1 >> 27) & 1);
      u32 _8_27 = ((_scenario_1 >> 28) & 1);
      u32 _8_28 = ((_scenario_1 >> 29) & 1);
      u32 _8_29 = ((_scenario_1 >> 30) & 1);
      u32 _8_30 = ((_scenario_1 >> 31) & 1);
      Term _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      u32 _v_33 = 0;
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _fv_0[1];
      _fv_0[0] = 10ull;
      Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_0);
      Term _at_0 = blk_loc(e.mem, _a_0);
      Term _at_1 = blk_at(_a_0, 1ull, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      blk_write(e.mem, 0, _at_0, _at_1 + 0, U32_BIN(10ull, +, 1ull));
      Term _at_2 = blk_loc(e.mem, _a_0);
      Term _at_3 = blk_at(_a_0, 2ull, 0);
      u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
      blk_write(e.mem, 0, _at_2, _at_3 + 0, U32_BIN(10ull, +, 2ull));
      Term _at_4 = blk_loc(e.mem, _a_0);
      Term _at_5 = blk_at(_a_0, 3ull, 0);
      u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
      blk_write(e.mem, 0, _at_4, _at_5 + 0, U32_BIN(10ull, +, 3ull));
      Term _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      u32 _v_42 = 0;
      u32 _v_43 = 0;
      u32 _v_44 = 0;
      u32 _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_0[9];
      if (spin_157(e, _o_0, _a_0, blk_loc(e.mem, _a_0), 9ull, 2ull) == 0) {
        return 0;
      }
      _v_39 = _o_0[0];
      _v_40 = _o_0[1];
      _v_41 = _o_0[2];
      _v_42 = _o_0[3];
      _v_43 = _o_0[4];
      _v_44 = _o_0[5];
      _v_45 = _o_0[6];
      _v_46 = _o_0[7];
      _v_47 = _o_0[8];
      _v_30 = _v_39;
      _v_31 = _v_40;
      _v_32 = _v_41;
      _v_33 = _v_42;
      _v_34 = _v_43;
      _v_35 = _v_44;
      _v_36 = _v_45;
      _v_37 = _v_46;
      _v_38 = _v_47;
      _v_20 = 1;
      _v_21 = _v_30;
      _v_22 = _v_31;
      _v_23 = _v_32;
      _v_24 = _v_33;
      _v_25 = _v_34;
      _v_26 = _v_35;
      _v_27 = _v_36;
      _v_28 = _v_37;
      _v_29 = _v_38;
    }
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  return 1;
}

INLINE Term spin_172(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_68 = 0;
  u32 _scenario_2 = r0;
  WL_SPIN
    if (_scenario_2 == 7) {
      _v_68 = 1;
    } else if ((_scenario_2 & 1) == 1) {
      u32 _8_31 = ((_scenario_2 >> 1) & 1);
      u32 _9_0 = ((_scenario_2 >> 2) & 1);
      u32 _9_1 = ((_scenario_2 >> 3) & 1);
      u32 _9_2 = ((_scenario_2 >> 4) & 1);
      u32 _9_3 = ((_scenario_2 >> 5) & 1);
      u32 _9_4 = ((_scenario_2 >> 6) & 1);
      u32 _9_5 = ((_scenario_2 >> 7) & 1);
      u32 _9_6 = ((_scenario_2 >> 8) & 1);
      u32 _9_7 = ((_scenario_2 >> 9) & 1);
      u32 _9_8 = ((_scenario_2 >> 10) & 1);
      u32 _9_9 = ((_scenario_2 >> 11) & 1);
      u32 _9_10 = ((_scenario_2 >> 12) & 1);
      u32 _9_11 = ((_scenario_2 >> 13) & 1);
      u32 _9_12 = ((_scenario_2 >> 14) & 1);
      u32 _9_13 = ((_scenario_2 >> 15) & 1);
      u32 _9_14 = ((_scenario_2 >> 16) & 1);
      u32 _9_15 = ((_scenario_2 >> 17) & 1);
      u32 _9_16 = ((_scenario_2 >> 18) & 1);
      u32 _9_17 = ((_scenario_2 >> 19) & 1);
      u32 _9_18 = ((_scenario_2 >> 20) & 1);
      u32 _9_19 = ((_scenario_2 >> 21) & 1);
      u32 _9_20 = ((_scenario_2 >> 22) & 1);
      u32 _9_21 = ((_scenario_2 >> 23) & 1);
      u32 _9_22 = ((_scenario_2 >> 24) & 1);
      u32 _9_23 = ((_scenario_2 >> 25) & 1);
      u32 _9_24 = ((_scenario_2 >> 26) & 1);
      u32 _9_25 = ((_scenario_2 >> 27) & 1);
      u32 _9_26 = ((_scenario_2 >> 28) & 1);
      u32 _9_27 = ((_scenario_2 >> 29) & 1);
      u32 _9_28 = ((_scenario_2 >> 30) & 1);
      u32 _9_29 = ((_scenario_2 >> 31) & 1);
      _v_68 = 0;
    } else if (_scenario_2 == 8) {
      _v_68 = 1;
    } else {
      u32 _70_0 = ((_scenario_2 >> 1) & 1);
      u32 _71_0 = ((_scenario_2 >> 2) & 1);
      u32 _71_1 = ((_scenario_2 >> 3) & 1);
      u32 _71_2 = ((_scenario_2 >> 4) & 1);
      u32 _71_3 = ((_scenario_2 >> 5) & 1);
      u32 _71_4 = ((_scenario_2 >> 6) & 1);
      u32 _71_5 = ((_scenario_2 >> 7) & 1);
      u32 _71_6 = ((_scenario_2 >> 8) & 1);
      u32 _71_7 = ((_scenario_2 >> 9) & 1);
      u32 _71_8 = ((_scenario_2 >> 10) & 1);
      u32 _71_9 = ((_scenario_2 >> 11) & 1);
      u32 _71_10 = ((_scenario_2 >> 12) & 1);
      u32 _71_11 = ((_scenario_2 >> 13) & 1);
      u32 _71_12 = ((_scenario_2 >> 14) & 1);
      u32 _71_13 = ((_scenario_2 >> 15) & 1);
      u32 _71_14 = ((_scenario_2 >> 16) & 1);
      u32 _71_15 = ((_scenario_2 >> 17) & 1);
      u32 _71_16 = ((_scenario_2 >> 18) & 1);
      u32 _71_17 = ((_scenario_2 >> 19) & 1);
      u32 _71_18 = ((_scenario_2 >> 20) & 1);
      u32 _71_19 = ((_scenario_2 >> 21) & 1);
      u32 _71_20 = ((_scenario_2 >> 22) & 1);
      u32 _71_21 = ((_scenario_2 >> 23) & 1);
      u32 _71_22 = ((_scenario_2 >> 24) & 1);
      u32 _71_23 = ((_scenario_2 >> 25) & 1);
      u32 _71_24 = ((_scenario_2 >> 26) & 1);
      u32 _71_25 = ((_scenario_2 >> 27) & 1);
      u32 _71_26 = ((_scenario_2 >> 28) & 1);
      u32 _71_27 = ((_scenario_2 >> 29) & 1);
      u32 _71_28 = ((_scenario_2 >> 30) & 1);
      u32 _71_29 = ((_scenario_2 >> 31) & 1);
      _v_68 = 0;
    }
  break;
  }
  o[0] = _v_68;
  return 1;
}

INLINE Term spin_173(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_71 = 0;
  u32 _scenario_3 = r0;
  WL_SPIN
    if (_scenario_3 == 7) {
      _v_71 = 1ull;
    } else {
      u32 _6_0 = ((_scenario_3 >> 0) & 1);
      u32 _7_1 = ((_scenario_3 >> 1) & 1);
      u32 _7_2 = ((_scenario_3 >> 2) & 1);
      u32 _7_3 = ((_scenario_3 >> 3) & 1);
      u32 _7_4 = ((_scenario_3 >> 4) & 1);
      u32 _7_5 = ((_scenario_3 >> 5) & 1);
      u32 _7_6 = ((_scenario_3 >> 6) & 1);
      u32 _7_7 = ((_scenario_3 >> 7) & 1);
      u32 _7_8 = ((_scenario_3 >> 8) & 1);
      u32 _7_9 = ((_scenario_3 >> 9) & 1);
      u32 _7_10 = ((_scenario_3 >> 10) & 1);
      u32 _7_11 = ((_scenario_3 >> 11) & 1);
      u32 _7_12 = ((_scenario_3 >> 12) & 1);
      u32 _7_13 = ((_scenario_3 >> 13) & 1);
      u32 _7_14 = ((_scenario_3 >> 14) & 1);
      u32 _7_15 = ((_scenario_3 >> 15) & 1);
      u32 _7_16 = ((_scenario_3 >> 16) & 1);
      u32 _7_17 = ((_scenario_3 >> 17) & 1);
      u32 _7_18 = ((_scenario_3 >> 18) & 1);
      u32 _7_19 = ((_scenario_3 >> 19) & 1);
      u32 _7_20 = ((_scenario_3 >> 20) & 1);
      u32 _7_21 = ((_scenario_3 >> 21) & 1);
      u32 _7_22 = ((_scenario_3 >> 22) & 1);
      u32 _7_23 = ((_scenario_3 >> 23) & 1);
      u32 _7_24 = ((_scenario_3 >> 24) & 1);
      u32 _7_25 = ((_scenario_3 >> 25) & 1);
      u32 _7_26 = ((_scenario_3 >> 26) & 1);
      u32 _7_27 = ((_scenario_3 >> 27) & 1);
      u32 _7_28 = ((_scenario_3 >> 28) & 1);
      u32 _7_29 = ((_scenario_3 >> 29) & 1);
      u32 _7_30 = ((_scenario_3 >> 30) & 1);
      u32 _7_31 = ((_scenario_3 >> 31) & 1);
      _v_71 = 2ull;
    }
  break;
  }
  o[0] = _v_71;
  return 1;
}

INLINE Term spin_174(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _scenario_4 = r0;
  WL_SPIN
    if (_scenario_4 == 5) {
      _v_88 = 0;
      _v_89 = 0;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
    } else {
      u32 _7_32 = ((_scenario_4 >> 0) & 1);
      u32 _8_32 = ((_scenario_4 >> 1) & 1);
      u32 _8_33 = ((_scenario_4 >> 2) & 1);
      u32 _8_34 = ((_scenario_4 >> 3) & 1);
      u32 _8_35 = ((_scenario_4 >> 4) & 1);
      u32 _8_36 = ((_scenario_4 >> 5) & 1);
      u32 _8_37 = ((_scenario_4 >> 6) & 1);
      u32 _8_38 = ((_scenario_4 >> 7) & 1);
      u32 _8_39 = ((_scenario_4 >> 8) & 1);
      u32 _8_40 = ((_scenario_4 >> 9) & 1);
      u32 _8_41 = ((_scenario_4 >> 10) & 1);
      u32 _8_42 = ((_scenario_4 >> 11) & 1);
      u32 _8_43 = ((_scenario_4 >> 12) & 1);
      u32 _8_44 = ((_scenario_4 >> 13) & 1);
      u32 _8_45 = ((_scenario_4 >> 14) & 1);
      u32 _8_46 = ((_scenario_4 >> 15) & 1);
      u32 _8_47 = ((_scenario_4 >> 16) & 1);
      u32 _8_48 = ((_scenario_4 >> 17) & 1);
      u32 _8_49 = ((_scenario_4 >> 18) & 1);
      u32 _8_50 = ((_scenario_4 >> 19) & 1);
      u32 _8_51 = ((_scenario_4 >> 20) & 1);
      u32 _8_52 = ((_scenario_4 >> 21) & 1);
      u32 _8_53 = ((_scenario_4 >> 22) & 1);
      u32 _8_54 = ((_scenario_4 >> 23) & 1);
      u32 _8_55 = ((_scenario_4 >> 24) & 1);
      u32 _8_56 = ((_scenario_4 >> 25) & 1);
      u32 _8_57 = ((_scenario_4 >> 26) & 1);
      u32 _8_58 = ((_scenario_4 >> 27) & 1);
      u32 _8_59 = ((_scenario_4 >> 28) & 1);
      u32 _8_60 = ((_scenario_4 >> 29) & 1);
      u32 _8_61 = ((_scenario_4 >> 30) & 1);
      u32 _8_62 = ((_scenario_4 >> 31) & 1);
      Term _v_96 = 0;
      u32 _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      u32 _v_101 = 0;
      u32 _v_102 = 0;
      Term _fv_16[1];
      _fv_16[0] = 100ull;
      Term _a_4 = blk_new(e, 0, 2ull, 0, 1, _fv_16);
      Term _at_24 = blk_loc(e.mem, _a_4);
      Term _at_25 = blk_at(_a_4, 1ull, 0);
      u32 _c_12 = blk_read(e.mem, 0, _at_24, _at_25 + 0);
      blk_write(e.mem, 0, _at_24, _at_25 + 0, U32_BIN(100ull, +, 1ull));
      Term _at_26 = blk_loc(e.mem, _a_4);
      Term _at_27 = blk_at(_a_4, 2ull, 0);
      u32 _c_13 = blk_read(e.mem, 0, _at_26, _at_27 + 0);
      blk_write(e.mem, 0, _at_26, _at_27 + 0, U32_BIN(100ull, +, 2ull));
      Term _at_28 = blk_loc(e.mem, _a_4);
      Term _at_29 = blk_at(_a_4, 3ull, 0);
      u32 _c_14 = blk_read(e.mem, 0, _at_28, _at_29 + 0);
      blk_write(e.mem, 0, _at_28, _at_29 + 0, U32_BIN(100ull, +, 3ull));
      Term _v_103 = 0;
      u32 _v_104 = 0;
      u32 _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      u32 _v_108 = 0;
      u32 _v_109 = 0;
      Term _o_17[7];
      if (spin_155(e, _o_17, _a_4, blk_loc(e.mem, _a_4), 4ull) == 0) {
        return 0;
      }
      _v_103 = _o_17[0];
      _v_104 = _o_17[1];
      _v_105 = _o_17[2];
      _v_106 = _o_17[3];
      _v_107 = _o_17[4];
      _v_108 = _o_17[5];
      _v_109 = _o_17[6];
      _v_96 = _v_103;
      _v_97 = _v_104;
      _v_98 = _v_105;
      _v_99 = _v_106;
      _v_100 = _v_107;
      _v_101 = _v_108;
      _v_102 = _v_109;
      _v_88 = 1;
      _v_89 = _v_96;
      _v_90 = _v_97;
      _v_91 = _v_98;
      _v_92 = _v_99;
      _v_93 = _v_100;
      _v_94 = _v_101;
      _v_95 = _v_102;
    }
  break;
  }
  o[0] = _v_88;
  o[1] = _v_89;
  o[2] = _v_90;
  o[3] = _v_91;
  o[4] = _v_92;
  o[5] = _v_93;
  o[6] = _v_94;
  o[7] = _v_95;
  return 1;
}

INLINE Term spin_175(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_114 = 0;
  u32 _v_115 = 0;
  u32 _scenario_5 = r0;
  WL_SPIN
    if (_scenario_5 == 1) {
      _v_114 = 8ull;
      _v_115 = 1ull;
    } else if ((_scenario_5 & 3) == 1) {
      u32 _9_30 = ((_scenario_5 >> 2) & 1);
      u32 _10_0 = ((_scenario_5 >> 3) & 1);
      u32 _10_1 = ((_scenario_5 >> 4) & 1);
      u32 _10_2 = ((_scenario_5 >> 5) & 1);
      u32 _10_3 = ((_scenario_5 >> 6) & 1);
      u32 _10_4 = ((_scenario_5 >> 7) & 1);
      u32 _10_5 = ((_scenario_5 >> 8) & 1);
      u32 _10_6 = ((_scenario_5 >> 9) & 1);
      u32 _10_7 = ((_scenario_5 >> 10) & 1);
      u32 _10_8 = ((_scenario_5 >> 11) & 1);
      u32 _10_9 = ((_scenario_5 >> 12) & 1);
      u32 _10_10 = ((_scenario_5 >> 13) & 1);
      u32 _10_11 = ((_scenario_5 >> 14) & 1);
      u32 _10_12 = ((_scenario_5 >> 15) & 1);
      u32 _10_13 = ((_scenario_5 >> 16) & 1);
      u32 _10_14 = ((_scenario_5 >> 17) & 1);
      u32 _10_15 = ((_scenario_5 >> 18) & 1);
      u32 _10_16 = ((_scenario_5 >> 19) & 1);
      u32 _10_17 = ((_scenario_5 >> 20) & 1);
      u32 _10_18 = ((_scenario_5 >> 21) & 1);
      u32 _10_19 = ((_scenario_5 >> 22) & 1);
      u32 _10_20 = ((_scenario_5 >> 23) & 1);
      u32 _10_21 = ((_scenario_5 >> 24) & 1);
      u32 _10_22 = ((_scenario_5 >> 25) & 1);
      u32 _10_23 = ((_scenario_5 >> 26) & 1);
      u32 _10_24 = ((_scenario_5 >> 27) & 1);
      u32 _10_25 = ((_scenario_5 >> 28) & 1);
      u32 _10_26 = ((_scenario_5 >> 29) & 1);
      u32 _10_27 = ((_scenario_5 >> 30) & 1);
      u32 _10_28 = ((_scenario_5 >> 31) & 1);
      _v_114 = 7ull;
      _v_115 = 1ull;
    } else if (_scenario_5 == 3) {
      _v_114 = 7ull;
      _v_115 = 3ull;
    } else if ((_scenario_5 & 7) == 3) {
      u32 _71_30 = ((_scenario_5 >> 3) & 1);
      u32 _72_0 = ((_scenario_5 >> 4) & 1);
      u32 _72_1 = ((_scenario_5 >> 5) & 1);
      u32 _72_2 = ((_scenario_5 >> 6) & 1);
      u32 _72_3 = ((_scenario_5 >> 7) & 1);
      u32 _72_4 = ((_scenario_5 >> 8) & 1);
      u32 _72_5 = ((_scenario_5 >> 9) & 1);
      u32 _72_6 = ((_scenario_5 >> 10) & 1);
      u32 _72_7 = ((_scenario_5 >> 11) & 1);
      u32 _72_8 = ((_scenario_5 >> 12) & 1);
      u32 _72_9 = ((_scenario_5 >> 13) & 1);
      u32 _72_10 = ((_scenario_5 >> 14) & 1);
      u32 _72_11 = ((_scenario_5 >> 15) & 1);
      u32 _72_12 = ((_scenario_5 >> 16) & 1);
      u32 _72_13 = ((_scenario_5 >> 17) & 1);
      u32 _72_14 = ((_scenario_5 >> 18) & 1);
      u32 _72_15 = ((_scenario_5 >> 19) & 1);
      u32 _72_16 = ((_scenario_5 >> 20) & 1);
      u32 _72_17 = ((_scenario_5 >> 21) & 1);
      u32 _72_18 = ((_scenario_5 >> 22) & 1);
      u32 _72_19 = ((_scenario_5 >> 23) & 1);
      u32 _72_20 = ((_scenario_5 >> 24) & 1);
      u32 _72_21 = ((_scenario_5 >> 25) & 1);
      u32 _72_22 = ((_scenario_5 >> 26) & 1);
      u32 _72_23 = ((_scenario_5 >> 27) & 1);
      u32 _72_24 = ((_scenario_5 >> 28) & 1);
      u32 _72_25 = ((_scenario_5 >> 29) & 1);
      u32 _72_26 = ((_scenario_5 >> 30) & 1);
      u32 _72_27 = ((_scenario_5 >> 31) & 1);
      _v_114 = 7ull;
      _v_115 = 1ull;
    } else if (_scenario_5 == 7) {
      _v_114 = 7ull;
      _v_115 = 2ull;
    } else if ((_scenario_5 & 7) == 7) {
      u32 _129_0 = ((_scenario_5 >> 3) & 1);
      u32 _130_0 = ((_scenario_5 >> 4) & 1);
      u32 _130_1 = ((_scenario_5 >> 5) & 1);
      u32 _130_2 = ((_scenario_5 >> 6) & 1);
      u32 _130_3 = ((_scenario_5 >> 7) & 1);
      u32 _130_4 = ((_scenario_5 >> 8) & 1);
      u32 _130_5 = ((_scenario_5 >> 9) & 1);
      u32 _130_6 = ((_scenario_5 >> 10) & 1);
      u32 _130_7 = ((_scenario_5 >> 11) & 1);
      u32 _130_8 = ((_scenario_5 >> 12) & 1);
      u32 _130_9 = ((_scenario_5 >> 13) & 1);
      u32 _130_10 = ((_scenario_5 >> 14) & 1);
      u32 _130_11 = ((_scenario_5 >> 15) & 1);
      u32 _130_12 = ((_scenario_5 >> 16) & 1);
      u32 _130_13 = ((_scenario_5 >> 17) & 1);
      u32 _130_14 = ((_scenario_5 >> 18) & 1);
      u32 _130_15 = ((_scenario_5 >> 19) & 1);
      u32 _130_16 = ((_scenario_5 >> 20) & 1);
      u32 _130_17 = ((_scenario_5 >> 21) & 1);
      u32 _130_18 = ((_scenario_5 >> 22) & 1);
      u32 _130_19 = ((_scenario_5 >> 23) & 1);
      u32 _130_20 = ((_scenario_5 >> 24) & 1);
      u32 _130_21 = ((_scenario_5 >> 25) & 1);
      u32 _130_22 = ((_scenario_5 >> 26) & 1);
      u32 _130_23 = ((_scenario_5 >> 27) & 1);
      u32 _130_24 = ((_scenario_5 >> 28) & 1);
      u32 _130_25 = ((_scenario_5 >> 29) & 1);
      u32 _130_26 = ((_scenario_5 >> 30) & 1);
      u32 _130_27 = ((_scenario_5 >> 31) & 1);
      _v_114 = 7ull;
      _v_115 = 1ull;
    } else if (_scenario_5 == 2) {
      _v_114 = 7ull;
      _v_115 = 0ull;
    } else if ((_scenario_5 & 7) == 2) {
      u32 _191_0 = ((_scenario_5 >> 3) & 1);
      u32 _192_0 = ((_scenario_5 >> 4) & 1);
      u32 _192_1 = ((_scenario_5 >> 5) & 1);
      u32 _192_2 = ((_scenario_5 >> 6) & 1);
      u32 _192_3 = ((_scenario_5 >> 7) & 1);
      u32 _192_4 = ((_scenario_5 >> 8) & 1);
      u32 _192_5 = ((_scenario_5 >> 9) & 1);
      u32 _192_6 = ((_scenario_5 >> 10) & 1);
      u32 _192_7 = ((_scenario_5 >> 11) & 1);
      u32 _192_8 = ((_scenario_5 >> 12) & 1);
      u32 _192_9 = ((_scenario_5 >> 13) & 1);
      u32 _192_10 = ((_scenario_5 >> 14) & 1);
      u32 _192_11 = ((_scenario_5 >> 15) & 1);
      u32 _192_12 = ((_scenario_5 >> 16) & 1);
      u32 _192_13 = ((_scenario_5 >> 17) & 1);
      u32 _192_14 = ((_scenario_5 >> 18) & 1);
      u32 _192_15 = ((_scenario_5 >> 19) & 1);
      u32 _192_16 = ((_scenario_5 >> 20) & 1);
      u32 _192_17 = ((_scenario_5 >> 21) & 1);
      u32 _192_18 = ((_scenario_5 >> 22) & 1);
      u32 _192_19 = ((_scenario_5 >> 23) & 1);
      u32 _192_20 = ((_scenario_5 >> 24) & 1);
      u32 _192_21 = ((_scenario_5 >> 25) & 1);
      u32 _192_22 = ((_scenario_5 >> 26) & 1);
      u32 _192_23 = ((_scenario_5 >> 27) & 1);
      u32 _192_24 = ((_scenario_5 >> 28) & 1);
      u32 _192_25 = ((_scenario_5 >> 29) & 1);
      u32 _192_26 = ((_scenario_5 >> 30) & 1);
      u32 _192_27 = ((_scenario_5 >> 31) & 1);
      _v_114 = 7ull;
      _v_115 = 1ull;
    } else if (_scenario_5 == 6) {
      _v_114 = 7ull;
      _v_115 = 2ull;
    } else if ((_scenario_5 & 7) == 6) {
      u32 _249_0 = ((_scenario_5 >> 3) & 1);
      u32 _250_0 = ((_scenario_5 >> 4) & 1);
      u32 _250_1 = ((_scenario_5 >> 5) & 1);
      u32 _250_2 = ((_scenario_5 >> 6) & 1);
      u32 _250_3 = ((_scenario_5 >> 7) & 1);
      u32 _250_4 = ((_scenario_5 >> 8) & 1);
      u32 _250_5 = ((_scenario_5 >> 9) & 1);
      u32 _250_6 = ((_scenario_5 >> 10) & 1);
      u32 _250_7 = ((_scenario_5 >> 11) & 1);
      u32 _250_8 = ((_scenario_5 >> 12) & 1);
      u32 _250_9 = ((_scenario_5 >> 13) & 1);
      u32 _250_10 = ((_scenario_5 >> 14) & 1);
      u32 _250_11 = ((_scenario_5 >> 15) & 1);
      u32 _250_12 = ((_scenario_5 >> 16) & 1);
      u32 _250_13 = ((_scenario_5 >> 17) & 1);
      u32 _250_14 = ((_scenario_5 >> 18) & 1);
      u32 _250_15 = ((_scenario_5 >> 19) & 1);
      u32 _250_16 = ((_scenario_5 >> 20) & 1);
      u32 _250_17 = ((_scenario_5 >> 21) & 1);
      u32 _250_18 = ((_scenario_5 >> 22) & 1);
      u32 _250_19 = ((_scenario_5 >> 23) & 1);
      u32 _250_20 = ((_scenario_5 >> 24) & 1);
      u32 _250_21 = ((_scenario_5 >> 25) & 1);
      u32 _250_22 = ((_scenario_5 >> 26) & 1);
      u32 _250_23 = ((_scenario_5 >> 27) & 1);
      u32 _250_24 = ((_scenario_5 >> 28) & 1);
      u32 _250_25 = ((_scenario_5 >> 29) & 1);
      u32 _250_26 = ((_scenario_5 >> 30) & 1);
      u32 _250_27 = ((_scenario_5 >> 31) & 1);
      _v_114 = 7ull;
      _v_115 = 1ull;
    } else if (_scenario_5 == 8) {
      _v_114 = 7ull;
      _v_115 = 2ull;
    } else {
      u32 _307_0 = ((_scenario_5 >> 2) & 1);
      u32 _308_0 = ((_scenario_5 >> 3) & 1);
      u32 _308_1 = ((_scenario_5 >> 4) & 1);
      u32 _308_2 = ((_scenario_5 >> 5) & 1);
      u32 _308_3 = ((_scenario_5 >> 6) & 1);
      u32 _308_4 = ((_scenario_5 >> 7) & 1);
      u32 _308_5 = ((_scenario_5 >> 8) & 1);
      u32 _308_6 = ((_scenario_5 >> 9) & 1);
      u32 _308_7 = ((_scenario_5 >> 10) & 1);
      u32 _308_8 = ((_scenario_5 >> 11) & 1);
      u32 _308_9 = ((_scenario_5 >> 12) & 1);
      u32 _308_10 = ((_scenario_5 >> 13) & 1);
      u32 _308_11 = ((_scenario_5 >> 14) & 1);
      u32 _308_12 = ((_scenario_5 >> 15) & 1);
      u32 _308_13 = ((_scenario_5 >> 16) & 1);
      u32 _308_14 = ((_scenario_5 >> 17) & 1);
      u32 _308_15 = ((_scenario_5 >> 18) & 1);
      u32 _308_16 = ((_scenario_5 >> 19) & 1);
      u32 _308_17 = ((_scenario_5 >> 20) & 1);
      u32 _308_18 = ((_scenario_5 >> 21) & 1);
      u32 _308_19 = ((_scenario_5 >> 22) & 1);
      u32 _308_20 = ((_scenario_5 >> 23) & 1);
      u32 _308_21 = ((_scenario_5 >> 24) & 1);
      u32 _308_22 = ((_scenario_5 >> 25) & 1);
      u32 _308_23 = ((_scenario_5 >> 26) & 1);
      u32 _308_24 = ((_scenario_5 >> 27) & 1);
      u32 _308_25 = ((_scenario_5 >> 28) & 1);
      u32 _308_26 = ((_scenario_5 >> 29) & 1);
      u32 _308_27 = ((_scenario_5 >> 30) & 1);
      u32 _308_28 = ((_scenario_5 >> 31) & 1);
      _v_114 = 7ull;
      _v_115 = 1ull;
    }
  break;
  }
  o[0] = _v_114;
  o[1] = _v_115;
  return 1;
}

FAR Term spin_176(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  u32 _v_71 = 0;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  Term _v_77 = 0;
  Term _v_78 = 0;
  Term _v_79 = 0;
  Term _v_80 = 0;
  u32 _scenario_1 = r0;
  WL_SPIN
    u32 _v_81 = 0;
    Term _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    Term _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    Term _o_0[10];
    if (spin_171(e, _o_0, _scenario_1) == 0) {
      return 0;
    }
    _v_91 = _o_0[0];
    _v_92 = _o_0[1];
    _v_93 = _o_0[2];
    _v_94 = _o_0[3];
    _v_95 = _o_0[4];
    _v_96 = _o_0[5];
    _v_97 = _o_0[6];
    _v_98 = _o_0[7];
    _v_99 = _o_0[8];
    _v_100 = _o_0[9];
    _v_81 = _v_91;
    _v_82 = _v_92;
    _v_83 = _v_93;
    _v_84 = _v_94;
    _v_85 = _v_95;
    _v_86 = _v_96;
    _v_87 = _v_97;
    _v_88 = _v_98;
    _v_89 = _v_99;
    _v_90 = _v_100;
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_v_81 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _v_82);
      e.mem[_nd_0 + 1] = rfc_seal(e, _v_83);
      e.mem[_nd_0 + 2] = rfc_seal(e, _v_84);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_85);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_86);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_87);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_88);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_89);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_90);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
      _o_2 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    Term _fv_0[2];
    _fv_0[0] = _o_1;
    _fv_0[1] = _o_2;
    Term _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    Term _fv_1[1];
    _fv_1[0] = 900ull;
    Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_1);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, U32_BIN(900ull, +, 1ull));
    Term _at_2 = blk_loc(e.mem, _a_0);
    Term _at_3 = blk_at(_a_0, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, U32_BIN(900ull, +, 2ull));
    Term _at_4 = blk_loc(e.mem, _a_0);
    Term _at_5 = blk_at(_a_0, 3ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, U32_BIN(900ull, +, 3ull));
    Term _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    Term _o_3[9];
    if (spin_157(e, _o_3, _a_0, blk_loc(e.mem, _a_0), 9ull, 2ull) == 0) {
      return 0;
    }
    _v_110 = _o_3[0];
    _v_111 = _o_3[1];
    _v_112 = _o_3[2];
    _v_113 = _o_3[3];
    _v_114 = _o_3[4];
    _v_115 = _o_3[5];
    _v_116 = _o_3[6];
    _v_117 = _o_3[7];
    _v_118 = _o_3[8];
    _v_101 = _v_110;
    _v_102 = _v_111;
    _v_103 = _v_112;
    _v_104 = _v_113;
    _v_105 = _v_114;
    _v_106 = _v_115;
    _v_107 = _v_116;
    _v_108 = _v_117;
    _v_109 = _v_118;
    u32 _o_4 = 0;
    Term _o_5 = 0;
    Term _t_0 = 1;
    if (_t_0 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_101);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_102);
      e.mem[_nd_3 + 2] = rfc_seal(e, _v_103);
      u64 _nd_4 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_4 + 0] = rfc_seal(e, _v_104);
      e.mem[_nd_4 + 1] = rfc_seal(e, _v_105);
      e.mem[_nd_4 + 2] = rfc_seal(e, _v_106);
      e.mem[_nd_4 + 3] = rfc_seal(e, _v_107);
      e.mem[_nd_4 + 4] = rfc_seal(e, _v_108);
      e.mem[_nd_4 + 5] = rfc_seal(e, _v_109);
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_3));
      e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_4));
      _o_5 = term_ctr(CID_CACHE_CACHE, _nd_5);
    }
    Term _fv_2[2];
    _fv_2[0] = _o_4;
    _fv_2[1] = _o_5;
    Term _fv_3[1];
    _fv_3[0] = 110ull;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_3);
    Term _at_6 = blk_loc(e.mem, _a_1);
    Term _at_7 = blk_at(_a_1, 1ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, U32_BIN(110ull, +, 1ull));
    Term _at_8 = blk_loc(e.mem, _a_1);
    Term _at_9 = blk_at(_a_1, 2ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, U32_BIN(110ull, +, 2ull));
    Term _at_10 = blk_loc(e.mem, _a_1);
    Term _at_11 = blk_at(_a_1, 3ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, U32_BIN(110ull, +, 3ull));
    u32 _o_6 = 0;
    Term _o_7 = 0;
    Term _t_1 = 1;
    if (_t_1 == 0) {
      _o_6 = 0;
    } else {
      _o_6 = 1;
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, _a_1);
      e.mem[_nd_6 + 1] = rfc_seal(e, 3ull);
      _o_7 = term_ctr(CID_TYPES_ARMOR, _nd_6);
    }
    Term _fv_4[2];
    _fv_4[0] = _o_6;
    _fv_4[1] = _o_7;
    Term _fv_5[1];
    _fv_5[0] = 190ull;
    Term _a_2 = blk_new(e, 0, 2ull, 0, 1, _fv_5);
    Term _at_12 = blk_loc(e.mem, _a_2);
    Term _at_13 = blk_at(_a_2, 1ull, 0);
    u32 _c_6 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, U32_BIN(190ull, +, 1ull));
    Term _at_14 = blk_loc(e.mem, _a_2);
    Term _at_15 = blk_at(_a_2, 2ull, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, U32_BIN(190ull, +, 2ull));
    Term _at_16 = blk_loc(e.mem, _a_2);
    Term _at_17 = blk_at(_a_2, 3ull, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_16, _at_17 + 0);
    blk_write(e.mem, 0, _at_16, _at_17 + 0, U32_BIN(190ull, +, 3ull));
    u32 _o_8 = 0;
    Term _o_9 = 0;
    Term _t_2 = 1;
    if (_t_2 == 0) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, _a_2);
      e.mem[_nd_7 + 1] = rfc_seal(e, 3ull);
      _o_9 = term_ctr(CID_TYPES_ARMOR, _nd_7);
    }
    Term _fv_6[2];
    _fv_6[0] = _o_8;
    _fv_6[1] = _o_9;
    Term _fv_7[1];
    _fv_7[0] = 1;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    Term _o_10[1];
    if (spin_172(e, _o_10, _scenario_1) == 0) {
      return 0;
    }
    _v_120 = _o_10[0];
    _v_119 = _v_120;
    Term _fv_8[1];
    _fv_8[0] = _v_119;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    Term _t_3 = 1;
    if (_t_3 == 0) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
      _o_12 = term_pak(CID_TYPES_TRACKED, 8ull);
    }
    Term _fv_9[2];
    _fv_9[0] = _o_11;
    _fv_9[1] = _o_12;
    u32 _o_13 = 0;
    Term _o_14 = 0;
    Term _t_4 = 0;
    if (_t_4 == 0) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      _o_14 = term_pak(CID_TYPES_TRACKED, 0);
    }
    Term _fv_10[2];
    _fv_10[0] = _o_13;
    _fv_10[1] = _o_14;
    Term _fv_11[1];
    _fv_11[0] = 3ull;
    Term _fv_12[1];
    _fv_12[0] = 5ull;
    Term _fv_13[1];
    _fv_13[0] = 4ull;
    Term _fv_14[1];
    _fv_14[0] = 6ull;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    Term _o_15[1];
    if (spin_173(e, _o_15, _scenario_1) == 0) {
      return 0;
    }
    _v_122 = _o_15[0];
    _v_121 = _v_122;
    u32 _v_123 = 0;
    Term _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    Term _o_16[8];
    if (spin_174(e, _o_16, _scenario_1) == 0) {
      return 0;
    }
    _v_131 = _o_16[0];
    _v_132 = _o_16[1];
    _v_133 = _o_16[2];
    _v_134 = _o_16[3];
    _v_135 = _o_16[4];
    _v_136 = _o_16[5];
    _v_137 = _o_16[6];
    _v_138 = _o_16[7];
    _v_123 = _v_131;
    _v_124 = _v_132;
    _v_125 = _v_133;
    _v_126 = _v_134;
    _v_127 = _v_135;
    _v_128 = _v_136;
    _v_129 = _v_137;
    _v_130 = _v_138;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    Term _o_17[2];
    if (spin_175(e, _o_17, _scenario_1) == 0) {
      return 0;
    }
    _v_141 = _o_17[0];
    _v_142 = _o_17[1];
    _v_139 = _v_141;
    _v_140 = _v_142;
    _v_54 = 7ull;
    _v_55 = 3ull;
    _v_56 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_0), blk_new(e, 1, 0, 1, 2, _fv_2));
    _v_57 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_4), blk_new(e, 1, 0, 1, 2, _fv_6));
    _v_58 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_7), blk_new(e, 0, 0, 0, 1, _fv_8));
    _v_59 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_9), blk_new(e, 1, 0, 1, 2, _fv_10));
    _v_60 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_11), blk_new(e, 0, 0, 0, 1, _fv_12));
    _v_61 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_13), blk_new(e, 0, 0, 0, 1, _fv_14));
    _v_62 = 2ull;
    _v_63 = 1ull;
    _v_64 = _v_121;
    _v_65 = term_pak(CID_NIL, 0);
    _v_66 = _v_123;
    _v_67 = _v_124;
    _v_68 = _v_125;
    _v_69 = _v_126;
    _v_70 = _v_127;
    _v_71 = _v_128;
    _v_72 = _v_129;
    _v_73 = _v_130;
    _v_74 = 0;
    _v_75 = _v_139;
    _v_76 = _v_140;
    _v_77 = term_ctr(CID_CON, STAT_OFF + 658);
    _v_78 = term_ctr(CID_CON, STAT_OFF + 662);
    _v_79 = term_ctr(CID_CON, STAT_OFF + 666);
    _v_80 = term_ctr(CID_CON, STAT_OFF + 670);
  break;
  }
  o[0] = _v_54;
  o[1] = _v_55;
  o[2] = _v_56;
  o[3] = _v_57;
  o[4] = _v_58;
  o[5] = _v_59;
  o[6] = _v_60;
  o[7] = _v_61;
  o[8] = _v_62;
  o[9] = _v_63;
  o[10] = _v_64;
  o[11] = _v_65;
  o[12] = _v_66;
  o[13] = _v_67;
  o[14] = _v_68;
  o[15] = _v_69;
  o[16] = _v_70;
  o[17] = _v_71;
  o[18] = _v_72;
  o[19] = _v_73;
  o[20] = _v_74;
  o[21] = _v_75;
  o[22] = _v_76;
  o[23] = _v_77;
  o[24] = _v_78;
  o[25] = _v_79;
  o[26] = _v_80;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROW_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    u32 _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    u32 _owner_7 = r7;
    u32 _owner_8 = r8;
    u32 _owner_9 = r9;
    u32 _owner_10 = r10;
    u32 _owner_11 = r11;
    Term _owner_12 = r12;
    u32 _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    u32 _owner_17 = r17;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _owner_0;
      STK(1) = _owner_11;
      STK(2) = _owner_12;
      STK(3) = _owner_13;
      STK(4) = _owner_14;
      STK(5) = _owner_15;
      STK(6) = _owner_16;
      STK(7) = _owner_17;
      STK(8) = FID_OBSERVATIONS_ROW_0_K33;
      WL_PUSHN(9);
    } else {
      u64 _t_0 = task_node(e, FID_OBSERVATIONS_ROW_0_K33, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_0;
      e.mem[_t_0 + 1] = _owner_11;
      e.mem[_t_0 + 2] = _owner_12;
      e.mem[_t_0 + 3] = _owner_13;
      e.mem[_t_0 + 4] = _owner_14;
      e.mem[_t_0 + 5] = _owner_15;
      e.mem[_t_0 + 6] = _owner_16;
      e.mem[_t_0 + 7] = _owner_17;
      WL_CONT = term_tsk(FID_OBSERVATIONS_ROW_0_K33, _t_0);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_MAYBE_GET_2)) {
      u64 _t_1 = task_node(e, FID_OBSERVATIONS_MAYBE_GET_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_1;
      e.mem[_t_1 + 1] = _owner_2;
      e.mem[_t_1 + 2] = _owner_3;
      e.mem[_t_1 + 3] = _owner_4;
      e.mem[_t_1 + 4] = _owner_5;
      e.mem[_t_1 + 5] = _owner_6;
      e.mem[_t_1 + 6] = _owner_7;
      e.mem[_t_1 + 7] = _owner_8;
      e.mem[_t_1 + 8] = _owner_9;
      e.mem[_t_1 + 9] = _owner_10;
      return term_tsk(FID_OBSERVATIONS_MAYBE_GET_2, _t_1);
    }
    r0 = _owner_1;
    r1 = _owner_2;
    r2 = _owner_3;
    r3 = _owner_4;
    r4 = _owner_5;
    r5 = _owner_6;
    r6 = _owner_7;
    r7 = _owner_8;
    r8 = _owner_9;
    r9 = _owner_10;
    WL_JMP(FID_OBSERVATIONS_MAYBE_GET_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROW_0_K33)
  {
    WL_POPN(8);
    u32 _owner_18 = STK(0);
    u32 _owner_19 = STK(1);
    Term _owner_20 = STK(2);
    u32 _owner_21 = STK(3);
    u32 _owner_22 = STK(4);
    u32 _owner_23 = STK(5);
    u32 _owner_24 = STK(6);
    u32 _owner_25 = STK(7);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_42[36];
    if (spin_33(e, _o_42, _owner_18, _owner_19, _owner_20, blk_loc(e.mem, _owner_20), _owner_21, _owner_22, _owner_23, _owner_24, _owner_25, _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, _h_4, _h_5, _h_6, _h_7, _h_8, _h_9, _h_10, _h_11, _h_12, _h_13, _h_14, _h_15, _h_16) == 0) {
      return 0;
    }
    _v_0 = _o_42[0];
    _v_1 = _o_42[1];
    _v_2 = _o_42[2];
    _v_3 = _o_42[3];
    _v_4 = _o_42[4];
    _v_5 = _o_42[5];
    _v_6 = _o_42[6];
    _v_7 = _o_42[7];
    _v_8 = _o_42[8];
    _v_9 = _o_42[9];
    _v_10 = _o_42[10];
    _v_11 = _o_42[11];
    _v_12 = _o_42[12];
    _v_13 = _o_42[13];
    _v_14 = _o_42[14];
    _v_15 = _o_42[15];
    _v_16 = _o_42[16];
    _v_17 = _o_42[17];
    _v_18 = _o_42[18];
    _v_19 = _o_42[19];
    _v_20 = _o_42[20];
    _v_21 = _o_42[21];
    _v_22 = _o_42[22];
    _v_23 = _o_42[23];
    _v_24 = _o_42[24];
    _v_25 = _o_42[25];
    _v_26 = _o_42[26];
    _v_27 = _o_42[27];
    _v_28 = _o_42[28];
    _v_29 = _o_42[29];
    _v_30 = _o_42[30];
    _v_31 = _o_42[31];
    _v_32 = _o_42[32];
    _v_33 = _o_42[33];
    _v_34 = _o_42[34];
    _v_35 = _o_42[35];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    r24 = _v_24;
    r25 = _v_25;
    r26 = _v_26;
    r27 = _v_27;
    r28 = _v_28;
    r29 = _v_29;
    r30 = _v_30;
    r31 = _v_31;
    r32 = _v_32;
    r33 = _v_33;
    r34 = _v_34;
    r35 = _v_35;
    WL_RETN(36);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_TRACKED)
  {
    u32 _value_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_TRACKED_K58;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_TRACKED_K58, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_TRACKED_K58, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_TRACKED_K58)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 98));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_VITALS)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_4;
      STK(1) = _value_5;
      STK(2) = FID_HOST_RENDER_RENDER_VITALS_K60;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_VITALS_K60, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      e.mem[_t_0 + 1] = _value_5;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_VITALS_K60, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_VITALS_K60)
  {
    WL_POPN(2);
    u32 _value_6 = STK(0);
    u32 _value_7 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_7;
      STK(1) = _h_0;
      STK(2) = FID_HOST_RENDER_RENDER_VITALS_K61;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_VITALS_K61, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_7;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_VITALS_K61, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_6;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_VITALS_K61)
  {
    WL_POPN(2);
    u32 _value_8 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_HOST_RENDER_RENDER_VITALS_K62;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_VITALS_K62, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_VITALS_K62, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_8;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _value_8;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_VITALS_K62)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_3);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 140));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_5);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 128));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_4);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 112));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_5);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_BUNDLE_1)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    u32 _value_6 = r6;
    u32 _value_7 = r7;
    u32 _value_8 = r8;
    u32 _value_9 = r9;
    u32 _value_10 = r10;
    u32 _value_11 = r11;
    u32 _value_12 = r12;
    u32 _value_13 = r13;
    u32 _value_14 = r14;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _value_7;
      STK(1) = _value_8;
      STK(2) = _value_9;
      STK(3) = _value_10;
      STK(4) = _value_11;
      STK(5) = _value_12;
      STK(6) = _value_13;
      STK(7) = _value_14;
      STK(8) = FID_HOST_RENDER_RENDER_BUNDLE_1_K64;
      WL_PUSHN(9);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_BUNDLE_1_K64, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_7;
      e.mem[_t_0 + 1] = _value_8;
      e.mem[_t_0 + 2] = _value_9;
      e.mem[_t_0 + 3] = _value_10;
      e.mem[_t_0 + 4] = _value_11;
      e.mem[_t_0 + 5] = _value_12;
      e.mem[_t_0 + 6] = _value_13;
      e.mem[_t_0 + 7] = _value_14;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_BUNDLE_1_K64, _t_0);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_6)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_6, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      e.mem[_t_1 + 4] = _value_4;
      e.mem[_t_1 + 5] = _value_5;
      e.mem[_t_1 + 6] = _value_6;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_6, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    r4 = _value_4;
    r5 = _value_5;
    r6 = _value_6;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_BUNDLE_1_K64)
  {
    WL_POPN(8);
    u32 _value_15 = STK(0);
    u32 _value_16 = STK(1);
    u32 _value_17 = STK(2);
    u32 _value_18 = STK(3);
    u32 _value_19 = STK(4);
    u32 _value_20 = STK(5);
    u32 _value_21 = STK(6);
    u32 _value_22 = STK(7);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_21;
      STK(1) = _value_22;
      STK(2) = _h_0;
      STK(3) = FID_HOST_RENDER_RENDER_BUNDLE_1_K65;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_BUNDLE_1_K65, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_21;
      e.mem[_t_2 + 1] = _value_22;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_BUNDLE_1_K65, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_4)) {
      u64 _t_3 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_4, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_15;
      e.mem[_t_3 + 1] = _value_16;
      e.mem[_t_3 + 2] = _value_17;
      e.mem[_t_3 + 3] = _value_18;
      e.mem[_t_3 + 4] = _value_19;
      e.mem[_t_3 + 5] = _value_20;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_4, _t_3);
    }
    r0 = _value_15;
    r1 = _value_16;
    r2 = _value_17;
    r3 = _value_18;
    r4 = _value_19;
    r5 = _value_20;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_BUNDLE_1_K65)
  {
    WL_POPN(3);
    u32 _value_23 = STK(0);
    u32 _value_24 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_HOST_RENDER_RENDER_BUNDLE_1_K66;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_BUNDLE_1_K66, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_BUNDLE_1_K66, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_5)) {
      u64 _t_5 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_5, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_23;
      e.mem[_t_5 + 1] = _value_24;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_5, _t_5);
    }
    r0 = _value_23;
    r1 = _value_24;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_BUNDLE_1_K66)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_3);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 174));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_5);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 162));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_4);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 152));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_5);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_5)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 182);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_TRACKED)) {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_TRACKED, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _value_1;
        return term_tsk(FID_HOST_RENDER_RENDER_TRACKED, _t_0);
      }
      r0 = _value_1;
      WL_JMP(FID_HOST_RENDER_RENDER_TRACKED);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_4)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 182);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _value_5;
        STK(1) = FID_HOST_RENDER_RENDER_OPTIONAL_4_K69;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_4_K69, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _value_5;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_4_K69, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
        u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_1;
        e.mem[_t_1 + 1] = _value_2;
        e.mem[_t_1 + 2] = _value_3;
        e.mem[_t_1 + 3] = _value_4;
        return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
      }
      r0 = _value_1;
      r1 = _value_2;
      r2 = _value_3;
      r3 = _value_4;
      WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_4_K69)
  {
    WL_POPN(1);
    u32 _value_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_OPTIONAL_4_K70;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_4_K70, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_4_K70, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_6;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_4_K70)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 72));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 58));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_3);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_6)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    u32 _value_6 = r6;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 182);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_VITALS)) {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_VITALS, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _value_1;
        e.mem[_t_0 + 1] = _value_2;
        e.mem[_t_0 + 2] = _value_3;
        e.mem[_t_0 + 3] = _value_4;
        e.mem[_t_0 + 4] = _value_5;
        e.mem[_t_0 + 5] = _value_6;
        return term_tsk(FID_HOST_RENDER_RENDER_VITALS, _t_0);
      }
      r0 = _value_1;
      r1 = _value_2;
      r2 = _value_3;
      r3 = _value_4;
      r4 = _value_5;
      r5 = _value_6;
      WL_JMP(FID_HOST_RENDER_RENDER_VITALS);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROWS_ADVANCE_0)
  {
    u32 _id_0 = r0;
    Term _state_0 = r1;
    Term _state_1 = r2;
    Term _state_2 = r3;
    Term _state_3 = r4;
    Term _state_4 = r5;
    Term _state_5 = r6;
    u32 _state_6 = r7;
    Term _state_7 = r8;
    u32 _state_8 = r9;
    Term _state_9 = r10;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_12[19];
    if (spin_62(e, _o_12, _state_0, blk_loc(e.mem, _state_0), _state_1, blk_loc(e.mem, _state_1), _state_2, blk_loc(e.mem, _state_2), _state_3, blk_loc(e.mem, _state_3), _state_4, blk_loc(e.mem, _state_4), _state_5, blk_loc(e.mem, _state_5), _state_6, _state_7, _state_8, _id_0) == 0) {
      return 0;
    }
    _v_19 = _o_12[0];
    _v_20 = _o_12[1];
    _v_21 = _o_12[2];
    _v_22 = _o_12[3];
    _v_23 = _o_12[4];
    _v_24 = _o_12[5];
    _v_25 = _o_12[6];
    _v_26 = _o_12[7];
    _v_27 = _o_12[8];
    _v_28 = _o_12[9];
    _v_29 = _o_12[10];
    _v_30 = _o_12[11];
    _v_31 = _o_12[12];
    _v_32 = _o_12[13];
    _v_33 = _o_12[14];
    _v_34 = _o_12[15];
    _v_35 = _o_12[16];
    _v_36 = _o_12[17];
    _v_37 = _o_12[18];
    _v_0 = _v_19;
    _v_1 = _v_20;
    _v_2 = _v_21;
    _v_3 = _v_22;
    _v_4 = _v_23;
    _v_5 = _v_24;
    _v_6 = _v_25;
    _v_7 = _v_26;
    _v_8 = _v_27;
    _v_9 = _v_28;
    _v_10 = _v_29;
    _v_11 = _v_30;
    _v_12 = _v_31;
    _v_13 = _v_32;
    _v_14 = _v_33;
    _v_15 = _v_34;
    _v_16 = _v_35;
    _v_17 = _v_36;
    _v_18 = _v_37;
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    Term _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    u32 _o_25 = 0;
    Term _o_26 = 0;
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    if (_v_9 == 0) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      u32 _o_32 = 0;
      Term _o_33 = 0;
      u32 _o_34 = 0;
      u32 _o_35 = 0;
      u32 _o_36 = 0;
      u32 _o_37 = 0;
      u32 _o_38 = 0;
      u32 _o_39 = 0;
      u32 _o_40 = 0;
      u32 _o_41 = 0;
      if (_v_11 == 0) {
        _o_32 = 0;
      } else {
        _o_32 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _v_12, 2, _fb_0);
        Term _f_4 = _fb_0[0];
        Term _f_5 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_4, 3, _fb_1);
        Term _f_6 = _fb_1[0];
        u32 _f_7 = _fb_1[1];
        u32 _f_8 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        Term _fb_2[6];
        u64 _sp_2 = ctr_take(e, _f_5, 6, _fb_2);
        u32 _f_9 = _fb_2[0];
        u32 _f_10 = _fb_2[1];
        u32 _f_11 = _fb_2[2];
        u32 _f_12 = _fb_2[3];
        u32 _f_13 = _fb_2[4];
        u32 _f_14 = _fb_2[5];
        spare_free(e, cls_fit(6), _sp_2);
        _o_33 = _f_6;
        _o_34 = _f_7;
        _o_35 = _f_8;
        _o_36 = _f_9;
        _o_37 = _f_10;
        _o_38 = _f_11;
        _o_39 = _f_12;
        _o_40 = _f_13;
        _o_41 = _f_14;
      }
      u32 _o_42 = 0;
      Term _o_43 = 0;
      u32 _o_44 = 0;
      if (_v_13 == 0) {
        _o_42 = 0;
      } else {
        _o_42 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _v_14, 2, _fb_3);
        Term _f_15 = _fb_3[0];
        u32 _f_16 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_43 = _f_15;
        _o_44 = _f_16;
      }
      u32 _o_45 = 0;
      u32 _o_46 = 0;
      if (_v_15 == 0) {
        _o_45 = 0;
      } else {
        _o_45 = 1;
        _o_46 = term_loc(_v_16);
      }
      _o_14 = _v_10;
      _o_15 = _o_32;
      _o_16 = _o_33;
      _o_17 = _o_34;
      _o_18 = _o_35;
      _o_19 = _o_36;
      _o_20 = _o_37;
      _o_21 = _o_38;
      _o_22 = _o_39;
      _o_23 = _o_40;
      _o_24 = _o_41;
      _o_25 = _o_42;
      _o_26 = _o_43;
      _o_27 = _o_44;
      _o_28 = _o_45;
      _o_29 = _o_46;
      _o_30 = _v_17;
      _o_31 = _v_18;
    }
    if (_o_13 == 0) {
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _state_9;
      WL_RETN(10);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _state_9;
        STK(1) = _v_0;
        STK(2) = _v_1;
        STK(3) = _v_2;
        STK(4) = _v_3;
        STK(5) = _v_4;
        STK(6) = _v_5;
        STK(7) = _v_6;
        STK(8) = _v_7;
        STK(9) = _v_8;
        STK(10) = FID_OBSERVATIONS_ROWS_ADVANCE_0_K89;
        WL_PUSHN(11);
      } else {
        u64 _t_0 = task_node(e, FID_OBSERVATIONS_ROWS_ADVANCE_0_K89, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _state_9;
        e.mem[_t_0 + 1] = _v_0;
        e.mem[_t_0 + 2] = _v_1;
        e.mem[_t_0 + 3] = _v_2;
        e.mem[_t_0 + 4] = _v_3;
        e.mem[_t_0 + 5] = _v_4;
        e.mem[_t_0 + 6] = _v_5;
        e.mem[_t_0 + 7] = _v_6;
        e.mem[_t_0 + 8] = _v_7;
        e.mem[_t_0 + 9] = _v_8;
        WL_CONT = term_tsk(FID_OBSERVATIONS_ROWS_ADVANCE_0_K89, _t_0);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_ROW_0)) {
        u64 _t_1 = task_node(e, FID_OBSERVATIONS_ROW_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_14;
        e.mem[_t_1 + 1] = _o_15;
        e.mem[_t_1 + 2] = _o_16;
        e.mem[_t_1 + 3] = _o_17;
        e.mem[_t_1 + 4] = _o_18;
        e.mem[_t_1 + 5] = _o_19;
        e.mem[_t_1 + 6] = _o_20;
        e.mem[_t_1 + 7] = _o_21;
        e.mem[_t_1 + 8] = _o_22;
        e.mem[_t_1 + 9] = _o_23;
        e.mem[_t_1 + 10] = _o_24;
        e.mem[_t_1 + 11] = _o_25;
        e.mem[_t_1 + 12] = _o_26;
        e.mem[_t_1 + 13] = _o_27;
        e.mem[_t_1 + 14] = _o_28;
        e.mem[_t_1 + 15] = _o_29;
        e.mem[_t_1 + 16] = _o_30;
        e.mem[_t_1 + 17] = _o_31;
        return term_tsk(FID_OBSERVATIONS_ROW_0, _t_1);
      }
      r0 = _o_14;
      r1 = _o_15;
      r2 = _o_16;
      r3 = _o_17;
      r4 = _o_18;
      r5 = _o_19;
      r6 = _o_20;
      r7 = _o_21;
      r8 = _o_22;
      r9 = _o_23;
      r10 = _o_24;
      r11 = _o_25;
      r12 = _o_26;
      r13 = _o_27;
      r14 = _o_28;
      r15 = _o_29;
      r16 = _o_30;
      r17 = _o_31;
      WL_JMP(FID_OBSERVATIONS_ROW_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROWS_ADVANCE_0_K89)
  {
    WL_POPN(10);
    Term _state_10 = STK(0);
    Term _v_350 = STK(1);
    Term _v_351 = STK(2);
    Term _v_352 = STK(3);
    Term _v_353 = STK(4);
    Term _v_354 = STK(5);
    Term _v_355 = STK(6);
    u32 _v_356 = STK(7);
    Term _v_357 = STK(8);
    u32 _v_358 = STK(9);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    u32 _h_27 = r27;
    u32 _h_28 = r28;
    u32 _h_29 = r29;
    u32 _h_30 = r30;
    u32 _h_31 = r31;
    u32 _h_32 = r32;
    u32 _h_33 = r33;
    u32 _h_34 = r34;
    u32 _h_35 = r35;
    WL_OPEN
    u32 _o_47 = 0;
    Term _o_48 = 0;
    if (_h_1 == 0) {
      _o_47 = 0;
    } else {
      _o_47 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_3);
      e.mem[_nd_0 + 2] = rfc_seal(e, _h_4);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_5);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_6);
      e.mem[_nd_1 + 2] = rfc_seal(e, _h_7);
      e.mem[_nd_1 + 3] = rfc_seal(e, _h_8);
      e.mem[_nd_1 + 4] = rfc_seal(e, _h_9);
      e.mem[_nd_1 + 5] = rfc_seal(e, _h_10);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
      _o_48 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    u32 _o_49 = 0;
    Term _o_50 = 0;
    if (_h_11 == 0) {
      _o_49 = 0;
    } else {
      _o_49 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _h_12);
      e.mem[_nd_3 + 1] = rfc_seal(e, _h_13);
      _o_50 = term_ctr(CID_TYPES_ARMOR, _nd_3);
    }
    u32 _o_51 = 0;
    Term _o_52 = 0;
    if (_h_14 == 0) {
      _o_51 = 0;
    } else {
      _o_51 = 1;
      _o_52 = term_pak(CID_TYPES_TRACKED, _h_15);
    }
    u32 _o_53 = 0;
    Term _o_54 = 0;
    if (_h_19 == 0) {
      _o_53 = 0;
    } else {
      _o_53 = 1;
      u64 _nd_4 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_4 + 0] = rfc_seal(e, _h_20);
      e.mem[_nd_4 + 1] = rfc_seal(e, _h_21);
      e.mem[_nd_4 + 2] = rfc_seal(e, _h_22);
      e.mem[_nd_4 + 3] = rfc_seal(e, _h_23);
      e.mem[_nd_4 + 4] = rfc_seal(e, _h_24);
      e.mem[_nd_4 + 5] = rfc_seal(e, _h_25);
      _o_54 = term_ctr(CID_TYPES_VITALSVIEW, _nd_4);
    }
    u32 _o_55 = 0;
    Term _o_56 = 0;
    if (_h_26 == 0) {
      _o_55 = 0;
    } else {
      _o_55 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_5 + 0] = rfc_seal(e, _h_27);
      e.mem[_nd_5 + 1] = rfc_seal(e, _h_28);
      e.mem[_nd_5 + 2] = rfc_seal(e, _h_29);
      e.mem[_nd_5 + 3] = rfc_seal(e, _h_30);
      e.mem[_nd_5 + 4] = rfc_seal(e, _h_31);
      _o_56 = term_ctr(CID_TYPES_ARMORVIEW, _nd_5);
    }
    u32 _o_57 = 0;
    Term _o_58 = 0;
    if (_h_32 == 0) {
      _o_57 = 0;
    } else {
      _o_57 = 1;
      _o_58 = term_pak(CID_TYPES_TRACKED, _h_33);
    }
    Term _v_359 = 0;
    Term _v_360 = 0;
    Term _v_361 = 0;
    Term _v_362 = 0;
    Term _v_363 = 0;
    Term _v_364 = 0;
    u32 _v_365 = 0;
    Term _v_366 = 0;
    u32 _v_367 = 0;
    Term _v_368 = 0;
    Term _o_59[10];
    if (spin_45(e, _o_59, _v_350, blk_loc(e.mem, _v_350), _v_351, blk_loc(e.mem, _v_351), _v_352, blk_loc(e.mem, _v_352), _v_353, blk_loc(e.mem, _v_353), _v_354, blk_loc(e.mem, _v_354), _v_355, blk_loc(e.mem, _v_355), _v_356, _v_357, _v_358, _state_10, blk_loc(e.mem, _state_10), _h_0, _o_47, _o_48, blk_loc(e.mem, _o_48), _o_49, _o_50, blk_loc(e.mem, _o_50), _o_51, _o_52, blk_loc(e.mem, _o_52), _h_16, _h_17, _h_18, _o_53, _o_54, blk_loc(e.mem, _o_54), _o_55, _o_56, blk_loc(e.mem, _o_56), _o_57, _o_58, blk_loc(e.mem, _o_58), _h_34, _h_35) == 0) {
      return 0;
    }
    _v_359 = _o_59[0];
    _v_360 = _o_59[1];
    _v_361 = _o_59[2];
    _v_362 = _o_59[3];
    _v_363 = _o_59[4];
    _v_364 = _o_59[5];
    _v_365 = _o_59[6];
    _v_366 = _o_59[7];
    _v_367 = _o_59[8];
    _v_368 = _o_59[9];
    r0 = _v_359;
    r1 = _v_360;
    r2 = _v_361;
    r3 = _v_362;
    r4 = _v_363;
    r5 = _v_364;
    r6 = _v_365;
    r7 = _v_366;
    r8 = _v_367;
    r9 = _v_368;
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET)
  {
    Term _owner_0 = r0;
    u32 _owner_1 = r1;
    u32 _owner_2 = r2;
    u32 _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _owner_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _owner_1);
    u64 _nd_4 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_4 + 0] = rfc_seal(e, _owner_2);
    e.mem[_nd_4 + 1] = rfc_seal(e, _owner_3);
    e.mem[_nd_4 + 2] = rfc_seal(e, _owner_4);
    e.mem[_nd_4 + 3] = rfc_seal(e, _owner_5);
    e.mem[_nd_4 + 4] = rfc_seal(e, _owner_6);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_K93;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_K93, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_K93, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ORIGINAL_RAW_OBSERVER_OBSERVE)) {
      u64 _t_1 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_clo(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_C92, 0);
      e.mem[_t_1 + 1] = term_ctr(CID_TYPES_HEALTHLEDGER, _nd_3);
      e.mem[_t_1 + 2] = term_ctr(CID_TYPES_LEDGERVIEW, _nd_4);
      return term_tsk(FID_ORIGINAL_RAW_OBSERVER_OBSERVE, _t_1);
    }
    r0 = term_clo(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_C92, 0);
    r1 = term_ctr(CID_TYPES_HEALTHLEDGER, _nd_3);
    r2 = term_ctr(CID_TYPES_LEDGERVIEW, _nd_4);
    WL_JMP(FID_ORIGINAL_RAW_OBSERVER_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_C92)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _o_2[7];
    if (spin_75(e, _o_2, _f_0, blk_loc(e.mem, _f_0), _f_1) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_1);
    u64 _nd_1 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_2);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_3);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_4);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_5);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_6);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET_K93)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    WL_OPEN
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _r_0, 2, _fb_1);
    Term _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    Term _fb_2[5];
    u64 _sp_2 = ctr_take(e, _r_1, 5, _fb_2);
    u32 _f_4 = _fb_2[0];
    u32 _f_5 = _fb_2[1];
    u32 _f_6 = _fb_2[2];
    u32 _f_7 = _fb_2[3];
    u32 _f_8 = _fb_2[4];
    spare_free(e, cls_fit(5), _sp_2);
    Term _fb_3[5];
    u64 _sp_3 = ctr_take(e, _r_2, 5, _fb_3);
    u32 _f_9 = _fb_3[0];
    u32 _f_10 = _fb_3[1];
    u32 _f_11 = _fb_3[2];
    u32 _f_12 = _fb_3[3];
    u32 _f_13 = _fb_3[4];
    spare_free(e, cls_fit(5), _sp_3);
    r0 = _f_2;
    r1 = _f_3;
    r2 = _f_4;
    r3 = _f_5;
    r4 = _f_6;
    r5 = _f_7;
    r6 = _f_8;
    r7 = _f_9;
    r8 = _f_10;
    r9 = _f_11;
    r10 = _f_12;
    r11 = _f_13;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = _value_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K95;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K95, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      e.mem[_t_0 + 2] = _value_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K95, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K95)
  {
    WL_POPN(3);
    u32 _value_4 = STK(0);
    u32 _value_5 = STK(1);
    u32 _value_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_5;
      STK(1) = _value_6;
      STK(2) = _h_0;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K96;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K96, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_5;
      e.mem[_t_2 + 1] = _value_6;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K96, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K96)
  {
    WL_POPN(3);
    u32 _value_7 = STK(0);
    u32 _value_8 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_8;
      STK(1) = _h_2;
      STK(2) = _h_1;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K97;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K97, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_8;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K97, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_7;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _value_7;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K97)
  {
    WL_POPN(3);
    u32 _value_9 = STK(0);
    Term _h_4 = STK(1);
    Term _h_5 = STK(2);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K98;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K98, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K98, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_9;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _value_9;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K98)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 206));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_9);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 200));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_8);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 194));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_7);
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_5));
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 188));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_7);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    u32 _value_6 = r6;
    u32 _value_7 = r7;
    u32 _value_8 = r8;
    u32 _value_9 = r9;
    u32 _value_10 = r10;
    u32 _value_11 = r11;
    u32 _value_12 = r12;
    u32 _value_13 = r13;
    u32 _value_14 = r14;
    u32 _value_15 = r15;
    u32 _value_16 = r16;
    WL_OPEN
    if (_value_0 == 0) {
      if (seq) {
        WL_ROOM(16);
        STK(0) = _value_2;
        STK(1) = _value_3;
        STK(2) = _value_4;
        STK(3) = _value_5;
        STK(4) = _value_6;
        STK(5) = _value_7;
        STK(6) = _value_8;
        STK(7) = _value_9;
        STK(8) = _value_10;
        STK(9) = _value_11;
        STK(10) = _value_12;
        STK(11) = _value_13;
        STK(12) = _value_14;
        STK(13) = _value_15;
        STK(14) = _value_16;
        STK(15) = FID_HOST_RENDER_RENDER_PENDING_1_K100;
        WL_PUSHN(16);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K100, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _value_2;
        e.mem[_t_0 + 1] = _value_3;
        e.mem[_t_0 + 2] = _value_4;
        e.mem[_t_0 + 3] = _value_5;
        e.mem[_t_0 + 4] = _value_6;
        e.mem[_t_0 + 5] = _value_7;
        e.mem[_t_0 + 6] = _value_8;
        e.mem[_t_0 + 7] = _value_9;
        e.mem[_t_0 + 8] = _value_10;
        e.mem[_t_0 + 9] = _value_11;
        e.mem[_t_0 + 10] = _value_12;
        e.mem[_t_0 + 11] = _value_13;
        e.mem[_t_0 + 12] = _value_14;
        e.mem[_t_0 + 13] = _value_15;
        e.mem[_t_0 + 14] = _value_16;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K100, _t_0);
        WL_IDX = 15;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_1;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _value_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_value_0 == 1) {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _value_2;
        STK(1) = _value_3;
        STK(2) = _value_4;
        STK(3) = _value_5;
        STK(4) = _value_6;
        STK(5) = _value_7;
        STK(6) = FID_HOST_RENDER_RENDER_PENDING_1_K102;
        WL_PUSHN(7);
      } else {
        u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K102, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _value_2;
        e.mem[_t_4 + 1] = _value_3;
        e.mem[_t_4 + 2] = _value_4;
        e.mem[_t_4 + 3] = _value_5;
        e.mem[_t_4 + 4] = _value_6;
        e.mem[_t_4 + 5] = _value_7;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K102, _t_4);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _value_1;
        return term_tsk(FID_U32_SHOW, _t_5);
      }
      r0 = _value_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_value_0 == 2) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _value_2;
        STK(1) = FID_HOST_RENDER_RENDER_PENDING_1_K104;
        WL_PUSHN(2);
      } else {
        u64 _t_8 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K104, WL_CONT, WL_IDX, 1);
        e.mem[_t_8 + 0] = _value_2;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K104, _t_8);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_9 + 0] = _value_1;
        return term_tsk(FID_U32_SHOW, _t_9);
      }
      r0 = _value_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_value_0 == 3) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_HOST_RENDER_RENDER_PENDING_1_K106;
        WL_PUSHN(1);
      } else {
        u64 _t_12 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K106, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K106, _t_12);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _value_1;
        return term_tsk(FID_U32_SHOW, _t_13);
      }
      r0 = _value_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_value_0 == 4) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_HOST_RENDER_RENDER_PENDING_1_K107;
        WL_PUSHN(1);
      } else {
        u64 _t_14 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K107, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K107, _t_14);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_15 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_15 + 0] = _value_1;
        return term_tsk(FID_U32_SHOW, _t_15);
      }
      r0 = _value_1;
      WL_JMP(FID_U32_SHOW);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_HOST_RENDER_RENDER_PENDING_1_K108;
        WL_PUSHN(1);
      } else {
        u64 _t_16 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K108, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K108, _t_16);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_17 + 0] = _value_1;
        return term_tsk(FID_U32_SHOW, _t_17);
      }
      r0 = _value_1;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K100)
  {
    WL_POPN(15);
    u32 _value_17 = STK(0);
    u32 _value_18 = STK(1);
    u32 _value_19 = STK(2);
    u32 _value_20 = STK(3);
    u32 _value_21 = STK(4);
    u32 _value_22 = STK(5);
    u32 _value_23 = STK(6);
    u32 _value_24 = STK(7);
    u32 _value_25 = STK(8);
    u32 _value_26 = STK(9);
    u32 _value_27 = STK(10);
    u32 _value_28 = STK(11);
    u32 _value_29 = STK(12);
    u32 _value_30 = STK(13);
    u32 _value_31 = STK(14);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_PENDING_1_K101;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K101, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K101, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_BUNDLE_1)) {
      u64 _t_3 = task_node(e, FID_HOST_RENDER_RENDER_BUNDLE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_17;
      e.mem[_t_3 + 1] = _value_18;
      e.mem[_t_3 + 2] = _value_19;
      e.mem[_t_3 + 3] = _value_20;
      e.mem[_t_3 + 4] = _value_21;
      e.mem[_t_3 + 5] = _value_22;
      e.mem[_t_3 + 6] = _value_23;
      e.mem[_t_3 + 7] = _value_24;
      e.mem[_t_3 + 8] = _value_25;
      e.mem[_t_3 + 9] = _value_26;
      e.mem[_t_3 + 10] = _value_27;
      e.mem[_t_3 + 11] = _value_28;
      e.mem[_t_3 + 12] = _value_29;
      e.mem[_t_3 + 13] = _value_30;
      e.mem[_t_3 + 14] = _value_31;
      return term_tsk(FID_HOST_RENDER_RENDER_BUNDLE_1, _t_3);
    }
    r0 = _value_17;
    r1 = _value_18;
    r2 = _value_19;
    r3 = _value_20;
    r4 = _value_21;
    r5 = _value_22;
    r6 = _value_23;
    r7 = _value_24;
    r8 = _value_25;
    r9 = _value_26;
    r10 = _value_27;
    r11 = _value_28;
    r12 = _value_29;
    r13 = _value_30;
    r14 = _value_31;
    WL_JMP(FID_HOST_RENDER_RENDER_BUNDLE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K101)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 256));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 236));
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 216));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_5);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K102)
  {
    WL_POPN(6);
    u32 _value_32 = STK(0);
    u32 _value_33 = STK(1);
    u32 _value_34 = STK(2);
    u32 _value_35 = STK(3);
    u32 _value_36 = STK(4);
    u32 _value_37 = STK(5);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_HOST_RENDER_RENDER_PENDING_1_K103;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K103, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K103, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_VITALS)) {
      u64 _t_7 = task_node(e, FID_HOST_RENDER_RENDER_VITALS, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_32;
      e.mem[_t_7 + 1] = _value_33;
      e.mem[_t_7 + 2] = _value_34;
      e.mem[_t_7 + 3] = _value_35;
      e.mem[_t_7 + 4] = _value_36;
      e.mem[_t_7 + 5] = _value_37;
      return term_tsk(FID_HOST_RENDER_RENDER_VITALS, _t_7);
    }
    r0 = _value_32;
    r1 = _value_33;
    r2 = _value_34;
    r3 = _value_35;
    r4 = _value_36;
    r5 = _value_37;
    WL_JMP(FID_HOST_RENDER_RENDER_VITALS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K103)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_4);
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 266));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _h_5);
    e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_7));
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_9 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_8));
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 264));
    e.mem[_nd_10 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_9));
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 216));
    e.mem[_nd_11 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_10));
    Term _v_1 = 0;
    Term _o_1[1];
    Term _a_1 = term_ctr(CID_CON, _nd_11);
    if (spin_24(e, _o_1, _a_1, blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_1 = _o_1[0];
    r0 = _v_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K104)
  {
    WL_POPN(1);
    u32 _value_38 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_6;
      STK(1) = FID_HOST_RENDER_RENDER_PENDING_1_K105;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1_K105, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_6;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_PENDING_1_K105, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_TRACKED)) {
      u64 _t_11 = task_node(e, FID_HOST_RENDER_RENDER_TRACKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _value_38;
      return term_tsk(FID_HOST_RENDER_RENDER_TRACKED, _t_11);
    }
    r0 = _value_38;
    WL_JMP(FID_HOST_RENDER_RENDER_TRACKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K105)
  {
    WL_POPN(1);
    Term _h_8 = STK(0);
    Term _h_7 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_12 + 0] = rfc_seal(e, _h_7);
    e.mem[_nd_12 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 174));
    e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_12));
    u64 _nd_14 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_14 + 0] = rfc_seal(e, _h_8);
    e.mem[_nd_14 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_13));
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_15 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_14));
    u64 _nd_16 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_16 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 276));
    e.mem[_nd_16 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_15));
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 216));
    e.mem[_nd_17 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_16));
    Term _v_2 = 0;
    Term _o_2[1];
    Term _a_2 = term_ctr(CID_CON, _nd_17);
    if (spin_24(e, _o_2, _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_2 = _o_2[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K106)
  {
    Term _h_9 = r0;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_18 + 0] = rfc_seal(e, _h_9);
    e.mem[_nd_18 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_19 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_19 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_19 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_18));
    u64 _nd_20 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_20 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 290));
    e.mem[_nd_20 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_19));
    u64 _nd_21 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_21 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 216));
    e.mem[_nd_21 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_20));
    Term _v_3 = 0;
    Term _o_3[1];
    Term _a_3 = term_ctr(CID_CON, _nd_21);
    if (spin_24(e, _o_3, _a_3, blk_loc(e.mem, _a_3)) == 0) {
      return 0;
    }
    _v_3 = _o_3[0];
    r0 = _v_3;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K107)
  {
    Term _h_10 = r0;
    WL_OPEN
    u64 _nd_22 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_22 + 0] = rfc_seal(e, _h_10);
    e.mem[_nd_22 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_23 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_23 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_23 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_22));
    u64 _nd_24 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_24 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 304));
    e.mem[_nd_24 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_23));
    u64 _nd_25 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_25 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 216));
    e.mem[_nd_25 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_24));
    Term _v_4 = 0;
    Term _o_4[1];
    Term _a_4 = term_ctr(CID_CON, _nd_25);
    if (spin_24(e, _o_4, _a_4, blk_loc(e.mem, _a_4)) == 0) {
      return 0;
    }
    _v_4 = _o_4[0];
    r0 = _v_4;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_PENDING_1_K108)
  {
    Term _h_11 = r0;
    WL_OPEN
    u64 _nd_26 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_26 + 0] = rfc_seal(e, _h_11);
    e.mem[_nd_26 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_27 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_27 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_27 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_26));
    u64 _nd_28 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_28 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 312));
    e.mem[_nd_28 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_27));
    u64 _nd_29 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_29 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 216));
    e.mem[_nd_29 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_28));
    Term _v_5 = 0;
    Term _o_5[1];
    Term _a_5 = term_ctr(CID_CON, _nd_29);
    if (spin_24(e, _o_5, _a_5, blk_loc(e.mem, _a_5)) == 0) {
      return 0;
    }
    _v_5 = _o_5[0];
    r0 = _v_5;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    u32 _value_6 = r6;
    u32 _value_7 = r7;
    u32 _value_8 = r8;
    u32 _value_9 = r9;
    u32 _value_10 = r10;
    u32 _value_11 = r11;
    u32 _value_12 = r12;
    u32 _value_13 = r13;
    u32 _value_14 = r14;
    u32 _value_15 = r15;
    u32 _value_16 = r16;
    u32 _value_17 = r17;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = _value_3;
      STK(3) = _value_4;
      STK(4) = _value_5;
      STK(5) = _value_6;
      STK(6) = _value_7;
      STK(7) = _value_8;
      STK(8) = _value_9;
      STK(9) = _value_10;
      STK(10) = _value_11;
      STK(11) = _value_12;
      STK(12) = _value_13;
      STK(13) = _value_14;
      STK(14) = _value_15;
      STK(15) = _value_16;
      STK(16) = _value_17;
      STK(17) = FID_HOST_RENDER_RENDER_ROW_1_K110;
      WL_PUSHN(18);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1_K110, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      e.mem[_t_0 + 2] = _value_3;
      e.mem[_t_0 + 3] = _value_4;
      e.mem[_t_0 + 4] = _value_5;
      e.mem[_t_0 + 5] = _value_6;
      e.mem[_t_0 + 6] = _value_7;
      e.mem[_t_0 + 7] = _value_8;
      e.mem[_t_0 + 8] = _value_9;
      e.mem[_t_0 + 9] = _value_10;
      e.mem[_t_0 + 10] = _value_11;
      e.mem[_t_0 + 11] = _value_12;
      e.mem[_t_0 + 12] = _value_13;
      e.mem[_t_0 + 13] = _value_14;
      e.mem[_t_0 + 14] = _value_15;
      e.mem[_t_0 + 15] = _value_16;
      e.mem[_t_0 + 16] = _value_17;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_ROW_1_K110, _t_0);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1_K110)
  {
    WL_POPN(17);
    u32 _value_18 = STK(0);
    u32 _value_19 = STK(1);
    u32 _value_20 = STK(2);
    u32 _value_21 = STK(3);
    u32 _value_22 = STK(4);
    u32 _value_23 = STK(5);
    u32 _value_24 = STK(6);
    u32 _value_25 = STK(7);
    u32 _value_26 = STK(8);
    u32 _value_27 = STK(9);
    u32 _value_28 = STK(10);
    u32 _value_29 = STK(11);
    u32 _value_30 = STK(12);
    u32 _value_31 = STK(13);
    u32 _value_32 = STK(14);
    u32 _value_33 = STK(15);
    u32 _value_34 = STK(16);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _value_25;
      STK(1) = _value_26;
      STK(2) = _value_27;
      STK(3) = _value_28;
      STK(4) = _value_29;
      STK(5) = _value_30;
      STK(6) = _value_31;
      STK(7) = _value_32;
      STK(8) = _value_33;
      STK(9) = _value_34;
      STK(10) = _h_0;
      STK(11) = FID_HOST_RENDER_RENDER_ROW_1_K111;
      WL_PUSHN(12);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1_K111, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_25;
      e.mem[_t_2 + 1] = _value_26;
      e.mem[_t_2 + 2] = _value_27;
      e.mem[_t_2 + 3] = _value_28;
      e.mem[_t_2 + 4] = _value_29;
      e.mem[_t_2 + 5] = _value_30;
      e.mem[_t_2 + 6] = _value_31;
      e.mem[_t_2 + 7] = _value_32;
      e.mem[_t_2 + 8] = _value_33;
      e.mem[_t_2 + 9] = _value_34;
      e.mem[_t_2 + 10] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_ROW_1_K111, _t_2);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_6)) {
      u64 _t_3 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_6, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_18;
      e.mem[_t_3 + 1] = _value_19;
      e.mem[_t_3 + 2] = _value_20;
      e.mem[_t_3 + 3] = _value_21;
      e.mem[_t_3 + 4] = _value_22;
      e.mem[_t_3 + 5] = _value_23;
      e.mem[_t_3 + 6] = _value_24;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_6, _t_3);
    }
    r0 = _value_18;
    r1 = _value_19;
    r2 = _value_20;
    r3 = _value_21;
    r4 = _value_22;
    r5 = _value_23;
    r6 = _value_24;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1_K111)
  {
    WL_POPN(11);
    u32 _value_35 = STK(0);
    u32 _value_36 = STK(1);
    u32 _value_37 = STK(2);
    u32 _value_38 = STK(3);
    u32 _value_39 = STK(4);
    u32 _value_40 = STK(5);
    u32 _value_41 = STK(6);
    u32 _value_42 = STK(7);
    u32 _value_43 = STK(8);
    u32 _value_44 = STK(9);
    Term _h_2 = STK(10);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _value_41;
      STK(1) = _value_42;
      STK(2) = _value_43;
      STK(3) = _value_44;
      STK(4) = _h_2;
      STK(5) = _h_1;
      STK(6) = FID_HOST_RENDER_RENDER_ROW_1_K112;
      WL_PUSHN(7);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1_K112, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_41;
      e.mem[_t_4 + 1] = _value_42;
      e.mem[_t_4 + 2] = _value_43;
      e.mem[_t_4 + 3] = _value_44;
      e.mem[_t_4 + 4] = _h_2;
      e.mem[_t_4 + 5] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_ROW_1_K112, _t_4);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_4)) {
      u64 _t_5 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_4, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_35;
      e.mem[_t_5 + 1] = _value_36;
      e.mem[_t_5 + 2] = _value_37;
      e.mem[_t_5 + 3] = _value_38;
      e.mem[_t_5 + 4] = _value_39;
      e.mem[_t_5 + 5] = _value_40;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_4, _t_5);
    }
    r0 = _value_35;
    r1 = _value_36;
    r2 = _value_37;
    r3 = _value_38;
    r4 = _value_39;
    r5 = _value_40;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1_K112)
  {
    WL_POPN(6);
    u32 _value_45 = STK(0);
    u32 _value_46 = STK(1);
    u32 _value_47 = STK(2);
    u32 _value_48 = STK(3);
    Term _h_4 = STK(4);
    Term _h_5 = STK(5);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _value_47;
      STK(1) = _value_48;
      STK(2) = _h_4;
      STK(3) = _h_5;
      STK(4) = _h_3;
      STK(5) = FID_HOST_RENDER_RENDER_ROW_1_K113;
      WL_PUSHN(6);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1_K113, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _value_47;
      e.mem[_t_6 + 1] = _value_48;
      e.mem[_t_6 + 2] = _h_4;
      e.mem[_t_6 + 3] = _h_5;
      e.mem[_t_6 + 4] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_ROW_1_K113, _t_6);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_5)) {
      u64 _t_7 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_5, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_45;
      e.mem[_t_7 + 1] = _value_46;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_5, _t_7);
    }
    r0 = _value_45;
    r1 = _value_46;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1_K113)
  {
    WL_POPN(5);
    u32 _value_49 = STK(0);
    u32 _value_50 = STK(1);
    Term _h_7 = STK(2);
    Term _h_8 = STK(3);
    Term _h_9 = STK(4);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _value_50;
      STK(1) = _h_7;
      STK(2) = _h_8;
      STK(3) = _h_9;
      STK(4) = _h_6;
      STK(5) = FID_HOST_RENDER_RENDER_ROW_1_K114;
      WL_PUSHN(6);
    } else {
      u64 _t_8 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1_K114, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _value_50;
      e.mem[_t_8 + 1] = _h_7;
      e.mem[_t_8 + 2] = _h_8;
      e.mem[_t_8 + 3] = _h_9;
      e.mem[_t_8 + 4] = _h_6;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_ROW_1_K114, _t_8);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _value_49;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _value_49;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1_K114)
  {
    WL_POPN(5);
    u32 _value_51 = STK(0);
    Term _h_11 = STK(1);
    Term _h_12 = STK(2);
    Term _h_13 = STK(3);
    Term _h_14 = STK(4);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = _h_14;
      STK(4) = _h_10;
      STK(5) = FID_HOST_RENDER_RENDER_ROW_1_K115;
      WL_PUSHN(6);
    } else {
      u64 _t_10 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1_K115, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_11;
      e.mem[_t_10 + 1] = _h_12;
      e.mem[_t_10 + 2] = _h_13;
      e.mem[_t_10 + 3] = _h_14;
      e.mem[_t_10 + 4] = _h_10;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_ROW_1_K115, _t_10);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _value_51;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _value_51;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_ROW_1_K115)
  {
    WL_POPN(5);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_19 = STK(3);
    Term _h_20 = STK(4);
    Term _h_15 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_15);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 340));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_20);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 326));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_19);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 174));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_18);
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_5));
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 162));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _h_17);
    e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_7));
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 266));
    e.mem[_nd_9 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_8));
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, _h_16);
    e.mem[_nd_10 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_9));
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 314));
    e.mem[_nd_11 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_10));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_11);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_LEDGER0_1)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _value_0 = r21;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _value_0;
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_world_12 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _world_13);
      e.mem[_nd_5 + 1] = rfc_seal(e, _world_14);
      u64 _nd_6 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_6 + 0] = rfc_seal(e, _world_15);
      e.mem[_nd_6 + 1] = rfc_seal(e, _world_16);
      e.mem[_nd_6 + 2] = rfc_seal(e, _world_17);
      e.mem[_nd_6 + 3] = rfc_seal(e, _world_18);
      e.mem[_nd_6 + 4] = rfc_seal(e, _world_19);
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_5));
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_6));
      _o_3 = term_ctr(CID_CACHE_CACHE, _nd_7);
    }
    Term _b_0 = 0;
    if (_world_20 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_STORAGE_SET_LEDGER0_1_K126;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_STORAGE_SET_LEDGER0_1_K126, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_K126, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_LEDGER)) {
      u64 _t_1 = task_node(e, FID_STORAGE_WITH_LEDGER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _o_2;
      e.mem[_t_1 + 13] = _o_3;
      e.mem[_t_1 + 14] = _b_0;
      e.mem[_t_1 + 15] = term_clo(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_C125, _nd_0);
      return term_tsk(FID_STORAGE_WITH_LEDGER, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _o_2;
    r13 = _o_3;
    r14 = _b_0;
    r15 = term_clo(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_C125, _nd_0);
    WL_JMP(FID_STORAGE_WITH_LEDGER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_C125)
  {
    u32 _value_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
    Term _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    Term _fb_2[5];
    u64 _sp_2 = ctr_take(e, _f_1, 5, _fb_2);
    u32 _f_4 = _fb_2[0];
    u32 _f_5 = _fb_2[1];
    u32 _f_6 = _fb_2[2];
    u32 _f_7 = _fb_2[3];
    u32 _f_8 = _fb_2[4];
    spare_free(e, cls_fit(5), _sp_2);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _o_1[8];
    if (spin_77(e, _o_1, _f_2, blk_loc(e.mem, _f_2), _f_3, _f_4, _f_5, _f_6, _f_7, _f_8, _value_1) == 0) {
      return 0;
    }
    _v_0 = _o_1[0];
    _v_1 = _o_1[1];
    _v_2 = _o_1[2];
    _v_3 = _o_1[3];
    _v_4 = _o_1[4];
    _v_5 = _o_1[5];
    _v_6 = _o_1[6];
    _v_7 = _o_1[7];
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_1);
    u64 _nd_2 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_6);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_1));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_CACHE_CACHE, _nd_3));
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_7);
    r0 = term_ctr(CID_TUPLE, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_LEDGER0_1_K126)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    u32 _r_12 = r12;
    Term _r_13 = r13;
    Term _r_14 = r14;
    u32 _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_4 = 0;
    Term _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    if (_r_12 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _r_13, 2, _fb_3);
      Term _f_9 = _fb_3[0];
      Term _f_10 = _fb_3[1];
      spare_free(e, cls_fit(2), _sp_3);
      Term _fb_4[2];
      u64 _sp_4 = ctr_take(e, _f_9, 2, _fb_4);
      Term _f_11 = _fb_4[0];
      u32 _f_12 = _fb_4[1];
      spare_free(e, cls_fit(2), _sp_4);
      Term _fb_5[5];
      u64 _sp_5 = ctr_take(e, _f_10, 5, _fb_5);
      u32 _f_13 = _fb_5[0];
      u32 _f_14 = _fb_5[1];
      u32 _f_15 = _fb_5[2];
      u32 _f_16 = _fb_5[3];
      u32 _f_17 = _fb_5[4];
      spare_free(e, cls_fit(5), _sp_5);
      _o_5 = _f_11;
      _o_6 = _f_12;
      _o_7 = _f_13;
      _o_8 = _f_14;
      _o_9 = _f_15;
      _o_10 = _f_16;
      _o_11 = _f_17;
    }
    u32 _o_12 = 0;
    if (term_aux(_r_14) == CID_TYPES_HEALTHON) {
      _o_12 = 0;
    } else {
      _o_12 = 1;
    }
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    if (_r_15 == 0) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      _o_14 = _r_16;
    }
    r0 = _r_0;
    r1 = _r_1;
    r2 = _r_2;
    r3 = _r_3;
    r4 = _r_4;
    r5 = _r_5;
    r6 = _r_6;
    r7 = _r_7;
    r8 = _r_8;
    r9 = _r_9;
    r10 = _r_10;
    r11 = _r_11;
    r12 = _o_4;
    r13 = _o_5;
    r14 = _o_6;
    r15 = _o_7;
    r16 = _o_8;
    r17 = _o_9;
    r18 = _o_10;
    r19 = _o_11;
    r20 = _o_12;
    r21 = _o_13;
    r22 = _o_14;
    WL_RETN(23);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_11)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_1[1];
      if (spin_78(e, _o_1, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_0 = _o_1[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      u64 _sp_1 = term_peek(e.mem, _values_0);
      Term _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      u64 _sp_2 = term_peek(e.mem, _f_2);
      u32 _f_4 = e.mem[_sp_2 + 0];
      u32 _f_5 = e.mem[_sp_2 + 1];
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_3;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_11_K131;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_11_K131, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_11_K131, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_HANDLE)) {
        u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_HANDLE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_4;
        e.mem[_t_1 + 1] = _f_5;
        return term_tsk(FID_HOST_RENDER_RENDER_HANDLE, _t_1);
      }
      r0 = _f_4;
      r1 = _f_5;
      WL_JMP(FID_HOST_RENDER_RENDER_HANDLE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_11_K131)
  {
    WL_POPN(3);
    Term _f_6 = STK(0);
    Term _acc_2 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_2[1];
    if (spin_80(e, _o_2, _h_0, blk_loc(e.mem, _h_0), _acc_2, blk_loc(e.mem, _acc_2), _first_1) == 0) {
      return 0;
    }
    _v_5 = _o_2[0];
    _v_4 = _v_5;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_11)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_11, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      e.mem[_t_2 + 1] = _v_4;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_11, _t_2);
    }
    r0 = _f_6;
    r1 = _v_4;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_HANDLE)
  {
    u32 _handle_0 = r0;
    u32 _handle_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _handle_1;
      STK(1) = FID_HEALTH_HANDLE_K133;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HEALTH_HANDLE_K133, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _handle_1;
      WL_CONT = term_tsk(FID_HEALTH_HANDLE_K133, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _handle_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _handle_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_HANDLE_K133)
  {
    WL_POPN(1);
    u32 _handle_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HEALTH_HANDLE_K134;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HEALTH_HANDLE_K134, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HEALTH_HANDLE_K134, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _handle_2;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _handle_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_HANDLE_K134)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_HEALTH_HANDLE_K135;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_HEALTH_HANDLE_K135, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_HEALTH_HANDLE_K135, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 344);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 344);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_HANDLE_K135)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROWS_GO_0)
  {
    Term _remaining_0 = r0;
    u32 _id_0 = r1;
    Term _state_0 = r2;
    Term _state_1 = r3;
    Term _state_2 = r4;
    Term _state_3 = r5;
    Term _state_4 = r6;
    Term _state_5 = r7;
    u32 _state_6 = r8;
    Term _state_7 = r9;
    u32 _state_8 = r10;
    Term _state_9 = r11;
    WL_OPEN
    if (_remaining_0 == 0) {
      Term _v_0 = 0;
      Term _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      u32 _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      Term _v_9 = 0;
      Term _o_2[10];
      if (spin_89(e, _o_2, _state_0, blk_loc(e.mem, _state_0), _state_1, blk_loc(e.mem, _state_1), _state_2, blk_loc(e.mem, _state_2), _state_3, blk_loc(e.mem, _state_3), _state_4, blk_loc(e.mem, _state_4), _state_5, blk_loc(e.mem, _state_5), _state_6, _state_7, _state_8, _state_9, blk_loc(e.mem, _state_9)) == 0) {
        return 0;
      }
      _v_0 = _o_2[0];
      _v_1 = _o_2[1];
      _v_2 = _o_2[2];
      _v_3 = _o_2[3];
      _v_4 = _o_2[4];
      _v_5 = _o_2[5];
      _v_6 = _o_2[6];
      _v_7 = _o_2[7];
      _v_8 = _o_2[8];
      _v_9 = _o_2[9];
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      WL_RETN(10);
    } else {
      Term _remaining_1 = (_remaining_0 - 1);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _remaining_1;
        STK(1) = _id_0;
        STK(2) = FID_OBSERVATIONS_ROWS_GO_0_K146;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_OBSERVATIONS_ROWS_GO_0_K146, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _remaining_1;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID_OBSERVATIONS_ROWS_GO_0_K146, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_ROWS_ADVANCE_0)) {
        u64 _t_1 = task_node(e, FID_OBSERVATIONS_ROWS_ADVANCE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _id_0;
        e.mem[_t_1 + 1] = _state_0;
        e.mem[_t_1 + 2] = _state_1;
        e.mem[_t_1 + 3] = _state_2;
        e.mem[_t_1 + 4] = _state_3;
        e.mem[_t_1 + 5] = _state_4;
        e.mem[_t_1 + 6] = _state_5;
        e.mem[_t_1 + 7] = _state_6;
        e.mem[_t_1 + 8] = _state_7;
        e.mem[_t_1 + 9] = _state_8;
        e.mem[_t_1 + 10] = _state_9;
        return term_tsk(FID_OBSERVATIONS_ROWS_ADVANCE_0, _t_1);
      }
      r0 = _id_0;
      r1 = _state_0;
      r2 = _state_1;
      r3 = _state_2;
      r4 = _state_3;
      r5 = _state_4;
      r6 = _state_5;
      r7 = _state_6;
      r8 = _state_7;
      r9 = _state_8;
      r10 = _state_9;
      WL_JMP(FID_OBSERVATIONS_ROWS_ADVANCE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROWS_GO_0_K146)
  {
    WL_POPN(2);
    Term _remaining_2 = STK(0);
    u32 _id_1 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_ROWS_GO_0)) {
      u64 _t_2 = task_node(e, FID_OBSERVATIONS_ROWS_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _remaining_2;
      e.mem[_t_2 + 1] = U32_BIN(_id_1, +, 1ull);
      e.mem[_t_2 + 2] = _h_0;
      e.mem[_t_2 + 3] = _h_1;
      e.mem[_t_2 + 4] = _h_2;
      e.mem[_t_2 + 5] = _h_3;
      e.mem[_t_2 + 6] = _h_4;
      e.mem[_t_2 + 7] = _h_5;
      e.mem[_t_2 + 8] = _h_6;
      e.mem[_t_2 + 9] = _h_7;
      e.mem[_t_2 + 10] = _h_8;
      e.mem[_t_2 + 11] = _h_9;
      return term_tsk(FID_OBSERVATIONS_ROWS_GO_0, _t_2);
    }
    r0 = _remaining_2;
    r1 = U32_BIN(_id_1, +, 1ull);
    r2 = _h_0;
    r3 = _h_1;
    r4 = _h_2;
    r5 = _h_3;
    r6 = _h_4;
    r7 = _h_5;
    r8 = _h_6;
    r9 = _h_7;
    r10 = _h_8;
    r11 = _h_9;
    WL_JMP(FID_OBSERVATIONS_ROWS_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_MAYBE_GET_0)
  {
    u32 _owner_0 = r0;
    Term _owner_1 = r1;
    u32 _owner_2 = r2;
    u32 _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    u32 _owner_7 = r7;
    WL_OPEN
    if (_owner_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      WL_RETN(14);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_OBSERVATIONS_MAYBE_GET_0_K148;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_OBSERVATIONS_MAYBE_GET_0_K148, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_OBSERVATIONS_MAYBE_GET_0_K148, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET)) {
        u64 _t_1 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owner_1;
        e.mem[_t_1 + 1] = _owner_2;
        e.mem[_t_1 + 2] = _owner_3;
        e.mem[_t_1 + 3] = _owner_4;
        e.mem[_t_1 + 4] = _owner_5;
        e.mem[_t_1 + 5] = _owner_6;
        e.mem[_t_1 + 6] = _owner_7;
        return term_tsk(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET, _t_1);
      }
      r0 = _owner_1;
      r1 = _owner_2;
      r2 = _owner_3;
      r3 = _owner_4;
      r4 = _owner_5;
      r5 = _owner_6;
      r6 = _owner_7;
      WL_JMP(FID_ORIGINAL_RAW_OBSERVER_HEALTH_LEDGER_GET);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_MAYBE_GET_0_K148)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    u64 _nd_1 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_1 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_3);
    e.mem[_nd_1 + 2] = rfc_seal(e, _h_4);
    e.mem[_nd_1 + 3] = rfc_seal(e, _h_5);
    e.mem[_nd_1 + 4] = rfc_seal(e, _h_6);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h_7);
    e.mem[_nd_3 + 1] = rfc_seal(e, _h_8);
    e.mem[_nd_3 + 2] = rfc_seal(e, _h_9);
    e.mem[_nd_3 + 3] = rfc_seal(e, _h_10);
    e.mem[_nd_3 + 4] = rfc_seal(e, _h_11);
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    Term _a_0 = term_ctr(CID_CACHE_CACHE, _nd_2);
    Term _a_1 = term_ctr(CID_TYPES_LEDGERVIEW, _nd_3);
    if (spin_92(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    u32 _o_1 = 0;
    Term _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    if (_v_0 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[5];
      u64 _sp_2 = ctr_take(e, _f_1, 5, _fb_2);
      u32 _f_4 = _fb_2[0];
      u32 _f_5 = _fb_2[1];
      u32 _f_6 = _fb_2[2];
      u32 _f_7 = _fb_2[3];
      u32 _f_8 = _fb_2[4];
      spare_free(e, cls_fit(5), _sp_2);
      _o_2 = _f_2;
      _o_3 = _f_3;
      _o_4 = _f_4;
      _o_5 = _f_5;
      _o_6 = _f_6;
      _o_7 = _f_7;
      _o_8 = _f_8;
    }
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    u32 _o_12 = 0;
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    if (_v_2 == 0) {
      _o_9 = 0;
    } else {
      _o_9 = 1;
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _v_3, 5, _fb_3);
      u32 _f_9 = _fb_3[0];
      u32 _f_10 = _fb_3[1];
      u32 _f_11 = _fb_3[2];
      u32 _f_12 = _fb_3[3];
      u32 _f_13 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_10 = _f_9;
      _o_11 = _f_10;
      _o_12 = _f_11;
      _o_13 = _f_12;
      _o_14 = _f_13;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_14)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_0[1];
      if (spin_78(e, _o_0, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_0 = _o_0[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      u32 _o_4 = 0;
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      u32 _o_12 = 0;
      u32 _o_13 = 0;
      u32 _o_14 = 0;
      u32 _o_15 = 0;
      u32 _o_16 = 0;
      u32 _o_17 = 0;
      if (term_aux(_f_0) == CID_OBSERVATIONS_SPAWNVIEW) {
        _o_1 = 0;
        Term _fb_1[7];
        u64 _sp_1 = ctr_take(e, _f_0, 7, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        u32 _f_7 = _fb_1[5];
        Term _f_8 = _fb_1[6];
        spare_free(e, cls_fit(7), _sp_1);
        u32 _o_18 = 0;
        u32 _o_19 = 0;
        u32 _o_20 = 0;
        u32 _o_21 = 0;
        u32 _o_22 = 0;
        u32 _o_23 = 0;
        u32 _o_24 = 0;
        if (_f_3 == 0) {
          _o_18 = 0;
        } else {
          _o_18 = 1;
          Term _fb_2[6];
          u64 _sp_2 = ctr_take(e, _f_4, 6, _fb_2);
          u32 _f_9 = _fb_2[0];
          u32 _f_10 = _fb_2[1];
          u32 _f_11 = _fb_2[2];
          u32 _f_12 = _fb_2[3];
          u32 _f_13 = _fb_2[4];
          u32 _f_14 = _fb_2[5];
          spare_free(e, cls_fit(6), _sp_2);
          _o_19 = _f_9;
          _o_20 = _f_10;
          _o_21 = _f_11;
          _o_22 = _f_12;
          _o_23 = _f_13;
          _o_24 = _f_14;
        }
        u32 _o_25 = 0;
        u32 _o_26 = 0;
        u32 _o_27 = 0;
        u32 _o_28 = 0;
        u32 _o_29 = 0;
        u32 _o_30 = 0;
        if (_f_5 == 0) {
          _o_25 = 0;
        } else {
          _o_25 = 1;
          Term _fb_3[5];
          u64 _sp_3 = ctr_take(e, _f_6, 5, _fb_3);
          u32 _f_15 = _fb_3[0];
          u32 _f_16 = _fb_3[1];
          u32 _f_17 = _fb_3[2];
          u32 _f_18 = _fb_3[3];
          u32 _f_19 = _fb_3[4];
          spare_free(e, cls_fit(5), _sp_3);
          _o_26 = _f_15;
          _o_27 = _f_16;
          _o_28 = _f_17;
          _o_29 = _f_18;
          _o_30 = _f_19;
        }
        u32 _o_31 = 0;
        u32 _o_32 = 0;
        if (_f_7 == 0) {
          _o_31 = 0;
        } else {
          _o_31 = 1;
          _o_32 = term_loc(_f_8);
        }
        _o_2 = _f_2;
        _o_3 = _o_18;
        _o_4 = _o_19;
        _o_5 = _o_20;
        _o_6 = _o_21;
        _o_7 = _o_22;
        _o_8 = _o_23;
        _o_9 = _o_24;
        _o_10 = _o_25;
        _o_11 = _o_26;
        _o_12 = _o_27;
        _o_13 = _o_28;
        _o_14 = _o_29;
        _o_15 = _o_30;
        _o_16 = _o_31;
        _o_17 = _o_32;
      } else if (term_aux(_f_0) == CID_OBSERVATIONS_MAINVIEW) {
        _o_1 = 1;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_0, 2, _fb_4);
        u32 _f_20 = _fb_4[0];
        Term _f_21 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        Term _fb_5[6];
        u64 _sp_5 = ctr_take(e, _f_21, 6, _fb_5);
        u32 _f_22 = _fb_5[0];
        u32 _f_23 = _fb_5[1];
        u32 _f_24 = _fb_5[2];
        u32 _f_25 = _fb_5[3];
        u32 _f_26 = _fb_5[4];
        u32 _f_27 = _fb_5[5];
        spare_free(e, cls_fit(6), _sp_5);
        _o_2 = _f_20;
        _o_3 = _f_22;
        _o_4 = _f_23;
        _o_5 = _f_24;
        _o_6 = _f_25;
        _o_7 = _f_26;
        _o_8 = _f_27;
      } else if (term_aux(_f_0) == CID_OBSERVATIONS_FLAGVIEW) {
        _o_1 = 2;
        Term _fb_6[2];
        u64 _sp_6 = ctr_take(e, _f_0, 2, _fb_6);
        u32 _f_28 = _fb_6[0];
        Term _f_29 = _fb_6[1];
        spare_free(e, cls_fit(2), _sp_6);
        _o_2 = _f_28;
        _o_3 = term_loc(_f_29);
      } else if (term_aux(_f_0) == CID_OBSERVATIONS_REMOVEMAINVIEW) {
        _o_1 = 3;
        _o_2 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID_OBSERVATIONS_REMOVEFLAGVIEW) {
        _o_1 = 4;
        _o_2 = term_loc(_f_0);
      } else {
        _o_1 = 5;
        _o_2 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_14_K154;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_14_K154, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_14_K154, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_PENDING_1)) {
        u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_PENDING_1, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_1;
        e.mem[_t_1 + 1] = _o_2;
        e.mem[_t_1 + 2] = _o_3;
        e.mem[_t_1 + 3] = _o_4;
        e.mem[_t_1 + 4] = _o_5;
        e.mem[_t_1 + 5] = _o_6;
        e.mem[_t_1 + 6] = _o_7;
        e.mem[_t_1 + 7] = _o_8;
        e.mem[_t_1 + 8] = _o_9;
        e.mem[_t_1 + 9] = _o_10;
        e.mem[_t_1 + 10] = _o_11;
        e.mem[_t_1 + 11] = _o_12;
        e.mem[_t_1 + 12] = _o_13;
        e.mem[_t_1 + 13] = _o_14;
        e.mem[_t_1 + 14] = _o_15;
        e.mem[_t_1 + 15] = _o_16;
        e.mem[_t_1 + 16] = _o_17;
        return term_tsk(FID_HOST_RENDER_RENDER_PENDING_1, _t_1);
      }
      r0 = _o_1;
      r1 = _o_2;
      r2 = _o_3;
      r3 = _o_4;
      r4 = _o_5;
      r5 = _o_6;
      r6 = _o_7;
      r7 = _o_8;
      r8 = _o_9;
      r9 = _o_10;
      r10 = _o_11;
      r11 = _o_12;
      r12 = _o_13;
      r13 = _o_14;
      r14 = _o_15;
      r15 = _o_16;
      r16 = _o_17;
      WL_JMP(FID_HOST_RENDER_RENDER_PENDING_1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_14_K154)
  {
    WL_POPN(3);
    Term _f_30 = STK(0);
    Term _acc_1 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _o_33[1];
    if (spin_80(e, _o_33, _h_0, blk_loc(e.mem, _h_0), _acc_1, blk_loc(e.mem, _acc_1), _first_1) == 0) {
      return 0;
    }
    _v_2 = _o_33[0];
    _v_1 = _v_2;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_14)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_14, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_30;
      e.mem[_t_2 + 1] = _v_1;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_14, _t_2);
    }
    r0 = _f_30;
    r1 = _v_1;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_13)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_0[1];
      if (spin_78(e, _o_0, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_0 = _o_0[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[9];
      u64 _sp_1 = ctr_take(e, _f_0, 9, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      Term _f_6 = _fb_1[4];
      u32 _f_7 = _fb_1[5];
      Term _f_8 = _fb_1[6];
      u32 _f_9 = _fb_1[7];
      u32 _f_10 = _fb_1[8];
      spare_free(e, cls_fit(9), _sp_1);
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      u32 _o_4 = 0;
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      if (_f_3 == 0) {
        _o_1 = 0;
      } else {
        _o_1 = 1;
        Term _fb_2[6];
        u64 _sp_2 = ctr_take(e, _f_4, 6, _fb_2);
        u32 _f_11 = _fb_2[0];
        u32 _f_12 = _fb_2[1];
        u32 _f_13 = _fb_2[2];
        u32 _f_14 = _fb_2[3];
        u32 _f_15 = _fb_2[4];
        u32 _f_16 = _fb_2[5];
        spare_free(e, cls_fit(6), _sp_2);
        _o_2 = _f_11;
        _o_3 = _f_12;
        _o_4 = _f_13;
        _o_5 = _f_14;
        _o_6 = _f_15;
        _o_7 = _f_16;
      }
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      u32 _o_12 = 0;
      u32 _o_13 = 0;
      if (_f_5 == 0) {
        _o_8 = 0;
      } else {
        _o_8 = 1;
        Term _fb_3[5];
        u64 _sp_3 = ctr_take(e, _f_6, 5, _fb_3);
        u32 _f_17 = _fb_3[0];
        u32 _f_18 = _fb_3[1];
        u32 _f_19 = _fb_3[2];
        u32 _f_20 = _fb_3[3];
        u32 _f_21 = _fb_3[4];
        spare_free(e, cls_fit(5), _sp_3);
        _o_9 = _f_17;
        _o_10 = _f_18;
        _o_11 = _f_19;
        _o_12 = _f_20;
        _o_13 = _f_21;
      }
      u32 _o_14 = 0;
      u32 _o_15 = 0;
      if (_f_7 == 0) {
        _o_14 = 0;
      } else {
        _o_14 = 1;
        _o_15 = term_loc(_f_8);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_13_K156;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_13_K156, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_13_K156, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_ROW_1)) {
        u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_ROW_1, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        e.mem[_t_1 + 6] = _o_6;
        e.mem[_t_1 + 7] = _o_7;
        e.mem[_t_1 + 8] = _o_8;
        e.mem[_t_1 + 9] = _o_9;
        e.mem[_t_1 + 10] = _o_10;
        e.mem[_t_1 + 11] = _o_11;
        e.mem[_t_1 + 12] = _o_12;
        e.mem[_t_1 + 13] = _o_13;
        e.mem[_t_1 + 14] = _o_14;
        e.mem[_t_1 + 15] = _o_15;
        e.mem[_t_1 + 16] = _f_9;
        e.mem[_t_1 + 17] = _f_10;
        return term_tsk(FID_HOST_RENDER_RENDER_ROW_1, _t_1);
      }
      r0 = _f_2;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      r6 = _o_6;
      r7 = _o_7;
      r8 = _o_8;
      r9 = _o_9;
      r10 = _o_10;
      r11 = _o_11;
      r12 = _o_12;
      r13 = _o_13;
      r14 = _o_14;
      r15 = _o_15;
      r16 = _f_9;
      r17 = _f_10;
      WL_JMP(FID_HOST_RENDER_RENDER_ROW_1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_13_K156)
  {
    WL_POPN(3);
    Term _f_22 = STK(0);
    Term _acc_1 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _o_16[1];
    if (spin_80(e, _o_16, _h_0, blk_loc(e.mem, _h_0), _acc_1, blk_loc(e.mem, _acc_1), _first_1) == 0) {
      return 0;
    }
    _v_2 = _o_16[0];
    _v_1 = _v_2;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_13)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_13, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_22;
      e.mem[_t_2 + 1] = _v_1;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_13, _t_2);
    }
    r0 = _f_22;
    r1 = _v_1;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_MAIN0_1)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _handle_0 = r21;
    u32 _handle_1 = r22;
    u32 _value_0 = r23;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _value_0;
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_world_12 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _world_13);
      e.mem[_nd_5 + 1] = rfc_seal(e, _world_14);
      u64 _nd_6 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_6 + 0] = rfc_seal(e, _world_15);
      e.mem[_nd_6 + 1] = rfc_seal(e, _world_16);
      e.mem[_nd_6 + 2] = rfc_seal(e, _world_17);
      e.mem[_nd_6 + 3] = rfc_seal(e, _world_18);
      e.mem[_nd_6 + 4] = rfc_seal(e, _world_19);
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_5));
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_6));
      _o_3 = term_ctr(CID_CACHE_CACHE, _nd_7);
    }
    Term _b_0 = 0;
    if (_world_20 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_STORAGE_SET_MAIN0_1_K166;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_STORAGE_SET_MAIN0_1_K166, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_STORAGE_SET_MAIN0_1_K166, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_MAIN)) {
      u64 _t_1 = task_node(e, FID_STORAGE_WITH_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _o_2;
      e.mem[_t_1 + 13] = _o_3;
      e.mem[_t_1 + 14] = _b_0;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_clo(FID_TRANSACTION_STORAGE_SET_MAIN0_1_C165, _nd_0);
      return term_tsk(FID_STORAGE_WITH_MAIN, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _o_2;
    r13 = _o_3;
    r14 = _b_0;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_clo(FID_TRANSACTION_STORAGE_SET_MAIN0_1_C165, _nd_0);
    WL_JMP(FID_STORAGE_WITH_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_MAIN0_1_C165)
  {
    u32 _value_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
    Term _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    u32 _f_4 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[6];
    u64 _sp_2 = ctr_take(e, _f_1, 6, _fb_2);
    u32 _f_5 = _fb_2[0];
    u32 _f_6 = _fb_2[1];
    u32 _f_7 = _fb_2[2];
    u32 _f_8 = _fb_2[3];
    u32 _f_9 = _fb_2[4];
    u32 _f_10 = _fb_2[5];
    spare_free(e, cls_fit(6), _sp_2);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    Term _o_1[10];
    if (spin_95(e, _o_1, _f_2, blk_loc(e.mem, _f_2), _f_3, _f_4, _f_5, _f_6, _f_7, _f_8, _f_9, _f_10, _value_1) == 0) {
      return 0;
    }
    _v_0 = _o_1[0];
    _v_1 = _o_1[1];
    _v_2 = _o_1[2];
    _v_3 = _o_1[3];
    _v_4 = _o_1[4];
    _v_5 = _o_1[5];
    _v_6 = _o_1[6];
    _v_7 = _o_1[7];
    _v_8 = _o_1[8];
    _v_9 = _o_1[9];
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_2);
    u64 _nd_2 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_6);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_7);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_8);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_1));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_CACHE_CACHE, _nd_3));
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_9);
    r0 = term_ctr(CID_TUPLE, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_MAIN0_1_K166)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    u32 _r_12 = r12;
    Term _r_13 = r13;
    Term _r_14 = r14;
    u32 _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_4 = 0;
    Term _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    if (_r_12 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _r_13, 2, _fb_3);
      Term _f_11 = _fb_3[0];
      Term _f_12 = _fb_3[1];
      spare_free(e, cls_fit(2), _sp_3);
      Term _fb_4[2];
      u64 _sp_4 = ctr_take(e, _f_11, 2, _fb_4);
      Term _f_13 = _fb_4[0];
      u32 _f_14 = _fb_4[1];
      spare_free(e, cls_fit(2), _sp_4);
      Term _fb_5[5];
      u64 _sp_5 = ctr_take(e, _f_12, 5, _fb_5);
      u32 _f_15 = _fb_5[0];
      u32 _f_16 = _fb_5[1];
      u32 _f_17 = _fb_5[2];
      u32 _f_18 = _fb_5[3];
      u32 _f_19 = _fb_5[4];
      spare_free(e, cls_fit(5), _sp_5);
      _o_5 = _f_13;
      _o_6 = _f_14;
      _o_7 = _f_15;
      _o_8 = _f_16;
      _o_9 = _f_17;
      _o_10 = _f_18;
      _o_11 = _f_19;
    }
    u32 _o_12 = 0;
    if (term_aux(_r_14) == CID_TYPES_HEALTHON) {
      _o_12 = 0;
    } else {
      _o_12 = 1;
    }
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    if (_r_15 == 0) {
      _o_13 = 0;
      _o_14 = _r_16;
    } else if (_r_15 == 1) {
      _o_13 = 1;
    } else {
      _o_13 = 2;
    }
    r0 = _r_0;
    r1 = _r_1;
    r2 = _r_2;
    r3 = _r_3;
    r4 = _r_4;
    r5 = _r_5;
    r6 = _r_6;
    r7 = _r_7;
    r8 = _r_8;
    r9 = _r_9;
    r10 = _r_10;
    r11 = _r_11;
    r12 = _o_4;
    r13 = _o_5;
    r14 = _o_6;
    r15 = _o_7;
    r16 = _o_8;
    r17 = _o_9;
    r18 = _o_10;
    r19 = _o_11;
    r20 = _o_12;
    r21 = _o_13;
    r22 = _o_14;
    WL_RETN(23);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_LEDGER)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    Term _transform_0 = r15;
    WL_OPEN
    if (_world_12 == 0) {
      term_sink(e, _transform_0);
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = 0;
      r13 = 0;
      r14 = _world_14;
      r15 = 0;
      r16 = 0;
      WL_RETN(17);
    } else {
      if (seq) {
        WL_ROOM(14);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_2;
        STK(3) = _world_3;
        STK(4) = _world_4;
        STK(5) = _world_5;
        STK(6) = _world_6;
        STK(7) = _world_7;
        STK(8) = _world_8;
        STK(9) = _world_9;
        STK(10) = _world_10;
        STK(11) = _world_11;
        STK(12) = _world_14;
        STK(13) = FID_STORAGE_WITH_LEDGER_K170;
        WL_PUSHN(14);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_WITH_LEDGER_K170, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_2;
        e.mem[_t_0 + 3] = _world_3;
        e.mem[_t_0 + 4] = _world_4;
        e.mem[_t_0 + 5] = _world_5;
        e.mem[_t_0 + 6] = _world_6;
        e.mem[_t_0 + 7] = _world_7;
        e.mem[_t_0 + 8] = _world_8;
        e.mem[_t_0 + 9] = _world_9;
        e.mem[_t_0 + 10] = _world_10;
        e.mem[_t_0 + 11] = _world_11;
        e.mem[_t_0 + 12] = _world_14;
        WL_CONT = term_tsk(FID_STORAGE_WITH_LEDGER_K170, _t_0);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _transform_0;
        e.mem[_t_1 + 1] = _world_13;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _transform_0;
      r1 = _world_13;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_LEDGER_K170)
  {
    WL_POPN(13);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    Term _world_22 = STK(7);
    u32 _world_23 = STK(8);
    Term _world_24 = STK(9);
    u32 _world_25 = STK(10);
    Term _world_26 = STK(11);
    Term _world_27 = STK(12);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _o_0[17];
    if (spin_96(e, _o_0, _world_15, _world_16, _world_17, blk_loc(e.mem, _world_17), _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, blk_loc(e.mem, _world_21), _world_22, blk_loc(e.mem, _world_22), _world_23, _world_24, _world_25, _world_26, blk_loc(e.mem, _world_26), _world_27, blk_loc(e.mem, _world_27), _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_11)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_11_K183;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_11_K183, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_11_K183, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_11)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_11, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_11, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_11_K183)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_24(e, _o_0, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 376));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 372));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_2 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_24(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _values_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      if (term_aux(_f_0) == CID_TRANSACTION_MAININVERSE) {
        _o_0 = 0;
        u64 _sp_1 = term_peek(e.mem, _f_0);
        Term _f_2 = e.mem[_sp_1 + 0];
        u32 _f_3 = e.mem[_sp_1 + 1];
        u64 _sp_2 = term_peek(e.mem, _f_2);
        u32 _f_4 = e.mem[_sp_2 + 0];
        u32 _f_5 = e.mem[_sp_2 + 1];
        _o_1 = _f_4;
        _o_2 = _f_5;
        _o_3 = _f_3;
      } else {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      }
      if (_o_0 == 0) {
        if (seq) {
          WL_ROOM(3);
          STK(0) = _o_3;
          STK(1) = _f_1;
          STK(2) = FID_UNDO_TEXT_0_K185;
          WL_PUSHN(3);
        } else {
          u64 _t_0 = task_node(e, FID_UNDO_TEXT_0_K185, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_3;
          e.mem[_t_0 + 1] = _f_1;
          WL_CONT = term_tsk(FID_UNDO_TEXT_0_K185, _t_0);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_HEALTH_HANDLE)) {
          u64 _t_1 = task_node(e, FID_HEALTH_HANDLE, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _o_1;
          e.mem[_t_1 + 1] = _o_2;
          return term_tsk(FID_HEALTH_HANDLE, _t_1);
        }
        r0 = _o_1;
        r1 = _o_2;
        WL_JMP(FID_HEALTH_HANDLE);
      } else {
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_UNDO_TEXT_0_K192;
          WL_PUSHN(2);
        } else {
          u64 _t_15 = task_node(e, FID_UNDO_TEXT_0_K192, WL_CONT, WL_IDX, 1);
          e.mem[_t_15 + 0] = _f_1;
          WL_CONT = term_tsk(FID_UNDO_TEXT_0_K192, _t_15);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
          u64 _t_16 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
          e.mem[_t_16 + 0] = _o_1;
          return term_tsk(FID_U32_SHOW, _t_16);
        }
        r0 = _o_1;
        WL_JMP(FID_U32_SHOW);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K185)
  {
    WL_POPN(2);
    u32 _o_4 = STK(0);
    Term _f_6 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_6;
      STK(1) = _h_0;
      STK(2) = FID_UNDO_TEXT_0_K186;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_UNDO_TEXT_0_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_6;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K186, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _o_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _o_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K186)
  {
    WL_POPN(2);
    Term _f_7 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_UNDO_TEXT_0_K187;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_UNDO_TEXT_0_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K187, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_UNDO_TEXT_0)) {
      u64 _t_5 = task_node(e, FID_UNDO_TEXT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_7;
      return term_tsk(FID_UNDO_TEXT_0, _t_5);
    }
    r0 = _f_7;
    WL_JMP(FID_UNDO_TEXT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K187)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_UNDO_TEXT_0_K188;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_UNDO_TEXT_0_K188, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K188, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 378);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 378);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K188)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_UNDO_TEXT_0_K189;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_UNDO_TEXT_0_K189, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K189, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K189)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_UNDO_TEXT_0_K190;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_UNDO_TEXT_0_K190, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K190, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 40);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 40);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K190)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_UNDO_TEXT_0_K191;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_UNDO_TEXT_0_K191, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K191, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_12;
      e.mem[_t_13 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K191)
  {
    Term _h_13 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 380);
      e.mem[_t_14 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 380);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K192)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_14;
      STK(1) = FID_UNDO_TEXT_0_K193;
      WL_PUSHN(2);
    } else {
      u64 _t_17 = task_node(e, FID_UNDO_TEXT_0_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_17 + 0] = _h_14;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K193, _t_17);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_UNDO_TEXT_0)) {
      u64 _t_18 = task_node(e, FID_UNDO_TEXT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _f_8;
      return term_tsk(FID_UNDO_TEXT_0, _t_18);
    }
    r0 = _f_8;
    WL_JMP(FID_UNDO_TEXT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K193)
  {
    WL_POPN(1);
    Term _h_16 = STK(0);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_16;
      STK(1) = FID_UNDO_TEXT_0_K194;
      WL_PUSHN(2);
    } else {
      u64 _t_19 = task_node(e, FID_UNDO_TEXT_0_K194, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _h_16;
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K194, _t_19);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_20 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = term_ctr(CID_SCON, STAT_OFF + 378);
      e.mem[_t_20 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_20);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 378);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K194)
  {
    WL_POPN(1);
    Term _h_18 = STK(0);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_UNDO_TEXT_0_K195;
      WL_PUSHN(1);
    } else {
      u64 _t_21 = task_node(e, FID_UNDO_TEXT_0_K195, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_UNDO_TEXT_0_K195, _t_21);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_22 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _h_18;
      e.mem[_t_22 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_22);
    }
    r0 = _h_18;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_UNDO_TEXT_0_K195)
  {
    Term _h_19 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 382);
      e.mem[_t_23 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 382);
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_HANDLE)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_1;
      STK(1) = FID_HOST_RENDER_RENDER_HANDLE_K198;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_HANDLE_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_HANDLE_K198, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_HANDLE_K198)
  {
    WL_POPN(1);
    u32 _value_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_HANDLE_K199;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_HANDLE_K199, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_HANDLE_K199, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_2;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_HANDLE_K199)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 242));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 404));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_3);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _old_0 = r21;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE_K203;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE_K203, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE_K203, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_STORAGE_SET_LEDGER0_1)) {
      u64 _t_1 = task_node(e, FID_TRANSACTION_STORAGE_SET_LEDGER0_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _world_15;
      e.mem[_t_1 + 16] = _world_16;
      e.mem[_t_1 + 17] = _world_17;
      e.mem[_t_1 + 18] = _world_18;
      e.mem[_t_1 + 19] = _world_19;
      e.mem[_t_1 + 20] = _world_20;
      e.mem[_t_1 + 21] = _old_0;
      return term_tsk(FID_TRANSACTION_STORAGE_SET_LEDGER0_1, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _world_15;
    r16 = _world_16;
    r17 = _world_17;
    r18 = _world_18;
    r19 = _world_19;
    r20 = _world_20;
    r21 = _old_0;
    WL_JMP(FID_TRANSACTION_STORAGE_SET_LEDGER0_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE_K203)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_13);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_14);
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_15);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_16);
      e.mem[_nd_1 + 2] = rfc_seal(e, _h_17);
      e.mem[_nd_1 + 3] = rfc_seal(e, _h_18);
      e.mem[_nd_1 + 4] = rfc_seal(e, _h_19);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    Term _b_0 = 0;
    if (_h_20 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_3 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_3 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_3 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_3 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_3 + 6] = rfc_seal(e, _h_6);
    e.mem[_nd_3 + 7] = rfc_seal(e, _h_7);
    e.mem[_nd_3 + 8] = rfc_seal(e, _h_8);
    e.mem[_nd_3 + 9] = rfc_seal(e, _h_9);
    e.mem[_nd_3 + 10] = rfc_seal(e, _h_10);
    e.mem[_nd_3 + 11] = rfc_seal(e, _h_11);
    e.mem[_nd_3 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_3 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_3 + 14] = rfc_seal(e, _b_0);
    Term _v_0 = 0;
    Term _o_2[1];
    Term _a_0 = term_ctr(CID_STORAGE_WORLD, _nd_3);
    if (spin_87(e, _o_2, _a_0, blk_loc(e.mem, _a_0), _h_21, _h_22) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _v_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_3 = 0;
    Term _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    if (_f_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_13, 2, _fb_1);
      Term _f_15 = _fb_1[0];
      Term _f_16 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_15, 2, _fb_2);
      Term _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _f_16, 5, _fb_3);
      u32 _f_19 = _fb_3[0];
      u32 _f_20 = _fb_3[1];
      u32 _f_21 = _fb_3[2];
      u32 _f_22 = _fb_3[3];
      u32 _f_23 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_4 = _f_17;
      _o_5 = _f_18;
      _o_6 = _f_19;
      _o_7 = _f_20;
      _o_8 = _f_21;
      _o_9 = _f_22;
      _o_10 = _f_23;
    }
    u32 _o_11 = 0;
    if (term_aux(_f_14) == CID_TYPES_HEALTHON) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
    }
    r0 = _f_0;
    r1 = _f_1;
    r2 = _f_2;
    r3 = _f_3;
    r4 = _f_4;
    r5 = _f_5;
    r6 = _f_6;
    r7 = _f_7;
    r8 = _f_8;
    r9 = _f_9;
    r10 = _f_10;
    r11 = _f_11;
    r12 = _o_3;
    r13 = _o_4;
    r14 = _o_5;
    r15 = _o_6;
    r16 = _o_7;
    r17 = _o_8;
    r18 = _o_9;
    r19 = _o_10;
    r20 = _o_11;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _handle_0 = r21;
    u32 _handle_1 = r22;
    u32 _old_0 = r23;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE_K205;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE_K205, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE_K205, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_STORAGE_SET_MAIN0_1)) {
      u64 _t_1 = task_node(e, FID_TRANSACTION_STORAGE_SET_MAIN0_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _world_15;
      e.mem[_t_1 + 16] = _world_16;
      e.mem[_t_1 + 17] = _world_17;
      e.mem[_t_1 + 18] = _world_18;
      e.mem[_t_1 + 19] = _world_19;
      e.mem[_t_1 + 20] = _world_20;
      e.mem[_t_1 + 21] = _handle_0;
      e.mem[_t_1 + 22] = _handle_1;
      e.mem[_t_1 + 23] = _old_0;
      return term_tsk(FID_TRANSACTION_STORAGE_SET_MAIN0_1, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _world_15;
    r16 = _world_16;
    r17 = _world_17;
    r18 = _world_18;
    r19 = _world_19;
    r20 = _world_20;
    r21 = _handle_0;
    r22 = _handle_1;
    r23 = _old_0;
    WL_JMP(FID_TRANSACTION_STORAGE_SET_MAIN0_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE_K205)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_13);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_14);
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_15);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_16);
      e.mem[_nd_1 + 2] = rfc_seal(e, _h_17);
      e.mem[_nd_1 + 3] = rfc_seal(e, _h_18);
      e.mem[_nd_1 + 4] = rfc_seal(e, _h_19);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    Term _b_0 = 0;
    if (_h_20 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_3 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_3 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_3 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_3 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_3 + 6] = rfc_seal(e, _h_6);
    e.mem[_nd_3 + 7] = rfc_seal(e, _h_7);
    e.mem[_nd_3 + 8] = rfc_seal(e, _h_8);
    e.mem[_nd_3 + 9] = rfc_seal(e, _h_9);
    e.mem[_nd_3 + 10] = rfc_seal(e, _h_10);
    e.mem[_nd_3 + 11] = rfc_seal(e, _h_11);
    e.mem[_nd_3 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_3 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_3 + 14] = rfc_seal(e, _b_0);
    Term _v_0 = 0;
    Term _o_2[1];
    Term _a_0 = term_ctr(CID_STORAGE_WORLD, _nd_3);
    if (spin_88(e, _o_2, _a_0, blk_loc(e.mem, _a_0), _h_21, _h_22) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _v_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_3 = 0;
    Term _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    if (_f_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_13, 2, _fb_1);
      Term _f_15 = _fb_1[0];
      Term _f_16 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_15, 2, _fb_2);
      Term _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _f_16, 5, _fb_3);
      u32 _f_19 = _fb_3[0];
      u32 _f_20 = _fb_3[1];
      u32 _f_21 = _fb_3[2];
      u32 _f_22 = _fb_3[3];
      u32 _f_23 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_4 = _f_17;
      _o_5 = _f_18;
      _o_6 = _f_19;
      _o_7 = _f_20;
      _o_8 = _f_21;
      _o_9 = _f_22;
      _o_10 = _f_23;
    }
    u32 _o_11 = 0;
    if (term_aux(_f_14) == CID_TYPES_HEALTHON) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
    }
    r0 = _f_0;
    r1 = _f_1;
    r2 = _f_2;
    r3 = _f_3;
    r4 = _f_4;
    r5 = _f_5;
    r6 = _f_6;
    r7 = _f_7;
    r8 = _f_8;
    r9 = _f_9;
    r10 = _f_10;
    r11 = _f_11;
    r12 = _o_3;
    r13 = _o_4;
    r14 = _o_5;
    r15 = _o_6;
    r16 = _o_7;
    r17 = _o_8;
    r18 = _o_9;
    r19 = _o_10;
    r20 = _o_11;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_0)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 182);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _value_5;
        STK(1) = FID_HOST_RENDER_RENDER_OPTIONAL_0_K213;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_0_K213, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _value_5;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_0_K213, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
        u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_1;
        e.mem[_t_1 + 1] = _value_2;
        e.mem[_t_1 + 2] = _value_3;
        e.mem[_t_1 + 3] = _value_4;
        return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
      }
      r0 = _value_1;
      r1 = _value_2;
      r2 = _value_3;
      r3 = _value_4;
      WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_0_K213)
  {
    WL_POPN(1);
    u32 _value_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_OPTIONAL_0_K214;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_0_K214, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_0_K214, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_6;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_OPTIONAL_0_K214)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 370));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 356));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_3);
    if (spin_24(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_14)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_14_K216;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_14_K216, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_14_K216, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_14)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_14, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_14, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_14_K216)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_24(e, _o_0, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 376));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 372));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_2 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_24(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_13)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_13_K218;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_13_K218, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_13_K218, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_13)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_13, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_13, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_13_K218)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_24(e, _o_0, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 376));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 372));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_2 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_24(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_0[1];
      if (spin_78(e, _o_0, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_0 = _o_0[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_16_K221;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16_K221, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K221, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K221)
  {
    WL_POPN(3);
    Term _f_2 = STK(0);
    Term _acc_1 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _o_1[1];
    if (spin_80(e, _o_1, _h_0, blk_loc(e.mem, _h_0), _acc_1, blk_loc(e.mem, _acc_1), _first_1) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    _v_1 = _v_2;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _v_1;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_2);
    }
    r0 = _f_2;
    r1 = _v_1;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _transform_0 = r17;
    WL_OPEN
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _transform_0);
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = 2;
      r16 = 0;
      WL_RETN(17);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _o_0[1];
      if (spin_43(e, _o_0, U32_BIN(_handle_1, <=, _world_8), U32_BIN(_handle_1, <=, _world_10)) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
      u32 _v_3 = 0;
      Term _o_1[1];
      if (spin_43(e, _o_1, U32_BIN(0ull, <, _handle_1), _v_1) == 0) {
        return 0;
      }
      _v_3 = _o_1[0];
      _v_0 = _v_3;
      if (_v_0 == 0) {
        term_sink(e, _transform_0);
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = 2;
        r16 = 0;
        WL_RETN(17);
      } else {
        u32 _index_0 = U32_BIN(_handle_1, -, 1ull);
        Term _at_0 = blk_loc(e.mem, _world_4);
        Term _at_1 = blk_at(_world_4, _index_0, 0);
        u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
        if (_c_0 == 0) {
          term_sink(e, _transform_0);
          r0 = _world_0;
          r1 = _world_1;
          r2 = _world_2;
          r3 = _world_3;
          r4 = _world_4;
          r5 = _world_5;
          r6 = _world_6;
          r7 = _world_7;
          r8 = _world_8;
          r9 = _world_9;
          r10 = _world_10;
          r11 = _world_11;
          r12 = _world_12;
          r13 = _world_13;
          r14 = _world_14;
          r15 = 2;
          r16 = 0;
          WL_RETN(17);
        } else {
          Term _at_2 = blk_loc(e.mem, _world_2);
          Term _at_3 = blk_at(_world_2, _index_0, 1);
          u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
          Term _c_2 = e.mem[_at_2 + _at_3 + 1];
          blk_write(e.mem, 1, _at_2, _at_3 + 0, 0);
          blk_write(e.mem, 1, _at_2, _at_3 + 1, 0);
          if (_c_1 == 0) {
            term_sink(e, _transform_0);
            r0 = _world_0;
            r1 = _world_1;
            r2 = _world_2;
            r3 = _world_3;
            r4 = _world_4;
            r5 = _world_5;
            r6 = _world_6;
            r7 = _world_7;
            r8 = _world_8;
            r9 = _world_9;
            r10 = _world_10;
            r11 = _world_11;
            r12 = _world_12;
            r13 = _world_13;
            r14 = _world_14;
            r15 = 1;
            r16 = 0;
            WL_RETN(17);
          } else {
            if (seq) {
              WL_ROOM(17);
              STK(0) = _world_0;
              STK(1) = _world_1;
              STK(2) = _world_3;
              STK(3) = _world_4;
              STK(4) = _world_5;
              STK(5) = _world_6;
              STK(6) = _world_7;
              STK(7) = _world_8;
              STK(8) = _world_9;
              STK(9) = _world_10;
              STK(10) = _world_11;
              STK(11) = _world_12;
              STK(12) = _world_13;
              STK(13) = _world_14;
              STK(14) = _index_0;
              STK(15) = _world_2;
              STK(16) = FID_STORAGE_WITH_MAIN_K228;
              WL_PUSHN(17);
            } else {
              u64 _t_0 = task_node(e, FID_STORAGE_WITH_MAIN_K228, WL_CONT, WL_IDX, 1);
              e.mem[_t_0 + 0] = _world_0;
              e.mem[_t_0 + 1] = _world_1;
              e.mem[_t_0 + 2] = _world_3;
              e.mem[_t_0 + 3] = _world_4;
              e.mem[_t_0 + 4] = _world_5;
              e.mem[_t_0 + 5] = _world_6;
              e.mem[_t_0 + 6] = _world_7;
              e.mem[_t_0 + 7] = _world_8;
              e.mem[_t_0 + 8] = _world_9;
              e.mem[_t_0 + 9] = _world_10;
              e.mem[_t_0 + 10] = _world_11;
              e.mem[_t_0 + 11] = _world_12;
              e.mem[_t_0 + 12] = _world_13;
              e.mem[_t_0 + 13] = _world_14;
              e.mem[_t_0 + 14] = _index_0;
              e.mem[_t_0 + 15] = _world_2;
              WL_CONT = term_tsk(FID_STORAGE_WITH_MAIN_K228, _t_0);
              WL_IDX = 16;
            }
            if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
              u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
              e.mem[_t_1 + 0] = _transform_0;
              e.mem[_t_1 + 1] = _c_2;
              return term_tsk(FID_CLO_APPLY, _t_1);
            }
            r0 = _transform_0;
            r1 = _c_2;
            WL_JMP(FID_CLO_APPLY);
          }
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_MAIN_K228)
  {
    WL_POPN(16);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    u32 _world_22 = STK(7);
    Term _world_23 = STK(8);
    u32 _world_24 = STK(9);
    Term _world_25 = STK(10);
    u32 _world_26 = STK(11);
    Term _world_27 = STK(12);
    Term _world_28 = STK(13);
    u32 _index_1 = STK(14);
    Term _world_29 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _o_2[17];
    if (spin_5(e, _o_2, _world_15, _world_16, _world_17, blk_loc(e.mem, _world_17), _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, blk_loc(e.mem, _world_21), _world_22, _world_23, _world_24, _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27, blk_loc(e.mem, _world_27), _world_28, blk_loc(e.mem, _world_28), _world_29, blk_loc(e.mem, _world_29), _index_1, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_4 = _o_2[0];
    _v_5 = _o_2[1];
    _v_6 = _o_2[2];
    _v_7 = _o_2[3];
    _v_8 = _o_2[4];
    _v_9 = _o_2[5];
    _v_10 = _o_2[6];
    _v_11 = _o_2[7];
    _v_12 = _o_2[8];
    _v_13 = _o_2[9];
    _v_14 = _o_2[10];
    _v_15 = _o_2[11];
    _v_16 = _o_2[12];
    _v_17 = _o_2[13];
    _v_18 = _o_2[14];
    _v_19 = _o_2[15];
    _v_20 = _o_2[16];
    r0 = _v_4;
    r1 = _v_5;
    r2 = _v_6;
    r3 = _v_7;
    r4 = _v_8;
    r5 = _v_9;
    r6 = _v_10;
    r7 = _v_11;
    r8 = _v_12;
    r9 = _v_13;
    r10 = _v_14;
    r11 = _v_15;
    r12 = _v_16;
    r13 = _v_17;
    r14 = _v_18;
    r15 = _v_19;
    r16 = _v_20;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0)
  {
    u32 _t_0 = r0;
    u32 _t_1 = r1;
    Term _t_2 = r2;
    Term _t_3 = r3;
    Term _t_4 = r4;
    Term _t_5 = r5;
    Term _t_6 = r6;
    Term _t_7 = r7;
    u32 _t_8 = r8;
    Term _t_9 = r9;
    u32 _t_10 = r10;
    Term _t_11 = r11;
    u32 _t_12 = r12;
    Term _t_13 = r13;
    u32 _t_14 = r14;
    u32 _t_15 = r15;
    u32 _t_16 = r16;
    u32 _t_17 = r17;
    u32 _t_18 = r18;
    u32 _t_19 = r19;
    u32 _t_20 = r20;
    u32 _t_21 = r21;
    u32 _t_22 = r22;
    Term _t_23 = r23;
    Term _t_24 = r24;
    Term _t_25 = r25;
    Term _t_26 = r26;
    u32 _value_0 = r27;
    WL_OPEN
    u32 _o_20 = 0;
    Term _o_21 = 0;
    if (_t_12 == 0) {
      _o_20 = 0;
    } else {
      _o_20 = 1;
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, _t_13);
      e.mem[_nd_7 + 1] = rfc_seal(e, _t_14);
      u64 _nd_8 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_8 + 0] = rfc_seal(e, _t_15);
      e.mem[_nd_8 + 1] = rfc_seal(e, _t_16);
      e.mem[_nd_8 + 2] = rfc_seal(e, _t_17);
      e.mem[_nd_8 + 3] = rfc_seal(e, _t_18);
      e.mem[_nd_8 + 4] = rfc_seal(e, _t_19);
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_7));
      e.mem[_nd_9 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_8));
      _o_21 = term_ctr(CID_CACHE_CACHE, _nd_9);
    }
    Term _b_2 = 0;
    if (_t_20 == 0) {
      _b_2 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_2 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_10 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_10 + 0] = rfc_seal(e, _t_0);
    e.mem[_nd_10 + 1] = rfc_seal(e, _t_1);
    e.mem[_nd_10 + 2] = rfc_seal(e, _t_2);
    e.mem[_nd_10 + 3] = rfc_seal(e, _t_3);
    e.mem[_nd_10 + 4] = rfc_seal(e, _t_4);
    e.mem[_nd_10 + 5] = rfc_seal(e, _t_5);
    e.mem[_nd_10 + 6] = rfc_seal(e, _t_6);
    e.mem[_nd_10 + 7] = rfc_seal(e, _t_7);
    e.mem[_nd_10 + 8] = rfc_seal(e, _t_8);
    e.mem[_nd_10 + 9] = rfc_seal(e, _t_9);
    e.mem[_nd_10 + 10] = rfc_seal(e, _t_10);
    e.mem[_nd_10 + 11] = rfc_seal(e, _t_11);
    e.mem[_nd_10 + 12] = rfc_seal(e, _o_20);
    e.mem[_nd_10 + 13] = rfc_seal(e, _o_21);
    e.mem[_nd_10 + 14] = rfc_seal(e, _b_2);
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, _t_21);
    e.mem[_nd_11 + 1] = rfc_seal(e, _t_22);
    Term _write_0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C241, 0);
    Term _s_0 = term_ctr(CID_STORAGE_WORLD, _nd_10);
    Term _s_1 = term_ctr(CID_STORAGE_HANDLE, _nd_11);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _s_1;
      STK(1) = _t_23;
      STK(2) = _t_24;
      STK(3) = _t_25;
      STK(4) = _t_26;
      STK(5) = _value_0;
      STK(6) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K244;
      WL_PUSHN(7);
    } else {
      u64 _t_29 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K244, WL_CONT, WL_IDX, 1);
      e.mem[_t_29 + 0] = _s_1;
      e.mem[_t_29 + 1] = _t_23;
      e.mem[_t_29 + 2] = _t_24;
      e.mem[_t_29 + 3] = _t_25;
      e.mem[_t_29 + 4] = _t_26;
      e.mem[_t_29 + 5] = _value_0;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K244, _t_29);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_30 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_30 + 0] = _write_0;
      e.mem[_t_30 + 1] = _s_0;
      return term_tsk(FID_CLO_APPLY, _t_30);
    }
    r0 = _write_0;
    r1 = _s_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C241)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _x_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_0 = 0;
    Term _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    if (_f_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_13, 2, _fb_1);
      Term _f_15 = _fb_1[0];
      Term _f_16 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_15, 2, _fb_2);
      Term _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _f_16, 5, _fb_3);
      u32 _f_19 = _fb_3[0];
      u32 _f_20 = _fb_3[1];
      u32 _f_21 = _fb_3[2];
      u32 _f_22 = _fb_3[3];
      u32 _f_23 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_1 = _f_17;
      _o_2 = _f_18;
      _o_3 = _f_19;
      _o_4 = _f_20;
      _o_5 = _f_21;
      _o_6 = _f_22;
      _o_7 = _f_23;
    }
    u32 _o_8 = 0;
    if (term_aux(_f_14) == CID_TYPES_HEALTHON) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(21));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _f_1;
    e.mem[_nd_0 + 2] = _f_2;
    e.mem[_nd_0 + 3] = _f_3;
    e.mem[_nd_0 + 4] = _f_4;
    e.mem[_nd_0 + 5] = _f_5;
    e.mem[_nd_0 + 6] = _f_6;
    e.mem[_nd_0 + 7] = _f_7;
    e.mem[_nd_0 + 8] = _f_8;
    e.mem[_nd_0 + 9] = _f_9;
    e.mem[_nd_0 + 10] = _f_10;
    e.mem[_nd_0 + 11] = _f_11;
    e.mem[_nd_0 + 12] = _o_0;
    e.mem[_nd_0 + 13] = _o_1;
    e.mem[_nd_0 + 14] = _o_2;
    e.mem[_nd_0 + 15] = _o_3;
    e.mem[_nd_0 + 16] = _o_4;
    e.mem[_nd_0 + 17] = _o_5;
    e.mem[_nd_0 + 18] = _o_6;
    e.mem[_nd_0 + 19] = _o_7;
    e.mem[_nd_0 + 20] = _o_8;
    r0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C242, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_C242)
  {
    u32 _f_24 = r0;
    u32 _f_25 = r1;
    Term _f_26 = r2;
    Term _f_27 = r3;
    Term _f_28 = r4;
    Term _f_29 = r5;
    Term _f_30 = r6;
    Term _f_31 = r7;
    u32 _f_32 = r8;
    Term _f_33 = r9;
    u32 _f_34 = r10;
    Term _f_35 = r11;
    u32 _o_9 = r12;
    Term _o_10 = r13;
    u32 _o_11 = r14;
    u32 _o_12 = r15;
    u32 _o_13 = r16;
    u32 _o_14 = r17;
    u32 _o_15 = r18;
    u32 _o_16 = r19;
    u32 _o_17 = r20;
    Term _x_1 = r21;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K243;
      WL_PUSHN(1);
    } else {
      u64 _t_27 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K243, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K243, _t_27);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_STORAGE_SET_LEDGER0_1)) {
      u64 _t_28 = task_node(e, FID_TRANSACTION_STORAGE_SET_LEDGER0_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _f_24;
      e.mem[_t_28 + 1] = _f_25;
      e.mem[_t_28 + 2] = _f_26;
      e.mem[_t_28 + 3] = _f_27;
      e.mem[_t_28 + 4] = _f_28;
      e.mem[_t_28 + 5] = _f_29;
      e.mem[_t_28 + 6] = _f_30;
      e.mem[_t_28 + 7] = _f_31;
      e.mem[_t_28 + 8] = _f_32;
      e.mem[_t_28 + 9] = _f_33;
      e.mem[_t_28 + 10] = _f_34;
      e.mem[_t_28 + 11] = _f_35;
      e.mem[_t_28 + 12] = _o_9;
      e.mem[_t_28 + 13] = _o_10;
      e.mem[_t_28 + 14] = _o_11;
      e.mem[_t_28 + 15] = _o_12;
      e.mem[_t_28 + 16] = _o_13;
      e.mem[_t_28 + 17] = _o_14;
      e.mem[_t_28 + 18] = _o_15;
      e.mem[_t_28 + 19] = _o_16;
      e.mem[_t_28 + 20] = _o_17;
      e.mem[_t_28 + 21] = _x_1;
      return term_tsk(FID_TRANSACTION_STORAGE_SET_LEDGER0_1, _t_28);
    }
    r0 = _f_24;
    r1 = _f_25;
    r2 = _f_26;
    r3 = _f_27;
    r4 = _f_28;
    r5 = _f_29;
    r6 = _f_30;
    r7 = _f_31;
    r8 = _f_32;
    r9 = _f_33;
    r10 = _f_34;
    r11 = _f_35;
    r12 = _o_9;
    r13 = _o_10;
    r14 = _o_11;
    r15 = _o_12;
    r16 = _o_13;
    r17 = _o_14;
    r18 = _o_15;
    r19 = _o_16;
    r20 = _o_17;
    r21 = _x_1;
    WL_JMP(FID_TRANSACTION_STORAGE_SET_LEDGER0_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K243)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    u32 _r_12 = r12;
    Term _r_13 = r13;
    u32 _r_14 = r14;
    u32 _r_15 = r15;
    u32 _r_16 = r16;
    u32 _r_17 = r17;
    u32 _r_18 = r18;
    u32 _r_19 = r19;
    u32 _r_20 = r20;
    u32 _r_21 = r21;
    u32 _r_22 = r22;
    WL_OPEN
    u32 _o_18 = 0;
    Term _o_19 = 0;
    if (_r_12 == 0) {
      _o_18 = 0;
    } else {
      _o_18 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _r_13);
      e.mem[_nd_1 + 1] = rfc_seal(e, _r_14);
      u64 _nd_2 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_2 + 0] = rfc_seal(e, _r_15);
      e.mem[_nd_2 + 1] = rfc_seal(e, _r_16);
      e.mem[_nd_2 + 2] = rfc_seal(e, _r_17);
      e.mem[_nd_2 + 3] = rfc_seal(e, _r_18);
      e.mem[_nd_2 + 4] = rfc_seal(e, _r_19);
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_1));
      e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_2));
      _o_19 = term_ctr(CID_CACHE_CACHE, _nd_3);
    }
    Term _b_0 = 0;
    if (_r_20 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_4 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_4 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_4 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_4 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_4 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_4 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_4 + 8] = rfc_seal(e, _r_8);
    e.mem[_nd_4 + 9] = rfc_seal(e, _r_9);
    e.mem[_nd_4 + 10] = rfc_seal(e, _r_10);
    e.mem[_nd_4 + 11] = rfc_seal(e, _r_11);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_18);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_19);
    e.mem[_nd_4 + 14] = rfc_seal(e, _b_0);
    Term _b_1 = 0;
    if (_r_21 == 0) {
      _b_1 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_5 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_5 + 0] = rfc_seal(e, _r_22);
      _b_1 = term_ctr(CID_SOME, _nd_5);
    }
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_WORLD, _nd_4));
    e.mem[_nd_6 + 1] = rfc_seal(e, _b_1);
    r0 = term_ctr(CID_TUPLE, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K244)
  {
    WL_POPN(6);
    Term _s_2 = STK(0);
    Term _t_31 = STK(1);
    Term _t_32 = STK(2);
    Term _t_33 = STK(3);
    Term _t_34 = STK(4);
    u32 _value_1 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _s_2;
      STK(1) = _t_31;
      STK(2) = _t_32;
      STK(3) = _t_33;
      STK(4) = _t_34;
      STK(5) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K245;
      WL_PUSHN(6);
    } else {
      u64 _t_35 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K245, WL_CONT, WL_IDX, 1);
      e.mem[_t_35 + 0] = _s_2;
      e.mem[_t_35 + 1] = _t_31;
      e.mem[_t_35 + 2] = _t_32;
      e.mem[_t_35 + 3] = _t_33;
      e.mem[_t_35 + 4] = _t_34;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K245, _t_35);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_36 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_36 + 0] = _h_0;
      e.mem[_t_36 + 1] = _value_1;
      return term_tsk(FID_CLO_APPLY, _t_36);
    }
    r0 = _h_0;
    r1 = _value_1;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0_K245)
  {
    WL_POPN(5);
    Term _s_3 = STK(0);
    Term _t_37 = STK(1);
    Term _t_38 = STK(2);
    Term _t_39 = STK(3);
    Term _t_40 = STK(4);
    Term _h_1 = r0;
    WL_OPEN
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _h_1, 2, _fb_4);
    Term _f_36 = _fb_4[0];
    Term _f_37 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    if (term_aux(_f_37) == CID_NONE) {
      _o_22 = 0;
    } else {
      _o_22 = 1;
      Term _fb_5[1];
      u64 _sp_5 = ctr_take(e, _f_37, 1, _fb_5);
      Term _f_38 = _fb_5[0];
      spare_free(e, cls_fit(1), _sp_5);
      _o_23 = _f_38;
    }
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_24[6];
    if (spin_110(e, _o_24, _s_3, blk_loc(e.mem, _s_3), _t_37, blk_loc(e.mem, _t_37), _t_38, blk_loc(e.mem, _t_38), _t_39, blk_loc(e.mem, _t_39), _t_40, blk_loc(e.mem, _t_40), _f_36, blk_loc(e.mem, _f_36), _o_22, _o_23) == 0) {
      return 0;
    }
    _v_0 = _o_24[0];
    _v_1 = _o_24[1];
    _v_2 = _o_24[2];
    _v_3 = _o_24[3];
    _v_4 = _o_24[4];
    _v_5 = _o_24[5];
    Term _fb_6[15];
    u64 _sp_6 = ctr_take(e, _v_0, 15, _fb_6);
    u32 _f_39 = _fb_6[0];
    u32 _f_40 = _fb_6[1];
    Term _f_41 = _fb_6[2];
    Term _f_42 = _fb_6[3];
    Term _f_43 = _fb_6[4];
    Term _f_44 = _fb_6[5];
    Term _f_45 = _fb_6[6];
    Term _f_46 = _fb_6[7];
    u32 _f_47 = _fb_6[8];
    Term _f_48 = _fb_6[9];
    u32 _f_49 = _fb_6[10];
    Term _f_50 = _fb_6[11];
    u32 _f_51 = _fb_6[12];
    Term _f_52 = _fb_6[13];
    Term _f_53 = _fb_6[14];
    spare_free(e, cls_fit(15), _sp_6);
    u32 _o_25 = 0;
    Term _o_26 = 0;
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    if (_f_51 == 0) {
      _o_25 = 0;
    } else {
      _o_25 = 1;
      Term _fb_7[2];
      u64 _sp_7 = ctr_take(e, _f_52, 2, _fb_7);
      Term _f_54 = _fb_7[0];
      Term _f_55 = _fb_7[1];
      spare_free(e, cls_fit(2), _sp_7);
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _f_54, 2, _fb_8);
      Term _f_56 = _fb_8[0];
      u32 _f_57 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      Term _fb_9[5];
      u64 _sp_9 = ctr_take(e, _f_55, 5, _fb_9);
      u32 _f_58 = _fb_9[0];
      u32 _f_59 = _fb_9[1];
      u32 _f_60 = _fb_9[2];
      u32 _f_61 = _fb_9[3];
      u32 _f_62 = _fb_9[4];
      spare_free(e, cls_fit(5), _sp_9);
      _o_26 = _f_56;
      _o_27 = _f_57;
      _o_28 = _f_58;
      _o_29 = _f_59;
      _o_30 = _f_60;
      _o_31 = _f_61;
      _o_32 = _f_62;
    }
    u32 _o_33 = 0;
    if (term_aux(_f_53) == CID_TYPES_HEALTHON) {
      _o_33 = 0;
    } else {
      _o_33 = 1;
    }
    Term _fb_10[2];
    u64 _sp_10 = ctr_take(e, _v_1, 2, _fb_10);
    u32 _f_63 = _fb_10[0];
    u32 _f_64 = _fb_10[1];
    spare_free(e, cls_fit(2), _sp_10);
    r0 = _f_39;
    r1 = _f_40;
    r2 = _f_41;
    r3 = _f_42;
    r4 = _f_43;
    r5 = _f_44;
    r6 = _f_45;
    r7 = _f_46;
    r8 = _f_47;
    r9 = _f_48;
    r10 = _f_49;
    r11 = _f_50;
    r12 = _o_25;
    r13 = _o_26;
    r14 = _o_27;
    r15 = _o_28;
    r16 = _o_29;
    r17 = _o_30;
    r18 = _o_31;
    r19 = _o_32;
    r20 = _o_33;
    r21 = _f_63;
    r22 = _f_64;
    r23 = _v_2;
    r24 = _v_3;
    r25 = _v_4;
    r26 = _v_5;
    WL_RETN(27);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_OBSERVE)
  {
    Term _get_0 = r0;
    Term _owner_0 = r1;
    Term _owner_1 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _owner_1;
      STK(1) = FID_ORIGINAL_RAW_OBSERVER_OBSERVE_K248;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_OBSERVE_K248, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_1;
      WL_CONT = term_tsk(FID_ORIGINAL_RAW_OBSERVER_OBSERVE_K248, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _get_0;
      e.mem[_t_1 + 1] = _owner_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _get_0;
    r1 = _owner_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_OBSERVE_K248)
  {
    WL_POPN(1);
    Term _owner_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _o_0[3];
    if (spin_112(e, _o_0, _owner_2, blk_loc(e.mem, _owner_2), _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_MAYBE_GET_2)
  {
    u32 _owner_0 = r0;
    Term _owner_1 = r1;
    u32 _owner_2 = r2;
    u32 _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    u32 _owner_7 = r7;
    u32 _owner_8 = r8;
    u32 _owner_9 = r9;
    WL_OPEN
    if (_owner_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      WL_RETN(17);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_OBSERVATIONS_MAYBE_GET_2_K250;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_OBSERVATIONS_MAYBE_GET_2_K250, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_OBSERVATIONS_MAYBE_GET_2_K250, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET)) {
        u64 _t_1 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_VITALS_GET, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owner_1;
        e.mem[_t_1 + 1] = _owner_2;
        e.mem[_t_1 + 2] = _owner_3;
        e.mem[_t_1 + 3] = _owner_4;
        e.mem[_t_1 + 4] = _owner_5;
        e.mem[_t_1 + 5] = _owner_6;
        e.mem[_t_1 + 6] = _owner_7;
        e.mem[_t_1 + 7] = _owner_8;
        e.mem[_t_1 + 8] = _owner_9;
        return term_tsk(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET, _t_1);
      }
      r0 = _owner_1;
      r1 = _owner_2;
      r2 = _owner_3;
      r3 = _owner_4;
      r4 = _owner_5;
      r5 = _owner_6;
      r6 = _owner_7;
      r7 = _owner_8;
      r8 = _owner_9;
      WL_JMP(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_MAYBE_GET_2_K250)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_1 + 0] = rfc_seal(e, _h_3);
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_4);
    e.mem[_nd_1 + 2] = rfc_seal(e, _h_5);
    e.mem[_nd_1 + 3] = rfc_seal(e, _h_6);
    e.mem[_nd_1 + 4] = rfc_seal(e, _h_7);
    e.mem[_nd_1 + 5] = rfc_seal(e, _h_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h_9);
    e.mem[_nd_3 + 1] = rfc_seal(e, _h_10);
    e.mem[_nd_3 + 2] = rfc_seal(e, _h_11);
    e.mem[_nd_3 + 3] = rfc_seal(e, _h_12);
    e.mem[_nd_3 + 4] = rfc_seal(e, _h_13);
    e.mem[_nd_3 + 5] = rfc_seal(e, _h_14);
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    Term _a_0 = term_ctr(CID_CACHE_CACHE, _nd_2);
    Term _a_1 = term_ctr(CID_TYPES_VITALSVIEW, _nd_3);
    if (spin_113(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    u32 _o_1 = 0;
    Term _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    if (_v_0 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      Term _fb_2[6];
      u64 _sp_2 = ctr_take(e, _f_1, 6, _fb_2);
      u32 _f_5 = _fb_2[0];
      u32 _f_6 = _fb_2[1];
      u32 _f_7 = _fb_2[2];
      u32 _f_8 = _fb_2[3];
      u32 _f_9 = _fb_2[4];
      u32 _f_10 = _fb_2[5];
      spare_free(e, cls_fit(6), _sp_2);
      _o_2 = _f_2;
      _o_3 = _f_3;
      _o_4 = _f_4;
      _o_5 = _f_5;
      _o_6 = _f_6;
      _o_7 = _f_7;
      _o_8 = _f_8;
      _o_9 = _f_9;
      _o_10 = _f_10;
    }
    u32 _o_11 = 0;
    u32 _o_12 = 0;
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    if (_v_2 == 0) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
      Term _fb_3[6];
      u64 _sp_3 = ctr_take(e, _v_3, 6, _fb_3);
      u32 _f_11 = _fb_3[0];
      u32 _f_12 = _fb_3[1];
      u32 _f_13 = _fb_3[2];
      u32 _f_14 = _fb_3[3];
      u32 _f_15 = _fb_3[4];
      u32 _f_16 = _fb_3[5];
      spare_free(e, cls_fit(6), _sp_3);
      _o_12 = _f_11;
      _o_13 = _f_12;
      _o_14 = _f_13;
      _o_15 = _f_14;
      _o_16 = _f_15;
      _o_17 = _f_16;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    r14 = _o_15;
    r15 = _o_16;
    r16 = _o_17;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_UNWIND_1)
  {
    Term _undo_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    Term _world_2 = r3;
    Term _world_3 = r4;
    Term _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    u32 _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    Term _world_11 = r12;
    u32 _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    u32 _world_16 = r17;
    u32 _world_17 = r18;
    u32 _world_18 = r19;
    u32 _world_19 = r20;
    u32 _world_20 = r21;
    WL_OPEN
    if (term_aux(_undo_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = _world_15;
      r16 = _world_16;
      r17 = _world_17;
      r18 = _world_18;
      r19 = _world_19;
      r20 = _world_20;
      WL_RETN(21);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _undo_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      if (term_aux(_f_0) == CID_TRANSACTION_MAININVERSE) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _f_2, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        _o_1 = _f_4;
        _o_2 = _f_5;
        _o_3 = _f_3;
      } else {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      }
      if (_o_0 == 0) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_TRANSACTION_UNWIND_1_K282;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID_TRANSACTION_UNWIND_1_K282, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          WL_CONT = term_tsk(FID_TRANSACTION_UNWIND_1_K282, _t_0);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE)) {
          u64 _t_1 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _world_0;
          e.mem[_t_1 + 1] = _world_1;
          e.mem[_t_1 + 2] = _world_2;
          e.mem[_t_1 + 3] = _world_3;
          e.mem[_t_1 + 4] = _world_4;
          e.mem[_t_1 + 5] = _world_5;
          e.mem[_t_1 + 6] = _world_6;
          e.mem[_t_1 + 7] = _world_7;
          e.mem[_t_1 + 8] = _world_8;
          e.mem[_t_1 + 9] = _world_9;
          e.mem[_t_1 + 10] = _world_10;
          e.mem[_t_1 + 11] = _world_11;
          e.mem[_t_1 + 12] = _world_12;
          e.mem[_t_1 + 13] = _world_13;
          e.mem[_t_1 + 14] = _world_14;
          e.mem[_t_1 + 15] = _world_15;
          e.mem[_t_1 + 16] = _world_16;
          e.mem[_t_1 + 17] = _world_17;
          e.mem[_t_1 + 18] = _world_18;
          e.mem[_t_1 + 19] = _world_19;
          e.mem[_t_1 + 20] = _world_20;
          e.mem[_t_1 + 21] = _o_1;
          e.mem[_t_1 + 22] = _o_2;
          e.mem[_t_1 + 23] = _o_3;
          return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE, _t_1);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = _world_15;
        r16 = _world_16;
        r17 = _world_17;
        r18 = _world_18;
        r19 = _world_19;
        r20 = _world_20;
        r21 = _o_1;
        r22 = _o_2;
        r23 = _o_3;
        WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_RESTORE);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_TRANSACTION_UNWIND_1_K283;
          WL_PUSHN(2);
        } else {
          u64 _t_3 = task_node(e, FID_TRANSACTION_UNWIND_1_K283, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_1;
          WL_CONT = term_tsk(FID_TRANSACTION_UNWIND_1_K283, _t_3);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE)) {
          u64 _t_4 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _world_0;
          e.mem[_t_4 + 1] = _world_1;
          e.mem[_t_4 + 2] = _world_2;
          e.mem[_t_4 + 3] = _world_3;
          e.mem[_t_4 + 4] = _world_4;
          e.mem[_t_4 + 5] = _world_5;
          e.mem[_t_4 + 6] = _world_6;
          e.mem[_t_4 + 7] = _world_7;
          e.mem[_t_4 + 8] = _world_8;
          e.mem[_t_4 + 9] = _world_9;
          e.mem[_t_4 + 10] = _world_10;
          e.mem[_t_4 + 11] = _world_11;
          e.mem[_t_4 + 12] = _world_12;
          e.mem[_t_4 + 13] = _world_13;
          e.mem[_t_4 + 14] = _world_14;
          e.mem[_t_4 + 15] = _world_15;
          e.mem[_t_4 + 16] = _world_16;
          e.mem[_t_4 + 17] = _world_17;
          e.mem[_t_4 + 18] = _world_18;
          e.mem[_t_4 + 19] = _world_19;
          e.mem[_t_4 + 20] = _world_20;
          e.mem[_t_4 + 21] = _o_1;
          return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE, _t_4);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = _world_15;
        r16 = _world_16;
        r17 = _world_17;
        r18 = _world_18;
        r19 = _world_19;
        r20 = _world_20;
        r21 = _o_1;
        WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_WORLD_LEDGER_RESTORE);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_UNWIND_1_K282)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_UNWIND_1)) {
      u64 _t_2 = task_node(e, FID_TRANSACTION_UNWIND_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      e.mem[_t_2 + 4] = _h_3;
      e.mem[_t_2 + 5] = _h_4;
      e.mem[_t_2 + 6] = _h_5;
      e.mem[_t_2 + 7] = _h_6;
      e.mem[_t_2 + 8] = _h_7;
      e.mem[_t_2 + 9] = _h_8;
      e.mem[_t_2 + 10] = _h_9;
      e.mem[_t_2 + 11] = _h_10;
      e.mem[_t_2 + 12] = _h_11;
      e.mem[_t_2 + 13] = _h_12;
      e.mem[_t_2 + 14] = _h_13;
      e.mem[_t_2 + 15] = _h_14;
      e.mem[_t_2 + 16] = _h_15;
      e.mem[_t_2 + 17] = _h_16;
      e.mem[_t_2 + 18] = _h_17;
      e.mem[_t_2 + 19] = _h_18;
      e.mem[_t_2 + 20] = _h_19;
      e.mem[_t_2 + 21] = _h_20;
      return term_tsk(FID_TRANSACTION_UNWIND_1, _t_2);
    }
    r0 = _f_6;
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _h_5;
    r7 = _h_6;
    r8 = _h_7;
    r9 = _h_8;
    r10 = _h_9;
    r11 = _h_10;
    r12 = _h_11;
    r13 = _h_12;
    r14 = _h_13;
    r15 = _h_14;
    r16 = _h_15;
    r17 = _h_16;
    r18 = _h_17;
    r19 = _h_18;
    r20 = _h_19;
    r21 = _h_20;
    WL_JMP(FID_TRANSACTION_UNWIND_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_UNWIND_1_K283)
  {
    WL_POPN(1);
    Term _f_7 = STK(0);
    u32 _h_21 = r0;
    u32 _h_22 = r1;
    Term _h_23 = r2;
    Term _h_24 = r3;
    Term _h_25 = r4;
    Term _h_26 = r5;
    Term _h_27 = r6;
    Term _h_28 = r7;
    u32 _h_29 = r8;
    Term _h_30 = r9;
    u32 _h_31 = r10;
    Term _h_32 = r11;
    u32 _h_33 = r12;
    Term _h_34 = r13;
    u32 _h_35 = r14;
    u32 _h_36 = r15;
    u32 _h_37 = r16;
    u32 _h_38 = r17;
    u32 _h_39 = r18;
    u32 _h_40 = r19;
    u32 _h_41 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_UNWIND_1)) {
      u64 _t_5 = task_node(e, FID_TRANSACTION_UNWIND_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_7;
      e.mem[_t_5 + 1] = _h_21;
      e.mem[_t_5 + 2] = _h_22;
      e.mem[_t_5 + 3] = _h_23;
      e.mem[_t_5 + 4] = _h_24;
      e.mem[_t_5 + 5] = _h_25;
      e.mem[_t_5 + 6] = _h_26;
      e.mem[_t_5 + 7] = _h_27;
      e.mem[_t_5 + 8] = _h_28;
      e.mem[_t_5 + 9] = _h_29;
      e.mem[_t_5 + 10] = _h_30;
      e.mem[_t_5 + 11] = _h_31;
      e.mem[_t_5 + 12] = _h_32;
      e.mem[_t_5 + 13] = _h_33;
      e.mem[_t_5 + 14] = _h_34;
      e.mem[_t_5 + 15] = _h_35;
      e.mem[_t_5 + 16] = _h_36;
      e.mem[_t_5 + 17] = _h_37;
      e.mem[_t_5 + 18] = _h_38;
      e.mem[_t_5 + 19] = _h_39;
      e.mem[_t_5 + 20] = _h_40;
      e.mem[_t_5 + 21] = _h_41;
      return term_tsk(FID_TRANSACTION_UNWIND_1, _t_5);
    }
    r0 = _f_7;
    r1 = _h_21;
    r2 = _h_22;
    r3 = _h_23;
    r4 = _h_24;
    r5 = _h_25;
    r6 = _h_26;
    r7 = _h_27;
    r8 = _h_28;
    r9 = _h_29;
    r10 = _h_30;
    r11 = _h_31;
    r12 = _h_32;
    r13 = _h_33;
    r14 = _h_34;
    r15 = _h_35;
    r16 = _h_36;
    r17 = _h_37;
    r18 = _h_38;
    r19 = _h_39;
    r20 = _h_40;
    r21 = _h_41;
    WL_JMP(FID_TRANSACTION_UNWIND_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_ROWS_0)
  {
    Term _owners_0 = r0;
    Term _owners_1 = r1;
    Term _owners_2 = r2;
    Term _owners_3 = r3;
    Term _owners_4 = r4;
    Term _owners_5 = r5;
    u32 _owners_6 = r6;
    Term _owners_7 = r7;
    u32 _owners_8 = r8;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[10];
    if (spin_119(e, _o_0, _owners_0, blk_loc(e.mem, _owners_0), _owners_1, blk_loc(e.mem, _owners_1), _owners_2, blk_loc(e.mem, _owners_2), _owners_3, blk_loc(e.mem, _owners_3), _owners_4, blk_loc(e.mem, _owners_4), _owners_5, blk_loc(e.mem, _owners_5), _owners_6, _owners_7, _owners_8) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_15 = _o_0[5];
    _v_16 = _o_0[6];
    _v_17 = _o_0[7];
    _v_18 = _o_0[8];
    _v_19 = _o_0[9];
    _v_0 = _v_10;
    _v_1 = _v_11;
    _v_2 = _v_12;
    _v_3 = _v_13;
    _v_4 = _v_14;
    _v_5 = _v_15;
    _v_6 = _v_16;
    _v_7 = _v_17;
    _v_8 = _v_18;
    _v_9 = _v_19;
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_ROWS_GO_0)) {
      u64 _t_0 = task_node(e, FID_OBSERVATIONS_ROWS_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = ((u64)_v_9);
      e.mem[_t_0 + 1] = 1ull;
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      e.mem[_t_0 + 4] = _v_2;
      e.mem[_t_0 + 5] = _v_3;
      e.mem[_t_0 + 6] = _v_4;
      e.mem[_t_0 + 7] = _v_5;
      e.mem[_t_0 + 8] = _v_6;
      e.mem[_t_0 + 9] = _v_7;
      e.mem[_t_0 + 10] = _v_8;
      e.mem[_t_0 + 11] = term_pak(CID_NIL, 0);
      return term_tsk(FID_OBSERVATIONS_ROWS_GO_0, _t_0);
    }
    r0 = ((u64)_v_9);
    r1 = 1ull;
    r2 = _v_0;
    r3 = _v_1;
    r4 = _v_2;
    r5 = _v_3;
    r6 = _v_4;
    r7 = _v_5;
    r8 = _v_6;
    r9 = _v_7;
    r10 = _v_8;
    r11 = term_pak(CID_NIL, 0);
    WL_JMP(FID_OBSERVATIONS_ROWS_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_WORLD_1)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    Term _value_2 = r2;
    Term _value_3 = r3;
    u32 _value_4 = r4;
    u32 _value_5 = r5;
    u32 _value_6 = r6;
    u32 _value_7 = r7;
    u32 _value_8 = r8;
    u32 _value_9 = r9;
    u32 _value_10 = r10;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = _value_3;
      STK(3) = _value_4;
      STK(4) = _value_5;
      STK(5) = _value_6;
      STK(6) = _value_7;
      STK(7) = _value_8;
      STK(8) = _value_9;
      STK(9) = _value_10;
      STK(10) = FID_HOST_RENDER_RENDER_WORLD_1_K291;
      WL_PUSHN(11);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1_K291, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      e.mem[_t_0 + 2] = _value_3;
      e.mem[_t_0 + 3] = _value_4;
      e.mem[_t_0 + 4] = _value_5;
      e.mem[_t_0 + 5] = _value_6;
      e.mem[_t_0 + 6] = _value_7;
      e.mem[_t_0 + 7] = _value_8;
      e.mem[_t_0 + 8] = _value_9;
      e.mem[_t_0 + 9] = _value_10;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_WORLD_1_K291, _t_0);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_WORLD_1_K291)
  {
    WL_POPN(10);
    u32 _value_11 = STK(0);
    Term _value_12 = STK(1);
    Term _value_13 = STK(2);
    u32 _value_14 = STK(3);
    u32 _value_15 = STK(4);
    u32 _value_16 = STK(5);
    u32 _value_17 = STK(6);
    u32 _value_18 = STK(7);
    u32 _value_19 = STK(8);
    u32 _value_20 = STK(9);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _value_12;
      STK(1) = _value_13;
      STK(2) = _value_14;
      STK(3) = _value_15;
      STK(4) = _value_16;
      STK(5) = _value_17;
      STK(6) = _value_18;
      STK(7) = _value_19;
      STK(8) = _value_20;
      STK(9) = _h_0;
      STK(10) = FID_HOST_RENDER_RENDER_WORLD_1_K292;
      WL_PUSHN(11);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1_K292, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_12;
      e.mem[_t_2 + 1] = _value_13;
      e.mem[_t_2 + 2] = _value_14;
      e.mem[_t_2 + 3] = _value_15;
      e.mem[_t_2 + 4] = _value_16;
      e.mem[_t_2 + 5] = _value_17;
      e.mem[_t_2 + 6] = _value_18;
      e.mem[_t_2 + 7] = _value_19;
      e.mem[_t_2 + 8] = _value_20;
      e.mem[_t_2 + 9] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_WORLD_1_K292, _t_2);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_11;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_11;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_WORLD_1_K292)
  {
    WL_POPN(10);
    Term _value_21 = STK(0);
    Term _value_22 = STK(1);
    u32 _value_23 = STK(2);
    u32 _value_24 = STK(3);
    u32 _value_25 = STK(4);
    u32 _value_26 = STK(5);
    u32 _value_27 = STK(6);
    u32 _value_28 = STK(7);
    u32 _value_29 = STK(8);
    Term _h_2 = STK(9);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _value_22;
      STK(1) = _value_23;
      STK(2) = _value_24;
      STK(3) = _value_25;
      STK(4) = _value_26;
      STK(5) = _value_27;
      STK(6) = _value_28;
      STK(7) = _value_29;
      STK(8) = _h_2;
      STK(9) = _h_1;
      STK(10) = FID_HOST_RENDER_RENDER_WORLD_1_K293;
      WL_PUSHN(11);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1_K293, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_22;
      e.mem[_t_4 + 1] = _value_23;
      e.mem[_t_4 + 2] = _value_24;
      e.mem[_t_4 + 3] = _value_25;
      e.mem[_t_4 + 4] = _value_26;
      e.mem[_t_4 + 5] = _value_27;
      e.mem[_t_4 + 6] = _value_28;
      e.mem[_t_4 + 7] = _value_29;
      e.mem[_t_4 + 8] = _h_2;
      e.mem[_t_4 + 9] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_WORLD_1_K293, _t_4);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_13)) {
      u64 _t_5 = task_node(e, FID_HOST_RENDER_RENDER_LIST_13, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_21;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_13, _t_5);
    }
    r0 = _value_21;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_WORLD_1_K293)
  {
    WL_POPN(10);
    Term _value_30 = STK(0);
    u32 _value_31 = STK(1);
    u32 _value_32 = STK(2);
    u32 _value_33 = STK(3);
    u32 _value_34 = STK(4);
    u32 _value_35 = STK(5);
    u32 _value_36 = STK(6);
    u32 _value_37 = STK(7);
    Term _h_4 = STK(8);
    Term _h_5 = STK(9);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _value_31;
      STK(1) = _value_32;
      STK(2) = _value_33;
      STK(3) = _value_34;
      STK(4) = _value_35;
      STK(5) = _value_36;
      STK(6) = _value_37;
      STK(7) = _h_4;
      STK(8) = _h_5;
      STK(9) = _h_3;
      STK(10) = FID_HOST_RENDER_RENDER_WORLD_1_K294;
      WL_PUSHN(11);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1_K294, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _value_31;
      e.mem[_t_6 + 1] = _value_32;
      e.mem[_t_6 + 2] = _value_33;
      e.mem[_t_6 + 3] = _value_34;
      e.mem[_t_6 + 4] = _value_35;
      e.mem[_t_6 + 5] = _value_36;
      e.mem[_t_6 + 6] = _value_37;
      e.mem[_t_6 + 7] = _h_4;
      e.mem[_t_6 + 8] = _h_5;
      e.mem[_t_6 + 9] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_WORLD_1_K294, _t_6);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_14)) {
      u64 _t_7 = task_node(e, FID_HOST_RENDER_RENDER_LIST_14, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_30;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_14, _t_7);
    }
    r0 = _value_30;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_WORLD_1_K294)
  {
    WL_POPN(10);
    u32 _value_38 = STK(0);
    u32 _value_39 = STK(1);
    u32 _value_40 = STK(2);
    u32 _value_41 = STK(3);
    u32 _value_42 = STK(4);
    u32 _value_43 = STK(5);
    u32 _value_44 = STK(6);
    Term _h_7 = STK(7);
    Term _h_8 = STK(8);
    Term _h_9 = STK(9);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _value_44;
      STK(1) = _h_7;
      STK(2) = _h_8;
      STK(3) = _h_9;
      STK(4) = _h_6;
      STK(5) = FID_HOST_RENDER_RENDER_WORLD_1_K295;
      WL_PUSHN(6);
    } else {
      u64 _t_8 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1_K295, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _value_44;
      e.mem[_t_8 + 1] = _h_7;
      e.mem[_t_8 + 2] = _h_8;
      e.mem[_t_8 + 3] = _h_9;
      e.mem[_t_8 + 4] = _h_6;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_WORLD_1_K295, _t_8);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_OPTIONAL_0)) {
      u64 _t_9 = task_node(e, FID_HOST_RENDER_RENDER_OPTIONAL_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _value_38;
      e.mem[_t_9 + 1] = _value_39;
      e.mem[_t_9 + 2] = _value_40;
      e.mem[_t_9 + 3] = _value_41;
      e.mem[_t_9 + 4] = _value_42;
      e.mem[_t_9 + 5] = _value_43;
      return term_tsk(FID_HOST_RENDER_RENDER_OPTIONAL_0, _t_9);
    }
    r0 = _value_38;
    r1 = _value_39;
    r2 = _value_40;
    r3 = _value_41;
    r4 = _value_42;
    r5 = _value_43;
    WL_JMP(FID_HOST_RENDER_RENDER_OPTIONAL_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_WORLD_1_K295)
  {
    WL_POPN(5);
    u32 _value_45 = STK(0);
    Term _h_11 = STK(1);
    Term _h_12 = STK(2);
    Term _h_13 = STK(3);
    Term _h_14 = STK(4);
    Term _h_10 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_120(e, _o_0, _value_45) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 76));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 626));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_10);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 618));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_14);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 602));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_13);
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_5));
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 586));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _h_12);
    e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_7));
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 576));
    e.mem[_nd_9 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_8));
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, _h_11);
    e.mem[_nd_10 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_9));
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 404));
    e.mem[_nd_11 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_10));
    Term _v_3 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_11);
    if (spin_24(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_1[0];
    r0 = _v_3;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_16_K297;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16_K297, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_16_K297, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16_K297)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_24(e, _o_0, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 376));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 372));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_2 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_24(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K299;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K299, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K299, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K299)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0)
  {
    u32 _t_0 = r0;
    u32 _t_1 = r1;
    Term _t_2 = r2;
    Term _t_3 = r3;
    Term _t_4 = r4;
    Term _t_5 = r5;
    Term _t_6 = r6;
    Term _t_7 = r7;
    u32 _t_8 = r8;
    Term _t_9 = r9;
    u32 _t_10 = r10;
    Term _t_11 = r11;
    u32 _t_12 = r12;
    Term _t_13 = r13;
    u32 _t_14 = r14;
    u32 _t_15 = r15;
    u32 _t_16 = r16;
    u32 _t_17 = r17;
    u32 _t_18 = r18;
    u32 _t_19 = r19;
    u32 _t_20 = r20;
    u32 _t_21 = r21;
    u32 _t_22 = r22;
    Term _t_23 = r23;
    Term _t_24 = r24;
    Term _t_25 = r25;
    Term _t_26 = r26;
    u32 _value_0 = r27;
    WL_OPEN
    u32 _o_29 = 0;
    Term _o_30 = 0;
    if (_t_12 == 0) {
      _o_29 = 0;
    } else {
      _o_29 = 1;
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, _t_13);
      e.mem[_nd_8 + 1] = rfc_seal(e, _t_14);
      u64 _nd_9 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_9 + 0] = rfc_seal(e, _t_15);
      e.mem[_nd_9 + 1] = rfc_seal(e, _t_16);
      e.mem[_nd_9 + 2] = rfc_seal(e, _t_17);
      e.mem[_nd_9 + 3] = rfc_seal(e, _t_18);
      e.mem[_nd_9 + 4] = rfc_seal(e, _t_19);
      u64 _nd_10 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_8));
      e.mem[_nd_10 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_9));
      _o_30 = term_ctr(CID_CACHE_CACHE, _nd_10);
    }
    Term _b_2 = 0;
    if (_t_20 == 0) {
      _b_2 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_2 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_11 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_11 + 0] = rfc_seal(e, _t_0);
    e.mem[_nd_11 + 1] = rfc_seal(e, _t_1);
    e.mem[_nd_11 + 2] = rfc_seal(e, _t_2);
    e.mem[_nd_11 + 3] = rfc_seal(e, _t_3);
    e.mem[_nd_11 + 4] = rfc_seal(e, _t_4);
    e.mem[_nd_11 + 5] = rfc_seal(e, _t_5);
    e.mem[_nd_11 + 6] = rfc_seal(e, _t_6);
    e.mem[_nd_11 + 7] = rfc_seal(e, _t_7);
    e.mem[_nd_11 + 8] = rfc_seal(e, _t_8);
    e.mem[_nd_11 + 9] = rfc_seal(e, _t_9);
    e.mem[_nd_11 + 10] = rfc_seal(e, _t_10);
    e.mem[_nd_11 + 11] = rfc_seal(e, _t_11);
    e.mem[_nd_11 + 12] = rfc_seal(e, _o_29);
    e.mem[_nd_11 + 13] = rfc_seal(e, _o_30);
    e.mem[_nd_11 + 14] = rfc_seal(e, _b_2);
    u64 _nd_12 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_12 + 0] = rfc_seal(e, _t_21);
    e.mem[_nd_12 + 1] = rfc_seal(e, _t_22);
    Term _write_0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C311, 0);
    Term _s_0 = term_ctr(CID_STORAGE_WORLD, _nd_11);
    Term _s_1 = term_ctr(CID_STORAGE_HANDLE, _nd_12);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _s_1;
      STK(1) = _t_23;
      STK(2) = _t_24;
      STK(3) = _t_25;
      STK(4) = _t_26;
      STK(5) = _value_0;
      STK(6) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K315;
      WL_PUSHN(7);
    } else {
      u64 _t_29 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K315, WL_CONT, WL_IDX, 1);
      e.mem[_t_29 + 0] = _s_1;
      e.mem[_t_29 + 1] = _t_23;
      e.mem[_t_29 + 2] = _t_24;
      e.mem[_t_29 + 3] = _t_25;
      e.mem[_t_29 + 4] = _t_26;
      e.mem[_t_29 + 5] = _value_0;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K315, _t_29);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_30 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_30 + 0] = _write_0;
      e.mem[_t_30 + 1] = _s_0;
      return term_tsk(FID_CLO_APPLY, _t_30);
    }
    r0 = _write_0;
    r1 = _s_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C311)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _x_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_0 = 0;
    Term _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    if (_f_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_13, 2, _fb_1);
      Term _f_15 = _fb_1[0];
      Term _f_16 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_15, 2, _fb_2);
      Term _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _f_16, 5, _fb_3);
      u32 _f_19 = _fb_3[0];
      u32 _f_20 = _fb_3[1];
      u32 _f_21 = _fb_3[2];
      u32 _f_22 = _fb_3[3];
      u32 _f_23 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_1 = _f_17;
      _o_2 = _f_18;
      _o_3 = _f_19;
      _o_4 = _f_20;
      _o_5 = _f_21;
      _o_6 = _f_22;
      _o_7 = _f_23;
    }
    u32 _o_8 = 0;
    if (term_aux(_f_14) == CID_TYPES_HEALTHON) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(21));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _f_1;
    e.mem[_nd_0 + 2] = _f_2;
    e.mem[_nd_0 + 3] = _f_3;
    e.mem[_nd_0 + 4] = _f_4;
    e.mem[_nd_0 + 5] = _f_5;
    e.mem[_nd_0 + 6] = _f_6;
    e.mem[_nd_0 + 7] = _f_7;
    e.mem[_nd_0 + 8] = _f_8;
    e.mem[_nd_0 + 9] = _f_9;
    e.mem[_nd_0 + 10] = _f_10;
    e.mem[_nd_0 + 11] = _f_11;
    e.mem[_nd_0 + 12] = _o_0;
    e.mem[_nd_0 + 13] = _o_1;
    e.mem[_nd_0 + 14] = _o_2;
    e.mem[_nd_0 + 15] = _o_3;
    e.mem[_nd_0 + 16] = _o_4;
    e.mem[_nd_0 + 17] = _o_5;
    e.mem[_nd_0 + 18] = _o_6;
    e.mem[_nd_0 + 19] = _o_7;
    e.mem[_nd_0 + 20] = _o_8;
    r0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C312, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C312)
  {
    u32 _f_24 = r0;
    u32 _f_25 = r1;
    Term _f_26 = r2;
    Term _f_27 = r3;
    Term _f_28 = r4;
    Term _f_29 = r5;
    Term _f_30 = r6;
    Term _f_31 = r7;
    u32 _f_32 = r8;
    Term _f_33 = r9;
    u32 _f_34 = r10;
    Term _f_35 = r11;
    u32 _o_9 = r12;
    Term _o_10 = r13;
    u32 _o_11 = r14;
    u32 _o_12 = r15;
    u32 _o_13 = r16;
    u32 _o_14 = r17;
    u32 _o_15 = r18;
    u32 _o_16 = r19;
    u32 _o_17 = r20;
    Term _x_1 = r21;
    WL_OPEN
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _x_1, 2, _fb_4);
    u32 _f_36 = _fb_4[0];
    u32 _f_37 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    u64 _nd_1 = heap_alloc(e, cls_fit(23));
    e.mem[_nd_1 + 0] = _f_24;
    e.mem[_nd_1 + 1] = _f_25;
    e.mem[_nd_1 + 2] = _f_26;
    e.mem[_nd_1 + 3] = _f_27;
    e.mem[_nd_1 + 4] = _f_28;
    e.mem[_nd_1 + 5] = _f_29;
    e.mem[_nd_1 + 6] = _f_30;
    e.mem[_nd_1 + 7] = _f_31;
    e.mem[_nd_1 + 8] = _f_32;
    e.mem[_nd_1 + 9] = _f_33;
    e.mem[_nd_1 + 10] = _f_34;
    e.mem[_nd_1 + 11] = _f_35;
    e.mem[_nd_1 + 12] = _o_9;
    e.mem[_nd_1 + 13] = _o_10;
    e.mem[_nd_1 + 14] = _o_11;
    e.mem[_nd_1 + 15] = _o_12;
    e.mem[_nd_1 + 16] = _o_13;
    e.mem[_nd_1 + 17] = _o_14;
    e.mem[_nd_1 + 18] = _o_15;
    e.mem[_nd_1 + 19] = _o_16;
    e.mem[_nd_1 + 20] = _o_17;
    e.mem[_nd_1 + 21] = _f_36;
    e.mem[_nd_1 + 22] = _f_37;
    r0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C313, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_C313)
  {
    u32 _f_38 = r0;
    u32 _f_39 = r1;
    Term _f_40 = r2;
    Term _f_41 = r3;
    Term _f_42 = r4;
    Term _f_43 = r5;
    Term _f_44 = r6;
    Term _f_45 = r7;
    u32 _f_46 = r8;
    Term _f_47 = r9;
    u32 _f_48 = r10;
    Term _f_49 = r11;
    u32 _o_18 = r12;
    Term _o_19 = r13;
    u32 _o_20 = r14;
    u32 _o_21 = r15;
    u32 _o_22 = r16;
    u32 _o_23 = r17;
    u32 _o_24 = r18;
    u32 _o_25 = r19;
    u32 _o_26 = r20;
    u32 _f_50 = r21;
    u32 _f_51 = r22;
    Term _x_2 = r23;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K314;
      WL_PUSHN(1);
    } else {
      u64 _t_27 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K314, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K314, _t_27);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_STORAGE_SET_MAIN0_1)) {
      u64 _t_28 = task_node(e, FID_TRANSACTION_STORAGE_SET_MAIN0_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _f_38;
      e.mem[_t_28 + 1] = _f_39;
      e.mem[_t_28 + 2] = _f_40;
      e.mem[_t_28 + 3] = _f_41;
      e.mem[_t_28 + 4] = _f_42;
      e.mem[_t_28 + 5] = _f_43;
      e.mem[_t_28 + 6] = _f_44;
      e.mem[_t_28 + 7] = _f_45;
      e.mem[_t_28 + 8] = _f_46;
      e.mem[_t_28 + 9] = _f_47;
      e.mem[_t_28 + 10] = _f_48;
      e.mem[_t_28 + 11] = _f_49;
      e.mem[_t_28 + 12] = _o_18;
      e.mem[_t_28 + 13] = _o_19;
      e.mem[_t_28 + 14] = _o_20;
      e.mem[_t_28 + 15] = _o_21;
      e.mem[_t_28 + 16] = _o_22;
      e.mem[_t_28 + 17] = _o_23;
      e.mem[_t_28 + 18] = _o_24;
      e.mem[_t_28 + 19] = _o_25;
      e.mem[_t_28 + 20] = _o_26;
      e.mem[_t_28 + 21] = _f_50;
      e.mem[_t_28 + 22] = _f_51;
      e.mem[_t_28 + 23] = _x_2;
      return term_tsk(FID_TRANSACTION_STORAGE_SET_MAIN0_1, _t_28);
    }
    r0 = _f_38;
    r1 = _f_39;
    r2 = _f_40;
    r3 = _f_41;
    r4 = _f_42;
    r5 = _f_43;
    r6 = _f_44;
    r7 = _f_45;
    r8 = _f_46;
    r9 = _f_47;
    r10 = _f_48;
    r11 = _f_49;
    r12 = _o_18;
    r13 = _o_19;
    r14 = _o_20;
    r15 = _o_21;
    r16 = _o_22;
    r17 = _o_23;
    r18 = _o_24;
    r19 = _o_25;
    r20 = _o_26;
    r21 = _f_50;
    r22 = _f_51;
    r23 = _x_2;
    WL_JMP(FID_TRANSACTION_STORAGE_SET_MAIN0_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K314)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    u32 _r_12 = r12;
    Term _r_13 = r13;
    u32 _r_14 = r14;
    u32 _r_15 = r15;
    u32 _r_16 = r16;
    u32 _r_17 = r17;
    u32 _r_18 = r18;
    u32 _r_19 = r19;
    u32 _r_20 = r20;
    u32 _r_21 = r21;
    u32 _r_22 = r22;
    WL_OPEN
    u32 _o_27 = 0;
    Term _o_28 = 0;
    if (_r_12 == 0) {
      _o_27 = 0;
    } else {
      _o_27 = 1;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _r_13);
      e.mem[_nd_2 + 1] = rfc_seal(e, _r_14);
      u64 _nd_3 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_3 + 0] = rfc_seal(e, _r_15);
      e.mem[_nd_3 + 1] = rfc_seal(e, _r_16);
      e.mem[_nd_3 + 2] = rfc_seal(e, _r_17);
      e.mem[_nd_3 + 3] = rfc_seal(e, _r_18);
      e.mem[_nd_3 + 4] = rfc_seal(e, _r_19);
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_2));
      e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_3));
      _o_28 = term_ctr(CID_CACHE_CACHE, _nd_4);
    }
    Term _b_0 = 0;
    if (_r_20 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_5 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_5 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_5 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_5 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_5 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_5 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_5 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_5 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_5 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_5 + 8] = rfc_seal(e, _r_8);
    e.mem[_nd_5 + 9] = rfc_seal(e, _r_9);
    e.mem[_nd_5 + 10] = rfc_seal(e, _r_10);
    e.mem[_nd_5 + 11] = rfc_seal(e, _r_11);
    e.mem[_nd_5 + 12] = rfc_seal(e, _o_27);
    e.mem[_nd_5 + 13] = rfc_seal(e, _o_28);
    e.mem[_nd_5 + 14] = rfc_seal(e, _b_0);
    Term _b_1 = 0;
    if (_r_21 == 0) {
      u64 _nd_6 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_6 + 0] = rfc_seal(e, _r_22);
      _b_1 = term_ctr(CID_TYPES_FOUND, _nd_6);
    } else if (_r_21 == 1) {
      _b_1 = term_pak(CID_TYPES_MISMATCH, 0);
    } else {
      _b_1 = term_pak(CID_TYPES_MISSING, 0);
    }
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_WORLD, _nd_5));
    e.mem[_nd_7 + 1] = rfc_seal(e, _b_1);
    r0 = term_ctr(CID_TUPLE, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K315)
  {
    WL_POPN(6);
    Term _s_2 = STK(0);
    Term _t_31 = STK(1);
    Term _t_32 = STK(2);
    Term _t_33 = STK(3);
    Term _t_34 = STK(4);
    u32 _value_1 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    _s_2 = term_keep(e, _s_2, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _s_2;
      STK(1) = _t_31;
      STK(2) = _t_32;
      STK(3) = _t_33;
      STK(4) = _t_34;
      STK(5) = _value_1;
      STK(6) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K316;
      WL_PUSHN(7);
    } else {
      u64 _t_35 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K316, WL_CONT, WL_IDX, 1);
      e.mem[_t_35 + 0] = _s_2;
      e.mem[_t_35 + 1] = _t_31;
      e.mem[_t_35 + 2] = _t_32;
      e.mem[_t_35 + 3] = _t_33;
      e.mem[_t_35 + 4] = _t_34;
      e.mem[_t_35 + 5] = _value_1;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K316, _t_35);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_36 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_36 + 0] = _h_0;
      e.mem[_t_36 + 1] = _s_2;
      return term_tsk(FID_CLO_APPLY, _t_36);
    }
    r0 = _h_0;
    r1 = _s_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K316)
  {
    WL_POPN(6);
    Term _s_3 = STK(0);
    Term _t_37 = STK(1);
    Term _t_38 = STK(2);
    Term _t_39 = STK(3);
    Term _t_40 = STK(4);
    u32 _value_2 = STK(5);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _s_3;
      STK(1) = _t_37;
      STK(2) = _t_38;
      STK(3) = _t_39;
      STK(4) = _t_40;
      STK(5) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K317;
      WL_PUSHN(6);
    } else {
      u64 _t_41 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K317, WL_CONT, WL_IDX, 1);
      e.mem[_t_41 + 0] = _s_3;
      e.mem[_t_41 + 1] = _t_37;
      e.mem[_t_41 + 2] = _t_38;
      e.mem[_t_41 + 3] = _t_39;
      e.mem[_t_41 + 4] = _t_40;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K317, _t_41);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_42 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_42 + 0] = _h_1;
      e.mem[_t_42 + 1] = _value_2;
      return term_tsk(FID_CLO_APPLY, _t_42);
    }
    r0 = _h_1;
    r1 = _value_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0_K317)
  {
    WL_POPN(5);
    Term _s_4 = STK(0);
    Term _t_43 = STK(1);
    Term _t_44 = STK(2);
    Term _t_45 = STK(3);
    Term _t_46 = STK(4);
    Term _h_2 = r0;
    WL_OPEN
    Term _fb_5[2];
    u64 _sp_5 = ctr_take(e, _h_2, 2, _fb_5);
    Term _f_52 = _fb_5[0];
    Term _f_53 = _fb_5[1];
    spare_free(e, cls_fit(2), _sp_5);
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    if (term_aux(_f_53) == CID_TYPES_FOUND) {
      _o_31 = 0;
      Term _fb_6[1];
      u64 _sp_6 = ctr_take(e, _f_53, 1, _fb_6);
      Term _f_54 = _fb_6[0];
      spare_free(e, cls_fit(1), _sp_6);
      _o_32 = _f_54;
    } else if (term_aux(_f_53) == CID_TYPES_MISMATCH) {
      _o_31 = 1;
    } else {
      _o_31 = 2;
    }
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_33[6];
    if (spin_126(e, _o_33, _s_4, blk_loc(e.mem, _s_4), _t_43, blk_loc(e.mem, _t_43), _t_44, blk_loc(e.mem, _t_44), _t_45, blk_loc(e.mem, _t_45), _t_46, blk_loc(e.mem, _t_46), _f_52, blk_loc(e.mem, _f_52), _o_31, _o_32) == 0) {
      return 0;
    }
    _v_0 = _o_33[0];
    _v_1 = _o_33[1];
    _v_2 = _o_33[2];
    _v_3 = _o_33[3];
    _v_4 = _o_33[4];
    _v_5 = _o_33[5];
    Term _fb_7[15];
    u64 _sp_7 = ctr_take(e, _v_0, 15, _fb_7);
    u32 _f_55 = _fb_7[0];
    u32 _f_56 = _fb_7[1];
    Term _f_57 = _fb_7[2];
    Term _f_58 = _fb_7[3];
    Term _f_59 = _fb_7[4];
    Term _f_60 = _fb_7[5];
    Term _f_61 = _fb_7[6];
    Term _f_62 = _fb_7[7];
    u32 _f_63 = _fb_7[8];
    Term _f_64 = _fb_7[9];
    u32 _f_65 = _fb_7[10];
    Term _f_66 = _fb_7[11];
    u32 _f_67 = _fb_7[12];
    Term _f_68 = _fb_7[13];
    Term _f_69 = _fb_7[14];
    spare_free(e, cls_fit(15), _sp_7);
    u32 _o_34 = 0;
    Term _o_35 = 0;
    u32 _o_36 = 0;
    u32 _o_37 = 0;
    u32 _o_38 = 0;
    u32 _o_39 = 0;
    u32 _o_40 = 0;
    u32 _o_41 = 0;
    if (_f_67 == 0) {
      _o_34 = 0;
    } else {
      _o_34 = 1;
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _f_68, 2, _fb_8);
      Term _f_70 = _fb_8[0];
      Term _f_71 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      Term _fb_9[2];
      u64 _sp_9 = ctr_take(e, _f_70, 2, _fb_9);
      Term _f_72 = _fb_9[0];
      u32 _f_73 = _fb_9[1];
      spare_free(e, cls_fit(2), _sp_9);
      Term _fb_10[5];
      u64 _sp_10 = ctr_take(e, _f_71, 5, _fb_10);
      u32 _f_74 = _fb_10[0];
      u32 _f_75 = _fb_10[1];
      u32 _f_76 = _fb_10[2];
      u32 _f_77 = _fb_10[3];
      u32 _f_78 = _fb_10[4];
      spare_free(e, cls_fit(5), _sp_10);
      _o_35 = _f_72;
      _o_36 = _f_73;
      _o_37 = _f_74;
      _o_38 = _f_75;
      _o_39 = _f_76;
      _o_40 = _f_77;
      _o_41 = _f_78;
    }
    u32 _o_42 = 0;
    if (term_aux(_f_69) == CID_TYPES_HEALTHON) {
      _o_42 = 0;
    } else {
      _o_42 = 1;
    }
    Term _fb_11[2];
    u64 _sp_11 = ctr_take(e, _v_1, 2, _fb_11);
    u32 _f_79 = _fb_11[0];
    u32 _f_80 = _fb_11[1];
    spare_free(e, cls_fit(2), _sp_11);
    r0 = _f_55;
    r1 = _f_56;
    r2 = _f_57;
    r3 = _f_58;
    r4 = _f_59;
    r5 = _f_60;
    r6 = _f_61;
    r7 = _f_62;
    r8 = _f_63;
    r9 = _f_64;
    r10 = _f_65;
    r11 = _f_66;
    r12 = _o_34;
    r13 = _o_35;
    r14 = _o_36;
    r15 = _o_37;
    r16 = _o_38;
    r17 = _o_39;
    r18 = _o_40;
    r19 = _o_41;
    r20 = _o_42;
    r21 = _f_79;
    r22 = _f_80;
    r23 = _v_2;
    r24 = _v_3;
    r25 = _v_4;
    r26 = _v_5;
    WL_RETN(27);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER)
  {
    u32 _t_0 = r0;
    u32 _t_1 = r1;
    Term _t_2 = r2;
    Term _t_3 = r3;
    Term _t_4 = r4;
    Term _t_5 = r5;
    Term _t_6 = r6;
    Term _t_7 = r7;
    u32 _t_8 = r8;
    Term _t_9 = r9;
    u32 _t_10 = r10;
    Term _t_11 = r11;
    u32 _t_12 = r12;
    Term _t_13 = r13;
    u32 _t_14 = r14;
    u32 _t_15 = r15;
    u32 _t_16 = r16;
    u32 _t_17 = r17;
    u32 _t_18 = r18;
    u32 _t_19 = r19;
    u32 _t_20 = r20;
    u32 _t_21 = r21;
    u32 _t_22 = r22;
    Term _t_23 = r23;
    Term _t_24 = r24;
    Term _t_25 = r25;
    Term _t_26 = r26;
    WL_OPEN
    u32 _o_12 = 0;
    Term _o_13 = 0;
    if (_t_12 == 0) {
      _o_12 = 0;
    } else {
      _o_12 = 1;
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, _t_13);
      e.mem[_nd_11 + 1] = rfc_seal(e, _t_14);
      u64 _nd_12 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_12 + 0] = rfc_seal(e, _t_15);
      e.mem[_nd_12 + 1] = rfc_seal(e, _t_16);
      e.mem[_nd_12 + 2] = rfc_seal(e, _t_17);
      e.mem[_nd_12 + 3] = rfc_seal(e, _t_18);
      e.mem[_nd_12 + 4] = rfc_seal(e, _t_19);
      u64 _nd_13 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_11));
      e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_12));
      _o_13 = term_ctr(CID_CACHE_CACHE, _nd_13);
    }
    Term _b_2 = 0;
    if (_t_20 == 0) {
      _b_2 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_2 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_14 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_14 + 0] = rfc_seal(e, _t_0);
    e.mem[_nd_14 + 1] = rfc_seal(e, _t_1);
    e.mem[_nd_14 + 2] = rfc_seal(e, _t_2);
    e.mem[_nd_14 + 3] = rfc_seal(e, _t_3);
    e.mem[_nd_14 + 4] = rfc_seal(e, _t_4);
    e.mem[_nd_14 + 5] = rfc_seal(e, _t_5);
    e.mem[_nd_14 + 6] = rfc_seal(e, _t_6);
    e.mem[_nd_14 + 7] = rfc_seal(e, _t_7);
    e.mem[_nd_14 + 8] = rfc_seal(e, _t_8);
    e.mem[_nd_14 + 9] = rfc_seal(e, _t_9);
    e.mem[_nd_14 + 10] = rfc_seal(e, _t_10);
    e.mem[_nd_14 + 11] = rfc_seal(e, _t_11);
    e.mem[_nd_14 + 12] = rfc_seal(e, _o_12);
    e.mem[_nd_14 + 13] = rfc_seal(e, _o_13);
    e.mem[_nd_14 + 14] = rfc_seal(e, _b_2);
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, _t_21);
    e.mem[_nd_15 + 1] = rfc_seal(e, _t_22);
    Term _read_0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C319, 0);
    Term _s_0 = term_ctr(CID_STORAGE_WORLD, _nd_14);
    Term _s_1 = term_ctr(CID_STORAGE_HANDLE, _nd_15);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _s_1;
      STK(1) = _t_23;
      STK(2) = _t_24;
      STK(3) = _t_25;
      STK(4) = _t_26;
      STK(5) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K322;
      WL_PUSHN(6);
    } else {
      u64 _t_29 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K322, WL_CONT, WL_IDX, 1);
      e.mem[_t_29 + 0] = _s_1;
      e.mem[_t_29 + 1] = _t_23;
      e.mem[_t_29 + 2] = _t_24;
      e.mem[_t_29 + 3] = _t_25;
      e.mem[_t_29 + 4] = _t_26;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K322, _t_29);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_30 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_30 + 0] = _read_0;
      e.mem[_t_30 + 1] = _s_0;
      return term_tsk(FID_CLO_APPLY, _t_30);
    }
    r0 = _read_0;
    r1 = _s_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C319)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _x_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_0 = 0;
    Term _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    if (_f_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_13, 2, _fb_1);
      Term _f_15 = _fb_1[0];
      Term _f_16 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_15, 2, _fb_2);
      Term _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _f_16, 5, _fb_3);
      u32 _f_19 = _fb_3[0];
      u32 _f_20 = _fb_3[1];
      u32 _f_21 = _fb_3[2];
      u32 _f_22 = _fb_3[3];
      u32 _f_23 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_1 = _f_17;
      _o_2 = _f_18;
      _o_3 = _f_19;
      _o_4 = _f_20;
      _o_5 = _f_21;
      _o_6 = _f_22;
      _o_7 = _f_23;
    }
    u32 _o_8 = 0;
    if (term_aux(_f_14) == CID_TYPES_HEALTHON) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
    }
    u32 _o_10 = 0;
    Term _o_11 = 0;
    if (_o_0 == 0) {
      _o_10 = 0;
    } else {
      _o_10 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _o_1);
      e.mem[_nd_5 + 1] = rfc_seal(e, _o_2);
      u64 _nd_6 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_6 + 0] = rfc_seal(e, _o_3);
      e.mem[_nd_6 + 1] = rfc_seal(e, _o_4);
      e.mem[_nd_6 + 2] = rfc_seal(e, _o_5);
      e.mem[_nd_6 + 3] = rfc_seal(e, _o_6);
      e.mem[_nd_6 + 4] = rfc_seal(e, _o_7);
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_5));
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_6));
      _o_11 = term_ctr(CID_CACHE_CACHE, _nd_7);
    }
    Term _b_0 = 0;
    if (_o_8 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K321;
      WL_PUSHN(1);
    } else {
      u64 _t_27 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K321, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K321, _t_27);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_LEDGER)) {
      u64 _t_28 = task_node(e, FID_STORAGE_WITH_LEDGER, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _f_0;
      e.mem[_t_28 + 1] = _f_1;
      e.mem[_t_28 + 2] = _f_2;
      e.mem[_t_28 + 3] = _f_3;
      e.mem[_t_28 + 4] = _f_4;
      e.mem[_t_28 + 5] = _f_5;
      e.mem[_t_28 + 6] = _f_6;
      e.mem[_t_28 + 7] = _f_7;
      e.mem[_t_28 + 8] = _f_8;
      e.mem[_t_28 + 9] = _f_9;
      e.mem[_t_28 + 10] = _f_10;
      e.mem[_t_28 + 11] = _f_11;
      e.mem[_t_28 + 12] = _o_10;
      e.mem[_t_28 + 13] = _o_11;
      e.mem[_t_28 + 14] = _b_0;
      e.mem[_t_28 + 15] = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C320, 0);
      return term_tsk(FID_STORAGE_WITH_LEDGER, _t_28);
    }
    r0 = _f_0;
    r1 = _f_1;
    r2 = _f_2;
    r3 = _f_3;
    r4 = _f_4;
    r5 = _f_5;
    r6 = _f_6;
    r7 = _f_7;
    r8 = _f_8;
    r9 = _f_9;
    r10 = _f_10;
    r11 = _f_11;
    r12 = _o_10;
    r13 = _o_11;
    r14 = _b_0;
    r15 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C320, 0);
    WL_JMP(FID_STORAGE_WITH_LEDGER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_C320)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _x_1, 2, _fb_4);
    Term _f_24 = _fb_4[0];
    Term _f_25 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    Term _fb_5[2];
    u64 _sp_5 = ctr_take(e, _f_24, 2, _fb_5);
    Term _f_26 = _fb_5[0];
    u32 _f_27 = _fb_5[1];
    spare_free(e, cls_fit(2), _sp_5);
    Term _fb_6[5];
    u64 _sp_6 = ctr_take(e, _f_25, 5, _fb_6);
    u32 _f_28 = _fb_6[0];
    u32 _f_29 = _fb_6[1];
    u32 _f_30 = _fb_6[2];
    u32 _f_31 = _fb_6[3];
    u32 _f_32 = _fb_6[4];
    spare_free(e, cls_fit(5), _sp_6);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_9[12];
    if (spin_108(e, _o_9, _f_26, blk_loc(e.mem, _f_26), _f_27, _f_28, _f_29, _f_30, _f_31, _f_32) == 0) {
      return 0;
    }
    _v_0 = _o_9[0];
    _v_1 = _o_9[1];
    _v_2 = _o_9[2];
    _v_3 = _o_9[3];
    _v_4 = _o_9[4];
    _v_5 = _o_9[5];
    _v_6 = _o_9[6];
    _v_7 = _o_9[7];
    _v_8 = _o_9[8];
    _v_9 = _o_9[9];
    _v_10 = _o_9[10];
    _v_11 = _o_9[11];
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_1);
    u64 _nd_1 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_2);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_3);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_4);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_5);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_6);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_3 + 0] = rfc_seal(e, _v_7);
    e.mem[_nd_3 + 1] = rfc_seal(e, _v_8);
    e.mem[_nd_3 + 2] = rfc_seal(e, _v_9);
    e.mem[_nd_3 + 3] = rfc_seal(e, _v_10);
    e.mem[_nd_3 + 4] = rfc_seal(e, _v_11);
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_CACHE_CACHE, _nd_2));
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_3));
    r0 = term_ctr(CID_TUPLE, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K321)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    u32 _r_12 = r12;
    Term _r_13 = r13;
    Term _r_14 = r14;
    u32 _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_8 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_8 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_8 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_8 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_8 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_8 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_8 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_8 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_8 + 8] = rfc_seal(e, _r_8);
    e.mem[_nd_8 + 9] = rfc_seal(e, _r_9);
    e.mem[_nd_8 + 10] = rfc_seal(e, _r_10);
    e.mem[_nd_8 + 11] = rfc_seal(e, _r_11);
    e.mem[_nd_8 + 12] = rfc_seal(e, _r_12);
    e.mem[_nd_8 + 13] = rfc_seal(e, _r_13);
    e.mem[_nd_8 + 14] = rfc_seal(e, _r_14);
    Term _b_1 = 0;
    if (_r_15 == 0) {
      _b_1 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_9 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_9 + 0] = rfc_seal(e, _r_16);
      _b_1 = term_ctr(CID_SOME, _nd_9);
    }
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_WORLD, _nd_8));
    e.mem[_nd_10 + 1] = rfc_seal(e, _b_1);
    r0 = term_ctr(CID_TUPLE, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER_K322)
  {
    WL_POPN(5);
    Term _s_2 = STK(0);
    Term _t_31 = STK(1);
    Term _t_32 = STK(2);
    Term _t_33 = STK(3);
    Term _t_34 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_7[2];
    u64 _sp_7 = ctr_take(e, _h_0, 2, _fb_7);
    Term _f_33 = _fb_7[0];
    Term _f_34 = _fb_7[1];
    spare_free(e, cls_fit(2), _sp_7);
    u32 _o_14 = 0;
    Term _o_15 = 0;
    if (term_aux(_f_34) == CID_NONE) {
      _o_14 = 0;
    } else {
      _o_14 = 1;
      Term _fb_8[1];
      u64 _sp_8 = ctr_take(e, _f_34, 1, _fb_8);
      Term _f_35 = _fb_8[0];
      spare_free(e, cls_fit(1), _sp_8);
      _o_15 = _f_35;
    }
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _o_16[8];
    if (spin_127(e, _o_16, _s_2, blk_loc(e.mem, _s_2), _t_31, blk_loc(e.mem, _t_31), _t_32, blk_loc(e.mem, _t_32), _t_33, blk_loc(e.mem, _t_33), _t_34, blk_loc(e.mem, _t_34), _f_33, blk_loc(e.mem, _f_33), _o_14, _o_15, blk_loc(e.mem, _o_15)) == 0) {
      return 0;
    }
    _v_12 = _o_16[0];
    _v_13 = _o_16[1];
    _v_14 = _o_16[2];
    _v_15 = _o_16[3];
    _v_16 = _o_16[4];
    _v_17 = _o_16[5];
    _v_18 = _o_16[6];
    _v_19 = _o_16[7];
    Term _fb_9[15];
    u64 _sp_9 = ctr_take(e, _v_12, 15, _fb_9);
    u32 _f_36 = _fb_9[0];
    u32 _f_37 = _fb_9[1];
    Term _f_38 = _fb_9[2];
    Term _f_39 = _fb_9[3];
    Term _f_40 = _fb_9[4];
    Term _f_41 = _fb_9[5];
    Term _f_42 = _fb_9[6];
    Term _f_43 = _fb_9[7];
    u32 _f_44 = _fb_9[8];
    Term _f_45 = _fb_9[9];
    u32 _f_46 = _fb_9[10];
    Term _f_47 = _fb_9[11];
    u32 _f_48 = _fb_9[12];
    Term _f_49 = _fb_9[13];
    Term _f_50 = _fb_9[14];
    spare_free(e, cls_fit(15), _sp_9);
    u32 _o_17 = 0;
    Term _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    if (_f_48 == 0) {
      _o_17 = 0;
    } else {
      _o_17 = 1;
      Term _fb_10[2];
      u64 _sp_10 = ctr_take(e, _f_49, 2, _fb_10);
      Term _f_51 = _fb_10[0];
      Term _f_52 = _fb_10[1];
      spare_free(e, cls_fit(2), _sp_10);
      Term _fb_11[2];
      u64 _sp_11 = ctr_take(e, _f_51, 2, _fb_11);
      Term _f_53 = _fb_11[0];
      u32 _f_54 = _fb_11[1];
      spare_free(e, cls_fit(2), _sp_11);
      Term _fb_12[5];
      u64 _sp_12 = ctr_take(e, _f_52, 5, _fb_12);
      u32 _f_55 = _fb_12[0];
      u32 _f_56 = _fb_12[1];
      u32 _f_57 = _fb_12[2];
      u32 _f_58 = _fb_12[3];
      u32 _f_59 = _fb_12[4];
      spare_free(e, cls_fit(5), _sp_12);
      _o_18 = _f_53;
      _o_19 = _f_54;
      _o_20 = _f_55;
      _o_21 = _f_56;
      _o_22 = _f_57;
      _o_23 = _f_58;
      _o_24 = _f_59;
    }
    u32 _o_25 = 0;
    if (term_aux(_f_50) == CID_TYPES_HEALTHON) {
      _o_25 = 0;
    } else {
      _o_25 = 1;
    }
    Term _fb_13[2];
    u64 _sp_13 = ctr_take(e, _v_13, 2, _fb_13);
    u32 _f_60 = _fb_13[0];
    u32 _f_61 = _fb_13[1];
    spare_free(e, cls_fit(2), _sp_13);
    u32 _o_26 = 0;
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    if (_v_18 == 0) {
      _o_26 = 0;
    } else {
      _o_26 = 1;
      Term _fb_14[5];
      u64 _sp_14 = ctr_take(e, _v_19, 5, _fb_14);
      u32 _f_62 = _fb_14[0];
      u32 _f_63 = _fb_14[1];
      u32 _f_64 = _fb_14[2];
      u32 _f_65 = _fb_14[3];
      u32 _f_66 = _fb_14[4];
      spare_free(e, cls_fit(5), _sp_14);
      _o_27 = _f_62;
      _o_28 = _f_63;
      _o_29 = _f_64;
      _o_30 = _f_65;
      _o_31 = _f_66;
    }
    r0 = _f_36;
    r1 = _f_37;
    r2 = _f_38;
    r3 = _f_39;
    r4 = _f_40;
    r5 = _f_41;
    r6 = _f_42;
    r7 = _f_43;
    r8 = _f_44;
    r9 = _f_45;
    r10 = _f_46;
    r11 = _f_47;
    r12 = _o_17;
    r13 = _o_18;
    r14 = _o_19;
    r15 = _o_20;
    r16 = _o_21;
    r17 = _o_22;
    r18 = _o_23;
    r19 = _o_24;
    r20 = _o_25;
    r21 = _f_60;
    r22 = _f_61;
    r23 = _v_14;
    r24 = _v_15;
    r25 = _v_16;
    r26 = _v_17;
    r27 = _o_26;
    r28 = _o_27;
    r29 = _o_28;
    r30 = _o_29;
    r31 = _o_30;
    r32 = _o_31;
    WL_RETN(33);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET)
  {
    Term _owner_0 = r0;
    u32 _owner_1 = r1;
    u32 _owner_2 = r2;
    u32 _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    u32 _owner_7 = r7;
    u32 _owner_8 = r8;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_3 + 0] = rfc_seal(e, _owner_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _owner_1);
    e.mem[_nd_3 + 2] = rfc_seal(e, _owner_2);
    u64 _nd_4 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_4 + 0] = rfc_seal(e, _owner_3);
    e.mem[_nd_4 + 1] = rfc_seal(e, _owner_4);
    e.mem[_nd_4 + 2] = rfc_seal(e, _owner_5);
    e.mem[_nd_4 + 3] = rfc_seal(e, _owner_6);
    e.mem[_nd_4 + 4] = rfc_seal(e, _owner_7);
    e.mem[_nd_4 + 5] = rfc_seal(e, _owner_8);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_K328;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_K328, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_K328, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ORIGINAL_RAW_OBSERVER_OBSERVE)) {
      u64 _t_1 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_clo(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_C327, 0);
      e.mem[_t_1 + 1] = term_ctr(CID_TYPES_VITALS, _nd_3);
      e.mem[_t_1 + 2] = term_ctr(CID_TYPES_VITALSVIEW, _nd_4);
      return term_tsk(FID_ORIGINAL_RAW_OBSERVER_OBSERVE, _t_1);
    }
    r0 = term_clo(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_C327, 0);
    r1 = term_ctr(CID_TYPES_VITALS, _nd_3);
    r2 = term_ctr(CID_TYPES_VITALSVIEW, _nd_4);
    WL_JMP(FID_ORIGINAL_RAW_OBSERVER_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_C327)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[3];
    u64 _sp_0 = ctr_take(e, _x_0, 3, _fb_0);
    Term _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_0);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _o_2[9];
    if (spin_128(e, _o_2, _f_0, blk_loc(e.mem, _f_0), _f_1, _f_2) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    _v_7 = _o_2[7];
    _v_8 = _o_2[8];
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_3);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_4);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_5);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_6);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_7);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET_K328)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    WL_OPEN
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _r_0, 3, _fb_1);
    Term _f_3 = _fb_1[0];
    u32 _f_4 = _fb_1[1];
    u32 _f_5 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[6];
    u64 _sp_2 = ctr_take(e, _r_1, 6, _fb_2);
    u32 _f_6 = _fb_2[0];
    u32 _f_7 = _fb_2[1];
    u32 _f_8 = _fb_2[2];
    u32 _f_9 = _fb_2[3];
    u32 _f_10 = _fb_2[4];
    u32 _f_11 = _fb_2[5];
    spare_free(e, cls_fit(6), _sp_2);
    Term _fb_3[6];
    u64 _sp_3 = ctr_take(e, _r_2, 6, _fb_3);
    u32 _f_12 = _fb_3[0];
    u32 _f_13 = _fb_3[1];
    u32 _f_14 = _fb_3[2];
    u32 _f_15 = _fb_3[3];
    u32 _f_16 = _fb_3[4];
    u32 _f_17 = _fb_3[5];
    spare_free(e, cls_fit(6), _sp_3);
    r0 = _f_3;
    r1 = _f_4;
    r2 = _f_5;
    r3 = _f_6;
    r4 = _f_7;
    r5 = _f_8;
    r6 = _f_9;
    r7 = _f_10;
    r8 = _f_11;
    r9 = _f_12;
    r10 = _f_13;
    r11 = _f_14;
    r12 = _f_15;
    r13 = _f_16;
    r14 = _f_17;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_BUNDLE_0)
  {
    u32 _owner_0 = r0;
    Term _owner_1 = r1;
    u32 _owner_2 = r2;
    u32 _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    u32 _owner_7 = r7;
    u32 _owner_8 = r8;
    u32 _owner_9 = r9;
    u32 _owner_10 = r10;
    Term _owner_11 = r11;
    u32 _owner_12 = r12;
    u32 _owner_13 = r13;
    u32 _owner_14 = r14;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _owner_10;
      STK(1) = _owner_11;
      STK(2) = _owner_12;
      STK(3) = _owner_13;
      STK(4) = _owner_14;
      STK(5) = FID_OBSERVATIONS_BUNDLE_0_K331;
      WL_PUSHN(6);
    } else {
      u64 _t_0 = task_node(e, FID_OBSERVATIONS_BUNDLE_0_K331, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_10;
      e.mem[_t_0 + 1] = _owner_11;
      e.mem[_t_0 + 2] = _owner_12;
      e.mem[_t_0 + 3] = _owner_13;
      e.mem[_t_0 + 4] = _owner_14;
      WL_CONT = term_tsk(FID_OBSERVATIONS_BUNDLE_0_K331, _t_0);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_MAYBE_GET_2)) {
      u64 _t_1 = task_node(e, FID_OBSERVATIONS_MAYBE_GET_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      e.mem[_t_1 + 1] = _owner_1;
      e.mem[_t_1 + 2] = _owner_2;
      e.mem[_t_1 + 3] = _owner_3;
      e.mem[_t_1 + 4] = _owner_4;
      e.mem[_t_1 + 5] = _owner_5;
      e.mem[_t_1 + 6] = _owner_6;
      e.mem[_t_1 + 7] = _owner_7;
      e.mem[_t_1 + 8] = _owner_8;
      e.mem[_t_1 + 9] = _owner_9;
      return term_tsk(FID_OBSERVATIONS_MAYBE_GET_2, _t_1);
    }
    r0 = _owner_0;
    r1 = _owner_1;
    r2 = _owner_2;
    r3 = _owner_3;
    r4 = _owner_4;
    r5 = _owner_5;
    r6 = _owner_6;
    r7 = _owner_7;
    r8 = _owner_8;
    r9 = _owner_9;
    WL_JMP(FID_OBSERVATIONS_MAYBE_GET_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_BUNDLE_0_K331)
  {
    WL_POPN(5);
    u32 _owner_15 = STK(0);
    Term _owner_16 = STK(1);
    u32 _owner_17 = STK(2);
    u32 _owner_18 = STK(3);
    u32 _owner_19 = STK(4);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_42[30];
    if (spin_129(e, _o_42, _owner_15, _owner_16, blk_loc(e.mem, _owner_16), _owner_17, _owner_18, _owner_19, _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, _h_4, _h_5, _h_6, _h_7, _h_8, _h_9, _h_10, _h_11, _h_12, _h_13, _h_14, _h_15, _h_16) == 0) {
      return 0;
    }
    _v_0 = _o_42[0];
    _v_1 = _o_42[1];
    _v_2 = _o_42[2];
    _v_3 = _o_42[3];
    _v_4 = _o_42[4];
    _v_5 = _o_42[5];
    _v_6 = _o_42[6];
    _v_7 = _o_42[7];
    _v_8 = _o_42[8];
    _v_9 = _o_42[9];
    _v_10 = _o_42[10];
    _v_11 = _o_42[11];
    _v_12 = _o_42[12];
    _v_13 = _o_42[13];
    _v_14 = _o_42[14];
    _v_15 = _o_42[15];
    _v_16 = _o_42[16];
    _v_17 = _o_42[17];
    _v_18 = _o_42[18];
    _v_19 = _o_42[19];
    _v_20 = _o_42[20];
    _v_21 = _o_42[21];
    _v_22 = _o_42[22];
    _v_23 = _o_42[23];
    _v_24 = _o_42[24];
    _v_25 = _o_42[25];
    _v_26 = _o_42[26];
    _v_27 = _o_42[27];
    _v_28 = _o_42[28];
    _v_29 = _o_42[29];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    r24 = _v_24;
    r25 = _v_25;
    r26 = _v_26;
    r27 = _v_27;
    r28 = _v_28;
    r29 = _v_29;
    WL_RETN(30);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_WORLD_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    Term _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    u32 _owner_8 = r8;
    Term _owner_9 = r9;
    u32 _owner_10 = r10;
    Term _owner_11 = r11;
    u32 _owner_12 = r12;
    Term _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    u32 _owner_17 = r17;
    u32 _owner_18 = r18;
    u32 _owner_19 = r19;
    u32 _owner_20 = r20;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _owner_0;
      STK(1) = _owner_1;
      STK(2) = _owner_11;
      STK(3) = _owner_12;
      STK(4) = _owner_13;
      STK(5) = _owner_14;
      STK(6) = _owner_15;
      STK(7) = _owner_16;
      STK(8) = _owner_17;
      STK(9) = _owner_18;
      STK(10) = _owner_19;
      STK(11) = _owner_20;
      STK(12) = FID_OBSERVATIONS_WORLD_0_K367;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID_OBSERVATIONS_WORLD_0_K367, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_0;
      e.mem[_t_0 + 1] = _owner_1;
      e.mem[_t_0 + 2] = _owner_11;
      e.mem[_t_0 + 3] = _owner_12;
      e.mem[_t_0 + 4] = _owner_13;
      e.mem[_t_0 + 5] = _owner_14;
      e.mem[_t_0 + 6] = _owner_15;
      e.mem[_t_0 + 7] = _owner_16;
      e.mem[_t_0 + 8] = _owner_17;
      e.mem[_t_0 + 9] = _owner_18;
      e.mem[_t_0 + 10] = _owner_19;
      e.mem[_t_0 + 11] = _owner_20;
      WL_CONT = term_tsk(FID_OBSERVATIONS_WORLD_0_K367, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_ROWS_0)) {
      u64 _t_1 = task_node(e, FID_OBSERVATIONS_ROWS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_2;
      e.mem[_t_1 + 1] = _owner_3;
      e.mem[_t_1 + 2] = _owner_4;
      e.mem[_t_1 + 3] = _owner_5;
      e.mem[_t_1 + 4] = _owner_6;
      e.mem[_t_1 + 5] = _owner_7;
      e.mem[_t_1 + 6] = _owner_8;
      e.mem[_t_1 + 7] = _owner_9;
      e.mem[_t_1 + 8] = _owner_10;
      return term_tsk(FID_OBSERVATIONS_ROWS_0, _t_1);
    }
    r0 = _owner_2;
    r1 = _owner_3;
    r2 = _owner_4;
    r3 = _owner_5;
    r4 = _owner_6;
    r5 = _owner_7;
    r6 = _owner_8;
    r7 = _owner_9;
    r8 = _owner_10;
    WL_JMP(FID_OBSERVATIONS_ROWS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_WORLD_0_K367)
  {
    WL_POPN(12);
    u32 _owner_21 = STK(0);
    u32 _owner_22 = STK(1);
    Term _owner_23 = STK(2);
    u32 _owner_24 = STK(3);
    Term _owner_25 = STK(4);
    u32 _owner_26 = STK(5);
    u32 _owner_27 = STK(6);
    u32 _owner_28 = STK(7);
    u32 _owner_29 = STK(8);
    u32 _owner_30 = STK(9);
    u32 _owner_31 = STK(10);
    u32 _owner_32 = STK(11);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _owner_21;
      STK(1) = _owner_22;
      STK(2) = _owner_24;
      STK(3) = _owner_25;
      STK(4) = _owner_26;
      STK(5) = _owner_27;
      STK(6) = _owner_28;
      STK(7) = _owner_29;
      STK(8) = _owner_30;
      STK(9) = _owner_31;
      STK(10) = _owner_32;
      STK(11) = _h_0;
      STK(12) = _h_1;
      STK(13) = _h_2;
      STK(14) = _h_3;
      STK(15) = _h_4;
      STK(16) = _h_5;
      STK(17) = _h_6;
      STK(18) = _h_7;
      STK(19) = _h_8;
      STK(20) = _h_9;
      STK(21) = FID_OBSERVATIONS_WORLD_0_K368;
      WL_PUSHN(22);
    } else {
      u64 _t_2 = task_node(e, FID_OBSERVATIONS_WORLD_0_K368, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_21;
      e.mem[_t_2 + 1] = _owner_22;
      e.mem[_t_2 + 2] = _owner_24;
      e.mem[_t_2 + 3] = _owner_25;
      e.mem[_t_2 + 4] = _owner_26;
      e.mem[_t_2 + 5] = _owner_27;
      e.mem[_t_2 + 6] = _owner_28;
      e.mem[_t_2 + 7] = _owner_29;
      e.mem[_t_2 + 8] = _owner_30;
      e.mem[_t_2 + 9] = _owner_31;
      e.mem[_t_2 + 10] = _owner_32;
      e.mem[_t_2 + 11] = _h_0;
      e.mem[_t_2 + 12] = _h_1;
      e.mem[_t_2 + 13] = _h_2;
      e.mem[_t_2 + 14] = _h_3;
      e.mem[_t_2 + 15] = _h_4;
      e.mem[_t_2 + 16] = _h_5;
      e.mem[_t_2 + 17] = _h_6;
      e.mem[_t_2 + 18] = _h_7;
      e.mem[_t_2 + 19] = _h_8;
      e.mem[_t_2 + 20] = _h_9;
      WL_CONT = term_tsk(FID_OBSERVATIONS_WORLD_0_K368, _t_2);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_COMMANDS_0)) {
      u64 _t_3 = task_node(e, FID_OBSERVATIONS_COMMANDS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _owner_23;
      return term_tsk(FID_OBSERVATIONS_COMMANDS_0, _t_3);
    }
    r0 = _owner_23;
    WL_JMP(FID_OBSERVATIONS_COMMANDS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_WORLD_0_K368)
  {
    WL_POPN(21);
    u32 _owner_33 = STK(0);
    u32 _owner_34 = STK(1);
    u32 _owner_35 = STK(2);
    Term _owner_36 = STK(3);
    u32 _owner_37 = STK(4);
    u32 _owner_38 = STK(5);
    u32 _owner_39 = STK(6);
    u32 _owner_40 = STK(7);
    u32 _owner_41 = STK(8);
    u32 _owner_42 = STK(9);
    u32 _owner_43 = STK(10);
    Term _h_12 = STK(11);
    Term _h_13 = STK(12);
    Term _h_14 = STK(13);
    Term _h_15 = STK(14);
    Term _h_16 = STK(15);
    Term _h_17 = STK(16);
    u32 _h_18 = STK(17);
    Term _h_19 = STK(18);
    u32 _h_20 = STK(19);
    Term _h_21 = STK(20);
    Term _h_10 = r0;
    Term _h_11 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _owner_33;
      STK(1) = _owner_34;
      STK(2) = _h_12;
      STK(3) = _h_13;
      STK(4) = _h_14;
      STK(5) = _h_15;
      STK(6) = _h_16;
      STK(7) = _h_17;
      STK(8) = _h_18;
      STK(9) = _h_19;
      STK(10) = _h_20;
      STK(11) = _h_21;
      STK(12) = _owner_43;
      STK(13) = _h_10;
      STK(14) = _h_11;
      STK(15) = FID_OBSERVATIONS_WORLD_0_K369;
      WL_PUSHN(16);
    } else {
      u64 _t_4 = task_node(e, FID_OBSERVATIONS_WORLD_0_K369, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _owner_33;
      e.mem[_t_4 + 1] = _owner_34;
      e.mem[_t_4 + 2] = _h_12;
      e.mem[_t_4 + 3] = _h_13;
      e.mem[_t_4 + 4] = _h_14;
      e.mem[_t_4 + 5] = _h_15;
      e.mem[_t_4 + 6] = _h_16;
      e.mem[_t_4 + 7] = _h_17;
      e.mem[_t_4 + 8] = _h_18;
      e.mem[_t_4 + 9] = _h_19;
      e.mem[_t_4 + 10] = _h_20;
      e.mem[_t_4 + 11] = _h_21;
      e.mem[_t_4 + 12] = _owner_43;
      e.mem[_t_4 + 13] = _h_10;
      e.mem[_t_4 + 14] = _h_11;
      WL_CONT = term_tsk(FID_OBSERVATIONS_WORLD_0_K369, _t_4);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_MAYBE_GET_0)) {
      u64 _t_5 = task_node(e, FID_OBSERVATIONS_MAYBE_GET_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _owner_35;
      e.mem[_t_5 + 1] = _owner_36;
      e.mem[_t_5 + 2] = _owner_37;
      e.mem[_t_5 + 3] = _owner_38;
      e.mem[_t_5 + 4] = _owner_39;
      e.mem[_t_5 + 5] = _owner_40;
      e.mem[_t_5 + 6] = _owner_41;
      e.mem[_t_5 + 7] = _owner_42;
      return term_tsk(FID_OBSERVATIONS_MAYBE_GET_0, _t_5);
    }
    r0 = _owner_35;
    r1 = _owner_36;
    r2 = _owner_37;
    r3 = _owner_38;
    r4 = _owner_39;
    r5 = _owner_40;
    r6 = _owner_41;
    r7 = _owner_42;
    WL_JMP(FID_OBSERVATIONS_MAYBE_GET_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_WORLD_0_K369)
  {
    WL_POPN(15);
    u32 _owner_44 = STK(0);
    u32 _owner_45 = STK(1);
    Term _h_36 = STK(2);
    Term _h_37 = STK(3);
    Term _h_38 = STK(4);
    Term _h_39 = STK(5);
    Term _h_40 = STK(6);
    Term _h_41 = STK(7);
    u32 _h_42 = STK(8);
    Term _h_43 = STK(9);
    u32 _h_44 = STK(10);
    Term _h_45 = STK(11);
    u32 _owner_46 = STK(12);
    Term _h_46 = STK(13);
    Term _h_47 = STK(14);
    u32 _h_22 = r0;
    Term _h_23 = r1;
    u32 _h_24 = r2;
    u32 _h_25 = r3;
    u32 _h_26 = r4;
    u32 _h_27 = r5;
    u32 _h_28 = r6;
    u32 _h_29 = r7;
    u32 _h_30 = r8;
    u32 _h_31 = r9;
    u32 _h_32 = r10;
    u32 _h_33 = r11;
    u32 _h_34 = r12;
    u32 _h_35 = r13;
    WL_OPEN
    Term _b_0 = 0;
    if (_owner_46 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_22 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_23);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_24);
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_25);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_26);
      e.mem[_nd_1 + 2] = rfc_seal(e, _h_27);
      e.mem[_nd_1 + 3] = rfc_seal(e, _h_28);
      e.mem[_nd_1 + 4] = rfc_seal(e, _h_29);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_h_30 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_3 + 0] = rfc_seal(e, _h_31);
      e.mem[_nd_3 + 1] = rfc_seal(e, _h_32);
      e.mem[_nd_3 + 2] = rfc_seal(e, _h_33);
      e.mem[_nd_3 + 3] = rfc_seal(e, _h_34);
      e.mem[_nd_3 + 4] = rfc_seal(e, _h_35);
      _o_3 = term_ctr(CID_TYPES_LEDGERVIEW, _nd_3);
    }
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _o_4[22];
    if (spin_103(e, _o_4, _owner_44, _owner_45, _h_36, blk_loc(e.mem, _h_36), _h_37, blk_loc(e.mem, _h_37), _h_38, blk_loc(e.mem, _h_38), _h_39, blk_loc(e.mem, _h_39), _h_40, blk_loc(e.mem, _h_40), _h_41, blk_loc(e.mem, _h_41), _h_42, _h_43, _h_44, _h_45, blk_loc(e.mem, _h_45), _h_46, blk_loc(e.mem, _h_46), _h_47, blk_loc(e.mem, _h_47), _b_0, blk_loc(e.mem, _b_0), _o_0, _o_1, blk_loc(e.mem, _o_1), _o_2, _o_3, blk_loc(e.mem, _o_3)) == 0) {
      return 0;
    }
    _v_0 = _o_4[0];
    _v_1 = _o_4[1];
    _v_2 = _o_4[2];
    _v_3 = _o_4[3];
    _v_4 = _o_4[4];
    _v_5 = _o_4[5];
    _v_6 = _o_4[6];
    _v_7 = _o_4[7];
    _v_8 = _o_4[8];
    _v_9 = _o_4[9];
    _v_10 = _o_4[10];
    _v_11 = _o_4[11];
    _v_12 = _o_4[12];
    _v_13 = _o_4[13];
    _v_14 = _o_4[14];
    _v_15 = _o_4[15];
    _v_16 = _o_4[16];
    _v_17 = _o_4[17];
    _v_18 = _o_4[18];
    _v_19 = _o_4[19];
    _v_20 = _o_4[20];
    _v_21 = _o_4[21];
    u32 _o_5 = 0;
    Term _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    u32 _o_12 = 0;
    if (_v_12 == 0) {
      _o_5 = 0;
    } else {
      _o_5 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_13, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[5];
      u64 _sp_2 = ctr_take(e, _f_1, 5, _fb_2);
      u32 _f_4 = _fb_2[0];
      u32 _f_5 = _fb_2[1];
      u32 _f_6 = _fb_2[2];
      u32 _f_7 = _fb_2[3];
      u32 _f_8 = _fb_2[4];
      spare_free(e, cls_fit(5), _sp_2);
      _o_6 = _f_2;
      _o_7 = _f_3;
      _o_8 = _f_4;
      _o_9 = _f_5;
      _o_10 = _f_6;
      _o_11 = _f_7;
      _o_12 = _f_8;
    }
    u32 _o_13 = 0;
    if (term_aux(_v_14) == CID_TYPES_HEALTHON) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
    }
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    if (_v_19 == 0) {
      _o_14 = 0;
    } else {
      _o_14 = 1;
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _v_20, 5, _fb_3);
      u32 _f_9 = _fb_3[0];
      u32 _f_10 = _fb_3[1];
      u32 _f_11 = _fb_3[2];
      u32 _f_12 = _fb_3[3];
      u32 _f_13 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_15 = _f_9;
      _o_16 = _f_10;
      _o_17 = _f_11;
      _o_18 = _f_12;
      _o_19 = _f_13;
    }
    u32 _o_20 = 0;
    if (term_aux(_v_21) == CID_TYPES_HEALTHON) {
      _o_20 = 0;
    } else {
      _o_20 = 1;
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _o_5;
    r13 = _o_6;
    r14 = _o_7;
    r15 = _o_8;
    r16 = _o_9;
    r17 = _o_10;
    r18 = _o_11;
    r19 = _o_12;
    r20 = _o_13;
    r21 = _v_15;
    r22 = _v_16;
    r23 = _v_17;
    r24 = _v_18;
    r25 = _o_14;
    r26 = _o_15;
    r27 = _o_16;
    r28 = _o_17;
    r29 = _o_18;
    r30 = _o_19;
    r31 = _o_20;
    WL_RETN(32);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN)
  {
    u32 _t_0 = r0;
    u32 _t_1 = r1;
    Term _t_2 = r2;
    Term _t_3 = r3;
    Term _t_4 = r4;
    Term _t_5 = r5;
    Term _t_6 = r6;
    Term _t_7 = r7;
    u32 _t_8 = r8;
    Term _t_9 = r9;
    u32 _t_10 = r10;
    Term _t_11 = r11;
    u32 _t_12 = r12;
    Term _t_13 = r13;
    u32 _t_14 = r14;
    u32 _t_15 = r15;
    u32 _t_16 = r16;
    u32 _t_17 = r17;
    u32 _t_18 = r18;
    u32 _t_19 = r19;
    u32 _t_20 = r20;
    u32 _t_21 = r21;
    u32 _t_22 = r22;
    Term _t_23 = r23;
    Term _t_24 = r24;
    Term _t_25 = r25;
    Term _t_26 = r26;
    WL_OPEN
    u32 _o_21 = 0;
    Term _o_22 = 0;
    if (_t_12 == 0) {
      _o_21 = 0;
    } else {
      _o_21 = 1;
      u64 _nd_12 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_12 + 0] = rfc_seal(e, _t_13);
      e.mem[_nd_12 + 1] = rfc_seal(e, _t_14);
      u64 _nd_13 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_13 + 0] = rfc_seal(e, _t_15);
      e.mem[_nd_13 + 1] = rfc_seal(e, _t_16);
      e.mem[_nd_13 + 2] = rfc_seal(e, _t_17);
      e.mem[_nd_13 + 3] = rfc_seal(e, _t_18);
      e.mem[_nd_13 + 4] = rfc_seal(e, _t_19);
      u64 _nd_14 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_14 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_12));
      e.mem[_nd_14 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_13));
      _o_22 = term_ctr(CID_CACHE_CACHE, _nd_14);
    }
    Term _b_2 = 0;
    if (_t_20 == 0) {
      _b_2 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_2 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_15 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_15 + 0] = rfc_seal(e, _t_0);
    e.mem[_nd_15 + 1] = rfc_seal(e, _t_1);
    e.mem[_nd_15 + 2] = rfc_seal(e, _t_2);
    e.mem[_nd_15 + 3] = rfc_seal(e, _t_3);
    e.mem[_nd_15 + 4] = rfc_seal(e, _t_4);
    e.mem[_nd_15 + 5] = rfc_seal(e, _t_5);
    e.mem[_nd_15 + 6] = rfc_seal(e, _t_6);
    e.mem[_nd_15 + 7] = rfc_seal(e, _t_7);
    e.mem[_nd_15 + 8] = rfc_seal(e, _t_8);
    e.mem[_nd_15 + 9] = rfc_seal(e, _t_9);
    e.mem[_nd_15 + 10] = rfc_seal(e, _t_10);
    e.mem[_nd_15 + 11] = rfc_seal(e, _t_11);
    e.mem[_nd_15 + 12] = rfc_seal(e, _o_21);
    e.mem[_nd_15 + 13] = rfc_seal(e, _o_22);
    e.mem[_nd_15 + 14] = rfc_seal(e, _b_2);
    u64 _nd_16 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_16 + 0] = rfc_seal(e, _t_21);
    e.mem[_nd_16 + 1] = rfc_seal(e, _t_22);
    Term _read_0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C380, 0);
    Term _s_0 = term_ctr(CID_STORAGE_WORLD, _nd_15);
    Term _s_1 = term_ctr(CID_STORAGE_HANDLE, _nd_16);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _s_1;
      STK(1) = _t_23;
      STK(2) = _t_24;
      STK(3) = _t_25;
      STK(4) = _t_26;
      STK(5) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K384;
      WL_PUSHN(6);
    } else {
      u64 _t_29 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K384, WL_CONT, WL_IDX, 1);
      e.mem[_t_29 + 0] = _s_1;
      e.mem[_t_29 + 1] = _t_23;
      e.mem[_t_29 + 2] = _t_24;
      e.mem[_t_29 + 3] = _t_25;
      e.mem[_t_29 + 4] = _t_26;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K384, _t_29);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_30 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_30 + 0] = _read_0;
      e.mem[_t_30 + 1] = _s_0;
      return term_tsk(FID_CLO_APPLY, _t_30);
    }
    r0 = _read_0;
    r1 = _s_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C380)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _x_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_0 = 0;
    Term _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    if (_f_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_13, 2, _fb_1);
      Term _f_15 = _fb_1[0];
      Term _f_16 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_15, 2, _fb_2);
      Term _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[5];
      u64 _sp_3 = ctr_take(e, _f_16, 5, _fb_3);
      u32 _f_19 = _fb_3[0];
      u32 _f_20 = _fb_3[1];
      u32 _f_21 = _fb_3[2];
      u32 _f_22 = _fb_3[3];
      u32 _f_23 = _fb_3[4];
      spare_free(e, cls_fit(5), _sp_3);
      _o_1 = _f_17;
      _o_2 = _f_18;
      _o_3 = _f_19;
      _o_4 = _f_20;
      _o_5 = _f_21;
      _o_6 = _f_22;
      _o_7 = _f_23;
    }
    u32 _o_8 = 0;
    if (term_aux(_f_14) == CID_TYPES_HEALTHON) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(21));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _f_1;
    e.mem[_nd_0 + 2] = _f_2;
    e.mem[_nd_0 + 3] = _f_3;
    e.mem[_nd_0 + 4] = _f_4;
    e.mem[_nd_0 + 5] = _f_5;
    e.mem[_nd_0 + 6] = _f_6;
    e.mem[_nd_0 + 7] = _f_7;
    e.mem[_nd_0 + 8] = _f_8;
    e.mem[_nd_0 + 9] = _f_9;
    e.mem[_nd_0 + 10] = _f_10;
    e.mem[_nd_0 + 11] = _f_11;
    e.mem[_nd_0 + 12] = _o_0;
    e.mem[_nd_0 + 13] = _o_1;
    e.mem[_nd_0 + 14] = _o_2;
    e.mem[_nd_0 + 15] = _o_3;
    e.mem[_nd_0 + 16] = _o_4;
    e.mem[_nd_0 + 17] = _o_5;
    e.mem[_nd_0 + 18] = _o_6;
    e.mem[_nd_0 + 19] = _o_7;
    e.mem[_nd_0 + 20] = _o_8;
    r0 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C381, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C381)
  {
    u32 _f_24 = r0;
    u32 _f_25 = r1;
    Term _f_26 = r2;
    Term _f_27 = r3;
    Term _f_28 = r4;
    Term _f_29 = r5;
    Term _f_30 = r6;
    Term _f_31 = r7;
    u32 _f_32 = r8;
    Term _f_33 = r9;
    u32 _f_34 = r10;
    Term _f_35 = r11;
    u32 _o_9 = r12;
    Term _o_10 = r13;
    u32 _o_11 = r14;
    u32 _o_12 = r15;
    u32 _o_13 = r16;
    u32 _o_14 = r17;
    u32 _o_15 = r18;
    u32 _o_16 = r19;
    u32 _o_17 = r20;
    Term _x_1 = r21;
    WL_OPEN
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _x_1, 2, _fb_4);
    u32 _f_36 = _fb_4[0];
    u32 _f_37 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    u32 _o_19 = 0;
    Term _o_20 = 0;
    if (_o_9 == 0) {
      _o_19 = 0;
    } else {
      _o_19 = 1;
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, _o_10);
      e.mem[_nd_6 + 1] = rfc_seal(e, _o_11);
      u64 _nd_7 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_7 + 0] = rfc_seal(e, _o_12);
      e.mem[_nd_7 + 1] = rfc_seal(e, _o_13);
      e.mem[_nd_7 + 2] = rfc_seal(e, _o_14);
      e.mem[_nd_7 + 3] = rfc_seal(e, _o_15);
      e.mem[_nd_7 + 4] = rfc_seal(e, _o_16);
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_6));
      e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_7));
      _o_20 = term_ctr(CID_CACHE_CACHE, _nd_8);
    }
    Term _b_0 = 0;
    if (_o_17 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K383;
      WL_PUSHN(1);
    } else {
      u64 _t_27 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K383, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K383, _t_27);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_MAIN)) {
      u64 _t_28 = task_node(e, FID_STORAGE_WITH_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _f_24;
      e.mem[_t_28 + 1] = _f_25;
      e.mem[_t_28 + 2] = _f_26;
      e.mem[_t_28 + 3] = _f_27;
      e.mem[_t_28 + 4] = _f_28;
      e.mem[_t_28 + 5] = _f_29;
      e.mem[_t_28 + 6] = _f_30;
      e.mem[_t_28 + 7] = _f_31;
      e.mem[_t_28 + 8] = _f_32;
      e.mem[_t_28 + 9] = _f_33;
      e.mem[_t_28 + 10] = _f_34;
      e.mem[_t_28 + 11] = _f_35;
      e.mem[_t_28 + 12] = _o_19;
      e.mem[_t_28 + 13] = _o_20;
      e.mem[_t_28 + 14] = _b_0;
      e.mem[_t_28 + 15] = _f_36;
      e.mem[_t_28 + 16] = _f_37;
      e.mem[_t_28 + 17] = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C382, 0);
      return term_tsk(FID_STORAGE_WITH_MAIN, _t_28);
    }
    r0 = _f_24;
    r1 = _f_25;
    r2 = _f_26;
    r3 = _f_27;
    r4 = _f_28;
    r5 = _f_29;
    r6 = _f_30;
    r7 = _f_31;
    r8 = _f_32;
    r9 = _f_33;
    r10 = _f_34;
    r11 = _f_35;
    r12 = _o_19;
    r13 = _o_20;
    r14 = _b_0;
    r15 = _f_36;
    r16 = _f_37;
    r17 = term_clo(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C382, 0);
    WL_JMP(FID_STORAGE_WITH_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_C382)
  {
    Term _x_2 = r0;
    WL_OPEN
    Term _fb_5[2];
    u64 _sp_5 = ctr_take(e, _x_2, 2, _fb_5);
    Term _f_38 = _fb_5[0];
    Term _f_39 = _fb_5[1];
    spare_free(e, cls_fit(2), _sp_5);
    Term _fb_6[3];
    u64 _sp_6 = ctr_take(e, _f_38, 3, _fb_6);
    Term _f_40 = _fb_6[0];
    u32 _f_41 = _fb_6[1];
    u32 _f_42 = _fb_6[2];
    spare_free(e, cls_fit(3), _sp_6);
    Term _fb_7[6];
    u64 _sp_7 = ctr_take(e, _f_39, 6, _fb_7);
    u32 _f_43 = _fb_7[0];
    u32 _f_44 = _fb_7[1];
    u32 _f_45 = _fb_7[2];
    u32 _f_46 = _fb_7[3];
    u32 _f_47 = _fb_7[4];
    u32 _f_48 = _fb_7[5];
    spare_free(e, cls_fit(6), _sp_7);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_18[15];
    if (spin_124(e, _o_18, _f_40, blk_loc(e.mem, _f_40), _f_41, _f_42, _f_43, _f_44, _f_45, _f_46, _f_47, _f_48) == 0) {
      return 0;
    }
    _v_0 = _o_18[0];
    _v_1 = _o_18[1];
    _v_2 = _o_18[2];
    _v_3 = _o_18[3];
    _v_4 = _o_18[4];
    _v_5 = _o_18[5];
    _v_6 = _o_18[6];
    _v_7 = _o_18[7];
    _v_8 = _o_18[8];
    _v_9 = _o_18[9];
    _v_10 = _o_18[10];
    _v_11 = _o_18[11];
    _v_12 = _o_18[12];
    _v_13 = _o_18[13];
    _v_14 = _o_18[14];
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_2);
    u64 _nd_2 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_6);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_7);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_8);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_1));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_4 + 0] = rfc_seal(e, _v_9);
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_10);
    e.mem[_nd_4 + 2] = rfc_seal(e, _v_11);
    e.mem[_nd_4 + 3] = rfc_seal(e, _v_12);
    e.mem[_nd_4 + 4] = rfc_seal(e, _v_13);
    e.mem[_nd_4 + 5] = rfc_seal(e, _v_14);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_CACHE_CACHE, _nd_3));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_4));
    r0 = term_ctr(CID_TUPLE, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K383)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    u32 _r_12 = r12;
    Term _r_13 = r13;
    Term _r_14 = r14;
    u32 _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_9 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_9 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_9 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_9 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_9 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_9 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_9 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_9 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_9 + 8] = rfc_seal(e, _r_8);
    e.mem[_nd_9 + 9] = rfc_seal(e, _r_9);
    e.mem[_nd_9 + 10] = rfc_seal(e, _r_10);
    e.mem[_nd_9 + 11] = rfc_seal(e, _r_11);
    e.mem[_nd_9 + 12] = rfc_seal(e, _r_12);
    e.mem[_nd_9 + 13] = rfc_seal(e, _r_13);
    e.mem[_nd_9 + 14] = rfc_seal(e, _r_14);
    Term _b_1 = 0;
    if (_r_15 == 0) {
      u64 _nd_10 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_10 + 0] = rfc_seal(e, _r_16);
      _b_1 = term_ctr(CID_TYPES_FOUND, _nd_10);
    } else if (_r_15 == 1) {
      _b_1 = term_pak(CID_TYPES_MISMATCH, 0);
    } else {
      _b_1 = term_pak(CID_TYPES_MISSING, 0);
    }
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_WORLD, _nd_9));
    e.mem[_nd_11 + 1] = rfc_seal(e, _b_1);
    r0 = term_ctr(CID_TUPLE, _nd_11);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K384)
  {
    WL_POPN(5);
    Term _s_2 = STK(0);
    Term _t_31 = STK(1);
    Term _t_32 = STK(2);
    Term _t_33 = STK(3);
    Term _t_34 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    _s_2 = term_keep(e, _s_2, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _s_2;
      STK(1) = _t_31;
      STK(2) = _t_32;
      STK(3) = _t_33;
      STK(4) = _t_34;
      STK(5) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K385;
      WL_PUSHN(6);
    } else {
      u64 _t_35 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K385, WL_CONT, WL_IDX, 1);
      e.mem[_t_35 + 0] = _s_2;
      e.mem[_t_35 + 1] = _t_31;
      e.mem[_t_35 + 2] = _t_32;
      e.mem[_t_35 + 3] = _t_33;
      e.mem[_t_35 + 4] = _t_34;
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K385, _t_35);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_36 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_36 + 0] = _h_0;
      e.mem[_t_36 + 1] = _s_2;
      return term_tsk(FID_CLO_APPLY, _t_36);
    }
    r0 = _h_0;
    r1 = _s_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN_K385)
  {
    WL_POPN(5);
    Term _s_3 = STK(0);
    Term _t_37 = STK(1);
    Term _t_38 = STK(2);
    Term _t_39 = STK(3);
    Term _t_40 = STK(4);
    Term _h_1 = r0;
    WL_OPEN
    Term _fb_8[2];
    u64 _sp_8 = ctr_take(e, _h_1, 2, _fb_8);
    Term _f_49 = _fb_8[0];
    Term _f_50 = _fb_8[1];
    spare_free(e, cls_fit(2), _sp_8);
    u32 _o_23 = 0;
    Term _o_24 = 0;
    if (term_aux(_f_50) == CID_TYPES_FOUND) {
      _o_23 = 0;
      Term _fb_9[1];
      u64 _sp_9 = ctr_take(e, _f_50, 1, _fb_9);
      Term _f_51 = _fb_9[0];
      spare_free(e, cls_fit(1), _sp_9);
      _o_24 = _f_51;
    } else if (term_aux(_f_50) == CID_TYPES_MISMATCH) {
      _o_23 = 1;
    } else {
      _o_23 = 2;
    }
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _v_22 = 0;
    Term _o_25[8];
    if (spin_139(e, _o_25, _s_3, blk_loc(e.mem, _s_3), _t_37, blk_loc(e.mem, _t_37), _t_38, blk_loc(e.mem, _t_38), _t_39, blk_loc(e.mem, _t_39), _t_40, blk_loc(e.mem, _t_40), _f_49, blk_loc(e.mem, _f_49), _o_23, _o_24, blk_loc(e.mem, _o_24)) == 0) {
      return 0;
    }
    _v_15 = _o_25[0];
    _v_16 = _o_25[1];
    _v_17 = _o_25[2];
    _v_18 = _o_25[3];
    _v_19 = _o_25[4];
    _v_20 = _o_25[5];
    _v_21 = _o_25[6];
    _v_22 = _o_25[7];
    Term _fb_10[15];
    u64 _sp_10 = ctr_take(e, _v_15, 15, _fb_10);
    u32 _f_52 = _fb_10[0];
    u32 _f_53 = _fb_10[1];
    Term _f_54 = _fb_10[2];
    Term _f_55 = _fb_10[3];
    Term _f_56 = _fb_10[4];
    Term _f_57 = _fb_10[5];
    Term _f_58 = _fb_10[6];
    Term _f_59 = _fb_10[7];
    u32 _f_60 = _fb_10[8];
    Term _f_61 = _fb_10[9];
    u32 _f_62 = _fb_10[10];
    Term _f_63 = _fb_10[11];
    u32 _f_64 = _fb_10[12];
    Term _f_65 = _fb_10[13];
    Term _f_66 = _fb_10[14];
    spare_free(e, cls_fit(15), _sp_10);
    u32 _o_26 = 0;
    Term _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    if (_f_64 == 0) {
      _o_26 = 0;
    } else {
      _o_26 = 1;
      Term _fb_11[2];
      u64 _sp_11 = ctr_take(e, _f_65, 2, _fb_11);
      Term _f_67 = _fb_11[0];
      Term _f_68 = _fb_11[1];
      spare_free(e, cls_fit(2), _sp_11);
      Term _fb_12[2];
      u64 _sp_12 = ctr_take(e, _f_67, 2, _fb_12);
      Term _f_69 = _fb_12[0];
      u32 _f_70 = _fb_12[1];
      spare_free(e, cls_fit(2), _sp_12);
      Term _fb_13[5];
      u64 _sp_13 = ctr_take(e, _f_68, 5, _fb_13);
      u32 _f_71 = _fb_13[0];
      u32 _f_72 = _fb_13[1];
      u32 _f_73 = _fb_13[2];
      u32 _f_74 = _fb_13[3];
      u32 _f_75 = _fb_13[4];
      spare_free(e, cls_fit(5), _sp_13);
      _o_27 = _f_69;
      _o_28 = _f_70;
      _o_29 = _f_71;
      _o_30 = _f_72;
      _o_31 = _f_73;
      _o_32 = _f_74;
      _o_33 = _f_75;
    }
    u32 _o_34 = 0;
    if (term_aux(_f_66) == CID_TYPES_HEALTHON) {
      _o_34 = 0;
    } else {
      _o_34 = 1;
    }
    Term _fb_14[2];
    u64 _sp_14 = ctr_take(e, _v_16, 2, _fb_14);
    u32 _f_76 = _fb_14[0];
    u32 _f_77 = _fb_14[1];
    spare_free(e, cls_fit(2), _sp_14);
    u32 _o_35 = 0;
    u32 _o_36 = 0;
    u32 _o_37 = 0;
    u32 _o_38 = 0;
    u32 _o_39 = 0;
    u32 _o_40 = 0;
    u32 _o_41 = 0;
    if (_v_21 == 0) {
      _o_35 = 0;
      Term _fb_15[6];
      u64 _sp_15 = ctr_take(e, _v_22, 6, _fb_15);
      u32 _f_78 = _fb_15[0];
      u32 _f_79 = _fb_15[1];
      u32 _f_80 = _fb_15[2];
      u32 _f_81 = _fb_15[3];
      u32 _f_82 = _fb_15[4];
      u32 _f_83 = _fb_15[5];
      spare_free(e, cls_fit(6), _sp_15);
      _o_36 = _f_78;
      _o_37 = _f_79;
      _o_38 = _f_80;
      _o_39 = _f_81;
      _o_40 = _f_82;
      _o_41 = _f_83;
    } else if (_v_21 == 1) {
      _o_35 = 1;
    } else {
      _o_35 = 2;
    }
    r0 = _f_52;
    r1 = _f_53;
    r2 = _f_54;
    r3 = _f_55;
    r4 = _f_56;
    r5 = _f_57;
    r6 = _f_58;
    r7 = _f_59;
    r8 = _f_60;
    r9 = _f_61;
    r10 = _f_62;
    r11 = _f_63;
    r12 = _o_26;
    r13 = _o_27;
    r14 = _o_28;
    r15 = _o_29;
    r16 = _o_30;
    r17 = _o_31;
    r18 = _o_32;
    r19 = _o_33;
    r20 = _o_34;
    r21 = _f_76;
    r22 = _f_77;
    r23 = _v_17;
    r24 = _v_18;
    r25 = _v_19;
    r26 = _v_20;
    r27 = _o_35;
    r28 = _o_36;
    r29 = _o_37;
    r30 = _o_38;
    r31 = _o_39;
    r32 = _o_40;
    r33 = _o_41;
    WL_RETN(34);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_COMMAND_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    u32 _owner_4 = r4;
    u32 _owner_5 = r5;
    u32 _owner_6 = r6;
    u32 _owner_7 = r7;
    u32 _owner_8 = r8;
    u32 _owner_9 = r9;
    u32 _owner_10 = r10;
    u32 _owner_11 = r11;
    u32 _owner_12 = r12;
    Term _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    WL_OPEN
    if (_owner_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _owner_1;
        STK(1) = FID_OBSERVATIONS_COMMAND_0_K391;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_OBSERVATIONS_COMMAND_0_K391, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _owner_1;
        WL_CONT = term_tsk(FID_OBSERVATIONS_COMMAND_0_K391, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_BUNDLE_0)) {
        u64 _t_1 = task_node(e, FID_OBSERVATIONS_BUNDLE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owner_2;
        e.mem[_t_1 + 1] = _owner_3;
        e.mem[_t_1 + 2] = _owner_4;
        e.mem[_t_1 + 3] = _owner_5;
        e.mem[_t_1 + 4] = _owner_6;
        e.mem[_t_1 + 5] = _owner_7;
        e.mem[_t_1 + 6] = _owner_8;
        e.mem[_t_1 + 7] = _owner_9;
        e.mem[_t_1 + 8] = _owner_10;
        e.mem[_t_1 + 9] = _owner_11;
        e.mem[_t_1 + 10] = _owner_12;
        e.mem[_t_1 + 11] = _owner_13;
        e.mem[_t_1 + 12] = _owner_14;
        e.mem[_t_1 + 13] = _owner_15;
        e.mem[_t_1 + 14] = _owner_16;
        return term_tsk(FID_OBSERVATIONS_BUNDLE_0, _t_1);
      }
      r0 = _owner_2;
      r1 = _owner_3;
      r2 = _owner_4;
      r3 = _owner_5;
      r4 = _owner_6;
      r5 = _owner_7;
      r6 = _owner_8;
      r7 = _owner_9;
      r8 = _owner_10;
      r9 = _owner_11;
      r10 = _owner_12;
      r11 = _owner_13;
      r12 = _owner_14;
      r13 = _owner_15;
      r14 = _owner_16;
      WL_JMP(FID_OBSERVATIONS_BUNDLE_0);
    } else if (_owner_0 == 1) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _owner_1;
        STK(1) = FID_OBSERVATIONS_COMMAND_0_K392;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID_OBSERVATIONS_COMMAND_0_K392, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _owner_1;
        WL_CONT = term_tsk(FID_OBSERVATIONS_COMMAND_0_K392, _t_2);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET)) {
        u64 _t_3 = task_node(e, FID_ORIGINAL_RAW_OBSERVER_VITALS_GET, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _owner_2;
        e.mem[_t_3 + 1] = _owner_3;
        e.mem[_t_3 + 2] = _owner_4;
        e.mem[_t_3 + 3] = _owner_5;
        e.mem[_t_3 + 4] = _owner_6;
        e.mem[_t_3 + 5] = _owner_7;
        e.mem[_t_3 + 6] = _owner_8;
        e.mem[_t_3 + 7] = _owner_9;
        e.mem[_t_3 + 8] = _owner_10;
        return term_tsk(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET, _t_3);
      }
      r0 = _owner_2;
      r1 = _owner_3;
      r2 = _owner_4;
      r3 = _owner_5;
      r4 = _owner_6;
      r5 = _owner_7;
      r6 = _owner_8;
      r7 = _owner_9;
      r8 = _owner_10;
      WL_JMP(FID_ORIGINAL_RAW_OBSERVER_VITALS_GET);
    } else if (_owner_0 == 2) {
      r0 = 2;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 2;
      r18 = _owner_1;
      r19 = _owner_2;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      r26 = 0;
      r27 = 0;
      r28 = 0;
      r29 = 0;
      r30 = 0;
      r31 = 0;
      r32 = 0;
      r33 = 0;
      WL_RETN(34);
    } else if (_owner_0 == 3) {
      r0 = 3;
      r1 = _owner_1;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 3;
      r18 = _owner_1;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      r26 = 0;
      r27 = 0;
      r28 = 0;
      r29 = 0;
      r30 = 0;
      r31 = 0;
      r32 = 0;
      r33 = 0;
      WL_RETN(34);
    } else if (_owner_0 == 4) {
      r0 = 4;
      r1 = _owner_1;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 4;
      r18 = _owner_1;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      r26 = 0;
      r27 = 0;
      r28 = 0;
      r29 = 0;
      r30 = 0;
      r31 = 0;
      r32 = 0;
      r33 = 0;
      WL_RETN(34);
    } else {
      r0 = 5;
      r1 = _owner_1;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 5;
      r18 = _owner_1;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      r26 = 0;
      r27 = 0;
      r28 = 0;
      r29 = 0;
      r30 = 0;
      r31 = 0;
      r32 = 0;
      r33 = 0;
      WL_RETN(34);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_COMMAND_0_K391)
  {
    WL_POPN(1);
    u32 _owner_17 = STK(0);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    u32 _h_27 = r27;
    u32 _h_28 = r28;
    u32 _h_29 = r29;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_0 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_2);
      e.mem[_nd_0 + 2] = rfc_seal(e, _h_3);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_4);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_5);
      e.mem[_nd_1 + 2] = rfc_seal(e, _h_6);
      e.mem[_nd_1 + 3] = rfc_seal(e, _h_7);
      e.mem[_nd_1 + 4] = rfc_seal(e, _h_8);
      e.mem[_nd_1 + 5] = rfc_seal(e, _h_9);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_h_10 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _h_11);
      e.mem[_nd_3 + 1] = rfc_seal(e, _h_12);
      _o_3 = term_ctr(CID_TYPES_ARMOR, _nd_3);
    }
    u32 _o_4 = 0;
    Term _o_5 = 0;
    if (_h_13 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_TYPES_TRACKED, _h_14);
    }
    u32 _o_6 = 0;
    Term _o_7 = 0;
    if (_h_15 == 0) {
      _o_6 = 0;
    } else {
      _o_6 = 1;
      u64 _nd_4 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_4 + 0] = rfc_seal(e, _h_16);
      e.mem[_nd_4 + 1] = rfc_seal(e, _h_17);
      e.mem[_nd_4 + 2] = rfc_seal(e, _h_18);
      e.mem[_nd_4 + 3] = rfc_seal(e, _h_19);
      e.mem[_nd_4 + 4] = rfc_seal(e, _h_20);
      e.mem[_nd_4 + 5] = rfc_seal(e, _h_21);
      _o_7 = term_ctr(CID_TYPES_VITALSVIEW, _nd_4);
    }
    u32 _o_8 = 0;
    Term _o_9 = 0;
    if (_h_22 == 0) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_5 + 0] = rfc_seal(e, _h_23);
      e.mem[_nd_5 + 1] = rfc_seal(e, _h_24);
      e.mem[_nd_5 + 2] = rfc_seal(e, _h_25);
      e.mem[_nd_5 + 3] = rfc_seal(e, _h_26);
      e.mem[_nd_5 + 4] = rfc_seal(e, _h_27);
      _o_9 = term_ctr(CID_TYPES_ARMORVIEW, _nd_5);
    }
    u32 _o_10 = 0;
    Term _o_11 = 0;
    if (_h_28 == 0) {
      _o_10 = 0;
    } else {
      _o_10 = 1;
      _o_11 = term_pak(CID_TYPES_TRACKED, _h_29);
    }
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    Term _o_12[16];
    if (spin_140(e, _o_12, _owner_17, _o_0, _o_1, blk_loc(e.mem, _o_1), _o_2, _o_3, blk_loc(e.mem, _o_3), _o_4, _o_5, blk_loc(e.mem, _o_5), _o_6, _o_7, blk_loc(e.mem, _o_7), _o_8, _o_9, blk_loc(e.mem, _o_9), _o_10, _o_11, blk_loc(e.mem, _o_11)) == 0) {
      return 0;
    }
    _v_0 = _o_12[0];
    _v_1 = _o_12[1];
    _v_2 = _o_12[2];
    _v_3 = _o_12[3];
    _v_4 = _o_12[4];
    _v_5 = _o_12[5];
    _v_6 = _o_12[6];
    _v_7 = _o_12[7];
    _v_8 = _o_12[8];
    _v_9 = _o_12[9];
    _v_10 = _o_12[10];
    _v_11 = _o_12[11];
    _v_12 = _o_12[12];
    _v_13 = _o_12[13];
    _v_14 = _o_12[14];
    _v_15 = _o_12[15];
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    u32 _o_25 = 0;
    Term _o_26 = 0;
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    if (_v_0 == 0) {
      _o_13 = 0;
      u32 _o_30 = 0;
      Term _o_31 = 0;
      u32 _o_32 = 0;
      u32 _o_33 = 0;
      u32 _o_34 = 0;
      u32 _o_35 = 0;
      u32 _o_36 = 0;
      u32 _o_37 = 0;
      u32 _o_38 = 0;
      u32 _o_39 = 0;
      if (_v_2 == 0) {
        _o_30 = 0;
      } else {
        _o_30 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _v_3, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        u32 _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        Term _fb_2[6];
        u64 _sp_2 = ctr_take(e, _f_1, 6, _fb_2);
        u32 _f_5 = _fb_2[0];
        u32 _f_6 = _fb_2[1];
        u32 _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        u32 _f_9 = _fb_2[4];
        u32 _f_10 = _fb_2[5];
        spare_free(e, cls_fit(6), _sp_2);
        _o_31 = _f_2;
        _o_32 = _f_3;
        _o_33 = _f_4;
        _o_34 = _f_5;
        _o_35 = _f_6;
        _o_36 = _f_7;
        _o_37 = _f_8;
        _o_38 = _f_9;
        _o_39 = _f_10;
      }
      u32 _o_40 = 0;
      Term _o_41 = 0;
      u32 _o_42 = 0;
      if (_v_4 == 0) {
        _o_40 = 0;
      } else {
        _o_40 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _v_5, 2, _fb_3);
        Term _f_11 = _fb_3[0];
        u32 _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_41 = _f_11;
        _o_42 = _f_12;
      }
      u32 _o_43 = 0;
      u32 _o_44 = 0;
      if (_v_6 == 0) {
        _o_43 = 0;
      } else {
        _o_43 = 1;
        _o_44 = term_loc(_v_7);
      }
      _o_14 = _v_1;
      _o_15 = _o_30;
      _o_16 = _o_31;
      _o_17 = _o_32;
      _o_18 = _o_33;
      _o_19 = _o_34;
      _o_20 = _o_35;
      _o_21 = _o_36;
      _o_22 = _o_37;
      _o_23 = _o_38;
      _o_24 = _o_39;
      _o_25 = _o_40;
      _o_26 = _o_41;
      _o_27 = _o_42;
      _o_28 = _o_43;
      _o_29 = _o_44;
    } else if (_v_0 == 1) {
      _o_13 = 1;
      Term _fb_4[2];
      u64 _sp_4 = ctr_take(e, _v_2, 2, _fb_4);
      Term _f_13 = _fb_4[0];
      Term _f_14 = _fb_4[1];
      spare_free(e, cls_fit(2), _sp_4);
      Term _fb_5[3];
      u64 _sp_5 = ctr_take(e, _f_13, 3, _fb_5);
      Term _f_15 = _fb_5[0];
      u32 _f_16 = _fb_5[1];
      u32 _f_17 = _fb_5[2];
      spare_free(e, cls_fit(3), _sp_5);
      Term _fb_6[6];
      u64 _sp_6 = ctr_take(e, _f_14, 6, _fb_6);
      u32 _f_18 = _fb_6[0];
      u32 _f_19 = _fb_6[1];
      u32 _f_20 = _fb_6[2];
      u32 _f_21 = _fb_6[3];
      u32 _f_22 = _fb_6[4];
      u32 _f_23 = _fb_6[5];
      spare_free(e, cls_fit(6), _sp_6);
      _o_14 = _v_1;
      _o_15 = _f_15;
      _o_16 = _f_16;
      _o_17 = _f_17;
      _o_18 = _f_18;
      _o_19 = _f_19;
      _o_20 = _f_20;
      _o_21 = _f_21;
      _o_22 = _f_22;
      _o_23 = _f_23;
    } else if (_v_0 == 2) {
      _o_13 = 2;
      _o_14 = _v_1;
      _o_15 = term_loc(_v_2);
    } else if (_v_0 == 3) {
      _o_13 = 3;
      _o_14 = _v_1;
    } else if (_v_0 == 4) {
      _o_13 = 4;
      _o_14 = _v_1;
    } else {
      _o_13 = 5;
      _o_14 = _v_1;
    }
    u32 _o_45 = 0;
    u32 _o_46 = 0;
    u32 _o_47 = 0;
    u32 _o_48 = 0;
    u32 _o_49 = 0;
    u32 _o_50 = 0;
    u32 _o_51 = 0;
    u32 _o_52 = 0;
    u32 _o_53 = 0;
    u32 _o_54 = 0;
    u32 _o_55 = 0;
    u32 _o_56 = 0;
    u32 _o_57 = 0;
    u32 _o_58 = 0;
    u32 _o_59 = 0;
    u32 _o_60 = 0;
    u32 _o_61 = 0;
    if (_v_8 == 0) {
      _o_45 = 0;
      u32 _o_62 = 0;
      u32 _o_63 = 0;
      u32 _o_64 = 0;
      u32 _o_65 = 0;
      u32 _o_66 = 0;
      u32 _o_67 = 0;
      u32 _o_68 = 0;
      if (_v_10 == 0) {
        _o_62 = 0;
      } else {
        _o_62 = 1;
        Term _fb_7[6];
        u64 _sp_7 = ctr_take(e, _v_11, 6, _fb_7);
        u32 _f_24 = _fb_7[0];
        u32 _f_25 = _fb_7[1];
        u32 _f_26 = _fb_7[2];
        u32 _f_27 = _fb_7[3];
        u32 _f_28 = _fb_7[4];
        u32 _f_29 = _fb_7[5];
        spare_free(e, cls_fit(6), _sp_7);
        _o_63 = _f_24;
        _o_64 = _f_25;
        _o_65 = _f_26;
        _o_66 = _f_27;
        _o_67 = _f_28;
        _o_68 = _f_29;
      }
      u32 _o_69 = 0;
      u32 _o_70 = 0;
      u32 _o_71 = 0;
      u32 _o_72 = 0;
      u32 _o_73 = 0;
      u32 _o_74 = 0;
      if (_v_12 == 0) {
        _o_69 = 0;
      } else {
        _o_69 = 1;
        Term _fb_8[5];
        u64 _sp_8 = ctr_take(e, _v_13, 5, _fb_8);
        u32 _f_30 = _fb_8[0];
        u32 _f_31 = _fb_8[1];
        u32 _f_32 = _fb_8[2];
        u32 _f_33 = _fb_8[3];
        u32 _f_34 = _fb_8[4];
        spare_free(e, cls_fit(5), _sp_8);
        _o_70 = _f_30;
        _o_71 = _f_31;
        _o_72 = _f_32;
        _o_73 = _f_33;
        _o_74 = _f_34;
      }
      u32 _o_75 = 0;
      u32 _o_76 = 0;
      if (_v_14 == 0) {
        _o_75 = 0;
      } else {
        _o_75 = 1;
        _o_76 = term_loc(_v_15);
      }
      _o_46 = _v_9;
      _o_47 = _o_62;
      _o_48 = _o_63;
      _o_49 = _o_64;
      _o_50 = _o_65;
      _o_51 = _o_66;
      _o_52 = _o_67;
      _o_53 = _o_68;
      _o_54 = _o_69;
      _o_55 = _o_70;
      _o_56 = _o_71;
      _o_57 = _o_72;
      _o_58 = _o_73;
      _o_59 = _o_74;
      _o_60 = _o_75;
      _o_61 = _o_76;
    } else if (_v_8 == 1) {
      _o_45 = 1;
      Term _fb_9[6];
      u64 _sp_9 = ctr_take(e, _v_10, 6, _fb_9);
      u32 _f_35 = _fb_9[0];
      u32 _f_36 = _fb_9[1];
      u32 _f_37 = _fb_9[2];
      u32 _f_38 = _fb_9[3];
      u32 _f_39 = _fb_9[4];
      u32 _f_40 = _fb_9[5];
      spare_free(e, cls_fit(6), _sp_9);
      _o_46 = _v_9;
      _o_47 = _f_35;
      _o_48 = _f_36;
      _o_49 = _f_37;
      _o_50 = _f_38;
      _o_51 = _f_39;
      _o_52 = _f_40;
    } else if (_v_8 == 2) {
      _o_45 = 2;
      _o_46 = _v_9;
      _o_47 = term_loc(_v_10);
    } else if (_v_8 == 3) {
      _o_45 = 3;
      _o_46 = _v_9;
    } else if (_v_8 == 4) {
      _o_45 = 4;
      _o_46 = _v_9;
    } else {
      _o_45 = 5;
      _o_46 = _v_9;
    }
    r0 = _o_13;
    r1 = _o_14;
    r2 = _o_15;
    r3 = _o_16;
    r4 = _o_17;
    r5 = _o_18;
    r6 = _o_19;
    r7 = _o_20;
    r8 = _o_21;
    r9 = _o_22;
    r10 = _o_23;
    r11 = _o_24;
    r12 = _o_25;
    r13 = _o_26;
    r14 = _o_27;
    r15 = _o_28;
    r16 = _o_29;
    r17 = _o_45;
    r18 = _o_46;
    r19 = _o_47;
    r20 = _o_48;
    r21 = _o_49;
    r22 = _o_50;
    r23 = _o_51;
    r24 = _o_52;
    r25 = _o_53;
    r26 = _o_54;
    r27 = _o_55;
    r28 = _o_56;
    r29 = _o_57;
    r30 = _o_58;
    r31 = _o_59;
    r32 = _o_60;
    r33 = _o_61;
    WL_RETN(34);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_COMMAND_0_K392)
  {
    WL_POPN(1);
    u32 _owner_18 = STK(0);
    Term _h_30 = r0;
    u32 _h_31 = r1;
    u32 _h_32 = r2;
    u32 _h_33 = r3;
    u32 _h_34 = r4;
    u32 _h_35 = r5;
    u32 _h_36 = r6;
    u32 _h_37 = r7;
    u32 _h_38 = r8;
    u32 _h_39 = r9;
    u32 _h_40 = r10;
    u32 _h_41 = r11;
    u32 _h_42 = r12;
    u32 _h_43 = r13;
    u32 _h_44 = r14;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_30);
    e.mem[_nd_6 + 1] = rfc_seal(e, _h_31);
    e.mem[_nd_6 + 2] = rfc_seal(e, _h_32);
    u64 _nd_7 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_7 + 0] = rfc_seal(e, _h_33);
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_34);
    e.mem[_nd_7 + 2] = rfc_seal(e, _h_35);
    e.mem[_nd_7 + 3] = rfc_seal(e, _h_36);
    e.mem[_nd_7 + 4] = rfc_seal(e, _h_37);
    e.mem[_nd_7 + 5] = rfc_seal(e, _h_38);
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_6));
    e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_7));
    u64 _nd_9 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_9 + 0] = rfc_seal(e, _h_39);
    e.mem[_nd_9 + 1] = rfc_seal(e, _h_40);
    e.mem[_nd_9 + 2] = rfc_seal(e, _h_41);
    e.mem[_nd_9 + 3] = rfc_seal(e, _h_42);
    e.mem[_nd_9 + 4] = rfc_seal(e, _h_43);
    e.mem[_nd_9 + 5] = rfc_seal(e, _h_44);
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _o_77[16];
    Term _a_0 = term_ctr(CID_CACHE_CACHE, _nd_8);
    Term _a_1 = term_ctr(CID_TYPES_VITALSVIEW, _nd_9);
    if (spin_141(e, _o_77, _owner_18, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_32 = _o_77[0];
    _v_33 = _o_77[1];
    _v_34 = _o_77[2];
    _v_35 = _o_77[3];
    _v_36 = _o_77[4];
    _v_37 = _o_77[5];
    _v_38 = _o_77[6];
    _v_39 = _o_77[7];
    _v_40 = _o_77[8];
    _v_41 = _o_77[9];
    _v_42 = _o_77[10];
    _v_43 = _o_77[11];
    _v_44 = _o_77[12];
    _v_45 = _o_77[13];
    _v_46 = _o_77[14];
    _v_47 = _o_77[15];
    u32 _o_78 = 0;
    u32 _o_79 = 0;
    Term _o_80 = 0;
    Term _o_81 = 0;
    u32 _o_82 = 0;
    u32 _o_83 = 0;
    u32 _o_84 = 0;
    u32 _o_85 = 0;
    u32 _o_86 = 0;
    u32 _o_87 = 0;
    u32 _o_88 = 0;
    u32 _o_89 = 0;
    u32 _o_90 = 0;
    Term _o_91 = 0;
    u32 _o_92 = 0;
    u32 _o_93 = 0;
    u32 _o_94 = 0;
    if (_v_32 == 0) {
      _o_78 = 0;
      u32 _o_95 = 0;
      Term _o_96 = 0;
      u32 _o_97 = 0;
      u32 _o_98 = 0;
      u32 _o_99 = 0;
      u32 _o_100 = 0;
      u32 _o_101 = 0;
      u32 _o_102 = 0;
      u32 _o_103 = 0;
      u32 _o_104 = 0;
      if (_v_34 == 0) {
        _o_95 = 0;
      } else {
        _o_95 = 1;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _v_35, 2, _fb_10);
        Term _f_41 = _fb_10[0];
        Term _f_42 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        Term _fb_11[3];
        u64 _sp_11 = ctr_take(e, _f_41, 3, _fb_11);
        Term _f_43 = _fb_11[0];
        u32 _f_44 = _fb_11[1];
        u32 _f_45 = _fb_11[2];
        spare_free(e, cls_fit(3), _sp_11);
        Term _fb_12[6];
        u64 _sp_12 = ctr_take(e, _f_42, 6, _fb_12);
        u32 _f_46 = _fb_12[0];
        u32 _f_47 = _fb_12[1];
        u32 _f_48 = _fb_12[2];
        u32 _f_49 = _fb_12[3];
        u32 _f_50 = _fb_12[4];
        u32 _f_51 = _fb_12[5];
        spare_free(e, cls_fit(6), _sp_12);
        _o_96 = _f_43;
        _o_97 = _f_44;
        _o_98 = _f_45;
        _o_99 = _f_46;
        _o_100 = _f_47;
        _o_101 = _f_48;
        _o_102 = _f_49;
        _o_103 = _f_50;
        _o_104 = _f_51;
      }
      u32 _o_105 = 0;
      Term _o_106 = 0;
      u32 _o_107 = 0;
      if (_v_36 == 0) {
        _o_105 = 0;
      } else {
        _o_105 = 1;
        Term _fb_13[2];
        u64 _sp_13 = ctr_take(e, _v_37, 2, _fb_13);
        Term _f_52 = _fb_13[0];
        u32 _f_53 = _fb_13[1];
        spare_free(e, cls_fit(2), _sp_13);
        _o_106 = _f_52;
        _o_107 = _f_53;
      }
      u32 _o_108 = 0;
      u32 _o_109 = 0;
      if (_v_38 == 0) {
        _o_108 = 0;
      } else {
        _o_108 = 1;
        _o_109 = term_loc(_v_39);
      }
      _o_79 = _v_33;
      _o_80 = _o_95;
      _o_81 = _o_96;
      _o_82 = _o_97;
      _o_83 = _o_98;
      _o_84 = _o_99;
      _o_85 = _o_100;
      _o_86 = _o_101;
      _o_87 = _o_102;
      _o_88 = _o_103;
      _o_89 = _o_104;
      _o_90 = _o_105;
      _o_91 = _o_106;
      _o_92 = _o_107;
      _o_93 = _o_108;
      _o_94 = _o_109;
    } else if (_v_32 == 1) {
      _o_78 = 1;
      Term _fb_14[2];
      u64 _sp_14 = ctr_take(e, _v_34, 2, _fb_14);
      Term _f_54 = _fb_14[0];
      Term _f_55 = _fb_14[1];
      spare_free(e, cls_fit(2), _sp_14);
      Term _fb_15[3];
      u64 _sp_15 = ctr_take(e, _f_54, 3, _fb_15);
      Term _f_56 = _fb_15[0];
      u32 _f_57 = _fb_15[1];
      u32 _f_58 = _fb_15[2];
      spare_free(e, cls_fit(3), _sp_15);
      Term _fb_16[6];
      u64 _sp_16 = ctr_take(e, _f_55, 6, _fb_16);
      u32 _f_59 = _fb_16[0];
      u32 _f_60 = _fb_16[1];
      u32 _f_61 = _fb_16[2];
      u32 _f_62 = _fb_16[3];
      u32 _f_63 = _fb_16[4];
      u32 _f_64 = _fb_16[5];
      spare_free(e, cls_fit(6), _sp_16);
      _o_79 = _v_33;
      _o_80 = _f_56;
      _o_81 = _f_57;
      _o_82 = _f_58;
      _o_83 = _f_59;
      _o_84 = _f_60;
      _o_85 = _f_61;
      _o_86 = _f_62;
      _o_87 = _f_63;
      _o_88 = _f_64;
    } else if (_v_32 == 2) {
      _o_78 = 2;
      _o_79 = _v_33;
      _o_80 = term_loc(_v_34);
    } else if (_v_32 == 3) {
      _o_78 = 3;
      _o_79 = _v_33;
    } else if (_v_32 == 4) {
      _o_78 = 4;
      _o_79 = _v_33;
    } else {
      _o_78 = 5;
      _o_79 = _v_33;
    }
    u32 _o_110 = 0;
    u32 _o_111 = 0;
    u32 _o_112 = 0;
    u32 _o_113 = 0;
    u32 _o_114 = 0;
    u32 _o_115 = 0;
    u32 _o_116 = 0;
    u32 _o_117 = 0;
    u32 _o_118 = 0;
    u32 _o_119 = 0;
    u32 _o_120 = 0;
    u32 _o_121 = 0;
    u32 _o_122 = 0;
    u32 _o_123 = 0;
    u32 _o_124 = 0;
    u32 _o_125 = 0;
    u32 _o_126 = 0;
    if (_v_40 == 0) {
      _o_110 = 0;
      u32 _o_127 = 0;
      u32 _o_128 = 0;
      u32 _o_129 = 0;
      u32 _o_130 = 0;
      u32 _o_131 = 0;
      u32 _o_132 = 0;
      u32 _o_133 = 0;
      if (_v_42 == 0) {
        _o_127 = 0;
      } else {
        _o_127 = 1;
        Term _fb_17[6];
        u64 _sp_17 = ctr_take(e, _v_43, 6, _fb_17);
        u32 _f_65 = _fb_17[0];
        u32 _f_66 = _fb_17[1];
        u32 _f_67 = _fb_17[2];
        u32 _f_68 = _fb_17[3];
        u32 _f_69 = _fb_17[4];
        u32 _f_70 = _fb_17[5];
        spare_free(e, cls_fit(6), _sp_17);
        _o_128 = _f_65;
        _o_129 = _f_66;
        _o_130 = _f_67;
        _o_131 = _f_68;
        _o_132 = _f_69;
        _o_133 = _f_70;
      }
      u32 _o_134 = 0;
      u32 _o_135 = 0;
      u32 _o_136 = 0;
      u32 _o_137 = 0;
      u32 _o_138 = 0;
      u32 _o_139 = 0;
      if (_v_44 == 0) {
        _o_134 = 0;
      } else {
        _o_134 = 1;
        Term _fb_18[5];
        u64 _sp_18 = ctr_take(e, _v_45, 5, _fb_18);
        u32 _f_71 = _fb_18[0];
        u32 _f_72 = _fb_18[1];
        u32 _f_73 = _fb_18[2];
        u32 _f_74 = _fb_18[3];
        u32 _f_75 = _fb_18[4];
        spare_free(e, cls_fit(5), _sp_18);
        _o_135 = _f_71;
        _o_136 = _f_72;
        _o_137 = _f_73;
        _o_138 = _f_74;
        _o_139 = _f_75;
      }
      u32 _o_140 = 0;
      u32 _o_141 = 0;
      if (_v_46 == 0) {
        _o_140 = 0;
      } else {
        _o_140 = 1;
        _o_141 = term_loc(_v_47);
      }
      _o_111 = _v_41;
      _o_112 = _o_127;
      _o_113 = _o_128;
      _o_114 = _o_129;
      _o_115 = _o_130;
      _o_116 = _o_131;
      _o_117 = _o_132;
      _o_118 = _o_133;
      _o_119 = _o_134;
      _o_120 = _o_135;
      _o_121 = _o_136;
      _o_122 = _o_137;
      _o_123 = _o_138;
      _o_124 = _o_139;
      _o_125 = _o_140;
      _o_126 = _o_141;
    } else if (_v_40 == 1) {
      _o_110 = 1;
      Term _fb_19[6];
      u64 _sp_19 = ctr_take(e, _v_42, 6, _fb_19);
      u32 _f_76 = _fb_19[0];
      u32 _f_77 = _fb_19[1];
      u32 _f_78 = _fb_19[2];
      u32 _f_79 = _fb_19[3];
      u32 _f_80 = _fb_19[4];
      u32 _f_81 = _fb_19[5];
      spare_free(e, cls_fit(6), _sp_19);
      _o_111 = _v_41;
      _o_112 = _f_76;
      _o_113 = _f_77;
      _o_114 = _f_78;
      _o_115 = _f_79;
      _o_116 = _f_80;
      _o_117 = _f_81;
    } else if (_v_40 == 2) {
      _o_110 = 2;
      _o_111 = _v_41;
      _o_112 = term_loc(_v_42);
    } else if (_v_40 == 3) {
      _o_110 = 3;
      _o_111 = _v_41;
    } else if (_v_40 == 4) {
      _o_110 = 4;
      _o_111 = _v_41;
    } else {
      _o_110 = 5;
      _o_111 = _v_41;
    }
    r0 = _o_78;
    r1 = _o_79;
    r2 = _o_80;
    r3 = _o_81;
    r4 = _o_82;
    r5 = _o_83;
    r6 = _o_84;
    r7 = _o_85;
    r8 = _o_86;
    r9 = _o_87;
    r10 = _o_88;
    r11 = _o_89;
    r12 = _o_90;
    r13 = _o_91;
    r14 = _o_92;
    r15 = _o_93;
    r16 = _o_94;
    r17 = _o_110;
    r18 = _o_111;
    r19 = _o_112;
    r20 = _o_113;
    r21 = _o_114;
    r22 = _o_115;
    r23 = _o_116;
    r24 = _o_117;
    r25 = _o_118;
    r26 = _o_119;
    r27 = _o_120;
    r28 = _o_121;
    r29 = _o_122;
    r30 = _o_123;
    r31 = _o_124;
    r32 = _o_125;
    r33 = _o_126;
    WL_RETN(34);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE)
  {
    u32 _t_0 = r0;
    u32 _t_1 = r1;
    Term _t_2 = r2;
    Term _t_3 = r3;
    Term _t_4 = r4;
    Term _t_5 = r5;
    Term _t_6 = r6;
    Term _t_7 = r7;
    u32 _t_8 = r8;
    Term _t_9 = r9;
    u32 _t_10 = r10;
    Term _t_11 = r11;
    u32 _t_12 = r12;
    Term _t_13 = r13;
    u32 _t_14 = r14;
    u32 _t_15 = r15;
    u32 _t_16 = r16;
    u32 _t_17 = r17;
    u32 _t_18 = r18;
    u32 _t_19 = r19;
    u32 _t_20 = r20;
    u32 _t_21 = r21;
    u32 _t_22 = r22;
    Term _t_23 = r23;
    Term _t_24 = r24;
    Term _t_25 = r25;
    Term _t_26 = r26;
    WL_OPEN
    term_sink(e, _t_24);
    term_sink(e, _t_25);
    term_sink(e, _t_26);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE_K422;
      WL_PUSHN(1);
    } else {
      u64 _t_27 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE_K422, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE_K422, _t_27);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_UNWIND_1)) {
      u64 _t_28 = task_node(e, FID_TRANSACTION_UNWIND_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _t_23;
      e.mem[_t_28 + 1] = _t_0;
      e.mem[_t_28 + 2] = _t_1;
      e.mem[_t_28 + 3] = _t_2;
      e.mem[_t_28 + 4] = _t_3;
      e.mem[_t_28 + 5] = _t_4;
      e.mem[_t_28 + 6] = _t_5;
      e.mem[_t_28 + 7] = _t_6;
      e.mem[_t_28 + 8] = _t_7;
      e.mem[_t_28 + 9] = _t_8;
      e.mem[_t_28 + 10] = _t_9;
      e.mem[_t_28 + 11] = _t_10;
      e.mem[_t_28 + 12] = _t_11;
      e.mem[_t_28 + 13] = _t_12;
      e.mem[_t_28 + 14] = _t_13;
      e.mem[_t_28 + 15] = _t_14;
      e.mem[_t_28 + 16] = _t_15;
      e.mem[_t_28 + 17] = _t_16;
      e.mem[_t_28 + 18] = _t_17;
      e.mem[_t_28 + 19] = _t_18;
      e.mem[_t_28 + 20] = _t_19;
      e.mem[_t_28 + 21] = _t_20;
      return term_tsk(FID_TRANSACTION_UNWIND_1, _t_28);
    }
    r0 = _t_23;
    r1 = _t_0;
    r2 = _t_1;
    r3 = _t_2;
    r4 = _t_3;
    r5 = _t_4;
    r6 = _t_5;
    r7 = _t_6;
    r8 = _t_7;
    r9 = _t_8;
    r10 = _t_9;
    r11 = _t_10;
    r12 = _t_11;
    r13 = _t_12;
    r14 = _t_13;
    r15 = _t_14;
    r16 = _t_15;
    r17 = _t_16;
    r18 = _t_17;
    r19 = _t_18;
    r20 = _t_19;
    r21 = _t_20;
    WL_JMP(FID_TRANSACTION_UNWIND_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE_K422)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    WL_OPEN
    r0 = 1;
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _h_5;
    r7 = _h_6;
    r8 = _h_7;
    r9 = _h_8;
    r10 = _h_9;
    r11 = _h_10;
    r12 = _h_11;
    r13 = _h_12;
    r14 = _h_13;
    r15 = _h_14;
    r16 = _h_15;
    r17 = _h_16;
    r18 = _h_17;
    r19 = _h_18;
    r20 = _h_19;
    r21 = _h_20;
    r22 = 0;
    r23 = 0;
    r24 = 0;
    WL_RETN(25);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    Term _result_2 = r2;
    Term _result_3 = r3;
    Term _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    u32 _result_8 = r8;
    Term _result_9 = r9;
    u32 _result_10 = r10;
    Term _result_11 = r11;
    u32 _result_12 = r12;
    Term _result_13 = r13;
    u32 _result_14 = r14;
    u32 _result_15 = r15;
    u32 _result_16 = r16;
    u32 _result_17 = r17;
    u32 _result_18 = r18;
    u32 _result_19 = r19;
    u32 _result_20 = r20;
    Term _result_21 = r21;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _result_21;
      STK(1) = FID_HEALTH_POST_K426;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HEALTH_POST_K426, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _result_21;
      WL_CONT = term_tsk(FID_HEALTH_POST_K426, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_WORLD_0)) {
      u64 _t_1 = task_node(e, FID_OBSERVATIONS_WORLD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _result_0;
      e.mem[_t_1 + 1] = _result_1;
      e.mem[_t_1 + 2] = _result_2;
      e.mem[_t_1 + 3] = _result_3;
      e.mem[_t_1 + 4] = _result_4;
      e.mem[_t_1 + 5] = _result_5;
      e.mem[_t_1 + 6] = _result_6;
      e.mem[_t_1 + 7] = _result_7;
      e.mem[_t_1 + 8] = _result_8;
      e.mem[_t_1 + 9] = _result_9;
      e.mem[_t_1 + 10] = _result_10;
      e.mem[_t_1 + 11] = _result_11;
      e.mem[_t_1 + 12] = _result_12;
      e.mem[_t_1 + 13] = _result_13;
      e.mem[_t_1 + 14] = _result_14;
      e.mem[_t_1 + 15] = _result_15;
      e.mem[_t_1 + 16] = _result_16;
      e.mem[_t_1 + 17] = _result_17;
      e.mem[_t_1 + 18] = _result_18;
      e.mem[_t_1 + 19] = _result_19;
      e.mem[_t_1 + 20] = _result_20;
      return term_tsk(FID_OBSERVATIONS_WORLD_0, _t_1);
    }
    r0 = _result_0;
    r1 = _result_1;
    r2 = _result_2;
    r3 = _result_3;
    r4 = _result_4;
    r5 = _result_5;
    r6 = _result_6;
    r7 = _result_7;
    r8 = _result_8;
    r9 = _result_9;
    r10 = _result_10;
    r11 = _result_11;
    r12 = _result_12;
    r13 = _result_13;
    r14 = _result_14;
    r15 = _result_15;
    r16 = _result_16;
    r17 = _result_17;
    r18 = _result_18;
    r19 = _result_19;
    r20 = _result_20;
    WL_JMP(FID_OBSERVATIONS_WORLD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K426)
  {
    WL_POPN(1);
    Term _result_22 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    Term _h_23 = r23;
    Term _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    u32 _h_27 = r27;
    u32 _h_28 = r28;
    u32 _h_29 = r29;
    u32 _h_30 = r30;
    u32 _h_31 = r31;
    WL_OPEN
    term_sink(e, _h_2);
    term_sink(e, _h_3);
    term_sink(e, _h_4);
    term_sink(e, _h_5);
    term_sink(e, _h_6);
    term_sink(e, _h_7);
    term_sink(e, _h_11);
    term_sink(e, _h_13);
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_21;
      STK(1) = _h_22;
      STK(2) = _h_23;
      STK(3) = _h_24;
      STK(4) = _h_25;
      STK(5) = _h_26;
      STK(6) = _h_27;
      STK(7) = _h_28;
      STK(8) = _h_29;
      STK(9) = _h_30;
      STK(10) = _h_31;
      STK(11) = FID_HEALTH_POST_K427;
      WL_PUSHN(12);
    } else {
      u64 _t_2 = task_node(e, FID_HEALTH_POST_K427, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_21;
      e.mem[_t_2 + 1] = _h_22;
      e.mem[_t_2 + 2] = _h_23;
      e.mem[_t_2 + 3] = _h_24;
      e.mem[_t_2 + 4] = _h_25;
      e.mem[_t_2 + 5] = _h_26;
      e.mem[_t_2 + 6] = _h_27;
      e.mem[_t_2 + 7] = _h_28;
      e.mem[_t_2 + 8] = _h_29;
      e.mem[_t_2 + 9] = _h_30;
      e.mem[_t_2 + 10] = _h_31;
      WL_CONT = term_tsk(FID_HEALTH_POST_K427, _t_2);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_3 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _result_22;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_3);
    }
    r0 = _result_22;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K427)
  {
    WL_POPN(11);
    u32 _h_33 = STK(0);
    u32 _h_34 = STK(1);
    Term _h_35 = STK(2);
    Term _h_36 = STK(3);
    u32 _h_37 = STK(4);
    u32 _h_38 = STK(5);
    u32 _h_39 = STK(6);
    u32 _h_40 = STK(7);
    u32 _h_41 = STK(8);
    u32 _h_42 = STK(9);
    u32 _h_43 = STK(10);
    Term _h_32 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_32;
      STK(1) = FID_HEALTH_POST_K428;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_HEALTH_POST_K428, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_32;
      WL_CONT = term_tsk(FID_HEALTH_POST_K428, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_WORLD_1)) {
      u64 _t_5 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_33;
      e.mem[_t_5 + 1] = _h_34;
      e.mem[_t_5 + 2] = _h_35;
      e.mem[_t_5 + 3] = _h_36;
      e.mem[_t_5 + 4] = _h_37;
      e.mem[_t_5 + 5] = _h_38;
      e.mem[_t_5 + 6] = _h_39;
      e.mem[_t_5 + 7] = _h_40;
      e.mem[_t_5 + 8] = _h_41;
      e.mem[_t_5 + 9] = _h_42;
      e.mem[_t_5 + 10] = _h_43;
      return term_tsk(FID_HOST_RENDER_RENDER_WORLD_1, _t_5);
    }
    r0 = _h_33;
    r1 = _h_34;
    r2 = _h_35;
    r3 = _h_36;
    r4 = _h_37;
    r5 = _h_38;
    r6 = _h_39;
    r7 = _h_40;
    r8 = _h_41;
    r9 = _h_42;
    r10 = _h_43;
    WL_JMP(FID_HOST_RENDER_RENDER_WORLD_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K428)
  {
    WL_POPN(1);
    Term _h_45 = STK(0);
    Term _h_44 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_45;
      STK(1) = FID_HEALTH_POST_K429;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_HEALTH_POST_K429, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_45;
      WL_CONT = term_tsk(FID_HEALTH_POST_K429, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_44;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 74);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_44;
    r1 = term_ctr(CID_SCON, STAT_OFF + 74);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K429)
  {
    WL_POPN(1);
    Term _h_47 = STK(0);
    Term _h_46 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_47;
      STK(1) = FID_HEALTH_POST_K430;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_HEALTH_POST_K430, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_47;
      WL_CONT = term_tsk(FID_HEALTH_POST_K430, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 454);
      e.mem[_t_9 + 1] = _h_46;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 454);
    r1 = _h_46;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K430)
  {
    WL_POPN(1);
    Term _h_49 = STK(0);
    Term _h_48 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HEALTH_POST_K431;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_HEALTH_POST_K431, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HEALTH_POST_K431, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_49;
      e.mem[_t_11 + 1] = _h_48;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _h_49;
    r1 = _h_48;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K431)
  {
    Term _h_50 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HEALTH_POST_K432;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_HEALTH_POST_K432, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HEALTH_POST_K432, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 656);
      e.mem[_t_13 + 1] = _h_50;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 656);
    r1 = _h_50;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_POST_K432)
  {
    Term _h_51 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_51;
    r0 = term_clo(FID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GATE_CALLBACKS_HEALTH_BODY_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    Term _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    u32 _owner_8 = r8;
    Term _owner_9 = r9;
    u32 _owner_10 = r10;
    Term _owner_11 = r11;
    u32 _owner_12 = r12;
    Term _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    u32 _owner_17 = r17;
    u32 _owner_18 = r18;
    u32 _owner_19 = r19;
    u32 _owner_20 = r20;
    u32 _owner_21 = r21;
    u32 _owner_22 = r22;
    Term _owner_23 = r23;
    Term _owner_24 = r24;
    Term _owner_25 = r25;
    Term _owner_26 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_GATE_CALLBACKS_HEALTH_BODY_0_K441;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0_K441, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0_K441, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN)) {
      u64 _t_1 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      e.mem[_t_1 + 1] = _owner_1;
      e.mem[_t_1 + 2] = _owner_2;
      e.mem[_t_1 + 3] = _owner_3;
      e.mem[_t_1 + 4] = _owner_4;
      e.mem[_t_1 + 5] = _owner_5;
      e.mem[_t_1 + 6] = _owner_6;
      e.mem[_t_1 + 7] = _owner_7;
      e.mem[_t_1 + 8] = _owner_8;
      e.mem[_t_1 + 9] = _owner_9;
      e.mem[_t_1 + 10] = _owner_10;
      e.mem[_t_1 + 11] = _owner_11;
      e.mem[_t_1 + 12] = _owner_12;
      e.mem[_t_1 + 13] = _owner_13;
      e.mem[_t_1 + 14] = _owner_14;
      e.mem[_t_1 + 15] = _owner_15;
      e.mem[_t_1 + 16] = _owner_16;
      e.mem[_t_1 + 17] = _owner_17;
      e.mem[_t_1 + 18] = _owner_18;
      e.mem[_t_1 + 19] = _owner_19;
      e.mem[_t_1 + 20] = _owner_20;
      e.mem[_t_1 + 21] = _owner_21;
      e.mem[_t_1 + 22] = _owner_22;
      e.mem[_t_1 + 23] = _owner_23;
      e.mem[_t_1 + 24] = _owner_24;
      e.mem[_t_1 + 25] = _owner_25;
      e.mem[_t_1 + 26] = _owner_26;
      return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN, _t_1);
    }
    r0 = _owner_0;
    r1 = _owner_1;
    r2 = _owner_2;
    r3 = _owner_3;
    r4 = _owner_4;
    r5 = _owner_5;
    r6 = _owner_6;
    r7 = _owner_7;
    r8 = _owner_8;
    r9 = _owner_9;
    r10 = _owner_10;
    r11 = _owner_11;
    r12 = _owner_12;
    r13 = _owner_13;
    r14 = _owner_14;
    r15 = _owner_15;
    r16 = _owner_16;
    r17 = _owner_17;
    r18 = _owner_18;
    r19 = _owner_19;
    r20 = _owner_20;
    r21 = _owner_21;
    r22 = _owner_22;
    r23 = _owner_23;
    r24 = _owner_24;
    r25 = _owner_25;
    r26 = _owner_26;
    WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GATE_CALLBACKS_HEALTH_BODY_0_K441)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    Term _h_23 = r23;
    Term _h_24 = r24;
    Term _h_25 = r25;
    Term _h_26 = r26;
    u32 _h_27 = r27;
    u32 _h_28 = r28;
    u32 _h_29 = r29;
    u32 _h_30 = r30;
    u32 _h_31 = r31;
    u32 _h_32 = r32;
    u32 _h_33 = r33;
    WL_OPEN
    if (_h_27 == 0) {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_60(e, _o_0, _h_28, _h_29, _h_30, _h_31) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      if (seq) {
        WL_ROOM(5);
        STK(0) = _h_28;
        STK(1) = _h_29;
        STK(2) = _h_30;
        STK(3) = _h_31;
        STK(4) = FID_GATE_CALLBACKS_HEALTH_BODY_0_K442;
        WL_PUSHN(5);
      } else {
        u64 _t_2 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0_K442, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _h_28;
        e.mem[_t_2 + 1] = _h_29;
        e.mem[_t_2 + 2] = _h_30;
        e.mem[_t_2 + 3] = _h_31;
        WL_CONT = term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0_K442, _t_2);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0)) {
        u64 _t_3 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_0;
        e.mem[_t_3 + 1] = _h_1;
        e.mem[_t_3 + 2] = _h_2;
        e.mem[_t_3 + 3] = _h_3;
        e.mem[_t_3 + 4] = _h_4;
        e.mem[_t_3 + 5] = _h_5;
        e.mem[_t_3 + 6] = _h_6;
        e.mem[_t_3 + 7] = _h_7;
        e.mem[_t_3 + 8] = _h_8;
        e.mem[_t_3 + 9] = _h_9;
        e.mem[_t_3 + 10] = _h_10;
        e.mem[_t_3 + 11] = _h_11;
        e.mem[_t_3 + 12] = _h_12;
        e.mem[_t_3 + 13] = _h_13;
        e.mem[_t_3 + 14] = _h_14;
        e.mem[_t_3 + 15] = _h_15;
        e.mem[_t_3 + 16] = _h_16;
        e.mem[_t_3 + 17] = _h_17;
        e.mem[_t_3 + 18] = _h_18;
        e.mem[_t_3 + 19] = _h_19;
        e.mem[_t_3 + 20] = _h_20;
        e.mem[_t_3 + 21] = _h_21;
        e.mem[_t_3 + 22] = _h_22;
        e.mem[_t_3 + 23] = _h_23;
        e.mem[_t_3 + 24] = _h_24;
        e.mem[_t_3 + 25] = _h_25;
        e.mem[_t_3 + 26] = _h_26;
        e.mem[_t_3 + 27] = U32_BIN(_v_0, +, 1ull);
        return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0, _t_3);
      }
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      r5 = _h_5;
      r6 = _h_6;
      r7 = _h_7;
      r8 = _h_8;
      r9 = _h_9;
      r10 = _h_10;
      r11 = _h_11;
      r12 = _h_12;
      r13 = _h_13;
      r14 = _h_14;
      r15 = _h_15;
      r16 = _h_16;
      r17 = _h_17;
      r18 = _h_18;
      r19 = _h_19;
      r20 = _h_20;
      r21 = _h_21;
      r22 = _h_22;
      r23 = _h_23;
      r24 = _h_24;
      r25 = _h_25;
      r26 = _h_26;
      r27 = U32_BIN(_v_0, +, 1ull);
      WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0);
    } else {
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      r5 = _h_5;
      r6 = _h_6;
      r7 = _h_7;
      r8 = _h_8;
      r9 = _h_9;
      r10 = _h_10;
      r11 = _h_11;
      r12 = _h_12;
      r13 = _h_13;
      r14 = _h_14;
      r15 = _h_15;
      r16 = _h_16;
      r17 = _h_17;
      r18 = _h_18;
      r19 = _h_19;
      r20 = _h_20;
      r21 = _h_21;
      r22 = _h_22;
      r23 = _h_23;
      r24 = _h_24;
      r25 = _h_25;
      r26 = _h_26;
      r27 = 4294967295ull;
      WL_RETN(28);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GATE_CALLBACKS_HEALTH_BODY_0_K442)
  {
    WL_POPN(4);
    u32 _h_61 = STK(0);
    u32 _h_62 = STK(1);
    u32 _h_63 = STK(2);
    u32 _h_64 = STK(3);
    u32 _h_34 = r0;
    u32 _h_35 = r1;
    Term _h_36 = r2;
    Term _h_37 = r3;
    Term _h_38 = r4;
    Term _h_39 = r5;
    Term _h_40 = r6;
    Term _h_41 = r7;
    u32 _h_42 = r8;
    Term _h_43 = r9;
    u32 _h_44 = r10;
    Term _h_45 = r11;
    u32 _h_46 = r12;
    Term _h_47 = r13;
    u32 _h_48 = r14;
    u32 _h_49 = r15;
    u32 _h_50 = r16;
    u32 _h_51 = r17;
    u32 _h_52 = r18;
    u32 _h_53 = r19;
    u32 _h_54 = r20;
    u32 _h_55 = r21;
    u32 _h_56 = r22;
    Term _h_57 = r23;
    Term _h_58 = r24;
    Term _h_59 = r25;
    Term _h_60 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_61;
      STK(1) = _h_62;
      STK(2) = _h_63;
      STK(3) = _h_64;
      STK(4) = FID_GATE_CALLBACKS_HEALTH_BODY_0_K443;
      WL_PUSHN(5);
    } else {
      u64 _t_4 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0_K443, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_61;
      e.mem[_t_4 + 1] = _h_62;
      e.mem[_t_4 + 2] = _h_63;
      e.mem[_t_4 + 3] = _h_64;
      WL_CONT = term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0_K443, _t_4);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER)) {
      u64 _t_5 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_34;
      e.mem[_t_5 + 1] = _h_35;
      e.mem[_t_5 + 2] = _h_36;
      e.mem[_t_5 + 3] = _h_37;
      e.mem[_t_5 + 4] = _h_38;
      e.mem[_t_5 + 5] = _h_39;
      e.mem[_t_5 + 6] = _h_40;
      e.mem[_t_5 + 7] = _h_41;
      e.mem[_t_5 + 8] = _h_42;
      e.mem[_t_5 + 9] = _h_43;
      e.mem[_t_5 + 10] = _h_44;
      e.mem[_t_5 + 11] = _h_45;
      e.mem[_t_5 + 12] = _h_46;
      e.mem[_t_5 + 13] = _h_47;
      e.mem[_t_5 + 14] = _h_48;
      e.mem[_t_5 + 15] = _h_49;
      e.mem[_t_5 + 16] = _h_50;
      e.mem[_t_5 + 17] = _h_51;
      e.mem[_t_5 + 18] = _h_52;
      e.mem[_t_5 + 19] = _h_53;
      e.mem[_t_5 + 20] = _h_54;
      e.mem[_t_5 + 21] = _h_55;
      e.mem[_t_5 + 22] = _h_56;
      e.mem[_t_5 + 23] = _h_57;
      e.mem[_t_5 + 24] = _h_58;
      e.mem[_t_5 + 25] = _h_59;
      e.mem[_t_5 + 26] = _h_60;
      return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER, _t_5);
    }
    r0 = _h_34;
    r1 = _h_35;
    r2 = _h_36;
    r3 = _h_37;
    r4 = _h_38;
    r5 = _h_39;
    r6 = _h_40;
    r7 = _h_41;
    r8 = _h_42;
    r9 = _h_43;
    r10 = _h_44;
    r11 = _h_45;
    r12 = _h_46;
    r13 = _h_47;
    r14 = _h_48;
    r15 = _h_49;
    r16 = _h_50;
    r17 = _h_51;
    r18 = _h_52;
    r19 = _h_53;
    r20 = _h_54;
    r21 = _h_55;
    r22 = _h_56;
    r23 = _h_57;
    r24 = _h_58;
    r25 = _h_59;
    r26 = _h_60;
    WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GATE_CALLBACKS_HEALTH_BODY_0_K443)
  {
    WL_POPN(4);
    u32 _h_98 = STK(0);
    u32 _h_99 = STK(1);
    u32 _h_100 = STK(2);
    u32 _h_101 = STK(3);
    u32 _h_65 = r0;
    u32 _h_66 = r1;
    Term _h_67 = r2;
    Term _h_68 = r3;
    Term _h_69 = r4;
    Term _h_70 = r5;
    Term _h_71 = r6;
    Term _h_72 = r7;
    u32 _h_73 = r8;
    Term _h_74 = r9;
    u32 _h_75 = r10;
    Term _h_76 = r11;
    u32 _h_77 = r12;
    Term _h_78 = r13;
    u32 _h_79 = r14;
    u32 _h_80 = r15;
    u32 _h_81 = r16;
    u32 _h_82 = r17;
    u32 _h_83 = r18;
    u32 _h_84 = r19;
    u32 _h_85 = r20;
    u32 _h_86 = r21;
    u32 _h_87 = r22;
    Term _h_88 = r23;
    Term _h_89 = r24;
    Term _h_90 = r25;
    Term _h_91 = r26;
    u32 _h_92 = r27;
    u32 _h_93 = r28;
    u32 _h_94 = r29;
    u32 _h_95 = r30;
    u32 _h_96 = r31;
    u32 _h_97 = r32;
    WL_OPEN
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _o_1[1];
    if (spin_83(e, _o_1, _h_98, _h_99, _h_100, _h_101) == 0) {
      return 0;
    }
    _v_3 = _o_1[0];
    _v_2 = _v_3;
    if (_h_92 == 1) {
      u32 _v_4 = 0;
      u32 _v_5 = 0;
      Term _o_2[1];
      if (spin_60(e, _o_2, _h_93, _h_94, _h_95, _h_96) == 0) {
        return 0;
      }
      _v_5 = _o_2[0];
      _v_4 = _v_5;
      if (seq) {
        WL_ROOM(2);
        STK(0) = _v_2;
        STK(1) = FID_GATE_CALLBACKS_HEALTH_BODY_0_K444;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0_K444, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _v_2;
        WL_CONT = term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0_K444, _t_6);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0)) {
        u64 _t_7 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0, WL_CONT, WL_IDX, 0);
        e.mem[_t_7 + 0] = _h_65;
        e.mem[_t_7 + 1] = _h_66;
        e.mem[_t_7 + 2] = _h_67;
        e.mem[_t_7 + 3] = _h_68;
        e.mem[_t_7 + 4] = _h_69;
        e.mem[_t_7 + 5] = _h_70;
        e.mem[_t_7 + 6] = _h_71;
        e.mem[_t_7 + 7] = _h_72;
        e.mem[_t_7 + 8] = _h_73;
        e.mem[_t_7 + 9] = _h_74;
        e.mem[_t_7 + 10] = _h_75;
        e.mem[_t_7 + 11] = _h_76;
        e.mem[_t_7 + 12] = _h_77;
        e.mem[_t_7 + 13] = _h_78;
        e.mem[_t_7 + 14] = _h_79;
        e.mem[_t_7 + 15] = _h_80;
        e.mem[_t_7 + 16] = _h_81;
        e.mem[_t_7 + 17] = _h_82;
        e.mem[_t_7 + 18] = _h_83;
        e.mem[_t_7 + 19] = _h_84;
        e.mem[_t_7 + 20] = _h_85;
        e.mem[_t_7 + 21] = _h_86;
        e.mem[_t_7 + 22] = _h_87;
        e.mem[_t_7 + 23] = _h_88;
        e.mem[_t_7 + 24] = _h_89;
        e.mem[_t_7 + 25] = _h_90;
        e.mem[_t_7 + 26] = _h_91;
        e.mem[_t_7 + 27] = U32_BIN(_v_4, +, 1ull);
        return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0, _t_7);
      }
      r0 = _h_65;
      r1 = _h_66;
      r2 = _h_67;
      r3 = _h_68;
      r4 = _h_69;
      r5 = _h_70;
      r6 = _h_71;
      r7 = _h_72;
      r8 = _h_73;
      r9 = _h_74;
      r10 = _h_75;
      r11 = _h_76;
      r12 = _h_77;
      r13 = _h_78;
      r14 = _h_79;
      r15 = _h_80;
      r16 = _h_81;
      r17 = _h_82;
      r18 = _h_83;
      r19 = _h_84;
      r20 = _h_85;
      r21 = _h_86;
      r22 = _h_87;
      r23 = _h_88;
      r24 = _h_89;
      r25 = _h_90;
      r26 = _h_91;
      r27 = U32_BIN(_v_4, +, 1ull);
      WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0);
    } else {
      r0 = _h_65;
      r1 = _h_66;
      r2 = _h_67;
      r3 = _h_68;
      r4 = _h_69;
      r5 = _h_70;
      r6 = _h_71;
      r7 = _h_72;
      r8 = _h_73;
      r9 = _h_74;
      r10 = _h_75;
      r11 = _h_76;
      r12 = _h_77;
      r13 = _h_78;
      r14 = _h_79;
      r15 = _h_80;
      r16 = _h_81;
      r17 = _h_82;
      r18 = _h_83;
      r19 = _h_84;
      r20 = _h_85;
      r21 = _h_86;
      r22 = _h_87;
      r23 = _h_88;
      r24 = _h_89;
      r25 = _h_90;
      r26 = _h_91;
      r27 = 4294967295ull;
      WL_RETN(28);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GATE_CALLBACKS_HEALTH_BODY_0_K444)
  {
    WL_POPN(1);
    u32 _v_6 = STK(0);
    u32 _h_102 = r0;
    u32 _h_103 = r1;
    Term _h_104 = r2;
    Term _h_105 = r3;
    Term _h_106 = r4;
    Term _h_107 = r5;
    Term _h_108 = r6;
    Term _h_109 = r7;
    u32 _h_110 = r8;
    Term _h_111 = r9;
    u32 _h_112 = r10;
    Term _h_113 = r11;
    u32 _h_114 = r12;
    Term _h_115 = r13;
    u32 _h_116 = r14;
    u32 _h_117 = r15;
    u32 _h_118 = r16;
    u32 _h_119 = r17;
    u32 _h_120 = r18;
    u32 _h_121 = r19;
    u32 _h_122 = r20;
    u32 _h_123 = r21;
    u32 _h_124 = r22;
    Term _h_125 = r23;
    Term _h_126 = r24;
    Term _h_127 = r25;
    Term _h_128 = r26;
    WL_OPEN
    r0 = _h_102;
    r1 = _h_103;
    r2 = _h_104;
    r3 = _h_105;
    r4 = _h_106;
    r5 = _h_107;
    r6 = _h_108;
    r7 = _h_109;
    r8 = _h_110;
    r9 = _h_111;
    r10 = _h_112;
    r11 = _h_113;
    r12 = _h_114;
    r13 = _h_115;
    r14 = _h_116;
    r15 = _h_117;
    r16 = _h_118;
    r17 = _h_119;
    r18 = _h_120;
    r19 = _h_121;
    r20 = _h_122;
    r21 = _h_123;
    r22 = _h_124;
    r23 = _h_125;
    r24 = _h_126;
    r25 = _h_127;
    r26 = _h_128;
    r27 = _v_6;
    WL_RETN(28);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_COMMANDS_0)
  {
    Term _owners_0 = r0;
    WL_OPEN
    if (term_aux(_owners_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = term_pak(CID_NIL, 0);
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _owners_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      u32 _o_12 = 0;
      Term _o_13 = 0;
      u32 _o_14 = 0;
      u32 _o_15 = 0;
      u32 _o_16 = 0;
      if (term_aux(_f_0) == CID_STORAGE_SPAWN) {
        _o_0 = 0;
        Term _fb_1[7];
        u64 _sp_1 = ctr_take(e, _f_0, 7, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        u32 _f_7 = _fb_1[5];
        Term _f_8 = _fb_1[6];
        spare_free(e, cls_fit(7), _sp_1);
        u32 _o_17 = 0;
        Term _o_18 = 0;
        u32 _o_19 = 0;
        u32 _o_20 = 0;
        u32 _o_21 = 0;
        u32 _o_22 = 0;
        u32 _o_23 = 0;
        u32 _o_24 = 0;
        u32 _o_25 = 0;
        u32 _o_26 = 0;
        if (_f_3 == 0) {
          _o_17 = 0;
        } else {
          _o_17 = 1;
          Term _fb_2[2];
          u64 _sp_2 = ctr_take(e, _f_4, 2, _fb_2);
          Term _f_9 = _fb_2[0];
          Term _f_10 = _fb_2[1];
          spare_free(e, cls_fit(2), _sp_2);
          Term _fb_3[3];
          u64 _sp_3 = ctr_take(e, _f_9, 3, _fb_3);
          Term _f_11 = _fb_3[0];
          u32 _f_12 = _fb_3[1];
          u32 _f_13 = _fb_3[2];
          spare_free(e, cls_fit(3), _sp_3);
          Term _fb_4[6];
          u64 _sp_4 = ctr_take(e, _f_10, 6, _fb_4);
          u32 _f_14 = _fb_4[0];
          u32 _f_15 = _fb_4[1];
          u32 _f_16 = _fb_4[2];
          u32 _f_17 = _fb_4[3];
          u32 _f_18 = _fb_4[4];
          u32 _f_19 = _fb_4[5];
          spare_free(e, cls_fit(6), _sp_4);
          _o_18 = _f_11;
          _o_19 = _f_12;
          _o_20 = _f_13;
          _o_21 = _f_14;
          _o_22 = _f_15;
          _o_23 = _f_16;
          _o_24 = _f_17;
          _o_25 = _f_18;
          _o_26 = _f_19;
        }
        u32 _o_27 = 0;
        Term _o_28 = 0;
        u32 _o_29 = 0;
        if (_f_5 == 0) {
          _o_27 = 0;
        } else {
          _o_27 = 1;
          Term _fb_5[2];
          u64 _sp_5 = ctr_take(e, _f_6, 2, _fb_5);
          Term _f_20 = _fb_5[0];
          u32 _f_21 = _fb_5[1];
          spare_free(e, cls_fit(2), _sp_5);
          _o_28 = _f_20;
          _o_29 = _f_21;
        }
        u32 _o_30 = 0;
        u32 _o_31 = 0;
        if (_f_7 == 0) {
          _o_30 = 0;
        } else {
          _o_30 = 1;
          _o_31 = term_loc(_f_8);
        }
        _o_1 = _f_2;
        _o_2 = _o_17;
        _o_3 = _o_18;
        _o_4 = _o_19;
        _o_5 = _o_20;
        _o_6 = _o_21;
        _o_7 = _o_22;
        _o_8 = _o_23;
        _o_9 = _o_24;
        _o_10 = _o_25;
        _o_11 = _o_26;
        _o_12 = _o_27;
        _o_13 = _o_28;
        _o_14 = _o_29;
        _o_15 = _o_30;
        _o_16 = _o_31;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTMAIN) {
        _o_0 = 1;
        Term _fb_6[2];
        u64 _sp_6 = ctr_take(e, _f_0, 2, _fb_6);
        u32 _f_22 = _fb_6[0];
        Term _f_23 = _fb_6[1];
        spare_free(e, cls_fit(2), _sp_6);
        Term _fb_7[2];
        u64 _sp_7 = ctr_take(e, _f_23, 2, _fb_7);
        Term _f_24 = _fb_7[0];
        Term _f_25 = _fb_7[1];
        spare_free(e, cls_fit(2), _sp_7);
        Term _fb_8[3];
        u64 _sp_8 = ctr_take(e, _f_24, 3, _fb_8);
        Term _f_26 = _fb_8[0];
        u32 _f_27 = _fb_8[1];
        u32 _f_28 = _fb_8[2];
        spare_free(e, cls_fit(3), _sp_8);
        Term _fb_9[6];
        u64 _sp_9 = ctr_take(e, _f_25, 6, _fb_9);
        u32 _f_29 = _fb_9[0];
        u32 _f_30 = _fb_9[1];
        u32 _f_31 = _fb_9[2];
        u32 _f_32 = _fb_9[3];
        u32 _f_33 = _fb_9[4];
        u32 _f_34 = _fb_9[5];
        spare_free(e, cls_fit(6), _sp_9);
        _o_1 = _f_22;
        _o_2 = _f_26;
        _o_3 = _f_27;
        _o_4 = _f_28;
        _o_5 = _f_29;
        _o_6 = _f_30;
        _o_7 = _f_31;
        _o_8 = _f_32;
        _o_9 = _f_33;
        _o_10 = _f_34;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTFLAG) {
        _o_0 = 2;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _f_0, 2, _fb_10);
        u32 _f_35 = _fb_10[0];
        Term _f_36 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        _o_1 = _f_35;
        _o_2 = term_loc(_f_36);
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEMAIN) {
        _o_0 = 3;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEFLAG) {
        _o_0 = 4;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 5;
        _o_1 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_OBSERVATIONS_COMMANDS_0_K446;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_OBSERVATIONS_COMMANDS_0_K446, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_OBSERVATIONS_COMMANDS_0_K446, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_COMMAND_0)) {
        u64 _t_1 = task_node(e, FID_OBSERVATIONS_COMMAND_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        e.mem[_t_1 + 6] = _o_6;
        e.mem[_t_1 + 7] = _o_7;
        e.mem[_t_1 + 8] = _o_8;
        e.mem[_t_1 + 9] = _o_9;
        e.mem[_t_1 + 10] = _o_10;
        e.mem[_t_1 + 11] = _o_11;
        e.mem[_t_1 + 12] = _o_12;
        e.mem[_t_1 + 13] = _o_13;
        e.mem[_t_1 + 14] = _o_14;
        e.mem[_t_1 + 15] = _o_15;
        e.mem[_t_1 + 16] = _o_16;
        return term_tsk(FID_OBSERVATIONS_COMMAND_0, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      r6 = _o_6;
      r7 = _o_7;
      r8 = _o_8;
      r9 = _o_9;
      r10 = _o_10;
      r11 = _o_11;
      r12 = _o_12;
      r13 = _o_13;
      r14 = _o_14;
      r15 = _o_15;
      r16 = _o_16;
      WL_JMP(FID_OBSERVATIONS_COMMAND_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_COMMANDS_0_K446)
  {
    WL_POPN(1);
    Term _f_37 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    u32 _h_27 = r27;
    u32 _h_28 = r28;
    u32 _h_29 = r29;
    u32 _h_30 = r30;
    u32 _h_31 = r31;
    u32 _h_32 = r32;
    u32 _h_33 = r33;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = _h_3;
      STK(4) = _h_4;
      STK(5) = _h_5;
      STK(6) = _h_6;
      STK(7) = _h_7;
      STK(8) = _h_8;
      STK(9) = _h_9;
      STK(10) = _h_10;
      STK(11) = _h_11;
      STK(12) = _h_12;
      STK(13) = _h_13;
      STK(14) = _h_14;
      STK(15) = _h_15;
      STK(16) = _h_16;
      STK(17) = _h_17;
      STK(18) = _h_18;
      STK(19) = _h_19;
      STK(20) = _h_20;
      STK(21) = _h_21;
      STK(22) = _h_22;
      STK(23) = _h_23;
      STK(24) = _h_24;
      STK(25) = _h_25;
      STK(26) = _h_26;
      STK(27) = _h_27;
      STK(28) = _h_28;
      STK(29) = _h_29;
      STK(30) = _h_30;
      STK(31) = _h_31;
      STK(32) = _h_32;
      STK(33) = _h_33;
      STK(34) = FID_OBSERVATIONS_COMMANDS_0_K447;
      WL_PUSHN(35);
    } else {
      u64 _t_2 = task_node(e, FID_OBSERVATIONS_COMMANDS_0_K447, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      e.mem[_t_2 + 3] = _h_3;
      e.mem[_t_2 + 4] = _h_4;
      e.mem[_t_2 + 5] = _h_5;
      e.mem[_t_2 + 6] = _h_6;
      e.mem[_t_2 + 7] = _h_7;
      e.mem[_t_2 + 8] = _h_8;
      e.mem[_t_2 + 9] = _h_9;
      e.mem[_t_2 + 10] = _h_10;
      e.mem[_t_2 + 11] = _h_11;
      e.mem[_t_2 + 12] = _h_12;
      e.mem[_t_2 + 13] = _h_13;
      e.mem[_t_2 + 14] = _h_14;
      e.mem[_t_2 + 15] = _h_15;
      e.mem[_t_2 + 16] = _h_16;
      e.mem[_t_2 + 17] = _h_17;
      e.mem[_t_2 + 18] = _h_18;
      e.mem[_t_2 + 19] = _h_19;
      e.mem[_t_2 + 20] = _h_20;
      e.mem[_t_2 + 21] = _h_21;
      e.mem[_t_2 + 22] = _h_22;
      e.mem[_t_2 + 23] = _h_23;
      e.mem[_t_2 + 24] = _h_24;
      e.mem[_t_2 + 25] = _h_25;
      e.mem[_t_2 + 26] = _h_26;
      e.mem[_t_2 + 27] = _h_27;
      e.mem[_t_2 + 28] = _h_28;
      e.mem[_t_2 + 29] = _h_29;
      e.mem[_t_2 + 30] = _h_30;
      e.mem[_t_2 + 31] = _h_31;
      e.mem[_t_2 + 32] = _h_32;
      e.mem[_t_2 + 33] = _h_33;
      WL_CONT = term_tsk(FID_OBSERVATIONS_COMMANDS_0_K447, _t_2);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_COMMANDS_0)) {
      u64 _t_3 = task_node(e, FID_OBSERVATIONS_COMMANDS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_37;
      return term_tsk(FID_OBSERVATIONS_COMMANDS_0, _t_3);
    }
    r0 = _f_37;
    WL_JMP(FID_OBSERVATIONS_COMMANDS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVATIONS_COMMANDS_0_K447)
  {
    WL_POPN(34);
    u32 _h_36 = STK(0);
    u32 _h_37 = STK(1);
    Term _h_38 = STK(2);
    Term _h_39 = STK(3);
    u32 _h_40 = STK(4);
    u32 _h_41 = STK(5);
    u32 _h_42 = STK(6);
    u32 _h_43 = STK(7);
    u32 _h_44 = STK(8);
    u32 _h_45 = STK(9);
    u32 _h_46 = STK(10);
    u32 _h_47 = STK(11);
    u32 _h_48 = STK(12);
    Term _h_49 = STK(13);
    u32 _h_50 = STK(14);
    u32 _h_51 = STK(15);
    u32 _h_52 = STK(16);
    u32 _h_53 = STK(17);
    u32 _h_54 = STK(18);
    u32 _h_55 = STK(19);
    u32 _h_56 = STK(20);
    u32 _h_57 = STK(21);
    u32 _h_58 = STK(22);
    u32 _h_59 = STK(23);
    u32 _h_60 = STK(24);
    u32 _h_61 = STK(25);
    u32 _h_62 = STK(26);
    u32 _h_63 = STK(27);
    u32 _h_64 = STK(28);
    u32 _h_65 = STK(29);
    u32 _h_66 = STK(30);
    u32 _h_67 = STK(31);
    u32 _h_68 = STK(32);
    u32 _h_69 = STK(33);
    Term _h_34 = r0;
    Term _h_35 = r1;
    WL_OPEN
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    Term _o_34 = 0;
    Term _o_35 = 0;
    u32 _o_36 = 0;
    Term _o_37 = 0;
    u32 _o_38 = 0;
    Term _o_39 = 0;
    if (_h_36 == 0) {
      _o_32 = 0;
      u32 _o_40 = 0;
      Term _o_41 = 0;
      if (_h_38 == 0) {
        _o_40 = 0;
      } else {
        _o_40 = 1;
        u64 _nd_0 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_0 + 0] = rfc_seal(e, _h_39);
        e.mem[_nd_0 + 1] = rfc_seal(e, _h_40);
        e.mem[_nd_0 + 2] = rfc_seal(e, _h_41);
        u64 _nd_1 = heap_alloc(e, cls_fit(6));
        e.mem[_nd_1 + 0] = rfc_seal(e, _h_42);
        e.mem[_nd_1 + 1] = rfc_seal(e, _h_43);
        e.mem[_nd_1 + 2] = rfc_seal(e, _h_44);
        e.mem[_nd_1 + 3] = rfc_seal(e, _h_45);
        e.mem[_nd_1 + 4] = rfc_seal(e, _h_46);
        e.mem[_nd_1 + 5] = rfc_seal(e, _h_47);
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_0));
        e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_1));
        _o_41 = term_ctr(CID_CACHE_CACHE, _nd_2);
      }
      u32 _o_42 = 0;
      Term _o_43 = 0;
      if (_h_48 == 0) {
        _o_42 = 0;
      } else {
        _o_42 = 1;
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, _h_49);
        e.mem[_nd_3 + 1] = rfc_seal(e, _h_50);
        _o_43 = term_ctr(CID_TYPES_ARMOR, _nd_3);
      }
      u32 _o_44 = 0;
      Term _o_45 = 0;
      if (_h_51 == 0) {
        _o_44 = 0;
      } else {
        _o_44 = 1;
        _o_45 = term_pak(CID_TYPES_TRACKED, _h_52);
      }
      _o_33 = _h_37;
      _o_34 = _o_40;
      _o_35 = _o_41;
      _o_36 = _o_42;
      _o_37 = _o_43;
      _o_38 = _o_44;
      _o_39 = _o_45;
    } else if (_h_36 == 1) {
      _o_32 = 1;
      u64 _nd_4 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_4 + 0] = rfc_seal(e, _h_38);
      e.mem[_nd_4 + 1] = rfc_seal(e, _h_39);
      e.mem[_nd_4 + 2] = rfc_seal(e, _h_40);
      u64 _nd_5 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_5 + 0] = rfc_seal(e, _h_41);
      e.mem[_nd_5 + 1] = rfc_seal(e, _h_42);
      e.mem[_nd_5 + 2] = rfc_seal(e, _h_43);
      e.mem[_nd_5 + 3] = rfc_seal(e, _h_44);
      e.mem[_nd_5 + 4] = rfc_seal(e, _h_45);
      e.mem[_nd_5 + 5] = rfc_seal(e, _h_46);
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_TYPES_VITALS, _nd_4));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_TYPES_VITALSVIEW, _nd_5));
      _o_33 = _h_37;
      _o_34 = term_ctr(CID_CACHE_CACHE, _nd_6);
    } else if (_h_36 == 2) {
      _o_32 = 2;
      _o_33 = _h_37;
      _o_34 = term_pak(CID_TYPES_TRACKED, _h_38);
    } else if (_h_36 == 3) {
      _o_32 = 3;
      _o_33 = _h_37;
    } else if (_h_36 == 4) {
      _o_32 = 4;
      _o_33 = _h_37;
    } else {
      _o_32 = 5;
      _o_33 = _h_37;
    }
    u32 _o_46 = 0;
    u32 _o_47 = 0;
    Term _o_48 = 0;
    Term _o_49 = 0;
    u32 _o_50 = 0;
    Term _o_51 = 0;
    u32 _o_52 = 0;
    Term _o_53 = 0;
    if (_h_53 == 0) {
      _o_46 = 0;
      u32 _o_54 = 0;
      Term _o_55 = 0;
      if (_h_55 == 0) {
        _o_54 = 0;
      } else {
        _o_54 = 1;
        u64 _nd_7 = heap_alloc(e, cls_fit(6));
        e.mem[_nd_7 + 0] = rfc_seal(e, _h_56);
        e.mem[_nd_7 + 1] = rfc_seal(e, _h_57);
        e.mem[_nd_7 + 2] = rfc_seal(e, _h_58);
        e.mem[_nd_7 + 3] = rfc_seal(e, _h_59);
        e.mem[_nd_7 + 4] = rfc_seal(e, _h_60);
        e.mem[_nd_7 + 5] = rfc_seal(e, _h_61);
        _o_55 = term_ctr(CID_TYPES_VITALSVIEW, _nd_7);
      }
      u32 _o_56 = 0;
      Term _o_57 = 0;
      if (_h_62 == 0) {
        _o_56 = 0;
      } else {
        _o_56 = 1;
        u64 _nd_8 = heap_alloc(e, cls_fit(5));
        e.mem[_nd_8 + 0] = rfc_seal(e, _h_63);
        e.mem[_nd_8 + 1] = rfc_seal(e, _h_64);
        e.mem[_nd_8 + 2] = rfc_seal(e, _h_65);
        e.mem[_nd_8 + 3] = rfc_seal(e, _h_66);
        e.mem[_nd_8 + 4] = rfc_seal(e, _h_67);
        _o_57 = term_ctr(CID_TYPES_ARMORVIEW, _nd_8);
      }
      u32 _o_58 = 0;
      Term _o_59 = 0;
      if (_h_68 == 0) {
        _o_58 = 0;
      } else {
        _o_58 = 1;
        _o_59 = term_pak(CID_TYPES_TRACKED, _h_69);
      }
      _o_47 = _h_54;
      _o_48 = _o_54;
      _o_49 = _o_55;
      _o_50 = _o_56;
      _o_51 = _o_57;
      _o_52 = _o_58;
      _o_53 = _o_59;
    } else if (_h_53 == 1) {
      _o_46 = 1;
      u64 _nd_9 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_9 + 0] = rfc_seal(e, _h_55);
      e.mem[_nd_9 + 1] = rfc_seal(e, _h_56);
      e.mem[_nd_9 + 2] = rfc_seal(e, _h_57);
      e.mem[_nd_9 + 3] = rfc_seal(e, _h_58);
      e.mem[_nd_9 + 4] = rfc_seal(e, _h_59);
      e.mem[_nd_9 + 5] = rfc_seal(e, _h_60);
      _o_47 = _h_54;
      _o_48 = term_ctr(CID_TYPES_VITALSVIEW, _nd_9);
    } else if (_h_53 == 2) {
      _o_46 = 2;
      _o_47 = _h_54;
      _o_48 = term_pak(CID_TYPES_TRACKED, _h_55);
    } else if (_h_53 == 3) {
      _o_46 = 3;
      _o_47 = _h_54;
    } else if (_h_53 == 4) {
      _o_46 = 4;
      _o_47 = _h_54;
    } else {
      _o_46 = 5;
      _o_47 = _h_54;
    }
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_61[2];
    if (spin_158(e, _o_61, _o_32, _o_33, _o_34, blk_loc(e.mem, _o_34), _o_35, blk_loc(e.mem, _o_35), _o_36, _o_37, blk_loc(e.mem, _o_37), _o_38, _o_39, blk_loc(e.mem, _o_39), _o_46, _o_47, _o_48, blk_loc(e.mem, _o_48), _o_49, blk_loc(e.mem, _o_49), _o_50, _o_51, blk_loc(e.mem, _o_51), _o_52, _o_53, blk_loc(e.mem, _o_53), _h_34, blk_loc(e.mem, _h_34), _h_35, blk_loc(e.mem, _h_35)) == 0) {
      return 0;
    }
    _v_0 = _o_61[0];
    _v_1 = _o_61[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HELD_ADAPTER_HEALTH_ROW_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    Term _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    u32 _owner_8 = r8;
    Term _owner_9 = r9;
    u32 _owner_10 = r10;
    Term _owner_11 = r11;
    u32 _owner_12 = r12;
    Term _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    u32 _owner_17 = r17;
    u32 _owner_18 = r18;
    u32 _owner_19 = r19;
    u32 _owner_20 = r20;
    u32 _owner_21 = r21;
    u32 _owner_22 = r22;
    Term _owner_23 = r23;
    Term _owner_24 = r24;
    Term _owner_25 = r25;
    Term _owner_26 = r26;
    WL_OPEN
    u32 _s_0 = U32_BIN(_owner_0, ==, _owner_21);
    if (_s_0 == 1) {
      if (_owner_12 == 1) {
        Term _v_0 = 0;
        Term _v_1 = 0;
        Term _v_2 = 0;
        Term _v_3 = 0;
        Term _v_4 = 0;
        Term _v_5 = 0;
        u32 _v_6 = 0;
        Term _v_7 = 0;
        u32 _v_8 = 0;
        u32 _v_9 = 0;
        Term _v_10 = 0;
        Term _v_11 = 0;
        Term _v_12 = 0;
        Term _v_13 = 0;
        Term _v_14 = 0;
        Term _v_15 = 0;
        Term _v_16 = 0;
        u32 _v_17 = 0;
        Term _v_18 = 0;
        u32 _v_19 = 0;
        u32 _v_20 = 0;
        Term _v_21 = 0;
        Term _o_0[11];
        if (spin_143(e, _o_0, _owner_2, blk_loc(e.mem, _owner_2), _owner_3, blk_loc(e.mem, _owner_3), _owner_4, blk_loc(e.mem, _owner_4), _owner_5, blk_loc(e.mem, _owner_5), _owner_6, blk_loc(e.mem, _owner_6), _owner_7, blk_loc(e.mem, _owner_7), _owner_8, _owner_9, _owner_10, _owner_22) == 0) {
          return 0;
        }
        _v_11 = _o_0[0];
        _v_12 = _o_0[1];
        _v_13 = _o_0[2];
        _v_14 = _o_0[3];
        _v_15 = _o_0[4];
        _v_16 = _o_0[5];
        _v_17 = _o_0[6];
        _v_18 = _o_0[7];
        _v_19 = _o_0[8];
        _v_20 = _o_0[9];
        _v_21 = _o_0[10];
        _v_0 = _v_11;
        _v_1 = _v_12;
        _v_2 = _v_13;
        _v_3 = _v_14;
        _v_4 = _v_15;
        _v_5 = _v_16;
        _v_6 = _v_17;
        _v_7 = _v_18;
        _v_8 = _v_19;
        _v_9 = _v_20;
        _v_10 = _v_21;
        u32 _o_1 = 0;
        Term _o_2 = 0;
        u32 _o_3 = 0;
        u32 _o_4 = 0;
        u32 _o_5 = 0;
        u32 _o_6 = 0;
        u32 _o_7 = 0;
        u32 _o_8 = 0;
        u32 _o_9 = 0;
        u32 _o_10 = 0;
        if (_v_9 == 0) {
          _o_1 = 0;
          Term _fb_0[2];
          u64 _sp_0 = ctr_take(e, _v_10, 2, _fb_0);
          Term _f_0 = _fb_0[0];
          Term _f_1 = _fb_0[1];
          spare_free(e, cls_fit(2), _sp_0);
          Term _fb_1[3];
          u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
          Term _f_2 = _fb_1[0];
          u32 _f_3 = _fb_1[1];
          u32 _f_4 = _fb_1[2];
          spare_free(e, cls_fit(3), _sp_1);
          Term _fb_2[6];
          u64 _sp_2 = ctr_take(e, _f_1, 6, _fb_2);
          u32 _f_5 = _fb_2[0];
          u32 _f_6 = _fb_2[1];
          u32 _f_7 = _fb_2[2];
          u32 _f_8 = _fb_2[3];
          u32 _f_9 = _fb_2[4];
          u32 _f_10 = _fb_2[5];
          spare_free(e, cls_fit(6), _sp_2);
          _o_2 = _f_2;
          _o_3 = _f_3;
          _o_4 = _f_4;
          _o_5 = _f_5;
          _o_6 = _f_6;
          _o_7 = _f_7;
          _o_8 = _f_8;
          _o_9 = _f_9;
          _o_10 = _f_10;
        } else if (_v_9 == 1) {
          _o_1 = 1;
        } else {
          _o_1 = 2;
        }
        if (_o_1 == 0) {
          Term _v_22 = 0;
          u32 _v_23 = 0;
          u32 _v_24 = 0;
          u32 _v_25 = 0;
          u32 _v_26 = 0;
          u32 _v_27 = 0;
          u32 _v_28 = 0;
          u32 _v_29 = 0;
          u32 _v_30 = 0;
          Term _v_31 = 0;
          u32 _v_32 = 0;
          u32 _v_33 = 0;
          u32 _v_34 = 0;
          u32 _v_35 = 0;
          u32 _v_36 = 0;
          u32 _v_37 = 0;
          u32 _v_38 = 0;
          u32 _v_39 = 0;
          Term _v_40 = 0;
          Term _v_41 = 0;
          u32 _v_42 = 0;
          Term _v_43 = 0;
          u32 _v_44 = 0;
          u32 _v_45 = 0;
          u32 _v_46 = 0;
          u32 _v_47 = 0;
          u32 _v_48 = 0;
          u32 _v_49 = 0;
          u32 _v_50 = 0;
          u32 _v_51 = 0;
          Term _v_52 = 0;
          u32 _v_53 = 0;
          u32 _v_54 = 0;
          u32 _v_55 = 0;
          u32 _v_56 = 0;
          u32 _v_57 = 0;
          u32 _v_58 = 0;
          u32 _v_59 = 0;
          u32 _v_60 = 0;
          Term _v_61 = 0;
          Term _v_62 = 0;
          u32 _v_63 = 0;
          Term _o_11[21];
          if (spin_131(e, _o_11, _o_2, blk_loc(e.mem, _o_2), _o_3, _o_4, _o_5, _o_6, _o_7, _o_8, _o_9, _o_10, _owner_13, blk_loc(e.mem, _owner_13), _owner_14, _owner_15, _owner_16, _owner_17, _owner_18, _owner_19, _owner_21, _owner_22, _owner_23, blk_loc(e.mem, _owner_23), _owner_26, blk_loc(e.mem, _owner_26)) == 0) {
            return 0;
          }
          _v_43 = _o_11[0];
          _v_44 = _o_11[1];
          _v_45 = _o_11[2];
          _v_46 = _o_11[3];
          _v_47 = _o_11[4];
          _v_48 = _o_11[5];
          _v_49 = _o_11[6];
          _v_50 = _o_11[7];
          _v_51 = _o_11[8];
          _v_52 = _o_11[9];
          _v_53 = _o_11[10];
          _v_54 = _o_11[11];
          _v_55 = _o_11[12];
          _v_56 = _o_11[13];
          _v_57 = _o_11[14];
          _v_58 = _o_11[15];
          _v_59 = _o_11[16];
          _v_60 = _o_11[17];
          _v_61 = _o_11[18];
          _v_62 = _o_11[19];
          _v_63 = _o_11[20];
          _v_22 = _v_43;
          _v_23 = _v_44;
          _v_24 = _v_45;
          _v_25 = _v_46;
          _v_26 = _v_47;
          _v_27 = _v_48;
          _v_28 = _v_49;
          _v_29 = _v_50;
          _v_30 = _v_51;
          _v_31 = _v_52;
          _v_32 = _v_53;
          _v_33 = _v_54;
          _v_34 = _v_55;
          _v_35 = _v_56;
          _v_36 = _v_57;
          _v_37 = _v_58;
          _v_38 = _v_59;
          _v_39 = _v_60;
          _v_40 = _v_61;
          _v_41 = _v_62;
          _v_42 = _v_63;
          u32 _v_64 = 0;
          u32 _v_65 = 0;
          Term _v_66 = 0;
          Term _v_67 = 0;
          Term _v_68 = 0;
          Term _v_69 = 0;
          Term _v_70 = 0;
          Term _v_71 = 0;
          u32 _v_72 = 0;
          Term _v_73 = 0;
          u32 _v_74 = 0;
          Term _v_75 = 0;
          u32 _v_76 = 0;
          Term _v_77 = 0;
          u32 _v_78 = 0;
          u32 _v_79 = 0;
          u32 _v_80 = 0;
          u32 _v_81 = 0;
          u32 _v_82 = 0;
          u32 _v_83 = 0;
          u32 _v_84 = 0;
          u32 _v_85 = 0;
          u32 _v_86 = 0;
          Term _v_87 = 0;
          Term _v_88 = 0;
          Term _v_89 = 0;
          Term _v_90 = 0;
          u32 _v_91 = 0;
          Term _o_12[28];
          if (spin_132(e, _o_12, _v_22, blk_loc(e.mem, _v_22), _v_23, _v_24, _v_25, _v_26, _v_27, _v_28, _v_29, _v_30, _v_31, blk_loc(e.mem, _v_31), _v_32, _v_33, _v_34, _v_35, _v_36, _v_37, _v_38, _v_39, _v_40, blk_loc(e.mem, _v_40), _v_41, blk_loc(e.mem, _v_41), _v_42, _owner_0, _owner_1, _v_0, blk_loc(e.mem, _v_0), _v_1, blk_loc(e.mem, _v_1), _v_2, blk_loc(e.mem, _v_2), _v_3, blk_loc(e.mem, _v_3), _v_4, blk_loc(e.mem, _v_4), _v_5, blk_loc(e.mem, _v_5), _v_6, _v_7, _v_8, _owner_11, blk_loc(e.mem, _owner_11), _owner_20, _owner_24, blk_loc(e.mem, _owner_24), _owner_25, blk_loc(e.mem, _owner_25)) == 0) {
            return 0;
          }
          _v_64 = _o_12[0];
          _v_65 = _o_12[1];
          _v_66 = _o_12[2];
          _v_67 = _o_12[3];
          _v_68 = _o_12[4];
          _v_69 = _o_12[5];
          _v_70 = _o_12[6];
          _v_71 = _o_12[7];
          _v_72 = _o_12[8];
          _v_73 = _o_12[9];
          _v_74 = _o_12[10];
          _v_75 = _o_12[11];
          _v_76 = _o_12[12];
          _v_77 = _o_12[13];
          _v_78 = _o_12[14];
          _v_79 = _o_12[15];
          _v_80 = _o_12[16];
          _v_81 = _o_12[17];
          _v_82 = _o_12[18];
          _v_83 = _o_12[19];
          _v_84 = _o_12[20];
          _v_85 = _o_12[21];
          _v_86 = _o_12[22];
          _v_87 = _o_12[23];
          _v_88 = _o_12[24];
          _v_89 = _o_12[25];
          _v_90 = _o_12[26];
          _v_91 = _o_12[27];
          r0 = _v_64;
          r1 = _v_65;
          r2 = _v_66;
          r3 = _v_67;
          r4 = _v_68;
          r5 = _v_69;
          r6 = _v_70;
          r7 = _v_71;
          r8 = _v_72;
          r9 = _v_73;
          r10 = _v_74;
          r11 = _v_75;
          r12 = _v_76;
          r13 = _v_77;
          r14 = _v_78;
          r15 = _v_79;
          r16 = _v_80;
          r17 = _v_81;
          r18 = _v_82;
          r19 = _v_83;
          r20 = _v_84;
          r21 = _v_85;
          r22 = _v_86;
          r23 = _v_87;
          r24 = _v_88;
          r25 = _v_89;
          r26 = _v_90;
          r27 = _v_91;
          WL_RETN(28);
        } else {
          term_sink(e, _o_2);
          if (!DEVICE && !seq && fid_nofk(FID_GATE_CALLBACKS_HEALTH_BODY_0)) {
            u64 _t_0 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_0 + 0] = _owner_0;
            e.mem[_t_0 + 1] = _owner_1;
            e.mem[_t_0 + 2] = _v_0;
            e.mem[_t_0 + 3] = _v_1;
            e.mem[_t_0 + 4] = _v_2;
            e.mem[_t_0 + 5] = _v_3;
            e.mem[_t_0 + 6] = _v_4;
            e.mem[_t_0 + 7] = _v_5;
            e.mem[_t_0 + 8] = _v_6;
            e.mem[_t_0 + 9] = _v_7;
            e.mem[_t_0 + 10] = _v_8;
            e.mem[_t_0 + 11] = _owner_11;
            e.mem[_t_0 + 12] = 1;
            e.mem[_t_0 + 13] = _owner_13;
            e.mem[_t_0 + 14] = _owner_14;
            e.mem[_t_0 + 15] = _owner_15;
            e.mem[_t_0 + 16] = _owner_16;
            e.mem[_t_0 + 17] = _owner_17;
            e.mem[_t_0 + 18] = _owner_18;
            e.mem[_t_0 + 19] = _owner_19;
            e.mem[_t_0 + 20] = _owner_20;
            e.mem[_t_0 + 21] = _owner_21;
            e.mem[_t_0 + 22] = _owner_22;
            e.mem[_t_0 + 23] = _owner_23;
            e.mem[_t_0 + 24] = _owner_24;
            e.mem[_t_0 + 25] = _owner_25;
            e.mem[_t_0 + 26] = _owner_26;
            return term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0, _t_0);
          }
          r0 = _owner_0;
          r1 = _owner_1;
          r2 = _v_0;
          r3 = _v_1;
          r4 = _v_2;
          r5 = _v_3;
          r6 = _v_4;
          r7 = _v_5;
          r8 = _v_6;
          r9 = _v_7;
          r10 = _v_8;
          r11 = _owner_11;
          r12 = 1;
          r13 = _owner_13;
          r14 = _owner_14;
          r15 = _owner_15;
          r16 = _owner_16;
          r17 = _owner_17;
          r18 = _owner_18;
          r19 = _owner_19;
          r20 = _owner_20;
          r21 = _owner_21;
          r22 = _owner_22;
          r23 = _owner_23;
          r24 = _owner_24;
          r25 = _owner_25;
          r26 = _owner_26;
          WL_JMP(FID_GATE_CALLBACKS_HEALTH_BODY_0);
        }
      } else {
        if (!DEVICE && !seq && fid_nofk(FID_GATE_CALLBACKS_HEALTH_BODY_0)) {
          u64 _t_1 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _owner_0;
          e.mem[_t_1 + 1] = _owner_1;
          e.mem[_t_1 + 2] = _owner_2;
          e.mem[_t_1 + 3] = _owner_3;
          e.mem[_t_1 + 4] = _owner_4;
          e.mem[_t_1 + 5] = _owner_5;
          e.mem[_t_1 + 6] = _owner_6;
          e.mem[_t_1 + 7] = _owner_7;
          e.mem[_t_1 + 8] = _owner_8;
          e.mem[_t_1 + 9] = _owner_9;
          e.mem[_t_1 + 10] = _owner_10;
          e.mem[_t_1 + 11] = _owner_11;
          e.mem[_t_1 + 12] = _owner_12;
          e.mem[_t_1 + 13] = _owner_13;
          e.mem[_t_1 + 14] = _owner_14;
          e.mem[_t_1 + 15] = _owner_15;
          e.mem[_t_1 + 16] = _owner_16;
          e.mem[_t_1 + 17] = _owner_17;
          e.mem[_t_1 + 18] = _owner_18;
          e.mem[_t_1 + 19] = _owner_19;
          e.mem[_t_1 + 20] = _owner_20;
          e.mem[_t_1 + 21] = _owner_21;
          e.mem[_t_1 + 22] = _owner_22;
          e.mem[_t_1 + 23] = _owner_23;
          e.mem[_t_1 + 24] = _owner_24;
          e.mem[_t_1 + 25] = _owner_25;
          e.mem[_t_1 + 26] = _owner_26;
          return term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0, _t_1);
        }
        r0 = _owner_0;
        r1 = _owner_1;
        r2 = _owner_2;
        r3 = _owner_3;
        r4 = _owner_4;
        r5 = _owner_5;
        r6 = _owner_6;
        r7 = _owner_7;
        r8 = _owner_8;
        r9 = _owner_9;
        r10 = _owner_10;
        r11 = _owner_11;
        r12 = _owner_12;
        r13 = _owner_13;
        r14 = _owner_14;
        r15 = _owner_15;
        r16 = _owner_16;
        r17 = _owner_17;
        r18 = _owner_18;
        r19 = _owner_19;
        r20 = _owner_20;
        r21 = _owner_21;
        r22 = _owner_22;
        r23 = _owner_23;
        r24 = _owner_24;
        r25 = _owner_25;
        r26 = _owner_26;
        WL_JMP(FID_GATE_CALLBACKS_HEALTH_BODY_0);
      }
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_GATE_CALLBACKS_HEALTH_BODY_0)) {
        u64 _t_2 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_2 + 0] = _owner_0;
        e.mem[_t_2 + 1] = _owner_1;
        e.mem[_t_2 + 2] = _owner_2;
        e.mem[_t_2 + 3] = _owner_3;
        e.mem[_t_2 + 4] = _owner_4;
        e.mem[_t_2 + 5] = _owner_5;
        e.mem[_t_2 + 6] = _owner_6;
        e.mem[_t_2 + 7] = _owner_7;
        e.mem[_t_2 + 8] = _owner_8;
        e.mem[_t_2 + 9] = _owner_9;
        e.mem[_t_2 + 10] = _owner_10;
        e.mem[_t_2 + 11] = _owner_11;
        e.mem[_t_2 + 12] = _owner_12;
        e.mem[_t_2 + 13] = _owner_13;
        e.mem[_t_2 + 14] = _owner_14;
        e.mem[_t_2 + 15] = _owner_15;
        e.mem[_t_2 + 16] = _owner_16;
        e.mem[_t_2 + 17] = _owner_17;
        e.mem[_t_2 + 18] = _owner_18;
        e.mem[_t_2 + 19] = _owner_19;
        e.mem[_t_2 + 20] = _owner_20;
        e.mem[_t_2 + 21] = _owner_21;
        e.mem[_t_2 + 22] = _owner_22;
        e.mem[_t_2 + 23] = _owner_23;
        e.mem[_t_2 + 24] = _owner_24;
        e.mem[_t_2 + 25] = _owner_25;
        e.mem[_t_2 + 26] = _owner_26;
        return term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0, _t_2);
      }
      r0 = _owner_0;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = _owner_3;
      r4 = _owner_4;
      r5 = _owner_5;
      r6 = _owner_6;
      r7 = _owner_7;
      r8 = _owner_8;
      r9 = _owner_9;
      r10 = _owner_10;
      r11 = _owner_11;
      r12 = _owner_12;
      r13 = _owner_13;
      r14 = _owner_14;
      r15 = _owner_15;
      r16 = _owner_16;
      r17 = _owner_17;
      r18 = _owner_18;
      r19 = _owner_19;
      r20 = _owner_20;
      r21 = _owner_21;
      r22 = _owner_22;
      r23 = _owner_23;
      r24 = _owner_24;
      r25 = _owner_25;
      r26 = _owner_26;
      WL_JMP(FID_GATE_CALLBACKS_HEALTH_BODY_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_FINISH)
  {
    u32 _fail_0 = r0;
    u32 _owner_0 = r1;
    u32 _owner_1 = r2;
    Term _owner_2 = r3;
    Term _owner_3 = r4;
    Term _owner_4 = r5;
    Term _owner_5 = r6;
    Term _owner_6 = r7;
    Term _owner_7 = r8;
    u32 _owner_8 = r9;
    Term _owner_9 = r10;
    u32 _owner_10 = r11;
    Term _owner_11 = r12;
    u32 _owner_12 = r13;
    Term _owner_13 = r14;
    u32 _owner_14 = r15;
    u32 _owner_15 = r16;
    u32 _owner_16 = r17;
    u32 _owner_17 = r18;
    u32 _owner_18 = r19;
    u32 _owner_19 = r20;
    u32 _owner_20 = r21;
    u32 _owner_21 = r22;
    u32 _owner_22 = r23;
    Term _owner_23 = r24;
    Term _owner_24 = r25;
    Term _owner_25 = r26;
    Term _owner_26 = r27;
    WL_OPEN
    if (_fail_0 == 0) {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      Term _v_9 = 0;
      u32 _v_10 = 0;
      Term _v_11 = 0;
      u32 _v_12 = 0;
      Term _v_13 = 0;
      Term _v_14 = 0;
      Term _v_15 = 0;
      u32 _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (_owner_12 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _owner_13);
        e.mem[_nd_0 + 1] = rfc_seal(e, _owner_14);
        u64 _nd_1 = heap_alloc(e, cls_fit(5));
        e.mem[_nd_1 + 0] = rfc_seal(e, _owner_15);
        e.mem[_nd_1 + 1] = rfc_seal(e, _owner_16);
        e.mem[_nd_1 + 2] = rfc_seal(e, _owner_17);
        e.mem[_nd_1 + 3] = rfc_seal(e, _owner_18);
        e.mem[_nd_1 + 4] = rfc_seal(e, _owner_19);
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_0));
        e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
        _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
      }
      Term _b_0 = 0;
      if (_owner_20 == 0) {
        _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
      } else {
        _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
      }
      u64 _nd_3 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_3 + 0] = rfc_seal(e, _owner_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, _owner_1);
      e.mem[_nd_3 + 2] = rfc_seal(e, _owner_2);
      e.mem[_nd_3 + 3] = rfc_seal(e, _owner_3);
      e.mem[_nd_3 + 4] = rfc_seal(e, _owner_4);
      e.mem[_nd_3 + 5] = rfc_seal(e, _owner_5);
      e.mem[_nd_3 + 6] = rfc_seal(e, _owner_6);
      e.mem[_nd_3 + 7] = rfc_seal(e, _owner_7);
      e.mem[_nd_3 + 8] = rfc_seal(e, _owner_8);
      e.mem[_nd_3 + 9] = rfc_seal(e, _owner_9);
      e.mem[_nd_3 + 10] = rfc_seal(e, _owner_10);
      e.mem[_nd_3 + 11] = rfc_seal(e, _owner_11);
      e.mem[_nd_3 + 12] = rfc_seal(e, _o_0);
      e.mem[_nd_3 + 13] = rfc_seal(e, _o_1);
      e.mem[_nd_3 + 14] = rfc_seal(e, _b_0);
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _owner_21);
      e.mem[_nd_4 + 1] = rfc_seal(e, _owner_22);
      u32 _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _o_5[5];
      Term _a_1 = term_ctr(CID_STORAGE_WORLD, _nd_3);
      Term _a_2 = term_ctr(CID_STORAGE_HANDLE, _nd_4);
      if (spin_160(e, _o_5, _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2), _owner_23, blk_loc(e.mem, _owner_23), _owner_24, blk_loc(e.mem, _owner_24), _owner_25, blk_loc(e.mem, _owner_25), _owner_26, blk_loc(e.mem, _owner_26)) == 0) {
        return 0;
      }
      _v_21 = _o_5[0];
      _v_22 = _o_5[1];
      _v_23 = _o_5[2];
      _v_24 = _o_5[3];
      _v_25 = _o_5[4];
      _v_16 = _v_21;
      _v_17 = _v_22;
      _v_18 = _v_23;
      _v_19 = _v_24;
      _v_20 = _v_25;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      Term _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      Term _o_12 = 0;
      Term _o_13 = 0;
      Term _o_14 = 0;
      u32 _o_15 = 0;
      Term _o_16 = 0;
      u32 _o_17 = 0;
      Term _o_18 = 0;
      u32 _o_19 = 0;
      Term _o_20 = 0;
      Term _o_21 = 0;
      Term _o_22 = 0;
      Term _o_23 = 0;
      Term _o_24 = 0;
      if (_v_16 == 0) {
        _o_6 = 0;
        Term _fb_1[15];
        u64 _sp_1 = ctr_take(e, _v_17, 15, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        Term _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        Term _f_7 = _fb_1[5];
        Term _f_8 = _fb_1[6];
        Term _f_9 = _fb_1[7];
        u32 _f_10 = _fb_1[8];
        Term _f_11 = _fb_1[9];
        u32 _f_12 = _fb_1[10];
        Term _f_13 = _fb_1[11];
        u32 _f_14 = _fb_1[12];
        Term _f_15 = _fb_1[13];
        Term _f_16 = _fb_1[14];
        spare_free(e, cls_fit(15), _sp_1);
        _o_7 = _f_2;
        _o_8 = _f_3;
        _o_9 = _f_4;
        _o_10 = _f_5;
        _o_11 = _f_6;
        _o_12 = _f_7;
        _o_13 = _f_8;
        _o_14 = _f_9;
        _o_15 = _f_10;
        _o_16 = _f_11;
        _o_17 = _f_12;
        _o_18 = _f_13;
        _o_19 = _f_14;
        _o_20 = _f_15;
        _o_21 = _f_16;
        _o_22 = _v_18;
        _o_23 = _v_19;
        _o_24 = _v_20;
      } else {
        _o_6 = 1;
        Term _fb_2[15];
        u64 _sp_2 = ctr_take(e, _v_17, 15, _fb_2);
        u32 _f_17 = _fb_2[0];
        u32 _f_18 = _fb_2[1];
        Term _f_19 = _fb_2[2];
        Term _f_20 = _fb_2[3];
        Term _f_21 = _fb_2[4];
        Term _f_22 = _fb_2[5];
        Term _f_23 = _fb_2[6];
        Term _f_24 = _fb_2[7];
        u32 _f_25 = _fb_2[8];
        Term _f_26 = _fb_2[9];
        u32 _f_27 = _fb_2[10];
        Term _f_28 = _fb_2[11];
        u32 _f_29 = _fb_2[12];
        Term _f_30 = _fb_2[13];
        Term _f_31 = _fb_2[14];
        spare_free(e, cls_fit(15), _sp_2);
        _o_7 = _f_17;
        _o_8 = _f_18;
        _o_9 = _f_19;
        _o_10 = _f_20;
        _o_11 = _f_21;
        _o_12 = _f_22;
        _o_13 = _f_23;
        _o_14 = _f_24;
        _o_15 = _f_25;
        _o_16 = _f_26;
        _o_17 = _f_27;
        _o_18 = _f_28;
        _o_19 = _f_29;
        _o_20 = _f_30;
        _o_21 = _f_31;
      }
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      u32 _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _o_37[16];
      if (spin_163(e, _o_37, _o_6, _o_7, _o_8, _o_9, blk_loc(e.mem, _o_9), _o_10, blk_loc(e.mem, _o_10), _o_11, blk_loc(e.mem, _o_11), _o_12, blk_loc(e.mem, _o_12), _o_13, blk_loc(e.mem, _o_13), _o_14, blk_loc(e.mem, _o_14), _o_15, _o_16, _o_17, _o_18, blk_loc(e.mem, _o_18), _o_19, _o_20, blk_loc(e.mem, _o_20), _o_21, blk_loc(e.mem, _o_21), _o_22, blk_loc(e.mem, _o_22), _o_23, blk_loc(e.mem, _o_23), _o_24, blk_loc(e.mem, _o_24), 9ull) == 0) {
        return 0;
      }
      _v_38 = _o_37[0];
      _v_39 = _o_37[1];
      _v_40 = _o_37[2];
      _v_41 = _o_37[3];
      _v_42 = _o_37[4];
      _v_43 = _o_37[5];
      _v_44 = _o_37[6];
      _v_45 = _o_37[7];
      _v_46 = _o_37[8];
      _v_47 = _o_37[9];
      _v_48 = _o_37[10];
      _v_49 = _o_37[11];
      _v_50 = _o_37[12];
      _v_51 = _o_37[13];
      _v_52 = _o_37[14];
      _v_53 = _o_37[15];
      _v_0 = _v_38;
      _v_1 = _v_39;
      _v_2 = _v_40;
      _v_3 = _v_41;
      _v_4 = _v_42;
      _v_5 = _v_43;
      _v_6 = _v_44;
      _v_7 = _v_45;
      _v_8 = _v_46;
      _v_9 = _v_47;
      _v_10 = _v_48;
      _v_11 = _v_49;
      _v_12 = _v_50;
      _v_13 = _v_51;
      _v_14 = _v_52;
      _v_15 = _v_53;
      u32 _o_38 = 0;
      Term _o_39 = 0;
      u32 _o_40 = 0;
      u32 _o_41 = 0;
      u32 _o_42 = 0;
      u32 _o_43 = 0;
      u32 _o_44 = 0;
      u32 _o_45 = 0;
      if (_v_12 == 0) {
        _o_38 = 0;
      } else {
        _o_38 = 1;
        Term _fb_7[2];
        u64 _sp_7 = ctr_take(e, _v_13, 2, _fb_7);
        Term _f_40 = _fb_7[0];
        Term _f_41 = _fb_7[1];
        spare_free(e, cls_fit(2), _sp_7);
        Term _fb_8[2];
        u64 _sp_8 = ctr_take(e, _f_40, 2, _fb_8);
        Term _f_42 = _fb_8[0];
        u32 _f_43 = _fb_8[1];
        spare_free(e, cls_fit(2), _sp_8);
        Term _fb_9[5];
        u64 _sp_9 = ctr_take(e, _f_41, 5, _fb_9);
        u32 _f_44 = _fb_9[0];
        u32 _f_45 = _fb_9[1];
        u32 _f_46 = _fb_9[2];
        u32 _f_47 = _fb_9[3];
        u32 _f_48 = _fb_9[4];
        spare_free(e, cls_fit(5), _sp_9);
        _o_39 = _f_42;
        _o_40 = _f_43;
        _o_41 = _f_44;
        _o_42 = _f_45;
        _o_43 = _f_46;
        _o_44 = _f_47;
        _o_45 = _f_48;
      }
      u32 _o_46 = 0;
      if (term_aux(_v_14) == CID_TYPES_HEALTHON) {
        _o_46 = 0;
      } else {
        _o_46 = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HEALTH_POST)) {
        u64 _t_6 = task_node(e, FID_HEALTH_POST, WL_CONT, WL_IDX, 0);
        e.mem[_t_6 + 0] = _v_0;
        e.mem[_t_6 + 1] = _v_1;
        e.mem[_t_6 + 2] = _v_2;
        e.mem[_t_6 + 3] = _v_3;
        e.mem[_t_6 + 4] = _v_4;
        e.mem[_t_6 + 5] = _v_5;
        e.mem[_t_6 + 6] = _v_6;
        e.mem[_t_6 + 7] = _v_7;
        e.mem[_t_6 + 8] = _v_8;
        e.mem[_t_6 + 9] = _v_9;
        e.mem[_t_6 + 10] = _v_10;
        e.mem[_t_6 + 11] = _v_11;
        e.mem[_t_6 + 12] = _o_38;
        e.mem[_t_6 + 13] = _o_39;
        e.mem[_t_6 + 14] = _o_40;
        e.mem[_t_6 + 15] = _o_41;
        e.mem[_t_6 + 16] = _o_42;
        e.mem[_t_6 + 17] = _o_43;
        e.mem[_t_6 + 18] = _o_44;
        e.mem[_t_6 + 19] = _o_45;
        e.mem[_t_6 + 20] = _o_46;
        e.mem[_t_6 + 21] = _v_15;
        return term_tsk(FID_HEALTH_POST, _t_6);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _o_38;
      r13 = _o_39;
      r14 = _o_40;
      r15 = _o_41;
      r16 = _o_42;
      r17 = _o_43;
      r18 = _o_44;
      r19 = _o_45;
      r20 = _o_46;
      r21 = _v_15;
      WL_JMP(FID_HEALTH_POST);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_HEALTH_FINISH_K476;
        WL_PUSHN(1);
      } else {
        u64 _t_7 = task_node(e, FID_HEALTH_FINISH_K476, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_HEALTH_FINISH_K476, _t_7);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE)) {
        u64 _t_8 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE, WL_CONT, WL_IDX, 0);
        e.mem[_t_8 + 0] = _owner_0;
        e.mem[_t_8 + 1] = _owner_1;
        e.mem[_t_8 + 2] = _owner_2;
        e.mem[_t_8 + 3] = _owner_3;
        e.mem[_t_8 + 4] = _owner_4;
        e.mem[_t_8 + 5] = _owner_5;
        e.mem[_t_8 + 6] = _owner_6;
        e.mem[_t_8 + 7] = _owner_7;
        e.mem[_t_8 + 8] = _owner_8;
        e.mem[_t_8 + 9] = _owner_9;
        e.mem[_t_8 + 10] = _owner_10;
        e.mem[_t_8 + 11] = _owner_11;
        e.mem[_t_8 + 12] = _owner_12;
        e.mem[_t_8 + 13] = _owner_13;
        e.mem[_t_8 + 14] = _owner_14;
        e.mem[_t_8 + 15] = _owner_15;
        e.mem[_t_8 + 16] = _owner_16;
        e.mem[_t_8 + 17] = _owner_17;
        e.mem[_t_8 + 18] = _owner_18;
        e.mem[_t_8 + 19] = _owner_19;
        e.mem[_t_8 + 20] = _owner_20;
        e.mem[_t_8 + 21] = _owner_21;
        e.mem[_t_8 + 22] = _owner_22;
        e.mem[_t_8 + 23] = _owner_23;
        e.mem[_t_8 + 24] = _owner_24;
        e.mem[_t_8 + 25] = _owner_25;
        e.mem[_t_8 + 26] = _owner_26;
        return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE, _t_8);
      }
      r0 = _owner_0;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = _owner_3;
      r4 = _owner_4;
      r5 = _owner_5;
      r6 = _owner_6;
      r7 = _owner_7;
      r8 = _owner_8;
      r9 = _owner_9;
      r10 = _owner_10;
      r11 = _owner_11;
      r12 = _owner_12;
      r13 = _owner_13;
      r14 = _owner_14;
      r15 = _owner_15;
      r16 = _owner_16;
      r17 = _owner_17;
      r18 = _owner_18;
      r19 = _owner_19;
      r20 = _owner_20;
      r21 = _owner_21;
      r22 = _owner_22;
      r23 = _owner_23;
      r24 = _owner_24;
      r25 = _owner_25;
      r26 = _owner_26;
      WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_FINISH_FAILURE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_FINISH_K476)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    Term _h_22 = r22;
    Term _h_23 = r23;
    Term _h_24 = r24;
    WL_OPEN
    u32 _v_212 = 0;
    u32 _v_213 = 0;
    Term _v_214 = 0;
    Term _v_215 = 0;
    Term _v_216 = 0;
    Term _v_217 = 0;
    Term _v_218 = 0;
    Term _v_219 = 0;
    u32 _v_220 = 0;
    Term _v_221 = 0;
    u32 _v_222 = 0;
    Term _v_223 = 0;
    u32 _v_224 = 0;
    Term _v_225 = 0;
    Term _v_226 = 0;
    Term _v_227 = 0;
    u32 _o_47 = 0;
    u32 _o_48 = 0;
    u32 _o_49 = 0;
    Term _o_50 = 0;
    Term _o_51 = 0;
    Term _o_52 = 0;
    Term _o_53 = 0;
    Term _o_54 = 0;
    Term _o_55 = 0;
    u32 _o_56 = 0;
    Term _o_57 = 0;
    u32 _o_58 = 0;
    Term _o_59 = 0;
    u32 _o_60 = 0;
    Term _o_61 = 0;
    Term _o_62 = 0;
    Term _o_63 = 0;
    Term _o_64 = 0;
    Term _o_65 = 0;
    if (_h_0 == 0) {
      _o_47 = 0;
      u32 _o_66 = 0;
      Term _o_67 = 0;
      if (_h_13 == 0) {
        _o_66 = 0;
      } else {
        _o_66 = 1;
        u64 _nd_8 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_8 + 0] = rfc_seal(e, _h_14);
        e.mem[_nd_8 + 1] = rfc_seal(e, _h_15);
        u64 _nd_9 = heap_alloc(e, cls_fit(5));
        e.mem[_nd_9 + 0] = rfc_seal(e, _h_16);
        e.mem[_nd_9 + 1] = rfc_seal(e, _h_17);
        e.mem[_nd_9 + 2] = rfc_seal(e, _h_18);
        e.mem[_nd_9 + 3] = rfc_seal(e, _h_19);
        e.mem[_nd_9 + 4] = rfc_seal(e, _h_20);
        u64 _nd_10 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_8));
        e.mem[_nd_10 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_9));
        _o_67 = term_ctr(CID_CACHE_CACHE, _nd_10);
      }
      Term _b_1 = 0;
      if (_h_21 == 0) {
        _b_1 = term_pak(CID_TYPES_HEALTHON, 0);
      } else {
        _b_1 = term_pak(CID_TYPES_HEALTHOFF, 0);
      }
      _o_48 = _h_1;
      _o_49 = _h_2;
      _o_50 = _h_3;
      _o_51 = _h_4;
      _o_52 = _h_5;
      _o_53 = _h_6;
      _o_54 = _h_7;
      _o_55 = _h_8;
      _o_56 = _h_9;
      _o_57 = _h_10;
      _o_58 = _h_11;
      _o_59 = _h_12;
      _o_60 = _o_66;
      _o_61 = _o_67;
      _o_62 = _b_1;
      _o_63 = _h_22;
      _o_64 = _h_23;
      _o_65 = _h_24;
    } else {
      _o_47 = 1;
      u32 _o_68 = 0;
      Term _o_69 = 0;
      if (_h_13 == 0) {
        _o_68 = 0;
      } else {
        _o_68 = 1;
        u64 _nd_11 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_11 + 0] = rfc_seal(e, _h_14);
        e.mem[_nd_11 + 1] = rfc_seal(e, _h_15);
        u64 _nd_12 = heap_alloc(e, cls_fit(5));
        e.mem[_nd_12 + 0] = rfc_seal(e, _h_16);
        e.mem[_nd_12 + 1] = rfc_seal(e, _h_17);
        e.mem[_nd_12 + 2] = rfc_seal(e, _h_18);
        e.mem[_nd_12 + 3] = rfc_seal(e, _h_19);
        e.mem[_nd_12 + 4] = rfc_seal(e, _h_20);
        u64 _nd_13 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_11));
        e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_12));
        _o_69 = term_ctr(CID_CACHE_CACHE, _nd_13);
      }
      Term _b_2 = 0;
      if (_h_21 == 0) {
        _b_2 = term_pak(CID_TYPES_HEALTHON, 0);
      } else {
        _b_2 = term_pak(CID_TYPES_HEALTHOFF, 0);
      }
      _o_48 = _h_1;
      _o_49 = _h_2;
      _o_50 = _h_3;
      _o_51 = _h_4;
      _o_52 = _h_5;
      _o_53 = _h_6;
      _o_54 = _h_7;
      _o_55 = _h_8;
      _o_56 = _h_9;
      _o_57 = _h_10;
      _o_58 = _h_11;
      _o_59 = _h_12;
      _o_60 = _o_68;
      _o_61 = _o_69;
      _o_62 = _b_2;
    }
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    Term _v_230 = 0;
    Term _v_231 = 0;
    Term _v_232 = 0;
    Term _v_233 = 0;
    Term _v_234 = 0;
    Term _v_235 = 0;
    u32 _v_236 = 0;
    Term _v_237 = 0;
    u32 _v_238 = 0;
    Term _v_239 = 0;
    u32 _v_240 = 0;
    Term _v_241 = 0;
    Term _v_242 = 0;
    Term _v_243 = 0;
    Term _o_70[16];
    if (spin_163(e, _o_70, _o_47, _o_48, _o_49, _o_50, blk_loc(e.mem, _o_50), _o_51, blk_loc(e.mem, _o_51), _o_52, blk_loc(e.mem, _o_52), _o_53, blk_loc(e.mem, _o_53), _o_54, blk_loc(e.mem, _o_54), _o_55, blk_loc(e.mem, _o_55), _o_56, _o_57, _o_58, _o_59, blk_loc(e.mem, _o_59), _o_60, _o_61, blk_loc(e.mem, _o_61), _o_62, blk_loc(e.mem, _o_62), _o_63, blk_loc(e.mem, _o_63), _o_64, blk_loc(e.mem, _o_64), _o_65, blk_loc(e.mem, _o_65), 9ull) == 0) {
      return 0;
    }
    _v_228 = _o_70[0];
    _v_229 = _o_70[1];
    _v_230 = _o_70[2];
    _v_231 = _o_70[3];
    _v_232 = _o_70[4];
    _v_233 = _o_70[5];
    _v_234 = _o_70[6];
    _v_235 = _o_70[7];
    _v_236 = _o_70[8];
    _v_237 = _o_70[9];
    _v_238 = _o_70[10];
    _v_239 = _o_70[11];
    _v_240 = _o_70[12];
    _v_241 = _o_70[13];
    _v_242 = _o_70[14];
    _v_243 = _o_70[15];
    _v_212 = _v_228;
    _v_213 = _v_229;
    _v_214 = _v_230;
    _v_215 = _v_231;
    _v_216 = _v_232;
    _v_217 = _v_233;
    _v_218 = _v_234;
    _v_219 = _v_235;
    _v_220 = _v_236;
    _v_221 = _v_237;
    _v_222 = _v_238;
    _v_223 = _v_239;
    _v_224 = _v_240;
    _v_225 = _v_241;
    _v_226 = _v_242;
    _v_227 = _v_243;
    u32 _o_71 = 0;
    Term _o_72 = 0;
    u32 _o_73 = 0;
    u32 _o_74 = 0;
    u32 _o_75 = 0;
    u32 _o_76 = 0;
    u32 _o_77 = 0;
    u32 _o_78 = 0;
    if (_v_224 == 0) {
      _o_71 = 0;
    } else {
      _o_71 = 1;
      Term _fb_10[2];
      u64 _sp_10 = ctr_take(e, _v_225, 2, _fb_10);
      Term _f_49 = _fb_10[0];
      Term _f_50 = _fb_10[1];
      spare_free(e, cls_fit(2), _sp_10);
      Term _fb_11[2];
      u64 _sp_11 = ctr_take(e, _f_49, 2, _fb_11);
      Term _f_51 = _fb_11[0];
      u32 _f_52 = _fb_11[1];
      spare_free(e, cls_fit(2), _sp_11);
      Term _fb_12[5];
      u64 _sp_12 = ctr_take(e, _f_50, 5, _fb_12);
      u32 _f_53 = _fb_12[0];
      u32 _f_54 = _fb_12[1];
      u32 _f_55 = _fb_12[2];
      u32 _f_56 = _fb_12[3];
      u32 _f_57 = _fb_12[4];
      spare_free(e, cls_fit(5), _sp_12);
      _o_72 = _f_51;
      _o_73 = _f_52;
      _o_74 = _f_53;
      _o_75 = _f_54;
      _o_76 = _f_55;
      _o_77 = _f_56;
      _o_78 = _f_57;
    }
    u32 _o_79 = 0;
    if (term_aux(_v_226) == CID_TYPES_HEALTHON) {
      _o_79 = 0;
    } else {
      _o_79 = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_POST)) {
      u64 _t_9 = task_node(e, FID_HEALTH_POST, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _v_212;
      e.mem[_t_9 + 1] = _v_213;
      e.mem[_t_9 + 2] = _v_214;
      e.mem[_t_9 + 3] = _v_215;
      e.mem[_t_9 + 4] = _v_216;
      e.mem[_t_9 + 5] = _v_217;
      e.mem[_t_9 + 6] = _v_218;
      e.mem[_t_9 + 7] = _v_219;
      e.mem[_t_9 + 8] = _v_220;
      e.mem[_t_9 + 9] = _v_221;
      e.mem[_t_9 + 10] = _v_222;
      e.mem[_t_9 + 11] = _v_223;
      e.mem[_t_9 + 12] = _o_71;
      e.mem[_t_9 + 13] = _o_72;
      e.mem[_t_9 + 14] = _o_73;
      e.mem[_t_9 + 15] = _o_74;
      e.mem[_t_9 + 16] = _o_75;
      e.mem[_t_9 + 17] = _o_76;
      e.mem[_t_9 + 18] = _o_77;
      e.mem[_t_9 + 19] = _o_78;
      e.mem[_t_9 + 20] = _o_79;
      e.mem[_t_9 + 21] = _v_227;
      return term_tsk(FID_HEALTH_POST, _t_9);
    }
    r0 = _v_212;
    r1 = _v_213;
    r2 = _v_214;
    r3 = _v_215;
    r4 = _v_216;
    r5 = _v_217;
    r6 = _v_218;
    r7 = _v_219;
    r8 = _v_220;
    r9 = _v_221;
    r10 = _v_222;
    r11 = _v_223;
    r12 = _o_71;
    r13 = _o_72;
    r14 = _o_73;
    r15 = _o_74;
    r16 = _o_75;
    r17 = _o_76;
    r18 = _o_77;
    r19 = _o_78;
    r20 = _o_79;
    r21 = _v_227;
    WL_JMP(FID_HEALTH_POST);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_BODY)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    Term _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    u32 _owner_8 = r8;
    Term _owner_9 = r9;
    u32 _owner_10 = r10;
    Term _owner_11 = r11;
    u32 _owner_12 = r12;
    Term _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    u32 _owner_17 = r17;
    u32 _owner_18 = r18;
    u32 _owner_19 = r19;
    u32 _owner_20 = r20;
    u32 _owner_21 = r21;
    u32 _owner_22 = r22;
    Term _owner_23 = r23;
    Term _owner_24 = r24;
    Term _owner_25 = r25;
    Term _owner_26 = r26;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_GATE_CALLBACKS_HEALTH_BODY_0)) {
      u64 _t_0 = task_node(e, FID_GATE_CALLBACKS_HEALTH_BODY_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _owner_0;
      e.mem[_t_0 + 1] = _owner_1;
      e.mem[_t_0 + 2] = _owner_2;
      e.mem[_t_0 + 3] = _owner_3;
      e.mem[_t_0 + 4] = _owner_4;
      e.mem[_t_0 + 5] = _owner_5;
      e.mem[_t_0 + 6] = _owner_6;
      e.mem[_t_0 + 7] = _owner_7;
      e.mem[_t_0 + 8] = _owner_8;
      e.mem[_t_0 + 9] = _owner_9;
      e.mem[_t_0 + 10] = _owner_10;
      e.mem[_t_0 + 11] = _owner_11;
      e.mem[_t_0 + 12] = _owner_12;
      e.mem[_t_0 + 13] = _owner_13;
      e.mem[_t_0 + 14] = _owner_14;
      e.mem[_t_0 + 15] = _owner_15;
      e.mem[_t_0 + 16] = _owner_16;
      e.mem[_t_0 + 17] = _owner_17;
      e.mem[_t_0 + 18] = _owner_18;
      e.mem[_t_0 + 19] = _owner_19;
      e.mem[_t_0 + 20] = _owner_20;
      e.mem[_t_0 + 21] = _owner_21;
      e.mem[_t_0 + 22] = _owner_22;
      e.mem[_t_0 + 23] = _owner_23;
      e.mem[_t_0 + 24] = _owner_24;
      e.mem[_t_0 + 25] = _owner_25;
      e.mem[_t_0 + 26] = _owner_26;
      return term_tsk(FID_GATE_CALLBACKS_HEALTH_BODY_0, _t_0);
    }
    r0 = _owner_0;
    r1 = _owner_1;
    r2 = _owner_2;
    r3 = _owner_3;
    r4 = _owner_4;
    r5 = _owner_5;
    r6 = _owner_6;
    r7 = _owner_7;
    r8 = _owner_8;
    r9 = _owner_9;
    r10 = _owner_10;
    r11 = _owner_11;
    r12 = _owner_12;
    r13 = _owner_13;
    r14 = _owner_14;
    r15 = _owner_15;
    r16 = _owner_16;
    r17 = _owner_17;
    r18 = _owner_18;
    r19 = _owner_19;
    r20 = _owner_20;
    r21 = _owner_21;
    r22 = _owner_22;
    r23 = _owner_23;
    r24 = _owner_24;
    r25 = _owner_25;
    r26 = _owner_26;
    WL_JMP(FID_GATE_CALLBACKS_HEALTH_BODY_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    Term _result_2 = r2;
    Term _result_3 = r3;
    Term _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    u32 _result_8 = r8;
    Term _result_9 = r9;
    u32 _result_10 = r10;
    Term _result_11 = r11;
    u32 _result_12 = r12;
    Term _result_13 = r13;
    u32 _result_14 = r14;
    u32 _result_15 = r15;
    u32 _result_16 = r16;
    u32 _result_17 = r17;
    u32 _result_18 = r18;
    u32 _result_19 = r19;
    u32 _result_20 = r20;
    u32 _result_21 = r21;
    u32 _result_22 = r22;
    Term _result_23 = r23;
    Term _result_24 = r24;
    Term _result_25 = r25;
    Term _result_26 = r26;
    u32 _result_27 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _result_0;
      STK(1) = _result_1;
      STK(2) = _result_2;
      STK(3) = _result_3;
      STK(4) = _result_4;
      STK(5) = _result_5;
      STK(6) = _result_6;
      STK(7) = _result_7;
      STK(8) = _result_8;
      STK(9) = _result_9;
      STK(10) = _result_10;
      STK(11) = _result_11;
      STK(12) = _result_12;
      STK(13) = _result_13;
      STK(14) = _result_14;
      STK(15) = _result_15;
      STK(16) = _result_16;
      STK(17) = _result_17;
      STK(18) = _result_18;
      STK(19) = _result_19;
      STK(20) = _result_20;
      STK(21) = _result_21;
      STK(22) = _result_22;
      STK(23) = _result_23;
      STK(24) = _result_25;
      STK(25) = _result_26;
      STK(26) = _result_27;
      STK(27) = FID_HEALTH_PRE_K480;
      WL_PUSHN(28);
    } else {
      u64 _t_0 = task_node(e, FID_HEALTH_PRE_K480, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _result_0;
      e.mem[_t_0 + 1] = _result_1;
      e.mem[_t_0 + 2] = _result_2;
      e.mem[_t_0 + 3] = _result_3;
      e.mem[_t_0 + 4] = _result_4;
      e.mem[_t_0 + 5] = _result_5;
      e.mem[_t_0 + 6] = _result_6;
      e.mem[_t_0 + 7] = _result_7;
      e.mem[_t_0 + 8] = _result_8;
      e.mem[_t_0 + 9] = _result_9;
      e.mem[_t_0 + 10] = _result_10;
      e.mem[_t_0 + 11] = _result_11;
      e.mem[_t_0 + 12] = _result_12;
      e.mem[_t_0 + 13] = _result_13;
      e.mem[_t_0 + 14] = _result_14;
      e.mem[_t_0 + 15] = _result_15;
      e.mem[_t_0 + 16] = _result_16;
      e.mem[_t_0 + 17] = _result_17;
      e.mem[_t_0 + 18] = _result_18;
      e.mem[_t_0 + 19] = _result_19;
      e.mem[_t_0 + 20] = _result_20;
      e.mem[_t_0 + 21] = _result_21;
      e.mem[_t_0 + 22] = _result_22;
      e.mem[_t_0 + 23] = _result_23;
      e.mem[_t_0 + 24] = _result_25;
      e.mem[_t_0 + 25] = _result_26;
      e.mem[_t_0 + 26] = _result_27;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K480, _t_0);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_COMMANDS_0)) {
      u64 _t_1 = task_node(e, FID_OBSERVATIONS_COMMANDS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _result_24;
      return term_tsk(FID_OBSERVATIONS_COMMANDS_0, _t_1);
    }
    r0 = _result_24;
    WL_JMP(FID_OBSERVATIONS_COMMANDS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K480)
  {
    WL_POPN(27);
    u32 _result_28 = STK(0);
    u32 _result_29 = STK(1);
    Term _result_30 = STK(2);
    Term _result_31 = STK(3);
    Term _result_32 = STK(4);
    Term _result_33 = STK(5);
    Term _result_34 = STK(6);
    Term _result_35 = STK(7);
    u32 _result_36 = STK(8);
    Term _result_37 = STK(9);
    u32 _result_38 = STK(10);
    Term _result_39 = STK(11);
    u32 _result_40 = STK(12);
    Term _result_41 = STK(13);
    u32 _result_42 = STK(14);
    u32 _result_43 = STK(15);
    u32 _result_44 = STK(16);
    u32 _result_45 = STK(17);
    u32 _result_46 = STK(18);
    u32 _result_47 = STK(19);
    u32 _result_48 = STK(20);
    u32 _result_49 = STK(21);
    u32 _result_50 = STK(22);
    Term _result_51 = STK(23);
    Term _result_52 = STK(24);
    Term _result_53 = STK(25);
    u32 _result_54 = STK(26);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _result_49;
      STK(3) = _result_50;
      STK(4) = _result_51;
      STK(5) = _result_52;
      STK(6) = _result_53;
      STK(7) = _result_54;
      STK(8) = FID_HEALTH_PRE_K481;
      WL_PUSHN(9);
    } else {
      u64 _t_2 = task_node(e, FID_HEALTH_PRE_K481, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _result_49;
      e.mem[_t_2 + 3] = _result_50;
      e.mem[_t_2 + 4] = _result_51;
      e.mem[_t_2 + 5] = _result_52;
      e.mem[_t_2 + 6] = _result_53;
      e.mem[_t_2 + 7] = _result_54;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K481, _t_2);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVATIONS_WORLD_0)) {
      u64 _t_3 = task_node(e, FID_OBSERVATIONS_WORLD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _result_28;
      e.mem[_t_3 + 1] = _result_29;
      e.mem[_t_3 + 2] = _result_30;
      e.mem[_t_3 + 3] = _result_31;
      e.mem[_t_3 + 4] = _result_32;
      e.mem[_t_3 + 5] = _result_33;
      e.mem[_t_3 + 6] = _result_34;
      e.mem[_t_3 + 7] = _result_35;
      e.mem[_t_3 + 8] = _result_36;
      e.mem[_t_3 + 9] = _result_37;
      e.mem[_t_3 + 10] = _result_38;
      e.mem[_t_3 + 11] = _result_39;
      e.mem[_t_3 + 12] = _result_40;
      e.mem[_t_3 + 13] = _result_41;
      e.mem[_t_3 + 14] = _result_42;
      e.mem[_t_3 + 15] = _result_43;
      e.mem[_t_3 + 16] = _result_44;
      e.mem[_t_3 + 17] = _result_45;
      e.mem[_t_3 + 18] = _result_46;
      e.mem[_t_3 + 19] = _result_47;
      e.mem[_t_3 + 20] = _result_48;
      return term_tsk(FID_OBSERVATIONS_WORLD_0, _t_3);
    }
    r0 = _result_28;
    r1 = _result_29;
    r2 = _result_30;
    r3 = _result_31;
    r4 = _result_32;
    r5 = _result_33;
    r6 = _result_34;
    r7 = _result_35;
    r8 = _result_36;
    r9 = _result_37;
    r10 = _result_38;
    r11 = _result_39;
    r12 = _result_40;
    r13 = _result_41;
    r14 = _result_42;
    r15 = _result_43;
    r16 = _result_44;
    r17 = _result_45;
    r18 = _result_46;
    r19 = _result_47;
    r20 = _result_48;
    WL_JMP(FID_OBSERVATIONS_WORLD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K481)
  {
    WL_POPN(8);
    Term _h_34 = STK(0);
    Term _h_35 = STK(1);
    u32 _result_55 = STK(2);
    u32 _result_56 = STK(3);
    Term _result_57 = STK(4);
    Term _result_58 = STK(5);
    Term _result_59 = STK(6);
    u32 _result_60 = STK(7);
    u32 _h_2 = r0;
    u32 _h_3 = r1;
    Term _h_4 = r2;
    Term _h_5 = r3;
    Term _h_6 = r4;
    Term _h_7 = r5;
    Term _h_8 = r6;
    Term _h_9 = r7;
    u32 _h_10 = r8;
    Term _h_11 = r9;
    u32 _h_12 = r10;
    Term _h_13 = r11;
    u32 _h_14 = r12;
    Term _h_15 = r13;
    u32 _h_16 = r14;
    u32 _h_17 = r15;
    u32 _h_18 = r16;
    u32 _h_19 = r17;
    u32 _h_20 = r18;
    u32 _h_21 = r19;
    u32 _h_22 = r20;
    u32 _h_23 = r21;
    u32 _h_24 = r22;
    Term _h_25 = r23;
    Term _h_26 = r24;
    u32 _h_27 = r25;
    u32 _h_28 = r26;
    u32 _h_29 = r27;
    u32 _h_30 = r28;
    u32 _h_31 = r29;
    u32 _h_32 = r30;
    u32 _h_33 = r31;
    WL_OPEN
    if (seq) {
      WL_ROOM(40);
      STK(0) = _h_2;
      STK(1) = _h_3;
      STK(2) = _h_4;
      STK(3) = _h_5;
      STK(4) = _h_6;
      STK(5) = _h_7;
      STK(6) = _h_8;
      STK(7) = _h_9;
      STK(8) = _h_10;
      STK(9) = _h_11;
      STK(10) = _h_12;
      STK(11) = _h_13;
      STK(12) = _h_14;
      STK(13) = _h_15;
      STK(14) = _h_16;
      STK(15) = _h_17;
      STK(16) = _h_18;
      STK(17) = _h_19;
      STK(18) = _h_20;
      STK(19) = _h_21;
      STK(20) = _h_22;
      STK(21) = _h_23;
      STK(22) = _h_24;
      STK(23) = _h_25;
      STK(24) = _h_26;
      STK(25) = _h_27;
      STK(26) = _h_28;
      STK(27) = _h_29;
      STK(28) = _h_30;
      STK(29) = _h_31;
      STK(30) = _h_32;
      STK(31) = _h_33;
      STK(32) = _result_55;
      STK(33) = _result_56;
      STK(34) = _result_57;
      STK(35) = _h_34;
      STK(36) = _result_58;
      STK(37) = _result_59;
      STK(38) = _h_35;
      STK(39) = FID_HEALTH_PRE_K482;
      WL_PUSHN(40);
    } else {
      u64 _t_4 = task_node(e, FID_HEALTH_PRE_K482, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_3;
      e.mem[_t_4 + 2] = _h_4;
      e.mem[_t_4 + 3] = _h_5;
      e.mem[_t_4 + 4] = _h_6;
      e.mem[_t_4 + 5] = _h_7;
      e.mem[_t_4 + 6] = _h_8;
      e.mem[_t_4 + 7] = _h_9;
      e.mem[_t_4 + 8] = _h_10;
      e.mem[_t_4 + 9] = _h_11;
      e.mem[_t_4 + 10] = _h_12;
      e.mem[_t_4 + 11] = _h_13;
      e.mem[_t_4 + 12] = _h_14;
      e.mem[_t_4 + 13] = _h_15;
      e.mem[_t_4 + 14] = _h_16;
      e.mem[_t_4 + 15] = _h_17;
      e.mem[_t_4 + 16] = _h_18;
      e.mem[_t_4 + 17] = _h_19;
      e.mem[_t_4 + 18] = _h_20;
      e.mem[_t_4 + 19] = _h_21;
      e.mem[_t_4 + 20] = _h_22;
      e.mem[_t_4 + 21] = _h_23;
      e.mem[_t_4 + 22] = _h_24;
      e.mem[_t_4 + 23] = _h_25;
      e.mem[_t_4 + 24] = _h_26;
      e.mem[_t_4 + 25] = _h_27;
      e.mem[_t_4 + 26] = _h_28;
      e.mem[_t_4 + 27] = _h_29;
      e.mem[_t_4 + 28] = _h_30;
      e.mem[_t_4 + 29] = _h_31;
      e.mem[_t_4 + 30] = _h_32;
      e.mem[_t_4 + 31] = _h_33;
      e.mem[_t_4 + 32] = _result_55;
      e.mem[_t_4 + 33] = _result_56;
      e.mem[_t_4 + 34] = _result_57;
      e.mem[_t_4 + 35] = _h_34;
      e.mem[_t_4 + 36] = _result_58;
      e.mem[_t_4 + 37] = _result_59;
      e.mem[_t_4 + 38] = _h_35;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K482, _t_4);
      WL_IDX = 39;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _result_60;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _result_60;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K482)
  {
    WL_POPN(39);
    u32 _h_37 = STK(0);
    u32 _h_38 = STK(1);
    Term _h_39 = STK(2);
    Term _h_40 = STK(3);
    Term _h_41 = STK(4);
    Term _h_42 = STK(5);
    Term _h_43 = STK(6);
    Term _h_44 = STK(7);
    u32 _h_45 = STK(8);
    Term _h_46 = STK(9);
    u32 _h_47 = STK(10);
    Term _h_48 = STK(11);
    u32 _h_49 = STK(12);
    Term _h_50 = STK(13);
    u32 _h_51 = STK(14);
    u32 _h_52 = STK(15);
    u32 _h_53 = STK(16);
    u32 _h_54 = STK(17);
    u32 _h_55 = STK(18);
    u32 _h_56 = STK(19);
    u32 _h_57 = STK(20);
    u32 _h_58 = STK(21);
    u32 _h_59 = STK(22);
    Term _h_60 = STK(23);
    Term _h_61 = STK(24);
    u32 _h_62 = STK(25);
    u32 _h_63 = STK(26);
    u32 _h_64 = STK(27);
    u32 _h_65 = STK(28);
    u32 _h_66 = STK(29);
    u32 _h_67 = STK(30);
    u32 _h_68 = STK(31);
    u32 _result_61 = STK(32);
    u32 _result_62 = STK(33);
    Term _result_63 = STK(34);
    Term _h_69 = STK(35);
    Term _result_64 = STK(36);
    Term _result_65 = STK(37);
    Term _h_70 = STK(38);
    Term _h_36 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(41);
      STK(0) = _h_37;
      STK(1) = _h_38;
      STK(2) = _h_39;
      STK(3) = _h_40;
      STK(4) = _h_41;
      STK(5) = _h_42;
      STK(6) = _h_43;
      STK(7) = _h_44;
      STK(8) = _h_45;
      STK(9) = _h_46;
      STK(10) = _h_47;
      STK(11) = _h_48;
      STK(12) = _h_49;
      STK(13) = _h_50;
      STK(14) = _h_51;
      STK(15) = _h_52;
      STK(16) = _h_53;
      STK(17) = _h_54;
      STK(18) = _h_55;
      STK(19) = _h_56;
      STK(20) = _h_57;
      STK(21) = _h_58;
      STK(22) = _h_59;
      STK(23) = _h_60;
      STK(24) = _h_61;
      STK(25) = _h_62;
      STK(26) = _h_63;
      STK(27) = _h_64;
      STK(28) = _h_65;
      STK(29) = _h_66;
      STK(30) = _h_67;
      STK(31) = _h_68;
      STK(32) = _result_61;
      STK(33) = _result_62;
      STK(34) = _result_63;
      STK(35) = _h_69;
      STK(36) = _result_64;
      STK(37) = _result_65;
      STK(38) = _h_70;
      STK(39) = _h_36;
      STK(40) = FID_HEALTH_PRE_K483;
      WL_PUSHN(41);
    } else {
      u64 _t_6 = task_node(e, FID_HEALTH_PRE_K483, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_37;
      e.mem[_t_6 + 1] = _h_38;
      e.mem[_t_6 + 2] = _h_39;
      e.mem[_t_6 + 3] = _h_40;
      e.mem[_t_6 + 4] = _h_41;
      e.mem[_t_6 + 5] = _h_42;
      e.mem[_t_6 + 6] = _h_43;
      e.mem[_t_6 + 7] = _h_44;
      e.mem[_t_6 + 8] = _h_45;
      e.mem[_t_6 + 9] = _h_46;
      e.mem[_t_6 + 10] = _h_47;
      e.mem[_t_6 + 11] = _h_48;
      e.mem[_t_6 + 12] = _h_49;
      e.mem[_t_6 + 13] = _h_50;
      e.mem[_t_6 + 14] = _h_51;
      e.mem[_t_6 + 15] = _h_52;
      e.mem[_t_6 + 16] = _h_53;
      e.mem[_t_6 + 17] = _h_54;
      e.mem[_t_6 + 18] = _h_55;
      e.mem[_t_6 + 19] = _h_56;
      e.mem[_t_6 + 20] = _h_57;
      e.mem[_t_6 + 21] = _h_58;
      e.mem[_t_6 + 22] = _h_59;
      e.mem[_t_6 + 23] = _h_60;
      e.mem[_t_6 + 24] = _h_61;
      e.mem[_t_6 + 25] = _h_62;
      e.mem[_t_6 + 26] = _h_63;
      e.mem[_t_6 + 27] = _h_64;
      e.mem[_t_6 + 28] = _h_65;
      e.mem[_t_6 + 29] = _h_66;
      e.mem[_t_6 + 30] = _h_67;
      e.mem[_t_6 + 31] = _h_68;
      e.mem[_t_6 + 32] = _result_61;
      e.mem[_t_6 + 33] = _result_62;
      e.mem[_t_6 + 34] = _result_63;
      e.mem[_t_6 + 35] = _h_69;
      e.mem[_t_6 + 36] = _result_64;
      e.mem[_t_6 + 37] = _result_65;
      e.mem[_t_6 + 38] = _h_70;
      e.mem[_t_6 + 39] = _h_36;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K483, _t_6);
      WL_IDX = 40;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_HANDLE)) {
      u64 _t_7 = task_node(e, FID_HOST_RENDER_RENDER_HANDLE, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _result_61;
      e.mem[_t_7 + 1] = _result_62;
      return term_tsk(FID_HOST_RENDER_RENDER_HANDLE, _t_7);
    }
    r0 = _result_61;
    r1 = _result_62;
    WL_JMP(FID_HOST_RENDER_RENDER_HANDLE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K483)
  {
    WL_POPN(40);
    u32 _h_72 = STK(0);
    u32 _h_73 = STK(1);
    Term _h_74 = STK(2);
    Term _h_75 = STK(3);
    Term _h_76 = STK(4);
    Term _h_77 = STK(5);
    Term _h_78 = STK(6);
    Term _h_79 = STK(7);
    u32 _h_80 = STK(8);
    Term _h_81 = STK(9);
    u32 _h_82 = STK(10);
    Term _h_83 = STK(11);
    u32 _h_84 = STK(12);
    Term _h_85 = STK(13);
    u32 _h_86 = STK(14);
    u32 _h_87 = STK(15);
    u32 _h_88 = STK(16);
    u32 _h_89 = STK(17);
    u32 _h_90 = STK(18);
    u32 _h_91 = STK(19);
    u32 _h_92 = STK(20);
    u32 _h_93 = STK(21);
    u32 _h_94 = STK(22);
    Term _h_95 = STK(23);
    Term _h_96 = STK(24);
    u32 _h_97 = STK(25);
    u32 _h_98 = STK(26);
    u32 _h_99 = STK(27);
    u32 _h_100 = STK(28);
    u32 _h_101 = STK(29);
    u32 _h_102 = STK(30);
    u32 _h_103 = STK(31);
    u32 _result_66 = STK(32);
    u32 _result_67 = STK(33);
    Term _result_68 = STK(34);
    Term _h_104 = STK(35);
    Term _result_69 = STK(36);
    Term _result_70 = STK(37);
    Term _h_105 = STK(38);
    Term _h_106 = STK(39);
    Term _h_71 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(42);
      STK(0) = _h_72;
      STK(1) = _h_73;
      STK(2) = _h_74;
      STK(3) = _h_75;
      STK(4) = _h_76;
      STK(5) = _h_77;
      STK(6) = _h_78;
      STK(7) = _h_79;
      STK(8) = _h_80;
      STK(9) = _h_81;
      STK(10) = _h_82;
      STK(11) = _h_83;
      STK(12) = _h_84;
      STK(13) = _h_85;
      STK(14) = _h_86;
      STK(15) = _h_87;
      STK(16) = _h_88;
      STK(17) = _h_89;
      STK(18) = _h_90;
      STK(19) = _h_91;
      STK(20) = _h_92;
      STK(21) = _h_93;
      STK(22) = _h_94;
      STK(23) = _h_95;
      STK(24) = _h_96;
      STK(25) = _h_97;
      STK(26) = _h_98;
      STK(27) = _h_99;
      STK(28) = _h_100;
      STK(29) = _h_101;
      STK(30) = _h_102;
      STK(31) = _h_103;
      STK(32) = _result_66;
      STK(33) = _result_67;
      STK(34) = _result_68;
      STK(35) = _h_104;
      STK(36) = _result_69;
      STK(37) = _result_70;
      STK(38) = _h_105;
      STK(39) = _h_106;
      STK(40) = _h_71;
      STK(41) = FID_HEALTH_PRE_K484;
      WL_PUSHN(42);
    } else {
      u64 _t_8 = task_node(e, FID_HEALTH_PRE_K484, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_72;
      e.mem[_t_8 + 1] = _h_73;
      e.mem[_t_8 + 2] = _h_74;
      e.mem[_t_8 + 3] = _h_75;
      e.mem[_t_8 + 4] = _h_76;
      e.mem[_t_8 + 5] = _h_77;
      e.mem[_t_8 + 6] = _h_78;
      e.mem[_t_8 + 7] = _h_79;
      e.mem[_t_8 + 8] = _h_80;
      e.mem[_t_8 + 9] = _h_81;
      e.mem[_t_8 + 10] = _h_82;
      e.mem[_t_8 + 11] = _h_83;
      e.mem[_t_8 + 12] = _h_84;
      e.mem[_t_8 + 13] = _h_85;
      e.mem[_t_8 + 14] = _h_86;
      e.mem[_t_8 + 15] = _h_87;
      e.mem[_t_8 + 16] = _h_88;
      e.mem[_t_8 + 17] = _h_89;
      e.mem[_t_8 + 18] = _h_90;
      e.mem[_t_8 + 19] = _h_91;
      e.mem[_t_8 + 20] = _h_92;
      e.mem[_t_8 + 21] = _h_93;
      e.mem[_t_8 + 22] = _h_94;
      e.mem[_t_8 + 23] = _h_95;
      e.mem[_t_8 + 24] = _h_96;
      e.mem[_t_8 + 25] = _h_97;
      e.mem[_t_8 + 26] = _h_98;
      e.mem[_t_8 + 27] = _h_99;
      e.mem[_t_8 + 28] = _h_100;
      e.mem[_t_8 + 29] = _h_101;
      e.mem[_t_8 + 30] = _h_102;
      e.mem[_t_8 + 31] = _h_103;
      e.mem[_t_8 + 32] = _result_66;
      e.mem[_t_8 + 33] = _result_67;
      e.mem[_t_8 + 34] = _result_68;
      e.mem[_t_8 + 35] = _h_104;
      e.mem[_t_8 + 36] = _result_69;
      e.mem[_t_8 + 37] = _result_70;
      e.mem[_t_8 + 38] = _h_105;
      e.mem[_t_8 + 39] = _h_106;
      e.mem[_t_8 + 40] = _h_71;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K484, _t_8);
      WL_IDX = 41;
    }
    if (!DEVICE && !seq && fid_nofk(FID_UNDO_TEXT_0)) {
      u64 _t_9 = task_node(e, FID_UNDO_TEXT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _result_68;
      return term_tsk(FID_UNDO_TEXT_0, _t_9);
    }
    r0 = _result_68;
    WL_JMP(FID_UNDO_TEXT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K484)
  {
    WL_POPN(41);
    u32 _h_108 = STK(0);
    u32 _h_109 = STK(1);
    Term _h_110 = STK(2);
    Term _h_111 = STK(3);
    Term _h_112 = STK(4);
    Term _h_113 = STK(5);
    Term _h_114 = STK(6);
    Term _h_115 = STK(7);
    u32 _h_116 = STK(8);
    Term _h_117 = STK(9);
    u32 _h_118 = STK(10);
    Term _h_119 = STK(11);
    u32 _h_120 = STK(12);
    Term _h_121 = STK(13);
    u32 _h_122 = STK(14);
    u32 _h_123 = STK(15);
    u32 _h_124 = STK(16);
    u32 _h_125 = STK(17);
    u32 _h_126 = STK(18);
    u32 _h_127 = STK(19);
    u32 _h_128 = STK(20);
    u32 _h_129 = STK(21);
    u32 _h_130 = STK(22);
    Term _h_131 = STK(23);
    Term _h_132 = STK(24);
    u32 _h_133 = STK(25);
    u32 _h_134 = STK(26);
    u32 _h_135 = STK(27);
    u32 _h_136 = STK(28);
    u32 _h_137 = STK(29);
    u32 _h_138 = STK(30);
    u32 _h_139 = STK(31);
    u32 _result_71 = STK(32);
    u32 _result_72 = STK(33);
    Term _result_73 = STK(34);
    Term _h_140 = STK(35);
    Term _result_74 = STK(36);
    Term _result_75 = STK(37);
    Term _h_141 = STK(38);
    Term _h_142 = STK(39);
    Term _h_143 = STK(40);
    Term _h_107 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(42);
      STK(0) = _h_108;
      STK(1) = _h_109;
      STK(2) = _h_110;
      STK(3) = _h_111;
      STK(4) = _h_112;
      STK(5) = _h_113;
      STK(6) = _h_114;
      STK(7) = _h_115;
      STK(8) = _h_116;
      STK(9) = _h_117;
      STK(10) = _h_118;
      STK(11) = _h_119;
      STK(12) = _h_120;
      STK(13) = _h_121;
      STK(14) = _h_122;
      STK(15) = _h_123;
      STK(16) = _h_124;
      STK(17) = _h_125;
      STK(18) = _h_126;
      STK(19) = _h_127;
      STK(20) = _h_128;
      STK(21) = _h_129;
      STK(22) = _h_130;
      STK(23) = _h_131;
      STK(24) = _h_132;
      STK(25) = _h_133;
      STK(26) = _h_134;
      STK(27) = _h_135;
      STK(28) = _h_136;
      STK(29) = _h_137;
      STK(30) = _h_138;
      STK(31) = _h_139;
      STK(32) = _result_71;
      STK(33) = _result_72;
      STK(34) = _result_73;
      STK(35) = _h_140;
      STK(36) = _result_74;
      STK(37) = _result_75;
      STK(38) = _h_142;
      STK(39) = _h_143;
      STK(40) = _h_107;
      STK(41) = FID_HEALTH_PRE_K485;
      WL_PUSHN(42);
    } else {
      u64 _t_10 = task_node(e, FID_HEALTH_PRE_K485, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_108;
      e.mem[_t_10 + 1] = _h_109;
      e.mem[_t_10 + 2] = _h_110;
      e.mem[_t_10 + 3] = _h_111;
      e.mem[_t_10 + 4] = _h_112;
      e.mem[_t_10 + 5] = _h_113;
      e.mem[_t_10 + 6] = _h_114;
      e.mem[_t_10 + 7] = _h_115;
      e.mem[_t_10 + 8] = _h_116;
      e.mem[_t_10 + 9] = _h_117;
      e.mem[_t_10 + 10] = _h_118;
      e.mem[_t_10 + 11] = _h_119;
      e.mem[_t_10 + 12] = _h_120;
      e.mem[_t_10 + 13] = _h_121;
      e.mem[_t_10 + 14] = _h_122;
      e.mem[_t_10 + 15] = _h_123;
      e.mem[_t_10 + 16] = _h_124;
      e.mem[_t_10 + 17] = _h_125;
      e.mem[_t_10 + 18] = _h_126;
      e.mem[_t_10 + 19] = _h_127;
      e.mem[_t_10 + 20] = _h_128;
      e.mem[_t_10 + 21] = _h_129;
      e.mem[_t_10 + 22] = _h_130;
      e.mem[_t_10 + 23] = _h_131;
      e.mem[_t_10 + 24] = _h_132;
      e.mem[_t_10 + 25] = _h_133;
      e.mem[_t_10 + 26] = _h_134;
      e.mem[_t_10 + 27] = _h_135;
      e.mem[_t_10 + 28] = _h_136;
      e.mem[_t_10 + 29] = _h_137;
      e.mem[_t_10 + 30] = _h_138;
      e.mem[_t_10 + 31] = _h_139;
      e.mem[_t_10 + 32] = _result_71;
      e.mem[_t_10 + 33] = _result_72;
      e.mem[_t_10 + 34] = _result_73;
      e.mem[_t_10 + 35] = _h_140;
      e.mem[_t_10 + 36] = _result_74;
      e.mem[_t_10 + 37] = _result_75;
      e.mem[_t_10 + 38] = _h_142;
      e.mem[_t_10 + 39] = _h_143;
      e.mem[_t_10 + 40] = _h_107;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K485, _t_10);
      WL_IDX = 41;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_14)) {
      u64 _t_11 = task_node(e, FID_HOST_RENDER_RENDER_LIST_14, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_141;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_14, _t_11);
    }
    r0 = _h_141;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K485)
  {
    WL_POPN(41);
    u32 _h_145 = STK(0);
    u32 _h_146 = STK(1);
    Term _h_147 = STK(2);
    Term _h_148 = STK(3);
    Term _h_149 = STK(4);
    Term _h_150 = STK(5);
    Term _h_151 = STK(6);
    Term _h_152 = STK(7);
    u32 _h_153 = STK(8);
    Term _h_154 = STK(9);
    u32 _h_155 = STK(10);
    Term _h_156 = STK(11);
    u32 _h_157 = STK(12);
    Term _h_158 = STK(13);
    u32 _h_159 = STK(14);
    u32 _h_160 = STK(15);
    u32 _h_161 = STK(16);
    u32 _h_162 = STK(17);
    u32 _h_163 = STK(18);
    u32 _h_164 = STK(19);
    u32 _h_165 = STK(20);
    u32 _h_166 = STK(21);
    u32 _h_167 = STK(22);
    Term _h_168 = STK(23);
    Term _h_169 = STK(24);
    u32 _h_170 = STK(25);
    u32 _h_171 = STK(26);
    u32 _h_172 = STK(27);
    u32 _h_173 = STK(28);
    u32 _h_174 = STK(29);
    u32 _h_175 = STK(30);
    u32 _h_176 = STK(31);
    u32 _result_76 = STK(32);
    u32 _result_77 = STK(33);
    Term _result_78 = STK(34);
    Term _h_177 = STK(35);
    Term _result_79 = STK(36);
    Term _result_80 = STK(37);
    Term _h_178 = STK(38);
    Term _h_179 = STK(39);
    Term _h_180 = STK(40);
    Term _h_144 = r0;
    WL_OPEN
    _result_79 = term_keep(e, _result_79, 1);
    if (seq) {
      WL_ROOM(43);
      STK(0) = _h_145;
      STK(1) = _h_146;
      STK(2) = _h_147;
      STK(3) = _h_148;
      STK(4) = _h_149;
      STK(5) = _h_150;
      STK(6) = _h_151;
      STK(7) = _h_152;
      STK(8) = _h_153;
      STK(9) = _h_154;
      STK(10) = _h_155;
      STK(11) = _h_156;
      STK(12) = _h_157;
      STK(13) = _h_158;
      STK(14) = _h_159;
      STK(15) = _h_160;
      STK(16) = _h_161;
      STK(17) = _h_162;
      STK(18) = _h_163;
      STK(19) = _h_164;
      STK(20) = _h_165;
      STK(21) = _h_166;
      STK(22) = _h_167;
      STK(23) = _h_168;
      STK(24) = _h_169;
      STK(25) = _h_170;
      STK(26) = _h_171;
      STK(27) = _h_172;
      STK(28) = _h_173;
      STK(29) = _h_174;
      STK(30) = _h_175;
      STK(31) = _h_176;
      STK(32) = _result_76;
      STK(33) = _result_77;
      STK(34) = _result_78;
      STK(35) = _h_177;
      STK(36) = _result_79;
      STK(37) = _result_80;
      STK(38) = _h_178;
      STK(39) = _h_179;
      STK(40) = _h_180;
      STK(41) = _h_144;
      STK(42) = FID_HEALTH_PRE_K486;
      WL_PUSHN(43);
    } else {
      u64 _t_12 = task_node(e, FID_HEALTH_PRE_K486, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_145;
      e.mem[_t_12 + 1] = _h_146;
      e.mem[_t_12 + 2] = _h_147;
      e.mem[_t_12 + 3] = _h_148;
      e.mem[_t_12 + 4] = _h_149;
      e.mem[_t_12 + 5] = _h_150;
      e.mem[_t_12 + 6] = _h_151;
      e.mem[_t_12 + 7] = _h_152;
      e.mem[_t_12 + 8] = _h_153;
      e.mem[_t_12 + 9] = _h_154;
      e.mem[_t_12 + 10] = _h_155;
      e.mem[_t_12 + 11] = _h_156;
      e.mem[_t_12 + 12] = _h_157;
      e.mem[_t_12 + 13] = _h_158;
      e.mem[_t_12 + 14] = _h_159;
      e.mem[_t_12 + 15] = _h_160;
      e.mem[_t_12 + 16] = _h_161;
      e.mem[_t_12 + 17] = _h_162;
      e.mem[_t_12 + 18] = _h_163;
      e.mem[_t_12 + 19] = _h_164;
      e.mem[_t_12 + 20] = _h_165;
      e.mem[_t_12 + 21] = _h_166;
      e.mem[_t_12 + 22] = _h_167;
      e.mem[_t_12 + 23] = _h_168;
      e.mem[_t_12 + 24] = _h_169;
      e.mem[_t_12 + 25] = _h_170;
      e.mem[_t_12 + 26] = _h_171;
      e.mem[_t_12 + 27] = _h_172;
      e.mem[_t_12 + 28] = _h_173;
      e.mem[_t_12 + 29] = _h_174;
      e.mem[_t_12 + 30] = _h_175;
      e.mem[_t_12 + 31] = _h_176;
      e.mem[_t_12 + 32] = _result_76;
      e.mem[_t_12 + 33] = _result_77;
      e.mem[_t_12 + 34] = _result_78;
      e.mem[_t_12 + 35] = _h_177;
      e.mem[_t_12 + 36] = _result_79;
      e.mem[_t_12 + 37] = _result_80;
      e.mem[_t_12 + 38] = _h_178;
      e.mem[_t_12 + 39] = _h_179;
      e.mem[_t_12 + 40] = _h_180;
      e.mem[_t_12 + 41] = _h_144;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K486, _t_12);
      WL_IDX = 42;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_13 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _result_79;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_13);
    }
    r0 = _result_79;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K486)
  {
    WL_POPN(42);
    u32 _h_182 = STK(0);
    u32 _h_183 = STK(1);
    Term _h_184 = STK(2);
    Term _h_185 = STK(3);
    Term _h_186 = STK(4);
    Term _h_187 = STK(5);
    Term _h_188 = STK(6);
    Term _h_189 = STK(7);
    u32 _h_190 = STK(8);
    Term _h_191 = STK(9);
    u32 _h_192 = STK(10);
    Term _h_193 = STK(11);
    u32 _h_194 = STK(12);
    Term _h_195 = STK(13);
    u32 _h_196 = STK(14);
    u32 _h_197 = STK(15);
    u32 _h_198 = STK(16);
    u32 _h_199 = STK(17);
    u32 _h_200 = STK(18);
    u32 _h_201 = STK(19);
    u32 _h_202 = STK(20);
    u32 _h_203 = STK(21);
    u32 _h_204 = STK(22);
    Term _h_205 = STK(23);
    Term _h_206 = STK(24);
    u32 _h_207 = STK(25);
    u32 _h_208 = STK(26);
    u32 _h_209 = STK(27);
    u32 _h_210 = STK(28);
    u32 _h_211 = STK(29);
    u32 _h_212 = STK(30);
    u32 _h_213 = STK(31);
    u32 _result_81 = STK(32);
    u32 _result_82 = STK(33);
    Term _result_83 = STK(34);
    Term _h_214 = STK(35);
    Term _result_84 = STK(36);
    Term _result_85 = STK(37);
    Term _h_215 = STK(38);
    Term _h_216 = STK(39);
    Term _h_217 = STK(40);
    Term _h_218 = STK(41);
    Term _h_181 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(44);
      STK(0) = _h_182;
      STK(1) = _h_183;
      STK(2) = _h_184;
      STK(3) = _h_185;
      STK(4) = _h_186;
      STK(5) = _h_187;
      STK(6) = _h_188;
      STK(7) = _h_189;
      STK(8) = _h_190;
      STK(9) = _h_191;
      STK(10) = _h_192;
      STK(11) = _h_193;
      STK(12) = _h_194;
      STK(13) = _h_195;
      STK(14) = _h_196;
      STK(15) = _h_197;
      STK(16) = _h_198;
      STK(17) = _h_199;
      STK(18) = _h_200;
      STK(19) = _h_201;
      STK(20) = _h_202;
      STK(21) = _h_203;
      STK(22) = _h_204;
      STK(23) = _h_205;
      STK(24) = _h_206;
      STK(25) = _h_207;
      STK(26) = _h_208;
      STK(27) = _h_209;
      STK(28) = _h_210;
      STK(29) = _h_211;
      STK(30) = _h_212;
      STK(31) = _h_213;
      STK(32) = _result_81;
      STK(33) = _result_82;
      STK(34) = _result_83;
      STK(35) = _h_214;
      STK(36) = _result_84;
      STK(37) = _result_85;
      STK(38) = _h_215;
      STK(39) = _h_216;
      STK(40) = _h_217;
      STK(41) = _h_218;
      STK(42) = _h_181;
      STK(43) = FID_HEALTH_PRE_K487;
      WL_PUSHN(44);
    } else {
      u64 _t_14 = task_node(e, FID_HEALTH_PRE_K487, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_182;
      e.mem[_t_14 + 1] = _h_183;
      e.mem[_t_14 + 2] = _h_184;
      e.mem[_t_14 + 3] = _h_185;
      e.mem[_t_14 + 4] = _h_186;
      e.mem[_t_14 + 5] = _h_187;
      e.mem[_t_14 + 6] = _h_188;
      e.mem[_t_14 + 7] = _h_189;
      e.mem[_t_14 + 8] = _h_190;
      e.mem[_t_14 + 9] = _h_191;
      e.mem[_t_14 + 10] = _h_192;
      e.mem[_t_14 + 11] = _h_193;
      e.mem[_t_14 + 12] = _h_194;
      e.mem[_t_14 + 13] = _h_195;
      e.mem[_t_14 + 14] = _h_196;
      e.mem[_t_14 + 15] = _h_197;
      e.mem[_t_14 + 16] = _h_198;
      e.mem[_t_14 + 17] = _h_199;
      e.mem[_t_14 + 18] = _h_200;
      e.mem[_t_14 + 19] = _h_201;
      e.mem[_t_14 + 20] = _h_202;
      e.mem[_t_14 + 21] = _h_203;
      e.mem[_t_14 + 22] = _h_204;
      e.mem[_t_14 + 23] = _h_205;
      e.mem[_t_14 + 24] = _h_206;
      e.mem[_t_14 + 25] = _h_207;
      e.mem[_t_14 + 26] = _h_208;
      e.mem[_t_14 + 27] = _h_209;
      e.mem[_t_14 + 28] = _h_210;
      e.mem[_t_14 + 29] = _h_211;
      e.mem[_t_14 + 30] = _h_212;
      e.mem[_t_14 + 31] = _h_213;
      e.mem[_t_14 + 32] = _result_81;
      e.mem[_t_14 + 33] = _result_82;
      e.mem[_t_14 + 34] = _result_83;
      e.mem[_t_14 + 35] = _h_214;
      e.mem[_t_14 + 36] = _result_84;
      e.mem[_t_14 + 37] = _result_85;
      e.mem[_t_14 + 38] = _h_215;
      e.mem[_t_14 + 39] = _h_216;
      e.mem[_t_14 + 40] = _h_217;
      e.mem[_t_14 + 41] = _h_218;
      e.mem[_t_14 + 42] = _h_181;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K487, _t_14);
      WL_IDX = 43;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_11)) {
      u64 _t_15 = task_node(e, FID_HOST_RENDER_RENDER_LIST_11, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _result_85;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_11, _t_15);
    }
    r0 = _result_85;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K487)
  {
    WL_POPN(43);
    u32 _h_220 = STK(0);
    u32 _h_221 = STK(1);
    Term _h_222 = STK(2);
    Term _h_223 = STK(3);
    Term _h_224 = STK(4);
    Term _h_225 = STK(5);
    Term _h_226 = STK(6);
    Term _h_227 = STK(7);
    u32 _h_228 = STK(8);
    Term _h_229 = STK(9);
    u32 _h_230 = STK(10);
    Term _h_231 = STK(11);
    u32 _h_232 = STK(12);
    Term _h_233 = STK(13);
    u32 _h_234 = STK(14);
    u32 _h_235 = STK(15);
    u32 _h_236 = STK(16);
    u32 _h_237 = STK(17);
    u32 _h_238 = STK(18);
    u32 _h_239 = STK(19);
    u32 _h_240 = STK(20);
    u32 _h_241 = STK(21);
    u32 _h_242 = STK(22);
    Term _h_243 = STK(23);
    Term _h_244 = STK(24);
    u32 _h_245 = STK(25);
    u32 _h_246 = STK(26);
    u32 _h_247 = STK(27);
    u32 _h_248 = STK(28);
    u32 _h_249 = STK(29);
    u32 _h_250 = STK(30);
    u32 _h_251 = STK(31);
    u32 _result_86 = STK(32);
    u32 _result_87 = STK(33);
    Term _result_88 = STK(34);
    Term _h_252 = STK(35);
    Term _result_89 = STK(36);
    Term _result_90 = STK(37);
    Term _h_253 = STK(38);
    Term _h_254 = STK(39);
    Term _h_255 = STK(40);
    Term _h_256 = STK(41);
    Term _h_257 = STK(42);
    Term _h_219 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_220;
      STK(1) = _h_221;
      STK(2) = _h_222;
      STK(3) = _h_223;
      STK(4) = _h_224;
      STK(5) = _h_225;
      STK(6) = _h_226;
      STK(7) = _h_227;
      STK(8) = _h_228;
      STK(9) = _h_229;
      STK(10) = _h_230;
      STK(11) = _h_231;
      STK(12) = _h_232;
      STK(13) = _h_233;
      STK(14) = _h_234;
      STK(15) = _h_235;
      STK(16) = _h_236;
      STK(17) = _h_237;
      STK(18) = _h_238;
      STK(19) = _h_239;
      STK(20) = _h_240;
      STK(21) = _result_86;
      STK(22) = _result_87;
      STK(23) = _result_88;
      STK(24) = _h_252;
      STK(25) = _result_89;
      STK(26) = _result_90;
      STK(27) = _h_253;
      STK(28) = _h_254;
      STK(29) = _h_255;
      STK(30) = _h_256;
      STK(31) = _h_257;
      STK(32) = _h_219;
      STK(33) = FID_HEALTH_PRE_K488;
      WL_PUSHN(34);
    } else {
      u64 _t_16 = task_node(e, FID_HEALTH_PRE_K488, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_220;
      e.mem[_t_16 + 1] = _h_221;
      e.mem[_t_16 + 2] = _h_222;
      e.mem[_t_16 + 3] = _h_223;
      e.mem[_t_16 + 4] = _h_224;
      e.mem[_t_16 + 5] = _h_225;
      e.mem[_t_16 + 6] = _h_226;
      e.mem[_t_16 + 7] = _h_227;
      e.mem[_t_16 + 8] = _h_228;
      e.mem[_t_16 + 9] = _h_229;
      e.mem[_t_16 + 10] = _h_230;
      e.mem[_t_16 + 11] = _h_231;
      e.mem[_t_16 + 12] = _h_232;
      e.mem[_t_16 + 13] = _h_233;
      e.mem[_t_16 + 14] = _h_234;
      e.mem[_t_16 + 15] = _h_235;
      e.mem[_t_16 + 16] = _h_236;
      e.mem[_t_16 + 17] = _h_237;
      e.mem[_t_16 + 18] = _h_238;
      e.mem[_t_16 + 19] = _h_239;
      e.mem[_t_16 + 20] = _h_240;
      e.mem[_t_16 + 21] = _result_86;
      e.mem[_t_16 + 22] = _result_87;
      e.mem[_t_16 + 23] = _result_88;
      e.mem[_t_16 + 24] = _h_252;
      e.mem[_t_16 + 25] = _result_89;
      e.mem[_t_16 + 26] = _result_90;
      e.mem[_t_16 + 27] = _h_253;
      e.mem[_t_16 + 28] = _h_254;
      e.mem[_t_16 + 29] = _h_255;
      e.mem[_t_16 + 30] = _h_256;
      e.mem[_t_16 + 31] = _h_257;
      e.mem[_t_16 + 32] = _h_219;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K488, _t_16);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_WORLD_1)) {
      u64 _t_17 = task_node(e, FID_HOST_RENDER_RENDER_WORLD_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_241;
      e.mem[_t_17 + 1] = _h_242;
      e.mem[_t_17 + 2] = _h_243;
      e.mem[_t_17 + 3] = _h_244;
      e.mem[_t_17 + 4] = _h_245;
      e.mem[_t_17 + 5] = _h_246;
      e.mem[_t_17 + 6] = _h_247;
      e.mem[_t_17 + 7] = _h_248;
      e.mem[_t_17 + 8] = _h_249;
      e.mem[_t_17 + 9] = _h_250;
      e.mem[_t_17 + 10] = _h_251;
      return term_tsk(FID_HOST_RENDER_RENDER_WORLD_1, _t_17);
    }
    r0 = _h_241;
    r1 = _h_242;
    r2 = _h_243;
    r3 = _h_244;
    r4 = _h_245;
    r5 = _h_246;
    r6 = _h_247;
    r7 = _h_248;
    r8 = _h_249;
    r9 = _h_250;
    r10 = _h_251;
    WL_JMP(FID_HOST_RENDER_RENDER_WORLD_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K488)
  {
    WL_POPN(33);
    u32 _h_259 = STK(0);
    u32 _h_260 = STK(1);
    Term _h_261 = STK(2);
    Term _h_262 = STK(3);
    Term _h_263 = STK(4);
    Term _h_264 = STK(5);
    Term _h_265 = STK(6);
    Term _h_266 = STK(7);
    u32 _h_267 = STK(8);
    Term _h_268 = STK(9);
    u32 _h_269 = STK(10);
    Term _h_270 = STK(11);
    u32 _h_271 = STK(12);
    Term _h_272 = STK(13);
    u32 _h_273 = STK(14);
    u32 _h_274 = STK(15);
    u32 _h_275 = STK(16);
    u32 _h_276 = STK(17);
    u32 _h_277 = STK(18);
    u32 _h_278 = STK(19);
    u32 _h_279 = STK(20);
    u32 _result_91 = STK(21);
    u32 _result_92 = STK(22);
    Term _result_93 = STK(23);
    Term _h_280 = STK(24);
    Term _result_94 = STK(25);
    Term _result_95 = STK(26);
    Term _h_281 = STK(27);
    Term _h_282 = STK(28);
    Term _h_283 = STK(29);
    Term _h_284 = STK(30);
    Term _h_285 = STK(31);
    Term _h_286 = STK(32);
    Term _h_258 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_259;
      STK(1) = _h_260;
      STK(2) = _h_261;
      STK(3) = _h_262;
      STK(4) = _h_263;
      STK(5) = _h_264;
      STK(6) = _h_265;
      STK(7) = _h_266;
      STK(8) = _h_267;
      STK(9) = _h_268;
      STK(10) = _h_269;
      STK(11) = _h_270;
      STK(12) = _h_271;
      STK(13) = _h_272;
      STK(14) = _h_273;
      STK(15) = _h_274;
      STK(16) = _h_275;
      STK(17) = _h_276;
      STK(18) = _h_277;
      STK(19) = _h_278;
      STK(20) = _h_279;
      STK(21) = _result_91;
      STK(22) = _result_92;
      STK(23) = _result_93;
      STK(24) = _h_280;
      STK(25) = _result_94;
      STK(26) = _result_95;
      STK(27) = _h_281;
      STK(28) = _h_282;
      STK(29) = _h_283;
      STK(30) = _h_284;
      STK(31) = _h_285;
      STK(32) = _h_286;
      STK(33) = FID_HEALTH_PRE_K489;
      WL_PUSHN(34);
    } else {
      u64 _t_18 = task_node(e, FID_HEALTH_PRE_K489, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_259;
      e.mem[_t_18 + 1] = _h_260;
      e.mem[_t_18 + 2] = _h_261;
      e.mem[_t_18 + 3] = _h_262;
      e.mem[_t_18 + 4] = _h_263;
      e.mem[_t_18 + 5] = _h_264;
      e.mem[_t_18 + 6] = _h_265;
      e.mem[_t_18 + 7] = _h_266;
      e.mem[_t_18 + 8] = _h_267;
      e.mem[_t_18 + 9] = _h_268;
      e.mem[_t_18 + 10] = _h_269;
      e.mem[_t_18 + 11] = _h_270;
      e.mem[_t_18 + 12] = _h_271;
      e.mem[_t_18 + 13] = _h_272;
      e.mem[_t_18 + 14] = _h_273;
      e.mem[_t_18 + 15] = _h_274;
      e.mem[_t_18 + 16] = _h_275;
      e.mem[_t_18 + 17] = _h_276;
      e.mem[_t_18 + 18] = _h_277;
      e.mem[_t_18 + 19] = _h_278;
      e.mem[_t_18 + 20] = _h_279;
      e.mem[_t_18 + 21] = _result_91;
      e.mem[_t_18 + 22] = _result_92;
      e.mem[_t_18 + 23] = _result_93;
      e.mem[_t_18 + 24] = _h_280;
      e.mem[_t_18 + 25] = _result_94;
      e.mem[_t_18 + 26] = _result_95;
      e.mem[_t_18 + 27] = _h_281;
      e.mem[_t_18 + 28] = _h_282;
      e.mem[_t_18 + 29] = _h_283;
      e.mem[_t_18 + 30] = _h_284;
      e.mem[_t_18 + 31] = _h_285;
      e.mem[_t_18 + 32] = _h_286;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K489, _t_18);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_258;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 74);
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_258;
    r1 = term_ctr(CID_SCON, STAT_OFF + 74);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K489)
  {
    WL_POPN(33);
    u32 _h_288 = STK(0);
    u32 _h_289 = STK(1);
    Term _h_290 = STK(2);
    Term _h_291 = STK(3);
    Term _h_292 = STK(4);
    Term _h_293 = STK(5);
    Term _h_294 = STK(6);
    Term _h_295 = STK(7);
    u32 _h_296 = STK(8);
    Term _h_297 = STK(9);
    u32 _h_298 = STK(10);
    Term _h_299 = STK(11);
    u32 _h_300 = STK(12);
    Term _h_301 = STK(13);
    u32 _h_302 = STK(14);
    u32 _h_303 = STK(15);
    u32 _h_304 = STK(16);
    u32 _h_305 = STK(17);
    u32 _h_306 = STK(18);
    u32 _h_307 = STK(19);
    u32 _h_308 = STK(20);
    u32 _result_96 = STK(21);
    u32 _result_97 = STK(22);
    Term _result_98 = STK(23);
    Term _h_309 = STK(24);
    Term _result_99 = STK(25);
    Term _result_100 = STK(26);
    Term _h_310 = STK(27);
    Term _h_311 = STK(28);
    Term _h_312 = STK(29);
    Term _h_313 = STK(30);
    Term _h_314 = STK(31);
    Term _h_315 = STK(32);
    Term _h_287 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_288;
      STK(1) = _h_289;
      STK(2) = _h_290;
      STK(3) = _h_291;
      STK(4) = _h_292;
      STK(5) = _h_293;
      STK(6) = _h_294;
      STK(7) = _h_295;
      STK(8) = _h_296;
      STK(9) = _h_297;
      STK(10) = _h_298;
      STK(11) = _h_299;
      STK(12) = _h_300;
      STK(13) = _h_301;
      STK(14) = _h_302;
      STK(15) = _h_303;
      STK(16) = _h_304;
      STK(17) = _h_305;
      STK(18) = _h_306;
      STK(19) = _h_307;
      STK(20) = _h_308;
      STK(21) = _result_96;
      STK(22) = _result_97;
      STK(23) = _result_98;
      STK(24) = _h_309;
      STK(25) = _result_99;
      STK(26) = _result_100;
      STK(27) = _h_310;
      STK(28) = _h_311;
      STK(29) = _h_312;
      STK(30) = _h_313;
      STK(31) = _h_314;
      STK(32) = _h_315;
      STK(33) = FID_HEALTH_PRE_K490;
      WL_PUSHN(34);
    } else {
      u64 _t_20 = task_node(e, FID_HEALTH_PRE_K490, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_288;
      e.mem[_t_20 + 1] = _h_289;
      e.mem[_t_20 + 2] = _h_290;
      e.mem[_t_20 + 3] = _h_291;
      e.mem[_t_20 + 4] = _h_292;
      e.mem[_t_20 + 5] = _h_293;
      e.mem[_t_20 + 6] = _h_294;
      e.mem[_t_20 + 7] = _h_295;
      e.mem[_t_20 + 8] = _h_296;
      e.mem[_t_20 + 9] = _h_297;
      e.mem[_t_20 + 10] = _h_298;
      e.mem[_t_20 + 11] = _h_299;
      e.mem[_t_20 + 12] = _h_300;
      e.mem[_t_20 + 13] = _h_301;
      e.mem[_t_20 + 14] = _h_302;
      e.mem[_t_20 + 15] = _h_303;
      e.mem[_t_20 + 16] = _h_304;
      e.mem[_t_20 + 17] = _h_305;
      e.mem[_t_20 + 18] = _h_306;
      e.mem[_t_20 + 19] = _h_307;
      e.mem[_t_20 + 20] = _h_308;
      e.mem[_t_20 + 21] = _result_96;
      e.mem[_t_20 + 22] = _result_97;
      e.mem[_t_20 + 23] = _result_98;
      e.mem[_t_20 + 24] = _h_309;
      e.mem[_t_20 + 25] = _result_99;
      e.mem[_t_20 + 26] = _result_100;
      e.mem[_t_20 + 27] = _h_310;
      e.mem[_t_20 + 28] = _h_311;
      e.mem[_t_20 + 29] = _h_312;
      e.mem[_t_20 + 30] = _h_313;
      e.mem[_t_20 + 31] = _h_314;
      e.mem[_t_20 + 32] = _h_315;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K490, _t_20);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 454);
      e.mem[_t_21 + 1] = _h_287;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 454);
    r1 = _h_287;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K490)
  {
    WL_POPN(33);
    u32 _h_317 = STK(0);
    u32 _h_318 = STK(1);
    Term _h_319 = STK(2);
    Term _h_320 = STK(3);
    Term _h_321 = STK(4);
    Term _h_322 = STK(5);
    Term _h_323 = STK(6);
    Term _h_324 = STK(7);
    u32 _h_325 = STK(8);
    Term _h_326 = STK(9);
    u32 _h_327 = STK(10);
    Term _h_328 = STK(11);
    u32 _h_329 = STK(12);
    Term _h_330 = STK(13);
    u32 _h_331 = STK(14);
    u32 _h_332 = STK(15);
    u32 _h_333 = STK(16);
    u32 _h_334 = STK(17);
    u32 _h_335 = STK(18);
    u32 _h_336 = STK(19);
    u32 _h_337 = STK(20);
    u32 _result_101 = STK(21);
    u32 _result_102 = STK(22);
    Term _result_103 = STK(23);
    Term _h_338 = STK(24);
    Term _result_104 = STK(25);
    Term _result_105 = STK(26);
    Term _h_339 = STK(27);
    Term _h_340 = STK(28);
    Term _h_341 = STK(29);
    Term _h_342 = STK(30);
    Term _h_343 = STK(31);
    Term _h_344 = STK(32);
    Term _h_316 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _h_317;
      STK(1) = _h_318;
      STK(2) = _h_319;
      STK(3) = _h_320;
      STK(4) = _h_321;
      STK(5) = _h_322;
      STK(6) = _h_323;
      STK(7) = _h_324;
      STK(8) = _h_325;
      STK(9) = _h_326;
      STK(10) = _h_327;
      STK(11) = _h_328;
      STK(12) = _h_329;
      STK(13) = _h_330;
      STK(14) = _h_331;
      STK(15) = _h_332;
      STK(16) = _h_333;
      STK(17) = _h_334;
      STK(18) = _h_335;
      STK(19) = _h_336;
      STK(20) = _h_337;
      STK(21) = _result_101;
      STK(22) = _result_102;
      STK(23) = _result_103;
      STK(24) = _h_338;
      STK(25) = _result_104;
      STK(26) = _result_105;
      STK(27) = _h_339;
      STK(28) = _h_340;
      STK(29) = _h_341;
      STK(30) = _h_342;
      STK(31) = _h_343;
      STK(32) = FID_HEALTH_PRE_K491;
      WL_PUSHN(33);
    } else {
      u64 _t_22 = task_node(e, FID_HEALTH_PRE_K491, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_317;
      e.mem[_t_22 + 1] = _h_318;
      e.mem[_t_22 + 2] = _h_319;
      e.mem[_t_22 + 3] = _h_320;
      e.mem[_t_22 + 4] = _h_321;
      e.mem[_t_22 + 5] = _h_322;
      e.mem[_t_22 + 6] = _h_323;
      e.mem[_t_22 + 7] = _h_324;
      e.mem[_t_22 + 8] = _h_325;
      e.mem[_t_22 + 9] = _h_326;
      e.mem[_t_22 + 10] = _h_327;
      e.mem[_t_22 + 11] = _h_328;
      e.mem[_t_22 + 12] = _h_329;
      e.mem[_t_22 + 13] = _h_330;
      e.mem[_t_22 + 14] = _h_331;
      e.mem[_t_22 + 15] = _h_332;
      e.mem[_t_22 + 16] = _h_333;
      e.mem[_t_22 + 17] = _h_334;
      e.mem[_t_22 + 18] = _h_335;
      e.mem[_t_22 + 19] = _h_336;
      e.mem[_t_22 + 20] = _h_337;
      e.mem[_t_22 + 21] = _result_101;
      e.mem[_t_22 + 22] = _result_102;
      e.mem[_t_22 + 23] = _result_103;
      e.mem[_t_22 + 24] = _h_338;
      e.mem[_t_22 + 25] = _result_104;
      e.mem[_t_22 + 26] = _result_105;
      e.mem[_t_22 + 27] = _h_339;
      e.mem[_t_22 + 28] = _h_340;
      e.mem[_t_22 + 29] = _h_341;
      e.mem[_t_22 + 30] = _h_342;
      e.mem[_t_22 + 31] = _h_343;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K491, _t_22);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_344;
      e.mem[_t_23 + 1] = _h_316;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_344;
    r1 = _h_316;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K491)
  {
    WL_POPN(32);
    u32 _h_346 = STK(0);
    u32 _h_347 = STK(1);
    Term _h_348 = STK(2);
    Term _h_349 = STK(3);
    Term _h_350 = STK(4);
    Term _h_351 = STK(5);
    Term _h_352 = STK(6);
    Term _h_353 = STK(7);
    u32 _h_354 = STK(8);
    Term _h_355 = STK(9);
    u32 _h_356 = STK(10);
    Term _h_357 = STK(11);
    u32 _h_358 = STK(12);
    Term _h_359 = STK(13);
    u32 _h_360 = STK(14);
    u32 _h_361 = STK(15);
    u32 _h_362 = STK(16);
    u32 _h_363 = STK(17);
    u32 _h_364 = STK(18);
    u32 _h_365 = STK(19);
    u32 _h_366 = STK(20);
    u32 _result_106 = STK(21);
    u32 _result_107 = STK(22);
    Term _result_108 = STK(23);
    Term _h_367 = STK(24);
    Term _result_109 = STK(25);
    Term _result_110 = STK(26);
    Term _h_368 = STK(27);
    Term _h_369 = STK(28);
    Term _h_370 = STK(29);
    Term _h_371 = STK(30);
    Term _h_372 = STK(31);
    Term _h_345 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _h_346;
      STK(1) = _h_347;
      STK(2) = _h_348;
      STK(3) = _h_349;
      STK(4) = _h_350;
      STK(5) = _h_351;
      STK(6) = _h_352;
      STK(7) = _h_353;
      STK(8) = _h_354;
      STK(9) = _h_355;
      STK(10) = _h_356;
      STK(11) = _h_357;
      STK(12) = _h_358;
      STK(13) = _h_359;
      STK(14) = _h_360;
      STK(15) = _h_361;
      STK(16) = _h_362;
      STK(17) = _h_363;
      STK(18) = _h_364;
      STK(19) = _h_365;
      STK(20) = _h_366;
      STK(21) = _result_106;
      STK(22) = _result_107;
      STK(23) = _result_108;
      STK(24) = _h_367;
      STK(25) = _result_109;
      STK(26) = _result_110;
      STK(27) = _h_368;
      STK(28) = _h_369;
      STK(29) = _h_370;
      STK(30) = _h_371;
      STK(31) = _h_372;
      STK(32) = FID_HEALTH_PRE_K492;
      WL_PUSHN(33);
    } else {
      u64 _t_24 = task_node(e, FID_HEALTH_PRE_K492, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_346;
      e.mem[_t_24 + 1] = _h_347;
      e.mem[_t_24 + 2] = _h_348;
      e.mem[_t_24 + 3] = _h_349;
      e.mem[_t_24 + 4] = _h_350;
      e.mem[_t_24 + 5] = _h_351;
      e.mem[_t_24 + 6] = _h_352;
      e.mem[_t_24 + 7] = _h_353;
      e.mem[_t_24 + 8] = _h_354;
      e.mem[_t_24 + 9] = _h_355;
      e.mem[_t_24 + 10] = _h_356;
      e.mem[_t_24 + 11] = _h_357;
      e.mem[_t_24 + 12] = _h_358;
      e.mem[_t_24 + 13] = _h_359;
      e.mem[_t_24 + 14] = _h_360;
      e.mem[_t_24 + 15] = _h_361;
      e.mem[_t_24 + 16] = _h_362;
      e.mem[_t_24 + 17] = _h_363;
      e.mem[_t_24 + 18] = _h_364;
      e.mem[_t_24 + 19] = _h_365;
      e.mem[_t_24 + 20] = _h_366;
      e.mem[_t_24 + 21] = _result_106;
      e.mem[_t_24 + 22] = _result_107;
      e.mem[_t_24 + 23] = _result_108;
      e.mem[_t_24 + 24] = _h_367;
      e.mem[_t_24 + 25] = _result_109;
      e.mem[_t_24 + 26] = _result_110;
      e.mem[_t_24 + 27] = _h_368;
      e.mem[_t_24 + 28] = _h_369;
      e.mem[_t_24 + 29] = _h_370;
      e.mem[_t_24 + 30] = _h_371;
      e.mem[_t_24 + 31] = _h_372;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K492, _t_24);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 466);
      e.mem[_t_25 + 1] = _h_345;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 466);
    r1 = _h_345;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K492)
  {
    WL_POPN(32);
    u32 _h_374 = STK(0);
    u32 _h_375 = STK(1);
    Term _h_376 = STK(2);
    Term _h_377 = STK(3);
    Term _h_378 = STK(4);
    Term _h_379 = STK(5);
    Term _h_380 = STK(6);
    Term _h_381 = STK(7);
    u32 _h_382 = STK(8);
    Term _h_383 = STK(9);
    u32 _h_384 = STK(10);
    Term _h_385 = STK(11);
    u32 _h_386 = STK(12);
    Term _h_387 = STK(13);
    u32 _h_388 = STK(14);
    u32 _h_389 = STK(15);
    u32 _h_390 = STK(16);
    u32 _h_391 = STK(17);
    u32 _h_392 = STK(18);
    u32 _h_393 = STK(19);
    u32 _h_394 = STK(20);
    u32 _result_111 = STK(21);
    u32 _result_112 = STK(22);
    Term _result_113 = STK(23);
    Term _h_395 = STK(24);
    Term _result_114 = STK(25);
    Term _result_115 = STK(26);
    Term _h_396 = STK(27);
    Term _h_397 = STK(28);
    Term _h_398 = STK(29);
    Term _h_399 = STK(30);
    Term _h_400 = STK(31);
    Term _h_373 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_374;
      STK(1) = _h_375;
      STK(2) = _h_376;
      STK(3) = _h_377;
      STK(4) = _h_378;
      STK(5) = _h_379;
      STK(6) = _h_380;
      STK(7) = _h_381;
      STK(8) = _h_382;
      STK(9) = _h_383;
      STK(10) = _h_384;
      STK(11) = _h_385;
      STK(12) = _h_386;
      STK(13) = _h_387;
      STK(14) = _h_388;
      STK(15) = _h_389;
      STK(16) = _h_390;
      STK(17) = _h_391;
      STK(18) = _h_392;
      STK(19) = _h_393;
      STK(20) = _h_394;
      STK(21) = _result_111;
      STK(22) = _result_112;
      STK(23) = _result_113;
      STK(24) = _h_395;
      STK(25) = _result_114;
      STK(26) = _result_115;
      STK(27) = _h_396;
      STK(28) = _h_397;
      STK(29) = _h_398;
      STK(30) = _h_399;
      STK(31) = FID_HEALTH_PRE_K493;
      WL_PUSHN(32);
    } else {
      u64 _t_26 = task_node(e, FID_HEALTH_PRE_K493, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_374;
      e.mem[_t_26 + 1] = _h_375;
      e.mem[_t_26 + 2] = _h_376;
      e.mem[_t_26 + 3] = _h_377;
      e.mem[_t_26 + 4] = _h_378;
      e.mem[_t_26 + 5] = _h_379;
      e.mem[_t_26 + 6] = _h_380;
      e.mem[_t_26 + 7] = _h_381;
      e.mem[_t_26 + 8] = _h_382;
      e.mem[_t_26 + 9] = _h_383;
      e.mem[_t_26 + 10] = _h_384;
      e.mem[_t_26 + 11] = _h_385;
      e.mem[_t_26 + 12] = _h_386;
      e.mem[_t_26 + 13] = _h_387;
      e.mem[_t_26 + 14] = _h_388;
      e.mem[_t_26 + 15] = _h_389;
      e.mem[_t_26 + 16] = _h_390;
      e.mem[_t_26 + 17] = _h_391;
      e.mem[_t_26 + 18] = _h_392;
      e.mem[_t_26 + 19] = _h_393;
      e.mem[_t_26 + 20] = _h_394;
      e.mem[_t_26 + 21] = _result_111;
      e.mem[_t_26 + 22] = _result_112;
      e.mem[_t_26 + 23] = _result_113;
      e.mem[_t_26 + 24] = _h_395;
      e.mem[_t_26 + 25] = _result_114;
      e.mem[_t_26 + 26] = _result_115;
      e.mem[_t_26 + 27] = _h_396;
      e.mem[_t_26 + 28] = _h_397;
      e.mem[_t_26 + 29] = _h_398;
      e.mem[_t_26 + 30] = _h_399;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K493, _t_26);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _h_400;
      e.mem[_t_27 + 1] = _h_373;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = _h_400;
    r1 = _h_373;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K493)
  {
    WL_POPN(31);
    u32 _h_402 = STK(0);
    u32 _h_403 = STK(1);
    Term _h_404 = STK(2);
    Term _h_405 = STK(3);
    Term _h_406 = STK(4);
    Term _h_407 = STK(5);
    Term _h_408 = STK(6);
    Term _h_409 = STK(7);
    u32 _h_410 = STK(8);
    Term _h_411 = STK(9);
    u32 _h_412 = STK(10);
    Term _h_413 = STK(11);
    u32 _h_414 = STK(12);
    Term _h_415 = STK(13);
    u32 _h_416 = STK(14);
    u32 _h_417 = STK(15);
    u32 _h_418 = STK(16);
    u32 _h_419 = STK(17);
    u32 _h_420 = STK(18);
    u32 _h_421 = STK(19);
    u32 _h_422 = STK(20);
    u32 _result_116 = STK(21);
    u32 _result_117 = STK(22);
    Term _result_118 = STK(23);
    Term _h_423 = STK(24);
    Term _result_119 = STK(25);
    Term _result_120 = STK(26);
    Term _h_424 = STK(27);
    Term _h_425 = STK(28);
    Term _h_426 = STK(29);
    Term _h_427 = STK(30);
    Term _h_401 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_402;
      STK(1) = _h_403;
      STK(2) = _h_404;
      STK(3) = _h_405;
      STK(4) = _h_406;
      STK(5) = _h_407;
      STK(6) = _h_408;
      STK(7) = _h_409;
      STK(8) = _h_410;
      STK(9) = _h_411;
      STK(10) = _h_412;
      STK(11) = _h_413;
      STK(12) = _h_414;
      STK(13) = _h_415;
      STK(14) = _h_416;
      STK(15) = _h_417;
      STK(16) = _h_418;
      STK(17) = _h_419;
      STK(18) = _h_420;
      STK(19) = _h_421;
      STK(20) = _h_422;
      STK(21) = _result_116;
      STK(22) = _result_117;
      STK(23) = _result_118;
      STK(24) = _h_423;
      STK(25) = _result_119;
      STK(26) = _result_120;
      STK(27) = _h_424;
      STK(28) = _h_425;
      STK(29) = _h_426;
      STK(30) = _h_427;
      STK(31) = FID_HEALTH_PRE_K494;
      WL_PUSHN(32);
    } else {
      u64 _t_28 = task_node(e, FID_HEALTH_PRE_K494, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_402;
      e.mem[_t_28 + 1] = _h_403;
      e.mem[_t_28 + 2] = _h_404;
      e.mem[_t_28 + 3] = _h_405;
      e.mem[_t_28 + 4] = _h_406;
      e.mem[_t_28 + 5] = _h_407;
      e.mem[_t_28 + 6] = _h_408;
      e.mem[_t_28 + 7] = _h_409;
      e.mem[_t_28 + 8] = _h_410;
      e.mem[_t_28 + 9] = _h_411;
      e.mem[_t_28 + 10] = _h_412;
      e.mem[_t_28 + 11] = _h_413;
      e.mem[_t_28 + 12] = _h_414;
      e.mem[_t_28 + 13] = _h_415;
      e.mem[_t_28 + 14] = _h_416;
      e.mem[_t_28 + 15] = _h_417;
      e.mem[_t_28 + 16] = _h_418;
      e.mem[_t_28 + 17] = _h_419;
      e.mem[_t_28 + 18] = _h_420;
      e.mem[_t_28 + 19] = _h_421;
      e.mem[_t_28 + 20] = _h_422;
      e.mem[_t_28 + 21] = _result_116;
      e.mem[_t_28 + 22] = _result_117;
      e.mem[_t_28 + 23] = _result_118;
      e.mem[_t_28 + 24] = _h_423;
      e.mem[_t_28 + 25] = _result_119;
      e.mem[_t_28 + 26] = _result_120;
      e.mem[_t_28 + 27] = _h_424;
      e.mem[_t_28 + 28] = _h_425;
      e.mem[_t_28 + 29] = _h_426;
      e.mem[_t_28 + 30] = _h_427;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K494, _t_28);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 478);
      e.mem[_t_29 + 1] = _h_401;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 478);
    r1 = _h_401;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K494)
  {
    WL_POPN(31);
    u32 _h_429 = STK(0);
    u32 _h_430 = STK(1);
    Term _h_431 = STK(2);
    Term _h_432 = STK(3);
    Term _h_433 = STK(4);
    Term _h_434 = STK(5);
    Term _h_435 = STK(6);
    Term _h_436 = STK(7);
    u32 _h_437 = STK(8);
    Term _h_438 = STK(9);
    u32 _h_439 = STK(10);
    Term _h_440 = STK(11);
    u32 _h_441 = STK(12);
    Term _h_442 = STK(13);
    u32 _h_443 = STK(14);
    u32 _h_444 = STK(15);
    u32 _h_445 = STK(16);
    u32 _h_446 = STK(17);
    u32 _h_447 = STK(18);
    u32 _h_448 = STK(19);
    u32 _h_449 = STK(20);
    u32 _result_121 = STK(21);
    u32 _result_122 = STK(22);
    Term _result_123 = STK(23);
    Term _h_450 = STK(24);
    Term _result_124 = STK(25);
    Term _result_125 = STK(26);
    Term _h_451 = STK(27);
    Term _h_452 = STK(28);
    Term _h_453 = STK(29);
    Term _h_454 = STK(30);
    Term _h_428 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_429;
      STK(1) = _h_430;
      STK(2) = _h_431;
      STK(3) = _h_432;
      STK(4) = _h_433;
      STK(5) = _h_434;
      STK(6) = _h_435;
      STK(7) = _h_436;
      STK(8) = _h_437;
      STK(9) = _h_438;
      STK(10) = _h_439;
      STK(11) = _h_440;
      STK(12) = _h_441;
      STK(13) = _h_442;
      STK(14) = _h_443;
      STK(15) = _h_444;
      STK(16) = _h_445;
      STK(17) = _h_446;
      STK(18) = _h_447;
      STK(19) = _h_448;
      STK(20) = _h_449;
      STK(21) = _result_121;
      STK(22) = _result_122;
      STK(23) = _result_123;
      STK(24) = _h_450;
      STK(25) = _result_124;
      STK(26) = _result_125;
      STK(27) = _h_451;
      STK(28) = _h_452;
      STK(29) = _h_453;
      STK(30) = FID_HEALTH_PRE_K495;
      WL_PUSHN(31);
    } else {
      u64 _t_30 = task_node(e, FID_HEALTH_PRE_K495, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _h_429;
      e.mem[_t_30 + 1] = _h_430;
      e.mem[_t_30 + 2] = _h_431;
      e.mem[_t_30 + 3] = _h_432;
      e.mem[_t_30 + 4] = _h_433;
      e.mem[_t_30 + 5] = _h_434;
      e.mem[_t_30 + 6] = _h_435;
      e.mem[_t_30 + 7] = _h_436;
      e.mem[_t_30 + 8] = _h_437;
      e.mem[_t_30 + 9] = _h_438;
      e.mem[_t_30 + 10] = _h_439;
      e.mem[_t_30 + 11] = _h_440;
      e.mem[_t_30 + 12] = _h_441;
      e.mem[_t_30 + 13] = _h_442;
      e.mem[_t_30 + 14] = _h_443;
      e.mem[_t_30 + 15] = _h_444;
      e.mem[_t_30 + 16] = _h_445;
      e.mem[_t_30 + 17] = _h_446;
      e.mem[_t_30 + 18] = _h_447;
      e.mem[_t_30 + 19] = _h_448;
      e.mem[_t_30 + 20] = _h_449;
      e.mem[_t_30 + 21] = _result_121;
      e.mem[_t_30 + 22] = _result_122;
      e.mem[_t_30 + 23] = _result_123;
      e.mem[_t_30 + 24] = _h_450;
      e.mem[_t_30 + 25] = _result_124;
      e.mem[_t_30 + 26] = _result_125;
      e.mem[_t_30 + 27] = _h_451;
      e.mem[_t_30 + 28] = _h_452;
      e.mem[_t_30 + 29] = _h_453;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K495, _t_30);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_454;
      e.mem[_t_31 + 1] = _h_428;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = _h_454;
    r1 = _h_428;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K495)
  {
    WL_POPN(30);
    u32 _h_456 = STK(0);
    u32 _h_457 = STK(1);
    Term _h_458 = STK(2);
    Term _h_459 = STK(3);
    Term _h_460 = STK(4);
    Term _h_461 = STK(5);
    Term _h_462 = STK(6);
    Term _h_463 = STK(7);
    u32 _h_464 = STK(8);
    Term _h_465 = STK(9);
    u32 _h_466 = STK(10);
    Term _h_467 = STK(11);
    u32 _h_468 = STK(12);
    Term _h_469 = STK(13);
    u32 _h_470 = STK(14);
    u32 _h_471 = STK(15);
    u32 _h_472 = STK(16);
    u32 _h_473 = STK(17);
    u32 _h_474 = STK(18);
    u32 _h_475 = STK(19);
    u32 _h_476 = STK(20);
    u32 _result_126 = STK(21);
    u32 _result_127 = STK(22);
    Term _result_128 = STK(23);
    Term _h_477 = STK(24);
    Term _result_129 = STK(25);
    Term _result_130 = STK(26);
    Term _h_478 = STK(27);
    Term _h_479 = STK(28);
    Term _h_480 = STK(29);
    Term _h_455 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_456;
      STK(1) = _h_457;
      STK(2) = _h_458;
      STK(3) = _h_459;
      STK(4) = _h_460;
      STK(5) = _h_461;
      STK(6) = _h_462;
      STK(7) = _h_463;
      STK(8) = _h_464;
      STK(9) = _h_465;
      STK(10) = _h_466;
      STK(11) = _h_467;
      STK(12) = _h_468;
      STK(13) = _h_469;
      STK(14) = _h_470;
      STK(15) = _h_471;
      STK(16) = _h_472;
      STK(17) = _h_473;
      STK(18) = _h_474;
      STK(19) = _h_475;
      STK(20) = _h_476;
      STK(21) = _result_126;
      STK(22) = _result_127;
      STK(23) = _result_128;
      STK(24) = _h_477;
      STK(25) = _result_129;
      STK(26) = _result_130;
      STK(27) = _h_478;
      STK(28) = _h_479;
      STK(29) = _h_480;
      STK(30) = FID_HEALTH_PRE_K496;
      WL_PUSHN(31);
    } else {
      u64 _t_32 = task_node(e, FID_HEALTH_PRE_K496, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _h_456;
      e.mem[_t_32 + 1] = _h_457;
      e.mem[_t_32 + 2] = _h_458;
      e.mem[_t_32 + 3] = _h_459;
      e.mem[_t_32 + 4] = _h_460;
      e.mem[_t_32 + 5] = _h_461;
      e.mem[_t_32 + 6] = _h_462;
      e.mem[_t_32 + 7] = _h_463;
      e.mem[_t_32 + 8] = _h_464;
      e.mem[_t_32 + 9] = _h_465;
      e.mem[_t_32 + 10] = _h_466;
      e.mem[_t_32 + 11] = _h_467;
      e.mem[_t_32 + 12] = _h_468;
      e.mem[_t_32 + 13] = _h_469;
      e.mem[_t_32 + 14] = _h_470;
      e.mem[_t_32 + 15] = _h_471;
      e.mem[_t_32 + 16] = _h_472;
      e.mem[_t_32 + 17] = _h_473;
      e.mem[_t_32 + 18] = _h_474;
      e.mem[_t_32 + 19] = _h_475;
      e.mem[_t_32 + 20] = _h_476;
      e.mem[_t_32 + 21] = _result_126;
      e.mem[_t_32 + 22] = _result_127;
      e.mem[_t_32 + 23] = _result_128;
      e.mem[_t_32 + 24] = _h_477;
      e.mem[_t_32 + 25] = _result_129;
      e.mem[_t_32 + 26] = _result_130;
      e.mem[_t_32 + 27] = _h_478;
      e.mem[_t_32 + 28] = _h_479;
      e.mem[_t_32 + 29] = _h_480;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K496, _t_32);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 496);
      e.mem[_t_33 + 1] = _h_455;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 496);
    r1 = _h_455;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K496)
  {
    WL_POPN(30);
    u32 _h_482 = STK(0);
    u32 _h_483 = STK(1);
    Term _h_484 = STK(2);
    Term _h_485 = STK(3);
    Term _h_486 = STK(4);
    Term _h_487 = STK(5);
    Term _h_488 = STK(6);
    Term _h_489 = STK(7);
    u32 _h_490 = STK(8);
    Term _h_491 = STK(9);
    u32 _h_492 = STK(10);
    Term _h_493 = STK(11);
    u32 _h_494 = STK(12);
    Term _h_495 = STK(13);
    u32 _h_496 = STK(14);
    u32 _h_497 = STK(15);
    u32 _h_498 = STK(16);
    u32 _h_499 = STK(17);
    u32 _h_500 = STK(18);
    u32 _h_501 = STK(19);
    u32 _h_502 = STK(20);
    u32 _result_131 = STK(21);
    u32 _result_132 = STK(22);
    Term _result_133 = STK(23);
    Term _h_503 = STK(24);
    Term _result_134 = STK(25);
    Term _result_135 = STK(26);
    Term _h_504 = STK(27);
    Term _h_505 = STK(28);
    Term _h_506 = STK(29);
    Term _h_481 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_115(e, _o_0, _h_506, blk_loc(e.mem, _h_506)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_482;
      STK(1) = _h_483;
      STK(2) = _h_484;
      STK(3) = _h_485;
      STK(4) = _h_486;
      STK(5) = _h_487;
      STK(6) = _h_488;
      STK(7) = _h_489;
      STK(8) = _h_490;
      STK(9) = _h_491;
      STK(10) = _h_492;
      STK(11) = _h_493;
      STK(12) = _h_494;
      STK(13) = _h_495;
      STK(14) = _h_496;
      STK(15) = _h_497;
      STK(16) = _h_498;
      STK(17) = _h_499;
      STK(18) = _h_500;
      STK(19) = _h_501;
      STK(20) = _h_502;
      STK(21) = _result_131;
      STK(22) = _result_132;
      STK(23) = _result_133;
      STK(24) = _h_503;
      STK(25) = _result_134;
      STK(26) = _result_135;
      STK(27) = _h_504;
      STK(28) = _h_505;
      STK(29) = FID_HEALTH_PRE_K497;
      WL_PUSHN(30);
    } else {
      u64 _t_34 = task_node(e, FID_HEALTH_PRE_K497, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _h_482;
      e.mem[_t_34 + 1] = _h_483;
      e.mem[_t_34 + 2] = _h_484;
      e.mem[_t_34 + 3] = _h_485;
      e.mem[_t_34 + 4] = _h_486;
      e.mem[_t_34 + 5] = _h_487;
      e.mem[_t_34 + 6] = _h_488;
      e.mem[_t_34 + 7] = _h_489;
      e.mem[_t_34 + 8] = _h_490;
      e.mem[_t_34 + 9] = _h_491;
      e.mem[_t_34 + 10] = _h_492;
      e.mem[_t_34 + 11] = _h_493;
      e.mem[_t_34 + 12] = _h_494;
      e.mem[_t_34 + 13] = _h_495;
      e.mem[_t_34 + 14] = _h_496;
      e.mem[_t_34 + 15] = _h_497;
      e.mem[_t_34 + 16] = _h_498;
      e.mem[_t_34 + 17] = _h_499;
      e.mem[_t_34 + 18] = _h_500;
      e.mem[_t_34 + 19] = _h_501;
      e.mem[_t_34 + 20] = _h_502;
      e.mem[_t_34 + 21] = _result_131;
      e.mem[_t_34 + 22] = _result_132;
      e.mem[_t_34 + 23] = _result_133;
      e.mem[_t_34 + 24] = _h_503;
      e.mem[_t_34 + 25] = _result_134;
      e.mem[_t_34 + 26] = _result_135;
      e.mem[_t_34 + 27] = _h_504;
      e.mem[_t_34 + 28] = _h_505;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K497, _t_34);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _v_0;
      e.mem[_t_35 + 1] = _h_481;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = _v_0;
    r1 = _h_481;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K497)
  {
    WL_POPN(29);
    u32 _h_508 = STK(0);
    u32 _h_509 = STK(1);
    Term _h_510 = STK(2);
    Term _h_511 = STK(3);
    Term _h_512 = STK(4);
    Term _h_513 = STK(5);
    Term _h_514 = STK(6);
    Term _h_515 = STK(7);
    u32 _h_516 = STK(8);
    Term _h_517 = STK(9);
    u32 _h_518 = STK(10);
    Term _h_519 = STK(11);
    u32 _h_520 = STK(12);
    Term _h_521 = STK(13);
    u32 _h_522 = STK(14);
    u32 _h_523 = STK(15);
    u32 _h_524 = STK(16);
    u32 _h_525 = STK(17);
    u32 _h_526 = STK(18);
    u32 _h_527 = STK(19);
    u32 _h_528 = STK(20);
    u32 _result_136 = STK(21);
    u32 _result_137 = STK(22);
    Term _result_138 = STK(23);
    Term _h_529 = STK(24);
    Term _result_139 = STK(25);
    Term _result_140 = STK(26);
    Term _h_530 = STK(27);
    Term _h_531 = STK(28);
    Term _h_507 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_508;
      STK(1) = _h_509;
      STK(2) = _h_510;
      STK(3) = _h_511;
      STK(4) = _h_512;
      STK(5) = _h_513;
      STK(6) = _h_514;
      STK(7) = _h_515;
      STK(8) = _h_516;
      STK(9) = _h_517;
      STK(10) = _h_518;
      STK(11) = _h_519;
      STK(12) = _h_520;
      STK(13) = _h_521;
      STK(14) = _h_522;
      STK(15) = _h_523;
      STK(16) = _h_524;
      STK(17) = _h_525;
      STK(18) = _h_526;
      STK(19) = _h_527;
      STK(20) = _h_528;
      STK(21) = _result_136;
      STK(22) = _result_137;
      STK(23) = _result_138;
      STK(24) = _h_529;
      STK(25) = _result_139;
      STK(26) = _result_140;
      STK(27) = _h_530;
      STK(28) = _h_531;
      STK(29) = FID_HEALTH_PRE_K498;
      WL_PUSHN(30);
    } else {
      u64 _t_36 = task_node(e, FID_HEALTH_PRE_K498, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _h_508;
      e.mem[_t_36 + 1] = _h_509;
      e.mem[_t_36 + 2] = _h_510;
      e.mem[_t_36 + 3] = _h_511;
      e.mem[_t_36 + 4] = _h_512;
      e.mem[_t_36 + 5] = _h_513;
      e.mem[_t_36 + 6] = _h_514;
      e.mem[_t_36 + 7] = _h_515;
      e.mem[_t_36 + 8] = _h_516;
      e.mem[_t_36 + 9] = _h_517;
      e.mem[_t_36 + 10] = _h_518;
      e.mem[_t_36 + 11] = _h_519;
      e.mem[_t_36 + 12] = _h_520;
      e.mem[_t_36 + 13] = _h_521;
      e.mem[_t_36 + 14] = _h_522;
      e.mem[_t_36 + 15] = _h_523;
      e.mem[_t_36 + 16] = _h_524;
      e.mem[_t_36 + 17] = _h_525;
      e.mem[_t_36 + 18] = _h_526;
      e.mem[_t_36 + 19] = _h_527;
      e.mem[_t_36 + 20] = _h_528;
      e.mem[_t_36 + 21] = _result_136;
      e.mem[_t_36 + 22] = _result_137;
      e.mem[_t_36 + 23] = _result_138;
      e.mem[_t_36 + 24] = _h_529;
      e.mem[_t_36 + 25] = _result_139;
      e.mem[_t_36 + 26] = _result_140;
      e.mem[_t_36 + 27] = _h_530;
      e.mem[_t_36 + 28] = _h_531;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K498, _t_36);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 508);
      e.mem[_t_37 + 1] = _h_507;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 508);
    r1 = _h_507;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K498)
  {
    WL_POPN(29);
    u32 _h_533 = STK(0);
    u32 _h_534 = STK(1);
    Term _h_535 = STK(2);
    Term _h_536 = STK(3);
    Term _h_537 = STK(4);
    Term _h_538 = STK(5);
    Term _h_539 = STK(6);
    Term _h_540 = STK(7);
    u32 _h_541 = STK(8);
    Term _h_542 = STK(9);
    u32 _h_543 = STK(10);
    Term _h_544 = STK(11);
    u32 _h_545 = STK(12);
    Term _h_546 = STK(13);
    u32 _h_547 = STK(14);
    u32 _h_548 = STK(15);
    u32 _h_549 = STK(16);
    u32 _h_550 = STK(17);
    u32 _h_551 = STK(18);
    u32 _h_552 = STK(19);
    u32 _h_553 = STK(20);
    u32 _result_141 = STK(21);
    u32 _result_142 = STK(22);
    Term _result_143 = STK(23);
    Term _h_554 = STK(24);
    Term _result_144 = STK(25);
    Term _result_145 = STK(26);
    Term _h_555 = STK(27);
    Term _h_556 = STK(28);
    Term _h_532 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_533;
      STK(1) = _h_534;
      STK(2) = _h_535;
      STK(3) = _h_536;
      STK(4) = _h_537;
      STK(5) = _h_538;
      STK(6) = _h_539;
      STK(7) = _h_540;
      STK(8) = _h_541;
      STK(9) = _h_542;
      STK(10) = _h_543;
      STK(11) = _h_544;
      STK(12) = _h_545;
      STK(13) = _h_546;
      STK(14) = _h_547;
      STK(15) = _h_548;
      STK(16) = _h_549;
      STK(17) = _h_550;
      STK(18) = _h_551;
      STK(19) = _h_552;
      STK(20) = _h_553;
      STK(21) = _result_141;
      STK(22) = _result_142;
      STK(23) = _result_143;
      STK(24) = _h_554;
      STK(25) = _result_144;
      STK(26) = _result_145;
      STK(27) = _h_555;
      STK(28) = FID_HEALTH_PRE_K499;
      WL_PUSHN(29);
    } else {
      u64 _t_38 = task_node(e, FID_HEALTH_PRE_K499, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _h_533;
      e.mem[_t_38 + 1] = _h_534;
      e.mem[_t_38 + 2] = _h_535;
      e.mem[_t_38 + 3] = _h_536;
      e.mem[_t_38 + 4] = _h_537;
      e.mem[_t_38 + 5] = _h_538;
      e.mem[_t_38 + 6] = _h_539;
      e.mem[_t_38 + 7] = _h_540;
      e.mem[_t_38 + 8] = _h_541;
      e.mem[_t_38 + 9] = _h_542;
      e.mem[_t_38 + 10] = _h_543;
      e.mem[_t_38 + 11] = _h_544;
      e.mem[_t_38 + 12] = _h_545;
      e.mem[_t_38 + 13] = _h_546;
      e.mem[_t_38 + 14] = _h_547;
      e.mem[_t_38 + 15] = _h_548;
      e.mem[_t_38 + 16] = _h_549;
      e.mem[_t_38 + 17] = _h_550;
      e.mem[_t_38 + 18] = _h_551;
      e.mem[_t_38 + 19] = _h_552;
      e.mem[_t_38 + 20] = _h_553;
      e.mem[_t_38 + 21] = _result_141;
      e.mem[_t_38 + 22] = _result_142;
      e.mem[_t_38 + 23] = _result_143;
      e.mem[_t_38 + 24] = _h_554;
      e.mem[_t_38 + 25] = _result_144;
      e.mem[_t_38 + 26] = _result_145;
      e.mem[_t_38 + 27] = _h_555;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K499, _t_38);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_39 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _h_556;
      e.mem[_t_39 + 1] = _h_532;
      return term_tsk(FID_STRING_APPEND, _t_39);
    }
    r0 = _h_556;
    r1 = _h_532;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K499)
  {
    WL_POPN(28);
    u32 _h_558 = STK(0);
    u32 _h_559 = STK(1);
    Term _h_560 = STK(2);
    Term _h_561 = STK(3);
    Term _h_562 = STK(4);
    Term _h_563 = STK(5);
    Term _h_564 = STK(6);
    Term _h_565 = STK(7);
    u32 _h_566 = STK(8);
    Term _h_567 = STK(9);
    u32 _h_568 = STK(10);
    Term _h_569 = STK(11);
    u32 _h_570 = STK(12);
    Term _h_571 = STK(13);
    u32 _h_572 = STK(14);
    u32 _h_573 = STK(15);
    u32 _h_574 = STK(16);
    u32 _h_575 = STK(17);
    u32 _h_576 = STK(18);
    u32 _h_577 = STK(19);
    u32 _h_578 = STK(20);
    u32 _result_146 = STK(21);
    u32 _result_147 = STK(22);
    Term _result_148 = STK(23);
    Term _h_579 = STK(24);
    Term _result_149 = STK(25);
    Term _result_150 = STK(26);
    Term _h_580 = STK(27);
    Term _h_557 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_558;
      STK(1) = _h_559;
      STK(2) = _h_560;
      STK(3) = _h_561;
      STK(4) = _h_562;
      STK(5) = _h_563;
      STK(6) = _h_564;
      STK(7) = _h_565;
      STK(8) = _h_566;
      STK(9) = _h_567;
      STK(10) = _h_568;
      STK(11) = _h_569;
      STK(12) = _h_570;
      STK(13) = _h_571;
      STK(14) = _h_572;
      STK(15) = _h_573;
      STK(16) = _h_574;
      STK(17) = _h_575;
      STK(18) = _h_576;
      STK(19) = _h_577;
      STK(20) = _h_578;
      STK(21) = _result_146;
      STK(22) = _result_147;
      STK(23) = _result_148;
      STK(24) = _h_579;
      STK(25) = _result_149;
      STK(26) = _result_150;
      STK(27) = _h_580;
      STK(28) = FID_HEALTH_PRE_K500;
      WL_PUSHN(29);
    } else {
      u64 _t_40 = task_node(e, FID_HEALTH_PRE_K500, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _h_558;
      e.mem[_t_40 + 1] = _h_559;
      e.mem[_t_40 + 2] = _h_560;
      e.mem[_t_40 + 3] = _h_561;
      e.mem[_t_40 + 4] = _h_562;
      e.mem[_t_40 + 5] = _h_563;
      e.mem[_t_40 + 6] = _h_564;
      e.mem[_t_40 + 7] = _h_565;
      e.mem[_t_40 + 8] = _h_566;
      e.mem[_t_40 + 9] = _h_567;
      e.mem[_t_40 + 10] = _h_568;
      e.mem[_t_40 + 11] = _h_569;
      e.mem[_t_40 + 12] = _h_570;
      e.mem[_t_40 + 13] = _h_571;
      e.mem[_t_40 + 14] = _h_572;
      e.mem[_t_40 + 15] = _h_573;
      e.mem[_t_40 + 16] = _h_574;
      e.mem[_t_40 + 17] = _h_575;
      e.mem[_t_40 + 18] = _h_576;
      e.mem[_t_40 + 19] = _h_577;
      e.mem[_t_40 + 20] = _h_578;
      e.mem[_t_40 + 21] = _result_146;
      e.mem[_t_40 + 22] = _result_147;
      e.mem[_t_40 + 23] = _result_148;
      e.mem[_t_40 + 24] = _h_579;
      e.mem[_t_40 + 25] = _result_149;
      e.mem[_t_40 + 26] = _result_150;
      e.mem[_t_40 + 27] = _h_580;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K500, _t_40);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 524);
      e.mem[_t_41 + 1] = _h_557;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 524);
    r1 = _h_557;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K500)
  {
    WL_POPN(28);
    u32 _h_582 = STK(0);
    u32 _h_583 = STK(1);
    Term _h_584 = STK(2);
    Term _h_585 = STK(3);
    Term _h_586 = STK(4);
    Term _h_587 = STK(5);
    Term _h_588 = STK(6);
    Term _h_589 = STK(7);
    u32 _h_590 = STK(8);
    Term _h_591 = STK(9);
    u32 _h_592 = STK(10);
    Term _h_593 = STK(11);
    u32 _h_594 = STK(12);
    Term _h_595 = STK(13);
    u32 _h_596 = STK(14);
    u32 _h_597 = STK(15);
    u32 _h_598 = STK(16);
    u32 _h_599 = STK(17);
    u32 _h_600 = STK(18);
    u32 _h_601 = STK(19);
    u32 _h_602 = STK(20);
    u32 _result_151 = STK(21);
    u32 _result_152 = STK(22);
    Term _result_153 = STK(23);
    Term _h_603 = STK(24);
    Term _result_154 = STK(25);
    Term _result_155 = STK(26);
    Term _h_604 = STK(27);
    Term _h_581 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_582;
      STK(1) = _h_583;
      STK(2) = _h_584;
      STK(3) = _h_585;
      STK(4) = _h_586;
      STK(5) = _h_587;
      STK(6) = _h_588;
      STK(7) = _h_589;
      STK(8) = _h_590;
      STK(9) = _h_591;
      STK(10) = _h_592;
      STK(11) = _h_593;
      STK(12) = _h_594;
      STK(13) = _h_595;
      STK(14) = _h_596;
      STK(15) = _h_597;
      STK(16) = _h_598;
      STK(17) = _h_599;
      STK(18) = _h_600;
      STK(19) = _h_601;
      STK(20) = _h_602;
      STK(21) = _result_151;
      STK(22) = _result_152;
      STK(23) = _result_153;
      STK(24) = _h_603;
      STK(25) = _result_154;
      STK(26) = _result_155;
      STK(27) = FID_HEALTH_PRE_K501;
      WL_PUSHN(28);
    } else {
      u64 _t_42 = task_node(e, FID_HEALTH_PRE_K501, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _h_582;
      e.mem[_t_42 + 1] = _h_583;
      e.mem[_t_42 + 2] = _h_584;
      e.mem[_t_42 + 3] = _h_585;
      e.mem[_t_42 + 4] = _h_586;
      e.mem[_t_42 + 5] = _h_587;
      e.mem[_t_42 + 6] = _h_588;
      e.mem[_t_42 + 7] = _h_589;
      e.mem[_t_42 + 8] = _h_590;
      e.mem[_t_42 + 9] = _h_591;
      e.mem[_t_42 + 10] = _h_592;
      e.mem[_t_42 + 11] = _h_593;
      e.mem[_t_42 + 12] = _h_594;
      e.mem[_t_42 + 13] = _h_595;
      e.mem[_t_42 + 14] = _h_596;
      e.mem[_t_42 + 15] = _h_597;
      e.mem[_t_42 + 16] = _h_598;
      e.mem[_t_42 + 17] = _h_599;
      e.mem[_t_42 + 18] = _h_600;
      e.mem[_t_42 + 19] = _h_601;
      e.mem[_t_42 + 20] = _h_602;
      e.mem[_t_42 + 21] = _result_151;
      e.mem[_t_42 + 22] = _result_152;
      e.mem[_t_42 + 23] = _result_153;
      e.mem[_t_42 + 24] = _h_603;
      e.mem[_t_42 + 25] = _result_154;
      e.mem[_t_42 + 26] = _result_155;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K501, _t_42);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_43 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _h_604;
      e.mem[_t_43 + 1] = _h_581;
      return term_tsk(FID_STRING_APPEND, _t_43);
    }
    r0 = _h_604;
    r1 = _h_581;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K501)
  {
    WL_POPN(27);
    u32 _h_606 = STK(0);
    u32 _h_607 = STK(1);
    Term _h_608 = STK(2);
    Term _h_609 = STK(3);
    Term _h_610 = STK(4);
    Term _h_611 = STK(5);
    Term _h_612 = STK(6);
    Term _h_613 = STK(7);
    u32 _h_614 = STK(8);
    Term _h_615 = STK(9);
    u32 _h_616 = STK(10);
    Term _h_617 = STK(11);
    u32 _h_618 = STK(12);
    Term _h_619 = STK(13);
    u32 _h_620 = STK(14);
    u32 _h_621 = STK(15);
    u32 _h_622 = STK(16);
    u32 _h_623 = STK(17);
    u32 _h_624 = STK(18);
    u32 _h_625 = STK(19);
    u32 _h_626 = STK(20);
    u32 _result_156 = STK(21);
    u32 _result_157 = STK(22);
    Term _result_158 = STK(23);
    Term _h_627 = STK(24);
    Term _result_159 = STK(25);
    Term _result_160 = STK(26);
    Term _h_605 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_606;
      STK(1) = _h_607;
      STK(2) = _h_608;
      STK(3) = _h_609;
      STK(4) = _h_610;
      STK(5) = _h_611;
      STK(6) = _h_612;
      STK(7) = _h_613;
      STK(8) = _h_614;
      STK(9) = _h_615;
      STK(10) = _h_616;
      STK(11) = _h_617;
      STK(12) = _h_618;
      STK(13) = _h_619;
      STK(14) = _h_620;
      STK(15) = _h_621;
      STK(16) = _h_622;
      STK(17) = _h_623;
      STK(18) = _h_624;
      STK(19) = _h_625;
      STK(20) = _h_626;
      STK(21) = _result_156;
      STK(22) = _result_157;
      STK(23) = _result_158;
      STK(24) = _h_627;
      STK(25) = _result_159;
      STK(26) = _result_160;
      STK(27) = FID_HEALTH_PRE_K502;
      WL_PUSHN(28);
    } else {
      u64 _t_44 = task_node(e, FID_HEALTH_PRE_K502, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_606;
      e.mem[_t_44 + 1] = _h_607;
      e.mem[_t_44 + 2] = _h_608;
      e.mem[_t_44 + 3] = _h_609;
      e.mem[_t_44 + 4] = _h_610;
      e.mem[_t_44 + 5] = _h_611;
      e.mem[_t_44 + 6] = _h_612;
      e.mem[_t_44 + 7] = _h_613;
      e.mem[_t_44 + 8] = _h_614;
      e.mem[_t_44 + 9] = _h_615;
      e.mem[_t_44 + 10] = _h_616;
      e.mem[_t_44 + 11] = _h_617;
      e.mem[_t_44 + 12] = _h_618;
      e.mem[_t_44 + 13] = _h_619;
      e.mem[_t_44 + 14] = _h_620;
      e.mem[_t_44 + 15] = _h_621;
      e.mem[_t_44 + 16] = _h_622;
      e.mem[_t_44 + 17] = _h_623;
      e.mem[_t_44 + 18] = _h_624;
      e.mem[_t_44 + 19] = _h_625;
      e.mem[_t_44 + 20] = _h_626;
      e.mem[_t_44 + 21] = _result_156;
      e.mem[_t_44 + 22] = _result_157;
      e.mem[_t_44 + 23] = _result_158;
      e.mem[_t_44 + 24] = _h_627;
      e.mem[_t_44 + 25] = _result_159;
      e.mem[_t_44 + 26] = _result_160;
      WL_CONT = term_tsk(FID_HEALTH_PRE_K502, _t_44);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_45 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 564);
      e.mem[_t_45 + 1] = _h_605;
      return term_tsk(FID_STRING_APPEND, _t_45);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 564);
    r1 = _h_605;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_K502)
  {
    WL_POPN(27);
    u32 _h_629 = STK(0);
    u32 _h_630 = STK(1);
    Term _h_631 = STK(2);
    Term _h_632 = STK(3);
    Term _h_633 = STK(4);
    Term _h_634 = STK(5);
    Term _h_635 = STK(6);
    Term _h_636 = STK(7);
    u32 _h_637 = STK(8);
    Term _h_638 = STK(9);
    u32 _h_639 = STK(10);
    Term _h_640 = STK(11);
    u32 _h_641 = STK(12);
    Term _h_642 = STK(13);
    u32 _h_643 = STK(14);
    u32 _h_644 = STK(15);
    u32 _h_645 = STK(16);
    u32 _h_646 = STK(17);
    u32 _h_647 = STK(18);
    u32 _h_648 = STK(19);
    u32 _h_649 = STK(20);
    u32 _result_161 = STK(21);
    u32 _result_162 = STK(22);
    Term _result_163 = STK(23);
    Term _h_650 = STK(24);
    Term _result_164 = STK(25);
    Term _result_165 = STK(26);
    Term _h_628 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(28));
    e.mem[_nd_0 + 0] = _h_629;
    e.mem[_nd_0 + 1] = _h_630;
    e.mem[_nd_0 + 2] = _h_631;
    e.mem[_nd_0 + 3] = _h_632;
    e.mem[_nd_0 + 4] = _h_633;
    e.mem[_nd_0 + 5] = _h_634;
    e.mem[_nd_0 + 6] = _h_635;
    e.mem[_nd_0 + 7] = _h_636;
    e.mem[_nd_0 + 8] = _h_637;
    e.mem[_nd_0 + 9] = _h_638;
    e.mem[_nd_0 + 10] = _h_639;
    e.mem[_nd_0 + 11] = _h_640;
    e.mem[_nd_0 + 12] = _h_641;
    e.mem[_nd_0 + 13] = _h_642;
    e.mem[_nd_0 + 14] = _h_643;
    e.mem[_nd_0 + 15] = _h_644;
    e.mem[_nd_0 + 16] = _h_645;
    e.mem[_nd_0 + 17] = _h_646;
    e.mem[_nd_0 + 18] = _h_647;
    e.mem[_nd_0 + 19] = _h_648;
    e.mem[_nd_0 + 20] = _h_649;
    e.mem[_nd_0 + 21] = _result_161;
    e.mem[_nd_0 + 22] = _result_162;
    e.mem[_nd_0 + 23] = _result_163;
    e.mem[_nd_0 + 24] = _h_650;
    e.mem[_nd_0 + 25] = _result_164;
    e.mem[_nd_0 + 26] = _result_165;
    e.mem[_nd_0 + 27] = _h_628;
    r0 = term_clo(FID_HEALTH_PRE_C503, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_C503)
  {
    u32 _h_651 = r0;
    u32 _h_652 = r1;
    Term _h_653 = r2;
    Term _h_654 = r3;
    Term _h_655 = r4;
    Term _h_656 = r5;
    Term _h_657 = r6;
    Term _h_658 = r7;
    u32 _h_659 = r8;
    Term _h_660 = r9;
    u32 _h_661 = r10;
    Term _h_662 = r11;
    u32 _h_663 = r12;
    Term _h_664 = r13;
    u32 _h_665 = r14;
    u32 _h_666 = r15;
    u32 _h_667 = r16;
    u32 _h_668 = r17;
    u32 _h_669 = r18;
    u32 _h_670 = r19;
    u32 _h_671 = r20;
    u32 _result_166 = r21;
    u32 _result_167 = r22;
    Term _result_168 = r23;
    Term _h_672 = r24;
    Term _result_169 = r25;
    Term _result_170 = r26;
    Term _h_673 = r27;
    Term _x_0 = r28;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_673;
    u64 _nd_2 = heap_alloc(e, cls_fit(27));
    e.mem[_nd_2 + 0] = _h_651;
    e.mem[_nd_2 + 1] = _h_652;
    e.mem[_nd_2 + 2] = _h_653;
    e.mem[_nd_2 + 3] = _h_654;
    e.mem[_nd_2 + 4] = _h_655;
    e.mem[_nd_2 + 5] = _h_656;
    e.mem[_nd_2 + 6] = _h_657;
    e.mem[_nd_2 + 7] = _h_658;
    e.mem[_nd_2 + 8] = _h_659;
    e.mem[_nd_2 + 9] = _h_660;
    e.mem[_nd_2 + 10] = _h_661;
    e.mem[_nd_2 + 11] = _h_662;
    e.mem[_nd_2 + 12] = _h_663;
    e.mem[_nd_2 + 13] = _h_664;
    e.mem[_nd_2 + 14] = _h_665;
    e.mem[_nd_2 + 15] = _h_666;
    e.mem[_nd_2 + 16] = _h_667;
    e.mem[_nd_2 + 17] = _h_668;
    e.mem[_nd_2 + 18] = _h_669;
    e.mem[_nd_2 + 19] = _h_670;
    e.mem[_nd_2 + 20] = _h_671;
    e.mem[_nd_2 + 21] = _result_166;
    e.mem[_nd_2 + 22] = _result_167;
    e.mem[_nd_2 + 23] = _result_168;
    e.mem[_nd_2 + 24] = _h_672;
    e.mem[_nd_2 + 25] = _result_169;
    e.mem[_nd_2 + 26] = _result_170;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_47 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_47 + 1] = term_clo(FID_HEALTH_PRE_C504, _nd_2);
      e.mem[_t_47 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_47);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_HEALTH_PRE_C504, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_C504)
  {
    u32 _h_674 = r0;
    u32 _h_675 = r1;
    Term _h_676 = r2;
    Term _h_677 = r3;
    Term _h_678 = r4;
    Term _h_679 = r5;
    Term _h_680 = r6;
    Term _h_681 = r7;
    u32 _h_682 = r8;
    Term _h_683 = r9;
    u32 _h_684 = r10;
    Term _h_685 = r11;
    u32 _h_686 = r12;
    Term _h_687 = r13;
    u32 _h_688 = r14;
    u32 _h_689 = r15;
    u32 _h_690 = r16;
    u32 _h_691 = r17;
    u32 _h_692 = r18;
    u32 _h_693 = r19;
    u32 _h_694 = r20;
    u32 _result_171 = r21;
    u32 _result_172 = r22;
    Term _result_173 = r23;
    Term _h_695 = r24;
    Term _result_174 = r25;
    Term _result_175 = r26;
    Term _x_1 = r27;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(27));
    e.mem[_nd_3 + 0] = _h_674;
    e.mem[_nd_3 + 1] = _h_675;
    e.mem[_nd_3 + 2] = _h_676;
    e.mem[_nd_3 + 3] = _h_677;
    e.mem[_nd_3 + 4] = _h_678;
    e.mem[_nd_3 + 5] = _h_679;
    e.mem[_nd_3 + 6] = _h_680;
    e.mem[_nd_3 + 7] = _h_681;
    e.mem[_nd_3 + 8] = _h_682;
    e.mem[_nd_3 + 9] = _h_683;
    e.mem[_nd_3 + 10] = _h_684;
    e.mem[_nd_3 + 11] = _h_685;
    e.mem[_nd_3 + 12] = _h_686;
    e.mem[_nd_3 + 13] = _h_687;
    e.mem[_nd_3 + 14] = _h_688;
    e.mem[_nd_3 + 15] = _h_689;
    e.mem[_nd_3 + 16] = _h_690;
    e.mem[_nd_3 + 17] = _h_691;
    e.mem[_nd_3 + 18] = _h_692;
    e.mem[_nd_3 + 19] = _h_693;
    e.mem[_nd_3 + 20] = _h_694;
    e.mem[_nd_3 + 21] = _result_171;
    e.mem[_nd_3 + 22] = _result_172;
    e.mem[_nd_3 + 23] = _result_173;
    e.mem[_nd_3 + 24] = _h_695;
    e.mem[_nd_3 + 25] = _result_174;
    e.mem[_nd_3 + 26] = _result_175;
    r0 = term_clo(FID_HEALTH_PRE_C505, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PRE_C505)
  {
    u32 _h_696 = r0;
    u32 _h_697 = r1;
    Term _h_698 = r2;
    Term _h_699 = r3;
    Term _h_700 = r4;
    Term _h_701 = r5;
    Term _h_702 = r6;
    Term _h_703 = r7;
    u32 _h_704 = r8;
    Term _h_705 = r9;
    u32 _h_706 = r10;
    Term _h_707 = r11;
    u32 _h_708 = r12;
    Term _h_709 = r13;
    u32 _h_710 = r14;
    u32 _h_711 = r15;
    u32 _h_712 = r16;
    u32 _h_713 = r17;
    u32 _h_714 = r18;
    u32 _h_715 = r19;
    u32 _h_716 = r20;
    u32 _result_176 = r21;
    u32 _result_177 = r22;
    Term _result_178 = r23;
    Term _h_717 = r24;
    Term _result_179 = r25;
    Term _result_180 = r26;
    Term _x_2 = r27;
    WL_OPEN
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_h_708 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _h_709);
      e.mem[_nd_4 + 1] = rfc_seal(e, _h_710);
      u64 _nd_5 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_5 + 0] = rfc_seal(e, _h_711);
      e.mem[_nd_5 + 1] = rfc_seal(e, _h_712);
      e.mem[_nd_5 + 2] = rfc_seal(e, _h_713);
      e.mem[_nd_5 + 3] = rfc_seal(e, _h_714);
      e.mem[_nd_5 + 4] = rfc_seal(e, _h_715);
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_TYPES_HEALTHLEDGER, _nd_4));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_5));
      _o_2 = term_ctr(CID_CACHE_CACHE, _nd_6);
    }
    Term _b_0 = 0;
    if (_h_716 == 0) {
      _b_0 = term_pak(CID_TYPES_HEALTHON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_HEALTHOFF, 0);
    }
    u64 _nd_7 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_7 + 0] = rfc_seal(e, _h_696);
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_697);
    e.mem[_nd_7 + 2] = rfc_seal(e, _h_698);
    e.mem[_nd_7 + 3] = rfc_seal(e, _h_699);
    e.mem[_nd_7 + 4] = rfc_seal(e, _h_700);
    e.mem[_nd_7 + 5] = rfc_seal(e, _h_701);
    e.mem[_nd_7 + 6] = rfc_seal(e, _h_702);
    e.mem[_nd_7 + 7] = rfc_seal(e, _h_703);
    e.mem[_nd_7 + 8] = rfc_seal(e, _h_704);
    e.mem[_nd_7 + 9] = rfc_seal(e, _h_705);
    e.mem[_nd_7 + 10] = rfc_seal(e, _h_706);
    e.mem[_nd_7 + 11] = rfc_seal(e, _h_707);
    e.mem[_nd_7 + 12] = rfc_seal(e, _o_1);
    e.mem[_nd_7 + 13] = rfc_seal(e, _o_2);
    e.mem[_nd_7 + 14] = rfc_seal(e, _b_0);
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _result_176);
    e.mem[_nd_8 + 1] = rfc_seal(e, _result_177);
    u64 _nd_9 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_WORLD, _nd_7));
    e.mem[_nd_9 + 1] = rfc_seal(e, term_ctr(CID_STORAGE_HANDLE, _nd_8));
    e.mem[_nd_9 + 2] = rfc_seal(e, _result_178);
    e.mem[_nd_9 + 3] = rfc_seal(e, _h_717);
    e.mem[_nd_9 + 4] = rfc_seal(e, _result_179);
    e.mem[_nd_9 + 5] = rfc_seal(e, _result_180);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_46 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_46 + 0] = term_ctr(CID_TRANSACTION_TX, _nd_9);
      e.mem[_t_46 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_46);
    }
    r0 = term_ctr(CID_TRANSACTION_TX, _nd_9);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR)
  {
    u32 _scenario_0 = r0;
    u32 _fail_0 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _o_18[27];
    if (spin_176(e, _o_18, _scenario_0) == 0) {
      return 0;
    }
    _v_27 = _o_18[0];
    _v_28 = _o_18[1];
    _v_29 = _o_18[2];
    _v_30 = _o_18[3];
    _v_31 = _o_18[4];
    _v_32 = _o_18[5];
    _v_33 = _o_18[6];
    _v_34 = _o_18[7];
    _v_35 = _o_18[8];
    _v_36 = _o_18[9];
    _v_37 = _o_18[10];
    _v_38 = _o_18[11];
    _v_39 = _o_18[12];
    _v_40 = _o_18[13];
    _v_41 = _o_18[14];
    _v_42 = _o_18[15];
    _v_43 = _o_18[16];
    _v_44 = _o_18[17];
    _v_45 = _o_18[18];
    _v_46 = _o_18[19];
    _v_47 = _o_18[20];
    _v_48 = _o_18[21];
    _v_49 = _o_18[22];
    _v_50 = _o_18[23];
    _v_51 = _o_18[24];
    _v_52 = _o_18[25];
    _v_53 = _o_18[26];
    _v_0 = _v_27;
    _v_1 = _v_28;
    _v_2 = _v_29;
    _v_3 = _v_30;
    _v_4 = _v_31;
    _v_5 = _v_32;
    _v_6 = _v_33;
    _v_7 = _v_34;
    _v_8 = _v_35;
    _v_9 = _v_36;
    _v_10 = _v_37;
    _v_11 = _v_38;
    _v_12 = _v_39;
    _v_13 = _v_40;
    _v_14 = _v_41;
    _v_15 = _v_42;
    _v_16 = _v_43;
    _v_17 = _v_44;
    _v_18 = _v_45;
    _v_19 = _v_46;
    _v_20 = _v_47;
    _v_21 = _v_48;
    _v_22 = _v_49;
    _v_23 = _v_50;
    _v_24 = _v_51;
    _v_25 = _v_52;
    _v_26 = _v_53;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _scenario_0;
      STK(1) = _fail_0;
      STK(2) = FID_HEALTH_PAIR_K507;
      WL_PUSHN(3);
    } else {
      u64 _t_5 = task_node(e, FID_HEALTH_PAIR_K507, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _scenario_0;
      e.mem[_t_5 + 1] = _fail_0;
      WL_CONT = term_tsk(FID_HEALTH_PAIR_K507, _t_5);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_BODY)) {
      u64 _t_6 = task_node(e, FID_HEALTH_BODY, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _v_0;
      e.mem[_t_6 + 1] = _v_1;
      e.mem[_t_6 + 2] = _v_2;
      e.mem[_t_6 + 3] = _v_3;
      e.mem[_t_6 + 4] = _v_4;
      e.mem[_t_6 + 5] = _v_5;
      e.mem[_t_6 + 6] = _v_6;
      e.mem[_t_6 + 7] = _v_7;
      e.mem[_t_6 + 8] = _v_8;
      e.mem[_t_6 + 9] = _v_9;
      e.mem[_t_6 + 10] = _v_10;
      e.mem[_t_6 + 11] = _v_11;
      e.mem[_t_6 + 12] = _v_12;
      e.mem[_t_6 + 13] = _v_13;
      e.mem[_t_6 + 14] = _v_14;
      e.mem[_t_6 + 15] = _v_15;
      e.mem[_t_6 + 16] = _v_16;
      e.mem[_t_6 + 17] = _v_17;
      e.mem[_t_6 + 18] = _v_18;
      e.mem[_t_6 + 19] = _v_19;
      e.mem[_t_6 + 20] = _v_20;
      e.mem[_t_6 + 21] = _v_21;
      e.mem[_t_6 + 22] = _v_22;
      e.mem[_t_6 + 23] = _v_23;
      e.mem[_t_6 + 24] = _v_24;
      e.mem[_t_6 + 25] = _v_25;
      e.mem[_t_6 + 26] = _v_26;
      return term_tsk(FID_HEALTH_BODY, _t_6);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    r24 = _v_24;
    r25 = _v_25;
    r26 = _v_26;
    WL_JMP(FID_HEALTH_BODY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_K507)
  {
    WL_POPN(2);
    u32 _scenario_2 = STK(0);
    u32 _fail_1 = STK(1);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    Term _h_23 = r23;
    Term _h_24 = r24;
    Term _h_25 = r25;
    Term _h_26 = r26;
    u32 _h_27 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _scenario_2;
      STK(1) = _fail_1;
      STK(2) = FID_HEALTH_PAIR_K508;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_HEALTH_PAIR_K508, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _scenario_2;
      e.mem[_t_7 + 1] = _fail_1;
      WL_CONT = term_tsk(FID_HEALTH_PAIR_K508, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_PRE)) {
      u64 _t_8 = task_node(e, FID_HEALTH_PRE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_0;
      e.mem[_t_8 + 1] = _h_1;
      e.mem[_t_8 + 2] = _h_2;
      e.mem[_t_8 + 3] = _h_3;
      e.mem[_t_8 + 4] = _h_4;
      e.mem[_t_8 + 5] = _h_5;
      e.mem[_t_8 + 6] = _h_6;
      e.mem[_t_8 + 7] = _h_7;
      e.mem[_t_8 + 8] = _h_8;
      e.mem[_t_8 + 9] = _h_9;
      e.mem[_t_8 + 10] = _h_10;
      e.mem[_t_8 + 11] = _h_11;
      e.mem[_t_8 + 12] = _h_12;
      e.mem[_t_8 + 13] = _h_13;
      e.mem[_t_8 + 14] = _h_14;
      e.mem[_t_8 + 15] = _h_15;
      e.mem[_t_8 + 16] = _h_16;
      e.mem[_t_8 + 17] = _h_17;
      e.mem[_t_8 + 18] = _h_18;
      e.mem[_t_8 + 19] = _h_19;
      e.mem[_t_8 + 20] = _h_20;
      e.mem[_t_8 + 21] = _h_21;
      e.mem[_t_8 + 22] = _h_22;
      e.mem[_t_8 + 23] = _h_23;
      e.mem[_t_8 + 24] = _h_24;
      e.mem[_t_8 + 25] = _h_25;
      e.mem[_t_8 + 26] = _h_26;
      e.mem[_t_8 + 27] = _h_27;
      return term_tsk(FID_HEALTH_PRE, _t_8);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    r18 = _h_18;
    r19 = _h_19;
    r20 = _h_20;
    r21 = _h_21;
    r22 = _h_22;
    r23 = _h_23;
    r24 = _h_24;
    r25 = _h_25;
    r26 = _h_26;
    r27 = _h_27;
    WL_JMP(FID_HEALTH_PRE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_K508)
  {
    WL_POPN(2);
    u32 _scenario_3 = STK(0);
    u32 _fail_2 = STK(1);
    Term _h_28 = r0;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_8 + 0] = _scenario_3;
    e.mem[_nd_8 + 1] = _fail_2;
    e.mem[_nd_8 + 2] = _h_28;
    r0 = term_clo(FID_HEALTH_PAIR_C509, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_C509)
  {
    u32 _scenario_4 = r0;
    u32 _fail_3 = r1;
    Term _h_29 = r2;
    Term _x_0 = r3;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = _scenario_4;
    e.mem[_nd_9 + 1] = _fail_3;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_18 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _h_29;
      e.mem[_t_18 + 1] = term_clo(FID_HEALTH_PAIR_C510, _nd_9);
      e.mem[_t_18 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_18);
    }
    r0 = _h_29;
    r1 = term_clo(FID_HEALTH_PAIR_C510, _nd_9);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_C510)
  {
    u32 _scenario_5 = r0;
    u32 _fail_4 = r1;
    Term _x_1 = r2;
    WL_OPEN
    Term _fb_0[6];
    u64 _sp_0 = ctr_take(e, _x_1, 6, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    spare_free(e, cls_fit(6), _sp_0);
    Term _fb_1[15];
    u64 _sp_1 = ctr_take(e, _f_0, 15, _fb_1);
    u32 _f_6 = _fb_1[0];
    u32 _f_7 = _fb_1[1];
    Term _f_8 = _fb_1[2];
    Term _f_9 = _fb_1[3];
    Term _f_10 = _fb_1[4];
    Term _f_11 = _fb_1[5];
    Term _f_12 = _fb_1[6];
    Term _f_13 = _fb_1[7];
    u32 _f_14 = _fb_1[8];
    Term _f_15 = _fb_1[9];
    u32 _f_16 = _fb_1[10];
    Term _f_17 = _fb_1[11];
    u32 _f_18 = _fb_1[12];
    Term _f_19 = _fb_1[13];
    Term _f_20 = _fb_1[14];
    spare_free(e, cls_fit(15), _sp_1);
    u32 _o_19 = 0;
    Term _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    u32 _o_25 = 0;
    u32 _o_26 = 0;
    if (_f_18 == 0) {
      _o_19 = 0;
    } else {
      _o_19 = 1;
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _f_19, 2, _fb_2);
      Term _f_21 = _fb_2[0];
      Term _f_22 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _f_21, 2, _fb_3);
      Term _f_23 = _fb_3[0];
      u32 _f_24 = _fb_3[1];
      spare_free(e, cls_fit(2), _sp_3);
      Term _fb_4[5];
      u64 _sp_4 = ctr_take(e, _f_22, 5, _fb_4);
      u32 _f_25 = _fb_4[0];
      u32 _f_26 = _fb_4[1];
      u32 _f_27 = _fb_4[2];
      u32 _f_28 = _fb_4[3];
      u32 _f_29 = _fb_4[4];
      spare_free(e, cls_fit(5), _sp_4);
      _o_20 = _f_23;
      _o_21 = _f_24;
      _o_22 = _f_25;
      _o_23 = _f_26;
      _o_24 = _f_27;
      _o_25 = _f_28;
      _o_26 = _f_29;
    }
    u32 _o_27 = 0;
    if (term_aux(_f_20) == CID_TYPES_HEALTHON) {
      _o_27 = 0;
    } else {
      _o_27 = 1;
    }
    Term _fb_5[2];
    u64 _sp_5 = ctr_take(e, _f_1, 2, _fb_5);
    u32 _f_30 = _fb_5[0];
    u32 _f_31 = _fb_5[1];
    spare_free(e, cls_fit(2), _sp_5);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _scenario_5;
      STK(1) = _fail_4;
      STK(2) = FID_HEALTH_PAIR_K511;
      WL_PUSHN(3);
    } else {
      u64 _t_9 = task_node(e, FID_HEALTH_PAIR_K511, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _scenario_5;
      e.mem[_t_9 + 1] = _fail_4;
      WL_CONT = term_tsk(FID_HEALTH_PAIR_K511, _t_9);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_FINISH)) {
      u64 _t_10 = task_node(e, FID_HEALTH_FINISH, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _fail_4;
      e.mem[_t_10 + 1] = _f_6;
      e.mem[_t_10 + 2] = _f_7;
      e.mem[_t_10 + 3] = _f_8;
      e.mem[_t_10 + 4] = _f_9;
      e.mem[_t_10 + 5] = _f_10;
      e.mem[_t_10 + 6] = _f_11;
      e.mem[_t_10 + 7] = _f_12;
      e.mem[_t_10 + 8] = _f_13;
      e.mem[_t_10 + 9] = _f_14;
      e.mem[_t_10 + 10] = _f_15;
      e.mem[_t_10 + 11] = _f_16;
      e.mem[_t_10 + 12] = _f_17;
      e.mem[_t_10 + 13] = _o_19;
      e.mem[_t_10 + 14] = _o_20;
      e.mem[_t_10 + 15] = _o_21;
      e.mem[_t_10 + 16] = _o_22;
      e.mem[_t_10 + 17] = _o_23;
      e.mem[_t_10 + 18] = _o_24;
      e.mem[_t_10 + 19] = _o_25;
      e.mem[_t_10 + 20] = _o_26;
      e.mem[_t_10 + 21] = _o_27;
      e.mem[_t_10 + 22] = _f_30;
      e.mem[_t_10 + 23] = _f_31;
      e.mem[_t_10 + 24] = _f_2;
      e.mem[_t_10 + 25] = _f_3;
      e.mem[_t_10 + 26] = _f_4;
      e.mem[_t_10 + 27] = _f_5;
      return term_tsk(FID_HEALTH_FINISH, _t_10);
    }
    r0 = _fail_4;
    r1 = _f_6;
    r2 = _f_7;
    r3 = _f_8;
    r4 = _f_9;
    r5 = _f_10;
    r6 = _f_11;
    r7 = _f_12;
    r8 = _f_13;
    r9 = _f_14;
    r10 = _f_15;
    r11 = _f_16;
    r12 = _f_17;
    r13 = _o_19;
    r14 = _o_20;
    r15 = _o_21;
    r16 = _o_22;
    r17 = _o_23;
    r18 = _o_24;
    r19 = _o_25;
    r20 = _o_26;
    r21 = _o_27;
    r22 = _f_30;
    r23 = _f_31;
    r24 = _f_2;
    r25 = _f_3;
    r26 = _f_4;
    r27 = _f_5;
    WL_JMP(FID_HEALTH_FINISH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_K511)
  {
    WL_POPN(2);
    u32 _scenario_6 = STK(0);
    u32 _fail_5 = STK(1);
    Term _h_30 = r0;
    WL_OPEN
    u64 _nd_10 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_10 + 0] = _scenario_6;
    e.mem[_nd_10 + 1] = _fail_5;
    e.mem[_nd_10 + 2] = _h_30;
    r0 = term_clo(FID_HEALTH_PAIR_C512, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_C512)
  {
    u32 _scenario_7 = r0;
    u32 _fail_6 = r1;
    Term _h_31 = r2;
    Term _x_2 = r3;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = _scenario_7;
    e.mem[_nd_11 + 1] = _fail_6;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_17 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_31;
      e.mem[_t_17 + 1] = term_clo(FID_HEALTH_PAIR_C513, _nd_11);
      e.mem[_t_17 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_17);
    }
    r0 = _h_31;
    r1 = term_clo(FID_HEALTH_PAIR_C513, _nd_11);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_C513)
  {
    u32 _scenario_8 = r0;
    u32 _fail_7 = r1;
    Term _x_3 = r2;
    WL_OPEN
    u32 _v_143 = 0;
    u32 _v_144 = 0;
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    Term _v_148 = 0;
    Term _v_149 = 0;
    Term _v_150 = 0;
    u32 _v_151 = 0;
    Term _v_152 = 0;
    u32 _v_153 = 0;
    Term _v_154 = 0;
    u32 _v_155 = 0;
    Term _v_156 = 0;
    u32 _v_157 = 0;
    u32 _v_158 = 0;
    u32 _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    u32 _v_165 = 0;
    Term _v_166 = 0;
    Term _v_167 = 0;
    Term _v_168 = 0;
    Term _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    Term _v_172 = 0;
    Term _v_173 = 0;
    Term _v_174 = 0;
    Term _v_175 = 0;
    Term _v_176 = 0;
    Term _v_177 = 0;
    u32 _v_178 = 0;
    Term _v_179 = 0;
    u32 _v_180 = 0;
    Term _v_181 = 0;
    u32 _v_182 = 0;
    Term _v_183 = 0;
    u32 _v_184 = 0;
    u32 _v_185 = 0;
    u32 _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    u32 _v_189 = 0;
    u32 _v_190 = 0;
    u32 _v_191 = 0;
    u32 _v_192 = 0;
    Term _v_193 = 0;
    Term _v_194 = 0;
    Term _v_195 = 0;
    Term _v_196 = 0;
    Term _o_28[27];
    if (spin_176(e, _o_28, _scenario_8) == 0) {
      return 0;
    }
    _v_170 = _o_28[0];
    _v_171 = _o_28[1];
    _v_172 = _o_28[2];
    _v_173 = _o_28[3];
    _v_174 = _o_28[4];
    _v_175 = _o_28[5];
    _v_176 = _o_28[6];
    _v_177 = _o_28[7];
    _v_178 = _o_28[8];
    _v_179 = _o_28[9];
    _v_180 = _o_28[10];
    _v_181 = _o_28[11];
    _v_182 = _o_28[12];
    _v_183 = _o_28[13];
    _v_184 = _o_28[14];
    _v_185 = _o_28[15];
    _v_186 = _o_28[16];
    _v_187 = _o_28[17];
    _v_188 = _o_28[18];
    _v_189 = _o_28[19];
    _v_190 = _o_28[20];
    _v_191 = _o_28[21];
    _v_192 = _o_28[22];
    _v_193 = _o_28[23];
    _v_194 = _o_28[24];
    _v_195 = _o_28[25];
    _v_196 = _o_28[26];
    _v_143 = _v_170;
    _v_144 = _v_171;
    _v_145 = _v_172;
    _v_146 = _v_173;
    _v_147 = _v_174;
    _v_148 = _v_175;
    _v_149 = _v_176;
    _v_150 = _v_177;
    _v_151 = _v_178;
    _v_152 = _v_179;
    _v_153 = _v_180;
    _v_154 = _v_181;
    _v_155 = _v_182;
    _v_156 = _v_183;
    _v_157 = _v_184;
    _v_158 = _v_185;
    _v_159 = _v_186;
    _v_160 = _v_187;
    _v_161 = _v_188;
    _v_162 = _v_189;
    _v_163 = _v_190;
    _v_164 = _v_191;
    _v_165 = _v_192;
    _v_166 = _v_193;
    _v_167 = _v_194;
    _v_168 = _v_195;
    _v_169 = _v_196;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _fail_7;
      STK(1) = FID_HEALTH_PAIR_K514;
      WL_PUSHN(2);
    } else {
      u64 _t_11 = task_node(e, FID_HEALTH_PAIR_K514, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _fail_7;
      WL_CONT = term_tsk(FID_HEALTH_PAIR_K514, _t_11);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HELD_ADAPTER_HEALTH_ROW_0)) {
      u64 _t_12 = task_node(e, FID_HELD_ADAPTER_HEALTH_ROW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _v_143;
      e.mem[_t_12 + 1] = _v_144;
      e.mem[_t_12 + 2] = _v_145;
      e.mem[_t_12 + 3] = _v_146;
      e.mem[_t_12 + 4] = _v_147;
      e.mem[_t_12 + 5] = _v_148;
      e.mem[_t_12 + 6] = _v_149;
      e.mem[_t_12 + 7] = _v_150;
      e.mem[_t_12 + 8] = _v_151;
      e.mem[_t_12 + 9] = _v_152;
      e.mem[_t_12 + 10] = _v_153;
      e.mem[_t_12 + 11] = _v_154;
      e.mem[_t_12 + 12] = _v_155;
      e.mem[_t_12 + 13] = _v_156;
      e.mem[_t_12 + 14] = _v_157;
      e.mem[_t_12 + 15] = _v_158;
      e.mem[_t_12 + 16] = _v_159;
      e.mem[_t_12 + 17] = _v_160;
      e.mem[_t_12 + 18] = _v_161;
      e.mem[_t_12 + 19] = _v_162;
      e.mem[_t_12 + 20] = _v_163;
      e.mem[_t_12 + 21] = _v_164;
      e.mem[_t_12 + 22] = _v_165;
      e.mem[_t_12 + 23] = _v_166;
      e.mem[_t_12 + 24] = _v_167;
      e.mem[_t_12 + 25] = _v_168;
      e.mem[_t_12 + 26] = _v_169;
      return term_tsk(FID_HELD_ADAPTER_HEALTH_ROW_0, _t_12);
    }
    r0 = _v_143;
    r1 = _v_144;
    r2 = _v_145;
    r3 = _v_146;
    r4 = _v_147;
    r5 = _v_148;
    r6 = _v_149;
    r7 = _v_150;
    r8 = _v_151;
    r9 = _v_152;
    r10 = _v_153;
    r11 = _v_154;
    r12 = _v_155;
    r13 = _v_156;
    r14 = _v_157;
    r15 = _v_158;
    r16 = _v_159;
    r17 = _v_160;
    r18 = _v_161;
    r19 = _v_162;
    r20 = _v_163;
    r21 = _v_164;
    r22 = _v_165;
    r23 = _v_166;
    r24 = _v_167;
    r25 = _v_168;
    r26 = _v_169;
    WL_JMP(FID_HELD_ADAPTER_HEALTH_ROW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_K514)
  {
    WL_POPN(1);
    u32 _fail_8 = STK(0);
    u32 _h_32 = r0;
    u32 _h_33 = r1;
    Term _h_34 = r2;
    Term _h_35 = r3;
    Term _h_36 = r4;
    Term _h_37 = r5;
    Term _h_38 = r6;
    Term _h_39 = r7;
    u32 _h_40 = r8;
    Term _h_41 = r9;
    u32 _h_42 = r10;
    Term _h_43 = r11;
    u32 _h_44 = r12;
    Term _h_45 = r13;
    u32 _h_46 = r14;
    u32 _h_47 = r15;
    u32 _h_48 = r16;
    u32 _h_49 = r17;
    u32 _h_50 = r18;
    u32 _h_51 = r19;
    u32 _h_52 = r20;
    u32 _h_53 = r21;
    u32 _h_54 = r22;
    Term _h_55 = r23;
    Term _h_56 = r24;
    Term _h_57 = r25;
    Term _h_58 = r26;
    u32 _h_59 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _fail_8;
      STK(1) = FID_HEALTH_PAIR_K515;
      WL_PUSHN(2);
    } else {
      u64 _t_13 = task_node(e, FID_HEALTH_PAIR_K515, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _fail_8;
      WL_CONT = term_tsk(FID_HEALTH_PAIR_K515, _t_13);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_PRE)) {
      u64 _t_14 = task_node(e, FID_HEALTH_PRE, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_32;
      e.mem[_t_14 + 1] = _h_33;
      e.mem[_t_14 + 2] = _h_34;
      e.mem[_t_14 + 3] = _h_35;
      e.mem[_t_14 + 4] = _h_36;
      e.mem[_t_14 + 5] = _h_37;
      e.mem[_t_14 + 6] = _h_38;
      e.mem[_t_14 + 7] = _h_39;
      e.mem[_t_14 + 8] = _h_40;
      e.mem[_t_14 + 9] = _h_41;
      e.mem[_t_14 + 10] = _h_42;
      e.mem[_t_14 + 11] = _h_43;
      e.mem[_t_14 + 12] = _h_44;
      e.mem[_t_14 + 13] = _h_45;
      e.mem[_t_14 + 14] = _h_46;
      e.mem[_t_14 + 15] = _h_47;
      e.mem[_t_14 + 16] = _h_48;
      e.mem[_t_14 + 17] = _h_49;
      e.mem[_t_14 + 18] = _h_50;
      e.mem[_t_14 + 19] = _h_51;
      e.mem[_t_14 + 20] = _h_52;
      e.mem[_t_14 + 21] = _h_53;
      e.mem[_t_14 + 22] = _h_54;
      e.mem[_t_14 + 23] = _h_55;
      e.mem[_t_14 + 24] = _h_56;
      e.mem[_t_14 + 25] = _h_57;
      e.mem[_t_14 + 26] = _h_58;
      e.mem[_t_14 + 27] = _h_59;
      return term_tsk(FID_HEALTH_PRE, _t_14);
    }
    r0 = _h_32;
    r1 = _h_33;
    r2 = _h_34;
    r3 = _h_35;
    r4 = _h_36;
    r5 = _h_37;
    r6 = _h_38;
    r7 = _h_39;
    r8 = _h_40;
    r9 = _h_41;
    r10 = _h_42;
    r11 = _h_43;
    r12 = _h_44;
    r13 = _h_45;
    r14 = _h_46;
    r15 = _h_47;
    r16 = _h_48;
    r17 = _h_49;
    r18 = _h_50;
    r19 = _h_51;
    r20 = _h_52;
    r21 = _h_53;
    r22 = _h_54;
    r23 = _h_55;
    r24 = _h_56;
    r25 = _h_57;
    r26 = _h_58;
    r27 = _h_59;
    WL_JMP(FID_HEALTH_PRE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_K515)
  {
    WL_POPN(1);
    u32 _fail_9 = STK(0);
    Term _h_60 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_12 + 0] = _fail_9;
    e.mem[_nd_12 + 1] = _h_60;
    r0 = term_clo(FID_HEALTH_PAIR_C516, _nd_12);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_C516)
  {
    u32 _fail_10 = r0;
    Term _h_61 = r1;
    Term _x_4 = r2;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_13 + 0] = _fail_10;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_16 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = _h_61;
      e.mem[_t_16 + 1] = term_clo(FID_HEALTH_PAIR_C517, _nd_13);
      e.mem[_t_16 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_16);
    }
    r0 = _h_61;
    r1 = term_clo(FID_HEALTH_PAIR_C517, _nd_13);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_PAIR_C517)
  {
    u32 _fail_11 = r0;
    Term _x_5 = r1;
    WL_OPEN
    Term _fb_6[6];
    u64 _sp_6 = ctr_take(e, _x_5, 6, _fb_6);
    Term _f_32 = _fb_6[0];
    Term _f_33 = _fb_6[1];
    Term _f_34 = _fb_6[2];
    Term _f_35 = _fb_6[3];
    Term _f_36 = _fb_6[4];
    Term _f_37 = _fb_6[5];
    spare_free(e, cls_fit(6), _sp_6);
    Term _fb_7[15];
    u64 _sp_7 = ctr_take(e, _f_32, 15, _fb_7);
    u32 _f_38 = _fb_7[0];
    u32 _f_39 = _fb_7[1];
    Term _f_40 = _fb_7[2];
    Term _f_41 = _fb_7[3];
    Term _f_42 = _fb_7[4];
    Term _f_43 = _fb_7[5];
    Term _f_44 = _fb_7[6];
    Term _f_45 = _fb_7[7];
    u32 _f_46 = _fb_7[8];
    Term _f_47 = _fb_7[9];
    u32 _f_48 = _fb_7[10];
    Term _f_49 = _fb_7[11];
    u32 _f_50 = _fb_7[12];
    Term _f_51 = _fb_7[13];
    Term _f_52 = _fb_7[14];
    spare_free(e, cls_fit(15), _sp_7);
    u32 _o_29 = 0;
    Term _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    u32 _o_34 = 0;
    u32 _o_35 = 0;
    u32 _o_36 = 0;
    if (_f_50 == 0) {
      _o_29 = 0;
    } else {
      _o_29 = 1;
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _f_51, 2, _fb_8);
      Term _f_53 = _fb_8[0];
      Term _f_54 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      Term _fb_9[2];
      u64 _sp_9 = ctr_take(e, _f_53, 2, _fb_9);
      Term _f_55 = _fb_9[0];
      u32 _f_56 = _fb_9[1];
      spare_free(e, cls_fit(2), _sp_9);
      Term _fb_10[5];
      u64 _sp_10 = ctr_take(e, _f_54, 5, _fb_10);
      u32 _f_57 = _fb_10[0];
      u32 _f_58 = _fb_10[1];
      u32 _f_59 = _fb_10[2];
      u32 _f_60 = _fb_10[3];
      u32 _f_61 = _fb_10[4];
      spare_free(e, cls_fit(5), _sp_10);
      _o_30 = _f_55;
      _o_31 = _f_56;
      _o_32 = _f_57;
      _o_33 = _f_58;
      _o_34 = _f_59;
      _o_35 = _f_60;
      _o_36 = _f_61;
    }
    u32 _o_37 = 0;
    if (term_aux(_f_52) == CID_TYPES_HEALTHON) {
      _o_37 = 0;
    } else {
      _o_37 = 1;
    }
    Term _fb_11[2];
    u64 _sp_11 = ctr_take(e, _f_33, 2, _fb_11);
    u32 _f_62 = _fb_11[0];
    u32 _f_63 = _fb_11[1];
    spare_free(e, cls_fit(2), _sp_11);
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_FINISH)) {
      u64 _t_15 = task_node(e, FID_HEALTH_FINISH, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _fail_11;
      e.mem[_t_15 + 1] = _f_38;
      e.mem[_t_15 + 2] = _f_39;
      e.mem[_t_15 + 3] = _f_40;
      e.mem[_t_15 + 4] = _f_41;
      e.mem[_t_15 + 5] = _f_42;
      e.mem[_t_15 + 6] = _f_43;
      e.mem[_t_15 + 7] = _f_44;
      e.mem[_t_15 + 8] = _f_45;
      e.mem[_t_15 + 9] = _f_46;
      e.mem[_t_15 + 10] = _f_47;
      e.mem[_t_15 + 11] = _f_48;
      e.mem[_t_15 + 12] = _f_49;
      e.mem[_t_15 + 13] = _o_29;
      e.mem[_t_15 + 14] = _o_30;
      e.mem[_t_15 + 15] = _o_31;
      e.mem[_t_15 + 16] = _o_32;
      e.mem[_t_15 + 17] = _o_33;
      e.mem[_t_15 + 18] = _o_34;
      e.mem[_t_15 + 19] = _o_35;
      e.mem[_t_15 + 20] = _o_36;
      e.mem[_t_15 + 21] = _o_37;
      e.mem[_t_15 + 22] = _f_62;
      e.mem[_t_15 + 23] = _f_63;
      e.mem[_t_15 + 24] = _f_34;
      e.mem[_t_15 + 25] = _f_35;
      e.mem[_t_15 + 26] = _f_36;
      e.mem[_t_15 + 27] = _f_37;
      return term_tsk(FID_HEALTH_FINISH, _t_15);
    }
    r0 = _fail_11;
    r1 = _f_38;
    r2 = _f_39;
    r3 = _f_40;
    r4 = _f_41;
    r5 = _f_42;
    r6 = _f_43;
    r7 = _f_44;
    r8 = _f_45;
    r9 = _f_46;
    r10 = _f_47;
    r11 = _f_48;
    r12 = _f_49;
    r13 = _o_29;
    r14 = _o_30;
    r15 = _o_31;
    r16 = _o_32;
    r17 = _o_33;
    r18 = _o_34;
    r19 = _o_35;
    r20 = _o_36;
    r21 = _o_37;
    r22 = _f_62;
    r23 = _f_63;
    r24 = _f_34;
    r25 = _f_35;
    r26 = _f_36;
    r27 = _f_37;
    WL_JMP(FID_HEALTH_FINISH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C519, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C519, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C519)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K520;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K520, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K520, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K520)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PURE)
  {
    Term _x_0 = r0;
    Term _k_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _k_0;
      e.mem[_t_0 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_0);
    }
    r0 = _k_0;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES)
  {
    Term _remaining_0 = r0;
    u32 _scenario_0 = r1;
    WL_OPEN
    if (_remaining_0 == 0) {
      r0 = term_clo(FID_CASES_C523, 0);
      WL_RETN(1);
    } else {
      Term _rest_0 = (_remaining_0 - 1);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _rest_0;
        STK(1) = _scenario_0;
        STK(2) = FID_CASES_K524;
        WL_PUSHN(3);
      } else {
        u64 _t_1 = task_node(e, FID_CASES_K524, WL_CONT, WL_IDX, 1);
        e.mem[_t_1 + 0] = _rest_0;
        e.mem[_t_1 + 1] = _scenario_0;
        WL_CONT = term_tsk(FID_CASES_K524, _t_1);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_HEALTH_PAIR)) {
        u64 _t_2 = task_node(e, FID_HEALTH_PAIR, WL_CONT, WL_IDX, 0);
        e.mem[_t_2 + 0] = _scenario_0;
        e.mem[_t_2 + 1] = 0;
        return term_tsk(FID_HEALTH_PAIR, _t_2);
      }
      r0 = _scenario_0;
      r1 = 0;
      WL_JMP(FID_HEALTH_PAIR);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_C523)
  {
    Term _x_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_0 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = term_pak(CID_UNIT, 0);
      e.mem[_t_0 + 1] = _x_0;
      return term_tsk(FID_IO_PURE, _t_0);
    }
    r0 = term_pak(CID_UNIT, 0);
    r1 = _x_0;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_K524)
  {
    WL_POPN(2);
    Term _rest_1 = STK(0);
    u32 _scenario_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = _rest_1;
    e.mem[_nd_0 + 1] = _scenario_1;
    e.mem[_nd_0 + 2] = _h_0;
    r0 = term_clo(FID_CASES_C525, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_C525)
  {
    Term _rest_2 = r0;
    u32 _scenario_2 = r1;
    Term _h_1 = r2;
    Term _x_1 = r3;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _rest_2;
    e.mem[_nd_1 + 1] = _scenario_2;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_7 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_1;
      e.mem[_t_7 + 1] = term_clo(FID_CASES_C526, _nd_1);
      e.mem[_t_7 + 2] = _x_1;
      return term_tsk(FID_IO_BIND, _t_7);
    }
    r0 = _h_1;
    r1 = term_clo(FID_CASES_C526, _nd_1);
    r2 = _x_1;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_C526)
  {
    Term _rest_3 = r0;
    u32 _scenario_3 = r1;
    Term _x_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _rest_3;
      STK(1) = _scenario_3;
      STK(2) = FID_CASES_K527;
      WL_PUSHN(3);
    } else {
      u64 _t_3 = task_node(e, FID_CASES_K527, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _rest_3;
      e.mem[_t_3 + 1] = _scenario_3;
      WL_CONT = term_tsk(FID_CASES_K527, _t_3);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_PAIR)) {
      u64 _t_4 = task_node(e, FID_HEALTH_PAIR, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _scenario_3;
      e.mem[_t_4 + 1] = 1;
      return term_tsk(FID_HEALTH_PAIR, _t_4);
    }
    r0 = _scenario_3;
    r1 = 1;
    WL_JMP(FID_HEALTH_PAIR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_K527)
  {
    WL_POPN(2);
    Term _rest_4 = STK(0);
    u32 _scenario_4 = STK(1);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = _rest_4;
    e.mem[_nd_2 + 1] = _scenario_4;
    e.mem[_nd_2 + 2] = _h_2;
    r0 = term_clo(FID_CASES_C528, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_C528)
  {
    Term _rest_5 = r0;
    u32 _scenario_5 = r1;
    Term _h_3 = r2;
    Term _x_3 = r3;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = _rest_5;
    e.mem[_nd_3 + 1] = _scenario_5;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_6 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_3;
      e.mem[_t_6 + 1] = term_clo(FID_CASES_C529, _nd_3);
      e.mem[_t_6 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_6);
    }
    r0 = _h_3;
    r1 = term_clo(FID_CASES_C529, _nd_3);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CASES_C529)
  {
    Term _rest_6 = r0;
    u32 _scenario_6 = r1;
    Term _x_4 = r2;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CASES)) {
      u64 _t_5 = task_node(e, FID_CASES, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rest_6;
      e.mem[_t_5 + 1] = U32_BIN(_scenario_6, +, 1ull);
      return term_tsk(FID_CASES, _t_5);
    }
    r0 = _rest_6;
    r1 = U32_BIN(_scenario_6, +, 1ull);
    WL_JMP(FID_CASES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CASES)) {
      u64 _t_0 = task_node(e, FID_CASES, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = 9ull;
      e.mem[_t_0 + 1] = 0ull;
      return term_tsk(FID_CASES, _t_0);
    }
    r0 = 9ull;
    r1 = 0ull;
    WL_JMP(FID_CASES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_2 = r0;
    Term _k_2 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _text_2;
    e.mem[_nd_2 + 1] = _k_2;
    r0 = term_ctr(CID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
