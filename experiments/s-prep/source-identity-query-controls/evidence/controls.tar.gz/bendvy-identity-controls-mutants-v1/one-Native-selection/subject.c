
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_STORAGE_WORLD 13
#define CID_QUERYSCHEMAONE 14
#define CID_OWNERS_MOTION 15
#define CID_OWNERS_HEALTH 16
#define CID_STORAGE_ROWS 17
#define CID_NIL 18
#define CID_CON 19
#define CID_STORAGE_SPAWN 20
#define CID_STORAGE_INSERTMAIN 21
#define CID_STORAGE_INSERTFLAG 22
#define CID_STORAGE_REMOVEMAIN 23
#define CID_STORAGE_REMOVEFLAG 24
#define CID_STORAGE_DESPAWN 25
#define CID_TYPES_RESERVED 26
#define CID_TYPES_RESERVEREJECTED 27
#define CID_STORAGE_HANDLE 28
#define CID_STORAGE_BUNDLE 29
#define CID_QUERY_REQUIRED 30
#define CID_QUERY_PRESENT 31
#define CID_QUERY_ABSENT 32
#define CID_QUERY_OPTIONAL 33
#define CID_COMMANDS_APPLIED 34
#define CID_COMMANDS_CAPACITYREJECTED 35
#define CID_COMMANDS_INVARIANTFAULT 36
#define CID_TYPES_COMMANDQUEUED 37
#define CID_TYPES_COMMANDMISSING 38
#define CID_CHR 39
#define CID_STORAGE_METADATACOLUMNS 40
#define CID_STORAGE_MAINADDED 41
#define CID_STORAGE_MAINCHANGED 42
#define CID_STORAGE_MAINREMOVED 43
#define CID_STORAGE_DESPAWNED 44
#define CID_STORAGE_ROW 45
#define CID_COMMANDS_PREFLIGHT 46
#define CID_TYPES_FOUND 47
#define CID_TYPES_MISMATCH 48
#define CID_TYPES_MISSING 49
#define CID_COMMANDS_COMPLETED 50
#define CID_COMMANDS_BATCHFAULT 51
#define CID_COMMANDS_RUNNING 52
#define CID_COMMANDS_FAULTED 53
#define CID_QUERY_STRUCTCOLSSTATE 54
#define CID_STORAGE_METADATA 55
#define CID_COMMANDS_STEPPED 56
#define CID_COMMANDS_PLACEMENTFAULT 57
#define CID_QUERY_STRUCTIDXSTATE 58
#define CID_STORAGE_MISSINGMAINTARGET 59
#define CID_STORAGE_ADDEDMAIN 60
#define CID_STORAGE_CHANGEDMAIN 61
#define CID_STORAGE_REMOVEDMAIN 62
#define CID_STORAGE_NOMAINCHANGE 63
#define CID_STORAGE_PLACED 64
#define CID_STORAGE_REJECTED 65
#define CID_COMMANDS_ROWEDIT 66
#define CID_IO_PRINT 67
#define FID_QUERY_AUX_READ_0 0
#define FID_QUERY_AUX_READ_0_K9 1
#define FID_STORAGE_SLOTS_EMPTY 2
#define FID_STORAGE_SLOTS_EMPTY_K24 3
#define FID_STORAGE_SLOTS_EMPTY_K25 4
#define FID_QUERY_MAIN_READ_0 5
#define FID_CALLBACK_0 6
#define FID_CALLBACK_0_K50 7
#define FID_CALLBACK_0_K51 8
#define FID_CALLBACK_0_K52 9
#define FID_CALLBACK_0_K53 10
#define FID_CALLBACK_0_K54 11
#define FID_CALLBACK_0_K55 12
#define FID_CALLBACK_0_K56 13
#define FID_CALLBACK_0_K57 14
#define FID_CALLBACK_0_K58 15
#define FID_CALLBACK_0_K59 16
#define FID_CALLBACK_0_K60 17
#define FID_CALLBACK_0_K61 18
#define FID_STORAGE_GROW 19
#define FID_STORAGE_GROW_C73 20
#define FID_STORAGE_GROW_K74 21
#define FID_STORAGE_GROW_K75 22
#define FID_STORAGE_GROW_K76 23
#define FID_STORAGE_GROW_K77 24
#define FID_QUERY_READ_MAIN_0 25
#define FID_QUERY_READ_MAIN_0_K82 26
#define FID_STORAGE_ROWS_PLACE 27
#define FID_STORAGE_ROWS_PLACE_K129 28
#define FID_QUERY_READ_ROW_0 29
#define FID_QUERY_READ_ROW_0_K133 30
#define FID_OWNERS_HEALTH_OBSERVE 31
#define FID_OWNERS_HEALTH_OBSERVE_K175 32
#define FID_OWNERS_HEALTH_OBSERVE_K176 33
#define FID_OWNERS_HEALTH_OBSERVE_K177 34
#define FID_OWNERS_HEALTH_OBSERVE_K178 35
#define FID_OWNERS_HEALTH_OBSERVE_K179 36
#define FID_OWNERS_HEALTH_OBSERVE_K180 37
#define FID_OWNERS_HEALTH_OBSERVE_K181 38
#define FID_OWNERS_HEALTH_OBSERVE_K182 39
#define FID_OWNERS_HEALTH_OBSERVE_K183 40
#define FID_OWNERS_HEALTH_OBSERVE_K184 41
#define FID_OWNERS_HEALTH_OBSERVE_K185 42
#define FID_OWNERS_HEALTH_OBSERVE_K186 43
#define FID_OWNERS_HEALTH_OBSERVE_K187 44
#define FID_OWNERS_MOTION_OBSERVE 45
#define FID_OWNERS_MOTION_OBSERVE_K190 46
#define FID_OWNERS_MOTION_OBSERVE_K191 47
#define FID_OWNERS_MOTION_OBSERVE_K192 48
#define FID_OWNERS_MOTION_OBSERVE_K193 49
#define FID_OWNERS_MOTION_OBSERVE_K194 50
#define FID_OWNERS_MOTION_OBSERVE_K195 51
#define FID_OWNERS_MOTION_OBSERVE_K196 52
#define FID_OWNERS_MOTION_OBSERVE_K197 53
#define FID_OWNERS_MOTION_OBSERVE_K198 54
#define FID_OWNERS_MOTION_OBSERVE_K199 55
#define FID_OWNERS_MOTION_OBSERVE_K200 56
#define FID_OWNERS_MOTION_OBSERVE_K201 57
#define FID_OWNERS_MOTION_OBSERVE_K202 58
#define FID_COMMANDS_STEP 59
#define FID_COMMANDS_STEP_K210 60
#define FID_COMMANDS_STEP_K211 61
#define FID_QUERY_LOOKUP_ROWS_0 62
#define FID_QUERY_LOOKUP_ROWS_0_K217 63
#define FID_ROW_AUX 64
#define FID_ROW_AUX_K222 65
#define FID_ROW_MAIN 66
#define FID_ROW_MAIN_K224 67
#define FID_NAT_SHOW_FIN 68
#define FID_COMMANDS_STATE_COMMAND 69
#define FID_COMMANDS_STATE_COMMAND_K245 70
#define FID_U32_SHOW_GO 71
#define FID_ROW_OBSERVE 72
#define FID_ROW_OBSERVE_K260 73
#define FID_ROW_OBSERVE_K261 74
#define FID_ROW_OBSERVE_K262 75
#define FID_ROW_OBSERVE_K263 76
#define FID_ROW_OBSERVE_K264 77
#define FID_ROW_OBSERVE_K265 78
#define FID_ROW_OBSERVE_K266 79
#define FID_ROW_OBSERVE_K267 80
#define FID_ROW_OBSERVE_K268 81
#define FID_ROW_OBSERVE_K269 82
#define FID_ROW_OBSERVE_K270 83
#define FID_ROW_OBSERVE_K271 84
#define FID_ROW_OBSERVE_K272 85
#define FID_ROW_OBSERVE_K273 86
#define FID_ROW_OBSERVE_K274 87
#define FID_NAT_SHOW 88
#define FID_COMMANDS_BATCH 89
#define FID_COMMANDS_BATCH_K284 90
#define FID_IDENTITY_VALUES 91
#define FID_IDENTITY_VALUES_K289 92
#define FID_IDENTITY_VALUES_K290 93
#define FID_STRINGS 94
#define FID_STRINGS_K292 95
#define FID_STRINGS_K293 96
#define FID_QUERY_LOOKUP_0 97
#define FID_QUERY_LOOKUP_0_K298 98
#define FID_COMMANDS_QUEUE_OWNED 99
#define FID_COMMANDS_QUEUE_OWNED_K309 100
#define FID_COMMANDS_QUEUE_OWNED_K310 101
#define FID_EXTRACTED_PRINT 102
#define FID_EXTRACTED_PRINT_K313 103
#define FID_EXTRACTED_PRINT_C314 104
#define FID_EXTRACTED_PRINT_C315 105
#define FID_EXTRACTED_PRINT_C316 106
#define FID_EXTRACTED_PRINT_K317 107
#define FID_EXTRACTED_PRINT_K318 108
#define FID_EXTRACTED_PRINT_C319 109
#define FID_EXTRACTED_PRINT_C320 110
#define FID_EXTRACTED_PRINT_C321 111
#define FID_ROWS_SHAPE 112
#define FID_ROWS_SHAPE_K323 113
#define FID_ROWS_SHAPE_K324 114
#define FID_ROWS_SHAPE_K325 115
#define FID_ROWS_SHAPE_K326 116
#define FID_ROWS_SHAPE_K327 117
#define FID_ROWS_SHAPE_K328 118
#define FID_ROWS_SHAPE_K329 119
#define FID_ROWS_SHAPE_K330 120
#define FID_ROWS_SHAPE_C331 121
#define FID_ROWS_SHAPE_C332 122
#define FID_ROWS_SHAPE_C333 123
#define FID_IDENTITY_RENDER 124
#define FID_U32_SHOW 125
#define FID_STRING_APPEND 126
#define FID_STRING_APPEND_K349 127
#define FID_IO_PURE 128
#define FID_LOOKUP 129
#define FID_LOOKUP_K353 130
#define FID_LOOKUP_K354 131
#define FID_LOOKUP_C355 132
#define FID_LOOKUP_C356 133
#define FID_LOOKUP_C357 134
#define FID_COMMANDS_DESPAWN 135
#define FID_COMMANDS_DESPAWN_C359 136
#define FID_COMMANDS_DESPAWN_C360 137
#define FID_COMMANDS_DESPAWN_K361 138
#define FID_COMMANDS_INSERT_MAIN 139
#define FID_COMMANDS_INSERT_MAIN_C363 140
#define FID_COMMANDS_INSERT_MAIN_C364 141
#define FID_COMMANDS_REMOVE_FLAG 142
#define FID_COMMANDS_REMOVE_FLAG_C366 143
#define FID_COMMANDS_REMOVE_FLAG_C367 144
#define FID_COMMANDS_REMOVE_FLAG_K368 145
#define FID_COMMANDS_INSERT_FLAG 146
#define FID_COMMANDS_INSERT_FLAG_C370 147
#define FID_COMMANDS_INSERT_FLAG_C371 148
#define FID_QUEUED 149
#define FID_QUEUED_K373 150
#define FID_QUEUED_C374 151
#define FID_QUEUED_C375 152
#define FID_QUEUED_C376 153
#define FID_QUEUED_K377 154
#define FID_QUEUED_C378 155
#define FID_QUEUED_C379 156
#define FID_QUEUED_C380 157
#define FID_SNAPSHOT 158
#define FID_SNAPSHOT_K382 159
#define FID_SNAPSHOT_C383 160
#define FID_SNAPSHOT_C384 161
#define FID_SNAPSHOT_C385 162
#define FID_SHAPE 163
#define FID_SHAPE_K387 164
#define FID_SHAPE_C388 165
#define FID_SHAPE_C389 166
#define FID_SHAPE_C390 167
#define FID_COMMANDS_APPLY_CHECKED 168
#define FID_COMMANDS_APPLY_CHECKED_K392 169
#define FID_APPLIED 170
#define FID_APPLIED_K394 171
#define FID_APPLIED_C395 172
#define FID_APPLIED_C396 173
#define FID_APPLIED_C397 174
#define FID_APPLIED_K398 175
#define FID_APPLIED_C399 176
#define FID_APPLIED_C400 177
#define FID_APPLIED_C401 178
#define FID_APPLIED_K402 179
#define FID_APPLIED_C403 180
#define FID_APPLIED_C404 181
#define FID_APPLIED_C405 182
#define FID_EACH 183
#define FID_EACH_K407 184
#define FID_EACH_K408 185
#define FID_EACH_K409 186
#define FID_EACH_C410 187
#define FID_EACH_C411 188
#define FID_EACH_C412 189
#define FID_RESERVED 190
#define FID_RESERVED_K417 191
#define FID_RESERVED_K418 192
#define FID_RESERVED_K419 193
#define FID_RESERVED_K420 194
#define FID_RESERVED_K421 195
#define FID_RESERVED_C422 196
#define FID_RESERVED_C423 197
#define FID_RESERVED_C424 198
#define FID_RESERVED_K425 199
#define FID_RESERVED_C426 200
#define FID_RESERVED_C427 201
#define FID_RESERVED_C428 202
#define FID_IO_BIND 203
#define FID_IO_BIND_C430 204
#define FID_IO_BIND_K431 205
#define FID_MAIN 206
#define FID_MAIN_K434 207
#define FID_MAIN_C435 208
#define FID_MAIN_C436 209
#define FID_MAIN_K437 210
#define FID_MAIN_C438 211
#define FID_MAIN_C439 212
#define FID_MAIN_K440 213
#define FID_MAIN_C441 214
#define FID_MAIN_C442 215
#define FID_MAIN_K443 216
#define FID_MAIN_C444 217
#define FID_MAIN_C445 218
#define FID_MAIN_K446 219
#define FID_MAIN_K447 220
#define FID_MAIN_C448 221
#define FID_MAIN_C449 222
#define FID_MAIN_K450 223
#define FID_MAIN_C451 224
#define FID_MAIN_C452 225
#define FID_MAIN_K453 226
#define FID_MAIN_C454 227
#define FID_MAIN_C455 228
#define FID_MAIN_K456 229
#define FID_MAIN_C457 230
#define FID_MAIN_C458 231
#define FID_MAIN_K459 232
#define FID_MAIN_C460 233
#define FID_MAIN_C461 234
#define FID_MAIN_K462 235
#define FID_MAIN_C463 236
#define FID_MAIN_C464 237
#define FID_MAIN_K465 238
#define FID_MAIN_C466 239
#define FID_MAIN_C467 240
#define FID_MAIN_K468 241
#define FID_MAIN_C469 242
#define FID_MAIN_C470 243
#define FID_MAIN_K471 244
#define FID_MAIN_C472 245
#define FID_MAIN_C473 246
#define FID_MAIN_K474 247
#define FID_MAIN_K475 248
#define FID_MAIN_C476 249
#define FID_MAIN_C477 250
#define FID_MAIN_K478 251
#define FID_MAIN_K479 252
#define FID_MAIN_C480 253
#define FID_MAIN_C481 254
#define FID_MAIN_K482 255
#define FID_MAIN_K483 256
#define FID_MAIN_C484 257
#define FID_MAIN_C485 258
#define FID_MAIN_K486 259
#define FID_MAIN_C487 260
#define FID_MAIN_C488 261
#define FID_MAIN_K489 262
#define FID_MAIN_K490 263
#define FID_MAIN_C491 264
#define FID_MAIN_C492 265
#define FID_MAIN_K493 266
#define FID_MAIN_C494 267
#define FID_MAIN_C495 268
#define FID_MAIN_K496 269
#define FID_MAIN_C497 270
#define FID_MAIN_C498 271
#define FID_MAIN_K499 272
#define FID_MAIN_C500 273
#define FID_MAIN_C501 274
#define FID_MAIN_K502 275
#define FID_MAIN_C503 276
#define FID_MAIN_C504 277
#define FID_MAIN_K505 278
#define FID_MAIN_C506 279
#define FID_MAIN_C507 280
#define FID_MAIN_K508 281
#define FID_MAIN_C509 282
#define FID_MAIN_C510 283
#define FID_MAIN_K511 284
#define FID_MAIN_K512 285
#define FID_MAIN_C513 286
#define FID_MAIN_C514 287
#define FID_MAIN_K515 288
#define FID_MAIN_C516 289
#define FID_MAIN_C517 290
#define FID_MAIN_K518 291
#define FID_MAIN_K519 292
#define FID_MAIN_C520 293
#define FID_MAIN_C521 294
#define FID_MAIN_K522 295
#define FID_MAIN_C523 296
#define FID_MAIN_C524 297
#define FID_MAIN_K525 298
#define FID_MAIN_C526 299
#define FID_MAIN_C527 300
#define FID_MAIN_K528 301
#define FID_MAIN_C529 302
#define FID_MAIN_C530 303
#define FID_MAIN_K531 304
#define FID_MAIN_C532 305
#define FID_MAIN_C533 306
#define FID_MAIN_K534 307
#define FID_MAIN_C535 308
#define FID_MAIN_C536 309
#define FID_MAIN_K537 310
#define FID_MAIN_C538 311
#define FID_MAIN_C539 312
#define FID_MAIN_K540 313
#define FID_MAIN_C541 314
#define FID_MAIN_C542 315
#define FID_MAIN_K543 316
#define FID_MAIN_C544 317
#define FID_MAIN_C545 318
#define FID_MAIN_K546 319
#define FID_MAIN_C547 320
#define FID_MAIN_C548 321
#define FID_MAIN_K549 322
#define FID_MAIN_C550 323
#define FID_MAIN_C551 324
#define FID_MAIN_K552 325
#define FID_MAIN_C553 326
#define FID_MAIN_C554 327
#define FID_MAIN_K555 328
#define FID_MAIN_C556 329
#define FID_MAIN_C557 330
#define FID_MAIN_K558 331
#define FID_MAIN_C559 332
#define FID_MAIN_C560 333
#define FID_MAIN_C561 334
#define FID_IO_PRINT 335
#define FID_IO_EMIT 336
#define FID_CLO_APPLY 337
#define FID_EXIT 338
#define FID_ENTER 339
CONSTV u8 FID_T[][3] = { { 3, 0, 2 }, { 3, 3, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 8, 0, 2 }, { 9, 3, 2 }, { 11, 5, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 11, 0, 2 }, { 3, 0, 2 }, { 9, 9, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 1, 1, 2 }, { 10, 0, 2 }, { 10, 6, 2 }, { 18, 0, 2 }, { 18, 9, 2 }, { 12, 0, 2 }, { 11, 11, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 19, 0, 2 }, { 19, 19, 2 }, { 21, 19, 2 }, { 12, 0, 2 }, { 21, 12, 2 }, { 3, 0, 2 }, { 3, 3, 2 }, { 3, 0, 2 }, { 3, 3, 2 }, { 4, 0, 2 }, { 31, 0, 2 }, { 20, 19, 2 }, { 3, 0, 2 }, { 10, 0, 2 }, { 11, 4, 2 }, { 12, 4, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 1, 0, 2 }, { 24, 0, 2 }, { 24, 21, 2 }, { 17, 0, 2 }, { 17, 15, 2 }, { 18, 15, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 16, 0, 2 }, { 15, 11, 2 }, { 19, 0, 2 }, { 17, 1, 2 }, { 16, 1, 2 }, { 21, 0, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 21, 11, 2 }, { 20, 1, 2 }, { 21, 0, 2 }, { 20, 0, 2 }, { 20, 0, 2 }, { 9, 0, 2 }, { 10, 1, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 14, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 17, 0, 2 }, { 16, 15, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 17, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 18, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 18, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 16, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 15, 0, 2 }, { 5, 1, 2 }, { 6, 0, 2 }, { 5, 0, 2 }, { 14, 0, 2 }, { 13, 0, 2 }, { 5, 1, 2 }, { 6, 0, 2 }, { 5, 0, 2 }, { 14, 0, 2 }, { 16, 0, 2 }, { 26, 21, 2 }, { 26, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 15, 0, 2 }, { 15, 14, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 22, 0, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 26, 26, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 17, 17, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 16, 16, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 17, 17, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 26, 26, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 16, 16, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 26, 26, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 15, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 9, 1 }, { 0, 1 }, { 2, 1 }, { 7, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 2, 0 }, { 2, 0 }, { 2, 1 }, { 6, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 16, 1 }, { 15, 1 }, { 25, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 4, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 9, 1 }, { 11, 0 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 10, 1 }, { 20, 1 }, { 10, 1 }, { 20, 1 }, { 7, 1 }, { 5, 1 }, { 10, 1 }, { 18, 1 }, { 7, 0 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 9, 1 }, { 18, 1 }, { 11, 0 }, { 2, 0 } };
#define STAT_LEN 708

#define WL_RESW 26
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
    if ((N) <= 29) break; r29 = e.mem[(A) + 29]; \
    if ((N) <= 30) break; r30 = e.mem[(A) + 30]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
    case 29: r29 = (X); \
      break; \
    case 30: r30 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30

#define WL_TABLE WL_X(FID_QUERY_AUX_READ_0) WL_X(FID_QUERY_AUX_READ_0_K9) WL_X(FID_STORAGE_SLOTS_EMPTY) WL_X(FID_STORAGE_SLOTS_EMPTY_K24) WL_X(FID_STORAGE_SLOTS_EMPTY_K25) WL_X(FID_QUERY_MAIN_READ_0) WL_X(FID_CALLBACK_0) WL_X(FID_CALLBACK_0_K50) WL_X(FID_CALLBACK_0_K51) WL_X(FID_CALLBACK_0_K52) WL_X(FID_CALLBACK_0_K53) WL_X(FID_CALLBACK_0_K54) WL_X(FID_CALLBACK_0_K55) WL_X(FID_CALLBACK_0_K56) WL_X(FID_CALLBACK_0_K57) WL_X(FID_CALLBACK_0_K58) WL_X(FID_CALLBACK_0_K59) WL_X(FID_CALLBACK_0_K60) WL_X(FID_CALLBACK_0_K61) WL_X(FID_STORAGE_GROW) WL_X(FID_STORAGE_GROW_C73) WL_X(FID_STORAGE_GROW_K74) WL_X(FID_STORAGE_GROW_K75) WL_X(FID_STORAGE_GROW_K76) WL_X(FID_STORAGE_GROW_K77) WL_X(FID_QUERY_READ_MAIN_0) WL_X(FID_QUERY_READ_MAIN_0_K82) WL_X(FID_STORAGE_ROWS_PLACE) WL_X(FID_STORAGE_ROWS_PLACE_K129) WL_X(FID_QUERY_READ_ROW_0) WL_X(FID_QUERY_READ_ROW_0_K133) WL_X(FID_OWNERS_HEALTH_OBSERVE) WL_X(FID_OWNERS_HEALTH_OBSERVE_K175) WL_X(FID_OWNERS_HEALTH_OBSERVE_K176) WL_X(FID_OWNERS_HEALTH_OBSERVE_K177) WL_X(FID_OWNERS_HEALTH_OBSERVE_K178) WL_X(FID_OWNERS_HEALTH_OBSERVE_K179) WL_X(FID_OWNERS_HEALTH_OBSERVE_K180) WL_X(FID_OWNERS_HEALTH_OBSERVE_K181) WL_X(FID_OWNERS_HEALTH_OBSERVE_K182) WL_X(FID_OWNERS_HEALTH_OBSERVE_K183) WL_X(FID_OWNERS_HEALTH_OBSERVE_K184) WL_X(FID_OWNERS_HEALTH_OBSERVE_K185) WL_X(FID_OWNERS_HEALTH_OBSERVE_K186) WL_X(FID_OWNERS_HEALTH_OBSERVE_K187) WL_X(FID_OWNERS_MOTION_OBSERVE) WL_X(FID_OWNERS_MOTION_OBSERVE_K190) WL_X(FID_OWNERS_MOTION_OBSERVE_K191) WL_X(FID_OWNERS_MOTION_OBSERVE_K192) WL_X(FID_OWNERS_MOTION_OBSERVE_K193) WL_X(FID_OWNERS_MOTION_OBSERVE_K194) WL_X(FID_OWNERS_MOTION_OBSERVE_K195) WL_X(FID_OWNERS_MOTION_OBSERVE_K196) WL_X(FID_OWNERS_MOTION_OBSERVE_K197) WL_X(FID_OWNERS_MOTION_OBSERVE_K198) WL_X(FID_OWNERS_MOTION_OBSERVE_K199) WL_X(FID_OWNERS_MOTION_OBSERVE_K200) WL_X(FID_OWNERS_MOTION_OBSERVE_K201) WL_X(FID_OWNERS_MOTION_OBSERVE_K202) WL_X(FID_COMMANDS_STEP) WL_X(FID_COMMANDS_STEP_K210) WL_X(FID_COMMANDS_STEP_K211) WL_X(FID_QUERY_LOOKUP_ROWS_0) WL_X(FID_QUERY_LOOKUP_ROWS_0_K217) WL_X(FID_ROW_AUX) WL_X(FID_ROW_AUX_K222) WL_X(FID_ROW_MAIN) WL_X(FID_ROW_MAIN_K224) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_COMMANDS_STATE_COMMAND) WL_X(FID_COMMANDS_STATE_COMMAND_K245) WL_X(FID_U32_SHOW_GO) WL_X(FID_ROW_OBSERVE) WL_X(FID_ROW_OBSERVE_K260) WL_X(FID_ROW_OBSERVE_K261) WL_X(FID_ROW_OBSERVE_K262) WL_X(FID_ROW_OBSERVE_K263) WL_X(FID_ROW_OBSERVE_K264) WL_X(FID_ROW_OBSERVE_K265) WL_X(FID_ROW_OBSERVE_K266) WL_X(FID_ROW_OBSERVE_K267) WL_X(FID_ROW_OBSERVE_K268) WL_X(FID_ROW_OBSERVE_K269) WL_X(FID_ROW_OBSERVE_K270) WL_X(FID_ROW_OBSERVE_K271) WL_X(FID_ROW_OBSERVE_K272) WL_X(FID_ROW_OBSERVE_K273) WL_X(FID_ROW_OBSERVE_K274) WL_X(FID_NAT_SHOW) WL_X(FID_COMMANDS_BATCH) WL_X(FID_COMMANDS_BATCH_K284) WL_X(FID_IDENTITY_VALUES) WL_X(FID_IDENTITY_VALUES_K289) WL_X(FID_IDENTITY_VALUES_K290) WL_X(FID_STRINGS) WL_X(FID_STRINGS_K292) WL_X(FID_STRINGS_K293) WL_X(FID_QUERY_LOOKUP_0) WL_X(FID_QUERY_LOOKUP_0_K298) WL_X(FID_COMMANDS_QUEUE_OWNED) WL_X(FID_COMMANDS_QUEUE_OWNED_K309) WL_X(FID_COMMANDS_QUEUE_OWNED_K310) WL_X(FID_EXTRACTED_PRINT) WL_X(FID_EXTRACTED_PRINT_K313) WL_X(FID_EXTRACTED_PRINT_C314) WL_X(FID_EXTRACTED_PRINT_C315) WL_X(FID_EXTRACTED_PRINT_C316) WL_X(FID_EXTRACTED_PRINT_K317) WL_X(FID_EXTRACTED_PRINT_K318) WL_X(FID_EXTRACTED_PRINT_C319) WL_X(FID_EXTRACTED_PRINT_C320) WL_X(FID_EXTRACTED_PRINT_C321) WL_X(FID_ROWS_SHAPE) WL_X(FID_ROWS_SHAPE_K323) WL_X(FID_ROWS_SHAPE_K324) WL_X(FID_ROWS_SHAPE_K325) WL_X(FID_ROWS_SHAPE_K326) WL_X(FID_ROWS_SHAPE_K327) WL_X(FID_ROWS_SHAPE_K328) WL_X(FID_ROWS_SHAPE_K329) WL_X(FID_ROWS_SHAPE_K330) WL_X(FID_ROWS_SHAPE_C331) WL_X(FID_ROWS_SHAPE_C332) WL_X(FID_ROWS_SHAPE_C333) WL_X(FID_IDENTITY_RENDER) WL_X(FID_U32_SHOW) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K349) WL_X(FID_IO_PURE) WL_X(FID_LOOKUP) WL_X(FID_LOOKUP_K353) WL_X(FID_LOOKUP_K354) WL_X(FID_LOOKUP_C355) WL_X(FID_LOOKUP_C356) WL_X(FID_LOOKUP_C357) WL_X(FID_COMMANDS_DESPAWN) WL_X(FID_COMMANDS_DESPAWN_C359) WL_X(FID_COMMANDS_DESPAWN_C360) WL_X(FID_COMMANDS_DESPAWN_K361) WL_X(FID_COMMANDS_INSERT_MAIN) WL_X(FID_COMMANDS_INSERT_MAIN_C363) WL_X(FID_COMMANDS_INSERT_MAIN_C364) WL_X(FID_COMMANDS_REMOVE_FLAG) WL_X(FID_COMMANDS_REMOVE_FLAG_C366) WL_X(FID_COMMANDS_REMOVE_FLAG_C367) WL_X(FID_COMMANDS_REMOVE_FLAG_K368) WL_X(FID_COMMANDS_INSERT_FLAG) WL_X(FID_COMMANDS_INSERT_FLAG_C370) WL_X(FID_COMMANDS_INSERT_FLAG_C371) WL_X(FID_QUEUED) WL_X(FID_QUEUED_K373) WL_X(FID_QUEUED_C374) WL_X(FID_QUEUED_C375) WL_X(FID_QUEUED_C376) WL_X(FID_QUEUED_K377) WL_X(FID_QUEUED_C378) WL_X(FID_QUEUED_C379) WL_X(FID_QUEUED_C380) WL_X(FID_SNAPSHOT) WL_X(FID_SNAPSHOT_K382) WL_X(FID_SNAPSHOT_C383) WL_X(FID_SNAPSHOT_C384) WL_X(FID_SNAPSHOT_C385) WL_X(FID_SHAPE) WL_X(FID_SHAPE_K387) WL_X(FID_SHAPE_C388) WL_X(FID_SHAPE_C389) WL_X(FID_SHAPE_C390) WL_X(FID_COMMANDS_APPLY_CHECKED) WL_X(FID_COMMANDS_APPLY_CHECKED_K392) WL_X(FID_APPLIED) WL_X(FID_APPLIED_K394) WL_X(FID_APPLIED_C395) WL_X(FID_APPLIED_C396) WL_X(FID_APPLIED_C397) WL_X(FID_APPLIED_K398) WL_X(FID_APPLIED_C399) WL_X(FID_APPLIED_C400) WL_X(FID_APPLIED_C401) WL_X(FID_APPLIED_K402) WL_X(FID_APPLIED_C403) WL_X(FID_APPLIED_C404) WL_X(FID_APPLIED_C405) WL_X(FID_EACH) WL_X(FID_EACH_K407) WL_X(FID_EACH_K408) WL_X(FID_EACH_K409) WL_X(FID_EACH_C410) WL_X(FID_EACH_C411) WL_X(FID_EACH_C412) WL_X(FID_RESERVED) WL_X(FID_RESERVED_K417) WL_X(FID_RESERVED_K418) WL_X(FID_RESERVED_K419) WL_X(FID_RESERVED_K420) WL_X(FID_RESERVED_K421) WL_X(FID_RESERVED_C422) WL_X(FID_RESERVED_C423) WL_X(FID_RESERVED_C424) WL_X(FID_RESERVED_K425) WL_X(FID_RESERVED_C426) WL_X(FID_RESERVED_C427) WL_X(FID_RESERVED_C428) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C430) WL_X(FID_IO_BIND_K431) WL_X(FID_MAIN) WL_X(FID_MAIN_K434) WL_X(FID_MAIN_C435) WL_X(FID_MAIN_C436) WL_X(FID_MAIN_K437) WL_X(FID_MAIN_C438) WL_X(FID_MAIN_C439) WL_X(FID_MAIN_K440) WL_X(FID_MAIN_C441) WL_X(FID_MAIN_C442) WL_X(FID_MAIN_K443) WL_X(FID_MAIN_C444) WL_X(FID_MAIN_C445) WL_X(FID_MAIN_K446) WL_X(FID_MAIN_K447) WL_X(FID_MAIN_C448) WL_X(FID_MAIN_C449) WL_X(FID_MAIN_K450) WL_X(FID_MAIN_C451) WL_X(FID_MAIN_C452) WL_X(FID_MAIN_K453) WL_X(FID_MAIN_C454) WL_X(FID_MAIN_C455) WL_X(FID_MAIN_K456) WL_X(FID_MAIN_C457) WL_X(FID_MAIN_C458) WL_X(FID_MAIN_K459) WL_X(FID_MAIN_C460) WL_X(FID_MAIN_C461) WL_X(FID_MAIN_K462) WL_X(FID_MAIN_C463) WL_X(FID_MAIN_C464) WL_X(FID_MAIN_K465) WL_X(FID_MAIN_C466) WL_X(FID_MAIN_C467) WL_X(FID_MAIN_K468) WL_X(FID_MAIN_C469) WL_X(FID_MAIN_C470) WL_X(FID_MAIN_K471) WL_X(FID_MAIN_C472) WL_X(FID_MAIN_C473) WL_X(FID_MAIN_K474) WL_X(FID_MAIN_K475) WL_X(FID_MAIN_C476) WL_X(FID_MAIN_C477) WL_X(FID_MAIN_K478) WL_X(FID_MAIN_K479) WL_X(FID_MAIN_C480) WL_X(FID_MAIN_C481) WL_X(FID_MAIN_K482) WL_X(FID_MAIN_K483) WL_X(FID_MAIN_C484) WL_X(FID_MAIN_C485) WL_X(FID_MAIN_K486) WL_X(FID_MAIN_C487) WL_X(FID_MAIN_C488) WL_X(FID_MAIN_K489) WL_X(FID_MAIN_K490) WL_X(FID_MAIN_C491) WL_X(FID_MAIN_C492) WL_X(FID_MAIN_K493) WL_X(FID_MAIN_C494) WL_X(FID_MAIN_C495) WL_X(FID_MAIN_K496) WL_X(FID_MAIN_C497) WL_X(FID_MAIN_C498) WL_X(FID_MAIN_K499) WL_X(FID_MAIN_C500) WL_X(FID_MAIN_C501) WL_X(FID_MAIN_K502) WL_X(FID_MAIN_C503) WL_X(FID_MAIN_C504) WL_X(FID_MAIN_K505) WL_X(FID_MAIN_C506) WL_X(FID_MAIN_C507) WL_X(FID_MAIN_K508) WL_X(FID_MAIN_C509) WL_X(FID_MAIN_C510) WL_X(FID_MAIN_K511) WL_X(FID_MAIN_K512) WL_X(FID_MAIN_C513) WL_X(FID_MAIN_C514) WL_X(FID_MAIN_K515) WL_X(FID_MAIN_C516) WL_X(FID_MAIN_C517) WL_X(FID_MAIN_K518) WL_X(FID_MAIN_K519) WL_X(FID_MAIN_C520) WL_X(FID_MAIN_C521) WL_X(FID_MAIN_K522) WL_X(FID_MAIN_C523) WL_X(FID_MAIN_C524) WL_X(FID_MAIN_K525) WL_X(FID_MAIN_C526) WL_X(FID_MAIN_C527) WL_X(FID_MAIN_K528) WL_X(FID_MAIN_C529) WL_X(FID_MAIN_C530) WL_X(FID_MAIN_K531) WL_X(FID_MAIN_C532) WL_X(FID_MAIN_C533) WL_X(FID_MAIN_K534) WL_X(FID_MAIN_C535) WL_X(FID_MAIN_C536) WL_X(FID_MAIN_K537) WL_X(FID_MAIN_C538) WL_X(FID_MAIN_C539) WL_X(FID_MAIN_K540) WL_X(FID_MAIN_C541) WL_X(FID_MAIN_C542) WL_X(FID_MAIN_K543) WL_X(FID_MAIN_C544) WL_X(FID_MAIN_C545) WL_X(FID_MAIN_K546) WL_X(FID_MAIN_C547) WL_X(FID_MAIN_C548) WL_X(FID_MAIN_K549) WL_X(FID_MAIN_C550) WL_X(FID_MAIN_C551) WL_X(FID_MAIN_K552) WL_X(FID_MAIN_C553) WL_X(FID_MAIN_C554) WL_X(FID_MAIN_K555) WL_X(FID_MAIN_C556) WL_X(FID_MAIN_C557) WL_X(FID_MAIN_K558) WL_X(FID_MAIN_C559) WL_X(FID_MAIN_C560) WL_X(FID_MAIN_C561) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 101ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 2), 110ull, term_ctr(CID_SCON, STAT_OFF + 4), 124ull, term_pak(CID_SNIL, 0), 116ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 10), 101ull, term_ctr(CID_SCON, STAT_OFF + 12), 115ull, term_ctr(CID_SCON, STAT_OFF + 14), 98ull, term_ctr(CID_SCON, STAT_OFF + 16), 97ull, term_ctr(CID_SCON, STAT_OFF + 18), 101ull, term_ctr(CID_SCON, STAT_OFF + 16), 114ull, term_ctr(CID_SCON, STAT_OFF + 22), 112ull, term_ctr(CID_SCON, STAT_OFF + 24), 58ull, term_pak(CID_SNIL, 0), 44ull, term_pak(CID_SNIL, 0), 103ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 32), 105ull, term_ctr(CID_SCON, STAT_OFF + 34), 115ull, term_ctr(CID_SCON, STAT_OFF + 36), 115ull, term_ctr(CID_SCON, STAT_OFF + 38), 105ull, term_ctr(CID_SCON, STAT_OFF + 40), 109ull, term_ctr(CID_SCON, STAT_OFF + 42), 104ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 46), 116ull, term_ctr(CID_SCON, STAT_OFF + 48), 97ull, term_ctr(CID_SCON, STAT_OFF + 50), 109ull, term_ctr(CID_SCON, STAT_OFF + 52), 115ull, term_ctr(CID_SCON, STAT_OFF + 54), 105ull, term_ctr(CID_SCON, STAT_OFF + 56), 109ull, term_ctr(CID_SCON, STAT_OFF + 58), 100ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 62), 101ull, term_ctr(CID_SCON, STAT_OFF + 64), 59ull, term_pak(CID_SNIL, 0), 48ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 28), 112ull, term_ctr(CID_SCON, STAT_OFF + 72), 97ull, term_ctr(CID_SCON, STAT_OFF + 74), 104ull, term_ctr(CID_SCON, STAT_OFF + 76), 115ull, term_ctr(CID_SCON, STAT_OFF + 78), 101ull, term_ctr(CID_SCON, STAT_OFF + 62), 117ull, term_ctr(CID_SCON, STAT_OFF + 82), 101ull, term_ctr(CID_SCON, STAT_OFF + 84), 117ull, term_ctr(CID_SCON, STAT_OFF + 86), 113ull, term_ctr(CID_SCON, STAT_OFF + 88), 105ull, term_ctr(CID_SCON, STAT_OFF + 82), 108ull, term_ctr(CID_SCON, STAT_OFF + 92), 112ull, term_ctr(CID_SCON, STAT_OFF + 94), 112ull, term_ctr(CID_SCON, STAT_OFF + 96), 97ull, term_ctr(CID_SCON, STAT_OFF + 98), 116ull, term_ctr(CID_SCON, STAT_OFF + 82), 99ull, term_ctr(CID_SCON, STAT_OFF + 102), 101ull, term_ctr(CID_SCON, STAT_OFF + 104), 106ull, term_ctr(CID_SCON, STAT_OFF + 106), 101ull, term_ctr(CID_SCON, STAT_OFF + 108), 114ull, term_ctr(CID_SCON, STAT_OFF + 110), 45ull, term_ctr(CID_SCON, STAT_OFF + 112), 121ull, term_ctr(CID_SCON, STAT_OFF + 114), 116ull, term_ctr(CID_SCON, STAT_OFF + 116), 105ull, term_ctr(CID_SCON, STAT_OFF + 118), 99ull, term_ctr(CID_SCON, STAT_OFF + 120), 97ull, term_ctr(CID_SCON, STAT_OFF + 122), 112ull, term_ctr(CID_SCON, STAT_OFF + 124), 97ull, term_ctr(CID_SCON, STAT_OFF + 126), 99ull, term_ctr(CID_SCON, STAT_OFF + 128), 108ull, term_ctr(CID_SCON, STAT_OFF + 10), 117ull, term_ctr(CID_SCON, STAT_OFF + 132), 97ull, term_ctr(CID_SCON, STAT_OFF + 134), 102ull, term_ctr(CID_SCON, STAT_OFF + 136), 45ull, term_ctr(CID_SCON, STAT_OFF + 138), 116ull, term_ctr(CID_SCON, STAT_OFF + 140), 110ull, term_ctr(CID_SCON, STAT_OFF + 142), 97ull, term_ctr(CID_SCON, STAT_OFF + 144), 105ull, term_ctr(CID_SCON, STAT_OFF + 146), 114ull, term_ctr(CID_SCON, STAT_OFF + 148), 97ull, term_ctr(CID_SCON, STAT_OFF + 150), 118ull, term_ctr(CID_SCON, STAT_OFF + 152), 110ull, term_ctr(CID_SCON, STAT_OFF + 154), 105ull, term_ctr(CID_SCON, STAT_OFF + 156), 49ull, term_ctr(CID_SCON, STAT_OFF + 28), 110ull, term_ctr(CID_SCON, STAT_OFF + 160), 119ull, term_ctr(CID_SCON, STAT_OFF + 162), 97ull, term_ctr(CID_SCON, STAT_OFF + 164), 112ull, term_ctr(CID_SCON, STAT_OFF + 166), 115ull, term_ctr(CID_SCON, STAT_OFF + 168), 50ull, term_ctr(CID_SCON, STAT_OFF + 28), 110ull, term_ctr(CID_SCON, STAT_OFF + 172), 119ull, term_ctr(CID_SCON, STAT_OFF + 174), 97ull, term_ctr(CID_SCON, STAT_OFF + 176), 112ull, term_ctr(CID_SCON, STAT_OFF + 178), 115ull, term_ctr(CID_SCON, STAT_OFF + 180), 51ull, term_ctr(CID_SCON, STAT_OFF + 28), 110ull, term_ctr(CID_SCON, STAT_OFF + 184), 119ull, term_ctr(CID_SCON, STAT_OFF + 186), 97ull, term_ctr(CID_SCON, STAT_OFF + 188), 112ull, term_ctr(CID_SCON, STAT_OFF + 190), 115ull, term_ctr(CID_SCON, STAT_OFF + 192), 114ull, term_ctr(CID_SCON, STAT_OFF + 28), 101ull, term_ctr(CID_SCON, STAT_OFF + 196), 105ull, term_ctr(CID_SCON, STAT_OFF + 198), 114ull, term_ctr(CID_SCON, STAT_OFF + 200), 114ull, term_ctr(CID_SCON, STAT_OFF + 202), 97ull, term_ctr(CID_SCON, STAT_OFF + 204), 98ull, term_ctr(CID_SCON, STAT_OFF + 206), 45ull, term_ctr(CID_SCON, STAT_OFF + 208), 101ull, term_ctr(CID_SCON, STAT_OFF + 210), 114ull, term_ctr(CID_SCON, STAT_OFF + 212), 111ull, term_ctr(CID_SCON, STAT_OFF + 214), 102ull, term_ctr(CID_SCON, STAT_OFF + 216), 101ull, term_ctr(CID_SCON, STAT_OFF + 218), 98ull, term_ctr(CID_SCON, STAT_OFF + 220), 48ull, term_ctr(CID_SCON, STAT_OFF + 28), 49ull, term_ctr(CID_SCON, STAT_OFF + 224), 114ull, term_ctr(CID_SCON, STAT_OFF + 226), 101ull, term_ctr(CID_SCON, STAT_OFF + 228), 105ull, term_ctr(CID_SCON, STAT_OFF + 230), 114ull, term_ctr(CID_SCON, STAT_OFF + 232), 114ull, term_ctr(CID_SCON, STAT_OFF + 234), 97ull, term_ctr(CID_SCON, STAT_OFF + 236), 98ull, term_ctr(CID_SCON, STAT_OFF + 238), 100ull, term_ctr(CID_SCON, STAT_OFF + 28), 101ull, term_ctr(CID_SCON, STAT_OFF + 242), 114ull, term_ctr(CID_SCON, STAT_OFF + 244), 105ull, term_ctr(CID_SCON, STAT_OFF + 246), 117ull, term_ctr(CID_SCON, STAT_OFF + 248), 113ull, term_ctr(CID_SCON, STAT_OFF + 250), 101ull, term_ctr(CID_SCON, STAT_OFF + 252), 114ull, term_ctr(CID_SCON, STAT_OFF + 254), 45ull, term_ctr(CID_SCON, STAT_OFF + 256), 108ull, term_ctr(CID_SCON, STAT_OFF + 258), 97ull, term_ctr(CID_SCON, STAT_OFF + 260), 105ull, term_ctr(CID_SCON, STAT_OFF + 262), 116ull, term_ctr(CID_SCON, STAT_OFF + 264), 105ull, term_ctr(CID_SCON, STAT_OFF + 266), 110ull, term_ctr(CID_SCON, STAT_OFF + 268), 105ull, term_ctr(CID_SCON, STAT_OFF + 270), 116ull, term_ctr(CID_SCON, STAT_OFF + 28), 110ull, term_ctr(CID_SCON, STAT_OFF + 274), 101ull, term_ctr(CID_SCON, STAT_OFF + 276), 115ull, term_ctr(CID_SCON, STAT_OFF + 278), 101ull, term_ctr(CID_SCON, STAT_OFF + 280), 114ull, term_ctr(CID_SCON, STAT_OFF + 282), 112ull, term_ctr(CID_SCON, STAT_OFF + 284), 45ull, term_ctr(CID_SCON, STAT_OFF + 286), 108ull, term_ctr(CID_SCON, STAT_OFF + 288), 97ull, term_ctr(CID_SCON, STAT_OFF + 290), 105ull, term_ctr(CID_SCON, STAT_OFF + 292), 116ull, term_ctr(CID_SCON, STAT_OFF + 294), 105ull, term_ctr(CID_SCON, STAT_OFF + 296), 110ull, term_ctr(CID_SCON, STAT_OFF + 298), 105ull, term_ctr(CID_SCON, STAT_OFF + 300), 98ull, term_ctr(CID_SCON, STAT_OFF + 280), 97ull, term_ctr(CID_SCON, STAT_OFF + 304), 45ull, term_ctr(CID_SCON, STAT_OFF + 306), 108ull, term_ctr(CID_SCON, STAT_OFF + 308), 97ull, term_ctr(CID_SCON, STAT_OFF + 310), 105ull, term_ctr(CID_SCON, STAT_OFF + 312), 116ull, term_ctr(CID_SCON, STAT_OFF + 314), 105ull, term_ctr(CID_SCON, STAT_OFF + 316), 110ull, term_ctr(CID_SCON, STAT_OFF + 318), 105ull, term_ctr(CID_SCON, STAT_OFF + 320), 108ull, term_ctr(CID_SCON, STAT_OFF + 28), 97ull, term_ctr(CID_SCON, STAT_OFF + 324), 110ull, term_ctr(CID_SCON, STAT_OFF + 326), 111ull, term_ctr(CID_SCON, STAT_OFF + 328), 105ull, term_ctr(CID_SCON, STAT_OFF + 330), 116ull, term_ctr(CID_SCON, STAT_OFF + 332), 112ull, term_ctr(CID_SCON, STAT_OFF + 334), 111ull, term_ctr(CID_SCON, STAT_OFF + 336), 45ull, term_ctr(CID_SCON, STAT_OFF + 338), 108ull, term_ctr(CID_SCON, STAT_OFF + 340), 97ull, term_ctr(CID_SCON, STAT_OFF + 342), 105ull, term_ctr(CID_SCON, STAT_OFF + 344), 116ull, term_ctr(CID_SCON, STAT_OFF + 346), 105ull, term_ctr(CID_SCON, STAT_OFF + 348), 110ull, term_ctr(CID_SCON, STAT_OFF + 350), 105ull, term_ctr(CID_SCON, STAT_OFF + 352), 119ull, term_ctr(CID_SCON, STAT_OFF + 160), 111ull, term_ctr(CID_SCON, STAT_OFF + 356), 114ull, term_ctr(CID_SCON, STAT_OFF + 358), 119ull, term_ctr(CID_SCON, STAT_OFF + 172), 111ull, term_ctr(CID_SCON, STAT_OFF + 362), 114ull, term_ctr(CID_SCON, STAT_OFF + 364), 119ull, term_ctr(CID_SCON, STAT_OFF + 184), 111ull, term_ctr(CID_SCON, STAT_OFF + 368), 114ull, term_ctr(CID_SCON, STAT_OFF + 370), 103ull, term_ctr(CID_SCON, STAT_OFF + 184), 97ull, term_ctr(CID_SCON, STAT_OFF + 374), 108ull, term_ctr(CID_SCON, STAT_OFF + 376), 102ull, term_ctr(CID_SCON, STAT_OFF + 378), 103ull, term_ctr(CID_SCON, STAT_OFF + 160), 97ull, term_ctr(CID_SCON, STAT_OFF + 382), 108ull, term_ctr(CID_SCON, STAT_OFF + 384), 102ull, term_ctr(CID_SCON, STAT_OFF + 386), 110ull, term_ctr(CID_SCON, STAT_OFF + 388), 117ull, term_ctr(CID_SCON, STAT_OFF + 390), 105ull, term_ctr(CID_SCON, STAT_OFF + 174), 97ull, term_ctr(CID_SCON, STAT_OFF + 394), 109ull, term_ctr(CID_SCON, STAT_OFF + 396), 100ull, term_ctr(CID_SCON, STAT_OFF + 258), 101ull, term_ctr(CID_SCON, STAT_OFF + 400), 117ull, term_ctr(CID_SCON, STAT_OFF + 402), 101ull, term_ctr(CID_SCON, STAT_OFF + 404), 117ull, term_ctr(CID_SCON, STAT_OFF + 406), 113ull, term_ctr(CID_SCON, STAT_OFF + 408), 50ull, term_ctr(CID_SCON, STAT_OFF + 224), 114ull, term_ctr(CID_SCON, STAT_OFF + 412), 101ull, term_ctr(CID_SCON, STAT_OFF + 414), 105ull, term_ctr(CID_SCON, STAT_OFF + 416), 114ull, term_ctr(CID_SCON, STAT_OFF + 418), 114ull, term_ctr(CID_SCON, STAT_OFF + 420), 97ull, term_ctr(CID_SCON, STAT_OFF + 422), 98ull, term_ctr(CID_SCON, STAT_OFF + 424), 116ull, term_ctr(CID_SCON, STAT_OFF + 402), 97ull, term_ctr(CID_SCON, STAT_OFF + 428), 100ull, term_ctr(CID_SCON, STAT_OFF + 430), 112ull, term_ctr(CID_SCON, STAT_OFF + 432), 117ull, term_ctr(CID_SCON, STAT_OFF + 434), 100ull, term_ctr(CID_SCON, STAT_OFF + 288), 101ull, term_ctr(CID_SCON, STAT_OFF + 438), 116ull, term_ctr(CID_SCON, STAT_OFF + 440), 97ull, term_ctr(CID_SCON, STAT_OFF + 442), 100ull, term_ctr(CID_SCON, STAT_OFF + 444), 112ull, term_ctr(CID_SCON, STAT_OFF + 446), 117ull, term_ctr(CID_SCON, STAT_OFF + 448), 100ull, term_ctr(CID_SCON, STAT_OFF + 308), 101ull, term_ctr(CID_SCON, STAT_OFF + 452), 116ull, term_ctr(CID_SCON, STAT_OFF + 454), 97ull, term_ctr(CID_SCON, STAT_OFF + 456), 100ull, term_ctr(CID_SCON, STAT_OFF + 458), 112ull, term_ctr(CID_SCON, STAT_OFF + 460), 117ull, term_ctr(CID_SCON, STAT_OFF + 462), 45ull, term_ctr(CID_SCON, STAT_OFF + 360), 100ull, term_ctr(CID_SCON, STAT_OFF + 466), 101ull, term_ctr(CID_SCON, STAT_OFF + 468), 116ull, term_ctr(CID_SCON, STAT_OFF + 470), 97ull, term_ctr(CID_SCON, STAT_OFF + 472), 100ull, term_ctr(CID_SCON, STAT_OFF + 474), 112ull, term_ctr(CID_SCON, STAT_OFF + 476), 117ull, term_ctr(CID_SCON, STAT_OFF + 478), 45ull, term_ctr(CID_SCON, STAT_OFF + 366), 100ull, term_ctr(CID_SCON, STAT_OFF + 482), 101ull, term_ctr(CID_SCON, STAT_OFF + 484), 116ull, term_ctr(CID_SCON, STAT_OFF + 486), 97ull, term_ctr(CID_SCON, STAT_OFF + 488), 100ull, term_ctr(CID_SCON, STAT_OFF + 490), 112ull, term_ctr(CID_SCON, STAT_OFF + 492), 117ull, term_ctr(CID_SCON, STAT_OFF + 494), 45ull, term_ctr(CID_SCON, STAT_OFF + 372), 100ull, term_ctr(CID_SCON, STAT_OFF + 498), 101ull, term_ctr(CID_SCON, STAT_OFF + 500), 116ull, term_ctr(CID_SCON, STAT_OFF + 502), 97ull, term_ctr(CID_SCON, STAT_OFF + 504), 100ull, term_ctr(CID_SCON, STAT_OFF + 506), 112ull, term_ctr(CID_SCON, STAT_OFF + 508), 117ull, term_ctr(CID_SCON, STAT_OFF + 510), 101ull, term_ctr(CID_SCON, STAT_OFF + 182), 100ull, term_ctr(CID_SCON, STAT_OFF + 514), 52ull, term_ctr(CID_SCON, STAT_OFF + 28), 110ull, term_ctr(CID_SCON, STAT_OFF + 518), 119ull, term_ctr(CID_SCON, STAT_OFF + 520), 97ull, term_ctr(CID_SCON, STAT_OFF + 522), 112ull, term_ctr(CID_SCON, STAT_OFF + 524), 115ull, term_ctr(CID_SCON, STAT_OFF + 526), 51ull, term_ctr(CID_SCON, STAT_OFF + 224), 114ull, term_ctr(CID_SCON, STAT_OFF + 530), 101ull, term_ctr(CID_SCON, STAT_OFF + 532), 105ull, term_ctr(CID_SCON, STAT_OFF + 534), 114ull, term_ctr(CID_SCON, STAT_OFF + 536), 114ull, term_ctr(CID_SCON, STAT_OFF + 538), 97ull, term_ctr(CID_SCON, STAT_OFF + 540), 98ull, term_ctr(CID_SCON, STAT_OFF + 542), 110ull, term_ctr(CID_SCON, STAT_OFF + 262), 105ull, term_ctr(CID_SCON, STAT_OFF + 546), 102ull, term_ctr(CID_SCON, STAT_OFF + 548), 110ull, term_ctr(CID_SCON, STAT_OFF + 292), 105ull, term_ctr(CID_SCON, STAT_OFF + 552), 102ull, term_ctr(CID_SCON, STAT_OFF + 554), 110ull, term_ctr(CID_SCON, STAT_OFF + 312), 105ull, term_ctr(CID_SCON, STAT_OFF + 558), 102ull, term_ctr(CID_SCON, STAT_OFF + 560), 110ull, term_ctr(CID_SCON, STAT_OFF + 344), 105ull, term_ctr(CID_SCON, STAT_OFF + 564), 102ull, term_ctr(CID_SCON, STAT_OFF + 566), 49ull, term_ctr(CID_SCON, STAT_OFF + 288), 112ull, term_ctr(CID_SCON, STAT_OFF + 570), 117ull, term_ctr(CID_SCON, STAT_OFF + 572), 107ull, term_ctr(CID_SCON, STAT_OFF + 574), 111ull, term_ctr(CID_SCON, STAT_OFF + 576), 111ull, term_ctr(CID_SCON, STAT_OFF + 578), 108ull, term_ctr(CID_SCON, STAT_OFF + 580), 51ull, term_ctr(CID_SCON, STAT_OFF + 308), 112ull, term_ctr(CID_SCON, STAT_OFF + 584), 117ull, term_ctr(CID_SCON, STAT_OFF + 586), 107ull, term_ctr(CID_SCON, STAT_OFF + 588), 111ull, term_ctr(CID_SCON, STAT_OFF + 590), 111ull, term_ctr(CID_SCON, STAT_OFF + 592), 108ull, term_ctr(CID_SCON, STAT_OFF + 594), 108ull, term_ctr(CID_SCON, STAT_OFF + 72), 111ull, term_ctr(CID_SCON, STAT_OFF + 598), 104ull, term_ctr(CID_SCON, STAT_OFF + 600), 45ull, term_ctr(CID_SCON, STAT_OFF + 602), 50ull, term_ctr(CID_SCON, STAT_OFF + 604), 112ull, term_ctr(CID_SCON, STAT_OFF + 606), 117ull, term_ctr(CID_SCON, STAT_OFF + 608), 107ull, term_ctr(CID_SCON, STAT_OFF + 610), 111ull, term_ctr(CID_SCON, STAT_OFF + 612), 111ull, term_ctr(CID_SCON, STAT_OFF + 614), 108ull, term_ctr(CID_SCON, STAT_OFF + 616), 112ull, term_ctr(CID_SCON, STAT_OFF + 518), 117ull, term_ctr(CID_SCON, STAT_OFF + 620), 107ull, term_ctr(CID_SCON, STAT_OFF + 622), 111ull, term_ctr(CID_SCON, STAT_OFF + 624), 111ull, term_ctr(CID_SCON, STAT_OFF + 626), 108ull, term_ctr(CID_SCON, STAT_OFF + 628), 110ull, term_ctr(CID_SCON, STAT_OFF + 28), 103ull, term_ctr(CID_SCON, STAT_OFF + 632), 105ull, term_ctr(CID_SCON, STAT_OFF + 634), 101ull, term_ctr(CID_SCON, STAT_OFF + 636), 114ull, term_ctr(CID_SCON, STAT_OFF + 638), 111ull, term_ctr(CID_SCON, STAT_OFF + 640), 102ull, term_ctr(CID_SCON, STAT_OFF + 642), 45ull, term_ctr(CID_SCON, STAT_OFF + 644), 112ull, term_ctr(CID_SCON, STAT_OFF + 646), 117ull, term_ctr(CID_SCON, STAT_OFF + 648), 107ull, term_ctr(CID_SCON, STAT_OFF + 650), 111ull, term_ctr(CID_SCON, STAT_OFF + 652), 111ull, term_ctr(CID_SCON, STAT_OFF + 654), 108ull, term_ctr(CID_SCON, STAT_OFF + 656), 108ull, term_ctr(CID_SCON, STAT_OFF + 466), 97ull, term_ctr(CID_SCON, STAT_OFF + 660), 110ull, term_ctr(CID_SCON, STAT_OFF + 662), 105ull, term_ctr(CID_SCON, STAT_OFF + 664), 102ull, term_ctr(CID_SCON, STAT_OFF + 666), 108ull, term_ctr(CID_SCON, STAT_OFF + 482), 97ull, term_ctr(CID_SCON, STAT_OFF + 670), 110ull, term_ctr(CID_SCON, STAT_OFF + 672), 105ull, term_ctr(CID_SCON, STAT_OFF + 674), 102ull, term_ctr(CID_SCON, STAT_OFF + 676), 108ull, term_ctr(CID_SCON, STAT_OFF + 498), 97ull, term_ctr(CID_SCON, STAT_OFF + 680), 110ull, term_ctr(CID_SCON, STAT_OFF + 682), 105ull, term_ctr(CID_SCON, STAT_OFF + 684), 102ull, term_ctr(CID_SCON, STAT_OFF + 686), 119ull, term_ctr(CID_SCON, STAT_OFF + 518), 111ull, term_ctr(CID_SCON, STAT_OFF + 690), 114ull, term_ctr(CID_SCON, STAT_OFF + 692), 45ull, term_ctr(CID_SCON, STAT_OFF + 694), 108ull, term_ctr(CID_SCON, STAT_OFF + 696), 97ull, term_ctr(CID_SCON, STAT_OFF + 698), 110ull, term_ctr(CID_SCON, STAT_OFF + 700), 105ull, term_ctr(CID_SCON, STAT_OFF + 702), 102ull, term_ctr(CID_SCON, STAT_OFF + 704) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _c_0 = r0;
  Term _a_1 = r1;
  Term _b_1 = r2;
  WL_SPIN
    if (_c_0 == 0) {
      term_sink(e, _a_1);
      _v_1 = _b_1;
    } else {
      term_sink(e, _b_1);
      _v_1 = _a_1;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_4 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_5 = blk_at(_columns_0, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_0);
    Term _at_6 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_7 = blk_at(_columns_1, _index_0, 1);
    u32 _c_5 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_6 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _meta_1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _meta_2);
    term_sink(e, _c_6);
    Term _at_8 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_9 = blk_at(_columns_2, _index_0, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _meta_3);
    Term _at_10 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_11 = blk_at(_columns_3, _index_0, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _meta_4);
    _v_8 = _columns_0;
    _v_9 = _columns_1;
    _v_10 = _columns_2;
    _v_11 = _columns_3;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_14 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    u32 _x_0 = ((_a_0 >> 0) & 1);
    u32 _x_1 = ((_a_0 >> 1) & 1);
    u32 _x_2 = ((_a_0 >> 2) & 1);
    u32 _x_3 = ((_a_0 >> 3) & 1);
    u32 _x_4 = ((_a_0 >> 4) & 1);
    u32 _x_5 = ((_a_0 >> 5) & 1);
    u32 _x_6 = ((_a_0 >> 6) & 1);
    u32 _x_7 = ((_a_0 >> 7) & 1);
    u32 _x_8 = ((_a_0 >> 8) & 1);
    u32 _x_9 = ((_a_0 >> 9) & 1);
    u32 _x_10 = ((_a_0 >> 10) & 1);
    u32 _x_11 = ((_a_0 >> 11) & 1);
    u32 _x_12 = ((_a_0 >> 12) & 1);
    u32 _x_13 = ((_a_0 >> 13) & 1);
    u32 _x_14 = ((_a_0 >> 14) & 1);
    u32 _x_15 = ((_a_0 >> 15) & 1);
    u32 _x_16 = ((_a_0 >> 16) & 1);
    u32 _x_17 = ((_a_0 >> 17) & 1);
    u32 _x_18 = ((_a_0 >> 18) & 1);
    u32 _x_19 = ((_a_0 >> 19) & 1);
    u32 _x_20 = ((_a_0 >> 20) & 1);
    u32 _x_21 = ((_a_0 >> 21) & 1);
    u32 _x_22 = ((_a_0 >> 22) & 1);
    u32 _x_23 = ((_a_0 >> 23) & 1);
    u32 _x_24 = ((_a_0 >> 24) & 1);
    u32 _x_25 = ((_a_0 >> 25) & 1);
    u32 _x_26 = ((_a_0 >> 26) & 1);
    u32 _x_27 = ((_a_0 >> 27) & 1);
    u32 _x_28 = ((_a_0 >> 28) & 1);
    u32 _x_29 = ((_a_0 >> 29) & 1);
    u32 _x_30 = ((_a_0 >> 30) & 1);
    u32 _x_31 = ((_a_0 >> 31) & 1);
    u32 _y_0 = ((_b_0 >> 0) & 1);
    u32 _y_1 = ((_b_0 >> 1) & 1);
    u32 _y_2 = ((_b_0 >> 2) & 1);
    u32 _y_3 = ((_b_0 >> 3) & 1);
    u32 _y_4 = ((_b_0 >> 4) & 1);
    u32 _y_5 = ((_b_0 >> 5) & 1);
    u32 _y_6 = ((_b_0 >> 6) & 1);
    u32 _y_7 = ((_b_0 >> 7) & 1);
    u32 _y_8 = ((_b_0 >> 8) & 1);
    u32 _y_9 = ((_b_0 >> 9) & 1);
    u32 _y_10 = ((_b_0 >> 10) & 1);
    u32 _y_11 = ((_b_0 >> 11) & 1);
    u32 _y_12 = ((_b_0 >> 12) & 1);
    u32 _y_13 = ((_b_0 >> 13) & 1);
    u32 _y_14 = ((_b_0 >> 14) & 1);
    u32 _y_15 = ((_b_0 >> 15) & 1);
    u32 _y_16 = ((_b_0 >> 16) & 1);
    u32 _y_17 = ((_b_0 >> 17) & 1);
    u32 _y_18 = ((_b_0 >> 18) & 1);
    u32 _y_19 = ((_b_0 >> 19) & 1);
    u32 _y_20 = ((_b_0 >> 20) & 1);
    u32 _y_21 = ((_b_0 >> 21) & 1);
    u32 _y_22 = ((_b_0 >> 22) & 1);
    u32 _y_23 = ((_b_0 >> 23) & 1);
    u32 _y_24 = ((_b_0 >> 24) & 1);
    u32 _y_25 = ((_b_0 >> 25) & 1);
    u32 _y_26 = ((_b_0 >> 26) & 1);
    u32 _y_27 = ((_b_0 >> 27) & 1);
    u32 _y_28 = ((_b_0 >> 28) & 1);
    u32 _y_29 = ((_b_0 >> 29) & 1);
    u32 _y_30 = ((_b_0 >> 30) & 1);
    u32 _y_31 = ((_b_0 >> 31) & 1);
    Term _v_15 = 0;
    Term _o_1[1];
    Term _a_1 = (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31));
    Term _a_2 = (((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31));
    if (spin_0(e, _o_1, U32_BIN((((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31)), <, (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31))), _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_15 = _o_1[0];
    _v_14 = _v_15;
  break;
  }
  o[0] = _v_14;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_4 = r2;
  Term _metadata_5 = r3;
  Term _metadata_6 = r4;
  Term _metadata_7 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _live_0 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_live_0 == 1) {
      _v_19 = 1;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _metadata_4;
      _v_23 = _metadata_5;
      _v_24 = _metadata_6;
      _v_25 = _metadata_7;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _high_1;
      _v_29 = _row_9;
      _v_30 = _row_10;
      _v_31 = _row_11;
      _v_32 = _row_12;
      _v_33 = _row_13;
      _v_34 = _row_14;
      _v_35 = _row_15;
      _v_36 = _row_16;
      _v_37 = _row_17;
    } else {
      Term _at_0 = _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_10);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_11);
      term_sink(e, _c_1);
      Term _at_2 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
      Term _at_3 = blk_at(_aux_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_12);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_13);
      term_sink(e, _c_3);
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_0[4];
      if (spin_1(e, _o_0, _metadata_4, _metadata_4 == h2 ? q2 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h3 ? q3 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h4 ? q4 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h5 ? q5 : blk_loc(e.mem, _metadata_7), U32_BIN(_row_9, -, 1ull), 1, _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
        return 0;
      }
      _v_42 = _o_0[0];
      _v_43 = _o_0[1];
      _v_44 = _o_0[2];
      _v_45 = _o_0[3];
      _v_38 = _v_42;
      _v_39 = _v_43;
      _v_40 = _v_44;
      _v_41 = _v_45;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_1[1];
      if (spin_2(e, _o_1, _high_1, _row_9) == 0) {
        return 0;
      }
      _v_47 = _o_1[0];
      _v_46 = _v_47;
      _v_19 = 0;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _v_38;
      _v_23 = _v_39;
      _v_24 = _v_40;
      _v_25 = _v_41;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _v_46;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _result_0;
    _v_6 = 1;
    _v_7 = _result_1;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _flag_3 = r0;
  WL_SPIN
    if (_flag_3 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 20);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 26);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_5 = 0;
  u32 _value_0 = r0;
  Term _value_1 = r1;
  WL_SPIN
    if (_value_0 == 0) {
      _v_5 = term_ctr(CID_SCON, STAT_OFF + 6);
    } else {
      _v_5 = _value_1;
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h17 = r17;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_0 = r2;
  Term _aux_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _flag_2 = r11;
  Term _flag_3 = r12;
  u32 _added_1 = r13;
  u32 _changed_1 = r14;
  u32 _insert_1 = r15;
  u32 _old_0 = r16;
  Term _old_1 = r17;
  WL_SPIN
    if (_insert_1 == 0) {
      if (_old_0 == 0) {
        term_sink(e, _flag_3);
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _metadata_4;
        _v_13 = _metadata_5;
        _v_14 = _metadata_6;
        _v_15 = _metadata_7;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 4;
      } else {
        term_sink(e, _old_1);
        Term _v_20 = 0;
        Term _v_21 = 0;
        Term _v_22 = 0;
        Term _v_23 = 0;
        Term _v_24 = 0;
        Term _v_25 = 0;
        Term _v_26 = 0;
        Term _v_27 = 0;
        Term _o_0[4];
        if (spin_1(e, _o_0, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), 0ull, 0ull) == 0) {
          return 0;
        }
        _v_24 = _o_0[0];
        _v_25 = _o_0[1];
        _v_26 = _o_0[2];
        _v_27 = _o_0[3];
        _v_20 = _v_24;
        _v_21 = _v_25;
        _v_22 = _v_26;
        _v_23 = _v_27;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_20;
        _v_13 = _v_21;
        _v_14 = _v_22;
        _v_15 = _v_23;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 3;
      }
    } else {
      if (_old_0 == 0) {
        Term _v_28 = 0;
        Term _v_29 = 0;
        Term _v_30 = 0;
        Term _v_31 = 0;
        Term _v_32 = 0;
        Term _v_33 = 0;
        Term _v_34 = 0;
        Term _v_35 = 0;
        Term _o_1[4];
        if (spin_1(e, _o_1, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), _tick_1, _tick_1) == 0) {
          return 0;
        }
        _v_32 = _o_1[0];
        _v_33 = _o_1[1];
        _v_34 = _o_1[2];
        _v_35 = _o_1[3];
        _v_28 = _v_32;
        _v_29 = _v_33;
        _v_30 = _v_34;
        _v_31 = _v_35;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_28;
        _v_13 = _v_29;
        _v_14 = _v_30;
        _v_15 = _v_31;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 1;
      } else {
        term_sink(e, _old_1);
        Term _v_36 = 0;
        Term _v_37 = 0;
        Term _v_38 = 0;
        Term _v_39 = 0;
        Term _v_40 = 0;
        Term _v_41 = 0;
        Term _v_42 = 0;
        Term _v_43 = 0;
        Term _o_2[4];
        if (spin_1(e, _o_2, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), _added_1, _tick_1) == 0) {
          return 0;
        }
        _v_40 = _o_2[0];
        _v_41 = _o_2[1];
        _v_42 = _o_2[2];
        _v_43 = _o_2[3];
        _v_36 = _v_40;
        _v_37 = _v_41;
        _v_38 = _v_42;
        _v_39 = _v_43;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_36;
        _v_13 = _v_37;
        _v_14 = _v_38;
        _v_15 = _v_39;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 2;
      }
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  Term _result_0 = r3;
  u32 _result_1 = r4;
  WL_SPIN
    _v_5 = _result_0;
    _v_6 = _flags_0;
    _v_7 = _added_0;
    _v_8 = _changed_0;
    _v_9 = _result_1;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _row_9 = r9;
  u32 _row_10 = r10;
  Term _row_11 = r11;
  u32 _row_12 = r12;
  Term _row_13 = r13;
  u32 _row_14 = r14;
  Term _row_15 = r15;
  u32 _row_16 = r16;
  u32 _row_17 = r17;
  u32 _meta_0 = r18;
  WL_SPIN
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_3(e, _o_0, _main_1, _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _row_9, _row_10, _row_11, _row_11 == h11 ? q11 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h13 ? q13 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h15 ? q15 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _aux_1 = r2;
  Term _metadata_4 = r3;
  Term _metadata_5 = r4;
  Term _metadata_6 = r5;
  Term _metadata_7 = r6;
  u32 _capacity_1 = r7;
  Term _depth_1 = r8;
  u32 _high_1 = r9;
  u32 _flag_2 = r10;
  Term _flag_3 = r11;
  u32 _added_1 = r12;
  u32 _changed_1 = r13;
  u32 _insert_0 = r14;
  Term _result_0 = r15;
  u32 _result_1 = r16;
  Term _result_2 = r17;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[10];
    if (spin_7(e, _o_0, _id_1, _tick_1, _result_0, _result_0 == h15 ? q15 : blk_loc(e.mem, _result_0), _aux_1, _aux_1 == h2 ? q2 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h3 ? q3 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h4 ? q4 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h5 ? q5 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h6 ? q6 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_2, _flag_3, _flag_3 == h11 ? q11 : blk_loc(e.mem, _flag_3), _added_1, _changed_1, _insert_0, _result_1, _result_2, _result_2 == h17 ? q17 : blk_loc(e.mem, _result_2)) == 0) {
      return 0;
    }
    _v_20 = _o_0[0];
    _v_21 = _o_0[1];
    _v_22 = _o_0[2];
    _v_23 = _o_0[3];
    _v_24 = _o_0[4];
    _v_25 = _o_0[5];
    _v_26 = _o_0[6];
    _v_27 = _o_0[7];
    _v_28 = _o_0[8];
    _v_29 = _o_0[9];
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  Term _depth_0 = r4;
  WL_SPIN
    Term _fv_0[1];
    _fv_0[0] = 0;
    Term _fv_1[2];
    _fv_1[0] = 0;
    _fv_1[1] = 0;
    Term _fv_2[1];
    _fv_2[0] = 0ull;
    Term _fv_3[1];
    _fv_3[0] = 0ull;
    _v_8 = blk_node(e, _columns_0, blk_new(e, 0, _depth_0, 0, 1, _fv_0));
    _v_9 = blk_node(e, _columns_1, blk_new(e, 1, _depth_0, 1, 2, _fv_1));
    _v_10 = blk_node(e, _columns_2, blk_new(e, 0, _depth_0, 0, 1, _fv_2));
    _v_11 = blk_node(e, _columns_3, blk_new(e, 0, _depth_0, 0, 1, _fv_3));
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[5];
    if (spin_8(e, _o_0, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h7 = r7;
  Term h9 = r9;
  Term h11 = r11;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _main_0 = r0;
  Term _aux_0 = r1;
  u32 _capacity_0 = r2;
  Term _depth_0 = r3;
  u32 _high_0 = r4;
  u32 _row_9 = r5;
  u32 _row_10 = r6;
  Term _row_11 = r7;
  u32 _row_12 = r8;
  Term _row_13 = r9;
  u32 _row_14 = r10;
  Term _row_15 = r11;
  u32 _row_16 = r12;
  u32 _row_17 = r13;
  Term _result_0 = r14;
  Term _result_1 = r15;
  Term _result_2 = r16;
  Term _result_3 = r17;
  u32 _result_4 = r18;
  WL_SPIN
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _o_2[19];
    if (spin_9(e, _o_2, _main_0, _main_0 == h0 ? q0 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h1 ? q1 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h14 ? q14 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h15 ? q15 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h16 ? q16 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h17 ? q17 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _row_9, _row_10, _row_11, _row_11 == h7 ? q7 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h9 ? q9 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h11 ? q11 : blk_loc(e.mem, _row_15), _row_16, _row_17, _result_4) == 0) {
      return 0;
    }
    _v_58 = _o_2[0];
    _v_59 = _o_2[1];
    _v_60 = _o_2[2];
    _v_61 = _o_2[3];
    _v_62 = _o_2[4];
    _v_63 = _o_2[5];
    _v_64 = _o_2[6];
    _v_65 = _o_2[7];
    _v_66 = _o_2[8];
    _v_67 = _o_2[9];
    _v_68 = _o_2[10];
    _v_69 = _o_2[11];
    _v_70 = _o_2[12];
    _v_71 = _o_2[13];
    _v_72 = _o_2[14];
    _v_73 = _o_2[15];
    _v_74 = _o_2[16];
    _v_75 = _o_2[17];
    _v_76 = _o_2[18];
    _v_39 = _v_58;
    _v_40 = _v_59;
    _v_41 = _v_60;
    _v_42 = _v_61;
    _v_43 = _v_62;
    _v_44 = _v_63;
    _v_45 = _v_64;
    _v_46 = _v_65;
    _v_47 = _v_66;
    _v_48 = _v_67;
    _v_49 = _v_68;
    _v_50 = _v_69;
    _v_51 = _v_70;
    _v_52 = _v_71;
    _v_53 = _v_72;
    _v_54 = _v_73;
    _v_55 = _v_74;
    _v_56 = _v_75;
    _v_57 = _v_76;
  break;
  }
  o[0] = _v_39;
  o[1] = _v_40;
  o[2] = _v_41;
  o[3] = _v_42;
  o[4] = _v_43;
  o[5] = _v_44;
  o[6] = _v_45;
  o[7] = _v_46;
  o[8] = _v_47;
  o[9] = _v_48;
  o[10] = _v_49;
  o[11] = _v_50;
  o[12] = _v_51;
  o[13] = _v_52;
  o[14] = _v_53;
  o[15] = _v_54;
  o[16] = _v_55;
  o[17] = _v_56;
  o[18] = _v_57;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_60 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_60 = 0;
    } else {
      _v_60 = _b_0;
    }
  break;
  }
  o[0] = _v_60;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_190 = 0;
  Term _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  u32 _v_194 = 0;
  u32 _v_195 = 0;
  Term _v_196 = 0;
  u32 _v_197 = 0;
  u32 _v_198 = 0;
  Term _live_2 = r0;
  Term _flags_2 = r1;
  Term _added_2 = r2;
  u32 _l_2 = r3;
  u32 _f_2 = r4;
  Term _f_3 = r5;
  u32 _a_1 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  WL_SPIN
    _v_190 = _live_2;
    _v_191 = _flags_2;
    _v_192 = _added_2;
    _v_193 = _result_7;
    _v_194 = _l_2;
    _v_195 = _f_2;
    _v_196 = _f_3;
    _v_197 = _a_1;
    _v_198 = _result_8;
  break;
  }
  o[0] = _v_190;
  o[1] = _v_191;
  o[2] = _v_192;
  o[3] = _v_193;
  o[4] = _v_194;
  o[5] = _v_195;
  o[6] = _v_196;
  o[7] = _v_197;
  o[8] = _v_198;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  Term _v_175 = 0;
  u32 _v_176 = 0;
  u32 _v_177 = 0;
  Term _v_178 = 0;
  u32 _v_179 = 0;
  u32 _v_180 = 0;
  Term _live_1 = r0;
  Term _flags_1 = r1;
  Term _changed_2 = r2;
  u32 _index_3 = r3;
  u32 _l_1 = r4;
  u32 _f_0 = r5;
  Term _f_1 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  WL_SPIN
    Term _at_6 = _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2);
    Term _at_7 = blk_at(_changed_2, _index_3, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    Term _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    Term _v_184 = 0;
    u32 _v_185 = 0;
    u32 _v_186 = 0;
    Term _v_187 = 0;
    u32 _v_188 = 0;
    u32 _v_189 = 0;
    Term _o_2[9];
    if (spin_21(e, _o_2, _live_1, _live_1 == h0 ? q0 : blk_loc(e.mem, _live_1), _flags_1, _flags_1 == h1 ? q1 : blk_loc(e.mem, _flags_1), _result_5, _result_5 == h7 ? q7 : blk_loc(e.mem, _result_5), _l_1, _f_0, _f_1, _f_1 == h6 ? q6 : blk_loc(e.mem, _f_1), _result_6, _changed_2, _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2), _c_4) == 0) {
      return 0;
    }
    _v_181 = _o_2[0];
    _v_182 = _o_2[1];
    _v_183 = _o_2[2];
    _v_184 = _o_2[3];
    _v_185 = _o_2[4];
    _v_186 = _o_2[5];
    _v_187 = _o_2[6];
    _v_188 = _o_2[7];
    _v_189 = _o_2[8];
    _v_172 = _v_181;
    _v_173 = _v_182;
    _v_174 = _v_183;
    _v_175 = _v_184;
    _v_176 = _v_185;
    _v_177 = _v_186;
    _v_178 = _v_187;
    _v_179 = _v_188;
    _v_180 = _v_189;
  break;
  }
  o[0] = _v_172;
  o[1] = _v_173;
  o[2] = _v_174;
  o[3] = _v_175;
  o[4] = _v_176;
  o[5] = _v_177;
  o[6] = _v_178;
  o[7] = _v_179;
  o[8] = _v_180;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  Term _v_157 = 0;
  u32 _v_158 = 0;
  u32 _v_159 = 0;
  Term _v_160 = 0;
  u32 _v_161 = 0;
  u32 _v_162 = 0;
  Term _live_0 = r0;
  Term _added_1 = r1;
  Term _changed_1 = r2;
  u32 _index_2 = r3;
  u32 _l_0 = r4;
  Term _result_2 = r5;
  u32 _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    Term _at_4 = _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1);
    Term _at_5 = blk_at(_added_1, _index_2, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_163 = 0;
    Term _v_164 = 0;
    Term _v_165 = 0;
    Term _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    Term _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    Term _o_3[9];
    if (spin_20(e, _o_3, _live_0, _live_0 == h0 ? q0 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h5 ? q5 : blk_loc(e.mem, _result_2), _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _index_2, _l_0, _result_3, _result_4, _result_4 == h7 ? q7 : blk_loc(e.mem, _result_4), _added_1, _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1), _c_3) == 0) {
      return 0;
    }
    _v_163 = _o_3[0];
    _v_164 = _o_3[1];
    _v_165 = _o_3[2];
    _v_166 = _o_3[3];
    _v_167 = _o_3[4];
    _v_168 = _o_3[5];
    _v_169 = _o_3[6];
    _v_170 = _o_3[7];
    _v_171 = _o_3[8];
    _v_154 = _v_163;
    _v_155 = _v_164;
    _v_156 = _v_165;
    _v_157 = _v_166;
    _v_158 = _v_167;
    _v_159 = _v_168;
    _v_160 = _v_169;
    _v_161 = _v_170;
    _v_162 = _v_171;
  break;
  }
  o[0] = _v_154;
  o[1] = _v_155;
  o[2] = _v_156;
  o[3] = _v_157;
  o[4] = _v_158;
  o[5] = _v_159;
  o[6] = _v_160;
  o[7] = _v_161;
  o[8] = _v_162;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  Term _v_139 = 0;
  u32 _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  u32 _v_144 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  u32 _index_1 = r3;
  Term _result_0 = r4;
  u32 _result_1 = r5;
  WL_SPIN
    Term _at_2 = _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0);
    Term _at_3 = blk_at(_flags_0, _index_1, 1);
    u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    Term _v_148 = 0;
    u32 _v_149 = 0;
    u32 _v_150 = 0;
    Term _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    Term _o_4[9];
    if (spin_19(e, _o_4, _result_0, _result_0 == h4 ? q4 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h1 ? q1 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), _index_1, _result_1, _flags_0, _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0), _c_1, _c_2, _c_2 == h4 ? q4 : _c_2 == h2 ? q2 : _c_2 == h1 ? q1 : _c_2 == h0 ? q0 : blk_loc(e.mem, _c_2)) == 0) {
      return 0;
    }
    _v_145 = _o_4[0];
    _v_146 = _o_4[1];
    _v_147 = _o_4[2];
    _v_148 = _o_4[3];
    _v_149 = _o_4[4];
    _v_150 = _o_4[5];
    _v_151 = _o_4[6];
    _v_152 = _o_4[7];
    _v_153 = _o_4[8];
    _v_136 = _v_145;
    _v_137 = _v_146;
    _v_138 = _v_147;
    _v_139 = _v_148;
    _v_140 = _v_149;
    _v_141 = _v_150;
    _v_142 = _v_151;
    _v_143 = _v_152;
    _v_144 = _v_153;
  break;
  }
  o[0] = _v_136;
  o[1] = _v_137;
  o[2] = _v_138;
  o[3] = _v_139;
  o[4] = _v_140;
  o[5] = _v_141;
  o[6] = _v_142;
  o[7] = _v_143;
  o[8] = _v_144;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  u32 _v_122 = 0;
  u32 _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  u32 _v_126 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    u32 _v_131 = 0;
    u32 _v_132 = 0;
    Term _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    Term _o_5[9];
    if (spin_18(e, _o_5, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _index_0, _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_127 = _o_5[0];
    _v_128 = _o_5[1];
    _v_129 = _o_5[2];
    _v_130 = _o_5[3];
    _v_131 = _o_5[4];
    _v_132 = _o_5[5];
    _v_133 = _o_5[6];
    _v_134 = _o_5[7];
    _v_135 = _o_5[8];
    _v_118 = _v_127;
    _v_119 = _v_128;
    _v_120 = _v_129;
    _v_121 = _v_130;
    _v_122 = _v_131;
    _v_123 = _v_132;
    _v_124 = _v_133;
    _v_125 = _v_134;
    _v_126 = _v_135;
  break;
  }
  o[0] = _v_118;
  o[1] = _v_119;
  o[2] = _v_120;
  o[3] = _v_121;
  o[4] = _v_122;
  o[5] = _v_123;
  o[6] = _v_124;
  o[7] = _v_125;
  o[8] = _v_126;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, Term r12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h16 = r16;
  Term _v_332 = 0;
  Term _v_333 = 0;
  Term _v_334 = 0;
  Term _v_335 = 0;
  Term _v_336 = 0;
  Term _v_337 = 0;
  u32 _v_338 = 0;
  Term _v_339 = 0;
  u32 _v_340 = 0;
  u32 _v_341 = 0;
  u32 _v_342 = 0;
  u32 _v_343 = 0;
  Term _v_344 = 0;
  u32 _v_345 = 0;
  Term _v_346 = 0;
  u32 _v_347 = 0;
  Term _v_348 = 0;
  u32 _v_349 = 0;
  u32 _v_350 = 0;
  u32 _id_6 = r0;
  Term _main_2 = r1;
  u32 _value_2 = r2;
  Term _value_3 = r3;
  Term _aux_2 = r4;
  u32 _av_0 = r5;
  Term _av_1 = r6;
  Term _metadata_8 = r7;
  Term _metadata_9 = r8;
  Term _metadata_10 = r9;
  Term _metadata_11 = r10;
  u32 _capacity_3 = r11;
  Term _depth_3 = r12;
  u32 _high_3 = r13;
  u32 _meta_10 = r14;
  u32 _meta_11 = r15;
  Term _meta_12 = r16;
  u32 _meta_13 = r17;
  u32 _meta_14 = r18;
  WL_SPIN
    _v_332 = _main_2;
    _v_333 = _aux_2;
    _v_334 = _metadata_8;
    _v_335 = _metadata_9;
    _v_336 = _metadata_10;
    _v_337 = _metadata_11;
    _v_338 = _capacity_3;
    _v_339 = _depth_3;
    _v_340 = _high_3;
    _v_341 = 1;
    _v_342 = _id_6;
    _v_343 = _value_2;
    _v_344 = _value_3;
    _v_345 = _av_0;
    _v_346 = _av_1;
    _v_347 = _meta_11;
    _v_348 = _meta_12;
    _v_349 = _meta_13;
    _v_350 = _meta_14;
  break;
  }
  o[0] = _v_332;
  o[1] = _v_333;
  o[2] = _v_334;
  o[3] = _v_335;
  o[4] = _v_336;
  o[5] = _v_337;
  o[6] = _v_338;
  o[7] = _v_339;
  o[8] = _v_340;
  o[9] = _v_341;
  o[10] = _v_342;
  o[11] = _v_343;
  o[12] = _v_344;
  o[13] = _v_345;
  o[14] = _v_346;
  o[15] = _v_347;
  o[16] = _v_348;
  o[17] = _v_349;
  o[18] = _v_350;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_294 = 0;
  Term _v_295 = 0;
  Term _v_296 = 0;
  Term _v_297 = 0;
  Term _v_298 = 0;
  Term _v_299 = 0;
  u32 _v_300 = 0;
  Term _v_301 = 0;
  u32 _v_302 = 0;
  u32 _v_303 = 0;
  u32 _v_304 = 0;
  u32 _v_305 = 0;
  Term _v_306 = 0;
  u32 _v_307 = 0;
  Term _v_308 = 0;
  u32 _v_309 = 0;
  Term _v_310 = 0;
  u32 _v_311 = 0;
  u32 _v_312 = 0;
  u32 _id_5 = r0;
  Term _main_1 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_2 = r8;
  Term _depth_2 = r9;
  u32 _high_2 = r10;
  u32 _meta_5 = r11;
  u32 _meta_6 = r12;
  Term _meta_7 = r13;
  u32 _meta_8 = r14;
  u32 _meta_9 = r15;
  Term _result_21 = r16;
  u32 _result_22 = r17;
  Term _result_23 = r18;
  WL_SPIN
    Term _v_313 = 0;
    Term _v_314 = 0;
    Term _v_315 = 0;
    Term _v_316 = 0;
    Term _v_317 = 0;
    Term _v_318 = 0;
    u32 _v_319 = 0;
    Term _v_320 = 0;
    u32 _v_321 = 0;
    u32 _v_322 = 0;
    u32 _v_323 = 0;
    u32 _v_324 = 0;
    Term _v_325 = 0;
    u32 _v_326 = 0;
    Term _v_327 = 0;
    u32 _v_328 = 0;
    Term _v_329 = 0;
    u32 _v_330 = 0;
    u32 _v_331 = 0;
    Term _o_7[19];
    if (spin_25(e, _o_7, _id_5, _main_1, _main_1 == h1 ? q1 : blk_loc(e.mem, _main_1), _value_0, _value_1, _value_1 == h3 ? q3 : blk_loc(e.mem, _value_1), _result_21, _result_21 == h16 ? q16 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h18 ? q18 : blk_loc(e.mem, _result_23), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_2, _depth_2, _high_2, _meta_5, _meta_6, _meta_7, _meta_7 == h13 ? q13 : blk_loc(e.mem, _meta_7), _meta_8, _meta_9) == 0) {
      return 0;
    }
    _v_313 = _o_7[0];
    _v_314 = _o_7[1];
    _v_315 = _o_7[2];
    _v_316 = _o_7[3];
    _v_317 = _o_7[4];
    _v_318 = _o_7[5];
    _v_319 = _o_7[6];
    _v_320 = _o_7[7];
    _v_321 = _o_7[8];
    _v_322 = _o_7[9];
    _v_323 = _o_7[10];
    _v_324 = _o_7[11];
    _v_325 = _o_7[12];
    _v_326 = _o_7[13];
    _v_327 = _o_7[14];
    _v_328 = _o_7[15];
    _v_329 = _o_7[16];
    _v_330 = _o_7[17];
    _v_331 = _o_7[18];
    _v_294 = _v_313;
    _v_295 = _v_314;
    _v_296 = _v_315;
    _v_297 = _v_316;
    _v_298 = _v_317;
    _v_299 = _v_318;
    _v_300 = _v_319;
    _v_301 = _v_320;
    _v_302 = _v_321;
    _v_303 = _v_322;
    _v_304 = _v_323;
    _v_305 = _v_324;
    _v_306 = _v_325;
    _v_307 = _v_326;
    _v_308 = _v_327;
    _v_309 = _v_328;
    _v_310 = _v_329;
    _v_311 = _v_330;
    _v_312 = _v_331;
  break;
  }
  o[0] = _v_294;
  o[1] = _v_295;
  o[2] = _v_296;
  o[3] = _v_297;
  o[4] = _v_298;
  o[5] = _v_299;
  o[6] = _v_300;
  o[7] = _v_301;
  o[8] = _v_302;
  o[9] = _v_303;
  o[10] = _v_304;
  o[11] = _v_305;
  o[12] = _v_306;
  o[13] = _v_307;
  o[14] = _v_308;
  o[15] = _v_309;
  o[16] = _v_310;
  o[17] = _v_311;
  o[18] = _v_312;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_256 = 0;
  Term _v_257 = 0;
  Term _v_258 = 0;
  Term _v_259 = 0;
  Term _v_260 = 0;
  Term _v_261 = 0;
  u32 _v_262 = 0;
  Term _v_263 = 0;
  u32 _v_264 = 0;
  u32 _v_265 = 0;
  u32 _v_266 = 0;
  u32 _v_267 = 0;
  Term _v_268 = 0;
  u32 _v_269 = 0;
  Term _v_270 = 0;
  u32 _v_271 = 0;
  Term _v_272 = 0;
  u32 _v_273 = 0;
  u32 _v_274 = 0;
  u32 _id_4 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _meta_0 = r9;
  u32 _meta_1 = r10;
  Term _meta_2 = r11;
  u32 _meta_3 = r12;
  u32 _meta_4 = r13;
  Term _result_18 = r14;
  u32 _result_19 = r15;
  Term _result_20 = r16;
  WL_SPIN
    Term _at_10 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
    Term _at_11 = blk_at(_aux_1, U32_BIN(_id_4, -, 1ull), 1);
    u32 _c_7 = blk_read(e.mem, 1, _at_10, _at_11 + 0);
    Term _c_8 = e.mem[_at_10 + _at_11 + 1];
    blk_write(e.mem, 1, _at_10, _at_11 + 0, 0);
    blk_write(e.mem, 1, _at_10, _at_11 + 1, 0);
    Term _v_275 = 0;
    Term _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    Term _v_280 = 0;
    u32 _v_281 = 0;
    Term _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    u32 _v_286 = 0;
    Term _v_287 = 0;
    u32 _v_288 = 0;
    Term _v_289 = 0;
    u32 _v_290 = 0;
    Term _v_291 = 0;
    u32 _v_292 = 0;
    u32 _v_293 = 0;
    Term _o_8[19];
    if (spin_24(e, _o_8, _id_4, _result_18, _result_18 == h14 ? q14 : blk_loc(e.mem, _result_18), _result_19, _result_20, _result_20 == h16 ? q16 : blk_loc(e.mem, _result_20), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _meta_1, _meta_2, _meta_2 == h11 ? q11 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _c_7, _c_8, _c_8 == h16 ? q16 : _c_8 == h14 ? q14 : _c_8 == h11 ? q11 : _c_8 == h5 ? q5 : _c_8 == h4 ? q4 : _c_8 == h3 ? q3 : _c_8 == h2 ? q2 : _c_8 == h1 ? q1 : blk_loc(e.mem, _c_8)) == 0) {
      return 0;
    }
    _v_275 = _o_8[0];
    _v_276 = _o_8[1];
    _v_277 = _o_8[2];
    _v_278 = _o_8[3];
    _v_279 = _o_8[4];
    _v_280 = _o_8[5];
    _v_281 = _o_8[6];
    _v_282 = _o_8[7];
    _v_283 = _o_8[8];
    _v_284 = _o_8[9];
    _v_285 = _o_8[10];
    _v_286 = _o_8[11];
    _v_287 = _o_8[12];
    _v_288 = _o_8[13];
    _v_289 = _o_8[14];
    _v_290 = _o_8[15];
    _v_291 = _o_8[16];
    _v_292 = _o_8[17];
    _v_293 = _o_8[18];
    _v_256 = _v_275;
    _v_257 = _v_276;
    _v_258 = _v_277;
    _v_259 = _v_278;
    _v_260 = _v_279;
    _v_261 = _v_280;
    _v_262 = _v_281;
    _v_263 = _v_282;
    _v_264 = _v_283;
    _v_265 = _v_284;
    _v_266 = _v_285;
    _v_267 = _v_286;
    _v_268 = _v_287;
    _v_269 = _v_288;
    _v_270 = _v_289;
    _v_271 = _v_290;
    _v_272 = _v_291;
    _v_273 = _v_292;
    _v_274 = _v_293;
  break;
  }
  o[0] = _v_256;
  o[1] = _v_257;
  o[2] = _v_258;
  o[3] = _v_259;
  o[4] = _v_260;
  o[5] = _v_261;
  o[6] = _v_262;
  o[7] = _v_263;
  o[8] = _v_264;
  o[9] = _v_265;
  o[10] = _v_266;
  o[11] = _v_267;
  o[12] = _v_268;
  o[13] = _v_269;
  o[14] = _v_270;
  o[15] = _v_271;
  o[16] = _v_272;
  o[17] = _v_273;
  o[18] = _v_274;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term _v_218 = 0;
  Term _v_219 = 0;
  Term _v_220 = 0;
  Term _v_221 = 0;
  Term _v_222 = 0;
  Term _v_223 = 0;
  u32 _v_224 = 0;
  Term _v_225 = 0;
  u32 _v_226 = 0;
  u32 _v_227 = 0;
  u32 _v_228 = 0;
  u32 _v_229 = 0;
  Term _v_230 = 0;
  u32 _v_231 = 0;
  Term _v_232 = 0;
  u32 _v_233 = 0;
  Term _v_234 = 0;
  u32 _v_235 = 0;
  u32 _v_236 = 0;
  u32 _id_3 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  u32 _capacity_0 = r3;
  Term _depth_0 = r4;
  u32 _high_0 = r5;
  Term _result_9 = r6;
  Term _result_10 = r7;
  Term _result_11 = r8;
  Term _result_12 = r9;
  u32 _result_13 = r10;
  u32 _result_14 = r11;
  Term _result_15 = r12;
  u32 _result_16 = r13;
  u32 _result_17 = r14;
  WL_SPIN
    if (_result_13 == 0) {
      term_sink(e, _result_15);
      _v_218 = _main_0;
      _v_219 = _aux_0;
      _v_220 = _result_9;
      _v_221 = _result_10;
      _v_222 = _result_11;
      _v_223 = _result_12;
      _v_224 = _capacity_0;
      _v_225 = _depth_0;
      _v_226 = _high_0;
      _v_227 = 0;
      _v_228 = 0;
      _v_229 = 0;
      _v_230 = 0;
      _v_231 = 0;
      _v_232 = 0;
      _v_233 = 0;
      _v_234 = 0;
      _v_235 = 0;
      _v_236 = 0;
    } else {
      Term _at_8 = _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0);
      Term _at_9 = blk_at(_main_0, U32_BIN(_id_3, -, 1ull), 1);
      u32 _c_5 = blk_read(e.mem, 1, _at_8, _at_9 + 0);
      Term _c_6 = e.mem[_at_8 + _at_9 + 1];
      blk_write(e.mem, 1, _at_8, _at_9 + 0, 0);
      blk_write(e.mem, 1, _at_8, _at_9 + 1, 0);
      Term _v_237 = 0;
      Term _v_238 = 0;
      Term _v_239 = 0;
      Term _v_240 = 0;
      Term _v_241 = 0;
      Term _v_242 = 0;
      u32 _v_243 = 0;
      Term _v_244 = 0;
      u32 _v_245 = 0;
      u32 _v_246 = 0;
      u32 _v_247 = 0;
      u32 _v_248 = 0;
      Term _v_249 = 0;
      u32 _v_250 = 0;
      Term _v_251 = 0;
      u32 _v_252 = 0;
      Term _v_253 = 0;
      u32 _v_254 = 0;
      u32 _v_255 = 0;
      Term _o_9[19];
      if (spin_23(e, _o_9, _id_3, _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _result_9, _result_9 == h6 ? q6 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h7 ? q7 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h8 ? q8 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h9 ? q9 : blk_loc(e.mem, _result_12), _capacity_0, _depth_0, _high_0, 1, _result_14, _result_15, _result_15 == h12 ? q12 : blk_loc(e.mem, _result_15), _result_16, _result_17, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _c_5, _c_6, _c_6 == h12 ? q12 : _c_6 == h9 ? q9 : _c_6 == h8 ? q8 : _c_6 == h7 ? q7 : _c_6 == h6 ? q6 : _c_6 == h2 ? q2 : _c_6 == h1 ? q1 : blk_loc(e.mem, _c_6)) == 0) {
        return 0;
      }
      _v_237 = _o_9[0];
      _v_238 = _o_9[1];
      _v_239 = _o_9[2];
      _v_240 = _o_9[3];
      _v_241 = _o_9[4];
      _v_242 = _o_9[5];
      _v_243 = _o_9[6];
      _v_244 = _o_9[7];
      _v_245 = _o_9[8];
      _v_246 = _o_9[9];
      _v_247 = _o_9[10];
      _v_248 = _o_9[11];
      _v_249 = _o_9[12];
      _v_250 = _o_9[13];
      _v_251 = _o_9[14];
      _v_252 = _o_9[15];
      _v_253 = _o_9[16];
      _v_254 = _o_9[17];
      _v_255 = _o_9[18];
      _v_218 = _v_237;
      _v_219 = _v_238;
      _v_220 = _v_239;
      _v_221 = _v_240;
      _v_222 = _v_241;
      _v_223 = _v_242;
      _v_224 = _v_243;
      _v_225 = _v_244;
      _v_226 = _v_245;
      _v_227 = _v_246;
      _v_228 = _v_247;
      _v_229 = _v_248;
      _v_230 = _v_249;
      _v_231 = _v_250;
      _v_232 = _v_251;
      _v_233 = _v_252;
      _v_234 = _v_253;
      _v_235 = _v_254;
      _v_236 = _v_255;
    }
  break;
  }
  o[0] = _v_218;
  o[1] = _v_219;
  o[2] = _v_220;
  o[3] = _v_221;
  o[4] = _v_222;
  o[5] = _v_223;
  o[6] = _v_224;
  o[7] = _v_225;
  o[8] = _v_226;
  o[9] = _v_227;
  o[10] = _v_228;
  o[11] = _v_229;
  o[12] = _v_230;
  o[13] = _v_231;
  o[14] = _v_232;
  o[15] = _v_233;
  o[16] = _v_234;
  o[17] = _v_235;
  o[18] = _v_236;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  Term _v_93 = 0;
  u32 _v_94 = 0;
  Term _v_95 = 0;
  u32 _v_96 = 0;
  Term _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  u32 _valid_0 = r0;
  u32 _id_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_81 = _rows_18;
      _v_82 = _rows_19;
      _v_83 = _rows_20;
      _v_84 = _rows_21;
      _v_85 = _rows_22;
      _v_86 = _rows_23;
      _v_87 = _rows_24;
      _v_88 = _rows_25;
      _v_89 = _rows_26;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
      _v_99 = 0;
    } else {
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      Term _v_103 = 0;
      u32 _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      u32 _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      Term _v_112 = 0;
      u32 _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      Term _o_6[9];
      if (spin_17(e, _o_6, _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), U32_BIN(_id_2, -, 1ull)) == 0) {
        return 0;
      }
      _v_109 = _o_6[0];
      _v_110 = _o_6[1];
      _v_111 = _o_6[2];
      _v_112 = _o_6[3];
      _v_113 = _o_6[4];
      _v_114 = _o_6[5];
      _v_115 = _o_6[6];
      _v_116 = _o_6[7];
      _v_117 = _o_6[8];
      _v_100 = _v_109;
      _v_101 = _v_110;
      _v_102 = _v_111;
      _v_103 = _v_112;
      _v_104 = _v_113;
      _v_105 = _v_114;
      _v_106 = _v_115;
      _v_107 = _v_116;
      _v_108 = _v_117;
      Term _v_199 = 0;
      Term _v_200 = 0;
      Term _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      Term _v_204 = 0;
      u32 _v_205 = 0;
      Term _v_206 = 0;
      u32 _v_207 = 0;
      u32 _v_208 = 0;
      u32 _v_209 = 0;
      u32 _v_210 = 0;
      Term _v_211 = 0;
      u32 _v_212 = 0;
      Term _v_213 = 0;
      u32 _v_214 = 0;
      Term _v_215 = 0;
      u32 _v_216 = 0;
      u32 _v_217 = 0;
      Term _o_10[19];
      if (spin_22(e, _o_10, _id_2, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_24, _rows_25, _rows_26, _v_100, _v_100 == h7 ? q7 : _v_100 == h6 ? q6 : _v_100 == h5 ? q5 : _v_100 == h4 ? q4 : _v_100 == h3 ? q3 : _v_100 == h2 ? q2 : blk_loc(e.mem, _v_100), _v_101, _v_101 == h7 ? q7 : _v_101 == h6 ? q6 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : blk_loc(e.mem, _v_101), _v_102, _v_102 == h7 ? q7 : _v_102 == h6 ? q6 : _v_102 == h5 ? q5 : _v_102 == h4 ? q4 : _v_102 == h3 ? q3 : _v_102 == h2 ? q2 : blk_loc(e.mem, _v_102), _v_103, _v_103 == h7 ? q7 : _v_103 == h6 ? q6 : _v_103 == h5 ? q5 : _v_103 == h4 ? q4 : _v_103 == h3 ? q3 : _v_103 == h2 ? q2 : blk_loc(e.mem, _v_103), _v_104, _v_105, _v_106, _v_106 == h7 ? q7 : _v_106 == h6 ? q6 : _v_106 == h5 ? q5 : _v_106 == h4 ? q4 : _v_106 == h3 ? q3 : _v_106 == h2 ? q2 : blk_loc(e.mem, _v_106), _v_107, _v_108) == 0) {
        return 0;
      }
      _v_199 = _o_10[0];
      _v_200 = _o_10[1];
      _v_201 = _o_10[2];
      _v_202 = _o_10[3];
      _v_203 = _o_10[4];
      _v_204 = _o_10[5];
      _v_205 = _o_10[6];
      _v_206 = _o_10[7];
      _v_207 = _o_10[8];
      _v_208 = _o_10[9];
      _v_209 = _o_10[10];
      _v_210 = _o_10[11];
      _v_211 = _o_10[12];
      _v_212 = _o_10[13];
      _v_213 = _o_10[14];
      _v_214 = _o_10[15];
      _v_215 = _o_10[16];
      _v_216 = _o_10[17];
      _v_217 = _o_10[18];
      _v_81 = _v_199;
      _v_82 = _v_200;
      _v_83 = _v_201;
      _v_84 = _v_202;
      _v_85 = _v_203;
      _v_86 = _v_204;
      _v_87 = _v_205;
      _v_88 = _v_206;
      _v_89 = _v_207;
      _v_90 = _v_208;
      _v_91 = _v_209;
      _v_92 = _v_210;
      _v_93 = _v_211;
      _v_94 = _v_212;
      _v_95 = _v_213;
      _v_96 = _v_214;
      _v_97 = _v_215;
      _v_98 = _v_216;
      _v_99 = _v_217;
    }
  break;
  }
  o[0] = _v_81;
  o[1] = _v_82;
  o[2] = _v_83;
  o[3] = _v_84;
  o[4] = _v_85;
  o[5] = _v_86;
  o[6] = _v_87;
  o[7] = _v_88;
  o[8] = _v_89;
  o[9] = _v_90;
  o[10] = _v_91;
  o[11] = _v_92;
  o[12] = _v_93;
  o[13] = _v_94;
  o[14] = _v_95;
  o[15] = _v_96;
  o[16] = _v_97;
  o[17] = _v_98;
  o[18] = _v_99;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_0[1];
    if (spin_15(e, _o_0, U32_BIN(_id_1, <=, _rows_15), U32_BIN(_id_1, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_59 = _o_0[0];
    _v_58 = _v_59;
    u32 _v_61 = 0;
    Term _o_1[1];
    if (spin_15(e, _o_1, U32_BIN(0ull, <, _id_1), _v_58) == 0) {
      return 0;
    }
    _v_61 = _o_1[0];
    _v_57 = _v_61;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    Term _o_11[19];
    if (spin_16(e, _o_11, _v_57, _id_1, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17) == 0) {
      return 0;
    }
    _v_62 = _o_11[0];
    _v_63 = _o_11[1];
    _v_64 = _o_11[2];
    _v_65 = _o_11[3];
    _v_66 = _o_11[4];
    _v_67 = _o_11[5];
    _v_68 = _o_11[6];
    _v_69 = _o_11[7];
    _v_70 = _o_11[8];
    _v_71 = _o_11[9];
    _v_72 = _o_11[10];
    _v_73 = _o_11[11];
    _v_74 = _o_11[12];
    _v_75 = _o_11[13];
    _v_76 = _o_11[14];
    _v_77 = _o_11[15];
    _v_78 = _o_11[16];
    _v_79 = _o_11[17];
    _v_80 = _o_11[18];
    _v_38 = _v_62;
    _v_39 = _v_63;
    _v_40 = _v_64;
    _v_41 = _v_65;
    _v_42 = _v_66;
    _v_43 = _v_67;
    _v_44 = _v_68;
    _v_45 = _v_69;
    _v_46 = _v_70;
    _v_47 = _v_71;
    _v_48 = _v_72;
    _v_49 = _v_73;
    _v_50 = _v_74;
    _v_51 = _v_75;
    _v_52 = _v_76;
    _v_53 = _v_77;
    _v_54 = _v_78;
    _v_55 = _v_79;
    _v_56 = _v_80;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_370 = 0;
  Term _v_371 = 0;
  Term _v_372 = 0;
  Term _v_373 = 0;
  Term _v_374 = 0;
  Term _v_375 = 0;
  u32 _v_376 = 0;
  Term _v_377 = 0;
  u32 _v_378 = 0;
  u32 _v_379 = 0;
  u32 _v_380 = 0;
  u32 _v_381 = 0;
  Term _v_382 = 0;
  u32 _v_383 = 0;
  Term _v_384 = 0;
  u32 _v_385 = 0;
  Term _v_386 = 0;
  u32 _v_387 = 0;
  u32 _v_388 = 0;
  u32 _id_7 = r0;
  Term _result_24 = r1;
  Term _result_25 = r2;
  Term _result_26 = r3;
  Term _result_27 = r4;
  Term _result_28 = r5;
  Term _result_29 = r6;
  u32 _result_30 = r7;
  Term _result_31 = r8;
  u32 _result_32 = r9;
  u32 _result_33 = r10;
  u32 _result_34 = r11;
  u32 _result_35 = r12;
  Term _result_36 = r13;
  u32 _result_37 = r14;
  Term _result_38 = r15;
  u32 _result_39 = r16;
  Term _result_40 = r17;
  u32 _result_41 = r18;
  u32 _result_42 = r19;
  WL_SPIN
    if (_result_33 == 0) {
      _v_370 = _result_24;
      _v_371 = _result_25;
      _v_372 = _result_26;
      _v_373 = _result_27;
      _v_374 = _result_28;
      _v_375 = _result_29;
      _v_376 = _result_30;
      _v_377 = _result_31;
      _v_378 = _result_32;
      _v_379 = 0;
      _v_380 = 0;
      _v_381 = 0;
      _v_382 = 0;
      _v_383 = 0;
      _v_384 = 0;
      _v_385 = 0;
      _v_386 = 0;
      _v_387 = 0;
      _v_388 = 0;
    } else {
      Term _v_389 = 0;
      Term _v_390 = 0;
      Term _v_391 = 0;
      Term _v_392 = 0;
      Term _v_393 = 0;
      Term _v_394 = 0;
      Term _v_395 = 0;
      Term _v_396 = 0;
      Term _o_13[4];
      Term _a_2 = 0;
      if (spin_1(e, _o_13, _result_26, _result_26 == h3 ? q3 : blk_loc(e.mem, _result_26), _result_27, _result_27 == h4 ? q4 : blk_loc(e.mem, _result_27), _result_28, _result_28 == h5 ? q5 : blk_loc(e.mem, _result_28), _result_29, _result_29 == h6 ? q6 : blk_loc(e.mem, _result_29), U32_BIN(_id_7, -, 1ull), 0, 0, _a_2, _a_2 == h17 ? q17 : _a_2 == h15 ? q15 : _a_2 == h13 ? q13 : _a_2 == h6 ? q6 : _a_2 == h5 ? q5 : _a_2 == h4 ? q4 : _a_2 == h3 ? q3 : _a_2 == h2 ? q2 : _a_2 == h1 ? q1 : blk_loc(e.mem, _a_2), 0ull, 0ull) == 0) {
        return 0;
      }
      _v_393 = _o_13[0];
      _v_394 = _o_13[1];
      _v_395 = _o_13[2];
      _v_396 = _o_13[3];
      _v_389 = _v_393;
      _v_390 = _v_394;
      _v_391 = _v_395;
      _v_392 = _v_396;
      _v_370 = _result_24;
      _v_371 = _result_25;
      _v_372 = _v_389;
      _v_373 = _v_390;
      _v_374 = _v_391;
      _v_375 = _v_392;
      _v_376 = _result_30;
      _v_377 = _result_31;
      _v_378 = _result_32;
      _v_379 = 1;
      _v_380 = _result_34;
      _v_381 = _result_35;
      _v_382 = _result_36;
      _v_383 = _result_37;
      _v_384 = _result_38;
      _v_385 = _result_39;
      _v_386 = _result_40;
      _v_387 = _result_41;
      _v_388 = _result_42;
    }
  break;
  }
  o[0] = _v_370;
  o[1] = _v_371;
  o[2] = _v_372;
  o[3] = _v_373;
  o[4] = _v_374;
  o[5] = _v_375;
  o[6] = _v_376;
  o[7] = _v_377;
  o[8] = _v_378;
  o[9] = _v_379;
  o[10] = _v_380;
  o[11] = _v_381;
  o[12] = _v_382;
  o[13] = _v_383;
  o[14] = _v_384;
  o[15] = _v_385;
  o[16] = _v_386;
  o[17] = _v_387;
  o[18] = _v_388;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h16 = r16;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _flag_0 = r11;
  Term _flag_1 = r12;
  u32 _added_0 = r13;
  u32 _changed_0 = r14;
  u32 _replacement_2 = r15;
  Term _replacement_3 = r16;
  WL_SPIN
    if (_replacement_2 == 0) {
      Term _at_0 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, 0);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, 0);
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _o_0[10];
      if (spin_10(e, _o_0, _id_1, _tick_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_0, _changed_0, 0, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_0, _c_1, _c_1 == h16 ? q16 : _c_1 == h12 ? q12 : _c_1 == h7 ? q7 : _c_1 == h6 ? q6 : _c_1 == h5 ? q5 : _c_1 == h4 ? q4 : _c_1 == h3 ? q3 : _c_1 == h2 ? q2 : blk_loc(e.mem, _c_1)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    } else {
      Term _at_2 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
      Term _at_3 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, 1);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _replacement_3);
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      u32 _v_36 = 0;
      Term _v_37 = 0;
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      Term _o_1[10];
      if (spin_10(e, _o_1, _id_1, _tick_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_0, _changed_0, 1, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_2, _c_3, _c_3 == h16 ? q16 : _c_3 == h12 ? q12 : _c_3 == h7 ? q7 : _c_3 == h6 ? q6 : _c_3 == h5 ? q5 : _c_3 == h4 ? q4 : _c_3 == h3 ? q3 : _c_3 == h2 ? q2 : blk_loc(e.mem, _c_3)) == 0) {
        return 0;
      }
      _v_30 = _o_1[0];
      _v_31 = _o_1[1];
      _v_32 = _o_1[2];
      _v_33 = _o_1[3];
      _v_34 = _o_1[4];
      _v_35 = _o_1[5];
      _v_36 = _o_1[6];
      _v_37 = _o_1[7];
      _v_38 = _o_1[8];
      _v_39 = _o_1[9];
      _v_10 = _v_30;
      _v_11 = _v_31;
      _v_12 = _v_32;
      _v_13 = _v_33;
      _v_14 = _v_34;
      _v_15 = _v_35;
      _v_16 = _v_36;
      _v_17 = _v_37;
      _v_18 = _v_38;
      _v_19 = _v_39;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _valid_0 = r0;
  Term _rows_9 = r1;
  Term _rows_10 = r2;
  Term _rows_11 = r3;
  Term _rows_12 = r4;
  Term _rows_13 = r5;
  Term _rows_14 = r6;
  u32 _rows_15 = r7;
  Term _rows_16 = r8;
  u32 _rows_17 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_21 = 1;
      _v_22 = _rows_9;
      _v_23 = _rows_10;
      _v_24 = _rows_11;
      _v_25 = _rows_12;
      _v_26 = _rows_13;
      _v_27 = _rows_14;
      _v_28 = _rows_15;
      _v_29 = _rows_16;
      _v_30 = _rows_17;
      _v_31 = _row_9;
      _v_32 = _row_10;
      _v_33 = _row_11;
      _v_34 = _row_12;
      _v_35 = _row_13;
      _v_36 = _row_14;
      _v_37 = _row_15;
      _v_38 = _row_16;
      _v_39 = _row_17;
    } else {
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      u32 _v_49 = 0;
      Term _o_1[5];
      if (spin_12(e, _o_1, _rows_11, _rows_11 == h3 ? q3 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h4 ? q4 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h5 ? q5 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h6 ? q6 : blk_loc(e.mem, _rows_14), U32_BIN(_row_9, -, 1ull)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_46 = _o_1[1];
      _v_47 = _o_1[2];
      _v_48 = _o_1[3];
      _v_49 = _o_1[4];
      _v_40 = _v_45;
      _v_41 = _v_46;
      _v_42 = _v_47;
      _v_43 = _v_48;
      _v_44 = _v_49;
      u32 _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      Term _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      u32 _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      Term _o_2[19];
      if (spin_13(e, _o_2, _rows_9, _rows_9 == h1 ? q1 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h2 ? q2 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _row_9, _row_10, _row_11, _row_11 == h12 ? q12 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h14 ? q14 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17, _v_40, _v_40 == h16 ? q16 : _v_40 == h14 ? q14 : _v_40 == h12 ? q12 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h16 ? q16 : _v_41 == h14 ? q14 : _v_41 == h12 ? q12 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h16 ? q16 : _v_42 == h14 ? q14 : _v_42 == h12 ? q12 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h16 ? q16 : _v_43 == h14 ? q14 : _v_43 == h12 ? q12 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : blk_loc(e.mem, _v_43), _v_44) == 0) {
        return 0;
      }
      _v_50 = _o_2[0];
      _v_51 = _o_2[1];
      _v_52 = _o_2[2];
      _v_53 = _o_2[3];
      _v_54 = _o_2[4];
      _v_55 = _o_2[5];
      _v_56 = _o_2[6];
      _v_57 = _o_2[7];
      _v_58 = _o_2[8];
      _v_59 = _o_2[9];
      _v_60 = _o_2[10];
      _v_61 = _o_2[11];
      _v_62 = _o_2[12];
      _v_63 = _o_2[13];
      _v_64 = _o_2[14];
      _v_65 = _o_2[15];
      _v_66 = _o_2[16];
      _v_67 = _o_2[17];
      _v_68 = _o_2[18];
      _v_21 = _v_50;
      _v_22 = _v_51;
      _v_23 = _v_52;
      _v_24 = _v_53;
      _v_25 = _v_54;
      _v_26 = _v_55;
      _v_27 = _v_56;
      _v_28 = _v_57;
      _v_29 = _v_58;
      _v_30 = _v_59;
      _v_31 = _v_60;
      _v_32 = _v_61;
      _v_33 = _v_62;
      _v_34 = _v_63;
      _v_35 = _v_64;
      _v_36 = _v_65;
      _v_37 = _v_66;
      _v_38 = _v_67;
      _v_39 = _v_68;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, Term r8, u64 q8) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _id_2 = r0;
  u32 _flag_2 = r1;
  Term _flag_3 = r2;
  u32 _added_2 = r3;
  u32 _changed_2 = r4;
  Term _result_0 = r5;
  u32 _result_1 = r6;
  Term _result_2 = r7;
  Term _result_3 = r8;
  WL_SPIN
    _v_10 = _id_2;
    _v_11 = 1;
    _v_12 = _result_0;
    _v_13 = _result_1;
    _v_14 = _result_2;
    _v_15 = _flag_2;
    _v_16 = _flag_3;
    _v_17 = _added_2;
    _v_18 = _changed_2;
    _v_19 = _result_3;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_0 = r9;
  u32 _row_1 = r10;
  Term _row_2 = r11;
  u32 _row_3 = r12;
  Term _row_4 = r13;
  u32 _row_5 = r14;
  Term _row_6 = r15;
  u32 _row_7 = r16;
  u32 _row_8 = r17;
  WL_SPIN
    Term _at_0 = _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9);
    Term _at_1 = blk_at(_rows_9, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_2);
    term_sink(e, _c_1);
    Term _at_2 = _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10);
    Term _at_3 = blk_at(_rows_10, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_3);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_4);
    term_sink(e, _c_3);
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _o_0[4];
    if (spin_1(e, _o_0, _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), U32_BIN(_row_0, -, 1ull), 1, _row_5, _row_6, _row_6 == h15 ? q15 : blk_loc(e.mem, _row_6), _row_7, _row_8) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_32 = _o_0[1];
    _v_33 = _o_0[2];
    _v_34 = _o_0[3];
    _v_27 = _v_31;
    _v_28 = _v_32;
    _v_29 = _v_33;
    _v_30 = _v_34;
    _v_18 = _rows_9;
    _v_19 = _rows_10;
    _v_20 = _v_27;
    _v_21 = _v_28;
    _v_22 = _v_29;
    _v_23 = _v_30;
    _v_24 = _rows_15;
    _v_25 = _rows_16;
    _v_26 = _rows_17;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_73 = 0;
  Term _v_74 = 0;
  Term _v_75 = 0;
  Term _v_76 = 0;
  Term _v_77 = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _rows_18 = r0;
  Term _rows_19 = r1;
  Term _rows_20 = r2;
  Term _rows_21 = r3;
  Term _rows_22 = r4;
  Term _rows_23 = r5;
  u32 _rows_24 = r6;
  Term _rows_25 = r7;
  u32 _rows_26 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    Term _v_104 = 0;
    u32 _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    Term _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    Term _v_116 = 0;
    u32 _v_117 = 0;
    Term _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    Term _v_123 = 0;
    u32 _v_124 = 0;
    Term _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    Term _o_2[19];
    if (spin_14(e, _o_2, _rows_18, _rows_18 == h0 ? q0 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h1 ? q1 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h2 ? q2 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h3 ? q3 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h4 ? q4 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h5 ? q5 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26, _id_1) == 0) {
      return 0;
    }
    _v_111 = _o_2[0];
    _v_112 = _o_2[1];
    _v_113 = _o_2[2];
    _v_114 = _o_2[3];
    _v_115 = _o_2[4];
    _v_116 = _o_2[5];
    _v_117 = _o_2[6];
    _v_118 = _o_2[7];
    _v_119 = _o_2[8];
    _v_120 = _o_2[9];
    _v_121 = _o_2[10];
    _v_122 = _o_2[11];
    _v_123 = _o_2[12];
    _v_124 = _o_2[13];
    _v_125 = _o_2[14];
    _v_126 = _o_2[15];
    _v_127 = _o_2[16];
    _v_128 = _o_2[17];
    _v_129 = _o_2[18];
    _v_92 = _v_111;
    _v_93 = _v_112;
    _v_94 = _v_113;
    _v_95 = _v_114;
    _v_96 = _v_115;
    _v_97 = _v_116;
    _v_98 = _v_117;
    _v_99 = _v_118;
    _v_100 = _v_119;
    _v_101 = _v_120;
    _v_102 = _v_121;
    _v_103 = _v_122;
    _v_104 = _v_123;
    _v_105 = _v_124;
    _v_106 = _v_125;
    _v_107 = _v_126;
    _v_108 = _v_127;
    _v_109 = _v_128;
    _v_110 = _v_129;
    Term _v_130 = 0;
    Term _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    Term _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    Term _v_142 = 0;
    u32 _v_143 = 0;
    Term _v_144 = 0;
    u32 _v_145 = 0;
    Term _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    Term _o_3[19];
    if (spin_26(e, _o_3, _id_1, _v_92, _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : _v_92 == h2 ? q2 : _v_92 == h1 ? q1 : _v_92 == h0 ? q0 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h5 ? q5 : _v_93 == h4 ? q4 : _v_93 == h3 ? q3 : _v_93 == h2 ? q2 : _v_93 == h1 ? q1 : _v_93 == h0 ? q0 : blk_loc(e.mem, _v_93), _v_94, _v_94 == h5 ? q5 : _v_94 == h4 ? q4 : _v_94 == h3 ? q3 : _v_94 == h2 ? q2 : _v_94 == h1 ? q1 : _v_94 == h0 ? q0 : blk_loc(e.mem, _v_94), _v_95, _v_95 == h5 ? q5 : _v_95 == h4 ? q4 : _v_95 == h3 ? q3 : _v_95 == h2 ? q2 : _v_95 == h1 ? q1 : _v_95 == h0 ? q0 : blk_loc(e.mem, _v_95), _v_96, _v_96 == h5 ? q5 : _v_96 == h4 ? q4 : _v_96 == h3 ? q3 : _v_96 == h2 ? q2 : _v_96 == h1 ? q1 : _v_96 == h0 ? q0 : blk_loc(e.mem, _v_96), _v_97, _v_97 == h5 ? q5 : _v_97 == h4 ? q4 : _v_97 == h3 ? q3 : _v_97 == h2 ? q2 : _v_97 == h1 ? q1 : _v_97 == h0 ? q0 : blk_loc(e.mem, _v_97), _v_98, _v_99, _v_100, _v_101, _v_102, _v_103, _v_104, _v_104 == h5 ? q5 : _v_104 == h4 ? q4 : _v_104 == h3 ? q3 : _v_104 == h2 ? q2 : _v_104 == h1 ? q1 : _v_104 == h0 ? q0 : blk_loc(e.mem, _v_104), _v_105, _v_106, _v_106 == h5 ? q5 : _v_106 == h4 ? q4 : _v_106 == h3 ? q3 : _v_106 == h2 ? q2 : _v_106 == h1 ? q1 : _v_106 == h0 ? q0 : blk_loc(e.mem, _v_106), _v_107, _v_108, _v_108 == h5 ? q5 : _v_108 == h4 ? q4 : _v_108 == h3 ? q3 : _v_108 == h2 ? q2 : _v_108 == h1 ? q1 : _v_108 == h0 ? q0 : blk_loc(e.mem, _v_108), _v_109, _v_110) == 0) {
      return 0;
    }
    _v_130 = _o_3[0];
    _v_131 = _o_3[1];
    _v_132 = _o_3[2];
    _v_133 = _o_3[3];
    _v_134 = _o_3[4];
    _v_135 = _o_3[5];
    _v_136 = _o_3[6];
    _v_137 = _o_3[7];
    _v_138 = _o_3[8];
    _v_139 = _o_3[9];
    _v_140 = _o_3[10];
    _v_141 = _o_3[11];
    _v_142 = _o_3[12];
    _v_143 = _o_3[13];
    _v_144 = _o_3[14];
    _v_145 = _o_3[15];
    _v_146 = _o_3[16];
    _v_147 = _o_3[17];
    _v_148 = _o_3[18];
    _v_73 = _v_130;
    _v_74 = _v_131;
    _v_75 = _v_132;
    _v_76 = _v_133;
    _v_77 = _v_134;
    _v_78 = _v_135;
    _v_79 = _v_136;
    _v_80 = _v_137;
    _v_81 = _v_138;
    _v_82 = _v_139;
    _v_83 = _v_140;
    _v_84 = _v_141;
    _v_85 = _v_142;
    _v_86 = _v_143;
    _v_87 = _v_144;
    _v_88 = _v_145;
    _v_89 = _v_146;
    _v_90 = _v_147;
    _v_91 = _v_148;
  break;
  }
  o[0] = _v_73;
  o[1] = _v_74;
  o[2] = _v_75;
  o[3] = _v_76;
  o[4] = _v_77;
  o[5] = _v_78;
  o[6] = _v_79;
  o[7] = _v_80;
  o[8] = _v_81;
  o[9] = _v_82;
  o[10] = _v_83;
  o[11] = _v_84;
  o[12] = _v_85;
  o[13] = _v_86;
  o[14] = _v_87;
  o[15] = _v_88;
  o[16] = _v_89;
  o[17] = _v_90;
  o[18] = _v_91;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_168 = 0;
  Term _v_169 = 0;
  Term _v_170 = 0;
  Term _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  Term _v_176 = 0;
  u32 _v_177 = 0;
  Term _v_178 = 0;
  u32 _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  Term _v_184 = 0;
  u32 _v_185 = 0;
  u32 _v_186 = 0;
  Term _changes_0 = r0;
  Term _result_11 = r1;
  Term _result_12 = r2;
  Term _result_13 = r3;
  Term _result_14 = r4;
  Term _result_15 = r5;
  Term _result_16 = r6;
  u32 _result_17 = r7;
  Term _result_18 = r8;
  u32 _result_19 = r9;
  u32 _result_20 = r10;
  u32 _result_21 = r11;
  u32 _result_22 = r12;
  Term _result_23 = r13;
  u32 _result_24 = r14;
  Term _result_25 = r15;
  u32 _result_26 = r16;
  Term _result_27 = r17;
  u32 _result_28 = r18;
  u32 _result_29 = r19;
  WL_SPIN
    term_sink(e, _result_23);
    term_sink(e, _result_25);
    term_sink(e, _result_27);
    _v_168 = 0;
    _v_169 = _result_11;
    _v_170 = _result_12;
    _v_171 = _result_13;
    _v_172 = _result_14;
    _v_173 = _result_15;
    _v_174 = _result_16;
    _v_175 = _result_17;
    _v_176 = _result_18;
    _v_177 = _result_19;
    _v_178 = _changes_0;
    _v_179 = 0;
    _v_180 = 0;
    _v_181 = 0;
    _v_182 = 0;
    _v_183 = 0;
    _v_184 = 0;
    _v_185 = 0;
    _v_186 = 0;
  break;
  }
  o[0] = _v_168;
  o[1] = _v_169;
  o[2] = _v_170;
  o[3] = _v_171;
  o[4] = _v_172;
  o[5] = _v_173;
  o[6] = _v_174;
  o[7] = _v_175;
  o[8] = _v_176;
  o[9] = _v_177;
  o[10] = _v_178;
  o[11] = _v_179;
  o[12] = _v_180;
  o[13] = _v_181;
  o[14] = _v_182;
  o[15] = _v_183;
  o[16] = _v_184;
  o[17] = _v_185;
  o[18] = _v_186;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _metadata_0 = r4;
  Term _metadata_1 = r5;
  Term _metadata_2 = r6;
  Term _metadata_3 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _replacement_2 = r11;
  Term _replacement_3 = r12;
  u32 _meta_0 = r13;
  u32 _meta_1 = r14;
  Term _meta_2 = r15;
  u32 _meta_3 = r16;
  u32 _meta_4 = r17;
  WL_SPIN
    if (_meta_0 == 0) {
      term_sink(e, _replacement_3);
      term_sink(e, _meta_2);
      _v_10 = _main_1;
      _v_11 = _aux_1;
      _v_12 = _metadata_0;
      _v_13 = _metadata_1;
      _v_14 = _metadata_2;
      _v_15 = _metadata_3;
      _v_16 = _capacity_1;
      _v_17 = _depth_1;
      _v_18 = _high_1;
      _v_19 = 0;
    } else {
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _o_0[10];
      if (spin_27(e, _o_0, _id_1, _tick_1, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h4 ? q4 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h5 ? q5 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h6 ? q6 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h7 ? q7 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_1, _meta_2, _meta_2 == h15 ? q15 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _replacement_2, _replacement_3, _replacement_3 == h12 ? q12 : blk_loc(e.mem, _replacement_3)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_18 = r9;
  u32 _row_19 = r10;
  Term _row_20 = r11;
  u32 _row_21 = r12;
  Term _row_22 = r13;
  u32 _row_23 = r14;
  Term _row_24 = r15;
  u32 _row_25 = r16;
  u32 _row_26 = r17;
  WL_SPIN
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_0[1];
    if (spin_15(e, _o_0, U32_BIN(0ull, <, _row_18), U32_BIN(_row_18, <=, _rows_15)) == 0) {
      return 0;
    }
    _v_39 = _o_0[0];
    _v_38 = _v_39;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    Term _o_1[19];
    if (spin_28(e, _o_1, _v_38, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _row_18, _row_19, _row_20, _row_20 == h11 ? q11 : blk_loc(e.mem, _row_20), _row_21, _row_22, _row_22 == h13 ? q13 : blk_loc(e.mem, _row_22), _row_23, _row_24, _row_24 == h15 ? q15 : blk_loc(e.mem, _row_24), _row_25, _row_26) == 0) {
      return 0;
    }
    _v_40 = _o_1[0];
    _v_41 = _o_1[1];
    _v_42 = _o_1[2];
    _v_43 = _o_1[3];
    _v_44 = _o_1[4];
    _v_45 = _o_1[5];
    _v_46 = _o_1[6];
    _v_47 = _o_1[7];
    _v_48 = _o_1[8];
    _v_49 = _o_1[9];
    _v_50 = _o_1[10];
    _v_51 = _o_1[11];
    _v_52 = _o_1[12];
    _v_53 = _o_1[13];
    _v_54 = _o_1[14];
    _v_55 = _o_1[15];
    _v_56 = _o_1[16];
    _v_57 = _o_1[17];
    _v_58 = _o_1[18];
    _v_19 = _v_40;
    _v_20 = _v_41;
    _v_21 = _v_42;
    _v_22 = _v_43;
    _v_23 = _v_44;
    _v_24 = _v_45;
    _v_25 = _v_46;
    _v_26 = _v_47;
    _v_27 = _v_48;
    _v_28 = _v_49;
    _v_29 = _v_50;
    _v_30 = _v_51;
    _v_31 = _v_52;
    _v_32 = _v_53;
    _v_33 = _v_54;
    _v_34 = _v_55;
    _v_35 = _v_56;
    _v_36 = _v_57;
    _v_37 = _v_58;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _index_1 = r0;
  Term _result_0 = r1;
  u32 _result_1 = r2;
  Term _result_2 = r3;
  WL_SPIN
    if (_result_1 == 0) {
      _v_8 = _result_0;
      _v_9 = 0;
    } else {
      Term _at_2 = _result_0 == h1 ? q1 : blk_loc(e.mem, _result_0);
      Term _at_3 = blk_at(_result_0, _index_1, 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, 1);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _result_2);
      term_sink(e, _c_3);
      _v_8 = _result_0;
      _v_9 = 1;
    }
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _array_0 = r0;
  u32 _index_0 = r1;
  WL_SPIN
    Term _at_0 = _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0);
    Term _at_1 = blk_at(_array_0, _index_0, 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, 0);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, 0);
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _o_0[2];
    if (spin_37(e, _o_0, _index_0, _array_0, _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0), _c_0, _c_1, _c_1 == h0 ? q0 : blk_loc(e.mem, _c_1)) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_4 = _v_6;
    _v_5 = _v_7;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h9 = r9;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _id_1 = r0;
  u32 _namespace_1 = r1;
  Term _aux_1 = r2;
  Term _live_1 = r3;
  Term _flags_1 = r4;
  Term _added_1 = r5;
  Term _changed_1 = r6;
  Term _values_1 = r7;
  u32 _flag_1 = r8;
  Term _result_3 = r9;
  u32 _result_4 = r10;
  WL_SPIN
    if (_result_4 == 0) {
      _v_17 = _result_3;
      _v_18 = _aux_1;
      _v_19 = _live_1;
      _v_20 = _flags_1;
      _v_21 = _added_1;
      _v_22 = _changed_1;
      _v_23 = _values_1;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _id_1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_HANDLE, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _values_1);
      _v_17 = _result_3;
      _v_18 = _aux_1;
      _v_19 = _live_1;
      _v_20 = _flags_1;
      _v_21 = _added_1;
      _v_22 = _changed_1;
      _v_23 = term_ctr(CID_CON, _nd_1);
    }
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, u32 r8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h6 = r6;
  Term h9 = r9;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  u32 _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  Term _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  WL_SPIN
    _v_11 = _result_0;
    _v_12 = _result_1;
    _v_13 = _result_2;
    _v_14 = _result_3;
    _v_15 = _result_4;
    _v_16 = _result_5;
    _v_17 = _result_6;
    _v_18 = _result_7;
    _v_19 = _result_8;
    _v_20 = 1;
    _v_21 = _result_9;
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term h9 = r9;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  u32 _namespace_1 = r0;
  u32 _tick_1 = r1;
  u32 _command_8 = r2;
  u32 _command_9 = r3;
  Term _command_10 = r4;
  Term _command_11 = r5;
  u32 _command_12 = r6;
  Term _command_13 = r7;
  u32 _command_14 = r8;
  Term _command_15 = r9;
  u32 _row_0 = r10;
  u32 _row_1 = r11;
  Term _row_2 = r12;
  u32 _row_3 = r13;
  Term _row_4 = r14;
  u32 _row_5 = r15;
  Term _row_6 = r16;
  u32 _row_7 = r17;
  u32 _row_8 = r18;
  WL_SPIN
    if (_command_8 == 2) {
      term_sink(e, _row_6);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = 1;
      _v_29 = _command_10;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 4) {
      term_sink(e, _row_6);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = 0;
      _v_29 = 0;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 1) {
      term_sink(e, _command_10);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 3) {
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 5) {
      if (_row_1 == 1) {
        term_sink(e, _row_2);
        term_sink(e, _row_4);
        term_sink(e, _row_6);
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_0 + 1] = rfc_seal(e, _row_0);
        u64 _nd_1 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _row_0);
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_DESPAWNED, _nd_1));
        e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINREMOVED, _nd_0));
        e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
        _v_22 = 0;
        _v_23 = 0;
        _v_24 = 0;
        _v_25 = 0;
        _v_26 = 0;
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0;
        _v_30 = 0;
        _v_31 = 0;
        _v_32 = term_ctr(CID_CON, _nd_3);
      } else {
        term_sink(e, _row_4);
        term_sink(e, _row_6);
        u64 _nd_4 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_4 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_4 + 1] = rfc_seal(e, _row_0);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_DESPAWNED, _nd_4));
        e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        _v_22 = 0;
        _v_23 = 0;
        _v_24 = 0;
        _v_25 = 0;
        _v_26 = 0;
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0;
        _v_30 = 0;
        _v_31 = 0;
        _v_32 = term_ctr(CID_CON, _nd_5);
      }
    } else {
      term_sink(e, _command_11);
      term_sink(e, _command_13);
      term_sink(e, _command_15);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    }
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term h20 = r20;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  u32 _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _id_1 = r9;
  u32 _result_19 = r10;
  u32 _result_20 = r11;
  u32 _result_21 = r12;
  Term _result_22 = r13;
  u32 _result_23 = r14;
  Term _result_24 = r15;
  u32 _result_25 = r16;
  Term _result_26 = r17;
  u32 _result_27 = r18;
  u32 _result_28 = r19;
  Term _result_29 = r20;
  WL_SPIN
    if (_result_19 == 1) {
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      u32 _v_77 = 0;
      Term _v_78 = 0;
      u32 _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      u32 _v_88 = 0;
      Term _o_1[9];
      if (spin_31(e, _o_1, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _result_20, _result_21, _result_22, _result_22 == h13 ? q13 : blk_loc(e.mem, _result_22), _result_23, _result_24, _result_24 == h15 ? q15 : blk_loc(e.mem, _result_24), _result_25, _result_26, _result_26 == h17 ? q17 : blk_loc(e.mem, _result_26), _result_27, _result_28) == 0) {
        return 0;
      }
      _v_80 = _o_1[0];
      _v_81 = _o_1[1];
      _v_82 = _o_1[2];
      _v_83 = _o_1[3];
      _v_84 = _o_1[4];
      _v_85 = _o_1[5];
      _v_86 = _o_1[6];
      _v_87 = _o_1[7];
      _v_88 = _o_1[8];
      _v_71 = _v_80;
      _v_72 = _v_81;
      _v_73 = _v_82;
      _v_74 = _v_83;
      _v_75 = _v_84;
      _v_76 = _v_85;
      _v_77 = _v_86;
      _v_78 = _v_87;
      _v_79 = _v_88;
      _v_52 = 0;
      _v_53 = _v_71;
      _v_54 = _v_72;
      _v_55 = _v_73;
      _v_56 = _v_74;
      _v_57 = _v_75;
      _v_58 = _v_76;
      _v_59 = _v_77;
      _v_60 = _v_78;
      _v_61 = _v_79;
      _v_62 = _result_29;
      _v_63 = 0;
      _v_64 = 0;
      _v_65 = 0;
      _v_66 = 0;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
    } else {
      Term _v_89 = 0;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      u32 _v_102 = 0;
      Term _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      Term _v_112 = 0;
      Term _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      u32 _v_118 = 0;
      u32 _v_119 = 0;
      Term _v_120 = 0;
      u32 _v_121 = 0;
      Term _v_122 = 0;
      u32 _v_123 = 0;
      Term _v_124 = 0;
      u32 _v_125 = 0;
      u32 _v_126 = 0;
      Term _o_2[19];
      if (spin_32(e, _o_2, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _id_1) == 0) {
        return 0;
      }
      _v_108 = _o_2[0];
      _v_109 = _o_2[1];
      _v_110 = _o_2[2];
      _v_111 = _o_2[3];
      _v_112 = _o_2[4];
      _v_113 = _o_2[5];
      _v_114 = _o_2[6];
      _v_115 = _o_2[7];
      _v_116 = _o_2[8];
      _v_117 = _o_2[9];
      _v_118 = _o_2[10];
      _v_119 = _o_2[11];
      _v_120 = _o_2[12];
      _v_121 = _o_2[13];
      _v_122 = _o_2[14];
      _v_123 = _o_2[15];
      _v_124 = _o_2[16];
      _v_125 = _o_2[17];
      _v_126 = _o_2[18];
      _v_89 = _v_108;
      _v_90 = _v_109;
      _v_91 = _v_110;
      _v_92 = _v_111;
      _v_93 = _v_112;
      _v_94 = _v_113;
      _v_95 = _v_114;
      _v_96 = _v_115;
      _v_97 = _v_116;
      _v_98 = _v_117;
      _v_99 = _v_118;
      _v_100 = _v_119;
      _v_101 = _v_120;
      _v_102 = _v_121;
      _v_103 = _v_122;
      _v_104 = _v_123;
      _v_105 = _v_124;
      _v_106 = _v_125;
      _v_107 = _v_126;
      u32 _v_127 = 0;
      Term _v_128 = 0;
      Term _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      u32 _v_134 = 0;
      Term _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      Term _v_139 = 0;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      u32 _v_142 = 0;
      Term _v_143 = 0;
      u32 _v_144 = 0;
      u32 _v_145 = 0;
      Term _o_3[19];
      if (spin_33(e, _o_3, _result_29, _result_29 == h20 ? q20 : blk_loc(e.mem, _result_29), _v_89, _v_89 == h20 ? q20 : _v_89 == h17 ? q17 : _v_89 == h15 ? q15 : _v_89 == h13 ? q13 : _v_89 == h5 ? q5 : _v_89 == h4 ? q4 : _v_89 == h3 ? q3 : _v_89 == h2 ? q2 : _v_89 == h1 ? q1 : _v_89 == h0 ? q0 : blk_loc(e.mem, _v_89), _v_90, _v_90 == h20 ? q20 : _v_90 == h17 ? q17 : _v_90 == h15 ? q15 : _v_90 == h13 ? q13 : _v_90 == h5 ? q5 : _v_90 == h4 ? q4 : _v_90 == h3 ? q3 : _v_90 == h2 ? q2 : _v_90 == h1 ? q1 : _v_90 == h0 ? q0 : blk_loc(e.mem, _v_90), _v_91, _v_91 == h20 ? q20 : _v_91 == h17 ? q17 : _v_91 == h15 ? q15 : _v_91 == h13 ? q13 : _v_91 == h5 ? q5 : _v_91 == h4 ? q4 : _v_91 == h3 ? q3 : _v_91 == h2 ? q2 : _v_91 == h1 ? q1 : _v_91 == h0 ? q0 : blk_loc(e.mem, _v_91), _v_92, _v_92 == h20 ? q20 : _v_92 == h17 ? q17 : _v_92 == h15 ? q15 : _v_92 == h13 ? q13 : _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : _v_92 == h2 ? q2 : _v_92 == h1 ? q1 : _v_92 == h0 ? q0 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h20 ? q20 : _v_93 == h17 ? q17 : _v_93 == h15 ? q15 : _v_93 == h13 ? q13 : _v_93 == h5 ? q5 : _v_93 == h4 ? q4 : _v_93 == h3 ? q3 : _v_93 == h2 ? q2 : _v_93 == h1 ? q1 : _v_93 == h0 ? q0 : blk_loc(e.mem, _v_93), _v_94, _v_94 == h20 ? q20 : _v_94 == h17 ? q17 : _v_94 == h15 ? q15 : _v_94 == h13 ? q13 : _v_94 == h5 ? q5 : _v_94 == h4 ? q4 : _v_94 == h3 ? q3 : _v_94 == h2 ? q2 : _v_94 == h1 ? q1 : _v_94 == h0 ? q0 : blk_loc(e.mem, _v_94), _v_95, _v_96, _v_97, _v_98, _v_99, _v_100, _v_101, _v_101 == h20 ? q20 : _v_101 == h17 ? q17 : _v_101 == h15 ? q15 : _v_101 == h13 ? q13 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : _v_101 == h1 ? q1 : _v_101 == h0 ? q0 : blk_loc(e.mem, _v_101), _v_102, _v_103, _v_103 == h20 ? q20 : _v_103 == h17 ? q17 : _v_103 == h15 ? q15 : _v_103 == h13 ? q13 : _v_103 == h5 ? q5 : _v_103 == h4 ? q4 : _v_103 == h3 ? q3 : _v_103 == h2 ? q2 : _v_103 == h1 ? q1 : _v_103 == h0 ? q0 : blk_loc(e.mem, _v_103), _v_104, _v_105, _v_105 == h20 ? q20 : _v_105 == h17 ? q17 : _v_105 == h15 ? q15 : _v_105 == h13 ? q13 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : _v_105 == h1 ? q1 : _v_105 == h0 ? q0 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_127 = _o_3[0];
      _v_128 = _o_3[1];
      _v_129 = _o_3[2];
      _v_130 = _o_3[3];
      _v_131 = _o_3[4];
      _v_132 = _o_3[5];
      _v_133 = _o_3[6];
      _v_134 = _o_3[7];
      _v_135 = _o_3[8];
      _v_136 = _o_3[9];
      _v_137 = _o_3[10];
      _v_138 = _o_3[11];
      _v_139 = _o_3[12];
      _v_140 = _o_3[13];
      _v_141 = _o_3[14];
      _v_142 = _o_3[15];
      _v_143 = _o_3[16];
      _v_144 = _o_3[17];
      _v_145 = _o_3[18];
      _v_52 = _v_127;
      _v_53 = _v_128;
      _v_54 = _v_129;
      _v_55 = _v_130;
      _v_56 = _v_131;
      _v_57 = _v_132;
      _v_58 = _v_133;
      _v_59 = _v_134;
      _v_60 = _v_135;
      _v_61 = _v_136;
      _v_62 = _v_137;
      _v_63 = _v_138;
      _v_64 = _v_139;
      _v_65 = _v_140;
      _v_66 = _v_141;
      _v_67 = _v_142;
      _v_68 = _v_143;
      _v_69 = _v_144;
      _v_70 = _v_145;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  o[18] = _v_70;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_0 = r2;
  Term _aux_0 = r3;
  u32 _capacity_0 = r4;
  Term _depth_0 = r5;
  u32 _high_0 = r6;
  u32 _replacement_2 = r7;
  Term _replacement_3 = r8;
  Term _result_0 = r9;
  Term _result_1 = r10;
  Term _result_2 = r11;
  Term _result_3 = r12;
  u32 _result_4 = r13;
  u32 _result_5 = r14;
  Term _result_6 = r15;
  u32 _result_7 = r16;
  u32 _result_8 = r17;
  WL_SPIN
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_1[10];
    if (spin_34(e, _o_1, _id_1, _tick_1, _main_0, _main_0 == h2 ? q2 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h3 ? q3 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h9 ? q9 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h10 ? q10 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h11 ? q11 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h12 ? q12 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _replacement_2, _replacement_3, _replacement_3 == h8 ? q8 : blk_loc(e.mem, _replacement_3), _result_4, _result_5, _result_6, _result_6 == h15 ? q15 : blk_loc(e.mem, _result_6), _result_7, _result_8) == 0) {
      return 0;
    }
    _v_38 = _o_1[0];
    _v_39 = _o_1[1];
    _v_40 = _o_1[2];
    _v_41 = _o_1[3];
    _v_42 = _o_1[4];
    _v_43 = _o_1[5];
    _v_44 = _o_1[6];
    _v_45 = _o_1[7];
    _v_46 = _o_1[8];
    _v_47 = _o_1[9];
    _v_28 = _v_38;
    _v_29 = _v_39;
    _v_30 = _v_40;
    _v_31 = _v_41;
    _v_32 = _v_42;
    _v_33 = _v_43;
    _v_34 = _v_44;
    _v_35 = _v_45;
    _v_36 = _v_46;
    _v_37 = _v_47;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _include_0 = r0;
  u32 _id_1 = r1;
  u32 _namespace_1 = r2;
  Term _main_1 = r3;
  Term _aux_1 = r4;
  Term _live_1 = r5;
  Term _flags_0 = r6;
  Term _added_1 = r7;
  Term _changed_1 = r8;
  Term _values_1 = r9;
  u32 _flag_0 = r10;
  WL_SPIN
    if (_include_0 == 0) {
      _v_7 = _main_1;
      _v_8 = _aux_1;
      _v_9 = _live_1;
      _v_10 = _flags_0;
      _v_11 = _added_1;
      _v_12 = _changed_1;
      _v_13 = _values_1;
    } else {
      Term _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      Term _o_0[2];
      if (spin_36(e, _o_0, _main_1, _main_1 == h3 ? q3 : blk_loc(e.mem, _main_1), U32_BIN(_id_1, -, 1ull)) == 0) {
        return 0;
      }
      _v_16 = _o_0[0];
      _v_17 = _o_0[1];
      _v_14 = _v_16;
      _v_15 = _v_17;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _o_1[7];
      if (spin_38(e, _o_1, _id_1, _namespace_1, _aux_1, _aux_1 == h4 ? q4 : blk_loc(e.mem, _aux_1), _live_1, _live_1 == h5 ? q5 : blk_loc(e.mem, _live_1), _flags_0, _flags_0 == h6 ? q6 : blk_loc(e.mem, _flags_0), _added_1, _added_1 == h7 ? q7 : blk_loc(e.mem, _added_1), _changed_1, _changed_1 == h8 ? q8 : blk_loc(e.mem, _changed_1), _values_1, _values_1 == h9 ? q9 : blk_loc(e.mem, _values_1), _flag_0, _v_14, _v_14 == h9 ? q9 : _v_14 == h8 ? q8 : _v_14 == h7 ? q7 : _v_14 == h6 ? q6 : _v_14 == h5 ? q5 : _v_14 == h4 ? q4 : _v_14 == h3 ? q3 : blk_loc(e.mem, _v_14), _v_15) == 0) {
        return 0;
      }
      _v_18 = _o_1[0];
      _v_19 = _o_1[1];
      _v_20 = _o_1[2];
      _v_21 = _o_1[3];
      _v_22 = _o_1[4];
      _v_23 = _o_1[5];
      _v_24 = _o_1[6];
      _v_7 = _v_18;
      _v_8 = _v_19;
      _v_9 = _v_20;
      _v_10 = _v_21;
      _v_11 = _v_22;
      _v_12 = _v_23;
      _v_13 = _v_24;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  u32 _v_2 = 0;
  u32 _selection_1 = r0;
  u32 _flag_0 = r1;
  Term _flag_1 = r2;
  WL_SPIN
    if (_selection_1 == 1) {
      if (_flag_0 == 0) {
        _v_2 = 0;
      } else {
        term_sink(e, _flag_1);
        _v_2 = 1;
      }
    } else if (_selection_1 == 2) {
      if (_flag_0 == 1) {
        term_sink(e, _flag_1);
        _v_2 = 0;
      } else {
        term_sink(e, _flag_1);
        _v_2 = 1;
      }
    } else {
      term_sink(e, _flag_1);
      _v_2 = 1;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, Term r18, u32 r19, u32 r20, u32 r21, u32 r22, Term r23, u64 q23, u32 r24, Term r25, u64 q25, u32 r26, Term r27, u64 q27, u32 r28, u32 r29) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h23 = r23;
  Term h25 = r25;
  Term h27 = r27;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _namespace_1 = r0;
  u32 _tick_1 = r1;
  u32 _id_0 = r2;
  u32 _command_0 = r3;
  u32 _command_1 = r4;
  Term _command_2 = r5;
  Term _command_3 = r6;
  u32 _command_4 = r7;
  Term _command_5 = r8;
  u32 _command_6 = r9;
  Term _command_7 = r10;
  Term _result_9 = r11;
  Term _result_10 = r12;
  Term _result_11 = r13;
  Term _result_12 = r14;
  Term _result_13 = r15;
  Term _result_14 = r16;
  u32 _result_15 = r17;
  Term _result_16 = r18;
  u32 _result_17 = r19;
  u32 _result_18 = r20;
  u32 _result_19 = r21;
  u32 _result_20 = r22;
  Term _result_21 = r23;
  u32 _result_22 = r24;
  Term _result_23 = r25;
  u32 _result_24 = r26;
  Term _result_25 = r27;
  u32 _result_26 = r28;
  u32 _result_27 = r29;
  WL_SPIN
    if (_result_18 == 0) {
      term_sink(e, _command_2);
      term_sink(e, _command_3);
      term_sink(e, _command_5);
      term_sink(e, _command_7);
      _v_57 = 0;
      _v_58 = _result_9;
      _v_59 = _result_10;
      _v_60 = _result_11;
      _v_61 = _result_12;
      _v_62 = _result_13;
      _v_63 = _result_14;
      _v_64 = _result_15;
      _v_65 = _result_16;
      _v_66 = _result_17;
      _v_67 = term_pak(CID_NIL, 0);
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
      _v_71 = 0;
      _v_72 = 0;
      _v_73 = 0;
      _v_74 = 0;
      _v_75 = 0;
    } else {
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      u32 _v_85 = 0;
      Term _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      u32 _v_96 = 0;
      Term _v_97 = 0;
      Term _o_1[11];
      if (spin_40(e, _o_1, _namespace_1, _tick_1, _command_0, _command_1, _command_2, _command_2 == h5 ? q5 : blk_loc(e.mem, _command_2), _command_3, _command_3 == h6 ? q6 : blk_loc(e.mem, _command_3), _command_4, _command_5, _command_5 == h8 ? q8 : blk_loc(e.mem, _command_5), _command_6, _command_7, _command_7 == h10 ? q10 : blk_loc(e.mem, _command_7), _result_19, _result_20, _result_21, _result_21 == h23 ? q23 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h25 ? q25 : blk_loc(e.mem, _result_23), _result_24, _result_25, _result_25 == h27 ? q27 : blk_loc(e.mem, _result_25), _result_26, _result_27) == 0) {
        return 0;
      }
      _v_87 = _o_1[0];
      _v_88 = _o_1[1];
      _v_89 = _o_1[2];
      _v_90 = _o_1[3];
      _v_91 = _o_1[4];
      _v_92 = _o_1[5];
      _v_93 = _o_1[6];
      _v_94 = _o_1[7];
      _v_95 = _o_1[8];
      _v_96 = _o_1[9];
      _v_97 = _o_1[10];
      _v_76 = _v_87;
      _v_77 = _v_88;
      _v_78 = _v_89;
      _v_79 = _v_90;
      _v_80 = _v_91;
      _v_81 = _v_92;
      _v_82 = _v_93;
      _v_83 = _v_94;
      _v_84 = _v_95;
      _v_85 = _v_96;
      _v_86 = _v_97;
      u32 _v_98 = 0;
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      Term _v_103 = 0;
      Term _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      u32 _v_109 = 0;
      Term _v_110 = 0;
      u32 _v_111 = 0;
      Term _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_2[19];
      if (spin_41(e, _o_2, _result_9, _result_9 == h11 ? q11 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h12 ? q12 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h13 ? q13 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h14 ? q14 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h15 ? q15 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h16 ? q16 : blk_loc(e.mem, _result_14), _result_15, _result_16, _result_17, _id_0, _v_76, _v_77, _v_78, _v_79, _v_79 == h27 ? q27 : _v_79 == h25 ? q25 : _v_79 == h23 ? q23 : _v_79 == h16 ? q16 : _v_79 == h15 ? q15 : _v_79 == h14 ? q14 : _v_79 == h13 ? q13 : _v_79 == h12 ? q12 : _v_79 == h11 ? q11 : _v_79 == h10 ? q10 : _v_79 == h8 ? q8 : _v_79 == h6 ? q6 : _v_79 == h5 ? q5 : blk_loc(e.mem, _v_79), _v_80, _v_81, _v_81 == h27 ? q27 : _v_81 == h25 ? q25 : _v_81 == h23 ? q23 : _v_81 == h16 ? q16 : _v_81 == h15 ? q15 : _v_81 == h14 ? q14 : _v_81 == h13 ? q13 : _v_81 == h12 ? q12 : _v_81 == h11 ? q11 : _v_81 == h10 ? q10 : _v_81 == h8 ? q8 : _v_81 == h6 ? q6 : _v_81 == h5 ? q5 : blk_loc(e.mem, _v_81), _v_82, _v_83, _v_83 == h27 ? q27 : _v_83 == h25 ? q25 : _v_83 == h23 ? q23 : _v_83 == h16 ? q16 : _v_83 == h15 ? q15 : _v_83 == h14 ? q14 : _v_83 == h13 ? q13 : _v_83 == h12 ? q12 : _v_83 == h11 ? q11 : _v_83 == h10 ? q10 : _v_83 == h8 ? q8 : _v_83 == h6 ? q6 : _v_83 == h5 ? q5 : blk_loc(e.mem, _v_83), _v_84, _v_85, _v_86, _v_86 == h27 ? q27 : _v_86 == h25 ? q25 : _v_86 == h23 ? q23 : _v_86 == h16 ? q16 : _v_86 == h15 ? q15 : _v_86 == h14 ? q14 : _v_86 == h13 ? q13 : _v_86 == h12 ? q12 : _v_86 == h11 ? q11 : _v_86 == h10 ? q10 : _v_86 == h8 ? q8 : _v_86 == h6 ? q6 : _v_86 == h5 ? q5 : blk_loc(e.mem, _v_86)) == 0) {
        return 0;
      }
      _v_98 = _o_2[0];
      _v_99 = _o_2[1];
      _v_100 = _o_2[2];
      _v_101 = _o_2[3];
      _v_102 = _o_2[4];
      _v_103 = _o_2[5];
      _v_104 = _o_2[6];
      _v_105 = _o_2[7];
      _v_106 = _o_2[8];
      _v_107 = _o_2[9];
      _v_108 = _o_2[10];
      _v_109 = _o_2[11];
      _v_110 = _o_2[12];
      _v_111 = _o_2[13];
      _v_112 = _o_2[14];
      _v_113 = _o_2[15];
      _v_114 = _o_2[16];
      _v_115 = _o_2[17];
      _v_116 = _o_2[18];
      _v_57 = _v_98;
      _v_58 = _v_99;
      _v_59 = _v_100;
      _v_60 = _v_101;
      _v_61 = _v_102;
      _v_62 = _v_103;
      _v_63 = _v_104;
      _v_64 = _v_105;
      _v_65 = _v_106;
      _v_66 = _v_107;
      _v_67 = _v_108;
      _v_68 = _v_109;
      _v_69 = _v_110;
      _v_70 = _v_111;
      _v_71 = _v_112;
      _v_72 = _v_113;
      _v_73 = _v_114;
      _v_74 = _v_115;
      _v_75 = _v_116;
    }
  break;
  }
  o[0] = _v_57;
  o[1] = _v_58;
  o[2] = _v_59;
  o[3] = _v_60;
  o[4] = _v_61;
  o[5] = _v_62;
  o[6] = _v_63;
  o[7] = _v_64;
  o[8] = _v_65;
  o[9] = _v_66;
  o[10] = _v_67;
  o[11] = _v_68;
  o[12] = _v_69;
  o[13] = _v_70;
  o[14] = _v_71;
  o[15] = _v_72;
  o[16] = _v_73;
  o[17] = _v_74;
  o[18] = _v_75;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h13 = r13;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  u32 _tick_1 = r2;
  Term _rows_9 = r3;
  Term _rows_10 = r4;
  Term _rows_11 = r5;
  Term _rows_12 = r6;
  Term _rows_13 = r7;
  Term _rows_14 = r8;
  u32 _rows_15 = r9;
  Term _rows_16 = r10;
  u32 _rows_17 = r11;
  u32 _replacement_2 = r12;
  Term _replacement_3 = r13;
  WL_SPIN
    if (_valid_0 == 0) {
      term_sink(e, _replacement_3);
      _v_14 = _rows_9;
      _v_15 = _rows_10;
      _v_16 = _rows_11;
      _v_17 = _rows_12;
      _v_18 = _rows_13;
      _v_19 = _rows_14;
      _v_20 = _rows_15;
      _v_21 = _rows_16;
      _v_22 = _rows_17;
      _v_23 = 0;
    } else {
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      Term _o_2[9];
      if (spin_17(e, _o_2, _rows_11, _rows_11 == h5 ? q5 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h6 ? q6 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h7 ? q7 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h8 ? q8 : blk_loc(e.mem, _rows_14), U32_BIN(_id_1, -, 1ull)) == 0) {
        return 0;
      }
      _v_33 = _o_2[0];
      _v_34 = _o_2[1];
      _v_35 = _o_2[2];
      _v_36 = _o_2[3];
      _v_37 = _o_2[4];
      _v_38 = _o_2[5];
      _v_39 = _o_2[6];
      _v_40 = _o_2[7];
      _v_41 = _o_2[8];
      _v_24 = _v_33;
      _v_25 = _v_34;
      _v_26 = _v_35;
      _v_27 = _v_36;
      _v_28 = _v_37;
      _v_29 = _v_38;
      _v_30 = _v_39;
      _v_31 = _v_40;
      _v_32 = _v_41;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      Term _o_3[10];
      if (spin_42(e, _o_3, _id_1, _tick_1, _rows_9, _rows_9 == h3 ? q3 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h4 ? q4 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _replacement_2, _replacement_3, _replacement_3 == h13 ? q13 : blk_loc(e.mem, _replacement_3), _v_24, _v_24 == h13 ? q13 : _v_24 == h8 ? q8 : _v_24 == h7 ? q7 : _v_24 == h6 ? q6 : _v_24 == h5 ? q5 : _v_24 == h4 ? q4 : _v_24 == h3 ? q3 : blk_loc(e.mem, _v_24), _v_25, _v_25 == h13 ? q13 : _v_25 == h8 ? q8 : _v_25 == h7 ? q7 : _v_25 == h6 ? q6 : _v_25 == h5 ? q5 : _v_25 == h4 ? q4 : _v_25 == h3 ? q3 : blk_loc(e.mem, _v_25), _v_26, _v_26 == h13 ? q13 : _v_26 == h8 ? q8 : _v_26 == h7 ? q7 : _v_26 == h6 ? q6 : _v_26 == h5 ? q5 : _v_26 == h4 ? q4 : _v_26 == h3 ? q3 : blk_loc(e.mem, _v_26), _v_27, _v_27 == h13 ? q13 : _v_27 == h8 ? q8 : _v_27 == h7 ? q7 : _v_27 == h6 ? q6 : _v_27 == h5 ? q5 : _v_27 == h4 ? q4 : _v_27 == h3 ? q3 : blk_loc(e.mem, _v_27), _v_28, _v_29, _v_30, _v_30 == h13 ? q13 : _v_30 == h8 ? q8 : _v_30 == h7 ? q7 : _v_30 == h6 ? q6 : _v_30 == h5 ? q5 : _v_30 == h4 ? q4 : _v_30 == h3 ? q3 : blk_loc(e.mem, _v_30), _v_31, _v_32) == 0) {
        return 0;
      }
      _v_42 = _o_3[0];
      _v_43 = _o_3[1];
      _v_44 = _o_3[2];
      _v_45 = _o_3[3];
      _v_46 = _o_3[4];
      _v_47 = _o_3[5];
      _v_48 = _o_3[6];
      _v_49 = _o_3[7];
      _v_50 = _o_3[8];
      _v_51 = _o_3[9];
      _v_14 = _v_42;
      _v_15 = _v_43;
      _v_16 = _v_44;
      _v_17 = _v_45;
      _v_18 = _v_46;
      _v_19 = _v_47;
      _v_20 = _v_48;
      _v_21 = _v_49;
      _v_22 = _v_50;
      _v_23 = _v_51;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _changes_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  Term _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  u32 _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  u32 _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  u32 _result_13 = r14;
  Term _result_14 = r15;
  u32 _result_15 = r16;
  Term _result_16 = r17;
  u32 _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      _v_19 = 0;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _changes_0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    } else {
      term_sink(e, _changes_0);
      _v_19 = 1;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _result_10;
      _v_30 = _result_11;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _id_1 = r0;
  u32 _namespace_1 = r1;
  u32 _selection_1 = r2;
  Term _main_1 = r3;
  Term _aux_1 = r4;
  Term _values_1 = r5;
  Term _live_0 = r6;
  Term _added_1 = r7;
  Term _changed_1 = r8;
  u32 _value_0 = r9;
  Term _result_2 = r10;
  u32 _result_3 = r11;
  WL_SPIN
    if (_value_0 == 0) {
      _v_7 = _main_1;
      _v_8 = _aux_1;
      _v_9 = _live_0;
      _v_10 = _result_2;
      _v_11 = _added_1;
      _v_12 = _changed_1;
      _v_13 = _values_1;
    } else {
      Term _v_14 = 0;
      Term _v_15 = 0;
      Term _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _o_1[7];
      if (spin_43(e, _o_1, 1, _id_1, _namespace_1, _main_1, _main_1 == h3 ? q3 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h4 ? q4 : blk_loc(e.mem, _aux_1), _live_0, _live_0 == h6 ? q6 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h10 ? q10 : blk_loc(e.mem, _result_2), _added_1, _added_1 == h7 ? q7 : blk_loc(e.mem, _added_1), _changed_1, _changed_1 == h8 ? q8 : blk_loc(e.mem, _changed_1), _values_1, _values_1 == h5 ? q5 : blk_loc(e.mem, _values_1), _result_3) == 0) {
        return 0;
      }
      _v_14 = _o_1[0];
      _v_15 = _o_1[1];
      _v_16 = _o_1[2];
      _v_17 = _o_1[3];
      _v_18 = _o_1[4];
      _v_19 = _o_1[5];
      _v_20 = _o_1[6];
      _v_7 = _v_14;
      _v_8 = _v_15;
      _v_9 = _v_16;
      _v_10 = _v_17;
      _v_11 = _v_18;
      _v_12 = _v_19;
      _v_13 = _v_20;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_4 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_4 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_50);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_50(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_4 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_5 = blk_at(_columns_0, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_0);
    Term _at_6 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_7 = blk_at(_columns_1, _index_0, 1);
    u32 _c_5 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_6 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _meta_1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _meta_2);
    term_sink(e, _c_6);
    Term _at_8 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_9 = blk_at(_columns_2, _index_0, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _meta_3);
    Term _at_10 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_11 = blk_at(_columns_3, _index_0, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _meta_4);
    _v_57 = _columns_0;
    _v_58 = _columns_1;
    _v_59 = _columns_2;
    _v_60 = _columns_3;
  break;
  }
  o[0] = _v_57;
  o[1] = _v_58;
  o[2] = _v_59;
  o[3] = _v_60;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _row_0 = r9;
  u32 _row_1 = r10;
  Term _row_2 = r11;
  u32 _row_3 = r12;
  Term _row_4 = r13;
  u32 _row_5 = r14;
  Term _row_6 = r15;
  u32 _row_7 = r16;
  u32 _row_8 = r17;
  WL_SPIN
    Term _at_0 = _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0);
    Term _at_1 = blk_at(_rows_0, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_2);
    term_sink(e, _c_1);
    Term _at_2 = _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1);
    Term _at_3 = blk_at(_rows_1, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_3);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_4);
    term_sink(e, _c_3);
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _o_6[4];
    if (spin_53(e, _o_6, _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), U32_BIN(_row_0, -, 1ull), 1, _row_5, _row_6, _row_6 == h15 ? q15 : blk_loc(e.mem, _row_6), _row_7, _row_8) == 0) {
      return 0;
    }
    _v_53 = _o_6[0];
    _v_54 = _o_6[1];
    _v_55 = _o_6[2];
    _v_56 = _o_6[3];
    _v_49 = _v_53;
    _v_50 = _v_54;
    _v_51 = _v_55;
    _v_52 = _v_56;
    _v_40 = _rows_0;
    _v_41 = _rows_1;
    _v_42 = _v_49;
    _v_43 = _v_50;
    _v_44 = _v_51;
    _v_45 = _v_52;
    _v_46 = _rows_6;
    _v_47 = _rows_7;
    _v_48 = _rows_8;
  break;
  }
  o[0] = _v_40;
  o[1] = _v_41;
  o[2] = _v_42;
  o[3] = _v_43;
  o[4] = _v_44;
  o[5] = _v_45;
  o[6] = _v_46;
  o[7] = _v_47;
  o[8] = _v_48;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term h19 = r19;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _owners_0 = r0;
  Term _owners_1 = r1;
  Term _owners_2 = r2;
  Term _owners_3 = r3;
  Term _owners_4 = r4;
  Term _owners_5 = r5;
  u32 _owners_6 = r6;
  Term _owners_7 = r7;
  u32 _owners_8 = r8;
  u32 _result_29 = r9;
  u32 _result_30 = r10;
  Term _result_31 = r11;
  u32 _result_32 = r12;
  Term _result_33 = r13;
  u32 _result_34 = r14;
  Term _result_35 = r15;
  u32 _result_36 = r16;
  u32 _result_37 = r17;
  u32 _result_38 = r18;
  Term _result_39 = r19;
  WL_SPIN
    if (_result_38 == 0) {
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      Term _v_29 = 0;
      u32 _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      Term _v_38 = 0;
      u32 _v_39 = 0;
      Term _o_7[9];
      if (spin_52(e, _o_7, _owners_0, _owners_0 == h0 ? q0 : blk_loc(e.mem, _owners_0), _owners_1, _owners_1 == h1 ? q1 : blk_loc(e.mem, _owners_1), _owners_2, _owners_2 == h2 ? q2 : blk_loc(e.mem, _owners_2), _owners_3, _owners_3 == h3 ? q3 : blk_loc(e.mem, _owners_3), _owners_4, _owners_4 == h4 ? q4 : blk_loc(e.mem, _owners_4), _owners_5, _owners_5 == h5 ? q5 : blk_loc(e.mem, _owners_5), _owners_6, _owners_7, _owners_8, _result_29, _result_30, _result_31, _result_31 == h11 ? q11 : blk_loc(e.mem, _result_31), _result_32, _result_33, _result_33 == h13 ? q13 : blk_loc(e.mem, _result_33), _result_34, _result_35, _result_35 == h15 ? q15 : blk_loc(e.mem, _result_35), _result_36, _result_37) == 0) {
        return 0;
      }
      _v_31 = _o_7[0];
      _v_32 = _o_7[1];
      _v_33 = _o_7[2];
      _v_34 = _o_7[3];
      _v_35 = _o_7[4];
      _v_36 = _o_7[5];
      _v_37 = _o_7[6];
      _v_38 = _o_7[7];
      _v_39 = _o_7[8];
      _v_22 = _v_31;
      _v_23 = _v_32;
      _v_24 = _v_33;
      _v_25 = _v_34;
      _v_26 = _v_35;
      _v_27 = _v_36;
      _v_28 = _v_37;
      _v_29 = _v_38;
      _v_30 = _v_39;
      _v_11 = _v_22;
      _v_12 = _v_23;
      _v_13 = _v_24;
      _v_14 = _v_25;
      _v_15 = _v_26;
      _v_16 = _v_27;
      _v_17 = _v_28;
      _v_18 = _v_29;
      _v_19 = _v_30;
      _v_20 = 1;
      _v_21 = 0;
    } else {
      Term _v_61 = 0;
      Term _v_62 = 0;
      Term _v_63 = 0;
      Term _v_64 = 0;
      Term _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      Term _v_68 = 0;
      u32 _v_69 = 0;
      Term _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      Term _o_8[9];
      if (spin_52(e, _o_8, _owners_0, _owners_0 == h0 ? q0 : blk_loc(e.mem, _owners_0), _owners_1, _owners_1 == h1 ? q1 : blk_loc(e.mem, _owners_1), _owners_2, _owners_2 == h2 ? q2 : blk_loc(e.mem, _owners_2), _owners_3, _owners_3 == h3 ? q3 : blk_loc(e.mem, _owners_3), _owners_4, _owners_4 == h4 ? q4 : blk_loc(e.mem, _owners_4), _owners_5, _owners_5 == h5 ? q5 : blk_loc(e.mem, _owners_5), _owners_6, _owners_7, _owners_8, _result_29, _result_30, _result_31, _result_31 == h11 ? q11 : blk_loc(e.mem, _result_31), _result_32, _result_33, _result_33 == h13 ? q13 : blk_loc(e.mem, _result_33), _result_34, _result_35, _result_35 == h15 ? q15 : blk_loc(e.mem, _result_35), _result_36, _result_37) == 0) {
        return 0;
      }
      _v_70 = _o_8[0];
      _v_71 = _o_8[1];
      _v_72 = _o_8[2];
      _v_73 = _o_8[3];
      _v_74 = _o_8[4];
      _v_75 = _o_8[5];
      _v_76 = _o_8[6];
      _v_77 = _o_8[7];
      _v_78 = _o_8[8];
      _v_61 = _v_70;
      _v_62 = _v_71;
      _v_63 = _v_72;
      _v_64 = _v_73;
      _v_65 = _v_74;
      _v_66 = _v_75;
      _v_67 = _v_76;
      _v_68 = _v_77;
      _v_69 = _v_78;
      _v_11 = _v_61;
      _v_12 = _v_62;
      _v_13 = _v_63;
      _v_14 = _v_64;
      _v_15 = _v_65;
      _v_16 = _v_66;
      _v_17 = _v_67;
      _v_18 = _v_68;
      _v_19 = _v_69;
      _v_20 = 0;
      _v_21 = _result_39;
    }
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  u32 _replacement_0 = r10;
  Term _replacement_1 = r11;
  u32 _tick_1 = r12;
  WL_SPIN
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _o_2[1];
    if (spin_15(e, _o_2, U32_BIN(_id_0, <=, _rows_15), U32_BIN(_id_0, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_70 = _o_2[0];
    _v_69 = _v_70;
    u32 _v_71 = 0;
    Term _o_3[1];
    if (spin_15(e, _o_3, U32_BIN(0ull, <, _id_0), _v_69) == 0) {
      return 0;
    }
    _v_71 = _o_3[0];
    _v_68 = _v_71;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _o_4[10];
    if (spin_46(e, _o_4, _v_68, _id_0, _tick_1, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _replacement_0, _replacement_1, _replacement_1 == h11 ? q11 : blk_loc(e.mem, _replacement_1)) == 0) {
      return 0;
    }
    _v_72 = _o_4[0];
    _v_73 = _o_4[1];
    _v_74 = _o_4[2];
    _v_75 = _o_4[3];
    _v_76 = _o_4[4];
    _v_77 = _o_4[5];
    _v_78 = _o_4[6];
    _v_79 = _o_4[7];
    _v_80 = _o_4[8];
    _v_81 = _o_4[9];
    _v_58 = _v_72;
    _v_59 = _v_73;
    _v_60 = _v_74;
    _v_61 = _v_75;
    _v_62 = _v_76;
    _v_63 = _v_77;
    _v_64 = _v_78;
    _v_65 = _v_79;
    _v_66 = _v_80;
    _v_67 = _v_81;
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  o[5] = _v_63;
  o[6] = _v_64;
  o[7] = _v_65;
  o[8] = _v_66;
  o[9] = _v_67;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  Term _v_103 = 0;
  Term _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  u32 _v_108 = 0;
  Term _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  u32 _v_114 = 0;
  Term _v_115 = 0;
  u32 _v_116 = 0;
  Term _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _namespace_2 = r0;
  u32 _id_1 = r1;
  Term _result_0 = r2;
  Term _result_1 = r3;
  Term _result_2 = r4;
  Term _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  Term _result_7 = r9;
  u32 _result_8 = r10;
  u32 _result_9 = r11;
  WL_SPIN
    if (_result_9 == 1) {
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_4 + 1] = rfc_seal(e, _id_1);
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_5 + 1] = rfc_seal(e, _id_1);
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_5));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINADDED, _nd_4));
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_7);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 2) {
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_8 + 1] = rfc_seal(e, _id_1);
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_8));
      e.mem[_nd_9 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_9);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 3) {
      u64 _nd_10 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_10 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_10 + 1] = rfc_seal(e, _id_1);
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINREMOVED, _nd_10));
      e.mem[_nd_11 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_11);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 0) {
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_pak(CID_NIL, 0);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else {
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_pak(CID_NIL, 0);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    }
  break;
  }
  o[0] = _v_101;
  o[1] = _v_102;
  o[2] = _v_103;
  o[3] = _v_104;
  o[4] = _v_105;
  o[5] = _v_106;
  o[6] = _v_107;
  o[7] = _v_108;
  o[8] = _v_109;
  o[9] = _v_110;
  o[10] = _v_111;
  o[11] = _v_112;
  o[12] = _v_113;
  o[13] = _v_114;
  o[14] = _v_115;
  o[15] = _v_116;
  o[16] = _v_117;
  o[17] = _v_118;
  o[18] = _v_119;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h7 = r7;
  u32 _v_177 = 0;
  u32 _v_178 = 0;
  Term _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  Term _v_184 = 0;
  u32 _v_185 = 0;
  u32 _command_9 = r0;
  u32 _command_10 = r1;
  Term _command_11 = r2;
  Term _command_12 = r3;
  u32 _command_13 = r4;
  Term _command_14 = r5;
  u32 _command_15 = r6;
  Term _command_16 = r7;
  WL_SPIN
    if (_command_9 == 0) {
      _v_177 = 0;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = _command_12;
      _v_181 = _command_13;
      _v_182 = _command_14;
      _v_183 = _command_15;
      _v_184 = _command_16;
      _v_185 = _command_10;
    } else if (_command_9 == 1) {
      _v_177 = 1;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 2) {
      _v_177 = 2;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 3) {
      _v_177 = 3;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 4) {
      _v_177 = 4;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else {
      _v_177 = 5;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    }
  break;
  }
  o[0] = _v_177;
  o[1] = _v_178;
  o[2] = _v_179;
  o[3] = _v_180;
  o[4] = _v_181;
  o[5] = _v_182;
  o[6] = _v_183;
  o[7] = _v_184;
  o[8] = _v_185;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  u32 _v_205 = 0;
  Term _v_206 = 0;
  Term _v_207 = 0;
  Term _v_208 = 0;
  Term _v_209 = 0;
  Term _v_210 = 0;
  Term _v_211 = 0;
  u32 _v_212 = 0;
  Term _v_213 = 0;
  u32 _v_214 = 0;
  Term _v_215 = 0;
  u32 _v_216 = 0;
  Term _v_217 = 0;
  u32 _v_218 = 0;
  Term _v_219 = 0;
  u32 _v_220 = 0;
  Term _v_221 = 0;
  u32 _v_222 = 0;
  u32 _v_223 = 0;
  u32 _namespace_3 = r0;
  u32 _tick_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  u32 _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  Term _result_13 = r14;
  u32 _result_14 = r15;
  Term _result_15 = r16;
  u32 _result_16 = r17;
  Term _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    Term _v_224 = 0;
    Term _v_225 = 0;
    Term _v_226 = 0;
    Term _v_227 = 0;
    Term _v_228 = 0;
    Term _v_229 = 0;
    u32 _v_230 = 0;
    Term _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    u32 _v_235 = 0;
    Term _v_236 = 0;
    u32 _v_237 = 0;
    Term _v_238 = 0;
    u32 _v_239 = 0;
    Term _v_240 = 0;
    u32 _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    Term _v_244 = 0;
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    Term _v_248 = 0;
    u32 _v_249 = 0;
    Term _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    Term _v_255 = 0;
    u32 _v_256 = 0;
    Term _v_257 = 0;
    u32 _v_258 = 0;
    Term _v_259 = 0;
    u32 _v_260 = 0;
    u32 _v_261 = 0;
    Term _o_10[19];
    if (spin_14(e, _o_10, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26, _result_18) == 0) {
      return 0;
    }
    _v_243 = _o_10[0];
    _v_244 = _o_10[1];
    _v_245 = _o_10[2];
    _v_246 = _o_10[3];
    _v_247 = _o_10[4];
    _v_248 = _o_10[5];
    _v_249 = _o_10[6];
    _v_250 = _o_10[7];
    _v_251 = _o_10[8];
    _v_252 = _o_10[9];
    _v_253 = _o_10[10];
    _v_254 = _o_10[11];
    _v_255 = _o_10[12];
    _v_256 = _o_10[13];
    _v_257 = _o_10[14];
    _v_258 = _o_10[15];
    _v_259 = _o_10[16];
    _v_260 = _o_10[17];
    _v_261 = _o_10[18];
    _v_224 = _v_243;
    _v_225 = _v_244;
    _v_226 = _v_245;
    _v_227 = _v_246;
    _v_228 = _v_247;
    _v_229 = _v_248;
    _v_230 = _v_249;
    _v_231 = _v_250;
    _v_232 = _v_251;
    _v_233 = _v_252;
    _v_234 = _v_253;
    _v_235 = _v_254;
    _v_236 = _v_255;
    _v_237 = _v_256;
    _v_238 = _v_257;
    _v_239 = _v_258;
    _v_240 = _v_259;
    _v_241 = _v_260;
    _v_242 = _v_261;
    u32 _v_262 = 0;
    Term _v_263 = 0;
    Term _v_264 = 0;
    Term _v_265 = 0;
    Term _v_266 = 0;
    Term _v_267 = 0;
    Term _v_268 = 0;
    u32 _v_269 = 0;
    Term _v_270 = 0;
    u32 _v_271 = 0;
    Term _v_272 = 0;
    u32 _v_273 = 0;
    Term _v_274 = 0;
    u32 _v_275 = 0;
    Term _v_276 = 0;
    u32 _v_277 = 0;
    Term _v_278 = 0;
    u32 _v_279 = 0;
    u32 _v_280 = 0;
    Term _o_11[19];
    if (spin_45(e, _o_11, _namespace_3, _tick_2, _result_18, _result_10, _result_11, _result_12, _result_12 == h13 ? q13 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h14 ? q14 : blk_loc(e.mem, _result_13), _result_14, _result_15, _result_15 == h16 ? q16 : blk_loc(e.mem, _result_15), _result_16, _result_17, _result_17 == h18 ? q18 : blk_loc(e.mem, _result_17), _v_224, _v_224 == h18 ? q18 : _v_224 == h16 ? q16 : _v_224 == h14 ? q14 : _v_224 == h13 ? q13 : _v_224 == h7 ? q7 : _v_224 == h6 ? q6 : _v_224 == h5 ? q5 : _v_224 == h4 ? q4 : _v_224 == h3 ? q3 : _v_224 == h2 ? q2 : blk_loc(e.mem, _v_224), _v_225, _v_225 == h18 ? q18 : _v_225 == h16 ? q16 : _v_225 == h14 ? q14 : _v_225 == h13 ? q13 : _v_225 == h7 ? q7 : _v_225 == h6 ? q6 : _v_225 == h5 ? q5 : _v_225 == h4 ? q4 : _v_225 == h3 ? q3 : _v_225 == h2 ? q2 : blk_loc(e.mem, _v_225), _v_226, _v_226 == h18 ? q18 : _v_226 == h16 ? q16 : _v_226 == h14 ? q14 : _v_226 == h13 ? q13 : _v_226 == h7 ? q7 : _v_226 == h6 ? q6 : _v_226 == h5 ? q5 : _v_226 == h4 ? q4 : _v_226 == h3 ? q3 : _v_226 == h2 ? q2 : blk_loc(e.mem, _v_226), _v_227, _v_227 == h18 ? q18 : _v_227 == h16 ? q16 : _v_227 == h14 ? q14 : _v_227 == h13 ? q13 : _v_227 == h7 ? q7 : _v_227 == h6 ? q6 : _v_227 == h5 ? q5 : _v_227 == h4 ? q4 : _v_227 == h3 ? q3 : _v_227 == h2 ? q2 : blk_loc(e.mem, _v_227), _v_228, _v_228 == h18 ? q18 : _v_228 == h16 ? q16 : _v_228 == h14 ? q14 : _v_228 == h13 ? q13 : _v_228 == h7 ? q7 : _v_228 == h6 ? q6 : _v_228 == h5 ? q5 : _v_228 == h4 ? q4 : _v_228 == h3 ? q3 : _v_228 == h2 ? q2 : blk_loc(e.mem, _v_228), _v_229, _v_229 == h18 ? q18 : _v_229 == h16 ? q16 : _v_229 == h14 ? q14 : _v_229 == h13 ? q13 : _v_229 == h7 ? q7 : _v_229 == h6 ? q6 : _v_229 == h5 ? q5 : _v_229 == h4 ? q4 : _v_229 == h3 ? q3 : _v_229 == h2 ? q2 : blk_loc(e.mem, _v_229), _v_230, _v_231, _v_232, _v_233, _v_234, _v_235, _v_236, _v_236 == h18 ? q18 : _v_236 == h16 ? q16 : _v_236 == h14 ? q14 : _v_236 == h13 ? q13 : _v_236 == h7 ? q7 : _v_236 == h6 ? q6 : _v_236 == h5 ? q5 : _v_236 == h4 ? q4 : _v_236 == h3 ? q3 : _v_236 == h2 ? q2 : blk_loc(e.mem, _v_236), _v_237, _v_238, _v_238 == h18 ? q18 : _v_238 == h16 ? q16 : _v_238 == h14 ? q14 : _v_238 == h13 ? q13 : _v_238 == h7 ? q7 : _v_238 == h6 ? q6 : _v_238 == h5 ? q5 : _v_238 == h4 ? q4 : _v_238 == h3 ? q3 : _v_238 == h2 ? q2 : blk_loc(e.mem, _v_238), _v_239, _v_240, _v_240 == h18 ? q18 : _v_240 == h16 ? q16 : _v_240 == h14 ? q14 : _v_240 == h13 ? q13 : _v_240 == h7 ? q7 : _v_240 == h6 ? q6 : _v_240 == h5 ? q5 : _v_240 == h4 ? q4 : _v_240 == h3 ? q3 : _v_240 == h2 ? q2 : blk_loc(e.mem, _v_240), _v_241, _v_242) == 0) {
      return 0;
    }
    _v_262 = _o_11[0];
    _v_263 = _o_11[1];
    _v_264 = _o_11[2];
    _v_265 = _o_11[3];
    _v_266 = _o_11[4];
    _v_267 = _o_11[5];
    _v_268 = _o_11[6];
    _v_269 = _o_11[7];
    _v_270 = _o_11[8];
    _v_271 = _o_11[9];
    _v_272 = _o_11[10];
    _v_273 = _o_11[11];
    _v_274 = _o_11[12];
    _v_275 = _o_11[13];
    _v_276 = _o_11[14];
    _v_277 = _o_11[15];
    _v_278 = _o_11[16];
    _v_279 = _o_11[17];
    _v_280 = _o_11[18];
    _v_205 = _v_262;
    _v_206 = _v_263;
    _v_207 = _v_264;
    _v_208 = _v_265;
    _v_209 = _v_266;
    _v_210 = _v_267;
    _v_211 = _v_268;
    _v_212 = _v_269;
    _v_213 = _v_270;
    _v_214 = _v_271;
    _v_215 = _v_272;
    _v_216 = _v_273;
    _v_217 = _v_274;
    _v_218 = _v_275;
    _v_219 = _v_276;
    _v_220 = _v_277;
    _v_221 = _v_278;
    _v_222 = _v_279;
    _v_223 = _v_280;
  break;
  }
  o[0] = _v_205;
  o[1] = _v_206;
  o[2] = _v_207;
  o[3] = _v_208;
  o[4] = _v_209;
  o[5] = _v_210;
  o[6] = _v_211;
  o[7] = _v_212;
  o[8] = _v_213;
  o[9] = _v_214;
  o[10] = _v_215;
  o[11] = _v_216;
  o[12] = _v_217;
  o[13] = _v_218;
  o[14] = _v_219;
  o[15] = _v_220;
  o[16] = _v_221;
  o[17] = _v_222;
  o[18] = _v_223;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _id_1 = r0;
  u32 _namespace_1 = r1;
  u32 _selection_1 = r2;
  Term _main_0 = r3;
  Term _aux_0 = r4;
  Term _values_0 = r5;
  Term _flags_0 = r6;
  Term _added_0 = r7;
  Term _changed_0 = r8;
  Term _result_0 = r9;
  u32 _result_1 = r10;
  WL_SPIN
    if (_result_1 == 0) {
      _v_7 = _main_0;
      _v_8 = _aux_0;
      _v_9 = _result_0;
      _v_10 = _flags_0;
      _v_11 = _added_0;
      _v_12 = _changed_0;
      _v_13 = _values_0;
    } else {
      Term _at_2 = _flags_0 == h6 ? q6 : blk_loc(e.mem, _flags_0);
      Term _at_3 = blk_at(_flags_0, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
      u32 _o_0 = 0;
      if (_c_1 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
      }
      Term _v_14 = 0;
      Term _v_15 = 0;
      Term _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _o_1[7];
      if (spin_48(e, _o_1, _id_1, _namespace_1, _selection_1, _main_0, _main_0 == h3 ? q3 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h4 ? q4 : blk_loc(e.mem, _aux_0), _values_0, _values_0 == h5 ? q5 : blk_loc(e.mem, _values_0), _result_0, _result_0 == h9 ? q9 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h7 ? q7 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h8 ? q8 : blk_loc(e.mem, _changed_0), 1, _flags_0, _flags_0 == h6 ? q6 : blk_loc(e.mem, _flags_0), _o_0) == 0) {
        return 0;
      }
      _v_14 = _o_1[0];
      _v_15 = _o_1[1];
      _v_16 = _o_1[2];
      _v_17 = _o_1[3];
      _v_18 = _o_1[4];
      _v_19 = _o_1[5];
      _v_20 = _o_1[6];
      _v_7 = _v_14;
      _v_8 = _v_15;
      _v_9 = _v_16;
      _v_10 = _v_17;
      _v_11 = _v_18;
      _v_12 = _v_19;
      _v_13 = _v_20;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_69(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_189 = 0;
  Term _v_190 = 0;
  Term _v_191 = 0;
  Term _v_192 = 0;
  u32 _v_193 = 0;
  u32 _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  u32 _v_197 = 0;
  Term _live_2 = r0;
  Term _flags_2 = r1;
  Term _added_2 = r2;
  u32 _l_2 = r3;
  u32 _f_2 = r4;
  Term _f_3 = r5;
  u32 _a_0 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  WL_SPIN
    _v_189 = _live_2;
    _v_190 = _flags_2;
    _v_191 = _added_2;
    _v_192 = _result_7;
    _v_193 = _l_2;
    _v_194 = _f_2;
    _v_195 = _f_3;
    _v_196 = _a_0;
    _v_197 = _result_8;
  break;
  }
  o[0] = _v_189;
  o[1] = _v_190;
  o[2] = _v_191;
  o[3] = _v_192;
  o[4] = _v_193;
  o[5] = _v_194;
  o[6] = _v_195;
  o[7] = _v_196;
  o[8] = _v_197;
  return 1;
}

INLINE Term spin_68(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  Term _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  Term _live_1 = r0;
  Term _flags_1 = r1;
  Term _changed_2 = r2;
  u32 _index_3 = r3;
  u32 _l_1 = r4;
  u32 _f_0 = r5;
  Term _f_1 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  WL_SPIN
    Term _at_6 = _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2);
    Term _at_7 = blk_at(_changed_2, _index_3, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    Term _v_180 = 0;
    Term _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    u32 _v_184 = 0;
    u32 _v_185 = 0;
    Term _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    Term _o_2[9];
    if (spin_69(e, _o_2, _live_1, _live_1 == h0 ? q0 : blk_loc(e.mem, _live_1), _flags_1, _flags_1 == h1 ? q1 : blk_loc(e.mem, _flags_1), _result_5, _result_5 == h7 ? q7 : blk_loc(e.mem, _result_5), _l_1, _f_0, _f_1, _f_1 == h6 ? q6 : blk_loc(e.mem, _f_1), _result_6, _changed_2, _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2), _c_4) == 0) {
      return 0;
    }
    _v_180 = _o_2[0];
    _v_181 = _o_2[1];
    _v_182 = _o_2[2];
    _v_183 = _o_2[3];
    _v_184 = _o_2[4];
    _v_185 = _o_2[5];
    _v_186 = _o_2[6];
    _v_187 = _o_2[7];
    _v_188 = _o_2[8];
    _v_171 = _v_180;
    _v_172 = _v_181;
    _v_173 = _v_182;
    _v_174 = _v_183;
    _v_175 = _v_184;
    _v_176 = _v_185;
    _v_177 = _v_186;
    _v_178 = _v_187;
    _v_179 = _v_188;
  break;
  }
  o[0] = _v_171;
  o[1] = _v_172;
  o[2] = _v_173;
  o[3] = _v_174;
  o[4] = _v_175;
  o[5] = _v_176;
  o[6] = _v_177;
  o[7] = _v_178;
  o[8] = _v_179;
  return 1;
}

INLINE Term spin_67(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_153 = 0;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  Term _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  Term _live_0 = r0;
  Term _added_1 = r1;
  Term _changed_1 = r2;
  u32 _index_2 = r3;
  u32 _l_0 = r4;
  Term _result_2 = r5;
  u32 _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    Term _at_4 = _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1);
    Term _at_5 = blk_at(_added_1, _index_2, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_162 = 0;
    Term _v_163 = 0;
    Term _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    Term _o_3[9];
    if (spin_68(e, _o_3, _live_0, _live_0 == h0 ? q0 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h5 ? q5 : blk_loc(e.mem, _result_2), _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _index_2, _l_0, _result_3, _result_4, _result_4 == h7 ? q7 : blk_loc(e.mem, _result_4), _added_1, _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1), _c_3) == 0) {
      return 0;
    }
    _v_162 = _o_3[0];
    _v_163 = _o_3[1];
    _v_164 = _o_3[2];
    _v_165 = _o_3[3];
    _v_166 = _o_3[4];
    _v_167 = _o_3[5];
    _v_168 = _o_3[6];
    _v_169 = _o_3[7];
    _v_170 = _o_3[8];
    _v_153 = _v_162;
    _v_154 = _v_163;
    _v_155 = _v_164;
    _v_156 = _v_165;
    _v_157 = _v_166;
    _v_158 = _v_167;
    _v_159 = _v_168;
    _v_160 = _v_169;
    _v_161 = _v_170;
  break;
  }
  o[0] = _v_153;
  o[1] = _v_154;
  o[2] = _v_155;
  o[3] = _v_156;
  o[4] = _v_157;
  o[5] = _v_158;
  o[6] = _v_159;
  o[7] = _v_160;
  o[8] = _v_161;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term _v_135 = 0;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  Term _v_141 = 0;
  u32 _v_142 = 0;
  u32 _v_143 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  u32 _index_1 = r3;
  Term _result_0 = r4;
  u32 _result_1 = r5;
  WL_SPIN
    Term _at_2 = _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0);
    Term _at_3 = blk_at(_flags_0, _index_1, 1);
    u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
    Term _v_144 = 0;
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    Term _o_4[9];
    if (spin_67(e, _o_4, _result_0, _result_0 == h4 ? q4 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h1 ? q1 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), _index_1, _result_1, _flags_0, _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0), _c_1, _c_2, _c_2 == h4 ? q4 : _c_2 == h2 ? q2 : _c_2 == h1 ? q1 : _c_2 == h0 ? q0 : blk_loc(e.mem, _c_2)) == 0) {
      return 0;
    }
    _v_144 = _o_4[0];
    _v_145 = _o_4[1];
    _v_146 = _o_4[2];
    _v_147 = _o_4[3];
    _v_148 = _o_4[4];
    _v_149 = _o_4[5];
    _v_150 = _o_4[6];
    _v_151 = _o_4[7];
    _v_152 = _o_4[8];
    _v_135 = _v_144;
    _v_136 = _v_145;
    _v_137 = _v_146;
    _v_138 = _v_147;
    _v_139 = _v_148;
    _v_140 = _v_149;
    _v_141 = _v_150;
    _v_142 = _v_151;
    _v_143 = _v_152;
  break;
  }
  o[0] = _v_135;
  o[1] = _v_136;
  o[2] = _v_137;
  o[3] = _v_138;
  o[4] = _v_139;
  o[5] = _v_140;
  o[6] = _v_141;
  o[7] = _v_142;
  o[8] = _v_143;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  u32 _v_121 = 0;
  u32 _v_122 = 0;
  Term _v_123 = 0;
  u32 _v_124 = 0;
  u32 _v_125 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_126 = 0;
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    Term _o_5[9];
    if (spin_66(e, _o_5, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _index_0, _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_126 = _o_5[0];
    _v_127 = _o_5[1];
    _v_128 = _o_5[2];
    _v_129 = _o_5[3];
    _v_130 = _o_5[4];
    _v_131 = _o_5[5];
    _v_132 = _o_5[6];
    _v_133 = _o_5[7];
    _v_134 = _o_5[8];
    _v_117 = _v_126;
    _v_118 = _v_127;
    _v_119 = _v_128;
    _v_120 = _v_129;
    _v_121 = _v_130;
    _v_122 = _v_131;
    _v_123 = _v_132;
    _v_124 = _v_133;
    _v_125 = _v_134;
  break;
  }
  o[0] = _v_117;
  o[1] = _v_118;
  o[2] = _v_119;
  o[3] = _v_120;
  o[4] = _v_121;
  o[5] = _v_122;
  o[6] = _v_123;
  o[7] = _v_124;
  o[8] = _v_125;
  return 1;
}

INLINE Term spin_73(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, Term r12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h16 = r16;
  Term _v_331 = 0;
  Term _v_332 = 0;
  Term _v_333 = 0;
  Term _v_334 = 0;
  Term _v_335 = 0;
  Term _v_336 = 0;
  u32 _v_337 = 0;
  Term _v_338 = 0;
  u32 _v_339 = 0;
  u32 _v_340 = 0;
  u32 _v_341 = 0;
  u32 _v_342 = 0;
  Term _v_343 = 0;
  u32 _v_344 = 0;
  Term _v_345 = 0;
  u32 _v_346 = 0;
  Term _v_347 = 0;
  u32 _v_348 = 0;
  u32 _v_349 = 0;
  u32 _id_5 = r0;
  Term _main_2 = r1;
  u32 _value_2 = r2;
  Term _value_3 = r3;
  Term _aux_2 = r4;
  u32 _av_0 = r5;
  Term _av_1 = r6;
  Term _metadata_8 = r7;
  Term _metadata_9 = r8;
  Term _metadata_10 = r9;
  Term _metadata_11 = r10;
  u32 _capacity_3 = r11;
  Term _depth_3 = r12;
  u32 _high_3 = r13;
  u32 _meta_10 = r14;
  u32 _meta_11 = r15;
  Term _meta_12 = r16;
  u32 _meta_13 = r17;
  u32 _meta_14 = r18;
  WL_SPIN
    _v_331 = _main_2;
    _v_332 = _aux_2;
    _v_333 = _metadata_8;
    _v_334 = _metadata_9;
    _v_335 = _metadata_10;
    _v_336 = _metadata_11;
    _v_337 = _capacity_3;
    _v_338 = _depth_3;
    _v_339 = _high_3;
    _v_340 = 1;
    _v_341 = _id_5;
    _v_342 = _value_2;
    _v_343 = _value_3;
    _v_344 = _av_0;
    _v_345 = _av_1;
    _v_346 = _meta_11;
    _v_347 = _meta_12;
    _v_348 = _meta_13;
    _v_349 = _meta_14;
  break;
  }
  o[0] = _v_331;
  o[1] = _v_332;
  o[2] = _v_333;
  o[3] = _v_334;
  o[4] = _v_335;
  o[5] = _v_336;
  o[6] = _v_337;
  o[7] = _v_338;
  o[8] = _v_339;
  o[9] = _v_340;
  o[10] = _v_341;
  o[11] = _v_342;
  o[12] = _v_343;
  o[13] = _v_344;
  o[14] = _v_345;
  o[15] = _v_346;
  o[16] = _v_347;
  o[17] = _v_348;
  o[18] = _v_349;
  return 1;
}

INLINE Term spin_72(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_293 = 0;
  Term _v_294 = 0;
  Term _v_295 = 0;
  Term _v_296 = 0;
  Term _v_297 = 0;
  Term _v_298 = 0;
  u32 _v_299 = 0;
  Term _v_300 = 0;
  u32 _v_301 = 0;
  u32 _v_302 = 0;
  u32 _v_303 = 0;
  u32 _v_304 = 0;
  Term _v_305 = 0;
  u32 _v_306 = 0;
  Term _v_307 = 0;
  u32 _v_308 = 0;
  Term _v_309 = 0;
  u32 _v_310 = 0;
  u32 _v_311 = 0;
  u32 _id_4 = r0;
  Term _main_1 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_2 = r8;
  Term _depth_2 = r9;
  u32 _high_2 = r10;
  u32 _meta_5 = r11;
  u32 _meta_6 = r12;
  Term _meta_7 = r13;
  u32 _meta_8 = r14;
  u32 _meta_9 = r15;
  Term _result_21 = r16;
  u32 _result_22 = r17;
  Term _result_23 = r18;
  WL_SPIN
    Term _v_312 = 0;
    Term _v_313 = 0;
    Term _v_314 = 0;
    Term _v_315 = 0;
    Term _v_316 = 0;
    Term _v_317 = 0;
    u32 _v_318 = 0;
    Term _v_319 = 0;
    u32 _v_320 = 0;
    u32 _v_321 = 0;
    u32 _v_322 = 0;
    u32 _v_323 = 0;
    Term _v_324 = 0;
    u32 _v_325 = 0;
    Term _v_326 = 0;
    u32 _v_327 = 0;
    Term _v_328 = 0;
    u32 _v_329 = 0;
    u32 _v_330 = 0;
    Term _o_7[19];
    if (spin_73(e, _o_7, _id_4, _main_1, _main_1 == h1 ? q1 : blk_loc(e.mem, _main_1), _value_0, _value_1, _value_1 == h3 ? q3 : blk_loc(e.mem, _value_1), _result_21, _result_21 == h16 ? q16 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h18 ? q18 : blk_loc(e.mem, _result_23), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_2, _depth_2, _high_2, _meta_5, _meta_6, _meta_7, _meta_7 == h13 ? q13 : blk_loc(e.mem, _meta_7), _meta_8, _meta_9) == 0) {
      return 0;
    }
    _v_312 = _o_7[0];
    _v_313 = _o_7[1];
    _v_314 = _o_7[2];
    _v_315 = _o_7[3];
    _v_316 = _o_7[4];
    _v_317 = _o_7[5];
    _v_318 = _o_7[6];
    _v_319 = _o_7[7];
    _v_320 = _o_7[8];
    _v_321 = _o_7[9];
    _v_322 = _o_7[10];
    _v_323 = _o_7[11];
    _v_324 = _o_7[12];
    _v_325 = _o_7[13];
    _v_326 = _o_7[14];
    _v_327 = _o_7[15];
    _v_328 = _o_7[16];
    _v_329 = _o_7[17];
    _v_330 = _o_7[18];
    _v_293 = _v_312;
    _v_294 = _v_313;
    _v_295 = _v_314;
    _v_296 = _v_315;
    _v_297 = _v_316;
    _v_298 = _v_317;
    _v_299 = _v_318;
    _v_300 = _v_319;
    _v_301 = _v_320;
    _v_302 = _v_321;
    _v_303 = _v_322;
    _v_304 = _v_323;
    _v_305 = _v_324;
    _v_306 = _v_325;
    _v_307 = _v_326;
    _v_308 = _v_327;
    _v_309 = _v_328;
    _v_310 = _v_329;
    _v_311 = _v_330;
  break;
  }
  o[0] = _v_293;
  o[1] = _v_294;
  o[2] = _v_295;
  o[3] = _v_296;
  o[4] = _v_297;
  o[5] = _v_298;
  o[6] = _v_299;
  o[7] = _v_300;
  o[8] = _v_301;
  o[9] = _v_302;
  o[10] = _v_303;
  o[11] = _v_304;
  o[12] = _v_305;
  o[13] = _v_306;
  o[14] = _v_307;
  o[15] = _v_308;
  o[16] = _v_309;
  o[17] = _v_310;
  o[18] = _v_311;
  return 1;
}

INLINE Term spin_71(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_255 = 0;
  Term _v_256 = 0;
  Term _v_257 = 0;
  Term _v_258 = 0;
  Term _v_259 = 0;
  Term _v_260 = 0;
  u32 _v_261 = 0;
  Term _v_262 = 0;
  u32 _v_263 = 0;
  u32 _v_264 = 0;
  u32 _v_265 = 0;
  u32 _v_266 = 0;
  Term _v_267 = 0;
  u32 _v_268 = 0;
  Term _v_269 = 0;
  u32 _v_270 = 0;
  Term _v_271 = 0;
  u32 _v_272 = 0;
  u32 _v_273 = 0;
  u32 _id_3 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _meta_0 = r9;
  u32 _meta_1 = r10;
  Term _meta_2 = r11;
  u32 _meta_3 = r12;
  u32 _meta_4 = r13;
  Term _result_18 = r14;
  u32 _result_19 = r15;
  Term _result_20 = r16;
  WL_SPIN
    Term _at_10 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
    Term _at_11 = blk_at(_aux_1, U32_BIN(_id_3, -, 1ull), 1);
    u32 _c_7 = blk_read(e.mem, 1, _at_10, _at_11 + 0);
    Term _c_8 = e.mem[_at_10 + _at_11 + 1];
    blk_write(e.mem, 1, _at_10, _at_11 + 0, 0);
    blk_write(e.mem, 1, _at_10, _at_11 + 1, 0);
    Term _v_274 = 0;
    Term _v_275 = 0;
    Term _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    u32 _v_280 = 0;
    Term _v_281 = 0;
    u32 _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    Term _v_286 = 0;
    u32 _v_287 = 0;
    Term _v_288 = 0;
    u32 _v_289 = 0;
    Term _v_290 = 0;
    u32 _v_291 = 0;
    u32 _v_292 = 0;
    Term _o_8[19];
    if (spin_72(e, _o_8, _id_3, _result_18, _result_18 == h14 ? q14 : blk_loc(e.mem, _result_18), _result_19, _result_20, _result_20 == h16 ? q16 : blk_loc(e.mem, _result_20), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _meta_1, _meta_2, _meta_2 == h11 ? q11 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _c_7, _c_8, _c_8 == h16 ? q16 : _c_8 == h14 ? q14 : _c_8 == h11 ? q11 : _c_8 == h5 ? q5 : _c_8 == h4 ? q4 : _c_8 == h3 ? q3 : _c_8 == h2 ? q2 : _c_8 == h1 ? q1 : blk_loc(e.mem, _c_8)) == 0) {
      return 0;
    }
    _v_274 = _o_8[0];
    _v_275 = _o_8[1];
    _v_276 = _o_8[2];
    _v_277 = _o_8[3];
    _v_278 = _o_8[4];
    _v_279 = _o_8[5];
    _v_280 = _o_8[6];
    _v_281 = _o_8[7];
    _v_282 = _o_8[8];
    _v_283 = _o_8[9];
    _v_284 = _o_8[10];
    _v_285 = _o_8[11];
    _v_286 = _o_8[12];
    _v_287 = _o_8[13];
    _v_288 = _o_8[14];
    _v_289 = _o_8[15];
    _v_290 = _o_8[16];
    _v_291 = _o_8[17];
    _v_292 = _o_8[18];
    _v_255 = _v_274;
    _v_256 = _v_275;
    _v_257 = _v_276;
    _v_258 = _v_277;
    _v_259 = _v_278;
    _v_260 = _v_279;
    _v_261 = _v_280;
    _v_262 = _v_281;
    _v_263 = _v_282;
    _v_264 = _v_283;
    _v_265 = _v_284;
    _v_266 = _v_285;
    _v_267 = _v_286;
    _v_268 = _v_287;
    _v_269 = _v_288;
    _v_270 = _v_289;
    _v_271 = _v_290;
    _v_272 = _v_291;
    _v_273 = _v_292;
  break;
  }
  o[0] = _v_255;
  o[1] = _v_256;
  o[2] = _v_257;
  o[3] = _v_258;
  o[4] = _v_259;
  o[5] = _v_260;
  o[6] = _v_261;
  o[7] = _v_262;
  o[8] = _v_263;
  o[9] = _v_264;
  o[10] = _v_265;
  o[11] = _v_266;
  o[12] = _v_267;
  o[13] = _v_268;
  o[14] = _v_269;
  o[15] = _v_270;
  o[16] = _v_271;
  o[17] = _v_272;
  o[18] = _v_273;
  return 1;
}

INLINE Term spin_70(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term _v_217 = 0;
  Term _v_218 = 0;
  Term _v_219 = 0;
  Term _v_220 = 0;
  Term _v_221 = 0;
  Term _v_222 = 0;
  u32 _v_223 = 0;
  Term _v_224 = 0;
  u32 _v_225 = 0;
  u32 _v_226 = 0;
  u32 _v_227 = 0;
  u32 _v_228 = 0;
  Term _v_229 = 0;
  u32 _v_230 = 0;
  Term _v_231 = 0;
  u32 _v_232 = 0;
  Term _v_233 = 0;
  u32 _v_234 = 0;
  u32 _v_235 = 0;
  u32 _id_2 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  u32 _capacity_0 = r3;
  Term _depth_0 = r4;
  u32 _high_0 = r5;
  Term _result_9 = r6;
  Term _result_10 = r7;
  Term _result_11 = r8;
  Term _result_12 = r9;
  u32 _result_13 = r10;
  u32 _result_14 = r11;
  Term _result_15 = r12;
  u32 _result_16 = r13;
  u32 _result_17 = r14;
  WL_SPIN
    if (_result_13 == 0) {
      term_sink(e, _result_15);
      _v_217 = _main_0;
      _v_218 = _aux_0;
      _v_219 = _result_9;
      _v_220 = _result_10;
      _v_221 = _result_11;
      _v_222 = _result_12;
      _v_223 = _capacity_0;
      _v_224 = _depth_0;
      _v_225 = _high_0;
      _v_226 = 0;
      _v_227 = 0;
      _v_228 = 0;
      _v_229 = 0;
      _v_230 = 0;
      _v_231 = 0;
      _v_232 = 0;
      _v_233 = 0;
      _v_234 = 0;
      _v_235 = 0;
    } else {
      Term _at_8 = _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0);
      Term _at_9 = blk_at(_main_0, U32_BIN(_id_2, -, 1ull), 1);
      u32 _c_5 = blk_read(e.mem, 1, _at_8, _at_9 + 0);
      Term _c_6 = e.mem[_at_8 + _at_9 + 1];
      blk_write(e.mem, 1, _at_8, _at_9 + 0, 0);
      blk_write(e.mem, 1, _at_8, _at_9 + 1, 0);
      Term _v_236 = 0;
      Term _v_237 = 0;
      Term _v_238 = 0;
      Term _v_239 = 0;
      Term _v_240 = 0;
      Term _v_241 = 0;
      u32 _v_242 = 0;
      Term _v_243 = 0;
      u32 _v_244 = 0;
      u32 _v_245 = 0;
      u32 _v_246 = 0;
      u32 _v_247 = 0;
      Term _v_248 = 0;
      u32 _v_249 = 0;
      Term _v_250 = 0;
      u32 _v_251 = 0;
      Term _v_252 = 0;
      u32 _v_253 = 0;
      u32 _v_254 = 0;
      Term _o_9[19];
      if (spin_71(e, _o_9, _id_2, _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _result_9, _result_9 == h6 ? q6 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h7 ? q7 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h8 ? q8 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h9 ? q9 : blk_loc(e.mem, _result_12), _capacity_0, _depth_0, _high_0, 1, _result_14, _result_15, _result_15 == h12 ? q12 : blk_loc(e.mem, _result_15), _result_16, _result_17, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _c_5, _c_6, _c_6 == h12 ? q12 : _c_6 == h9 ? q9 : _c_6 == h8 ? q8 : _c_6 == h7 ? q7 : _c_6 == h6 ? q6 : _c_6 == h2 ? q2 : _c_6 == h1 ? q1 : blk_loc(e.mem, _c_6)) == 0) {
        return 0;
      }
      _v_236 = _o_9[0];
      _v_237 = _o_9[1];
      _v_238 = _o_9[2];
      _v_239 = _o_9[3];
      _v_240 = _o_9[4];
      _v_241 = _o_9[5];
      _v_242 = _o_9[6];
      _v_243 = _o_9[7];
      _v_244 = _o_9[8];
      _v_245 = _o_9[9];
      _v_246 = _o_9[10];
      _v_247 = _o_9[11];
      _v_248 = _o_9[12];
      _v_249 = _o_9[13];
      _v_250 = _o_9[14];
      _v_251 = _o_9[15];
      _v_252 = _o_9[16];
      _v_253 = _o_9[17];
      _v_254 = _o_9[18];
      _v_217 = _v_236;
      _v_218 = _v_237;
      _v_219 = _v_238;
      _v_220 = _v_239;
      _v_221 = _v_240;
      _v_222 = _v_241;
      _v_223 = _v_242;
      _v_224 = _v_243;
      _v_225 = _v_244;
      _v_226 = _v_245;
      _v_227 = _v_246;
      _v_228 = _v_247;
      _v_229 = _v_248;
      _v_230 = _v_249;
      _v_231 = _v_250;
      _v_232 = _v_251;
      _v_233 = _v_252;
      _v_234 = _v_253;
      _v_235 = _v_254;
    }
  break;
  }
  o[0] = _v_217;
  o[1] = _v_218;
  o[2] = _v_219;
  o[3] = _v_220;
  o[4] = _v_221;
  o[5] = _v_222;
  o[6] = _v_223;
  o[7] = _v_224;
  o[8] = _v_225;
  o[9] = _v_226;
  o[10] = _v_227;
  o[11] = _v_228;
  o[12] = _v_229;
  o[13] = _v_230;
  o[14] = _v_231;
  o[15] = _v_232;
  o[16] = _v_233;
  o[17] = _v_234;
  o[18] = _v_235;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  Term _v_94 = 0;
  u32 _v_95 = 0;
  Term _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_80 = _rows_18;
      _v_81 = _rows_19;
      _v_82 = _rows_20;
      _v_83 = _rows_21;
      _v_84 = _rows_22;
      _v_85 = _rows_23;
      _v_86 = _rows_24;
      _v_87 = _rows_25;
      _v_88 = _rows_26;
      _v_89 = 0;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
    } else {
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      u32 _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_6[9];
      if (spin_65(e, _o_6, _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), U32_BIN(_id_1, -, 1ull)) == 0) {
        return 0;
      }
      _v_108 = _o_6[0];
      _v_109 = _o_6[1];
      _v_110 = _o_6[2];
      _v_111 = _o_6[3];
      _v_112 = _o_6[4];
      _v_113 = _o_6[5];
      _v_114 = _o_6[6];
      _v_115 = _o_6[7];
      _v_116 = _o_6[8];
      _v_99 = _v_108;
      _v_100 = _v_109;
      _v_101 = _v_110;
      _v_102 = _v_111;
      _v_103 = _v_112;
      _v_104 = _v_113;
      _v_105 = _v_114;
      _v_106 = _v_115;
      _v_107 = _v_116;
      Term _v_198 = 0;
      Term _v_199 = 0;
      Term _v_200 = 0;
      Term _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      u32 _v_204 = 0;
      Term _v_205 = 0;
      u32 _v_206 = 0;
      u32 _v_207 = 0;
      u32 _v_208 = 0;
      u32 _v_209 = 0;
      Term _v_210 = 0;
      u32 _v_211 = 0;
      Term _v_212 = 0;
      u32 _v_213 = 0;
      Term _v_214 = 0;
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      Term _o_10[19];
      if (spin_70(e, _o_10, _id_1, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_24, _rows_25, _rows_26, _v_99, _v_99 == h7 ? q7 : _v_99 == h6 ? q6 : _v_99 == h5 ? q5 : _v_99 == h4 ? q4 : _v_99 == h3 ? q3 : _v_99 == h2 ? q2 : blk_loc(e.mem, _v_99), _v_100, _v_100 == h7 ? q7 : _v_100 == h6 ? q6 : _v_100 == h5 ? q5 : _v_100 == h4 ? q4 : _v_100 == h3 ? q3 : _v_100 == h2 ? q2 : blk_loc(e.mem, _v_100), _v_101, _v_101 == h7 ? q7 : _v_101 == h6 ? q6 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : blk_loc(e.mem, _v_101), _v_102, _v_102 == h7 ? q7 : _v_102 == h6 ? q6 : _v_102 == h5 ? q5 : _v_102 == h4 ? q4 : _v_102 == h3 ? q3 : _v_102 == h2 ? q2 : blk_loc(e.mem, _v_102), _v_103, _v_104, _v_105, _v_105 == h7 ? q7 : _v_105 == h6 ? q6 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_198 = _o_10[0];
      _v_199 = _o_10[1];
      _v_200 = _o_10[2];
      _v_201 = _o_10[3];
      _v_202 = _o_10[4];
      _v_203 = _o_10[5];
      _v_204 = _o_10[6];
      _v_205 = _o_10[7];
      _v_206 = _o_10[8];
      _v_207 = _o_10[9];
      _v_208 = _o_10[10];
      _v_209 = _o_10[11];
      _v_210 = _o_10[12];
      _v_211 = _o_10[13];
      _v_212 = _o_10[14];
      _v_213 = _o_10[15];
      _v_214 = _o_10[16];
      _v_215 = _o_10[17];
      _v_216 = _o_10[18];
      _v_80 = _v_198;
      _v_81 = _v_199;
      _v_82 = _v_200;
      _v_83 = _v_201;
      _v_84 = _v_202;
      _v_85 = _v_203;
      _v_86 = _v_204;
      _v_87 = _v_205;
      _v_88 = _v_206;
      _v_89 = _v_207;
      _v_90 = _v_208;
      _v_91 = _v_209;
      _v_92 = _v_210;
      _v_93 = _v_211;
      _v_94 = _v_212;
      _v_95 = _v_213;
      _v_96 = _v_214;
      _v_97 = _v_215;
      _v_98 = _v_216;
    }
  break;
  }
  o[0] = _v_80;
  o[1] = _v_81;
  o[2] = _v_82;
  o[3] = _v_83;
  o[4] = _v_84;
  o[5] = _v_85;
  o[6] = _v_86;
  o[7] = _v_87;
  o[8] = _v_88;
  o[9] = _v_89;
  o[10] = _v_90;
  o[11] = _v_91;
  o[12] = _v_92;
  o[13] = _v_93;
  o[14] = _v_94;
  o[15] = _v_95;
  o[16] = _v_96;
  o[17] = _v_97;
  o[18] = _v_98;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  WL_SPIN
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_0[1];
    if (spin_15(e, _o_0, U32_BIN(_id_0, <=, _rows_15), U32_BIN(_id_0, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_59 = _o_0[0];
    _v_58 = _v_59;
    u32 _v_60 = 0;
    Term _o_1[1];
    if (spin_15(e, _o_1, U32_BIN(0ull, <, _id_0), _v_58) == 0) {
      return 0;
    }
    _v_60 = _o_1[0];
    _v_57 = _v_60;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_11[19];
    if (spin_64(e, _o_11, _v_57, _id_0, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17) == 0) {
      return 0;
    }
    _v_61 = _o_11[0];
    _v_62 = _o_11[1];
    _v_63 = _o_11[2];
    _v_64 = _o_11[3];
    _v_65 = _o_11[4];
    _v_66 = _o_11[5];
    _v_67 = _o_11[6];
    _v_68 = _o_11[7];
    _v_69 = _o_11[8];
    _v_70 = _o_11[9];
    _v_71 = _o_11[10];
    _v_72 = _o_11[11];
    _v_73 = _o_11[12];
    _v_74 = _o_11[13];
    _v_75 = _o_11[14];
    _v_76 = _o_11[15];
    _v_77 = _o_11[16];
    _v_78 = _o_11[17];
    _v_79 = _o_11[18];
    _v_38 = _v_61;
    _v_39 = _v_62;
    _v_40 = _v_63;
    _v_41 = _v_64;
    _v_42 = _v_65;
    _v_43 = _v_66;
    _v_44 = _v_67;
    _v_45 = _v_68;
    _v_46 = _v_69;
    _v_47 = _v_70;
    _v_48 = _v_71;
    _v_49 = _v_72;
    _v_50 = _v_73;
    _v_51 = _v_74;
    _v_52 = _v_75;
    _v_53 = _v_76;
    _v_54 = _v_77;
    _v_55 = _v_78;
    _v_56 = _v_79;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

INLINE Term spin_74(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _result_0;
    _v_6 = _result_1;
    _v_7 = _result_2;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_75(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _result_0;
    _v_6 = _result_1;
    _v_7 = _result_2;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_76(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  WL_SPIN
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_0[1];
    if (spin_15(e, _o_0, U32_BIN(0ull, <, _id_0), U32_BIN(_id_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_30 = _v_31;
    _v_20 = _rows_9;
    _v_21 = _rows_10;
    _v_22 = _rows_11;
    _v_23 = _rows_12;
    _v_24 = _rows_13;
    _v_25 = _rows_14;
    _v_26 = _rows_15;
    _v_27 = _rows_16;
    _v_28 = _rows_17;
    _v_29 = _v_30;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  return 1;
}

INLINE Term spin_77(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _id_1 = r0;
  u32 _bundle_0 = r1;
  Term _bundle_1 = r2;
  u32 _bundle_2 = r3;
  Term _bundle_3 = r4;
  u32 _bundle_4 = r5;
  Term _bundle_5 = r6;
  Term _result_0 = r7;
  Term _result_1 = r8;
  Term _result_2 = r9;
  Term _result_3 = r10;
  Term _result_4 = r11;
  Term _result_5 = r12;
  u32 _result_6 = r13;
  Term _result_7 = r14;
  u32 _result_8 = r15;
  u32 _result_9 = r16;
  WL_SPIN
    _v_50 = _result_0;
    _v_51 = _result_1;
    _v_52 = _result_2;
    _v_53 = _result_3;
    _v_54 = _result_4;
    _v_55 = _result_5;
    _v_56 = _result_6;
    _v_57 = _result_7;
    _v_58 = _result_8;
    _v_59 = 0;
    _v_60 = _id_1;
    _v_61 = _bundle_0;
    _v_62 = _bundle_1;
    _v_63 = _bundle_2;
    _v_64 = _bundle_3;
    _v_65 = _bundle_4;
    _v_66 = _bundle_5;
    _v_67 = _result_9;
  break;
  }
  o[0] = _v_50;
  o[1] = _v_51;
  o[2] = _v_52;
  o[3] = _v_53;
  o[4] = _v_54;
  o[5] = _v_55;
  o[6] = _v_56;
  o[7] = _v_57;
  o[8] = _v_58;
  o[9] = _v_59;
  o[10] = _v_60;
  o[11] = _v_61;
  o[12] = _v_62;
  o[13] = _v_63;
  o[14] = _v_64;
  o[15] = _v_65;
  o[16] = _v_66;
  o[17] = _v_67;
  return 1;
}

INLINE Term spin_79(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_44 = 0;
  Term _xs_0 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      _v_44 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_0 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_79);
    }
  break;
  }
  o[0] = _v_44;
  return 1;
}

INLINE Term spin_80(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_47 = 0;
  Term _xs_1 = r0;
  WL_SPIN
    Term _v_48 = 0;
    Term _o_1[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_79(e, _o_1, _xs_1, _xs_1 == h0 ? q0 : blk_loc(e.mem, _xs_1), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_48 = _o_1[0];
    _v_47 = _v_48;
  break;
  }
  o[0] = _v_47;
  return 1;
}

INLINE Term spin_78(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _reverseChanges_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  Term _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  u32 _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  Term _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  u32 _result_13 = r14;
  Term _result_14 = r15;
  u32 _result_15 = r16;
  Term _result_16 = r17;
  u32 _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _o_0[1];
      if (spin_79(e, _o_0, _result_10, _result_10 == h11 ? q11 : blk_loc(e.mem, _result_10), _reverseChanges_0, _reverseChanges_0 == h0 ? q0 : blk_loc(e.mem, _reverseChanges_0)) == 0) {
        return 0;
      }
      _v_43 = _o_0[0];
      _v_42 = _v_43;
      _v_21 = 0;
      _v_22 = _result_1;
      _v_23 = _result_2;
      _v_24 = _result_3;
      _v_25 = _result_4;
      _v_26 = _result_5;
      _v_27 = _result_6;
      _v_28 = _result_7;
      _v_29 = _result_8;
      _v_30 = _result_9;
      _v_31 = _v_42;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
    } else {
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _o_2[1];
      if (spin_80(e, _o_2, _reverseChanges_0, _reverseChanges_0 == h0 ? q0 : blk_loc(e.mem, _reverseChanges_0)) == 0) {
        return 0;
      }
      _v_46 = _o_2[0];
      _v_45 = _v_46;
      _v_21 = 1;
      _v_22 = _result_1;
      _v_23 = _result_2;
      _v_24 = _result_3;
      _v_25 = _result_4;
      _v_26 = _result_5;
      _v_27 = _result_6;
      _v_28 = _result_7;
      _v_29 = _result_8;
      _v_30 = _result_9;
      _v_31 = _result_10;
      _v_32 = _result_11;
      _v_33 = _result_12;
      _v_34 = _result_13;
      _v_35 = _result_14;
      _v_36 = _result_15;
      _v_37 = _result_16;
      _v_38 = _result_17;
      _v_39 = _result_18;
      _v_40 = term_pak(CID_NIL, 0);
      _v_41 = _v_45;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_86(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_44 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_44 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_86);
    }
  break;
  }
  o[0] = _v_44;
  return 1;
}

INLINE Term spin_85(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_42 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_43 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_86(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_43 = _o_0[0];
    _v_42 = _v_43;
  break;
  }
  o[0] = _v_42;
  return 1;
}

INLINE Term spin_84(Env e, THR Term* o, u32 r0, Term r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _capacity_2 = r0;
  Term _depth_2 = r1;
  u32 _high_2 = r2;
  Term _state_14 = r3;
  Term _state_15 = r4;
  Term _state_16 = r5;
  Term _state_17 = r6;
  Term _state_18 = r7;
  Term _state_19 = r8;
  Term _state_20 = r9;
  WL_SPIN
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _o_1[1];
    if (spin_85(e, _o_1, _state_20, _state_20 == h9 ? q9 : blk_loc(e.mem, _state_20)) == 0) {
      return 0;
    }
    _v_41 = _o_1[0];
    _v_40 = _v_41;
    _v_30 = _state_14;
    _v_31 = _state_15;
    _v_32 = _state_16;
    _v_33 = _state_17;
    _v_34 = _state_18;
    _v_35 = _state_19;
    _v_36 = _capacity_2;
    _v_37 = _depth_2;
    _v_38 = _high_2;
    _v_39 = _v_40;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  return 1;
}

INLINE Term spin_83(Env e, THR Term* o, u32 r0, Term r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _capacity_1 = r0;
  Term _depth_1 = r1;
  u32 _high_1 = r2;
  Term _state_7 = r3;
  Term _state_8 = r4;
  Term _state_9 = r5;
  Term _state_10 = r6;
  Term _state_11 = r7;
  Term _state_12 = r8;
  Term _state_13 = r9;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _o_2[10];
    if (spin_84(e, _o_2, _capacity_1, _depth_1, _high_1, _state_7, _state_7 == h3 ? q3 : blk_loc(e.mem, _state_7), _state_8, _state_8 == h4 ? q4 : blk_loc(e.mem, _state_8), _state_9, _state_9 == h5 ? q5 : blk_loc(e.mem, _state_9), _state_10, _state_10 == h6 ? q6 : blk_loc(e.mem, _state_10), _state_11, _state_11 == h7 ? q7 : blk_loc(e.mem, _state_11), _state_12, _state_12 == h8 ? q8 : blk_loc(e.mem, _state_12), _state_13, _state_13 == h9 ? q9 : blk_loc(e.mem, _state_13)) == 0) {
      return 0;
    }
    _v_20 = _o_2[0];
    _v_21 = _o_2[1];
    _v_22 = _o_2[2];
    _v_23 = _o_2[3];
    _v_24 = _o_2[4];
    _v_25 = _o_2[5];
    _v_26 = _o_2[6];
    _v_27 = _o_2[7];
    _v_28 = _o_2[8];
    _v_29 = _o_2[9];
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_87(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  Term _v_65 = 0;
  Term _v_66 = 0;
  Term _v_67 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  u32 _namespace_1 = r2;
  u32 _selection_1 = r3;
  Term _state_21 = r4;
  Term _state_22 = r5;
  Term _state_23 = r6;
  Term _state_24 = r7;
  Term _state_25 = r8;
  Term _state_26 = r9;
  Term _state_27 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_61 = _state_21;
      _v_62 = _state_22;
      _v_63 = _state_23;
      _v_64 = _state_24;
      _v_65 = _state_25;
      _v_66 = _state_26;
      _v_67 = _state_27;
    } else {
      Term _at_0 = _state_23 == h6 ? q6 : blk_loc(e.mem, _state_23);
      Term _at_1 = blk_at(_state_23, U32_BIN(_id_1, -, 1ull), 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      Term _v_68 = 0;
      Term _v_69 = 0;
      Term _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _o_5[7];
      if (spin_61(e, _o_5, _id_1, _namespace_1, _selection_1, _state_21, _state_21 == h4 ? q4 : blk_loc(e.mem, _state_21), _state_22, _state_22 == h5 ? q5 : blk_loc(e.mem, _state_22), _state_27, _state_27 == h10 ? q10 : blk_loc(e.mem, _state_27), _state_24, _state_24 == h7 ? q7 : blk_loc(e.mem, _state_24), _state_25, _state_25 == h8 ? q8 : blk_loc(e.mem, _state_25), _state_26, _state_26 == h9 ? q9 : blk_loc(e.mem, _state_26), _state_23, _state_23 == h6 ? q6 : blk_loc(e.mem, _state_23), _c_0) == 0) {
        return 0;
      }
      _v_68 = _o_5[0];
      _v_69 = _o_5[1];
      _v_70 = _o_5[2];
      _v_71 = _o_5[3];
      _v_72 = _o_5[4];
      _v_73 = _o_5[5];
      _v_74 = _o_5[6];
      _v_61 = _v_68;
      _v_62 = _v_69;
      _v_63 = _v_70;
      _v_64 = _v_71;
      _v_65 = _v_72;
      _v_66 = _v_73;
      _v_67 = _v_74;
    }
  break;
  }
  o[0] = _v_61;
  o[1] = _v_62;
  o[2] = _v_63;
  o[3] = _v_64;
  o[4] = _v_65;
  o[5] = _v_66;
  o[6] = _v_67;
  return 1;
}

INLINE Term spin_88(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_2 = 0;
  u32 _result_15 = r0;
  Term _result_16 = r1;
  WL_SPIN
    if (_result_15 == 2) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 44);
    } else if (_result_15 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 60);
    } else {
      _v_2 = _result_16;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_89(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h16 = r16;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _namespace_0 = r0;
  u32 _next_0 = r1;
  Term _pending_0 = r2;
  u32 _ledger_0 = r3;
  Term _ledger_1 = r4;
  Term _mode_0 = r5;
  Term _result_0 = r6;
  Term _result_1 = r7;
  Term _result_2 = r8;
  Term _result_3 = r9;
  Term _result_4 = r10;
  Term _result_5 = r11;
  u32 _result_6 = r12;
  Term _result_7 = r13;
  u32 _result_8 = r14;
  u32 _result_9 = r15;
  Term _result_10 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _next_0;
    _v_19 = _result_0;
    _v_20 = _result_1;
    _v_21 = _result_2;
    _v_22 = _result_3;
    _v_23 = _result_4;
    _v_24 = _result_5;
    _v_25 = _result_6;
    _v_26 = _result_7;
    _v_27 = _result_8;
    _v_28 = _pending_0;
    _v_29 = _ledger_0;
    _v_30 = _ledger_1;
    _v_31 = _mode_0;
    _v_32 = _result_9;
    _v_33 = _result_10;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_92(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_50 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_50 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_1 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_1);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_92);
    }
  break;
  }
  o[0] = _v_50;
  return 1;
}

INLINE Term spin_91(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_48 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_49 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_92(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_49 = _o_0[0];
    _v_48 = _v_49;
  break;
  }
  o[0] = _v_48;
  return 1;
}

INLINE Term spin_90(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _world_45 = r0;
  u32 _world_46 = r1;
  Term _world_47 = r2;
  Term _world_48 = r3;
  Term _world_49 = r4;
  Term _world_50 = r5;
  Term _world_51 = r6;
  Term _world_52 = r7;
  u32 _world_53 = r8;
  Term _world_54 = r9;
  u32 _world_55 = r10;
  Term _world_56 = r11;
  u32 _world_57 = r12;
  Term _world_58 = r13;
  Term _world_59 = r14;
  Term _staged_0 = r15;
  WL_SPIN
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _o_1[1];
    if (spin_91(e, _o_1, _staged_0, _staged_0 == h15 ? q15 : blk_loc(e.mem, _staged_0)) == 0) {
      return 0;
    }
    _v_47 = _o_1[0];
    _v_46 = _v_47;
    Term _v_51 = 0;
    Term _o_2[1];
    if (spin_92(e, _o_2, _v_46, _v_46 == h15 ? q15 : _v_46 == h14 ? q14 : _v_46 == h13 ? q13 : _v_46 == h11 ? q11 : _v_46 == h7 ? q7 : _v_46 == h6 ? q6 : _v_46 == h5 ? q5 : _v_46 == h4 ? q4 : _v_46 == h3 ? q3 : _v_46 == h2 ? q2 : blk_loc(e.mem, _v_46), _world_56, _world_56 == h11 ? q11 : blk_loc(e.mem, _world_56)) == 0) {
      return 0;
    }
    _v_51 = _o_2[0];
    _v_45 = _v_51;
    _v_30 = _world_45;
    _v_31 = _world_46;
    _v_32 = _world_47;
    _v_33 = _world_48;
    _v_34 = _world_49;
    _v_35 = _world_50;
    _v_36 = _world_51;
    _v_37 = _world_52;
    _v_38 = _world_53;
    _v_39 = _world_54;
    _v_40 = _world_55;
    _v_41 = _v_45;
    _v_42 = _world_57;
    _v_43 = _world_58;
    _v_44 = _world_59;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  return 1;
}

INLINE Term spin_95(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _command_0 = r9;
  u32 _command_1 = r10;
  Term _command_2 = r11;
  Term _command_3 = r12;
  u32 _command_4 = r13;
  Term _command_5 = r14;
  u32 _command_6 = r15;
  Term _command_7 = r16;
  WL_SPIN
    if (_command_0 == 0) {
      Term _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      Term _o_10[10];
      if (spin_76(e, _o_10, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1) == 0) {
        return 0;
      }
      _v_80 = _o_10[0];
      _v_81 = _o_10[1];
      _v_82 = _o_10[2];
      _v_83 = _o_10[3];
      _v_84 = _o_10[4];
      _v_85 = _o_10[5];
      _v_86 = _o_10[6];
      _v_87 = _o_10[7];
      _v_88 = _o_10[8];
      _v_89 = _o_10[9];
      _v_70 = _v_80;
      _v_71 = _v_81;
      _v_72 = _v_82;
      _v_73 = _v_83;
      _v_74 = _v_84;
      _v_75 = _v_85;
      _v_76 = _v_86;
      _v_77 = _v_87;
      _v_78 = _v_88;
      _v_79 = _v_89;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      Term _v_95 = 0;
      u32 _v_96 = 0;
      Term _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      Term _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      Term _o_11[18];
      if (spin_77(e, _o_11, _command_1, _command_2, _command_3, _command_3 == h12 ? q12 : blk_loc(e.mem, _command_3), _command_4, _command_5, _command_5 == h14 ? q14 : blk_loc(e.mem, _command_5), _command_6, _command_7, _command_7 == h16 ? q16 : blk_loc(e.mem, _command_7), _v_70, _v_70 == h16 ? q16 : _v_70 == h14 ? q14 : _v_70 == h12 ? q12 : _v_70 == h11 ? q11 : _v_70 == h5 ? q5 : _v_70 == h4 ? q4 : _v_70 == h3 ? q3 : _v_70 == h2 ? q2 : _v_70 == h1 ? q1 : _v_70 == h0 ? q0 : blk_loc(e.mem, _v_70), _v_71, _v_71 == h16 ? q16 : _v_71 == h14 ? q14 : _v_71 == h12 ? q12 : _v_71 == h11 ? q11 : _v_71 == h5 ? q5 : _v_71 == h4 ? q4 : _v_71 == h3 ? q3 : _v_71 == h2 ? q2 : _v_71 == h1 ? q1 : _v_71 == h0 ? q0 : blk_loc(e.mem, _v_71), _v_72, _v_72 == h16 ? q16 : _v_72 == h14 ? q14 : _v_72 == h12 ? q12 : _v_72 == h11 ? q11 : _v_72 == h5 ? q5 : _v_72 == h4 ? q4 : _v_72 == h3 ? q3 : _v_72 == h2 ? q2 : _v_72 == h1 ? q1 : _v_72 == h0 ? q0 : blk_loc(e.mem, _v_72), _v_73, _v_73 == h16 ? q16 : _v_73 == h14 ? q14 : _v_73 == h12 ? q12 : _v_73 == h11 ? q11 : _v_73 == h5 ? q5 : _v_73 == h4 ? q4 : _v_73 == h3 ? q3 : _v_73 == h2 ? q2 : _v_73 == h1 ? q1 : _v_73 == h0 ? q0 : blk_loc(e.mem, _v_73), _v_74, _v_74 == h16 ? q16 : _v_74 == h14 ? q14 : _v_74 == h12 ? q12 : _v_74 == h11 ? q11 : _v_74 == h5 ? q5 : _v_74 == h4 ? q4 : _v_74 == h3 ? q3 : _v_74 == h2 ? q2 : _v_74 == h1 ? q1 : _v_74 == h0 ? q0 : blk_loc(e.mem, _v_74), _v_75, _v_75 == h16 ? q16 : _v_75 == h14 ? q14 : _v_75 == h12 ? q12 : _v_75 == h11 ? q11 : _v_75 == h5 ? q5 : _v_75 == h4 ? q4 : _v_75 == h3 ? q3 : _v_75 == h2 ? q2 : _v_75 == h1 ? q1 : _v_75 == h0 ? q0 : blk_loc(e.mem, _v_75), _v_76, _v_77, _v_78, _v_79) == 0) {
        return 0;
      }
      _v_90 = _o_11[0];
      _v_91 = _o_11[1];
      _v_92 = _o_11[2];
      _v_93 = _o_11[3];
      _v_94 = _o_11[4];
      _v_95 = _o_11[5];
      _v_96 = _o_11[6];
      _v_97 = _o_11[7];
      _v_98 = _o_11[8];
      _v_99 = _o_11[9];
      _v_100 = _o_11[10];
      _v_101 = _o_11[11];
      _v_102 = _o_11[12];
      _v_103 = _o_11[13];
      _v_104 = _o_11[14];
      _v_105 = _o_11[15];
      _v_106 = _o_11[16];
      _v_107 = _o_11[17];
      _v_52 = _v_90;
      _v_53 = _v_91;
      _v_54 = _v_92;
      _v_55 = _v_93;
      _v_56 = _v_94;
      _v_57 = _v_95;
      _v_58 = _v_96;
      _v_59 = _v_97;
      _v_60 = _v_98;
      _v_61 = _v_99;
      _v_62 = _v_100;
      _v_63 = _v_101;
      _v_64 = _v_102;
      _v_65 = _v_103;
      _v_66 = _v_104;
      _v_67 = _v_105;
      _v_68 = _v_106;
      _v_69 = _v_107;
    } else {
      _v_52 = _rows_0;
      _v_53 = _rows_1;
      _v_54 = _rows_2;
      _v_55 = _rows_3;
      _v_56 = _rows_4;
      _v_57 = _rows_5;
      _v_58 = _rows_6;
      _v_59 = _rows_7;
      _v_60 = _rows_8;
      _v_61 = _command_0;
      _v_62 = _command_1;
      _v_63 = _command_2;
      _v_64 = _command_3;
      _v_65 = _command_4;
      _v_66 = _command_5;
      _v_67 = _command_6;
      _v_68 = _command_7;
      _v_69 = 1;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  return 1;
}

INLINE Term spin_96(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  Term _v_122 = 0;
  Term _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  Term _v_126 = 0;
  u32 _v_127 = 0;
  Term _v_128 = 0;
  u32 _v_129 = 0;
  Term _reverse_0 = r0;
  u32 _valid_0 = r1;
  Term _result_0 = r2;
  Term _result_1 = r3;
  Term _result_2 = r4;
  Term _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  Term _result_7 = r9;
  u32 _result_8 = r10;
  u32 _result_9 = r11;
  u32 _result_10 = r12;
  Term _result_11 = r13;
  Term _result_12 = r14;
  u32 _result_13 = r15;
  Term _result_14 = r16;
  u32 _result_15 = r17;
  Term _result_16 = r18;
  u32 _result_17 = r19;
  WL_SPIN
    Term _b_0 = 0;
    if (_result_9 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_11);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_12);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_13);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_14);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_15);
      e.mem[_nd_1 + 6] = rfc_seal(e, _result_16);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_result_9 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_2 + 1] = rfc_seal(e, _result_11);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_result_9 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_3 + 1] = rfc_seal(e, _result_11);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_result_9 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _result_10);
    } else if (_result_9 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _result_10);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _result_10);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _reverse_0);
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _o_13[1];
    if (spin_15(e, _o_13, _valid_0, _result_17) == 0) {
      return 0;
    }
    _v_131 = _o_13[0];
    _v_130 = _v_131;
    _v_119 = _result_0;
    _v_120 = _result_1;
    _v_121 = _result_2;
    _v_122 = _result_3;
    _v_123 = _result_4;
    _v_124 = _result_5;
    _v_125 = _result_6;
    _v_126 = _result_7;
    _v_127 = _result_8;
    _v_128 = term_ctr(CID_CON, _nd_4);
    _v_129 = _v_130;
  break;
  }
  o[0] = _v_119;
  o[1] = _v_120;
  o[2] = _v_121;
  o[3] = _v_122;
  o[4] = _v_123;
  o[5] = _v_124;
  o[6] = _v_125;
  o[7] = _v_126;
  o[8] = _v_127;
  o[9] = _v_128;
  o[10] = _v_129;
  return 1;
}

INLINE Term spin_97(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  u32 _state_21 = r0;
  Term _state_22 = r1;
  Term _state_23 = r2;
  Term _state_24 = r3;
  Term _state_25 = r4;
  Term _state_26 = r5;
  Term _state_27 = r6;
  u32 _state_28 = r7;
  Term _state_29 = r8;
  u32 _state_30 = r9;
  Term _state_31 = r10;
  u32 _state_32 = r11;
  Term _state_33 = r12;
  u32 _state_34 = r13;
  Term _state_35 = r14;
  u32 _state_36 = r15;
  Term _state_37 = r16;
  u32 _state_38 = r17;
  u32 _state_39 = r18;
  Term _state_40 = r19;
  Term _state_41 = r20;
  WL_SPIN
    if (_state_21 == 0) {
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _o_0[1];
      if (spin_80(e, _o_0, _state_31, _state_31 == h10 ? q10 : blk_loc(e.mem, _state_31)) == 0) {
        return 0;
      }
      _v_43 = _o_0[0];
      _v_42 = _v_43;
      _v_21 = 0;
      _v_22 = _state_22;
      _v_23 = _state_23;
      _v_24 = _state_24;
      _v_25 = _state_25;
      _v_26 = _state_26;
      _v_27 = _state_27;
      _v_28 = _state_28;
      _v_29 = _state_29;
      _v_30 = _state_30;
      _v_31 = _v_42;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
    } else {
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_1[1];
      if (spin_91(e, _o_1, _state_40, _state_40 == h19 ? q19 : blk_loc(e.mem, _state_40)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_44 = _v_45;
      _v_21 = 1;
      _v_22 = _state_22;
      _v_23 = _state_23;
      _v_24 = _state_24;
      _v_25 = _state_25;
      _v_26 = _state_26;
      _v_27 = _state_27;
      _v_28 = _state_28;
      _v_29 = _state_29;
      _v_30 = _state_30;
      _v_31 = _state_31;
      _v_32 = _state_32;
      _v_33 = _state_33;
      _v_34 = _state_34;
      _v_35 = _state_35;
      _v_36 = _state_36;
      _v_37 = _state_37;
      _v_38 = _state_38;
      _v_39 = _state_39;
      _v_40 = _v_44;
      _v_41 = _state_41;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_98(Env e, THR Term* o, Term r0, u32 r1, u32 r2, Term r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _remaining_0 = r0;
  u32 _id_0 = r1;
  u32 _capacity_0 = r2;
  Term _depth_0 = r3;
  u32 _high_0 = r4;
  u32 _selection_1 = r5;
  u32 _namespace_1 = r6;
  Term _state_0 = r7;
  Term _state_1 = r8;
  Term _state_2 = r9;
  Term _state_3 = r10;
  Term _state_4 = r11;
  Term _state_5 = r12;
  Term _state_6 = r13;
  WL_SPIN
    if (_remaining_0 == 0) {
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      Term _v_29 = 0;
      Term _o_0[10];
      if (spin_83(e, _o_0, _capacity_0, _depth_0, _high_0, _state_0, _state_0 == h7 ? q7 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h8 ? q8 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h9 ? q9 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h10 ? q10 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h11 ? q11 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h12 ? q12 : blk_loc(e.mem, _state_5), _state_6, _state_6 == h13 ? q13 : blk_loc(e.mem, _state_6)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    } else {
      Term _rest_0 = (_remaining_0 - 1);
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _o_1[1];
      if (spin_15(e, _o_1, U32_BIN(0ull, <, _id_0), U32_BIN(_id_0, <=, _capacity_0)) == 0) {
        return 0;
      }
      _v_38 = _o_1[0];
      _v_37 = _v_38;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_2[7];
      if (spin_87(e, _o_2, _v_37, _id_0, _namespace_1, _selection_1, _state_0, _state_0 == h7 ? q7 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h8 ? q8 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h9 ? q9 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h10 ? q10 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h11 ? q11 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h12 ? q12 : blk_loc(e.mem, _state_5), _state_6, _state_6 == h13 ? q13 : blk_loc(e.mem, _state_6)) == 0) {
        return 0;
      }
      _v_39 = _o_2[0];
      _v_40 = _o_2[1];
      _v_41 = _o_2[2];
      _v_42 = _o_2[3];
      _v_43 = _o_2[4];
      _v_44 = _o_2[5];
      _v_45 = _o_2[6];
      _v_30 = _v_39;
      _v_31 = _v_40;
      _v_32 = _v_41;
      _v_33 = _v_42;
      _v_34 = _v_43;
      _v_35 = _v_44;
      _v_36 = _v_45;
      r0 = _rest_0;
      r1 = U32_BIN(_id_0, +, 1ull);
      r2 = _capacity_0;
      r3 = _depth_0;
      r4 = _high_0;
      r5 = _selection_1;
      r6 = _namespace_1;
      r7 = _v_30;
      r8 = _v_31;
      r9 = _v_32;
      r10 = _v_33;
      r11 = _v_34;
      r12 = _v_35;
      r13 = _v_36;
      _remaining_0 = r0;
      _id_0 = r1;
      _capacity_0 = r2;
      _depth_0 = r3;
      _high_0 = r4;
      _selection_1 = r5;
      _namespace_1 = r6;
      _state_0 = r7;
      _state_1 = r8;
      _state_2 = r9;
      _state_3 = r10;
      _state_4 = r11;
      _state_5 = r12;
      _state_6 = r13;
      WL_AGAIN(spin_98);
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_99(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h14 = r14;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  u32 _result_15 = r0;
  u32 _result_16 = r1;
  Term _result_17 = r2;
  Term _result_18 = r3;
  Term _result_19 = r4;
  Term _result_20 = r5;
  Term _result_21 = r6;
  Term _result_22 = r7;
  u32 _result_23 = r8;
  Term _result_24 = r9;
  u32 _result_25 = r10;
  Term _result_26 = r11;
  u32 _result_27 = r12;
  u32 _result_28 = r13;
  Term _result_29 = r14;
  WL_SPIN
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _o_2[1];
    if (spin_88(e, _o_2, _result_28, _result_29, _result_29 == h14 ? q14 : blk_loc(e.mem, _result_29)) == 0) {
      return 0;
    }
    _v_50 = _o_2[0];
    _v_49 = _v_50;
    _v_34 = _result_15;
    _v_35 = _result_16;
    _v_36 = _result_17;
    _v_37 = _result_18;
    _v_38 = _result_19;
    _v_39 = _result_20;
    _v_40 = _result_21;
    _v_41 = _result_22;
    _v_42 = _result_23;
    _v_43 = _result_24;
    _v_44 = _result_25;
    _v_45 = _result_26;
    _v_46 = _result_27;
    _v_47 = 1;
    _v_48 = _v_49;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  return 1;
}

INLINE Term spin_102(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_26 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_26 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_102);
    }
  break;
  }
  o[0] = _v_26;
  return 1;
}

INLINE Term spin_101(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_24 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_25 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_102(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_25 = _o_0[0];
    _v_24 = _v_25;
  break;
  }
  o[0] = _v_24;
  return 1;
}

INLINE Term spin_100(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _commands_1 = r0;
  Term _state_0 = r1;
  Term _state_1 = r2;
  Term _state_2 = r3;
  Term _state_3 = r4;
  Term _state_4 = r5;
  Term _state_5 = r6;
  u32 _state_6 = r7;
  Term _state_7 = r8;
  u32 _state_8 = r9;
  Term _state_9 = r10;
  u32 _state_10 = r11;
  WL_SPIN
    if (term_aux(_commands_1) == CID_NIL) {
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _o_1[1];
      if (spin_101(e, _o_1, _state_9, _state_9 == h10 ? q10 : blk_loc(e.mem, _state_9)) == 0) {
        return 0;
      }
      _v_23 = _o_1[0];
      _v_22 = _v_23;
      _v_11 = _state_0;
      _v_12 = _state_1;
      _v_13 = _state_2;
      _v_14 = _state_3;
      _v_15 = _state_4;
      _v_16 = _state_5;
      _v_17 = _state_6;
      _v_18 = _state_7;
      _v_19 = _state_8;
      _v_20 = _v_22;
      _v_21 = _state_10;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _commands_1, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      u32 _o_6 = 0;
      Term _o_7 = 0;
      u32 _o_8 = 0;
      Term _o_9 = 0;
      if (term_aux(_f_2) == CID_STORAGE_SPAWN) {
        _o_2 = 0;
        Term _fb_2[7];
        u64 _sp_2 = ctr_take(e, _f_2, 7, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        Term _f_8 = _fb_2[4];
        u32 _f_9 = _fb_2[5];
        Term _f_10 = _fb_2[6];
        spare_free(e, cls_fit(7), _sp_2);
        _o_3 = _f_4;
        _o_4 = _f_5;
        _o_5 = _f_6;
        _o_6 = _f_7;
        _o_7 = _f_8;
        _o_8 = _f_9;
        _o_9 = _f_10;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTMAIN) {
        _o_2 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_2, 2, _fb_3);
        u32 _f_11 = _fb_3[0];
        Term _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_3 = _f_11;
        _o_4 = _f_12;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTFLAG) {
        _o_2 = 2;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_2, 2, _fb_4);
        u32 _f_13 = _fb_4[0];
        Term _f_14 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        _o_3 = _f_13;
        _o_4 = _f_14;
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEMAIN) {
        _o_2 = 3;
        _o_3 = term_loc(_f_2);
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEFLAG) {
        _o_2 = 4;
        _o_3 = term_loc(_f_2);
      } else {
        _o_2 = 5;
        _o_3 = term_loc(_f_2);
      }
      Term _v_27 = 0;
      Term _v_28 = 0;
      Term _v_29 = 0;
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      u32 _v_33 = 0;
      Term _v_34 = 0;
      u32 _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      u32 _v_51 = 0;
      Term _v_52 = 0;
      u32 _v_53 = 0;
      Term _v_54 = 0;
      u32 _v_55 = 0;
      Term _v_56 = 0;
      Term _v_57 = 0;
      Term _v_58 = 0;
      Term _v_59 = 0;
      Term _v_60 = 0;
      Term _v_61 = 0;
      u32 _v_62 = 0;
      Term _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      u32 _v_69 = 0;
      Term _v_70 = 0;
      u32 _v_71 = 0;
      Term _v_72 = 0;
      u32 _v_73 = 0;
      Term _o_10[18];
      if (spin_95(e, _o_10, _state_0, _state_0 == h1 ? q1 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h2 ? q2 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h3 ? q3 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h4 ? q4 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h5 ? q5 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h6 ? q6 : blk_loc(e.mem, _state_5), _state_6, _state_7, _state_8, _o_2, _o_3, _o_4, _o_4 == h10 ? q10 : _o_4 == h6 ? q6 : _o_4 == h5 ? q5 : _o_4 == h4 ? q4 : _o_4 == h3 ? q3 : _o_4 == h2 ? q2 : _o_4 == h1 ? q1 : _o_4 == h0 ? q0 : blk_loc(e.mem, _o_4), _o_5, _o_5 == h10 ? q10 : _o_5 == h6 ? q6 : _o_5 == h5 ? q5 : _o_5 == h4 ? q4 : _o_5 == h3 ? q3 : _o_5 == h2 ? q2 : _o_5 == h1 ? q1 : _o_5 == h0 ? q0 : blk_loc(e.mem, _o_5), _o_6, _o_7, _o_7 == h10 ? q10 : _o_7 == h6 ? q6 : _o_7 == h5 ? q5 : _o_7 == h4 ? q4 : _o_7 == h3 ? q3 : _o_7 == h2 ? q2 : _o_7 == h1 ? q1 : _o_7 == h0 ? q0 : blk_loc(e.mem, _o_7), _o_8, _o_9, _o_9 == h10 ? q10 : _o_9 == h6 ? q6 : _o_9 == h5 ? q5 : _o_9 == h4 ? q4 : _o_9 == h3 ? q3 : _o_9 == h2 ? q2 : _o_9 == h1 ? q1 : _o_9 == h0 ? q0 : blk_loc(e.mem, _o_9)) == 0) {
        return 0;
      }
      _v_56 = _o_10[0];
      _v_57 = _o_10[1];
      _v_58 = _o_10[2];
      _v_59 = _o_10[3];
      _v_60 = _o_10[4];
      _v_61 = _o_10[5];
      _v_62 = _o_10[6];
      _v_63 = _o_10[7];
      _v_64 = _o_10[8];
      _v_65 = _o_10[9];
      _v_66 = _o_10[10];
      _v_67 = _o_10[11];
      _v_68 = _o_10[12];
      _v_69 = _o_10[13];
      _v_70 = _o_10[14];
      _v_71 = _o_10[15];
      _v_72 = _o_10[16];
      _v_73 = _o_10[17];
      _v_38 = _v_56;
      _v_39 = _v_57;
      _v_40 = _v_58;
      _v_41 = _v_59;
      _v_42 = _v_60;
      _v_43 = _v_61;
      _v_44 = _v_62;
      _v_45 = _v_63;
      _v_46 = _v_64;
      _v_47 = _v_65;
      _v_48 = _v_66;
      _v_49 = _v_67;
      _v_50 = _v_68;
      _v_51 = _v_69;
      _v_52 = _v_70;
      _v_53 = _v_71;
      _v_54 = _v_72;
      _v_55 = _v_73;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      Term _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      Term _o_11[11];
      if (spin_96(e, _o_11, _state_9, _state_9 == h10 ? q10 : blk_loc(e.mem, _state_9), _state_10, _v_38, _v_38 == h10 ? q10 : _v_38 == h6 ? q6 : _v_38 == h5 ? q5 : _v_38 == h4 ? q4 : _v_38 == h3 ? q3 : _v_38 == h2 ? q2 : _v_38 == h1 ? q1 : _v_38 == h0 ? q0 : blk_loc(e.mem, _v_38), _v_39, _v_39 == h10 ? q10 : _v_39 == h6 ? q6 : _v_39 == h5 ? q5 : _v_39 == h4 ? q4 : _v_39 == h3 ? q3 : _v_39 == h2 ? q2 : _v_39 == h1 ? q1 : _v_39 == h0 ? q0 : blk_loc(e.mem, _v_39), _v_40, _v_40 == h10 ? q10 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : _v_40 == h0 ? q0 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h10 ? q10 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : _v_41 == h0 ? q0 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h10 ? q10 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : _v_42 == h0 ? q0 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h10 ? q10 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : _v_43 == h0 ? q0 : blk_loc(e.mem, _v_43), _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_49 == h10 ? q10 : _v_49 == h6 ? q6 : _v_49 == h5 ? q5 : _v_49 == h4 ? q4 : _v_49 == h3 ? q3 : _v_49 == h2 ? q2 : _v_49 == h1 ? q1 : _v_49 == h0 ? q0 : blk_loc(e.mem, _v_49), _v_50, _v_50 == h10 ? q10 : _v_50 == h6 ? q6 : _v_50 == h5 ? q5 : _v_50 == h4 ? q4 : _v_50 == h3 ? q3 : _v_50 == h2 ? q2 : _v_50 == h1 ? q1 : _v_50 == h0 ? q0 : blk_loc(e.mem, _v_50), _v_51, _v_52, _v_52 == h10 ? q10 : _v_52 == h6 ? q6 : _v_52 == h5 ? q5 : _v_52 == h4 ? q4 : _v_52 == h3 ? q3 : _v_52 == h2 ? q2 : _v_52 == h1 ? q1 : _v_52 == h0 ? q0 : blk_loc(e.mem, _v_52), _v_53, _v_54, _v_54 == h10 ? q10 : _v_54 == h6 ? q6 : _v_54 == h5 ? q5 : _v_54 == h4 ? q4 : _v_54 == h3 ? q3 : _v_54 == h2 ? q2 : _v_54 == h1 ? q1 : _v_54 == h0 ? q0 : blk_loc(e.mem, _v_54), _v_55) == 0) {
        return 0;
      }
      _v_74 = _o_11[0];
      _v_75 = _o_11[1];
      _v_76 = _o_11[2];
      _v_77 = _o_11[3];
      _v_78 = _o_11[4];
      _v_79 = _o_11[5];
      _v_80 = _o_11[6];
      _v_81 = _o_11[7];
      _v_82 = _o_11[8];
      _v_83 = _o_11[9];
      _v_84 = _o_11[10];
      _v_27 = _v_74;
      _v_28 = _v_75;
      _v_29 = _v_76;
      _v_30 = _v_77;
      _v_31 = _v_78;
      _v_32 = _v_79;
      _v_33 = _v_80;
      _v_34 = _v_81;
      _v_35 = _v_82;
      _v_36 = _v_83;
      _v_37 = _v_84;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _v_27;
      r2 = _v_28;
      r3 = _v_29;
      r4 = _v_30;
      r5 = _v_31;
      r6 = _v_32;
      r7 = _v_33;
      r8 = _v_34;
      r9 = _v_35;
      r10 = _v_36;
      r11 = _v_37;
      _commands_1 = r0;
      _state_0 = r1;
      _state_1 = r2;
      _state_2 = r3;
      _state_3 = r4;
      _state_4 = r5;
      _state_5 = r6;
      _state_6 = r7;
      _state_7 = r8;
      _state_8 = r9;
      _state_9 = r10;
      _state_10 = r11;
      WL_AGAIN(spin_100);
    }
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_103(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, Term r19, u64 q19, u32 r20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term h19 = r19;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _v_45 = 0;
  Term _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  u32 _ledger_4 = r2;
  Term _ledger_5 = r3;
  Term _mode_2 = r4;
  u32 _result_11 = r5;
  Term _result_12 = r6;
  Term _result_13 = r7;
  Term _result_14 = r8;
  Term _result_15 = r9;
  Term _result_16 = r10;
  Term _result_17 = r11;
  u32 _result_18 = r12;
  Term _result_19 = r13;
  u32 _result_20 = r14;
  Term _result_21 = r15;
  u32 _result_22 = r16;
  Term _result_23 = r17;
  u32 _result_24 = r18;
  Term _result_25 = r19;
  u32 _result_26 = r20;
  Term _result_27 = r21;
  u32 _result_28 = r22;
  u32 _result_29 = r23;
  Term _result_30 = r24;
  Term _result_31 = r25;
  WL_SPIN
    if (_result_11 == 0) {
      _v_28 = 0;
      _v_29 = _namespace_2;
      _v_30 = _next_2;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
      _v_38 = _result_19;
      _v_39 = _result_20;
      _v_40 = term_pak(CID_NIL, 0);
      _v_41 = _ledger_4;
      _v_42 = _ledger_5;
      _v_43 = _mode_2;
      _v_44 = _result_21;
      _v_45 = 0;
      _v_46 = 0;
      _v_47 = 0;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
      _v_52 = 0;
      _v_53 = 0;
    } else {
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _o_1[1];
      if (spin_91(e, _o_1, _result_30, _result_30 == h24 ? q24 : blk_loc(e.mem, _result_30)) == 0) {
        return 0;
      }
      _v_55 = _o_1[0];
      _v_54 = _v_55;
      _v_28 = 2;
      _v_29 = _namespace_2;
      _v_30 = _next_2;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
      _v_38 = _result_19;
      _v_39 = _result_20;
      _v_40 = _v_54;
      _v_41 = _ledger_4;
      _v_42 = _ledger_5;
      _v_43 = _mode_2;
      _v_44 = _result_21;
      _v_45 = _result_22;
      _v_46 = _result_23;
      _v_47 = _result_24;
      _v_48 = _result_25;
      _v_49 = _result_26;
      _v_50 = _result_27;
      _v_51 = _result_28;
      _v_52 = _result_29;
      _v_53 = _result_31;
    }
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  o[14] = _v_42;
  o[15] = _v_43;
  o[16] = _v_44;
  o[17] = _v_45;
  o[18] = _v_46;
  o[19] = _v_47;
  o[20] = _v_48;
  o[21] = _v_49;
  o[22] = _v_50;
  o[23] = _v_51;
  o[24] = _v_52;
  o[25] = _v_53;
  return 1;
}

INLINE Term spin_104(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _selection_1 = r9;
  u32 _namespace_0 = r10;
  WL_SPIN
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _o_0[10];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_98(e, _o_0, ((u64)_rows_8), 1ull, _rows_6, _rows_7, _rows_8, _selection_1, _namespace_0, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _a_0, _a_0 == h5 ? q5 : _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_30 = _o_0[0];
    _v_31 = _o_0[1];
    _v_32 = _o_0[2];
    _v_33 = _o_0[3];
    _v_34 = _o_0[4];
    _v_35 = _o_0[5];
    _v_36 = _o_0[6];
    _v_37 = _o_0[7];
    _v_38 = _o_0[8];
    _v_39 = _o_0[9];
    _v_20 = _v_30;
    _v_21 = _v_31;
    _v_22 = _v_32;
    _v_23 = _v_33;
    _v_24 = _v_34;
    _v_25 = _v_35;
    _v_26 = _v_36;
    _v_27 = _v_37;
    _v_28 = _v_38;
    _v_29 = _v_39;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  return 1;
}

INLINE Term spin_105(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u32 r14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h15 = r15;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  u32 _namespace_1 = r0;
  u32 _next_0 = r1;
  Term _pending_0 = r2;
  u32 _ledger_0 = r3;
  Term _ledger_1 = r4;
  Term _mode_0 = r5;
  Term _result_0 = r6;
  Term _result_1 = r7;
  Term _result_2 = r8;
  Term _result_3 = r9;
  Term _result_4 = r10;
  Term _result_5 = r11;
  u32 _result_6 = r12;
  Term _result_7 = r13;
  u32 _result_8 = r14;
  Term _result_9 = r15;
  WL_SPIN
    _v_56 = _namespace_1;
    _v_57 = _next_0;
    _v_58 = _result_0;
    _v_59 = _result_1;
    _v_60 = _result_2;
    _v_61 = _result_3;
    _v_62 = _result_4;
    _v_63 = _result_5;
    _v_64 = _result_6;
    _v_65 = _result_7;
    _v_66 = _result_8;
    _v_67 = _pending_0;
    _v_68 = _ledger_0;
    _v_69 = _ledger_1;
    _v_70 = _mode_0;
    _v_71 = _result_9;
  break;
  }
  o[0] = _v_56;
  o[1] = _v_57;
  o[2] = _v_58;
  o[3] = _v_59;
  o[4] = _v_60;
  o[5] = _v_61;
  o[6] = _v_62;
  o[7] = _v_63;
  o[8] = _v_64;
  o[9] = _v_65;
  o[10] = _v_66;
  o[11] = _v_67;
  o[12] = _v_68;
  o[13] = _v_69;
  o[14] = _v_70;
  o[15] = _v_71;
  return 1;
}

INLINE Term spin_107(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  WL_SPIN
    _v_8 = 5;
    _v_9 = _id_0;
    _v_10 = 0;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_108(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  Term _main_1 = r1;
  WL_SPIN
    _v_8 = 1;
    _v_9 = _id_0;
    _v_10 = _main_1;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_109(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  WL_SPIN
    _v_8 = 4;
    _v_9 = _id_0;
    _v_10 = 0;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_110(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  Term _flag_1 = r1;
  WL_SPIN
    _v_8 = 2;
    _v_9 = _id_0;
    _v_10 = _flag_1;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_111(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _commands_0 = r0;
  Term _rows_0 = r1;
  Term _rows_1 = r2;
  Term _rows_2 = r3;
  Term _rows_3 = r4;
  Term _rows_4 = r5;
  Term _rows_5 = r6;
  u32 _rows_6 = r7;
  Term _rows_7 = r8;
  u32 _rows_8 = r9;
  WL_SPIN
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _o_0[11];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_100(e, _o_0, _commands_0, _commands_0 == h0 ? q0 : blk_loc(e.mem, _commands_0), _rows_0, _rows_0 == h1 ? q1 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h2 ? q2 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h3 ? q3 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h4 ? q4 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h5 ? q5 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h6 ? q6 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _a_0, _a_0 == h6 ? q6 : _a_0 == h5 ? q5 : _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), 1) == 0) {
      return 0;
    }
    _v_33 = _o_0[0];
    _v_34 = _o_0[1];
    _v_35 = _o_0[2];
    _v_36 = _o_0[3];
    _v_37 = _o_0[4];
    _v_38 = _o_0[5];
    _v_39 = _o_0[6];
    _v_40 = _o_0[7];
    _v_41 = _o_0[8];
    _v_42 = _o_0[9];
    _v_43 = _o_0[10];
    _v_22 = _v_33;
    _v_23 = _v_34;
    _v_24 = _v_35;
    _v_25 = _v_36;
    _v_26 = _v_37;
    _v_27 = _v_38;
    _v_28 = _v_39;
    _v_29 = _v_40;
    _v_30 = _v_41;
    _v_31 = _v_42;
    _v_32 = _v_43;
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_112(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _selection_1 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  Term _world_16 = r4;
  Term _world_17 = r5;
  Term _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  u32 _world_21 = r9;
  Term _world_22 = r10;
  u32 _world_23 = r11;
  Term _world_24 = r12;
  u32 _world_25 = r13;
  WL_SPIN
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    Term _o_0[10];
    if (spin_104(e, _o_0, _world_15, _world_15 == h3 ? q3 : blk_loc(e.mem, _world_15), _world_16, _world_16 == h4 ? q4 : blk_loc(e.mem, _world_16), _world_17, _world_17 == h5 ? q5 : blk_loc(e.mem, _world_17), _world_18, _world_18 == h6 ? q6 : blk_loc(e.mem, _world_18), _world_19, _world_19 == h7 ? q7 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h8 ? q8 : blk_loc(e.mem, _world_20), _world_21, _world_22, _world_23, _selection_1, _world_13) == 0) {
      return 0;
    }
    _v_52 = _o_0[0];
    _v_53 = _o_0[1];
    _v_54 = _o_0[2];
    _v_55 = _o_0[3];
    _v_56 = _o_0[4];
    _v_57 = _o_0[5];
    _v_58 = _o_0[6];
    _v_59 = _o_0[7];
    _v_60 = _o_0[8];
    _v_61 = _o_0[9];
    _v_42 = _v_52;
    _v_43 = _v_53;
    _v_44 = _v_54;
    _v_45 = _v_55;
    _v_46 = _v_56;
    _v_47 = _v_57;
    _v_48 = _v_58;
    _v_49 = _v_59;
    _v_50 = _v_60;
    _v_51 = _v_61;
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_world_25 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      _o_2 = term_pak(CID_UNIT, 0);
    }
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _o_3[16];
    Term _a_0 = term_pak(CID_UNIT, 0);
    if (spin_105(e, _o_3, _world_13, _world_14, _world_24, _world_24 == h12 ? q12 : blk_loc(e.mem, _world_24), _o_1, _o_2, _o_2 == h12 ? q12 : _o_2 == h8 ? q8 : _o_2 == h7 ? q7 : _o_2 == h6 ? q6 : _o_2 == h5 ? q5 : _o_2 == h4 ? q4 : _o_2 == h3 ? q3 : blk_loc(e.mem, _o_2), _a_0, _a_0 == h12 ? q12 : _a_0 == h8 ? q8 : _a_0 == h7 ? q7 : _a_0 == h6 ? q6 : _a_0 == h5 ? q5 : _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : blk_loc(e.mem, _a_0), _v_42, _v_42 == h12 ? q12 : _v_42 == h8 ? q8 : _v_42 == h7 ? q7 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h12 ? q12 : _v_43 == h8 ? q8 : _v_43 == h7 ? q7 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : blk_loc(e.mem, _v_43), _v_44, _v_44 == h12 ? q12 : _v_44 == h8 ? q8 : _v_44 == h7 ? q7 : _v_44 == h6 ? q6 : _v_44 == h5 ? q5 : _v_44 == h4 ? q4 : _v_44 == h3 ? q3 : blk_loc(e.mem, _v_44), _v_45, _v_45 == h12 ? q12 : _v_45 == h8 ? q8 : _v_45 == h7 ? q7 : _v_45 == h6 ? q6 : _v_45 == h5 ? q5 : _v_45 == h4 ? q4 : _v_45 == h3 ? q3 : blk_loc(e.mem, _v_45), _v_46, _v_46 == h12 ? q12 : _v_46 == h8 ? q8 : _v_46 == h7 ? q7 : _v_46 == h6 ? q6 : _v_46 == h5 ? q5 : _v_46 == h4 ? q4 : _v_46 == h3 ? q3 : blk_loc(e.mem, _v_46), _v_47, _v_47 == h12 ? q12 : _v_47 == h8 ? q8 : _v_47 == h7 ? q7 : _v_47 == h6 ? q6 : _v_47 == h5 ? q5 : _v_47 == h4 ? q4 : _v_47 == h3 ? q3 : blk_loc(e.mem, _v_47), _v_48, _v_49, _v_50, _v_51, _v_51 == h12 ? q12 : _v_51 == h8 ? q8 : _v_51 == h7 ? q7 : _v_51 == h6 ? q6 : _v_51 == h5 ? q5 : _v_51 == h4 ? q4 : _v_51 == h3 ? q3 : blk_loc(e.mem, _v_51)) == 0) {
      return 0;
    }
    _v_62 = _o_3[0];
    _v_63 = _o_3[1];
    _v_64 = _o_3[2];
    _v_65 = _o_3[3];
    _v_66 = _o_3[4];
    _v_67 = _o_3[5];
    _v_68 = _o_3[6];
    _v_69 = _o_3[7];
    _v_70 = _o_3[8];
    _v_71 = _o_3[9];
    _v_72 = _o_3[10];
    _v_73 = _o_3[11];
    _v_74 = _o_3[12];
    _v_75 = _o_3[13];
    _v_76 = _o_3[14];
    _v_77 = _o_3[15];
    u32 _o_4 = 0;
    if (_v_74 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
    }
    _v_28 = _v_62;
    _v_29 = _v_63;
    _v_30 = _v_64;
    _v_31 = _v_65;
    _v_32 = _v_66;
    _v_33 = _v_67;
    _v_34 = _v_68;
    _v_35 = _v_69;
    _v_36 = _v_70;
    _v_37 = _v_71;
    _v_38 = _v_72;
    _v_39 = _v_73;
    _v_40 = _o_4;
    _v_41 = _v_77;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  return 1;
}

INLINE Term spin_117(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_138 = 0;
  u32 _v_139 = 0;
  Term _v_140 = 0;
  Term _v_141 = 0;
  Term _v_142 = 0;
  Term _v_143 = 0;
  Term _v_144 = 0;
  Term _v_145 = 0;
  u32 _v_146 = 0;
  Term _v_147 = 0;
  u32 _v_148 = 0;
  Term _v_149 = 0;
  u32 _v_150 = 0;
  Term _v_151 = 0;
  Term _v_152 = 0;
  u32 _v_153 = 0;
  u32 _v_154 = 0;
  u32 _v_155 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  u32 _next_0 = r2;
  Term _rows_0 = r3;
  Term _rows_1 = r4;
  Term _rows_2 = r5;
  Term _rows_3 = r6;
  Term _rows_4 = r7;
  Term _rows_5 = r8;
  u32 _rows_6 = r9;
  Term _rows_7 = r10;
  u32 _rows_8 = r11;
  Term _pending_0 = r12;
  u32 _ledger_0 = r13;
  Term _ledger_1 = r14;
  Term _mode_0 = r15;
  WL_SPIN
    if (_available_0 == 0) {
      _v_138 = _namespace_0;
      _v_139 = _next_0;
      _v_140 = _rows_0;
      _v_141 = _rows_1;
      _v_142 = _rows_2;
      _v_143 = _rows_3;
      _v_144 = _rows_4;
      _v_145 = _rows_5;
      _v_146 = _rows_6;
      _v_147 = _rows_7;
      _v_148 = _rows_8;
      _v_149 = _pending_0;
      _v_150 = _ledger_0;
      _v_151 = _ledger_1;
      _v_152 = _mode_0;
      _v_153 = 0;
      _v_154 = 0;
      _v_155 = 0;
    } else {
      _v_138 = _namespace_0;
      _v_139 = U32_BIN(_next_0, +, 1ull);
      _v_140 = _rows_0;
      _v_141 = _rows_1;
      _v_142 = _rows_2;
      _v_143 = _rows_3;
      _v_144 = _rows_4;
      _v_145 = _rows_5;
      _v_146 = _rows_6;
      _v_147 = _rows_7;
      _v_148 = _rows_8;
      _v_149 = _pending_0;
      _v_150 = _ledger_0;
      _v_151 = _ledger_1;
      _v_152 = _mode_0;
      _v_153 = 1;
      _v_154 = _namespace_0;
      _v_155 = _next_0;
    }
  break;
  }
  o[0] = _v_138;
  o[1] = _v_139;
  o[2] = _v_140;
  o[3] = _v_141;
  o[4] = _v_142;
  o[5] = _v_143;
  o[6] = _v_144;
  o[7] = _v_145;
  o[8] = _v_146;
  o[9] = _v_147;
  o[10] = _v_148;
  o[11] = _v_149;
  o[12] = _v_150;
  o[13] = _v_151;
  o[14] = _v_152;
  o[15] = _v_153;
  o[16] = _v_154;
  o[17] = _v_155;
  return 1;
}

INLINE Term spin_116(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_102 = 0;
  u32 _v_103 = 0;
  Term _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  Term _v_108 = 0;
  Term _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  u32 _v_114 = 0;
  Term _v_115 = 0;
  Term _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _world_28 = r0;
  u32 _world_29 = r1;
  Term _world_30 = r2;
  Term _world_31 = r3;
  Term _world_32 = r4;
  Term _world_33 = r5;
  Term _world_34 = r6;
  Term _world_35 = r7;
  u32 _world_36 = r8;
  Term _world_37 = r9;
  u32 _world_38 = r10;
  Term _world_39 = r11;
  u32 _world_40 = r12;
  Term _world_41 = r13;
  Term _world_42 = r14;
  WL_SPIN
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    Term _v_122 = 0;
    Term _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    Term _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    Term _v_131 = 0;
    u32 _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    Term _o_2[18];
    if (spin_117(e, _o_2, U32_BIN(_world_29, <, 4294967295ull), _world_28, _world_29, _world_30, _world_30 == h2 ? q2 : blk_loc(e.mem, _world_30), _world_31, _world_31 == h3 ? q3 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h4 ? q4 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h5 ? q5 : blk_loc(e.mem, _world_33), _world_34, _world_34 == h6 ? q6 : blk_loc(e.mem, _world_34), _world_35, _world_35 == h7 ? q7 : blk_loc(e.mem, _world_35), _world_36, _world_37, _world_38, _world_39, _world_39 == h11 ? q11 : blk_loc(e.mem, _world_39), _world_40, _world_41, _world_41 == h13 ? q13 : blk_loc(e.mem, _world_41), _world_42, _world_42 == h14 ? q14 : blk_loc(e.mem, _world_42)) == 0) {
      return 0;
    }
    _v_120 = _o_2[0];
    _v_121 = _o_2[1];
    _v_122 = _o_2[2];
    _v_123 = _o_2[3];
    _v_124 = _o_2[4];
    _v_125 = _o_2[5];
    _v_126 = _o_2[6];
    _v_127 = _o_2[7];
    _v_128 = _o_2[8];
    _v_129 = _o_2[9];
    _v_130 = _o_2[10];
    _v_131 = _o_2[11];
    _v_132 = _o_2[12];
    _v_133 = _o_2[13];
    _v_134 = _o_2[14];
    _v_135 = _o_2[15];
    _v_136 = _o_2[16];
    _v_137 = _o_2[17];
    _v_102 = _v_120;
    _v_103 = _v_121;
    _v_104 = _v_122;
    _v_105 = _v_123;
    _v_106 = _v_124;
    _v_107 = _v_125;
    _v_108 = _v_126;
    _v_109 = _v_127;
    _v_110 = _v_128;
    _v_111 = _v_129;
    _v_112 = _v_130;
    _v_113 = _v_131;
    _v_114 = _v_132;
    _v_115 = _v_133;
    _v_116 = _v_134;
    _v_117 = _v_135;
    _v_118 = _v_136;
    _v_119 = _v_137;
  break;
  }
  o[0] = _v_102;
  o[1] = _v_103;
  o[2] = _v_104;
  o[3] = _v_105;
  o[4] = _v_106;
  o[5] = _v_107;
  o[6] = _v_108;
  o[7] = _v_109;
  o[8] = _v_110;
  o[9] = _v_111;
  o[10] = _v_112;
  o[11] = _v_113;
  o[12] = _v_114;
  o[13] = _v_115;
  o[14] = _v_116;
  o[15] = _v_117;
  o[16] = _v_118;
  o[17] = _v_119;
  return 1;
}

INLINE Term spin_121(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_250 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_250 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_4 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_4 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_4);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_121);
    }
  break;
  }
  o[0] = _v_250;
  return 1;
}

INLINE Term spin_120(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_248 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_249 = 0;
    Term _o_4[1];
    Term _a_2 = term_pak(CID_NIL, 0);
    if (spin_121(e, _o_4, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_2, _a_2 == h0 ? q0 : blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_249 = _o_4[0];
    _v_248 = _v_249;
  break;
  }
  o[0] = _v_248;
  return 1;
}

INLINE Term spin_119(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_230 = 0;
  u32 _v_231 = 0;
  Term _v_232 = 0;
  Term _v_233 = 0;
  Term _v_234 = 0;
  Term _v_235 = 0;
  Term _v_236 = 0;
  Term _v_237 = 0;
  u32 _v_238 = 0;
  Term _v_239 = 0;
  u32 _v_240 = 0;
  Term _v_241 = 0;
  u32 _v_242 = 0;
  Term _v_243 = 0;
  Term _v_244 = 0;
  u32 _world_43 = r0;
  u32 _world_44 = r1;
  Term _world_45 = r2;
  Term _world_46 = r3;
  Term _world_47 = r4;
  Term _world_48 = r5;
  Term _world_49 = r6;
  Term _world_50 = r7;
  u32 _world_51 = r8;
  Term _world_52 = r9;
  u32 _world_53 = r10;
  Term _world_54 = r11;
  u32 _world_55 = r12;
  Term _world_56 = r13;
  Term _world_57 = r14;
  Term _staged_0 = r15;
  WL_SPIN
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    Term _o_5[1];
    if (spin_120(e, _o_5, _staged_0, _staged_0 == h15 ? q15 : blk_loc(e.mem, _staged_0)) == 0) {
      return 0;
    }
    _v_247 = _o_5[0];
    _v_246 = _v_247;
    Term _v_251 = 0;
    Term _o_6[1];
    if (spin_121(e, _o_6, _v_246, _v_246 == h15 ? q15 : _v_246 == h14 ? q14 : _v_246 == h13 ? q13 : _v_246 == h11 ? q11 : _v_246 == h7 ? q7 : _v_246 == h6 ? q6 : _v_246 == h5 ? q5 : _v_246 == h4 ? q4 : _v_246 == h3 ? q3 : _v_246 == h2 ? q2 : blk_loc(e.mem, _v_246), _world_54, _world_54 == h11 ? q11 : blk_loc(e.mem, _world_54)) == 0) {
      return 0;
    }
    _v_251 = _o_6[0];
    _v_245 = _v_251;
    _v_230 = _world_43;
    _v_231 = _world_44;
    _v_232 = _world_45;
    _v_233 = _world_46;
    _v_234 = _world_47;
    _v_235 = _world_48;
    _v_236 = _world_49;
    _v_237 = _world_50;
    _v_238 = _world_51;
    _v_239 = _world_52;
    _v_240 = _world_53;
    _v_241 = _v_245;
    _v_242 = _world_55;
    _v_243 = _world_56;
    _v_244 = _world_57;
  break;
  }
  o[0] = _v_230;
  o[1] = _v_231;
  o[2] = _v_232;
  o[3] = _v_233;
  o[4] = _v_234;
  o[5] = _v_235;
  o[6] = _v_236;
  o[7] = _v_237;
  o[8] = _v_238;
  o[9] = _v_239;
  o[10] = _v_240;
  o[11] = _v_241;
  o[12] = _v_242;
  o[13] = _v_243;
  o[14] = _v_244;
  return 1;
}

INLINE Term spin_118(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, Term r15, u32 r16, Term r17, u64 q17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, u32 r21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h17 = r17;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  u32 _v_180 = 0;
  Term _v_181 = 0;
  Term _v_182 = 0;
  Term _v_183 = 0;
  Term _v_184 = 0;
  Term _v_185 = 0;
  Term _v_186 = 0;
  u32 _v_187 = 0;
  Term _v_188 = 0;
  u32 _v_189 = 0;
  Term _v_190 = 0;
  u32 _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  u32 _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  Term _v_197 = 0;
  u32 _v_198 = 0;
  Term _v_199 = 0;
  u32 _bundle_6 = r0;
  Term _bundle_7 = r1;
  u32 _bundle_8 = r2;
  Term _bundle_9 = r3;
  u32 _bundle_10 = r4;
  Term _bundle_11 = r5;
  u32 _result_0 = r6;
  u32 _result_1 = r7;
  Term _result_2 = r8;
  Term _result_3 = r9;
  Term _result_4 = r10;
  Term _result_5 = r11;
  Term _result_6 = r12;
  Term _result_7 = r13;
  u32 _result_8 = r14;
  Term _result_9 = r15;
  u32 _result_10 = r16;
  Term _result_11 = r17;
  u32 _result_12 = r18;
  Term _result_13 = r19;
  Term _result_14 = r20;
  u32 _result_15 = r21;
  u32 _result_16 = r22;
  u32 _result_17 = r23;
  WL_SPIN
    if (_result_15 == 0) {
      _v_178 = 1;
      _v_179 = _result_0;
      _v_180 = _result_1;
      _v_181 = _result_2;
      _v_182 = _result_3;
      _v_183 = _result_4;
      _v_184 = _result_5;
      _v_185 = _result_6;
      _v_186 = _result_7;
      _v_187 = _result_8;
      _v_188 = _result_9;
      _v_189 = _result_10;
      _v_190 = _result_11;
      _v_191 = _result_12;
      _v_192 = _result_13;
      _v_193 = _result_14;
      _v_194 = _bundle_6;
      _v_195 = _bundle_7;
      _v_196 = _bundle_8;
      _v_197 = _bundle_9;
      _v_198 = _bundle_10;
      _v_199 = _bundle_11;
    } else {
      u32 _v_200 = 0;
      u32 _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      Term _v_204 = 0;
      Term _v_205 = 0;
      Term _v_206 = 0;
      Term _v_207 = 0;
      u32 _v_208 = 0;
      Term _v_209 = 0;
      u32 _v_210 = 0;
      Term _v_211 = 0;
      u32 _v_212 = 0;
      Term _v_213 = 0;
      Term _v_214 = 0;
      u64 _nd_2 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_2 + 0] = rfc_seal(e, _result_17);
      e.mem[_nd_2 + 1] = rfc_seal(e, _bundle_6);
      e.mem[_nd_2 + 2] = rfc_seal(e, _bundle_7);
      e.mem[_nd_2 + 3] = rfc_seal(e, _bundle_8);
      e.mem[_nd_2 + 4] = rfc_seal(e, _bundle_9);
      e.mem[_nd_2 + 5] = rfc_seal(e, _bundle_10);
      e.mem[_nd_2 + 6] = rfc_seal(e, _bundle_11);
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_SPAWN, _nd_2));
      e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      Term _v_217 = 0;
      Term _v_218 = 0;
      Term _v_219 = 0;
      Term _v_220 = 0;
      Term _v_221 = 0;
      Term _v_222 = 0;
      u32 _v_223 = 0;
      Term _v_224 = 0;
      u32 _v_225 = 0;
      Term _v_226 = 0;
      u32 _v_227 = 0;
      Term _v_228 = 0;
      Term _v_229 = 0;
      Term _o_7[15];
      Term _a_3 = term_ctr(CID_CON, _nd_3);
      if (spin_119(e, _o_7, _result_0, _result_1, _result_2, _result_2 == h8 ? q8 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h9 ? q9 : blk_loc(e.mem, _result_3), _result_4, _result_4 == h10 ? q10 : blk_loc(e.mem, _result_4), _result_5, _result_5 == h11 ? q11 : blk_loc(e.mem, _result_5), _result_6, _result_6 == h12 ? q12 : blk_loc(e.mem, _result_6), _result_7, _result_7 == h13 ? q13 : blk_loc(e.mem, _result_7), _result_8, _result_9, _result_10, _result_11, _result_11 == h17 ? q17 : blk_loc(e.mem, _result_11), _result_12, _result_13, _result_13 == h19 ? q19 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h20 ? q20 : blk_loc(e.mem, _result_14), _a_3, _a_3 == h20 ? q20 : _a_3 == h19 ? q19 : _a_3 == h17 ? q17 : _a_3 == h13 ? q13 : _a_3 == h12 ? q12 : _a_3 == h11 ? q11 : _a_3 == h10 ? q10 : _a_3 == h9 ? q9 : _a_3 == h8 ? q8 : _a_3 == h5 ? q5 : _a_3 == h3 ? q3 : _a_3 == h1 ? q1 : blk_loc(e.mem, _a_3)) == 0) {
        return 0;
      }
      _v_215 = _o_7[0];
      _v_216 = _o_7[1];
      _v_217 = _o_7[2];
      _v_218 = _o_7[3];
      _v_219 = _o_7[4];
      _v_220 = _o_7[5];
      _v_221 = _o_7[6];
      _v_222 = _o_7[7];
      _v_223 = _o_7[8];
      _v_224 = _o_7[9];
      _v_225 = _o_7[10];
      _v_226 = _o_7[11];
      _v_227 = _o_7[12];
      _v_228 = _o_7[13];
      _v_229 = _o_7[14];
      _v_200 = _v_215;
      _v_201 = _v_216;
      _v_202 = _v_217;
      _v_203 = _v_218;
      _v_204 = _v_219;
      _v_205 = _v_220;
      _v_206 = _v_221;
      _v_207 = _v_222;
      _v_208 = _v_223;
      _v_209 = _v_224;
      _v_210 = _v_225;
      _v_211 = _v_226;
      _v_212 = _v_227;
      _v_213 = _v_228;
      _v_214 = _v_229;
      _v_178 = 0;
      _v_179 = _v_200;
      _v_180 = _v_201;
      _v_181 = _v_202;
      _v_182 = _v_203;
      _v_183 = _v_204;
      _v_184 = _v_205;
      _v_185 = _v_206;
      _v_186 = _v_207;
      _v_187 = _v_208;
      _v_188 = _v_209;
      _v_189 = _v_210;
      _v_190 = _v_211;
      _v_191 = _v_212;
      _v_192 = _v_213;
      _v_193 = _v_214;
      _v_194 = _result_16;
      _v_195 = _result_17;
      _v_196 = 0;
      _v_197 = 0;
      _v_198 = 0;
      _v_199 = 0;
    }
  break;
  }
  o[0] = _v_178;
  o[1] = _v_179;
  o[2] = _v_180;
  o[3] = _v_181;
  o[4] = _v_182;
  o[5] = _v_183;
  o[6] = _v_184;
  o[7] = _v_185;
  o[8] = _v_186;
  o[9] = _v_187;
  o[10] = _v_188;
  o[11] = _v_189;
  o[12] = _v_190;
  o[13] = _v_191;
  o[14] = _v_192;
  o[15] = _v_193;
  o[16] = _v_194;
  o[17] = _v_195;
  o[18] = _v_196;
  o[19] = _v_197;
  o[20] = _v_198;
  o[21] = _v_199;
  return 1;
}

INLINE Term spin_115(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  Term h20 = r20;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _world_13 = r0;
  u32 _world_14 = r1;
  Term _world_15 = r2;
  Term _world_16 = r3;
  Term _world_17 = r4;
  Term _world_18 = r5;
  Term _world_19 = r6;
  Term _world_20 = r7;
  u32 _world_21 = r8;
  Term _world_22 = r9;
  u32 _world_23 = r10;
  Term _world_24 = r11;
  u32 _world_25 = r12;
  Term _world_26 = r13;
  Term _world_27 = r14;
  u32 _bundle_0 = r15;
  Term _bundle_1 = r16;
  u32 _bundle_2 = r17;
  Term _bundle_3 = r18;
  u32 _bundle_4 = r19;
  Term _bundle_5 = r20;
  WL_SPIN
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    u32 _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    Term _v_95 = 0;
    u32 _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    Term _o_3[18];
    if (spin_116(e, _o_3, _world_13, _world_14, _world_15, _world_15 == h2 ? q2 : blk_loc(e.mem, _world_15), _world_16, _world_16 == h3 ? q3 : blk_loc(e.mem, _world_16), _world_17, _world_17 == h4 ? q4 : blk_loc(e.mem, _world_17), _world_18, _world_18 == h5 ? q5 : blk_loc(e.mem, _world_18), _world_19, _world_19 == h6 ? q6 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h7 ? q7 : blk_loc(e.mem, _world_20), _world_21, _world_22, _world_23, _world_24, _world_24 == h11 ? q11 : blk_loc(e.mem, _world_24), _world_25, _world_26, _world_26 == h13 ? q13 : blk_loc(e.mem, _world_26), _world_27, _world_27 == h14 ? q14 : blk_loc(e.mem, _world_27)) == 0) {
      return 0;
    }
    _v_84 = _o_3[0];
    _v_85 = _o_3[1];
    _v_86 = _o_3[2];
    _v_87 = _o_3[3];
    _v_88 = _o_3[4];
    _v_89 = _o_3[5];
    _v_90 = _o_3[6];
    _v_91 = _o_3[7];
    _v_92 = _o_3[8];
    _v_93 = _o_3[9];
    _v_94 = _o_3[10];
    _v_95 = _o_3[11];
    _v_96 = _o_3[12];
    _v_97 = _o_3[13];
    _v_98 = _o_3[14];
    _v_99 = _o_3[15];
    _v_100 = _o_3[16];
    _v_101 = _o_3[17];
    _v_66 = _v_84;
    _v_67 = _v_85;
    _v_68 = _v_86;
    _v_69 = _v_87;
    _v_70 = _v_88;
    _v_71 = _v_89;
    _v_72 = _v_90;
    _v_73 = _v_91;
    _v_74 = _v_92;
    _v_75 = _v_93;
    _v_76 = _v_94;
    _v_77 = _v_95;
    _v_78 = _v_96;
    _v_79 = _v_97;
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    u32 _v_158 = 0;
    Term _v_159 = 0;
    Term _v_160 = 0;
    Term _v_161 = 0;
    Term _v_162 = 0;
    Term _v_163 = 0;
    Term _v_164 = 0;
    u32 _v_165 = 0;
    Term _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    Term _v_170 = 0;
    Term _v_171 = 0;
    u32 _v_172 = 0;
    Term _v_173 = 0;
    u32 _v_174 = 0;
    Term _v_175 = 0;
    u32 _v_176 = 0;
    Term _v_177 = 0;
    Term _o_8[22];
    if (spin_118(e, _o_8, _bundle_0, _bundle_1, _bundle_1 == h16 ? q16 : blk_loc(e.mem, _bundle_1), _bundle_2, _bundle_3, _bundle_3 == h18 ? q18 : blk_loc(e.mem, _bundle_3), _bundle_4, _bundle_5, _bundle_5 == h20 ? q20 : blk_loc(e.mem, _bundle_5), _v_66, _v_67, _v_68, _v_68 == h20 ? q20 : _v_68 == h18 ? q18 : _v_68 == h16 ? q16 : _v_68 == h14 ? q14 : _v_68 == h13 ? q13 : _v_68 == h11 ? q11 : _v_68 == h7 ? q7 : _v_68 == h6 ? q6 : _v_68 == h5 ? q5 : _v_68 == h4 ? q4 : _v_68 == h3 ? q3 : _v_68 == h2 ? q2 : blk_loc(e.mem, _v_68), _v_69, _v_69 == h20 ? q20 : _v_69 == h18 ? q18 : _v_69 == h16 ? q16 : _v_69 == h14 ? q14 : _v_69 == h13 ? q13 : _v_69 == h11 ? q11 : _v_69 == h7 ? q7 : _v_69 == h6 ? q6 : _v_69 == h5 ? q5 : _v_69 == h4 ? q4 : _v_69 == h3 ? q3 : _v_69 == h2 ? q2 : blk_loc(e.mem, _v_69), _v_70, _v_70 == h20 ? q20 : _v_70 == h18 ? q18 : _v_70 == h16 ? q16 : _v_70 == h14 ? q14 : _v_70 == h13 ? q13 : _v_70 == h11 ? q11 : _v_70 == h7 ? q7 : _v_70 == h6 ? q6 : _v_70 == h5 ? q5 : _v_70 == h4 ? q4 : _v_70 == h3 ? q3 : _v_70 == h2 ? q2 : blk_loc(e.mem, _v_70), _v_71, _v_71 == h20 ? q20 : _v_71 == h18 ? q18 : _v_71 == h16 ? q16 : _v_71 == h14 ? q14 : _v_71 == h13 ? q13 : _v_71 == h11 ? q11 : _v_71 == h7 ? q7 : _v_71 == h6 ? q6 : _v_71 == h5 ? q5 : _v_71 == h4 ? q4 : _v_71 == h3 ? q3 : _v_71 == h2 ? q2 : blk_loc(e.mem, _v_71), _v_72, _v_72 == h20 ? q20 : _v_72 == h18 ? q18 : _v_72 == h16 ? q16 : _v_72 == h14 ? q14 : _v_72 == h13 ? q13 : _v_72 == h11 ? q11 : _v_72 == h7 ? q7 : _v_72 == h6 ? q6 : _v_72 == h5 ? q5 : _v_72 == h4 ? q4 : _v_72 == h3 ? q3 : _v_72 == h2 ? q2 : blk_loc(e.mem, _v_72), _v_73, _v_73 == h20 ? q20 : _v_73 == h18 ? q18 : _v_73 == h16 ? q16 : _v_73 == h14 ? q14 : _v_73 == h13 ? q13 : _v_73 == h11 ? q11 : _v_73 == h7 ? q7 : _v_73 == h6 ? q6 : _v_73 == h5 ? q5 : _v_73 == h4 ? q4 : _v_73 == h3 ? q3 : _v_73 == h2 ? q2 : blk_loc(e.mem, _v_73), _v_74, _v_75, _v_76, _v_77, _v_77 == h20 ? q20 : _v_77 == h18 ? q18 : _v_77 == h16 ? q16 : _v_77 == h14 ? q14 : _v_77 == h13 ? q13 : _v_77 == h11 ? q11 : _v_77 == h7 ? q7 : _v_77 == h6 ? q6 : _v_77 == h5 ? q5 : _v_77 == h4 ? q4 : _v_77 == h3 ? q3 : _v_77 == h2 ? q2 : blk_loc(e.mem, _v_77), _v_78, _v_79, _v_79 == h20 ? q20 : _v_79 == h18 ? q18 : _v_79 == h16 ? q16 : _v_79 == h14 ? q14 : _v_79 == h13 ? q13 : _v_79 == h11 ? q11 : _v_79 == h7 ? q7 : _v_79 == h6 ? q6 : _v_79 == h5 ? q5 : _v_79 == h4 ? q4 : _v_79 == h3 ? q3 : _v_79 == h2 ? q2 : blk_loc(e.mem, _v_79), _v_80, _v_80 == h20 ? q20 : _v_80 == h18 ? q18 : _v_80 == h16 ? q16 : _v_80 == h14 ? q14 : _v_80 == h13 ? q13 : _v_80 == h11 ? q11 : _v_80 == h7 ? q7 : _v_80 == h6 ? q6 : _v_80 == h5 ? q5 : _v_80 == h4 ? q4 : _v_80 == h3 ? q3 : _v_80 == h2 ? q2 : blk_loc(e.mem, _v_80), _v_81, _v_82, _v_83) == 0) {
      return 0;
    }
    _v_156 = _o_8[0];
    _v_157 = _o_8[1];
    _v_158 = _o_8[2];
    _v_159 = _o_8[3];
    _v_160 = _o_8[4];
    _v_161 = _o_8[5];
    _v_162 = _o_8[6];
    _v_163 = _o_8[7];
    _v_164 = _o_8[8];
    _v_165 = _o_8[9];
    _v_166 = _o_8[10];
    _v_167 = _o_8[11];
    _v_168 = _o_8[12];
    _v_169 = _o_8[13];
    _v_170 = _o_8[14];
    _v_171 = _o_8[15];
    _v_172 = _o_8[16];
    _v_173 = _o_8[17];
    _v_174 = _o_8[18];
    _v_175 = _o_8[19];
    _v_176 = _o_8[20];
    _v_177 = _o_8[21];
    _v_44 = _v_156;
    _v_45 = _v_157;
    _v_46 = _v_158;
    _v_47 = _v_159;
    _v_48 = _v_160;
    _v_49 = _v_161;
    _v_50 = _v_162;
    _v_51 = _v_163;
    _v_52 = _v_164;
    _v_53 = _v_165;
    _v_54 = _v_166;
    _v_55 = _v_167;
    _v_56 = _v_168;
    _v_57 = _v_169;
    _v_58 = _v_170;
    _v_59 = _v_171;
    _v_60 = _v_172;
    _v_61 = _v_173;
    _v_62 = _v_174;
    _v_63 = _v_175;
    _v_64 = _v_176;
    _v_65 = _v_177;
  break;
  }
  o[0] = _v_44;
  o[1] = _v_45;
  o[2] = _v_46;
  o[3] = _v_47;
  o[4] = _v_48;
  o[5] = _v_49;
  o[6] = _v_50;
  o[7] = _v_51;
  o[8] = _v_52;
  o[9] = _v_53;
  o[10] = _v_54;
  o[11] = _v_55;
  o[12] = _v_56;
  o[13] = _v_57;
  o[14] = _v_58;
  o[15] = _v_59;
  o[16] = _v_60;
  o[17] = _v_61;
  o[18] = _v_62;
  o[19] = _v_63;
  o[20] = _v_64;
  o[21] = _v_65;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_QUERY_AUX_READ_0)
  {
    u32 _owner_0 = r0;
    Term _owner_1 = r1;
    u32 _owner_2 = r2;
    WL_OPEN
    if (_owner_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      WL_RETN(5);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_QUERY_AUX_READ_0_K9;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_QUERY_AUX_READ_0_K9, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_QUERY_AUX_READ_0_K9, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OWNERS_HEALTH_OBSERVE)) {
        u64 _t_1 = task_node(e, FID_OWNERS_HEALTH_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owner_1;
        e.mem[_t_1 + 1] = _owner_2;
        return term_tsk(FID_OWNERS_HEALTH_OBSERVE, _t_1);
      }
      r0 = _owner_1;
      r1 = _owner_2;
      WL_JMP(FID_OWNERS_HEALTH_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_AUX_READ_0_K9)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    Term _a_0 = term_ctr(CID_OWNERS_HEALTH, _nd_0);
    if (spin_4(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    u32 _o_1 = 0;
    Term _o_2 = 0;
    u32 _o_3 = 0;
    if (_v_0 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      u32 _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      _o_2 = _f_0;
      _o_3 = _f_1;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _v_2;
    r4 = _v_3;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY)
  {
    Term _depth_0 = r0;
    WL_OPEN
    WL_SPIN
    if (_depth_0 == 0) {
      Term _fv_0[2];
      _fv_0[0] = 0;
      _fv_0[1] = 0;
      r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
      WL_RETN(1);
    } else {
      Term _d_0 = (_depth_0 - 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _d_0;
        STK(1) = FID_STORAGE_SLOTS_EMPTY_K24;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K24, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _d_0;
        WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K24, _t_0);
        WL_IDX = 1;
      }
      r0 = _d_0;
      _depth_0 = r0;
      WL_AGAIN(FID_STORAGE_SLOTS_EMPTY);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K24)
  {
    WL_POPN(1);
    Term _d_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_STORAGE_SLOTS_EMPTY_K25;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K25, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K25, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_2 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _d_1;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_2);
    }
    r0 = _d_1;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K25)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_2, _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_MAIN_READ_0)
  {
    Term _owner_0 = r0;
    u32 _owner_1 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_OWNERS_MOTION_OBSERVE)) {
      u64 _t_0 = task_node(e, FID_OWNERS_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _owner_0;
      e.mem[_t_0 + 1] = _owner_1;
      return term_tsk(FID_OWNERS_MOTION_OBSERVE, _t_0);
    }
    r0 = _owner_0;
    r1 = _owner_1;
    WL_JMP(FID_OWNERS_MOTION_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0)
  {
    u32 _handle_0 = r0;
    u32 _handle_1 = r1;
    u32 _flag_0 = r2;
    Term _p_0 = r3;
    u32 _p_1 = r4;
    u32 _u_0 = r5;
    Term _u_1 = r6;
    u32 _u_2 = r7;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _handle_0;
      STK(1) = _handle_1;
      STK(2) = _flag_0;
      STK(3) = _u_0;
      STK(4) = _u_1;
      STK(5) = _u_2;
      STK(6) = FID_CALLBACK_0_K50;
      WL_PUSHN(7);
    } else {
      u64 _t_0 = task_node(e, FID_CALLBACK_0_K50, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _handle_0;
      e.mem[_t_0 + 1] = _handle_1;
      e.mem[_t_0 + 2] = _flag_0;
      e.mem[_t_0 + 3] = _u_0;
      e.mem[_t_0 + 4] = _u_1;
      e.mem[_t_0 + 5] = _u_2;
      WL_CONT = term_tsk(FID_CALLBACK_0_K50, _t_0);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUERY_MAIN_READ_0)) {
      u64 _t_1 = task_node(e, FID_QUERY_MAIN_READ_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _p_0;
      e.mem[_t_1 + 1] = _p_1;
      return term_tsk(FID_QUERY_MAIN_READ_0, _t_1);
    }
    r0 = _p_0;
    r1 = _p_1;
    WL_JMP(FID_QUERY_MAIN_READ_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K50)
  {
    WL_POPN(6);
    u32 _handle_2 = STK(0);
    u32 _handle_3 = STK(1);
    u32 _flag_1 = STK(2);
    u32 _u_3 = STK(3);
    Term _u_4 = STK(4);
    u32 _u_5 = STK(5);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _handle_2;
      STK(1) = _handle_3;
      STK(2) = _flag_1;
      STK(3) = _h_0;
      STK(4) = _h_1;
      STK(5) = _h_2;
      STK(6) = FID_CALLBACK_0_K51;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID_CALLBACK_0_K51, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _handle_2;
      e.mem[_t_2 + 1] = _handle_3;
      e.mem[_t_2 + 2] = _flag_1;
      e.mem[_t_2 + 3] = _h_0;
      e.mem[_t_2 + 4] = _h_1;
      e.mem[_t_2 + 5] = _h_2;
      WL_CONT = term_tsk(FID_CALLBACK_0_K51, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUERY_AUX_READ_0)) {
      u64 _t_3 = task_node(e, FID_QUERY_AUX_READ_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _u_3;
      e.mem[_t_3 + 1] = _u_4;
      e.mem[_t_3 + 2] = _u_5;
      return term_tsk(FID_QUERY_AUX_READ_0, _t_3);
    }
    r0 = _u_3;
    r1 = _u_4;
    r2 = _u_5;
    WL_JMP(FID_QUERY_AUX_READ_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K51)
  {
    WL_POPN(6);
    u32 _handle_4 = STK(0);
    u32 _handle_5 = STK(1);
    u32 _flag_2 = STK(2);
    Term _h_8 = STK(3);
    u32 _h_9 = STK(4);
    Term _h_10 = STK(5);
    u32 _h_3 = r0;
    Term _h_4 = r1;
    u32 _h_5 = r2;
    u32 _h_6 = r3;
    Term _h_7 = r4;
    WL_OPEN
    Term _b_0 = 0;
    if (_h_3 == 0) {
      _b_0 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_4);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_5);
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_OWNERS_HEALTH, _nd_0));
      _b_0 = term_ctr(CID_SOME, _nd_1);
    }
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_8);
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_9);
    Term _p_2 = term_ctr(CID_OWNERS_MOTION, _nd_2);
    if (seq) {
      WL_ROOM(8);
      STK(0) = _flag_2;
      STK(1) = _h_10;
      STK(2) = _p_2;
      STK(3) = _handle_5;
      STK(4) = _b_0;
      STK(5) = _h_6;
      STK(6) = _h_7;
      STK(7) = FID_CALLBACK_0_K52;
      WL_PUSHN(8);
    } else {
      u64 _t_4 = task_node(e, FID_CALLBACK_0_K52, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _flag_2;
      e.mem[_t_4 + 1] = _h_10;
      e.mem[_t_4 + 2] = _p_2;
      e.mem[_t_4 + 3] = _handle_5;
      e.mem[_t_4 + 4] = _b_0;
      e.mem[_t_4 + 5] = _h_6;
      e.mem[_t_4 + 6] = _h_7;
      WL_CONT = term_tsk(FID_CALLBACK_0_K52, _t_4);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _handle_4;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _handle_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K52)
  {
    WL_POPN(7);
    u32 _flag_3 = STK(0);
    Term _h_12 = STK(1);
    Term _p_3 = STK(2);
    u32 _handle_6 = STK(3);
    Term _b_1 = STK(4);
    u32 _h_13 = STK(5);
    Term _h_14 = STK(6);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _flag_3;
      STK(1) = _h_12;
      STK(2) = _p_3;
      STK(3) = _b_1;
      STK(4) = _h_13;
      STK(5) = _h_14;
      STK(6) = _h_11;
      STK(7) = FID_CALLBACK_0_K53;
      WL_PUSHN(8);
    } else {
      u64 _t_6 = task_node(e, FID_CALLBACK_0_K53, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _flag_3;
      e.mem[_t_6 + 1] = _h_12;
      e.mem[_t_6 + 2] = _p_3;
      e.mem[_t_6 + 3] = _b_1;
      e.mem[_t_6 + 4] = _h_13;
      e.mem[_t_6 + 5] = _h_14;
      e.mem[_t_6 + 6] = _h_11;
      WL_CONT = term_tsk(FID_CALLBACK_0_K53, _t_6);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _handle_6;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _handle_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K53)
  {
    WL_POPN(7);
    u32 _flag_4 = STK(0);
    Term _h_16 = STK(1);
    Term _p_4 = STK(2);
    Term _b_2 = STK(3);
    u32 _h_17 = STK(4);
    Term _h_18 = STK(5);
    Term _h_19 = STK(6);
    Term _h_15 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_5(e, _o_0, _flag_4) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_16;
      STK(1) = _p_4;
      STK(2) = _b_2;
      STK(3) = _h_17;
      STK(4) = _h_18;
      STK(5) = _h_19;
      STK(6) = _h_15;
      STK(7) = FID_CALLBACK_0_K54;
      WL_PUSHN(8);
    } else {
      u64 _t_8 = task_node(e, FID_CALLBACK_0_K54, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_16;
      e.mem[_t_8 + 1] = _p_4;
      e.mem[_t_8 + 2] = _b_2;
      e.mem[_t_8 + 3] = _h_17;
      e.mem[_t_8 + 4] = _h_18;
      e.mem[_t_8 + 5] = _h_19;
      e.mem[_t_8 + 6] = _h_15;
      WL_CONT = term_tsk(FID_CALLBACK_0_K54, _t_8);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_9 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K54)
  {
    WL_POPN(7);
    Term _h_21 = STK(0);
    Term _p_5 = STK(1);
    Term _b_3 = STK(2);
    u32 _h_22 = STK(3);
    Term _h_23 = STK(4);
    Term _h_24 = STK(5);
    Term _h_25 = STK(6);
    Term _h_20 = r0;
    WL_OPEN
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_1[1];
    if (spin_6(e, _o_1, _h_22, _h_23, blk_loc(e.mem, _h_23)) == 0) {
      return 0;
    }
    _v_3 = _o_1[0];
    _v_2 = _v_3;
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_21;
      STK(1) = _p_5;
      STK(2) = _b_3;
      STK(3) = _h_24;
      STK(4) = _h_25;
      STK(5) = FID_CALLBACK_0_K55;
      WL_PUSHN(6);
    } else {
      u64 _t_10 = task_node(e, FID_CALLBACK_0_K55, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_21;
      e.mem[_t_10 + 1] = _p_5;
      e.mem[_t_10 + 2] = _b_3;
      e.mem[_t_10 + 3] = _h_24;
      e.mem[_t_10 + 4] = _h_25;
      WL_CONT = term_tsk(FID_CALLBACK_0_K55, _t_10);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _v_2;
      e.mem[_t_11 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _v_2;
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K55)
  {
    WL_POPN(5);
    Term _h_27 = STK(0);
    Term _p_6 = STK(1);
    Term _b_4 = STK(2);
    Term _h_28 = STK(3);
    Term _h_29 = STK(4);
    Term _h_26 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_27;
      STK(1) = _p_6;
      STK(2) = _b_4;
      STK(3) = _h_28;
      STK(4) = _h_29;
      STK(5) = FID_CALLBACK_0_K56;
      WL_PUSHN(6);
    } else {
      u64 _t_12 = task_node(e, FID_CALLBACK_0_K56, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_27;
      e.mem[_t_12 + 1] = _p_6;
      e.mem[_t_12 + 2] = _b_4;
      e.mem[_t_12 + 3] = _h_28;
      e.mem[_t_12 + 4] = _h_29;
      WL_CONT = term_tsk(FID_CALLBACK_0_K56, _t_12);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_13 + 1] = _h_26;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_26;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K56)
  {
    WL_POPN(5);
    Term _h_31 = STK(0);
    Term _p_7 = STK(1);
    Term _b_5 = STK(2);
    Term _h_32 = STK(3);
    Term _h_33 = STK(4);
    Term _h_30 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _p_7;
      STK(1) = _b_5;
      STK(2) = _h_32;
      STK(3) = _h_33;
      STK(4) = FID_CALLBACK_0_K57;
      WL_PUSHN(5);
    } else {
      u64 _t_14 = task_node(e, FID_CALLBACK_0_K57, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _p_7;
      e.mem[_t_14 + 1] = _b_5;
      e.mem[_t_14 + 2] = _h_32;
      e.mem[_t_14 + 3] = _h_33;
      WL_CONT = term_tsk(FID_CALLBACK_0_K57, _t_14);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_31;
      e.mem[_t_15 + 1] = _h_30;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_31;
    r1 = _h_30;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K57)
  {
    WL_POPN(4);
    Term _p_8 = STK(0);
    Term _b_6 = STK(1);
    Term _h_35 = STK(2);
    Term _h_36 = STK(3);
    Term _h_34 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _p_8;
      STK(1) = _b_6;
      STK(2) = _h_35;
      STK(3) = _h_36;
      STK(4) = FID_CALLBACK_0_K58;
      WL_PUSHN(5);
    } else {
      u64 _t_16 = task_node(e, FID_CALLBACK_0_K58, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _p_8;
      e.mem[_t_16 + 1] = _b_6;
      e.mem[_t_16 + 2] = _h_35;
      e.mem[_t_16 + 3] = _h_36;
      WL_CONT = term_tsk(FID_CALLBACK_0_K58, _t_16);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_17 + 1] = _h_34;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_34;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K58)
  {
    WL_POPN(4);
    Term _p_9 = STK(0);
    Term _b_7 = STK(1);
    Term _h_38 = STK(2);
    Term _h_39 = STK(3);
    Term _h_37 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _p_9;
      STK(1) = _b_7;
      STK(2) = _h_38;
      STK(3) = FID_CALLBACK_0_K59;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID_CALLBACK_0_K59, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _p_9;
      e.mem[_t_18 + 1] = _b_7;
      e.mem[_t_18 + 2] = _h_38;
      WL_CONT = term_tsk(FID_CALLBACK_0_K59, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_39;
      e.mem[_t_19 + 1] = _h_37;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_39;
    r1 = _h_37;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K59)
  {
    WL_POPN(3);
    Term _p_10 = STK(0);
    Term _b_8 = STK(1);
    Term _h_41 = STK(2);
    Term _h_40 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _p_10;
      STK(1) = _b_8;
      STK(2) = _h_41;
      STK(3) = FID_CALLBACK_0_K60;
      WL_PUSHN(4);
    } else {
      u64 _t_20 = task_node(e, FID_CALLBACK_0_K60, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _p_10;
      e.mem[_t_20 + 1] = _b_8;
      e.mem[_t_20 + 2] = _h_41;
      WL_CONT = term_tsk(FID_CALLBACK_0_K60, _t_20);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
      e.mem[_t_21 + 1] = _h_40;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 28);
    r1 = _h_40;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K60)
  {
    WL_POPN(3);
    Term _p_11 = STK(0);
    Term _b_9 = STK(1);
    Term _h_43 = STK(2);
    Term _h_42 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _p_11;
      STK(1) = _b_9;
      STK(2) = FID_CALLBACK_0_K61;
      WL_PUSHN(3);
    } else {
      u64 _t_22 = task_node(e, FID_CALLBACK_0_K61, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _p_11;
      e.mem[_t_22 + 1] = _b_9;
      WL_CONT = term_tsk(FID_CALLBACK_0_K61, _t_22);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_43;
      e.mem[_t_23 + 1] = _h_42;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_43;
    r1 = _h_42;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CALLBACK_0_K61)
  {
    WL_POPN(2);
    Term _p_12 = STK(0);
    Term _b_10 = STK(1);
    Term _h_44 = r0;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    u32 _o_4 = 0;
    if (term_aux(_b_10) == CID_NONE) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      Term _fb_0[1];
      u64 _sp_0 = ctr_take(e, _b_10, 1, _fb_0);
      Term _f_0 = _fb_0[0];
      spare_free(e, cls_fit(1), _sp_0);
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      Term _f_1 = _fb_1[0];
      u32 _f_2 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      _o_3 = _f_1;
      _o_4 = _f_2;
    }
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _p_12, 2, _fb_2);
    Term _f_3 = _fb_2[0];
    u32 _f_4 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    r0 = _f_3;
    r1 = _f_4;
    r2 = _o_2;
    r3 = _o_3;
    r4 = _o_4;
    r5 = _h_44;
    WL_RETN(6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW)
  {
    Term _fuel_0 = r0;
    u32 _id_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    WL_OPEN
    if (_fuel_0 == 0) {
      r0 = _rows_0;
      r1 = _rows_1;
      r2 = _rows_2;
      r3 = _rows_3;
      r4 = _rows_4;
      r5 = _rows_5;
      r6 = _rows_6;
      r7 = _rows_7;
      r8 = _rows_8;
      WL_RETN(9);
    } else {
      Term _n_0 = (_fuel_0 - 1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_15(e, _o_0, U32_BIN(_rows_6, <, _id_0), U32_BIN(_rows_6, <=, 65536ull)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _n_0;
      e.mem[_nd_0 + 1] = _id_0;
      if (_v_0 == 0) {
        Term _recurse_0 = term_clo(FID_STORAGE_GROW_C73, _nd_0);
        term_sink(e, _recurse_0);
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        WL_RETN(9);
      } else {
        Term _recurse_1 = term_clo(FID_STORAGE_GROW_C73, _nd_0);
        if (seq) {
          WL_ROOM(11);
          STK(0) = _rows_0;
          STK(1) = _rows_1;
          STK(2) = _rows_2;
          STK(3) = _rows_3;
          STK(4) = _rows_4;
          STK(5) = _rows_5;
          STK(6) = _rows_6;
          STK(7) = _rows_7;
          STK(8) = _rows_8;
          STK(9) = _recurse_1;
          STK(10) = FID_STORAGE_GROW_K75;
          WL_PUSHN(11);
        } else {
          u64 _t_2 = task_node(e, FID_STORAGE_GROW_K75, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _rows_0;
          e.mem[_t_2 + 1] = _rows_1;
          e.mem[_t_2 + 2] = _rows_2;
          e.mem[_t_2 + 3] = _rows_3;
          e.mem[_t_2 + 4] = _rows_4;
          e.mem[_t_2 + 5] = _rows_5;
          e.mem[_t_2 + 6] = _rows_6;
          e.mem[_t_2 + 7] = _rows_7;
          e.mem[_t_2 + 8] = _rows_8;
          e.mem[_t_2 + 9] = _recurse_1;
          WL_CONT = term_tsk(FID_STORAGE_GROW_K75, _t_2);
          WL_IDX = 10;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
          u64 _t_3 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_7;
          return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_3);
        }
        r0 = _rows_7;
        WL_JMP(FID_STORAGE_SLOTS_EMPTY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_C73)
  {
    Term _n_1 = r0;
    u32 _id_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    u32 _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K74;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STORAGE_GROW_K74, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K74, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
      u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _n_1;
      e.mem[_t_1 + 1] = _id_1;
      e.mem[_t_1 + 2] = _f_0;
      e.mem[_t_1 + 3] = _f_1;
      e.mem[_t_1 + 4] = _f_2;
      e.mem[_t_1 + 5] = _f_3;
      e.mem[_t_1 + 6] = _f_4;
      e.mem[_t_1 + 7] = _f_5;
      e.mem[_t_1 + 8] = _f_6;
      e.mem[_t_1 + 9] = _f_7;
      e.mem[_t_1 + 10] = _f_8;
      return term_tsk(FID_STORAGE_GROW, _t_1);
    }
    r0 = _n_1;
    r1 = _id_1;
    r2 = _f_0;
    r3 = _f_1;
    r4 = _f_2;
    r5 = _f_3;
    r6 = _f_4;
    r7 = _f_5;
    r8 = _f_6;
    r9 = _f_7;
    r10 = _f_8;
    WL_JMP(FID_STORAGE_GROW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K74)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    u32 _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_1 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_1 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_1 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_1 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_1 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_1 + 8] = rfc_seal(e, _r_8);
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K75)
  {
    WL_POPN(10);
    Term _rows_9 = STK(0);
    Term _rows_10 = STK(1);
    Term _rows_11 = STK(2);
    Term _rows_12 = STK(3);
    Term _rows_13 = STK(4);
    Term _rows_14 = STK(5);
    u32 _rows_15 = STK(6);
    Term _rows_16 = STK(7);
    u32 _rows_17 = STK(8);
    Term _recurse_2 = STK(9);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_9;
      STK(1) = _rows_10;
      STK(2) = _rows_11;
      STK(3) = _rows_12;
      STK(4) = _rows_13;
      STK(5) = _rows_14;
      STK(6) = _rows_15;
      STK(7) = _rows_16;
      STK(8) = _rows_17;
      STK(9) = _recurse_2;
      STK(10) = _h_0;
      STK(11) = FID_STORAGE_GROW_K76;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_STORAGE_GROW_K76, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _rows_9;
      e.mem[_t_4 + 1] = _rows_10;
      e.mem[_t_4 + 2] = _rows_11;
      e.mem[_t_4 + 3] = _rows_12;
      e.mem[_t_4 + 4] = _rows_13;
      e.mem[_t_4 + 5] = _rows_14;
      e.mem[_t_4 + 6] = _rows_15;
      e.mem[_t_4 + 7] = _rows_16;
      e.mem[_t_4 + 8] = _rows_17;
      e.mem[_t_4 + 9] = _recurse_2;
      e.mem[_t_4 + 10] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_GROW_K76, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_5 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rows_16;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_5);
    }
    r0 = _rows_16;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K76)
  {
    WL_POPN(11);
    Term _rows_18 = STK(0);
    Term _rows_19 = STK(1);
    Term _rows_20 = STK(2);
    Term _rows_21 = STK(3);
    Term _rows_22 = STK(4);
    Term _rows_23 = STK(5);
    u32 _rows_24 = STK(6);
    Term _rows_25 = STK(7);
    u32 _rows_26 = STK(8);
    Term _recurse_3 = STK(9);
    Term _h_2 = STK(10);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _o_1[4];
    if (spin_11(e, _o_1, _rows_20, blk_loc(e.mem, _rows_20), _rows_21, blk_loc(e.mem, _rows_21), _rows_22, blk_loc(e.mem, _rows_22), _rows_23, blk_loc(e.mem, _rows_23), _rows_25) == 0) {
      return 0;
    }
    _v_6 = _o_1[0];
    _v_7 = _o_1[1];
    _v_8 = _o_1[2];
    _v_9 = _o_1[3];
    _v_2 = _v_6;
    _v_3 = _v_7;
    _v_4 = _v_8;
    _v_5 = _v_9;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = rfc_seal(e, blk_node(e, _rows_18, _h_2));
    e.mem[_nd_2 + 1] = rfc_seal(e, blk_node(e, _rows_19, _h_1));
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 6] = rfc_seal(e, U32_BIN(_rows_24, +, _rows_24));
    e.mem[_nd_2 + 7] = rfc_seal(e, nat_chk(e, _rows_25 + 1));
    e.mem[_nd_2 + 8] = rfc_seal(e, _rows_26);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K77;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_STORAGE_GROW_K77, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K77, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _recurse_3;
      e.mem[_t_7 + 1] = term_ctr(CID_STORAGE_ROWS, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _recurse_3;
    r1 = term_ctr(CID_STORAGE_ROWS, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K77)
  {
    Term _r_9 = r0;
    WL_OPEN
    Term _fb_1[9];
    u64 _sp_1 = ctr_take(e, _r_9, 9, _fb_1);
    Term _f_9 = _fb_1[0];
    Term _f_10 = _fb_1[1];
    Term _f_11 = _fb_1[2];
    Term _f_12 = _fb_1[3];
    Term _f_13 = _fb_1[4];
    Term _f_14 = _fb_1[5];
    u32 _f_15 = _fb_1[6];
    Term _f_16 = _fb_1[7];
    u32 _f_17 = _fb_1[8];
    spare_free(e, cls_fit(9), _sp_1);
    r0 = _f_9;
    r1 = _f_10;
    r2 = _f_11;
    r3 = _f_12;
    r4 = _f_13;
    r5 = _f_14;
    r6 = _f_15;
    r7 = _f_16;
    r8 = _f_17;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_READ_MAIN_0)
  {
    u32 _namespace_0 = r0;
    u32 _id_0 = r1;
    Term _main_0 = r2;
    u32 _main_1 = r3;
    u32 _aux_0 = r4;
    Term _aux_1 = r5;
    u32 _aux_2 = r6;
    u32 _flag_0 = r7;
    u32 _added_0 = r8;
    u32 _changed_0 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _id_0;
      STK(1) = _flag_0;
      STK(2) = _added_0;
      STK(3) = _changed_0;
      STK(4) = FID_QUERY_READ_MAIN_0_K82;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID_QUERY_READ_MAIN_0_K82, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _id_0;
      e.mem[_t_0 + 1] = _flag_0;
      e.mem[_t_0 + 2] = _added_0;
      e.mem[_t_0 + 3] = _changed_0;
      WL_CONT = term_tsk(FID_QUERY_READ_MAIN_0_K82, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CALLBACK_0)) {
      u64 _t_1 = task_node(e, FID_CALLBACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _namespace_0;
      e.mem[_t_1 + 1] = _id_0;
      e.mem[_t_1 + 2] = _flag_0;
      e.mem[_t_1 + 3] = _main_0;
      e.mem[_t_1 + 4] = _main_1;
      e.mem[_t_1 + 5] = _aux_0;
      e.mem[_t_1 + 6] = _aux_1;
      e.mem[_t_1 + 7] = _aux_2;
      return term_tsk(FID_CALLBACK_0, _t_1);
    }
    r0 = _namespace_0;
    r1 = _id_0;
    r2 = _flag_0;
    r3 = _main_0;
    r4 = _main_1;
    r5 = _aux_0;
    r6 = _aux_1;
    r7 = _aux_2;
    WL_JMP(FID_CALLBACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_READ_MAIN_0_K82)
  {
    WL_POPN(4);
    u32 _id_1 = STK(0);
    u32 _flag_1 = STK(1);
    u32 _added_1 = STK(2);
    u32 _changed_1 = STK(3);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_flag_1 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_h_2 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_3);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_4);
      _o_3 = term_ctr(CID_OWNERS_HEALTH, _nd_1);
    }
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    Term _o_4[10];
    Term _a_0 = term_ctr(CID_OWNERS_MOTION, _nd_0);
    if (spin_30(e, _o_4, _id_1, _o_0, _o_1, blk_loc(e.mem, _o_1), _added_1, _changed_1, _a_0, blk_loc(e.mem, _a_0), _o_2, _o_3, blk_loc(e.mem, _o_3), _h_5, blk_loc(e.mem, _h_5)) == 0) {
      return 0;
    }
    _v_0 = _o_4[0];
    _v_1 = _o_4[1];
    _v_2 = _o_4[2];
    _v_3 = _o_4[3];
    _v_4 = _o_4[4];
    _v_5 = _o_4[5];
    _v_6 = _o_4[6];
    _v_7 = _o_4[7];
    _v_8 = _o_4[8];
    _v_9 = _o_4[9];
    u32 _o_5 = 0;
    Term _o_6 = 0;
    u32 _o_7 = 0;
    if (_v_1 == 0) {
      _o_5 = 0;
    } else {
      _o_5 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_2, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      u32 _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      _o_6 = _f_0;
      _o_7 = _f_1;
    }
    u32 _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    if (_v_3 == 0) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _v_4, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      _o_9 = _f_2;
      _o_10 = _f_3;
    }
    u32 _o_11 = 0;
    if (_v_5 == 0) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
    }
    r0 = _v_0;
    r1 = _o_5;
    r2 = _o_6;
    r3 = _o_7;
    r4 = _o_8;
    r5 = _o_9;
    r6 = _o_10;
    r7 = _o_11;
    r8 = _v_7;
    r9 = _v_8;
    r10 = _v_9;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    u32 _row_0 = r9;
    u32 _row_1 = r10;
    Term _row_2 = r11;
    u32 _row_3 = r12;
    Term _row_4 = r13;
    u32 _row_5 = r14;
    Term _row_6 = r15;
    u32 _row_7 = r16;
    u32 _row_8 = r17;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_15(e, _o_0, U32_BIN(0ull, <, _row_0), U32_BIN(_row_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (_v_0 == 0) {
      r0 = 1;
      r1 = _rows_0;
      r2 = _rows_1;
      r3 = _rows_2;
      r4 = _rows_3;
      r5 = _rows_4;
      r6 = _rows_5;
      r7 = _rows_6;
      r8 = _rows_7;
      r9 = _rows_8;
      r10 = _row_0;
      r11 = _row_1;
      r12 = _row_2;
      r13 = _row_3;
      r14 = _row_4;
      r15 = _row_5;
      r16 = _row_6;
      r17 = _row_7;
      r18 = _row_8;
      WL_RETN(19);
    } else {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _row_0;
        STK(1) = _row_1;
        STK(2) = _row_2;
        STK(3) = _row_3;
        STK(4) = _row_4;
        STK(5) = _row_5;
        STK(6) = _row_6;
        STK(7) = _row_7;
        STK(8) = _row_8;
        STK(9) = FID_STORAGE_ROWS_PLACE_K129;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_ROWS_PLACE_K129, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _row_0;
        e.mem[_t_0 + 1] = _row_1;
        e.mem[_t_0 + 2] = _row_2;
        e.mem[_t_0 + 3] = _row_3;
        e.mem[_t_0 + 4] = _row_4;
        e.mem[_t_0 + 5] = _row_5;
        e.mem[_t_0 + 6] = _row_6;
        e.mem[_t_0 + 7] = _row_7;
        e.mem[_t_0 + 8] = _row_8;
        WL_CONT = term_tsk(FID_STORAGE_ROWS_PLACE_K129, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
        u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = 17ull;
        e.mem[_t_1 + 1] = _row_0;
        e.mem[_t_1 + 2] = _rows_0;
        e.mem[_t_1 + 3] = _rows_1;
        e.mem[_t_1 + 4] = _rows_2;
        e.mem[_t_1 + 5] = _rows_3;
        e.mem[_t_1 + 6] = _rows_4;
        e.mem[_t_1 + 7] = _rows_5;
        e.mem[_t_1 + 8] = _rows_6;
        e.mem[_t_1 + 9] = _rows_7;
        e.mem[_t_1 + 10] = _rows_8;
        return term_tsk(FID_STORAGE_GROW, _t_1);
      }
      r0 = 17ull;
      r1 = _row_0;
      r2 = _rows_0;
      r3 = _rows_1;
      r4 = _rows_2;
      r5 = _rows_3;
      r6 = _rows_4;
      r7 = _rows_5;
      r8 = _rows_6;
      r9 = _rows_7;
      r10 = _rows_8;
      WL_JMP(FID_STORAGE_GROW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE_K129)
  {
    WL_POPN(9);
    u32 _row_9 = STK(0);
    u32 _row_10 = STK(1);
    Term _row_11 = STK(2);
    u32 _row_12 = STK(3);
    Term _row_13 = STK(4);
    u32 _row_14 = STK(5);
    Term _row_15 = STK(6);
    u32 _row_16 = STK(7);
    u32 _row_17 = STK(8);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _o_1[19];
    if (spin_35(e, _o_1, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, _row_9, _row_10, _row_11, blk_loc(e.mem, _row_11), _row_12, _row_13, blk_loc(e.mem, _row_13), _row_14, _row_15, blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    _v_3 = _o_1[1];
    _v_4 = _o_1[2];
    _v_5 = _o_1[3];
    _v_6 = _o_1[4];
    _v_7 = _o_1[5];
    _v_8 = _o_1[6];
    _v_9 = _o_1[7];
    _v_10 = _o_1[8];
    _v_11 = _o_1[9];
    _v_12 = _o_1[10];
    _v_13 = _o_1[11];
    _v_14 = _o_1[12];
    _v_15 = _o_1[13];
    _v_16 = _o_1[14];
    _v_17 = _o_1[15];
    _v_18 = _o_1[16];
    _v_19 = _o_1[17];
    _v_20 = _o_1[18];
    r0 = _v_2;
    r1 = _v_3;
    r2 = _v_4;
    r3 = _v_5;
    r4 = _v_6;
    r5 = _v_7;
    r6 = _v_8;
    r7 = _v_9;
    r8 = _v_10;
    r9 = _v_11;
    r10 = _v_12;
    r11 = _v_13;
    r12 = _v_14;
    r13 = _v_15;
    r14 = _v_16;
    r15 = _v_17;
    r16 = _v_18;
    r17 = _v_19;
    r18 = _v_20;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_READ_ROW_0)
  {
    u32 _selection_0 = r0;
    u32 _namespace_0 = r1;
    u32 _row_0 = r2;
    u32 _row_1 = r3;
    Term _row_2 = r4;
    u32 _row_3 = r5;
    u32 _row_4 = r6;
    Term _row_5 = r7;
    u32 _row_6 = r8;
    u32 _row_7 = r9;
    u32 _row_8 = r10;
    u32 _row_9 = r11;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_row_7 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u32 _v_1 = 0;
    Term _o_2[1];
    if (spin_44(e, _o_2, _selection_0, _o_0, _o_1, blk_loc(e.mem, _o_1)) == 0) {
      return 0;
    }
    _v_1 = _o_2[0];
    _v_0 = _v_1;
    if (_v_0 == 0) {
      r0 = _row_0;
      r1 = _row_1;
      r2 = _row_2;
      r3 = _row_3;
      r4 = _row_4;
      r5 = _row_5;
      r6 = _row_6;
      r7 = _row_7;
      r8 = _row_8;
      r9 = _row_9;
      r10 = 0;
      r11 = 0;
      WL_RETN(12);
    } else {
      if (_row_1 == 0) {
        r0 = _row_0;
        r1 = 0;
        r2 = 0;
        r3 = 0;
        r4 = _row_4;
        r5 = _row_5;
        r6 = _row_6;
        r7 = _row_7;
        r8 = _row_8;
        r9 = _row_9;
        r10 = 0;
        r11 = 0;
        WL_RETN(12);
      } else {
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_QUERY_READ_ROW_0_K133;
          WL_PUSHN(1);
        } else {
          u64 _t_0 = task_node(e, FID_QUERY_READ_ROW_0_K133, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_QUERY_READ_ROW_0_K133, _t_0);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_QUERY_READ_MAIN_0)) {
          u64 _t_1 = task_node(e, FID_QUERY_READ_MAIN_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _namespace_0;
          e.mem[_t_1 + 1] = _row_0;
          e.mem[_t_1 + 2] = _row_2;
          e.mem[_t_1 + 3] = _row_3;
          e.mem[_t_1 + 4] = _row_4;
          e.mem[_t_1 + 5] = _row_5;
          e.mem[_t_1 + 6] = _row_6;
          e.mem[_t_1 + 7] = _row_7;
          e.mem[_t_1 + 8] = _row_8;
          e.mem[_t_1 + 9] = _row_9;
          return term_tsk(FID_QUERY_READ_MAIN_0, _t_1);
        }
        r0 = _namespace_0;
        r1 = _row_0;
        r2 = _row_2;
        r3 = _row_3;
        r4 = _row_4;
        r5 = _row_5;
        r6 = _row_6;
        r7 = _row_7;
        r8 = _row_8;
        r9 = _row_9;
        WL_JMP(FID_QUERY_READ_MAIN_0);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_READ_ROW_0_K133)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    WL_OPEN
    u32 _o_3 = 0;
    Term _o_4 = 0;
    if (_h_1 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_3);
      _o_4 = term_ctr(CID_OWNERS_MOTION, _nd_0);
    }
    u32 _o_5 = 0;
    Term _o_6 = 0;
    if (_h_4 == 0) {
      _o_5 = 0;
    } else {
      _o_5 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_5);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_6);
      _o_6 = term_ctr(CID_OWNERS_HEALTH, _nd_1);
    }
    u32 _o_7 = 0;
    Term _o_8 = 0;
    if (_h_7 == 0) {
      _o_7 = 0;
    } else {
      _o_7 = 1;
      _o_8 = term_pak(CID_UNIT, 0);
    }
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _o_9[11];
    if (spin_39(e, _o_9, _h_0, _o_3, _o_4, blk_loc(e.mem, _o_4), _o_5, _o_6, blk_loc(e.mem, _o_6), _o_7, _o_8, blk_loc(e.mem, _o_8), _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10)) == 0) {
      return 0;
    }
    _v_3 = _o_9[0];
    _v_4 = _o_9[1];
    _v_5 = _o_9[2];
    _v_6 = _o_9[3];
    _v_7 = _o_9[4];
    _v_8 = _o_9[5];
    _v_9 = _o_9[6];
    _v_10 = _o_9[7];
    _v_11 = _o_9[8];
    _v_12 = _o_9[9];
    _v_13 = _o_9[10];
    u32 _o_10 = 0;
    Term _o_11 = 0;
    u32 _o_12 = 0;
    if (_v_4 == 0) {
      _o_10 = 0;
    } else {
      _o_10 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_5, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      u32 _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      _o_11 = _f_0;
      _o_12 = _f_1;
    }
    u32 _o_13 = 0;
    Term _o_14 = 0;
    u32 _o_15 = 0;
    if (_v_6 == 0) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _v_7, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      _o_14 = _f_2;
      _o_15 = _f_3;
    }
    u32 _o_16 = 0;
    if (_v_8 == 0) {
      _o_16 = 0;
    } else {
      _o_16 = 1;
    }
    r0 = _v_3;
    r1 = _o_10;
    r2 = _o_11;
    r3 = _o_12;
    r4 = _o_13;
    r5 = _o_14;
    r6 = _o_15;
    r7 = _o_16;
    r8 = _v_10;
    r9 = _v_11;
    r10 = _v_12;
    r11 = _v_13;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE)
  {
    Term _m_0 = r0;
    u32 _m_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_0;
      STK(1) = _m_1;
      STK(2) = FID_OWNERS_HEALTH_OBSERVE_K175;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K175, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _m_0;
      e.mem[_t_0 + 1] = _m_1;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K175, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _m_1;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _m_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K175)
  {
    WL_POPN(2);
    Term _m_2 = STK(0);
    u32 _m_3 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_2;
      STK(1) = _m_3;
      STK(2) = FID_OWNERS_HEALTH_OBSERVE_K176;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K176, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _m_2;
      e.mem[_t_2 + 1] = _m_3;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K176, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 28);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 28);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K176)
  {
    WL_POPN(2);
    Term _m_4 = STK(0);
    u32 _m_5 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    Term _at_0 = blk_loc(e.mem, _m_4);
    Term _at_1 = blk_at(_m_4, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_5;
      STK(1) = _h_1;
      STK(2) = _m_4;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K177;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K177, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _m_5;
      e.mem[_t_4 + 1] = _h_1;
      e.mem[_t_4 + 2] = _m_4;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K177, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _c_0;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _c_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K177)
  {
    WL_POPN(3);
    u32 _m_6 = STK(0);
    Term _h_3 = STK(1);
    Term _m_7 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_6;
      STK(1) = _h_3;
      STK(2) = _m_7;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K178;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K178, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _m_6;
      e.mem[_t_6 + 1] = _h_3;
      e.mem[_t_6 + 2] = _m_7;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K178, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_2;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_2;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K178)
  {
    WL_POPN(3);
    u32 _m_8 = STK(0);
    Term _h_5 = STK(1);
    Term _m_9 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_8;
      STK(1) = _m_9;
      STK(2) = FID_OWNERS_HEALTH_OBSERVE_K179;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K179, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _m_8;
      e.mem[_t_8 + 1] = _m_9;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K179, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_5;
      e.mem[_t_9 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K179)
  {
    WL_POPN(2);
    u32 _m_10 = STK(0);
    Term _m_11 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    Term _at_2 = blk_loc(e.mem, _m_11);
    Term _at_3 = blk_at(_m_11, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_10;
      STK(1) = _h_6;
      STK(2) = _m_11;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K180;
      WL_PUSHN(4);
    } else {
      u64 _t_10 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K180, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _m_10;
      e.mem[_t_10 + 1] = _h_6;
      e.mem[_t_10 + 2] = _m_11;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K180, _t_10);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _c_1;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _c_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K180)
  {
    WL_POPN(3);
    u32 _m_12 = STK(0);
    Term _h_8 = STK(1);
    Term _m_13 = STK(2);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_12;
      STK(1) = _h_8;
      STK(2) = _m_13;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K181;
      WL_PUSHN(4);
    } else {
      u64 _t_12 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K181, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _m_12;
      e.mem[_t_12 + 1] = _h_8;
      e.mem[_t_12 + 2] = _m_13;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K181, _t_12);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_7;
      e.mem[_t_13 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_7;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K181)
  {
    WL_POPN(3);
    u32 _m_14 = STK(0);
    Term _h_10 = STK(1);
    Term _m_15 = STK(2);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_14;
      STK(1) = _m_15;
      STK(2) = FID_OWNERS_HEALTH_OBSERVE_K182;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K182, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _m_14;
      e.mem[_t_14 + 1] = _m_15;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K182, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_10;
      e.mem[_t_15 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_10;
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K182)
  {
    WL_POPN(2);
    u32 _m_16 = STK(0);
    Term _m_17 = STK(1);
    Term _h_11 = r0;
    WL_OPEN
    Term _at_4 = blk_loc(e.mem, _m_17);
    Term _at_5 = blk_at(_m_17, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_16;
      STK(1) = _h_11;
      STK(2) = _m_17;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K183;
      WL_PUSHN(4);
    } else {
      u64 _t_16 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _m_16;
      e.mem[_t_16 + 1] = _h_11;
      e.mem[_t_16 + 2] = _m_17;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K183, _t_16);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _c_2;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _c_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K183)
  {
    WL_POPN(3);
    u32 _m_18 = STK(0);
    Term _h_13 = STK(1);
    Term _m_19 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_18;
      STK(1) = _h_13;
      STK(2) = _m_19;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K184;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K184, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _m_18;
      e.mem[_t_18 + 1] = _h_13;
      e.mem[_t_18 + 2] = _m_19;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K184, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_12;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K184)
  {
    WL_POPN(3);
    u32 _m_20 = STK(0);
    Term _h_15 = STK(1);
    Term _m_21 = STK(2);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_20;
      STK(1) = _m_21;
      STK(2) = FID_OWNERS_HEALTH_OBSERVE_K185;
      WL_PUSHN(3);
    } else {
      u64 _t_20 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K185, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _m_20;
      e.mem[_t_20 + 1] = _m_21;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K185, _t_20);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_15;
      e.mem[_t_21 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_15;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K185)
  {
    WL_POPN(2);
    u32 _m_22 = STK(0);
    Term _m_23 = STK(1);
    Term _h_16 = r0;
    WL_OPEN
    Term _at_6 = blk_loc(e.mem, _m_23);
    Term _at_7 = blk_at(_m_23, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_22;
      STK(1) = _h_16;
      STK(2) = _m_23;
      STK(3) = FID_OWNERS_HEALTH_OBSERVE_K186;
      WL_PUSHN(4);
    } else {
      u64 _t_22 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _m_22;
      e.mem[_t_22 + 1] = _h_16;
      e.mem[_t_22 + 2] = _m_23;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K186, _t_22);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_23 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _c_3;
      return term_tsk(FID_U32_SHOW, _t_23);
    }
    r0 = _c_3;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K186)
  {
    WL_POPN(3);
    u32 _m_24 = STK(0);
    Term _h_18 = STK(1);
    Term _m_25 = STK(2);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_24;
      STK(1) = _m_25;
      STK(2) = FID_OWNERS_HEALTH_OBSERVE_K187;
      WL_PUSHN(3);
    } else {
      u64 _t_24 = task_node(e, FID_OWNERS_HEALTH_OBSERVE_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _m_24;
      e.mem[_t_24 + 1] = _m_25;
      WL_CONT = term_tsk(FID_OWNERS_HEALTH_OBSERVE_K187, _t_24);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_18;
      e.mem[_t_25 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _h_18;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_HEALTH_OBSERVE_K187)
  {
    WL_POPN(2);
    u32 _m_26 = STK(0);
    Term _m_27 = STK(1);
    Term _h_19 = r0;
    WL_OPEN
    r0 = _m_27;
    r1 = _m_26;
    r2 = _h_19;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE)
  {
    Term _m_0 = r0;
    u32 _m_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_0;
      STK(1) = _m_1;
      STK(2) = FID_OWNERS_MOTION_OBSERVE_K190;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K190, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _m_0;
      e.mem[_t_0 + 1] = _m_1;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K190, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _m_1;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _m_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K190)
  {
    WL_POPN(2);
    Term _m_2 = STK(0);
    u32 _m_3 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_2;
      STK(1) = _m_3;
      STK(2) = FID_OWNERS_MOTION_OBSERVE_K191;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _m_2;
      e.mem[_t_2 + 1] = _m_3;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K191, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 28);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 28);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K191)
  {
    WL_POPN(2);
    Term _m_4 = STK(0);
    u32 _m_5 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    Term _at_0 = blk_loc(e.mem, _m_4);
    Term _at_1 = blk_at(_m_4, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_5;
      STK(1) = _h_1;
      STK(2) = _m_4;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K192;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K192, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _m_5;
      e.mem[_t_4 + 1] = _h_1;
      e.mem[_t_4 + 2] = _m_4;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K192, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _c_0;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _c_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K192)
  {
    WL_POPN(3);
    u32 _m_6 = STK(0);
    Term _h_3 = STK(1);
    Term _m_7 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_6;
      STK(1) = _h_3;
      STK(2) = _m_7;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K193;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _m_6;
      e.mem[_t_6 + 1] = _h_3;
      e.mem[_t_6 + 2] = _m_7;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K193, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_2;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_2;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K193)
  {
    WL_POPN(3);
    u32 _m_8 = STK(0);
    Term _h_5 = STK(1);
    Term _m_9 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_8;
      STK(1) = _m_9;
      STK(2) = FID_OWNERS_MOTION_OBSERVE_K194;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K194, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _m_8;
      e.mem[_t_8 + 1] = _m_9;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K194, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_5;
      e.mem[_t_9 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K194)
  {
    WL_POPN(2);
    u32 _m_10 = STK(0);
    Term _m_11 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    Term _at_2 = blk_loc(e.mem, _m_11);
    Term _at_3 = blk_at(_m_11, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_10;
      STK(1) = _h_6;
      STK(2) = _m_11;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K195;
      WL_PUSHN(4);
    } else {
      u64 _t_10 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K195, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _m_10;
      e.mem[_t_10 + 1] = _h_6;
      e.mem[_t_10 + 2] = _m_11;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K195, _t_10);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _c_1;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _c_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K195)
  {
    WL_POPN(3);
    u32 _m_12 = STK(0);
    Term _h_8 = STK(1);
    Term _m_13 = STK(2);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_12;
      STK(1) = _h_8;
      STK(2) = _m_13;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K196;
      WL_PUSHN(4);
    } else {
      u64 _t_12 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K196, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _m_12;
      e.mem[_t_12 + 1] = _h_8;
      e.mem[_t_12 + 2] = _m_13;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K196, _t_12);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_7;
      e.mem[_t_13 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_7;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K196)
  {
    WL_POPN(3);
    u32 _m_14 = STK(0);
    Term _h_10 = STK(1);
    Term _m_15 = STK(2);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_14;
      STK(1) = _m_15;
      STK(2) = FID_OWNERS_MOTION_OBSERVE_K197;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K197, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _m_14;
      e.mem[_t_14 + 1] = _m_15;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K197, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_10;
      e.mem[_t_15 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_10;
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K197)
  {
    WL_POPN(2);
    u32 _m_16 = STK(0);
    Term _m_17 = STK(1);
    Term _h_11 = r0;
    WL_OPEN
    Term _at_4 = blk_loc(e.mem, _m_17);
    Term _at_5 = blk_at(_m_17, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_16;
      STK(1) = _h_11;
      STK(2) = _m_17;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K198;
      WL_PUSHN(4);
    } else {
      u64 _t_16 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _m_16;
      e.mem[_t_16 + 1] = _h_11;
      e.mem[_t_16 + 2] = _m_17;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K198, _t_16);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _c_2;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _c_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K198)
  {
    WL_POPN(3);
    u32 _m_18 = STK(0);
    Term _h_13 = STK(1);
    Term _m_19 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_18;
      STK(1) = _h_13;
      STK(2) = _m_19;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K199;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K199, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _m_18;
      e.mem[_t_18 + 1] = _h_13;
      e.mem[_t_18 + 2] = _m_19;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K199, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_12;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K199)
  {
    WL_POPN(3);
    u32 _m_20 = STK(0);
    Term _h_15 = STK(1);
    Term _m_21 = STK(2);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_20;
      STK(1) = _m_21;
      STK(2) = FID_OWNERS_MOTION_OBSERVE_K200;
      WL_PUSHN(3);
    } else {
      u64 _t_20 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K200, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _m_20;
      e.mem[_t_20 + 1] = _m_21;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K200, _t_20);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_15;
      e.mem[_t_21 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_15;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K200)
  {
    WL_POPN(2);
    u32 _m_22 = STK(0);
    Term _m_23 = STK(1);
    Term _h_16 = r0;
    WL_OPEN
    Term _at_6 = blk_loc(e.mem, _m_23);
    Term _at_7 = blk_at(_m_23, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_22;
      STK(1) = _h_16;
      STK(2) = _m_23;
      STK(3) = FID_OWNERS_MOTION_OBSERVE_K201;
      WL_PUSHN(4);
    } else {
      u64 _t_22 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _m_22;
      e.mem[_t_22 + 1] = _h_16;
      e.mem[_t_22 + 2] = _m_23;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K201, _t_22);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_23 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _c_3;
      return term_tsk(FID_U32_SHOW, _t_23);
    }
    r0 = _c_3;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K201)
  {
    WL_POPN(3);
    u32 _m_24 = STK(0);
    Term _h_18 = STK(1);
    Term _m_25 = STK(2);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_24;
      STK(1) = _m_25;
      STK(2) = FID_OWNERS_MOTION_OBSERVE_K202;
      WL_PUSHN(3);
    } else {
      u64 _t_24 = task_node(e, FID_OWNERS_MOTION_OBSERVE_K202, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _m_24;
      e.mem[_t_24 + 1] = _m_25;
      WL_CONT = term_tsk(FID_OWNERS_MOTION_OBSERVE_K202, _t_24);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_18;
      e.mem[_t_25 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _h_18;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_MOTION_OBSERVE_K202)
  {
    WL_POPN(2);
    u32 _m_26 = STK(0);
    Term _m_27 = STK(1);
    Term _h_19 = r0;
    WL_OPEN
    r0 = _m_27;
    r1 = _m_26;
    r2 = _h_19;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP)
  {
    u32 _namespace_0 = r0;
    u32 _tick_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    u32 _command_0 = r11;
    u32 _command_1 = r12;
    Term _command_2 = r13;
    Term _command_3 = r14;
    u32 _command_4 = r15;
    Term _command_5 = r16;
    u32 _command_6 = r17;
    Term _command_7 = r18;
    WL_OPEN
    if (_command_0 == 0) {
      if (_command_2 == 0) {
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_COMMANDS_STEP_K210;
          WL_PUSHN(1);
        } else {
          u64 _t_0 = task_node(e, FID_COMMANDS_STEP_K210, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_COMMANDS_STEP_K210, _t_0);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
          u64 _t_1 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _rows_0;
          e.mem[_t_1 + 1] = _rows_1;
          e.mem[_t_1 + 2] = _rows_2;
          e.mem[_t_1 + 3] = _rows_3;
          e.mem[_t_1 + 4] = _rows_4;
          e.mem[_t_1 + 5] = _rows_5;
          e.mem[_t_1 + 6] = _rows_6;
          e.mem[_t_1 + 7] = _rows_7;
          e.mem[_t_1 + 8] = _rows_8;
          e.mem[_t_1 + 9] = _command_1;
          e.mem[_t_1 + 10] = 0;
          e.mem[_t_1 + 11] = 0;
          e.mem[_t_1 + 12] = _command_4;
          e.mem[_t_1 + 13] = _command_5;
          e.mem[_t_1 + 14] = _command_6;
          e.mem[_t_1 + 15] = _command_7;
          e.mem[_t_1 + 16] = 0ull;
          e.mem[_t_1 + 17] = 0ull;
          return term_tsk(FID_STORAGE_ROWS_PLACE, _t_1);
        }
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        r9 = _command_1;
        r10 = 0;
        r11 = 0;
        r12 = _command_4;
        r13 = _command_5;
        r14 = _command_6;
        r15 = _command_7;
        r16 = 0ull;
        r17 = 0ull;
        WL_JMP(FID_STORAGE_ROWS_PLACE);
      } else {
        if (seq) {
          WL_ROOM(3);
          STK(0) = _namespace_0;
          STK(1) = _command_1;
          STK(2) = FID_COMMANDS_STEP_K211;
          WL_PUSHN(3);
        } else {
          u64 _t_2 = task_node(e, FID_COMMANDS_STEP_K211, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _namespace_0;
          e.mem[_t_2 + 1] = _command_1;
          WL_CONT = term_tsk(FID_COMMANDS_STEP_K211, _t_2);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
          u64 _t_3 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_0;
          e.mem[_t_3 + 1] = _rows_1;
          e.mem[_t_3 + 2] = _rows_2;
          e.mem[_t_3 + 3] = _rows_3;
          e.mem[_t_3 + 4] = _rows_4;
          e.mem[_t_3 + 5] = _rows_5;
          e.mem[_t_3 + 6] = _rows_6;
          e.mem[_t_3 + 7] = _rows_7;
          e.mem[_t_3 + 8] = _rows_8;
          e.mem[_t_3 + 9] = _command_1;
          e.mem[_t_3 + 10] = 1;
          e.mem[_t_3 + 11] = _command_3;
          e.mem[_t_3 + 12] = _command_4;
          e.mem[_t_3 + 13] = _command_5;
          e.mem[_t_3 + 14] = _command_6;
          e.mem[_t_3 + 15] = _command_7;
          e.mem[_t_3 + 16] = _tick_0;
          e.mem[_t_3 + 17] = _tick_0;
          return term_tsk(FID_STORAGE_ROWS_PLACE, _t_3);
        }
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        r9 = _command_1;
        r10 = 1;
        r11 = _command_3;
        r12 = _command_4;
        r13 = _command_5;
        r14 = _command_6;
        r15 = _command_7;
        r16 = _tick_0;
        r17 = _tick_0;
        WL_JMP(FID_STORAGE_ROWS_PLACE);
      }
    } else if (_command_0 == 1) {
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      Term _o_5[10];
      if (spin_55(e, _o_5, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1, 1, _command_2, blk_loc(e.mem, _command_2), _tick_0) == 0) {
        return 0;
      }
      _v_48 = _o_5[0];
      _v_49 = _o_5[1];
      _v_50 = _o_5[2];
      _v_51 = _o_5[3];
      _v_52 = _o_5[4];
      _v_53 = _o_5[5];
      _v_54 = _o_5[6];
      _v_55 = _o_5[7];
      _v_56 = _o_5[8];
      _v_57 = _o_5[9];
      _v_38 = _v_48;
      _v_39 = _v_49;
      _v_40 = _v_50;
      _v_41 = _v_51;
      _v_42 = _v_52;
      _v_43 = _v_53;
      _v_44 = _v_54;
      _v_45 = _v_55;
      _v_46 = _v_56;
      _v_47 = _v_57;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      Term _v_86 = 0;
      Term _v_87 = 0;
      Term _v_88 = 0;
      u32 _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      Term _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _o_6[19];
      if (spin_56(e, _o_6, _namespace_0, _command_1, _v_38, blk_loc(e.mem, _v_38), _v_39, blk_loc(e.mem, _v_39), _v_40, blk_loc(e.mem, _v_40), _v_41, blk_loc(e.mem, _v_41), _v_42, blk_loc(e.mem, _v_42), _v_43, blk_loc(e.mem, _v_43), _v_44, _v_45, _v_46, _v_47) == 0) {
        return 0;
      }
      _v_82 = _o_6[0];
      _v_83 = _o_6[1];
      _v_84 = _o_6[2];
      _v_85 = _o_6[3];
      _v_86 = _o_6[4];
      _v_87 = _o_6[5];
      _v_88 = _o_6[6];
      _v_89 = _o_6[7];
      _v_90 = _o_6[8];
      _v_91 = _o_6[9];
      _v_92 = _o_6[10];
      _v_93 = _o_6[11];
      _v_94 = _o_6[12];
      _v_95 = _o_6[13];
      _v_96 = _o_6[14];
      _v_97 = _o_6[15];
      _v_98 = _o_6[16];
      _v_99 = _o_6[17];
      _v_100 = _o_6[18];
      r0 = _v_82;
      r1 = _v_83;
      r2 = _v_84;
      r3 = _v_85;
      r4 = _v_86;
      r5 = _v_87;
      r6 = _v_88;
      r7 = _v_89;
      r8 = _v_90;
      r9 = _v_91;
      r10 = _v_92;
      r11 = _v_93;
      r12 = _v_94;
      r13 = _v_95;
      r14 = _v_96;
      r15 = _v_97;
      r16 = _v_98;
      r17 = _v_99;
      r18 = _v_100;
      WL_RETN(19);
    } else if (_command_0 == 3) {
      Term _v_120 = 0;
      Term _v_121 = 0;
      Term _v_122 = 0;
      Term _v_123 = 0;
      Term _v_124 = 0;
      Term _v_125 = 0;
      u32 _v_126 = 0;
      Term _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      Term _v_134 = 0;
      Term _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      u32 _v_139 = 0;
      Term _o_7[10];
      Term _a_2 = 0;
      if (spin_55(e, _o_7, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1, 0, _a_2, blk_loc(e.mem, _a_2), _tick_0) == 0) {
        return 0;
      }
      _v_130 = _o_7[0];
      _v_131 = _o_7[1];
      _v_132 = _o_7[2];
      _v_133 = _o_7[3];
      _v_134 = _o_7[4];
      _v_135 = _o_7[5];
      _v_136 = _o_7[6];
      _v_137 = _o_7[7];
      _v_138 = _o_7[8];
      _v_139 = _o_7[9];
      _v_120 = _v_130;
      _v_121 = _v_131;
      _v_122 = _v_132;
      _v_123 = _v_133;
      _v_124 = _v_134;
      _v_125 = _v_135;
      _v_126 = _v_136;
      _v_127 = _v_137;
      _v_128 = _v_138;
      _v_129 = _v_139;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      Term _v_142 = 0;
      Term _v_143 = 0;
      Term _v_144 = 0;
      Term _v_145 = 0;
      Term _v_146 = 0;
      u32 _v_147 = 0;
      Term _v_148 = 0;
      u32 _v_149 = 0;
      Term _v_150 = 0;
      u32 _v_151 = 0;
      Term _v_152 = 0;
      u32 _v_153 = 0;
      Term _v_154 = 0;
      u32 _v_155 = 0;
      Term _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      Term _o_8[19];
      if (spin_56(e, _o_8, _namespace_0, _command_1, _v_120, blk_loc(e.mem, _v_120), _v_121, blk_loc(e.mem, _v_121), _v_122, blk_loc(e.mem, _v_122), _v_123, blk_loc(e.mem, _v_123), _v_124, blk_loc(e.mem, _v_124), _v_125, blk_loc(e.mem, _v_125), _v_126, _v_127, _v_128, _v_129) == 0) {
        return 0;
      }
      _v_140 = _o_8[0];
      _v_141 = _o_8[1];
      _v_142 = _o_8[2];
      _v_143 = _o_8[3];
      _v_144 = _o_8[4];
      _v_145 = _o_8[5];
      _v_146 = _o_8[6];
      _v_147 = _o_8[7];
      _v_148 = _o_8[8];
      _v_149 = _o_8[9];
      _v_150 = _o_8[10];
      _v_151 = _o_8[11];
      _v_152 = _o_8[12];
      _v_153 = _o_8[13];
      _v_154 = _o_8[14];
      _v_155 = _o_8[15];
      _v_156 = _o_8[16];
      _v_157 = _o_8[17];
      _v_158 = _o_8[18];
      r0 = _v_140;
      r1 = _v_141;
      r2 = _v_142;
      r3 = _v_143;
      r4 = _v_144;
      r5 = _v_145;
      r6 = _v_146;
      r7 = _v_147;
      r8 = _v_148;
      r9 = _v_149;
      r10 = _v_150;
      r11 = _v_151;
      r12 = _v_152;
      r13 = _v_153;
      r14 = _v_154;
      r15 = _v_155;
      r16 = _v_156;
      r17 = _v_157;
      r18 = _v_158;
      WL_RETN(19);
    } else {
      u32 _v_159 = 0;
      u32 _v_160 = 0;
      Term _v_161 = 0;
      Term _v_162 = 0;
      u32 _v_163 = 0;
      Term _v_164 = 0;
      u32 _v_165 = 0;
      Term _v_166 = 0;
      u32 _v_167 = 0;
      u32 _v_168 = 0;
      u32 _v_169 = 0;
      Term _v_170 = 0;
      Term _v_171 = 0;
      u32 _v_172 = 0;
      Term _v_173 = 0;
      u32 _v_174 = 0;
      Term _v_175 = 0;
      u32 _v_176 = 0;
      Term _o_9[9];
      if (spin_57(e, _o_9, _command_0, _command_1, _command_2, blk_loc(e.mem, _command_2), _command_3, blk_loc(e.mem, _command_3), _command_4, _command_5, blk_loc(e.mem, _command_5), _command_6, _command_7, blk_loc(e.mem, _command_7)) == 0) {
        return 0;
      }
      _v_168 = _o_9[0];
      _v_169 = _o_9[1];
      _v_170 = _o_9[2];
      _v_171 = _o_9[3];
      _v_172 = _o_9[4];
      _v_173 = _o_9[5];
      _v_174 = _o_9[6];
      _v_175 = _o_9[7];
      _v_176 = _o_9[8];
      _v_159 = _v_168;
      _v_160 = _v_169;
      _v_161 = _v_170;
      _v_162 = _v_171;
      _v_163 = _v_172;
      _v_164 = _v_173;
      _v_165 = _v_174;
      _v_166 = _v_175;
      _v_167 = _v_176;
      u32 _v_186 = 0;
      Term _v_187 = 0;
      Term _v_188 = 0;
      Term _v_189 = 0;
      Term _v_190 = 0;
      Term _v_191 = 0;
      Term _v_192 = 0;
      u32 _v_193 = 0;
      Term _v_194 = 0;
      u32 _v_195 = 0;
      Term _v_196 = 0;
      u32 _v_197 = 0;
      Term _v_198 = 0;
      u32 _v_199 = 0;
      Term _v_200 = 0;
      u32 _v_201 = 0;
      Term _v_202 = 0;
      u32 _v_203 = 0;
      u32 _v_204 = 0;
      Term _o_12[19];
      if (spin_58(e, _o_12, _namespace_0, _tick_0, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _v_159, _v_160, _v_161, blk_loc(e.mem, _v_161), _v_162, blk_loc(e.mem, _v_162), _v_163, _v_164, blk_loc(e.mem, _v_164), _v_165, _v_166, blk_loc(e.mem, _v_166), _v_167) == 0) {
        return 0;
      }
      _v_186 = _o_12[0];
      _v_187 = _o_12[1];
      _v_188 = _o_12[2];
      _v_189 = _o_12[3];
      _v_190 = _o_12[4];
      _v_191 = _o_12[5];
      _v_192 = _o_12[6];
      _v_193 = _o_12[7];
      _v_194 = _o_12[8];
      _v_195 = _o_12[9];
      _v_196 = _o_12[10];
      _v_197 = _o_12[11];
      _v_198 = _o_12[12];
      _v_199 = _o_12[13];
      _v_200 = _o_12[14];
      _v_201 = _o_12[15];
      _v_202 = _o_12[16];
      _v_203 = _o_12[17];
      _v_204 = _o_12[18];
      r0 = _v_186;
      r1 = _v_187;
      r2 = _v_188;
      r3 = _v_189;
      r4 = _v_190;
      r5 = _v_191;
      r6 = _v_192;
      r7 = _v_193;
      r8 = _v_194;
      r9 = _v_195;
      r10 = _v_196;
      r11 = _v_197;
      r12 = _v_198;
      r13 = _v_199;
      r14 = _v_200;
      r15 = _v_201;
      r16 = _v_202;
      r17 = _v_203;
      r18 = _v_204;
      WL_RETN(19);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP_K210)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _o_0[19];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_47(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP_K211)
  {
    WL_POPN(2);
    u32 _namespace_1 = STK(0);
    u32 _command_8 = STK(1);
    u32 _h_19 = r0;
    Term _h_20 = r1;
    Term _h_21 = r2;
    Term _h_22 = r3;
    Term _h_23 = r4;
    Term _h_24 = r5;
    Term _h_25 = r6;
    u32 _h_26 = r7;
    Term _h_27 = r8;
    u32 _h_28 = r9;
    u32 _h_29 = r10;
    u32 _h_30 = r11;
    Term _h_31 = r12;
    u32 _h_32 = r13;
    Term _h_33 = r14;
    u32 _h_34 = r15;
    Term _h_35 = r16;
    u32 _h_36 = r17;
    u32 _h_37 = r18;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _command_8);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, _command_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINADDED, _nd_0));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_1[19];
    Term _a_1 = term_ctr(CID_CON, _nd_3);
    if (spin_47(e, _o_1, _a_1, blk_loc(e.mem, _a_1), _h_19, _h_20, blk_loc(e.mem, _h_20), _h_21, blk_loc(e.mem, _h_21), _h_22, blk_loc(e.mem, _h_22), _h_23, blk_loc(e.mem, _h_23), _h_24, blk_loc(e.mem, _h_24), _h_25, blk_loc(e.mem, _h_25), _h_26, _h_27, _h_28, _h_29, _h_30, _h_31, blk_loc(e.mem, _h_31), _h_32, _h_33, blk_loc(e.mem, _h_33), _h_34, _h_35, blk_loc(e.mem, _h_35), _h_36, _h_37) == 0) {
      return 0;
    }
    _v_19 = _o_1[0];
    _v_20 = _o_1[1];
    _v_21 = _o_1[2];
    _v_22 = _o_1[3];
    _v_23 = _o_1[4];
    _v_24 = _o_1[5];
    _v_25 = _o_1[6];
    _v_26 = _o_1[7];
    _v_27 = _o_1[8];
    _v_28 = _o_1[9];
    _v_29 = _o_1[10];
    _v_30 = _o_1[11];
    _v_31 = _o_1[12];
    _v_32 = _o_1[13];
    _v_33 = _o_1[14];
    _v_34 = _o_1[15];
    _v_35 = _o_1[16];
    _v_36 = _o_1[17];
    _v_37 = _o_1[18];
    r0 = _v_19;
    r1 = _v_20;
    r2 = _v_21;
    r3 = _v_22;
    r4 = _v_23;
    r5 = _v_24;
    r6 = _v_25;
    r7 = _v_26;
    r8 = _v_27;
    r9 = _v_28;
    r10 = _v_29;
    r11 = _v_30;
    r12 = _v_31;
    r13 = _v_32;
    r14 = _v_33;
    r15 = _v_34;
    r16 = _v_35;
    r17 = _v_36;
    r18 = _v_37;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_LOOKUP_ROWS_0)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    u32 _selection_0 = r9;
    u32 _namespace_0 = r10;
    u32 _target_0 = r11;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_12[19];
    if (spin_63(e, _o_12, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _target_0) == 0) {
      return 0;
    }
    _v_19 = _o_12[0];
    _v_20 = _o_12[1];
    _v_21 = _o_12[2];
    _v_22 = _o_12[3];
    _v_23 = _o_12[4];
    _v_24 = _o_12[5];
    _v_25 = _o_12[6];
    _v_26 = _o_12[7];
    _v_27 = _o_12[8];
    _v_28 = _o_12[9];
    _v_29 = _o_12[10];
    _v_30 = _o_12[11];
    _v_31 = _o_12[12];
    _v_32 = _o_12[13];
    _v_33 = _o_12[14];
    _v_34 = _o_12[15];
    _v_35 = _o_12[16];
    _v_36 = _o_12[17];
    _v_37 = _o_12[18];
    _v_0 = _v_19;
    _v_1 = _v_20;
    _v_2 = _v_21;
    _v_3 = _v_22;
    _v_4 = _v_23;
    _v_5 = _v_24;
    _v_6 = _v_25;
    _v_7 = _v_26;
    _v_8 = _v_27;
    _v_9 = _v_28;
    _v_10 = _v_29;
    _v_11 = _v_30;
    _v_12 = _v_31;
    _v_13 = _v_32;
    _v_14 = _v_33;
    _v_15 = _v_34;
    _v_16 = _v_35;
    _v_17 = _v_36;
    _v_18 = _v_37;
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    Term _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    Term _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    if (_v_9 == 0) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      u32 _o_24 = 0;
      Term _o_25 = 0;
      u32 _o_26 = 0;
      if (_v_11 == 0) {
        _o_24 = 0;
      } else {
        _o_24 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _v_12, 2, _fb_0);
        Term _f_4 = _fb_0[0];
        u32 _f_5 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        _o_25 = _f_4;
        _o_26 = _f_5;
      }
      u32 _o_27 = 0;
      Term _o_28 = 0;
      u32 _o_29 = 0;
      if (_v_13 == 0) {
        _o_27 = 0;
      } else {
        _o_27 = 1;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _v_14, 2, _fb_1);
        Term _f_6 = _fb_1[0];
        u32 _f_7 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_28 = _f_6;
        _o_29 = _f_7;
      }
      u32 _o_30 = 0;
      if (_v_15 == 0) {
        _o_30 = 0;
      } else {
        _o_30 = 1;
      }
      _o_14 = _v_10;
      _o_15 = _o_24;
      _o_16 = _o_25;
      _o_17 = _o_26;
      _o_18 = _o_27;
      _o_19 = _o_28;
      _o_20 = _o_29;
      _o_21 = _o_30;
      _o_22 = _v_17;
      _o_23 = _v_18;
    }
    if (_o_13 == 0) {
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = 2;
      r10 = 0;
      WL_RETN(11);
    } else {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _v_0;
        STK(1) = _v_1;
        STK(2) = _v_2;
        STK(3) = _v_3;
        STK(4) = _v_4;
        STK(5) = _v_5;
        STK(6) = _v_6;
        STK(7) = _v_7;
        STK(8) = _v_8;
        STK(9) = FID_QUERY_LOOKUP_ROWS_0_K217;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_QUERY_LOOKUP_ROWS_0_K217, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _v_0;
        e.mem[_t_0 + 1] = _v_1;
        e.mem[_t_0 + 2] = _v_2;
        e.mem[_t_0 + 3] = _v_3;
        e.mem[_t_0 + 4] = _v_4;
        e.mem[_t_0 + 5] = _v_5;
        e.mem[_t_0 + 6] = _v_6;
        e.mem[_t_0 + 7] = _v_7;
        e.mem[_t_0 + 8] = _v_8;
        WL_CONT = term_tsk(FID_QUERY_LOOKUP_ROWS_0_K217, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_QUERY_READ_ROW_0)) {
        u64 _t_1 = task_node(e, FID_QUERY_READ_ROW_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _selection_0;
        e.mem[_t_1 + 1] = _namespace_0;
        e.mem[_t_1 + 2] = _o_14;
        e.mem[_t_1 + 3] = _o_15;
        e.mem[_t_1 + 4] = _o_16;
        e.mem[_t_1 + 5] = _o_17;
        e.mem[_t_1 + 6] = _o_18;
        e.mem[_t_1 + 7] = _o_19;
        e.mem[_t_1 + 8] = _o_20;
        e.mem[_t_1 + 9] = _o_21;
        e.mem[_t_1 + 10] = _o_22;
        e.mem[_t_1 + 11] = _o_23;
        return term_tsk(FID_QUERY_READ_ROW_0, _t_1);
      }
      r0 = _selection_0;
      r1 = _namespace_0;
      r2 = _o_14;
      r3 = _o_15;
      r4 = _o_16;
      r5 = _o_17;
      r6 = _o_18;
      r7 = _o_19;
      r8 = _o_20;
      r9 = _o_21;
      r10 = _o_22;
      r11 = _o_23;
      WL_JMP(FID_QUERY_READ_ROW_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_LOOKUP_ROWS_0_K217)
  {
    WL_POPN(9);
    Term _v_350 = STK(0);
    Term _v_351 = STK(1);
    Term _v_352 = STK(2);
    Term _v_353 = STK(3);
    Term _v_354 = STK(4);
    Term _v_355 = STK(5);
    u32 _v_356 = STK(6);
    Term _v_357 = STK(7);
    u32 _v_358 = STK(8);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    WL_OPEN
    u32 _o_31 = 0;
    Term _o_32 = 0;
    if (_h_1 == 0) {
      _o_31 = 0;
    } else {
      _o_31 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_3);
      _o_32 = term_ctr(CID_OWNERS_MOTION, _nd_0);
    }
    u32 _o_33 = 0;
    Term _o_34 = 0;
    if (_h_4 == 0) {
      _o_33 = 0;
    } else {
      _o_33 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _h_5);
      e.mem[_nd_1 + 1] = rfc_seal(e, _h_6);
      _o_34 = term_ctr(CID_OWNERS_HEALTH, _nd_1);
    }
    u32 _o_35 = 0;
    Term _o_36 = 0;
    if (_h_7 == 0) {
      _o_35 = 0;
    } else {
      _o_35 = 1;
      _o_36 = term_pak(CID_UNIT, 0);
    }
    Term _v_359 = 0;
    Term _v_360 = 0;
    Term _v_361 = 0;
    Term _v_362 = 0;
    Term _v_363 = 0;
    Term _v_364 = 0;
    u32 _v_365 = 0;
    Term _v_366 = 0;
    u32 _v_367 = 0;
    u32 _v_368 = 0;
    Term _v_369 = 0;
    Term _o_37[11];
    if (spin_51(e, _o_37, _v_350, blk_loc(e.mem, _v_350), _v_351, blk_loc(e.mem, _v_351), _v_352, blk_loc(e.mem, _v_352), _v_353, blk_loc(e.mem, _v_353), _v_354, blk_loc(e.mem, _v_354), _v_355, blk_loc(e.mem, _v_355), _v_356, _v_357, _v_358, _h_0, _o_31, _o_32, blk_loc(e.mem, _o_32), _o_33, _o_34, blk_loc(e.mem, _o_34), _o_35, _o_36, blk_loc(e.mem, _o_36), _h_8, _h_9, _h_10, _h_11, blk_loc(e.mem, _h_11)) == 0) {
      return 0;
    }
    _v_359 = _o_37[0];
    _v_360 = _o_37[1];
    _v_361 = _o_37[2];
    _v_362 = _o_37[3];
    _v_363 = _o_37[4];
    _v_364 = _o_37[5];
    _v_365 = _o_37[6];
    _v_366 = _o_37[7];
    _v_367 = _o_37[8];
    _v_368 = _o_37[9];
    _v_369 = _o_37[10];
    r0 = _v_359;
    r1 = _v_360;
    r2 = _v_361;
    r3 = _v_362;
    r4 = _v_363;
    r5 = _v_364;
    r6 = _v_365;
    r7 = _v_366;
    r8 = _v_367;
    r9 = _v_368;
    r10 = _v_369;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_AUX)
  {
    u32 _value_0 = r0;
    Term _value_1 = r1;
    u32 _value_2 = r2;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = term_ctr(CID_SCON, STAT_OFF + 6);
      WL_RETN(4);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_ROW_AUX_K222;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_ROW_AUX_K222, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_ROW_AUX_K222, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OWNERS_HEALTH_OBSERVE)) {
        u64 _t_1 = task_node(e, FID_OWNERS_HEALTH_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_1;
        e.mem[_t_1 + 1] = _value_2;
        return term_tsk(FID_OWNERS_HEALTH_OBSERVE, _t_1);
      }
      r0 = _value_1;
      r1 = _value_2;
      WL_JMP(FID_OWNERS_HEALTH_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_AUX_K222)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    if (spin_74(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_MAIN)
  {
    u32 _value_0 = r0;
    Term _value_1 = r1;
    u32 _value_2 = r2;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = term_ctr(CID_SCON, STAT_OFF + 6);
      WL_RETN(4);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_ROW_MAIN_K224;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_ROW_MAIN_K224, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_ROW_MAIN_K224, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_OWNERS_MOTION_OBSERVE)) {
        u64 _t_1 = task_node(e, FID_OWNERS_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_1;
        e.mem[_t_1 + 1] = _value_2;
        return term_tsk(FID_OWNERS_MOTION_OBSERVE, _t_1);
      }
      r0 = _value_1;
      r1 = _value_2;
      WL_JMP(FID_OWNERS_MOTION_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_MAIN_K224)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    if (spin_75(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_54(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STATE_COMMAND)
  {
    u32 _namespace_0 = r0;
    u32 _tick_0 = r1;
    u32 _command_0 = r2;
    u32 _command_1 = r3;
    Term _command_2 = r4;
    Term _command_3 = r5;
    u32 _command_4 = r6;
    Term _command_5 = r7;
    u32 _command_6 = r8;
    Term _command_7 = r9;
    u32 _state_0 = r10;
    Term _state_1 = r11;
    Term _state_2 = r12;
    Term _state_3 = r13;
    Term _state_4 = r14;
    Term _state_5 = r15;
    Term _state_6 = r16;
    u32 _state_7 = r17;
    Term _state_8 = r18;
    u32 _state_9 = r19;
    Term _state_10 = r20;
    u32 _state_11 = r21;
    Term _state_12 = r22;
    u32 _state_13 = r23;
    Term _state_14 = r24;
    u32 _state_15 = r25;
    Term _state_16 = r26;
    u32 _state_17 = r27;
    u32 _state_18 = r28;
    Term _state_19 = r29;
    Term _state_20 = r30;
    WL_OPEN
    if (_state_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _state_10;
        STK(1) = FID_COMMANDS_STATE_COMMAND_K245;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_STATE_COMMAND_K245, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _state_10;
        WL_CONT = term_tsk(FID_COMMANDS_STATE_COMMAND_K245, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_STEP)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_STEP, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _namespace_0;
        e.mem[_t_1 + 1] = _tick_0;
        e.mem[_t_1 + 2] = _state_1;
        e.mem[_t_1 + 3] = _state_2;
        e.mem[_t_1 + 4] = _state_3;
        e.mem[_t_1 + 5] = _state_4;
        e.mem[_t_1 + 6] = _state_5;
        e.mem[_t_1 + 7] = _state_6;
        e.mem[_t_1 + 8] = _state_7;
        e.mem[_t_1 + 9] = _state_8;
        e.mem[_t_1 + 10] = _state_9;
        e.mem[_t_1 + 11] = _command_0;
        e.mem[_t_1 + 12] = _command_1;
        e.mem[_t_1 + 13] = _command_2;
        e.mem[_t_1 + 14] = _command_3;
        e.mem[_t_1 + 15] = _command_4;
        e.mem[_t_1 + 16] = _command_5;
        e.mem[_t_1 + 17] = _command_6;
        e.mem[_t_1 + 18] = _command_7;
        return term_tsk(FID_COMMANDS_STEP, _t_1);
      }
      r0 = _namespace_0;
      r1 = _tick_0;
      r2 = _state_1;
      r3 = _state_2;
      r4 = _state_3;
      r5 = _state_4;
      r6 = _state_5;
      r7 = _state_6;
      r8 = _state_7;
      r9 = _state_8;
      r10 = _state_9;
      r11 = _command_0;
      r12 = _command_1;
      r13 = _command_2;
      r14 = _command_3;
      r15 = _command_4;
      r16 = _command_5;
      r17 = _command_6;
      r18 = _command_7;
      WL_JMP(FID_COMMANDS_STEP);
    } else {
      Term _b_0 = 0;
      if (_command_0 == 0) {
        u64 _nd_1 = heap_alloc(e, cls_fit(7));
        e.mem[_nd_1 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _command_2);
        e.mem[_nd_1 + 2] = rfc_seal(e, _command_3);
        e.mem[_nd_1 + 3] = rfc_seal(e, _command_4);
        e.mem[_nd_1 + 4] = rfc_seal(e, _command_5);
        e.mem[_nd_1 + 5] = rfc_seal(e, _command_6);
        e.mem[_nd_1 + 6] = rfc_seal(e, _command_7);
        _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
      } else if (_command_0 == 1) {
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_2 + 1] = rfc_seal(e, _command_2);
        _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
      } else if (_command_0 == 2) {
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_3 + 1] = rfc_seal(e, _command_2);
        _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
      } else if (_command_0 == 3) {
        _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _command_1);
      } else if (_command_0 == 4) {
        _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _command_1);
      } else {
        _b_0 = term_pak(CID_STORAGE_DESPAWN, _command_1);
      }
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_4 + 1] = rfc_seal(e, _state_19);
      r0 = 1;
      r1 = _state_1;
      r2 = _state_2;
      r3 = _state_3;
      r4 = _state_4;
      r5 = _state_5;
      r6 = _state_6;
      r7 = _state_7;
      r8 = _state_8;
      r9 = _state_9;
      r10 = _state_10;
      r11 = _state_11;
      r12 = _state_12;
      r13 = _state_13;
      r14 = _state_14;
      r15 = _state_15;
      r16 = _state_16;
      r17 = _state_17;
      r18 = _state_18;
      r19 = term_ctr(CID_CON, _nd_4);
      r20 = _state_20;
      WL_RETN(21);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STATE_COMMAND_K245)
  {
    WL_POPN(1);
    Term _state_21 = STK(0);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_3[21];
    if (spin_78(e, _o_3, _state_21, blk_loc(e.mem, _state_21), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18) == 0) {
      return 0;
    }
    _v_0 = _o_3[0];
    _v_1 = _o_3[1];
    _v_2 = _o_3[2];
    _v_3 = _o_3[3];
    _v_4 = _o_3[4];
    _v_5 = _o_3[5];
    _v_6 = _o_3[6];
    _v_7 = _o_3[7];
    _v_8 = _o_3[8];
    _v_9 = _o_3[9];
    _v_10 = _o_3[10];
    _v_11 = _o_3[11];
    _v_12 = _o_3[12];
    _v_13 = _o_3[13];
    _v_14 = _o_3[14];
    _v_15 = _o_3[15];
    _v_16 = _o_3[16];
    _v_17 = _o_3[17];
    _v_18 = _o_3[18];
    _v_19 = _o_3[19];
    _v_20 = _o_3[20];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE)
  {
    u32 _row_0 = r0;
    u32 _row_1 = r1;
    Term _row_2 = r2;
    u32 _row_3 = r3;
    u32 _row_4 = r4;
    Term _row_5 = r5;
    u32 _row_6 = r6;
    u32 _row_7 = r7;
    u32 _row_8 = r8;
    u32 _row_9 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _row_0;
      STK(1) = _row_4;
      STK(2) = _row_5;
      STK(3) = _row_6;
      STK(4) = _row_7;
      STK(5) = _row_8;
      STK(6) = _row_9;
      STK(7) = FID_ROW_OBSERVE_K260;
      WL_PUSHN(8);
    } else {
      u64 _t_0 = task_node(e, FID_ROW_OBSERVE_K260, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _row_0;
      e.mem[_t_0 + 1] = _row_4;
      e.mem[_t_0 + 2] = _row_5;
      e.mem[_t_0 + 3] = _row_6;
      e.mem[_t_0 + 4] = _row_7;
      e.mem[_t_0 + 5] = _row_8;
      e.mem[_t_0 + 6] = _row_9;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K260, _t_0);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ROW_MAIN)) {
      u64 _t_1 = task_node(e, FID_ROW_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _row_1;
      e.mem[_t_1 + 1] = _row_2;
      e.mem[_t_1 + 2] = _row_3;
      return term_tsk(FID_ROW_MAIN, _t_1);
    }
    r0 = _row_1;
    r1 = _row_2;
    r2 = _row_3;
    WL_JMP(FID_ROW_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K260)
  {
    WL_POPN(7);
    u32 _row_10 = STK(0);
    u32 _row_11 = STK(1);
    Term _row_12 = STK(2);
    u32 _row_13 = STK(3);
    u32 _row_14 = STK(4);
    u32 _row_15 = STK(5);
    u32 _row_16 = STK(6);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _row_10;
      STK(1) = _row_14;
      STK(2) = _row_15;
      STK(3) = _row_16;
      STK(4) = _h_0;
      STK(5) = _h_1;
      STK(6) = _h_2;
      STK(7) = _h_3;
      STK(8) = FID_ROW_OBSERVE_K261;
      WL_PUSHN(9);
    } else {
      u64 _t_2 = task_node(e, FID_ROW_OBSERVE_K261, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _row_10;
      e.mem[_t_2 + 1] = _row_14;
      e.mem[_t_2 + 2] = _row_15;
      e.mem[_t_2 + 3] = _row_16;
      e.mem[_t_2 + 4] = _h_0;
      e.mem[_t_2 + 5] = _h_1;
      e.mem[_t_2 + 6] = _h_2;
      e.mem[_t_2 + 7] = _h_3;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K261, _t_2);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ROW_AUX)) {
      u64 _t_3 = task_node(e, FID_ROW_AUX, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _row_11;
      e.mem[_t_3 + 1] = _row_12;
      e.mem[_t_3 + 2] = _row_13;
      return term_tsk(FID_ROW_AUX, _t_3);
    }
    r0 = _row_11;
    r1 = _row_12;
    r2 = _row_13;
    WL_JMP(FID_ROW_AUX);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K261)
  {
    WL_POPN(8);
    u32 _row_17 = STK(0);
    u32 _row_18 = STK(1);
    u32 _row_19 = STK(2);
    u32 _row_20 = STK(3);
    u32 _h_8 = STK(4);
    Term _h_9 = STK(5);
    u32 _h_10 = STK(6);
    Term _h_11 = STK(7);
    u32 _h_4 = r0;
    Term _h_5 = r1;
    u32 _h_6 = r2;
    Term _h_7 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_17;
      STK(1) = _row_18;
      STK(2) = _row_19;
      STK(3) = _row_20;
      STK(4) = _h_8;
      STK(5) = _h_9;
      STK(6) = _h_10;
      STK(7) = _h_11;
      STK(8) = _h_4;
      STK(9) = _h_5;
      STK(10) = _h_6;
      STK(11) = _h_7;
      STK(12) = FID_ROW_OBSERVE_K262;
      WL_PUSHN(13);
    } else {
      u64 _t_4 = task_node(e, FID_ROW_OBSERVE_K262, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _row_17;
      e.mem[_t_4 + 1] = _row_18;
      e.mem[_t_4 + 2] = _row_19;
      e.mem[_t_4 + 3] = _row_20;
      e.mem[_t_4 + 4] = _h_8;
      e.mem[_t_4 + 5] = _h_9;
      e.mem[_t_4 + 6] = _h_10;
      e.mem[_t_4 + 7] = _h_11;
      e.mem[_t_4 + 8] = _h_4;
      e.mem[_t_4 + 9] = _h_5;
      e.mem[_t_4 + 10] = _h_6;
      e.mem[_t_4 + 11] = _h_7;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K262, _t_4);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _row_17;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _row_17;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K262)
  {
    WL_POPN(12);
    u32 _row_21 = STK(0);
    u32 _row_22 = STK(1);
    u32 _row_23 = STK(2);
    u32 _row_24 = STK(3);
    u32 _h_13 = STK(4);
    Term _h_14 = STK(5);
    u32 _h_15 = STK(6);
    Term _h_16 = STK(7);
    u32 _h_17 = STK(8);
    Term _h_18 = STK(9);
    u32 _h_19 = STK(10);
    Term _h_20 = STK(11);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_21;
      STK(1) = _row_22;
      STK(2) = _row_23;
      STK(3) = _row_24;
      STK(4) = _h_13;
      STK(5) = _h_14;
      STK(6) = _h_15;
      STK(7) = _h_16;
      STK(8) = _h_17;
      STK(9) = _h_18;
      STK(10) = _h_19;
      STK(11) = _h_20;
      STK(12) = _h_12;
      STK(13) = FID_ROW_OBSERVE_K263;
      WL_PUSHN(14);
    } else {
      u64 _t_6 = task_node(e, FID_ROW_OBSERVE_K263, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _row_21;
      e.mem[_t_6 + 1] = _row_22;
      e.mem[_t_6 + 2] = _row_23;
      e.mem[_t_6 + 3] = _row_24;
      e.mem[_t_6 + 4] = _h_13;
      e.mem[_t_6 + 5] = _h_14;
      e.mem[_t_6 + 6] = _h_15;
      e.mem[_t_6 + 7] = _h_16;
      e.mem[_t_6 + 8] = _h_17;
      e.mem[_t_6 + 9] = _h_18;
      e.mem[_t_6 + 10] = _h_19;
      e.mem[_t_6 + 11] = _h_20;
      e.mem[_t_6 + 12] = _h_12;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K263, _t_6);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _row_23;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _row_23;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K263)
  {
    WL_POPN(13);
    u32 _row_25 = STK(0);
    u32 _row_26 = STK(1);
    u32 _row_27 = STK(2);
    u32 _row_28 = STK(3);
    u32 _h_22 = STK(4);
    Term _h_23 = STK(5);
    u32 _h_24 = STK(6);
    Term _h_25 = STK(7);
    u32 _h_26 = STK(8);
    Term _h_27 = STK(9);
    u32 _h_28 = STK(10);
    Term _h_29 = STK(11);
    Term _h_30 = STK(12);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _row_25;
      STK(1) = _row_26;
      STK(2) = _row_27;
      STK(3) = _row_28;
      STK(4) = _h_22;
      STK(5) = _h_23;
      STK(6) = _h_24;
      STK(7) = _h_25;
      STK(8) = _h_26;
      STK(9) = _h_27;
      STK(10) = _h_28;
      STK(11) = _h_29;
      STK(12) = _h_30;
      STK(13) = _h_21;
      STK(14) = FID_ROW_OBSERVE_K264;
      WL_PUSHN(15);
    } else {
      u64 _t_8 = task_node(e, FID_ROW_OBSERVE_K264, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _row_25;
      e.mem[_t_8 + 1] = _row_26;
      e.mem[_t_8 + 2] = _row_27;
      e.mem[_t_8 + 3] = _row_28;
      e.mem[_t_8 + 4] = _h_22;
      e.mem[_t_8 + 5] = _h_23;
      e.mem[_t_8 + 6] = _h_24;
      e.mem[_t_8 + 7] = _h_25;
      e.mem[_t_8 + 8] = _h_26;
      e.mem[_t_8 + 9] = _h_27;
      e.mem[_t_8 + 10] = _h_28;
      e.mem[_t_8 + 11] = _h_29;
      e.mem[_t_8 + 12] = _h_30;
      e.mem[_t_8 + 13] = _h_21;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K264, _t_8);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _row_28;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _row_28;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K264)
  {
    WL_POPN(14);
    u32 _row_29 = STK(0);
    u32 _row_30 = STK(1);
    u32 _row_31 = STK(2);
    u32 _row_32 = STK(3);
    u32 _h_32 = STK(4);
    Term _h_33 = STK(5);
    u32 _h_34 = STK(6);
    Term _h_35 = STK(7);
    u32 _h_36 = STK(8);
    Term _h_37 = STK(9);
    u32 _h_38 = STK(10);
    Term _h_39 = STK(11);
    Term _h_40 = STK(12);
    Term _h_41 = STK(13);
    Term _h_31 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _row_29;
      STK(1) = _row_30;
      STK(2) = _row_31;
      STK(3) = _row_32;
      STK(4) = _h_32;
      STK(5) = _h_33;
      STK(6) = _h_34;
      STK(7) = _h_35;
      STK(8) = _h_36;
      STK(9) = _h_37;
      STK(10) = _h_38;
      STK(11) = _h_39;
      STK(12) = _h_40;
      STK(13) = _h_41;
      STK(14) = FID_ROW_OBSERVE_K265;
      WL_PUSHN(15);
    } else {
      u64 _t_10 = task_node(e, FID_ROW_OBSERVE_K265, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _row_29;
      e.mem[_t_10 + 1] = _row_30;
      e.mem[_t_10 + 2] = _row_31;
      e.mem[_t_10 + 3] = _row_32;
      e.mem[_t_10 + 4] = _h_32;
      e.mem[_t_10 + 5] = _h_33;
      e.mem[_t_10 + 6] = _h_34;
      e.mem[_t_10 + 7] = _h_35;
      e.mem[_t_10 + 8] = _h_36;
      e.mem[_t_10 + 9] = _h_37;
      e.mem[_t_10 + 10] = _h_38;
      e.mem[_t_10 + 11] = _h_39;
      e.mem[_t_10 + 12] = _h_40;
      e.mem[_t_10 + 13] = _h_41;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K265, _t_10);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
      e.mem[_t_11 + 1] = _h_31;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 28);
    r1 = _h_31;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K265)
  {
    WL_POPN(14);
    u32 _row_33 = STK(0);
    u32 _row_34 = STK(1);
    u32 _row_35 = STK(2);
    u32 _row_36 = STK(3);
    u32 _h_43 = STK(4);
    Term _h_44 = STK(5);
    u32 _h_45 = STK(6);
    Term _h_46 = STK(7);
    u32 _h_47 = STK(8);
    Term _h_48 = STK(9);
    u32 _h_49 = STK(10);
    Term _h_50 = STK(11);
    Term _h_51 = STK(12);
    Term _h_52 = STK(13);
    Term _h_42 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_33;
      STK(1) = _row_34;
      STK(2) = _row_35;
      STK(3) = _row_36;
      STK(4) = _h_43;
      STK(5) = _h_44;
      STK(6) = _h_45;
      STK(7) = _h_46;
      STK(8) = _h_47;
      STK(9) = _h_48;
      STK(10) = _h_49;
      STK(11) = _h_50;
      STK(12) = _h_51;
      STK(13) = FID_ROW_OBSERVE_K266;
      WL_PUSHN(14);
    } else {
      u64 _t_12 = task_node(e, FID_ROW_OBSERVE_K266, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _row_33;
      e.mem[_t_12 + 1] = _row_34;
      e.mem[_t_12 + 2] = _row_35;
      e.mem[_t_12 + 3] = _row_36;
      e.mem[_t_12 + 4] = _h_43;
      e.mem[_t_12 + 5] = _h_44;
      e.mem[_t_12 + 6] = _h_45;
      e.mem[_t_12 + 7] = _h_46;
      e.mem[_t_12 + 8] = _h_47;
      e.mem[_t_12 + 9] = _h_48;
      e.mem[_t_12 + 10] = _h_49;
      e.mem[_t_12 + 11] = _h_50;
      e.mem[_t_12 + 12] = _h_51;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K266, _t_12);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_52;
      e.mem[_t_13 + 1] = _h_42;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_52;
    r1 = _h_42;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K266)
  {
    WL_POPN(13);
    u32 _row_37 = STK(0);
    u32 _row_38 = STK(1);
    u32 _row_39 = STK(2);
    u32 _row_40 = STK(3);
    u32 _h_54 = STK(4);
    Term _h_55 = STK(5);
    u32 _h_56 = STK(6);
    Term _h_57 = STK(7);
    u32 _h_58 = STK(8);
    Term _h_59 = STK(9);
    u32 _h_60 = STK(10);
    Term _h_61 = STK(11);
    Term _h_62 = STK(12);
    Term _h_53 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_37;
      STK(1) = _row_38;
      STK(2) = _row_39;
      STK(3) = _row_40;
      STK(4) = _h_54;
      STK(5) = _h_55;
      STK(6) = _h_56;
      STK(7) = _h_57;
      STK(8) = _h_58;
      STK(9) = _h_59;
      STK(10) = _h_60;
      STK(11) = _h_61;
      STK(12) = _h_62;
      STK(13) = FID_ROW_OBSERVE_K267;
      WL_PUSHN(14);
    } else {
      u64 _t_14 = task_node(e, FID_ROW_OBSERVE_K267, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _row_37;
      e.mem[_t_14 + 1] = _row_38;
      e.mem[_t_14 + 2] = _row_39;
      e.mem[_t_14 + 3] = _row_40;
      e.mem[_t_14 + 4] = _h_54;
      e.mem[_t_14 + 5] = _h_55;
      e.mem[_t_14 + 6] = _h_56;
      e.mem[_t_14 + 7] = _h_57;
      e.mem[_t_14 + 8] = _h_58;
      e.mem[_t_14 + 9] = _h_59;
      e.mem[_t_14 + 10] = _h_60;
      e.mem[_t_14 + 11] = _h_61;
      e.mem[_t_14 + 12] = _h_62;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K267, _t_14);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_15 + 1] = _h_53;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_53;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K267)
  {
    WL_POPN(13);
    u32 _row_41 = STK(0);
    u32 _row_42 = STK(1);
    u32 _row_43 = STK(2);
    u32 _row_44 = STK(3);
    u32 _h_64 = STK(4);
    Term _h_65 = STK(5);
    u32 _h_66 = STK(6);
    Term _h_67 = STK(7);
    u32 _h_68 = STK(8);
    Term _h_69 = STK(9);
    u32 _h_70 = STK(10);
    Term _h_71 = STK(11);
    Term _h_72 = STK(12);
    Term _h_63 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_5(e, _o_0, _row_42) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_41;
      STK(1) = _row_42;
      STK(2) = _row_43;
      STK(3) = _row_44;
      STK(4) = _h_64;
      STK(5) = _h_65;
      STK(6) = _h_66;
      STK(7) = _h_67;
      STK(8) = _h_68;
      STK(9) = _h_69;
      STK(10) = _h_70;
      STK(11) = _h_71;
      STK(12) = _h_72;
      STK(13) = FID_ROW_OBSERVE_K268;
      WL_PUSHN(14);
    } else {
      u64 _t_16 = task_node(e, FID_ROW_OBSERVE_K268, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _row_41;
      e.mem[_t_16 + 1] = _row_42;
      e.mem[_t_16 + 2] = _row_43;
      e.mem[_t_16 + 3] = _row_44;
      e.mem[_t_16 + 4] = _h_64;
      e.mem[_t_16 + 5] = _h_65;
      e.mem[_t_16 + 6] = _h_66;
      e.mem[_t_16 + 7] = _h_67;
      e.mem[_t_16 + 8] = _h_68;
      e.mem[_t_16 + 9] = _h_69;
      e.mem[_t_16 + 10] = _h_70;
      e.mem[_t_16 + 11] = _h_71;
      e.mem[_t_16 + 12] = _h_72;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K268, _t_16);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _v_0;
      e.mem[_t_17 + 1] = _h_63;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = _v_0;
    r1 = _h_63;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K268)
  {
    WL_POPN(13);
    u32 _row_45 = STK(0);
    u32 _row_46 = STK(1);
    u32 _row_47 = STK(2);
    u32 _row_48 = STK(3);
    u32 _h_74 = STK(4);
    Term _h_75 = STK(5);
    u32 _h_76 = STK(6);
    Term _h_77 = STK(7);
    u32 _h_78 = STK(8);
    Term _h_79 = STK(9);
    u32 _h_80 = STK(10);
    Term _h_81 = STK(11);
    Term _h_82 = STK(12);
    Term _h_73 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_45;
      STK(1) = _row_46;
      STK(2) = _row_47;
      STK(3) = _row_48;
      STK(4) = _h_74;
      STK(5) = _h_75;
      STK(6) = _h_76;
      STK(7) = _h_77;
      STK(8) = _h_78;
      STK(9) = _h_79;
      STK(10) = _h_80;
      STK(11) = _h_81;
      STK(12) = _h_82;
      STK(13) = FID_ROW_OBSERVE_K269;
      WL_PUSHN(14);
    } else {
      u64 _t_18 = task_node(e, FID_ROW_OBSERVE_K269, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _row_45;
      e.mem[_t_18 + 1] = _row_46;
      e.mem[_t_18 + 2] = _row_47;
      e.mem[_t_18 + 3] = _row_48;
      e.mem[_t_18 + 4] = _h_74;
      e.mem[_t_18 + 5] = _h_75;
      e.mem[_t_18 + 6] = _h_76;
      e.mem[_t_18 + 7] = _h_77;
      e.mem[_t_18 + 8] = _h_78;
      e.mem[_t_18 + 9] = _h_79;
      e.mem[_t_18 + 10] = _h_80;
      e.mem[_t_18 + 11] = _h_81;
      e.mem[_t_18 + 12] = _h_82;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K269, _t_18);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_19 + 1] = _h_73;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_73;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K269)
  {
    WL_POPN(13);
    u32 _row_49 = STK(0);
    u32 _row_50 = STK(1);
    u32 _row_51 = STK(2);
    u32 _row_52 = STK(3);
    u32 _h_84 = STK(4);
    Term _h_85 = STK(5);
    u32 _h_86 = STK(6);
    Term _h_87 = STK(7);
    u32 _h_88 = STK(8);
    Term _h_89 = STK(9);
    u32 _h_90 = STK(10);
    Term _h_91 = STK(11);
    Term _h_92 = STK(12);
    Term _h_83 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_49;
      STK(1) = _row_50;
      STK(2) = _row_51;
      STK(3) = _row_52;
      STK(4) = _h_84;
      STK(5) = _h_85;
      STK(6) = _h_86;
      STK(7) = _h_87;
      STK(8) = _h_88;
      STK(9) = _h_89;
      STK(10) = _h_90;
      STK(11) = _h_92;
      STK(12) = FID_ROW_OBSERVE_K270;
      WL_PUSHN(13);
    } else {
      u64 _t_20 = task_node(e, FID_ROW_OBSERVE_K270, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _row_49;
      e.mem[_t_20 + 1] = _row_50;
      e.mem[_t_20 + 2] = _row_51;
      e.mem[_t_20 + 3] = _row_52;
      e.mem[_t_20 + 4] = _h_84;
      e.mem[_t_20 + 5] = _h_85;
      e.mem[_t_20 + 6] = _h_86;
      e.mem[_t_20 + 7] = _h_87;
      e.mem[_t_20 + 8] = _h_88;
      e.mem[_t_20 + 9] = _h_89;
      e.mem[_t_20 + 10] = _h_90;
      e.mem[_t_20 + 11] = _h_92;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K270, _t_20);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_91;
      e.mem[_t_21 + 1] = _h_83;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_91;
    r1 = _h_83;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K270)
  {
    WL_POPN(12);
    u32 _row_53 = STK(0);
    u32 _row_54 = STK(1);
    u32 _row_55 = STK(2);
    u32 _row_56 = STK(3);
    u32 _h_94 = STK(4);
    Term _h_95 = STK(5);
    u32 _h_96 = STK(6);
    Term _h_97 = STK(7);
    u32 _h_98 = STK(8);
    Term _h_99 = STK(9);
    u32 _h_100 = STK(10);
    Term _h_101 = STK(11);
    Term _h_93 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_53;
      STK(1) = _row_54;
      STK(2) = _row_55;
      STK(3) = _row_56;
      STK(4) = _h_94;
      STK(5) = _h_95;
      STK(6) = _h_96;
      STK(7) = _h_97;
      STK(8) = _h_98;
      STK(9) = _h_99;
      STK(10) = _h_100;
      STK(11) = _h_101;
      STK(12) = FID_ROW_OBSERVE_K271;
      WL_PUSHN(13);
    } else {
      u64 _t_22 = task_node(e, FID_ROW_OBSERVE_K271, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _row_53;
      e.mem[_t_22 + 1] = _row_54;
      e.mem[_t_22 + 2] = _row_55;
      e.mem[_t_22 + 3] = _row_56;
      e.mem[_t_22 + 4] = _h_94;
      e.mem[_t_22 + 5] = _h_95;
      e.mem[_t_22 + 6] = _h_96;
      e.mem[_t_22 + 7] = _h_97;
      e.mem[_t_22 + 8] = _h_98;
      e.mem[_t_22 + 9] = _h_99;
      e.mem[_t_22 + 10] = _h_100;
      e.mem[_t_22 + 11] = _h_101;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K271, _t_22);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_23 + 1] = _h_93;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_93;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K271)
  {
    WL_POPN(12);
    u32 _row_57 = STK(0);
    u32 _row_58 = STK(1);
    u32 _row_59 = STK(2);
    u32 _row_60 = STK(3);
    u32 _h_103 = STK(4);
    Term _h_104 = STK(5);
    u32 _h_105 = STK(6);
    Term _h_106 = STK(7);
    u32 _h_107 = STK(8);
    Term _h_108 = STK(9);
    u32 _h_109 = STK(10);
    Term _h_110 = STK(11);
    Term _h_102 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _row_57;
      STK(1) = _row_58;
      STK(2) = _row_59;
      STK(3) = _row_60;
      STK(4) = _h_103;
      STK(5) = _h_104;
      STK(6) = _h_105;
      STK(7) = _h_107;
      STK(8) = _h_108;
      STK(9) = _h_109;
      STK(10) = _h_110;
      STK(11) = FID_ROW_OBSERVE_K272;
      WL_PUSHN(12);
    } else {
      u64 _t_24 = task_node(e, FID_ROW_OBSERVE_K272, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _row_57;
      e.mem[_t_24 + 1] = _row_58;
      e.mem[_t_24 + 2] = _row_59;
      e.mem[_t_24 + 3] = _row_60;
      e.mem[_t_24 + 4] = _h_103;
      e.mem[_t_24 + 5] = _h_104;
      e.mem[_t_24 + 6] = _h_105;
      e.mem[_t_24 + 7] = _h_107;
      e.mem[_t_24 + 8] = _h_108;
      e.mem[_t_24 + 9] = _h_109;
      e.mem[_t_24 + 10] = _h_110;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K272, _t_24);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_106;
      e.mem[_t_25 + 1] = _h_102;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _h_106;
    r1 = _h_102;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K272)
  {
    WL_POPN(11);
    u32 _row_61 = STK(0);
    u32 _row_62 = STK(1);
    u32 _row_63 = STK(2);
    u32 _row_64 = STK(3);
    u32 _h_112 = STK(4);
    Term _h_113 = STK(5);
    u32 _h_114 = STK(6);
    u32 _h_115 = STK(7);
    Term _h_116 = STK(8);
    u32 _h_117 = STK(9);
    Term _h_118 = STK(10);
    Term _h_111 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _row_61;
      STK(1) = _row_62;
      STK(2) = _row_63;
      STK(3) = _row_64;
      STK(4) = _h_112;
      STK(5) = _h_113;
      STK(6) = _h_114;
      STK(7) = _h_115;
      STK(8) = _h_116;
      STK(9) = _h_117;
      STK(10) = _h_118;
      STK(11) = FID_ROW_OBSERVE_K273;
      WL_PUSHN(12);
    } else {
      u64 _t_26 = task_node(e, FID_ROW_OBSERVE_K273, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _row_61;
      e.mem[_t_26 + 1] = _row_62;
      e.mem[_t_26 + 2] = _row_63;
      e.mem[_t_26 + 3] = _row_64;
      e.mem[_t_26 + 4] = _h_112;
      e.mem[_t_26 + 5] = _h_113;
      e.mem[_t_26 + 6] = _h_114;
      e.mem[_t_26 + 7] = _h_115;
      e.mem[_t_26 + 8] = _h_116;
      e.mem[_t_26 + 9] = _h_117;
      e.mem[_t_26 + 10] = _h_118;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K273, _t_26);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_27 + 1] = _h_111;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_111;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K273)
  {
    WL_POPN(11);
    u32 _row_65 = STK(0);
    u32 _row_66 = STK(1);
    u32 _row_67 = STK(2);
    u32 _row_68 = STK(3);
    u32 _h_120 = STK(4);
    Term _h_121 = STK(5);
    u32 _h_122 = STK(6);
    u32 _h_123 = STK(7);
    Term _h_124 = STK(8);
    u32 _h_125 = STK(9);
    Term _h_126 = STK(10);
    Term _h_119 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _row_65;
      STK(1) = _row_66;
      STK(2) = _row_67;
      STK(3) = _row_68;
      STK(4) = _h_120;
      STK(5) = _h_121;
      STK(6) = _h_122;
      STK(7) = _h_123;
      STK(8) = _h_124;
      STK(9) = _h_125;
      STK(10) = FID_ROW_OBSERVE_K274;
      WL_PUSHN(11);
    } else {
      u64 _t_28 = task_node(e, FID_ROW_OBSERVE_K274, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _row_65;
      e.mem[_t_28 + 1] = _row_66;
      e.mem[_t_28 + 2] = _row_67;
      e.mem[_t_28 + 3] = _row_68;
      e.mem[_t_28 + 4] = _h_120;
      e.mem[_t_28 + 5] = _h_121;
      e.mem[_t_28 + 6] = _h_122;
      e.mem[_t_28 + 7] = _h_123;
      e.mem[_t_28 + 8] = _h_124;
      e.mem[_t_28 + 9] = _h_125;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K274, _t_28);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _h_126;
      e.mem[_t_29 + 1] = _h_119;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = _h_126;
    r1 = _h_119;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K274)
  {
    WL_POPN(10);
    u32 _row_69 = STK(0);
    u32 _row_70 = STK(1);
    u32 _row_71 = STK(2);
    u32 _row_72 = STK(3);
    u32 _h_128 = STK(4);
    Term _h_129 = STK(5);
    u32 _h_130 = STK(6);
    u32 _h_131 = STK(7);
    Term _h_132 = STK(8);
    u32 _h_133 = STK(9);
    Term _h_127 = r0;
    WL_OPEN
    r0 = _row_69;
    r1 = _h_128;
    r2 = _h_129;
    r3 = _h_130;
    r4 = _h_131;
    r5 = _h_132;
    r6 = _h_133;
    r7 = _row_70;
    r8 = _row_71;
    r9 = _row_72;
    r10 = _h_127;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_54(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_BATCH)
  {
    Term _commands_0 = r0;
    u32 _namespace_0 = r1;
    u32 _tick_0 = r2;
    u32 _state_0 = r3;
    Term _state_1 = r4;
    Term _state_2 = r5;
    Term _state_3 = r6;
    Term _state_4 = r7;
    Term _state_5 = r8;
    Term _state_6 = r9;
    u32 _state_7 = r10;
    Term _state_8 = r11;
    u32 _state_9 = r12;
    Term _state_10 = r13;
    u32 _state_11 = r14;
    Term _state_12 = r15;
    u32 _state_13 = r16;
    Term _state_14 = r17;
    u32 _state_15 = r18;
    Term _state_16 = r19;
    u32 _state_17 = r20;
    u32 _state_18 = r21;
    Term _state_19 = r22;
    Term _state_20 = r23;
    WL_OPEN
    if (term_aux(_commands_0) == CID_NIL) {
      u32 _v_0 = 0;
      Term _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      u32 _v_7 = 0;
      Term _v_8 = 0;
      u32 _v_9 = 0;
      Term _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      u32 _v_13 = 0;
      Term _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _o_2[21];
      if (spin_97(e, _o_2, _state_0, _state_1, blk_loc(e.mem, _state_1), _state_2, blk_loc(e.mem, _state_2), _state_3, blk_loc(e.mem, _state_3), _state_4, blk_loc(e.mem, _state_4), _state_5, blk_loc(e.mem, _state_5), _state_6, blk_loc(e.mem, _state_6), _state_7, _state_8, _state_9, _state_10, blk_loc(e.mem, _state_10), _state_11, _state_12, blk_loc(e.mem, _state_12), _state_13, _state_14, blk_loc(e.mem, _state_14), _state_15, _state_16, blk_loc(e.mem, _state_16), _state_17, _state_18, _state_19, blk_loc(e.mem, _state_19), _state_20, blk_loc(e.mem, _state_20)) == 0) {
        return 0;
      }
      _v_0 = _o_2[0];
      _v_1 = _o_2[1];
      _v_2 = _o_2[2];
      _v_3 = _o_2[3];
      _v_4 = _o_2[4];
      _v_5 = _o_2[5];
      _v_6 = _o_2[6];
      _v_7 = _o_2[7];
      _v_8 = _o_2[8];
      _v_9 = _o_2[9];
      _v_10 = _o_2[10];
      _v_11 = _o_2[11];
      _v_12 = _o_2[12];
      _v_13 = _o_2[13];
      _v_14 = _o_2[14];
      _v_15 = _o_2[15];
      _v_16 = _o_2[16];
      _v_17 = _o_2[17];
      _v_18 = _o_2[18];
      _v_19 = _o_2[19];
      _v_20 = _o_2[20];
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      WL_RETN(21);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_3 = 0;
      u32 _o_4 = 0;
      Term _o_5 = 0;
      Term _o_6 = 0;
      u32 _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      if (term_aux(_f_0) == CID_STORAGE_SPAWN) {
        _o_3 = 0;
        Term _fb_1[7];
        u64 _sp_1 = ctr_take(e, _f_0, 7, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        u32 _f_7 = _fb_1[5];
        Term _f_8 = _fb_1[6];
        spare_free(e, cls_fit(7), _sp_1);
        _o_4 = _f_2;
        _o_5 = _f_3;
        _o_6 = _f_4;
        _o_7 = _f_5;
        _o_8 = _f_6;
        _o_9 = _f_7;
        _o_10 = _f_8;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTMAIN) {
        _o_3 = 1;
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _f_0, 2, _fb_2);
        u32 _f_9 = _fb_2[0];
        Term _f_10 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        _o_4 = _f_9;
        _o_5 = _f_10;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTFLAG) {
        _o_3 = 2;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_0, 2, _fb_3);
        u32 _f_11 = _fb_3[0];
        Term _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_4 = _f_11;
        _o_5 = _f_12;
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEMAIN) {
        _o_3 = 3;
        _o_4 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEFLAG) {
        _o_3 = 4;
        _o_4 = term_loc(_f_0);
      } else {
        _o_3 = 5;
        _o_4 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _namespace_0;
        STK(2) = _tick_0;
        STK(3) = FID_COMMANDS_BATCH_K284;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_BATCH_K284, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _namespace_0;
        e.mem[_t_0 + 2] = _tick_0;
        WL_CONT = term_tsk(FID_COMMANDS_BATCH_K284, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_STATE_COMMAND)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_STATE_COMMAND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _namespace_0;
        e.mem[_t_1 + 1] = _tick_0;
        e.mem[_t_1 + 2] = _o_3;
        e.mem[_t_1 + 3] = _o_4;
        e.mem[_t_1 + 4] = _o_5;
        e.mem[_t_1 + 5] = _o_6;
        e.mem[_t_1 + 6] = _o_7;
        e.mem[_t_1 + 7] = _o_8;
        e.mem[_t_1 + 8] = _o_9;
        e.mem[_t_1 + 9] = _o_10;
        e.mem[_t_1 + 10] = _state_0;
        e.mem[_t_1 + 11] = _state_1;
        e.mem[_t_1 + 12] = _state_2;
        e.mem[_t_1 + 13] = _state_3;
        e.mem[_t_1 + 14] = _state_4;
        e.mem[_t_1 + 15] = _state_5;
        e.mem[_t_1 + 16] = _state_6;
        e.mem[_t_1 + 17] = _state_7;
        e.mem[_t_1 + 18] = _state_8;
        e.mem[_t_1 + 19] = _state_9;
        e.mem[_t_1 + 20] = _state_10;
        e.mem[_t_1 + 21] = _state_11;
        e.mem[_t_1 + 22] = _state_12;
        e.mem[_t_1 + 23] = _state_13;
        e.mem[_t_1 + 24] = _state_14;
        e.mem[_t_1 + 25] = _state_15;
        e.mem[_t_1 + 26] = _state_16;
        e.mem[_t_1 + 27] = _state_17;
        e.mem[_t_1 + 28] = _state_18;
        e.mem[_t_1 + 29] = _state_19;
        e.mem[_t_1 + 30] = _state_20;
        return term_tsk(FID_COMMANDS_STATE_COMMAND, _t_1);
      }
      r0 = _namespace_0;
      r1 = _tick_0;
      r2 = _o_3;
      r3 = _o_4;
      r4 = _o_5;
      r5 = _o_6;
      r6 = _o_7;
      r7 = _o_8;
      r8 = _o_9;
      r9 = _o_10;
      r10 = _state_0;
      r11 = _state_1;
      r12 = _state_2;
      r13 = _state_3;
      r14 = _state_4;
      r15 = _state_5;
      r16 = _state_6;
      r17 = _state_7;
      r18 = _state_8;
      r19 = _state_9;
      r20 = _state_10;
      r21 = _state_11;
      r22 = _state_12;
      r23 = _state_13;
      r24 = _state_14;
      r25 = _state_15;
      r26 = _state_16;
      r27 = _state_17;
      r28 = _state_18;
      r29 = _state_19;
      r30 = _state_20;
      WL_JMP(FID_COMMANDS_STATE_COMMAND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_BATCH_K284)
  {
    WL_POPN(3);
    Term _f_13 = STK(0);
    u32 _namespace_1 = STK(1);
    u32 _tick_1 = STK(2);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_BATCH)) {
      u64 _t_2 = task_node(e, FID_COMMANDS_BATCH, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_13;
      e.mem[_t_2 + 1] = _namespace_1;
      e.mem[_t_2 + 2] = _tick_1;
      e.mem[_t_2 + 3] = _h_0;
      e.mem[_t_2 + 4] = _h_1;
      e.mem[_t_2 + 5] = _h_2;
      e.mem[_t_2 + 6] = _h_3;
      e.mem[_t_2 + 7] = _h_4;
      e.mem[_t_2 + 8] = _h_5;
      e.mem[_t_2 + 9] = _h_6;
      e.mem[_t_2 + 10] = _h_7;
      e.mem[_t_2 + 11] = _h_8;
      e.mem[_t_2 + 12] = _h_9;
      e.mem[_t_2 + 13] = _h_10;
      e.mem[_t_2 + 14] = _h_11;
      e.mem[_t_2 + 15] = _h_12;
      e.mem[_t_2 + 16] = _h_13;
      e.mem[_t_2 + 17] = _h_14;
      e.mem[_t_2 + 18] = _h_15;
      e.mem[_t_2 + 19] = _h_16;
      e.mem[_t_2 + 20] = _h_17;
      e.mem[_t_2 + 21] = _h_18;
      e.mem[_t_2 + 22] = _h_19;
      e.mem[_t_2 + 23] = _h_20;
      return term_tsk(FID_COMMANDS_BATCH, _t_2);
    }
    r0 = _f_13;
    r1 = _namespace_1;
    r2 = _tick_1;
    r3 = _h_0;
    r4 = _h_1;
    r5 = _h_2;
    r6 = _h_3;
    r7 = _h_4;
    r8 = _h_5;
    r9 = _h_6;
    r10 = _h_7;
    r11 = _h_8;
    r12 = _h_9;
    r13 = _h_10;
    r14 = _h_11;
    r15 = _h_12;
    r16 = _h_13;
    r17 = _h_14;
    r18 = _h_15;
    r19 = _h_16;
    r20 = _h_17;
    r21 = _h_18;
    r22 = _h_19;
    r23 = _h_20;
    WL_JMP(FID_COMMANDS_BATCH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDENTITY_VALUES)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _result_0 = r2;
    u32 _result_1 = r3;
    Term _result_2 = r4;
    Term _result_3 = r5;
    Term _result_4 = r6;
    Term _result_5 = r7;
    Term _result_6 = r8;
    Term _result_7 = r9;
    u32 _result_8 = r10;
    Term _result_9 = r11;
    u32 _result_10 = r12;
    Term _result_11 = r13;
    u32 _result_12 = r14;
    u32 _result_13 = r15;
    Term _result_14 = r16;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      if (_result_13 == 0) {
        Term _v_0 = 0;
        Term _v_1 = 0;
        Term _o_0[1];
        if (spin_49(e, _o_0, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
          return 0;
        }
        _v_1 = _o_0[0];
        _v_0 = _v_1;
        r0 = _result_0;
        r1 = _result_1;
        r2 = _result_2;
        r3 = _result_3;
        r4 = _result_4;
        r5 = _result_5;
        r6 = _result_6;
        r7 = _result_7;
        r8 = _result_8;
        r9 = _result_9;
        r10 = _result_10;
        r11 = _result_11;
        r12 = _result_12;
        r13 = _v_0;
        WL_RETN(14);
      } else {
        Term _v_2 = 0;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _result_14);
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        Term _v_3 = 0;
        Term _o_1[1];
        Term _a_0 = term_ctr(CID_CON, _nd_0);
        if (spin_49(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
          return 0;
        }
        _v_3 = _o_1[0];
        _v_2 = _v_3;
        r0 = _result_0;
        r1 = _result_1;
        r2 = _result_2;
        r3 = _result_3;
        r4 = _result_4;
        r5 = _result_5;
        r6 = _result_6;
        r7 = _result_7;
        r8 = _result_8;
        r9 = _result_9;
        r10 = _result_10;
        r11 = _result_11;
        r12 = _result_12;
        r13 = _v_2;
        WL_RETN(14);
      }
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      if (_result_13 == 0) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_1;
          STK(1) = _acc_0;
          STK(2) = FID_IDENTITY_VALUES_K289;
          WL_PUSHN(3);
        } else {
          u64 _t_0 = task_node(e, FID_IDENTITY_VALUES_K289, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _acc_0;
          WL_CONT = term_tsk(FID_IDENTITY_VALUES_K289, _t_0);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_QUERY_LOOKUP_0)) {
          u64 _t_1 = task_node(e, FID_QUERY_LOOKUP_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = 3;
          e.mem[_t_1 + 1] = _result_0;
          e.mem[_t_1 + 2] = _result_1;
          e.mem[_t_1 + 3] = _result_2;
          e.mem[_t_1 + 4] = _result_3;
          e.mem[_t_1 + 5] = _result_4;
          e.mem[_t_1 + 6] = _result_5;
          e.mem[_t_1 + 7] = _result_6;
          e.mem[_t_1 + 8] = _result_7;
          e.mem[_t_1 + 9] = _result_8;
          e.mem[_t_1 + 10] = _result_9;
          e.mem[_t_1 + 11] = _result_10;
          e.mem[_t_1 + 12] = _result_11;
          e.mem[_t_1 + 13] = _result_12;
          e.mem[_t_1 + 14] = _f_2;
          e.mem[_t_1 + 15] = _f_3;
          return term_tsk(FID_QUERY_LOOKUP_0, _t_1);
        }
        r0 = 3;
        r1 = _result_0;
        r2 = _result_1;
        r3 = _result_2;
        r4 = _result_3;
        r5 = _result_4;
        r6 = _result_5;
        r7 = _result_6;
        r8 = _result_7;
        r9 = _result_8;
        r10 = _result_9;
        r11 = _result_10;
        r12 = _result_11;
        r13 = _result_12;
        r14 = _f_2;
        r15 = _f_3;
        WL_JMP(FID_QUERY_LOOKUP_0);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(4);
          STK(0) = _f_1;
          STK(1) = _acc_0;
          STK(2) = _result_14;
          STK(3) = FID_IDENTITY_VALUES_K290;
          WL_PUSHN(4);
        } else {
          u64 _t_3 = task_node(e, FID_IDENTITY_VALUES_K290, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_1;
          e.mem[_t_3 + 1] = _acc_0;
          e.mem[_t_3 + 2] = _result_14;
          WL_CONT = term_tsk(FID_IDENTITY_VALUES_K290, _t_3);
          WL_IDX = 3;
        }
        if (!DEVICE && !seq && fid_nofk(FID_QUERY_LOOKUP_0)) {
          u64 _t_4 = task_node(e, FID_QUERY_LOOKUP_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = 3;
          e.mem[_t_4 + 1] = _result_0;
          e.mem[_t_4 + 2] = _result_1;
          e.mem[_t_4 + 3] = _result_2;
          e.mem[_t_4 + 4] = _result_3;
          e.mem[_t_4 + 5] = _result_4;
          e.mem[_t_4 + 6] = _result_5;
          e.mem[_t_4 + 7] = _result_6;
          e.mem[_t_4 + 8] = _result_7;
          e.mem[_t_4 + 9] = _result_8;
          e.mem[_t_4 + 10] = _result_9;
          e.mem[_t_4 + 11] = _result_10;
          e.mem[_t_4 + 12] = _result_11;
          e.mem[_t_4 + 13] = _result_12;
          e.mem[_t_4 + 14] = _f_2;
          e.mem[_t_4 + 15] = _f_3;
          return term_tsk(FID_QUERY_LOOKUP_0, _t_4);
        }
        r0 = 3;
        r1 = _result_0;
        r2 = _result_1;
        r3 = _result_2;
        r4 = _result_3;
        r5 = _result_4;
        r6 = _result_5;
        r7 = _result_6;
        r8 = _result_7;
        r9 = _result_8;
        r10 = _result_9;
        r11 = _result_10;
        r12 = _result_11;
        r13 = _result_12;
        r14 = _f_2;
        r15 = _f_3;
        WL_JMP(FID_QUERY_LOOKUP_0);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDENTITY_VALUES_K289)
  {
    WL_POPN(2);
    Term _f_4 = STK(0);
    Term _acc_1 = STK(1);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    WL_OPEN
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    Term _o_3[15];
    if (spin_99(e, _o_3, _h_0, _h_1, _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, _h_9, _h_10, _h_11, blk_loc(e.mem, _h_11), _h_12, _h_13, _h_14, blk_loc(e.mem, _h_14)) == 0) {
      return 0;
    }
    _v_19 = _o_3[0];
    _v_20 = _o_3[1];
    _v_21 = _o_3[2];
    _v_22 = _o_3[3];
    _v_23 = _o_3[4];
    _v_24 = _o_3[5];
    _v_25 = _o_3[6];
    _v_26 = _o_3[7];
    _v_27 = _o_3[8];
    _v_28 = _o_3[9];
    _v_29 = _o_3[10];
    _v_30 = _o_3[11];
    _v_31 = _o_3[12];
    _v_32 = _o_3[13];
    _v_33 = _o_3[14];
    _v_4 = _v_19;
    _v_5 = _v_20;
    _v_6 = _v_21;
    _v_7 = _v_22;
    _v_8 = _v_23;
    _v_9 = _v_24;
    _v_10 = _v_25;
    _v_11 = _v_26;
    _v_12 = _v_27;
    _v_13 = _v_28;
    _v_14 = _v_29;
    _v_15 = _v_30;
    _v_16 = _v_31;
    _v_17 = _v_32;
    _v_18 = _v_33;
    if (!DEVICE && !seq && fid_nofk(FID_IDENTITY_VALUES)) {
      u64 _t_2 = task_node(e, FID_IDENTITY_VALUES, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_4;
      e.mem[_t_2 + 1] = _acc_1;
      e.mem[_t_2 + 2] = _v_4;
      e.mem[_t_2 + 3] = _v_5;
      e.mem[_t_2 + 4] = _v_6;
      e.mem[_t_2 + 5] = _v_7;
      e.mem[_t_2 + 6] = _v_8;
      e.mem[_t_2 + 7] = _v_9;
      e.mem[_t_2 + 8] = _v_10;
      e.mem[_t_2 + 9] = _v_11;
      e.mem[_t_2 + 10] = _v_12;
      e.mem[_t_2 + 11] = _v_13;
      e.mem[_t_2 + 12] = _v_14;
      e.mem[_t_2 + 13] = _v_15;
      e.mem[_t_2 + 14] = _v_16;
      e.mem[_t_2 + 15] = _v_17;
      e.mem[_t_2 + 16] = _v_18;
      return term_tsk(FID_IDENTITY_VALUES, _t_2);
    }
    r0 = _f_4;
    r1 = _acc_1;
    r2 = _v_4;
    r3 = _v_5;
    r4 = _v_6;
    r5 = _v_7;
    r6 = _v_8;
    r7 = _v_9;
    r8 = _v_10;
    r9 = _v_11;
    r10 = _v_12;
    r11 = _v_13;
    r12 = _v_14;
    r13 = _v_15;
    r14 = _v_16;
    r15 = _v_17;
    r16 = _v_18;
    WL_JMP(FID_IDENTITY_VALUES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDENTITY_VALUES_K290)
  {
    WL_POPN(3);
    Term _f_5 = STK(0);
    Term _acc_2 = STK(1);
    Term _result_30 = STK(2);
    u32 _h_15 = r0;
    u32 _h_16 = r1;
    Term _h_17 = r2;
    Term _h_18 = r3;
    Term _h_19 = r4;
    Term _h_20 = r5;
    Term _h_21 = r6;
    Term _h_22 = r7;
    u32 _h_23 = r8;
    Term _h_24 = r9;
    u32 _h_25 = r10;
    Term _h_26 = r11;
    u32 _h_27 = r12;
    u32 _h_28 = r13;
    Term _h_29 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _result_30);
    e.mem[_nd_1 + 1] = rfc_seal(e, _acc_2);
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    u32 _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _v_80 = 0;
    Term _o_4[15];
    if (spin_99(e, _o_4, _h_15, _h_16, _h_17, blk_loc(e.mem, _h_17), _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20), _h_21, blk_loc(e.mem, _h_21), _h_22, blk_loc(e.mem, _h_22), _h_23, _h_24, _h_25, _h_26, blk_loc(e.mem, _h_26), _h_27, _h_28, _h_29, blk_loc(e.mem, _h_29)) == 0) {
      return 0;
    }
    _v_66 = _o_4[0];
    _v_67 = _o_4[1];
    _v_68 = _o_4[2];
    _v_69 = _o_4[3];
    _v_70 = _o_4[4];
    _v_71 = _o_4[5];
    _v_72 = _o_4[6];
    _v_73 = _o_4[7];
    _v_74 = _o_4[8];
    _v_75 = _o_4[9];
    _v_76 = _o_4[10];
    _v_77 = _o_4[11];
    _v_78 = _o_4[12];
    _v_79 = _o_4[13];
    _v_80 = _o_4[14];
    _v_51 = _v_66;
    _v_52 = _v_67;
    _v_53 = _v_68;
    _v_54 = _v_69;
    _v_55 = _v_70;
    _v_56 = _v_71;
    _v_57 = _v_72;
    _v_58 = _v_73;
    _v_59 = _v_74;
    _v_60 = _v_75;
    _v_61 = _v_76;
    _v_62 = _v_77;
    _v_63 = _v_78;
    _v_64 = _v_79;
    _v_65 = _v_80;
    if (!DEVICE && !seq && fid_nofk(FID_IDENTITY_VALUES)) {
      u64 _t_5 = task_node(e, FID_IDENTITY_VALUES, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_5;
      e.mem[_t_5 + 1] = term_ctr(CID_CON, _nd_1);
      e.mem[_t_5 + 2] = _v_51;
      e.mem[_t_5 + 3] = _v_52;
      e.mem[_t_5 + 4] = _v_53;
      e.mem[_t_5 + 5] = _v_54;
      e.mem[_t_5 + 6] = _v_55;
      e.mem[_t_5 + 7] = _v_56;
      e.mem[_t_5 + 8] = _v_57;
      e.mem[_t_5 + 9] = _v_58;
      e.mem[_t_5 + 10] = _v_59;
      e.mem[_t_5 + 11] = _v_60;
      e.mem[_t_5 + 12] = _v_61;
      e.mem[_t_5 + 13] = _v_62;
      e.mem[_t_5 + 14] = _v_63;
      e.mem[_t_5 + 15] = _v_64;
      e.mem[_t_5 + 16] = _v_65;
      return term_tsk(FID_IDENTITY_VALUES, _t_5);
    }
    r0 = _f_5;
    r1 = term_ctr(CID_CON, _nd_1);
    r2 = _v_51;
    r3 = _v_52;
    r4 = _v_53;
    r5 = _v_54;
    r6 = _v_55;
    r7 = _v_56;
    r8 = _v_57;
    r9 = _v_58;
    r10 = _v_59;
    r11 = _v_60;
    r12 = _v_61;
    r13 = _v_62;
    r14 = _v_63;
    r15 = _v_64;
    r16 = _v_65;
    WL_JMP(FID_IDENTITY_VALUES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRINGS)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 66);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRINGS_K292;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRINGS_K292, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRINGS_K292, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _values_0 = r0;
      WL_AGAIN(FID_STRINGS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRINGS_K292)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_2;
      STK(1) = FID_STRINGS_K293;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_STRINGS_K293, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _f_2;
      WL_CONT = term_tsk(FID_STRINGS_K293, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 68);
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 68);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRINGS_K293)
  {
    WL_POPN(1);
    Term _f_3 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_3;
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _f_3;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_LOOKUP_0)
  {
    u32 _selection_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    Term _world_2 = r3;
    Term _world_3 = r4;
    Term _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    u32 _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    Term _world_11 = r12;
    u32 _world_12 = r13;
    u32 _handle_0 = r14;
    u32 _handle_1 = r15;
    WL_OPEN
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = 2;
      r14 = 0;
      WL_RETN(15);
    } else {
      if (seq) {
        WL_ROOM(5);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_11;
        STK(3) = _world_12;
        STK(4) = FID_QUERY_LOOKUP_0_K298;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID_QUERY_LOOKUP_0_K298, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_11;
        e.mem[_t_0 + 3] = _world_12;
        WL_CONT = term_tsk(FID_QUERY_LOOKUP_0_K298, _t_0);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID_QUERY_LOOKUP_ROWS_0)) {
        u64 _t_1 = task_node(e, FID_QUERY_LOOKUP_ROWS_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _world_2;
        e.mem[_t_1 + 1] = _world_3;
        e.mem[_t_1 + 2] = _world_4;
        e.mem[_t_1 + 3] = _world_5;
        e.mem[_t_1 + 4] = _world_6;
        e.mem[_t_1 + 5] = _world_7;
        e.mem[_t_1 + 6] = _world_8;
        e.mem[_t_1 + 7] = _world_9;
        e.mem[_t_1 + 8] = _world_10;
        e.mem[_t_1 + 9] = _selection_0;
        e.mem[_t_1 + 10] = _world_0;
        e.mem[_t_1 + 11] = _handle_1;
        return term_tsk(FID_QUERY_LOOKUP_ROWS_0, _t_1);
      }
      r0 = _world_2;
      r1 = _world_3;
      r2 = _world_4;
      r3 = _world_5;
      r4 = _world_6;
      r5 = _world_7;
      r6 = _world_8;
      r7 = _world_9;
      r8 = _world_10;
      r9 = _selection_0;
      r10 = _world_0;
      r11 = _handle_1;
      WL_JMP(FID_QUERY_LOOKUP_ROWS_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUERY_LOOKUP_0_K298)
  {
    WL_POPN(4);
    u32 _world_13 = STK(0);
    u32 _world_14 = STK(1);
    Term _world_15 = STK(2);
    u32 _world_16 = STK(3);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_world_16 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _o_2[17];
    Term _a_0 = term_pak(CID_UNIT, 0);
    if (spin_89(e, _o_2, _world_13, _world_14, _world_15, blk_loc(e.mem, _world_15), _o_0, _o_1, blk_loc(e.mem, _o_1), _a_0, blk_loc(e.mem, _a_0), _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10)) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    _v_7 = _o_2[7];
    _v_8 = _o_2[8];
    _v_9 = _o_2[9];
    _v_10 = _o_2[10];
    _v_11 = _o_2[11];
    _v_12 = _o_2[12];
    _v_13 = _o_2[13];
    _v_14 = _o_2[14];
    _v_15 = _o_2[15];
    _v_16 = _o_2[16];
    u32 _o_3 = 0;
    if (_v_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _o_3;
    r13 = _v_15;
    r14 = _v_16;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_QUEUE_OWNED)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _payload_0 = r17;
    Term _build_0 = r18;
    WL_OPEN
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _build_0);
      r0 = 1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _world_2;
      r4 = _world_3;
      r5 = _world_4;
      r6 = _world_5;
      r7 = _world_6;
      r8 = _world_7;
      r9 = _world_8;
      r10 = _world_9;
      r11 = _world_10;
      r12 = _world_11;
      r13 = _world_12;
      r14 = _world_13;
      r15 = _world_14;
      r16 = _payload_0;
      WL_RETN(17);
    } else {
      if (seq) {
        WL_ROOM(17);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_2;
        STK(3) = _world_3;
        STK(4) = _world_4;
        STK(5) = _world_5;
        STK(6) = _world_6;
        STK(7) = _world_7;
        STK(8) = _world_8;
        STK(9) = _world_9;
        STK(10) = _world_10;
        STK(11) = _world_11;
        STK(12) = _world_12;
        STK(13) = _world_13;
        STK(14) = _world_14;
        STK(15) = _payload_0;
        STK(16) = FID_COMMANDS_QUEUE_OWNED_K309;
        WL_PUSHN(17);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_QUEUE_OWNED_K309, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_2;
        e.mem[_t_0 + 3] = _world_3;
        e.mem[_t_0 + 4] = _world_4;
        e.mem[_t_0 + 5] = _world_5;
        e.mem[_t_0 + 6] = _world_6;
        e.mem[_t_0 + 7] = _world_7;
        e.mem[_t_0 + 8] = _world_8;
        e.mem[_t_0 + 9] = _world_9;
        e.mem[_t_0 + 10] = _world_10;
        e.mem[_t_0 + 11] = _world_11;
        e.mem[_t_0 + 12] = _world_12;
        e.mem[_t_0 + 13] = _world_13;
        e.mem[_t_0 + 14] = _world_14;
        e.mem[_t_0 + 15] = _payload_0;
        WL_CONT = term_tsk(FID_COMMANDS_QUEUE_OWNED_K309, _t_0);
        WL_IDX = 16;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _build_0;
        e.mem[_t_1 + 1] = _handle_1;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _build_0;
      r1 = _handle_1;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_QUEUE_OWNED_K309)
  {
    WL_POPN(16);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    Term _world_22 = STK(7);
    u32 _world_23 = STK(8);
    Term _world_24 = STK(9);
    u32 _world_25 = STK(10);
    Term _world_26 = STK(11);
    u32 _world_27 = STK(12);
    Term _world_28 = STK(13);
    Term _world_29 = STK(14);
    Term _payload_1 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _world_15;
      STK(1) = _world_16;
      STK(2) = _world_17;
      STK(3) = _world_18;
      STK(4) = _world_19;
      STK(5) = _world_20;
      STK(6) = _world_21;
      STK(7) = _world_22;
      STK(8) = _world_23;
      STK(9) = _world_24;
      STK(10) = _world_25;
      STK(11) = _world_26;
      STK(12) = _world_27;
      STK(13) = _world_28;
      STK(14) = _world_29;
      STK(15) = FID_COMMANDS_QUEUE_OWNED_K310;
      WL_PUSHN(16);
    } else {
      u64 _t_2 = task_node(e, FID_COMMANDS_QUEUE_OWNED_K310, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _world_15;
      e.mem[_t_2 + 1] = _world_16;
      e.mem[_t_2 + 2] = _world_17;
      e.mem[_t_2 + 3] = _world_18;
      e.mem[_t_2 + 4] = _world_19;
      e.mem[_t_2 + 5] = _world_20;
      e.mem[_t_2 + 6] = _world_21;
      e.mem[_t_2 + 7] = _world_22;
      e.mem[_t_2 + 8] = _world_23;
      e.mem[_t_2 + 9] = _world_24;
      e.mem[_t_2 + 10] = _world_25;
      e.mem[_t_2 + 11] = _world_26;
      e.mem[_t_2 + 12] = _world_27;
      e.mem[_t_2 + 13] = _world_28;
      e.mem[_t_2 + 14] = _world_29;
      WL_CONT = term_tsk(FID_COMMANDS_QUEUE_OWNED_K310, _t_2);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _payload_1;
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _h_0;
    r1 = _payload_1;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_QUEUE_OWNED_K310)
  {
    WL_POPN(15);
    u32 _world_30 = STK(0);
    u32 _world_31 = STK(1);
    Term _world_32 = STK(2);
    Term _world_33 = STK(3);
    Term _world_34 = STK(4);
    Term _world_35 = STK(5);
    Term _world_36 = STK(6);
    Term _world_37 = STK(7);
    u32 _world_38 = STK(8);
    Term _world_39 = STK(9);
    u32 _world_40 = STK(10);
    Term _world_41 = STK(11);
    u32 _world_42 = STK(12);
    Term _world_43 = STK(13);
    Term _world_44 = STK(14);
    Term _h_1 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _o_0[15];
    Term _a_0 = term_ctr(CID_CON, _nd_0);
    if (spin_90(e, _o_0, _world_30, _world_31, _world_32, blk_loc(e.mem, _world_32), _world_33, blk_loc(e.mem, _world_33), _world_34, blk_loc(e.mem, _world_34), _world_35, blk_loc(e.mem, _world_35), _world_36, blk_loc(e.mem, _world_36), _world_37, blk_loc(e.mem, _world_37), _world_38, _world_39, _world_40, _world_41, blk_loc(e.mem, _world_41), _world_42, _world_43, blk_loc(e.mem, _world_43), _world_44, blk_loc(e.mem, _world_44), _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_20 = _o_0[5];
    _v_21 = _o_0[6];
    _v_22 = _o_0[7];
    _v_23 = _o_0[8];
    _v_24 = _o_0[9];
    _v_25 = _o_0[10];
    _v_26 = _o_0[11];
    _v_27 = _o_0[12];
    _v_28 = _o_0[13];
    _v_29 = _o_0[14];
    _v_0 = _v_15;
    _v_1 = _v_16;
    _v_2 = _v_17;
    _v_3 = _v_18;
    _v_4 = _v_19;
    _v_5 = _v_20;
    _v_6 = _v_21;
    _v_7 = _v_22;
    _v_8 = _v_23;
    _v_9 = _v_24;
    _v_10 = _v_25;
    _v_11 = _v_26;
    _v_12 = _v_27;
    _v_13 = _v_28;
    _v_14 = _v_29;
    r0 = 0;
    r1 = _v_0;
    r2 = _v_1;
    r3 = _v_2;
    r4 = _v_3;
    r5 = _v_4;
    r6 = _v_5;
    r7 = _v_6;
    r8 = _v_7;
    r9 = _v_8;
    r10 = _v_9;
    r11 = _v_10;
    r12 = _v_11;
    r13 = _v_12;
    r14 = _v_13;
    r15 = _v_14;
    r16 = 0;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT)
  {
    Term _prefix_0 = r0;
    Term _result_0 = r1;
    Term _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    u32 _result_6 = r7;
    Term _result_7 = r8;
    u32 _result_8 = r9;
    u32 _result_9 = r10;
    u32 _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    u32 _result_14 = r15;
    Term _result_15 = r16;
    u32 _result_16 = r17;
    u32 _result_17 = r18;
    u32 _result_18 = r19;
    u32 _result_19 = r20;
    WL_OPEN
    if (_result_9 == 0) {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _result_0;
        STK(1) = _result_1;
        STK(2) = _result_2;
        STK(3) = _result_3;
        STK(4) = _result_4;
        STK(5) = _result_5;
        STK(6) = _result_6;
        STK(7) = _result_7;
        STK(8) = _result_8;
        STK(9) = FID_EXTRACTED_PRINT_K313;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_EXTRACTED_PRINT_K313, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_0;
        e.mem[_t_0 + 1] = _result_1;
        e.mem[_t_0 + 2] = _result_2;
        e.mem[_t_0 + 3] = _result_3;
        e.mem[_t_0 + 4] = _result_4;
        e.mem[_t_0 + 5] = _result_5;
        e.mem[_t_0 + 6] = _result_6;
        e.mem[_t_0 + 7] = _result_7;
        e.mem[_t_0 + 8] = _result_8;
        WL_CONT = term_tsk(FID_EXTRACTED_PRINT_K313, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _prefix_0;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 44);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 44);
      WL_JMP(FID_STRING_APPEND);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _prefix_0;
        STK(1) = _result_0;
        STK(2) = _result_1;
        STK(3) = _result_2;
        STK(4) = _result_3;
        STK(5) = _result_4;
        STK(6) = _result_5;
        STK(7) = _result_6;
        STK(8) = _result_7;
        STK(9) = _result_8;
        STK(10) = FID_EXTRACTED_PRINT_K317;
        WL_PUSHN(11);
      } else {
        u64 _t_4 = task_node(e, FID_EXTRACTED_PRINT_K317, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _prefix_0;
        e.mem[_t_4 + 1] = _result_0;
        e.mem[_t_4 + 2] = _result_1;
        e.mem[_t_4 + 3] = _result_2;
        e.mem[_t_4 + 4] = _result_3;
        e.mem[_t_4 + 5] = _result_4;
        e.mem[_t_4 + 6] = _result_5;
        e.mem[_t_4 + 7] = _result_6;
        e.mem[_t_4 + 8] = _result_7;
        e.mem[_t_4 + 9] = _result_8;
        WL_CONT = term_tsk(FID_EXTRACTED_PRINT_K317, _t_4);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ROW_OBSERVE)) {
        u64 _t_5 = task_node(e, FID_ROW_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _result_10;
        e.mem[_t_5 + 1] = _result_11;
        e.mem[_t_5 + 2] = _result_12;
        e.mem[_t_5 + 3] = _result_13;
        e.mem[_t_5 + 4] = _result_14;
        e.mem[_t_5 + 5] = _result_15;
        e.mem[_t_5 + 6] = _result_16;
        e.mem[_t_5 + 7] = _result_17;
        e.mem[_t_5 + 8] = _result_18;
        e.mem[_t_5 + 9] = _result_19;
        return term_tsk(FID_ROW_OBSERVE, _t_5);
      }
      r0 = _result_10;
      r1 = _result_11;
      r2 = _result_12;
      r3 = _result_13;
      r4 = _result_14;
      r5 = _result_15;
      r6 = _result_16;
      r7 = _result_17;
      r8 = _result_18;
      r9 = _result_19;
      WL_JMP(FID_ROW_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_K313)
  {
    WL_POPN(9);
    Term _result_20 = STK(0);
    Term _result_21 = STK(1);
    Term _result_22 = STK(2);
    Term _result_23 = STK(3);
    Term _result_24 = STK(4);
    Term _result_25 = STK(5);
    u32 _result_26 = STK(6);
    Term _result_27 = STK(7);
    u32 _result_28 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _result_20;
    e.mem[_nd_0 + 1] = _result_21;
    e.mem[_nd_0 + 2] = _result_22;
    e.mem[_nd_0 + 3] = _result_23;
    e.mem[_nd_0 + 4] = _result_24;
    e.mem[_nd_0 + 5] = _result_25;
    e.mem[_nd_0 + 6] = _result_26;
    e.mem[_nd_0 + 7] = _result_27;
    e.mem[_nd_0 + 8] = _result_28;
    e.mem[_nd_0 + 9] = _h_0;
    r0 = term_clo(FID_EXTRACTED_PRINT_C314, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_C314)
  {
    Term _result_29 = r0;
    Term _result_30 = r1;
    Term _result_31 = r2;
    Term _result_32 = r3;
    Term _result_33 = r4;
    Term _result_34 = r5;
    u32 _result_35 = r6;
    Term _result_36 = r7;
    u32 _result_37 = r8;
    Term _h_1 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _result_29;
    e.mem[_nd_2 + 1] = _result_30;
    e.mem[_nd_2 + 2] = _result_31;
    e.mem[_nd_2 + 3] = _result_32;
    e.mem[_nd_2 + 4] = _result_33;
    e.mem[_nd_2 + 5] = _result_34;
    e.mem[_nd_2 + 6] = _result_35;
    e.mem[_nd_2 + 7] = _result_36;
    e.mem[_nd_2 + 8] = _result_37;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_EXTRACTED_PRINT_C315, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_EXTRACTED_PRINT_C315, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_C315)
  {
    Term _result_38 = r0;
    Term _result_39 = r1;
    Term _result_40 = r2;
    Term _result_41 = r3;
    Term _result_42 = r4;
    Term _result_43 = r5;
    u32 _result_44 = r6;
    Term _result_45 = r7;
    u32 _result_46 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _result_38;
    e.mem[_nd_3 + 1] = _result_39;
    e.mem[_nd_3 + 2] = _result_40;
    e.mem[_nd_3 + 3] = _result_41;
    e.mem[_nd_3 + 4] = _result_42;
    e.mem[_nd_3 + 5] = _result_43;
    e.mem[_nd_3 + 6] = _result_44;
    e.mem[_nd_3 + 7] = _result_45;
    e.mem[_nd_3 + 8] = _result_46;
    r0 = term_clo(FID_EXTRACTED_PRINT_C316, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_C316)
  {
    Term _result_47 = r0;
    Term _result_48 = r1;
    Term _result_49 = r2;
    Term _result_50 = r3;
    Term _result_51 = r4;
    Term _result_52 = r5;
    u32 _result_53 = r6;
    Term _result_54 = r7;
    u32 _result_55 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_47);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_48);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_49);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_50);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_51);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_52);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_53);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_54);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_55);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_K317)
  {
    WL_POPN(10);
    Term _prefix_1 = STK(0);
    Term _result_56 = STK(1);
    Term _result_57 = STK(2);
    Term _result_58 = STK(3);
    Term _result_59 = STK(4);
    Term _result_60 = STK(5);
    Term _result_61 = STK(6);
    u32 _result_62 = STK(7);
    Term _result_63 = STK(8);
    u32 _result_64 = STK(9);
    u32 _h_2 = r0;
    u32 _h_3 = r1;
    Term _h_4 = r2;
    u32 _h_5 = r3;
    u32 _h_6 = r4;
    Term _h_7 = r5;
    u32 _h_8 = r6;
    u32 _h_9 = r7;
    u32 _h_10 = r8;
    u32 _h_11 = r9;
    Term _h_12 = r10;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_56;
      STK(1) = _result_57;
      STK(2) = _result_58;
      STK(3) = _result_59;
      STK(4) = _result_60;
      STK(5) = _result_61;
      STK(6) = _result_62;
      STK(7) = _result_63;
      STK(8) = _result_64;
      STK(9) = _h_2;
      STK(10) = _h_3;
      STK(11) = _h_4;
      STK(12) = _h_5;
      STK(13) = _h_6;
      STK(14) = _h_7;
      STK(15) = _h_8;
      STK(16) = _h_9;
      STK(17) = _h_10;
      STK(18) = _h_11;
      STK(19) = FID_EXTRACTED_PRINT_K318;
      WL_PUSHN(20);
    } else {
      u64 _t_6 = task_node(e, FID_EXTRACTED_PRINT_K318, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _result_56;
      e.mem[_t_6 + 1] = _result_57;
      e.mem[_t_6 + 2] = _result_58;
      e.mem[_t_6 + 3] = _result_59;
      e.mem[_t_6 + 4] = _result_60;
      e.mem[_t_6 + 5] = _result_61;
      e.mem[_t_6 + 6] = _result_62;
      e.mem[_t_6 + 7] = _result_63;
      e.mem[_t_6 + 8] = _result_64;
      e.mem[_t_6 + 9] = _h_2;
      e.mem[_t_6 + 10] = _h_3;
      e.mem[_t_6 + 11] = _h_4;
      e.mem[_t_6 + 12] = _h_5;
      e.mem[_t_6 + 13] = _h_6;
      e.mem[_t_6 + 14] = _h_7;
      e.mem[_t_6 + 15] = _h_8;
      e.mem[_t_6 + 16] = _h_9;
      e.mem[_t_6 + 17] = _h_10;
      e.mem[_t_6 + 18] = _h_11;
      WL_CONT = term_tsk(FID_EXTRACTED_PRINT_K318, _t_6);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _prefix_1;
      e.mem[_t_7 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _prefix_1;
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_K318)
  {
    WL_POPN(19);
    Term _result_65 = STK(0);
    Term _result_66 = STK(1);
    Term _result_67 = STK(2);
    Term _result_68 = STK(3);
    Term _result_69 = STK(4);
    Term _result_70 = STK(5);
    u32 _result_71 = STK(6);
    Term _result_72 = STK(7);
    u32 _result_73 = STK(8);
    u32 _h_14 = STK(9);
    u32 _h_15 = STK(10);
    Term _h_16 = STK(11);
    u32 _h_17 = STK(12);
    u32 _h_18 = STK(13);
    Term _h_19 = STK(14);
    u32 _h_20 = STK(15);
    u32 _h_21 = STK(16);
    u32 _h_22 = STK(17);
    u32 _h_23 = STK(18);
    Term _h_13 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(20));
    e.mem[_nd_5 + 0] = _result_65;
    e.mem[_nd_5 + 1] = _result_66;
    e.mem[_nd_5 + 2] = _result_67;
    e.mem[_nd_5 + 3] = _result_68;
    e.mem[_nd_5 + 4] = _result_69;
    e.mem[_nd_5 + 5] = _result_70;
    e.mem[_nd_5 + 6] = _result_71;
    e.mem[_nd_5 + 7] = _result_72;
    e.mem[_nd_5 + 8] = _result_73;
    e.mem[_nd_5 + 9] = _h_14;
    e.mem[_nd_5 + 10] = _h_15;
    e.mem[_nd_5 + 11] = _h_16;
    e.mem[_nd_5 + 12] = _h_17;
    e.mem[_nd_5 + 13] = _h_18;
    e.mem[_nd_5 + 14] = _h_19;
    e.mem[_nd_5 + 15] = _h_20;
    e.mem[_nd_5 + 16] = _h_21;
    e.mem[_nd_5 + 17] = _h_22;
    e.mem[_nd_5 + 18] = _h_23;
    e.mem[_nd_5 + 19] = _h_13;
    r0 = term_clo(FID_EXTRACTED_PRINT_C319, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_C319)
  {
    Term _result_74 = r0;
    Term _result_75 = r1;
    Term _result_76 = r2;
    Term _result_77 = r3;
    Term _result_78 = r4;
    Term _result_79 = r5;
    u32 _result_80 = r6;
    Term _result_81 = r7;
    u32 _result_82 = r8;
    u32 _h_24 = r9;
    u32 _h_25 = r10;
    Term _h_26 = r11;
    u32 _h_27 = r12;
    u32 _h_28 = r13;
    Term _h_29 = r14;
    u32 _h_30 = r15;
    u32 _h_31 = r16;
    u32 _h_32 = r17;
    u32 _h_33 = r18;
    Term _h_34 = r19;
    Term _x_3 = r20;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_34;
    u64 _nd_7 = heap_alloc(e, cls_fit(19));
    e.mem[_nd_7 + 0] = _result_74;
    e.mem[_nd_7 + 1] = _result_75;
    e.mem[_nd_7 + 2] = _result_76;
    e.mem[_nd_7 + 3] = _result_77;
    e.mem[_nd_7 + 4] = _result_78;
    e.mem[_nd_7 + 5] = _result_79;
    e.mem[_nd_7 + 6] = _result_80;
    e.mem[_nd_7 + 7] = _result_81;
    e.mem[_nd_7 + 8] = _result_82;
    e.mem[_nd_7 + 9] = _h_24;
    e.mem[_nd_7 + 10] = _h_25;
    e.mem[_nd_7 + 11] = _h_26;
    e.mem[_nd_7 + 12] = _h_27;
    e.mem[_nd_7 + 13] = _h_28;
    e.mem[_nd_7 + 14] = _h_29;
    e.mem[_nd_7 + 15] = _h_30;
    e.mem[_nd_7 + 16] = _h_31;
    e.mem[_nd_7 + 17] = _h_32;
    e.mem[_nd_7 + 18] = _h_33;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_9 + 1] = term_clo(FID_EXTRACTED_PRINT_C320, _nd_7);
      e.mem[_t_9 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_EXTRACTED_PRINT_C320, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_C320)
  {
    Term _result_83 = r0;
    Term _result_84 = r1;
    Term _result_85 = r2;
    Term _result_86 = r3;
    Term _result_87 = r4;
    Term _result_88 = r5;
    u32 _result_89 = r6;
    Term _result_90 = r7;
    u32 _result_91 = r8;
    u32 _h_35 = r9;
    u32 _h_36 = r10;
    Term _h_37 = r11;
    u32 _h_38 = r12;
    u32 _h_39 = r13;
    Term _h_40 = r14;
    u32 _h_41 = r15;
    u32 _h_42 = r16;
    u32 _h_43 = r17;
    u32 _h_44 = r18;
    Term _x_4 = r19;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(19));
    e.mem[_nd_8 + 0] = _result_83;
    e.mem[_nd_8 + 1] = _result_84;
    e.mem[_nd_8 + 2] = _result_85;
    e.mem[_nd_8 + 3] = _result_86;
    e.mem[_nd_8 + 4] = _result_87;
    e.mem[_nd_8 + 5] = _result_88;
    e.mem[_nd_8 + 6] = _result_89;
    e.mem[_nd_8 + 7] = _result_90;
    e.mem[_nd_8 + 8] = _result_91;
    e.mem[_nd_8 + 9] = _h_35;
    e.mem[_nd_8 + 10] = _h_36;
    e.mem[_nd_8 + 11] = _h_37;
    e.mem[_nd_8 + 12] = _h_38;
    e.mem[_nd_8 + 13] = _h_39;
    e.mem[_nd_8 + 14] = _h_40;
    e.mem[_nd_8 + 15] = _h_41;
    e.mem[_nd_8 + 16] = _h_42;
    e.mem[_nd_8 + 17] = _h_43;
    e.mem[_nd_8 + 18] = _h_44;
    r0 = term_clo(FID_EXTRACTED_PRINT_C321, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EXTRACTED_PRINT_C321)
  {
    Term _result_92 = r0;
    Term _result_93 = r1;
    Term _result_94 = r2;
    Term _result_95 = r3;
    Term _result_96 = r4;
    Term _result_97 = r5;
    u32 _result_98 = r6;
    Term _result_99 = r7;
    u32 _result_100 = r8;
    u32 _h_45 = r9;
    u32 _h_46 = r10;
    Term _h_47 = r11;
    u32 _h_48 = r12;
    u32 _h_49 = r13;
    Term _h_50 = r14;
    u32 _h_51 = r15;
    u32 _h_52 = r16;
    u32 _h_53 = r17;
    u32 _h_54 = r18;
    Term _x_5 = r19;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_46 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, _h_47);
      e.mem[_nd_9 + 1] = rfc_seal(e, _h_48);
      _o_1 = term_ctr(CID_OWNERS_MOTION, _nd_9);
    }
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_h_49 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_10 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_10 + 0] = rfc_seal(e, _h_50);
      e.mem[_nd_10 + 1] = rfc_seal(e, _h_51);
      _o_3 = term_ctr(CID_OWNERS_HEALTH, _nd_10);
    }
    u32 _o_4 = 0;
    Term _o_5 = 0;
    if (_h_52 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_UNIT, 0);
    }
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _o_6[9];
    if (spin_52(e, _o_6, _result_92, blk_loc(e.mem, _result_92), _result_93, blk_loc(e.mem, _result_93), _result_94, blk_loc(e.mem, _result_94), _result_95, blk_loc(e.mem, _result_95), _result_96, blk_loc(e.mem, _result_96), _result_97, blk_loc(e.mem, _result_97), _result_98, _result_99, _result_100, _h_45, _o_0, _o_1, blk_loc(e.mem, _o_1), _o_2, _o_3, blk_loc(e.mem, _o_3), _o_4, _o_5, blk_loc(e.mem, _o_5), _h_53, _h_54) == 0) {
      return 0;
    }
    _v_9 = _o_6[0];
    _v_10 = _o_6[1];
    _v_11 = _o_6[2];
    _v_12 = _o_6[3];
    _v_13 = _o_6[4];
    _v_14 = _o_6[5];
    _v_15 = _o_6[6];
    _v_16 = _o_6[7];
    _v_17 = _o_6[8];
    _v_0 = _v_9;
    _v_1 = _v_10;
    _v_2 = _v_11;
    _v_3 = _v_12;
    _v_4 = _v_13;
    _v_5 = _v_14;
    _v_6 = _v_15;
    _v_7 = _v_16;
    _v_8 = _v_17;
    u64 _nd_11 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_11 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_11 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_11 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_11 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_11 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_11 + 5] = rfc_seal(e, _v_5);
    e.mem[_nd_11 + 6] = rfc_seal(e, _v_6);
    e.mem[_nd_11 + 7] = rfc_seal(e, _v_7);
    e.mem[_nd_11 + 8] = rfc_seal(e, _v_8);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_8 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_11);
      e.mem[_t_8 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_8);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_11);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _rows_0;
      STK(1) = _rows_1;
      STK(2) = _rows_2;
      STK(3) = _rows_3;
      STK(4) = _rows_4;
      STK(5) = _rows_5;
      STK(6) = _rows_6;
      STK(7) = _rows_7;
      STK(8) = _rows_8;
      STK(9) = FID_ROWS_SHAPE_K323;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID_ROWS_SHAPE_K323, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _rows_0;
      e.mem[_t_0 + 1] = _rows_1;
      e.mem[_t_0 + 2] = _rows_2;
      e.mem[_t_0 + 3] = _rows_3;
      e.mem[_t_0 + 4] = _rows_4;
      e.mem[_t_0 + 5] = _rows_5;
      e.mem[_t_0 + 6] = _rows_6;
      e.mem[_t_0 + 7] = _rows_7;
      e.mem[_t_0 + 8] = _rows_8;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K323, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _rows_6;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _rows_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K323)
  {
    WL_POPN(9);
    Term _rows_9 = STK(0);
    Term _rows_10 = STK(1);
    Term _rows_11 = STK(2);
    Term _rows_12 = STK(3);
    Term _rows_13 = STK(4);
    Term _rows_14 = STK(5);
    u32 _rows_15 = STK(6);
    Term _rows_16 = STK(7);
    u32 _rows_17 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _rows_9;
      STK(1) = _rows_10;
      STK(2) = _rows_11;
      STK(3) = _rows_12;
      STK(4) = _rows_13;
      STK(5) = _rows_14;
      STK(6) = _rows_15;
      STK(7) = _rows_16;
      STK(8) = _rows_17;
      STK(9) = _h_0;
      STK(10) = FID_ROWS_SHAPE_K324;
      WL_PUSHN(11);
    } else {
      u64 _t_2 = task_node(e, FID_ROWS_SHAPE_K324, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _rows_9;
      e.mem[_t_2 + 1] = _rows_10;
      e.mem[_t_2 + 2] = _rows_11;
      e.mem[_t_2 + 3] = _rows_12;
      e.mem[_t_2 + 4] = _rows_13;
      e.mem[_t_2 + 5] = _rows_14;
      e.mem[_t_2 + 6] = _rows_15;
      e.mem[_t_2 + 7] = _rows_16;
      e.mem[_t_2 + 8] = _rows_17;
      e.mem[_t_2 + 9] = _h_0;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K324, _t_2);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_3 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _rows_16;
      return term_tsk(FID_NAT_SHOW, _t_3);
    }
    r0 = _rows_16;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K324)
  {
    WL_POPN(10);
    Term _rows_18 = STK(0);
    Term _rows_19 = STK(1);
    Term _rows_20 = STK(2);
    Term _rows_21 = STK(3);
    Term _rows_22 = STK(4);
    Term _rows_23 = STK(5);
    u32 _rows_24 = STK(6);
    Term _rows_25 = STK(7);
    u32 _rows_26 = STK(8);
    Term _h_2 = STK(9);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_18;
      STK(1) = _rows_19;
      STK(2) = _rows_20;
      STK(3) = _rows_21;
      STK(4) = _rows_22;
      STK(5) = _rows_23;
      STK(6) = _rows_24;
      STK(7) = _rows_25;
      STK(8) = _rows_26;
      STK(9) = _h_2;
      STK(10) = _h_1;
      STK(11) = FID_ROWS_SHAPE_K325;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_ROWS_SHAPE_K325, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _rows_18;
      e.mem[_t_4 + 1] = _rows_19;
      e.mem[_t_4 + 2] = _rows_20;
      e.mem[_t_4 + 3] = _rows_21;
      e.mem[_t_4 + 4] = _rows_22;
      e.mem[_t_4 + 5] = _rows_23;
      e.mem[_t_4 + 6] = _rows_24;
      e.mem[_t_4 + 7] = _rows_25;
      e.mem[_t_4 + 8] = _rows_26;
      e.mem[_t_4 + 9] = _h_2;
      e.mem[_t_4 + 10] = _h_1;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K325, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rows_26;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _rows_26;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K325)
  {
    WL_POPN(11);
    Term _rows_27 = STK(0);
    Term _rows_28 = STK(1);
    Term _rows_29 = STK(2);
    Term _rows_30 = STK(3);
    Term _rows_31 = STK(4);
    Term _rows_32 = STK(5);
    u32 _rows_33 = STK(6);
    Term _rows_34 = STK(7);
    u32 _rows_35 = STK(8);
    Term _h_4 = STK(9);
    Term _h_5 = STK(10);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_27;
      STK(1) = _rows_28;
      STK(2) = _rows_29;
      STK(3) = _rows_30;
      STK(4) = _rows_31;
      STK(5) = _rows_32;
      STK(6) = _rows_33;
      STK(7) = _rows_34;
      STK(8) = _rows_35;
      STK(9) = _h_4;
      STK(10) = _h_5;
      STK(11) = FID_ROWS_SHAPE_K326;
      WL_PUSHN(12);
    } else {
      u64 _t_6 = task_node(e, FID_ROWS_SHAPE_K326, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _rows_27;
      e.mem[_t_6 + 1] = _rows_28;
      e.mem[_t_6 + 2] = _rows_29;
      e.mem[_t_6 + 3] = _rows_30;
      e.mem[_t_6 + 4] = _rows_31;
      e.mem[_t_6 + 5] = _rows_32;
      e.mem[_t_6 + 6] = _rows_33;
      e.mem[_t_6 + 7] = _rows_34;
      e.mem[_t_6 + 8] = _rows_35;
      e.mem[_t_6 + 9] = _h_4;
      e.mem[_t_6 + 10] = _h_5;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K326, _t_6);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 28);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K326)
  {
    WL_POPN(11);
    Term _rows_36 = STK(0);
    Term _rows_37 = STK(1);
    Term _rows_38 = STK(2);
    Term _rows_39 = STK(3);
    Term _rows_40 = STK(4);
    Term _rows_41 = STK(5);
    u32 _rows_42 = STK(6);
    Term _rows_43 = STK(7);
    u32 _rows_44 = STK(8);
    Term _h_7 = STK(9);
    Term _h_8 = STK(10);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _rows_36;
      STK(1) = _rows_37;
      STK(2) = _rows_38;
      STK(3) = _rows_39;
      STK(4) = _rows_40;
      STK(5) = _rows_41;
      STK(6) = _rows_42;
      STK(7) = _rows_43;
      STK(8) = _rows_44;
      STK(9) = _h_7;
      STK(10) = FID_ROWS_SHAPE_K327;
      WL_PUSHN(11);
    } else {
      u64 _t_8 = task_node(e, FID_ROWS_SHAPE_K327, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _rows_36;
      e.mem[_t_8 + 1] = _rows_37;
      e.mem[_t_8 + 2] = _rows_38;
      e.mem[_t_8 + 3] = _rows_39;
      e.mem[_t_8 + 4] = _rows_40;
      e.mem[_t_8 + 5] = _rows_41;
      e.mem[_t_8 + 6] = _rows_42;
      e.mem[_t_8 + 7] = _rows_43;
      e.mem[_t_8 + 8] = _rows_44;
      e.mem[_t_8 + 9] = _h_7;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K327, _t_8);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K327)
  {
    WL_POPN(10);
    Term _rows_45 = STK(0);
    Term _rows_46 = STK(1);
    Term _rows_47 = STK(2);
    Term _rows_48 = STK(3);
    Term _rows_49 = STK(4);
    Term _rows_50 = STK(5);
    u32 _rows_51 = STK(6);
    Term _rows_52 = STK(7);
    u32 _rows_53 = STK(8);
    Term _h_10 = STK(9);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _rows_45;
      STK(1) = _rows_46;
      STK(2) = _rows_47;
      STK(3) = _rows_48;
      STK(4) = _rows_49;
      STK(5) = _rows_50;
      STK(6) = _rows_51;
      STK(7) = _rows_52;
      STK(8) = _rows_53;
      STK(9) = _h_10;
      STK(10) = FID_ROWS_SHAPE_K328;
      WL_PUSHN(11);
    } else {
      u64 _t_10 = task_node(e, FID_ROWS_SHAPE_K328, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _rows_45;
      e.mem[_t_10 + 1] = _rows_46;
      e.mem[_t_10 + 2] = _rows_47;
      e.mem[_t_10 + 3] = _rows_48;
      e.mem[_t_10 + 4] = _rows_49;
      e.mem[_t_10 + 5] = _rows_50;
      e.mem[_t_10 + 6] = _rows_51;
      e.mem[_t_10 + 7] = _rows_52;
      e.mem[_t_10 + 8] = _rows_53;
      e.mem[_t_10 + 9] = _h_10;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K328, _t_10);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 28);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K328)
  {
    WL_POPN(10);
    Term _rows_54 = STK(0);
    Term _rows_55 = STK(1);
    Term _rows_56 = STK(2);
    Term _rows_57 = STK(3);
    Term _rows_58 = STK(4);
    Term _rows_59 = STK(5);
    u32 _rows_60 = STK(6);
    Term _rows_61 = STK(7);
    u32 _rows_62 = STK(8);
    Term _h_12 = STK(9);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _rows_54;
      STK(1) = _rows_55;
      STK(2) = _rows_56;
      STK(3) = _rows_57;
      STK(4) = _rows_58;
      STK(5) = _rows_59;
      STK(6) = _rows_60;
      STK(7) = _rows_61;
      STK(8) = _rows_62;
      STK(9) = FID_ROWS_SHAPE_K329;
      WL_PUSHN(10);
    } else {
      u64 _t_12 = task_node(e, FID_ROWS_SHAPE_K329, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _rows_54;
      e.mem[_t_12 + 1] = _rows_55;
      e.mem[_t_12 + 2] = _rows_56;
      e.mem[_t_12 + 3] = _rows_57;
      e.mem[_t_12 + 4] = _rows_58;
      e.mem[_t_12 + 5] = _rows_59;
      e.mem[_t_12 + 6] = _rows_60;
      e.mem[_t_12 + 7] = _rows_61;
      e.mem[_t_12 + 8] = _rows_62;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K329, _t_12);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_12;
      e.mem[_t_13 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K329)
  {
    WL_POPN(9);
    Term _rows_63 = STK(0);
    Term _rows_64 = STK(1);
    Term _rows_65 = STK(2);
    Term _rows_66 = STK(3);
    Term _rows_67 = STK(4);
    Term _rows_68 = STK(5);
    u32 _rows_69 = STK(6);
    Term _rows_70 = STK(7);
    u32 _rows_71 = STK(8);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _rows_63;
      STK(1) = _rows_64;
      STK(2) = _rows_65;
      STK(3) = _rows_66;
      STK(4) = _rows_67;
      STK(5) = _rows_68;
      STK(6) = _rows_69;
      STK(7) = _rows_70;
      STK(8) = _rows_71;
      STK(9) = FID_ROWS_SHAPE_K330;
      WL_PUSHN(10);
    } else {
      u64 _t_14 = task_node(e, FID_ROWS_SHAPE_K330, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _rows_63;
      e.mem[_t_14 + 1] = _rows_64;
      e.mem[_t_14 + 2] = _rows_65;
      e.mem[_t_14 + 3] = _rows_66;
      e.mem[_t_14 + 4] = _rows_67;
      e.mem[_t_14 + 5] = _rows_68;
      e.mem[_t_14 + 6] = _rows_69;
      e.mem[_t_14 + 7] = _rows_70;
      e.mem[_t_14 + 8] = _rows_71;
      WL_CONT = term_tsk(FID_ROWS_SHAPE_K330, _t_14);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 80);
      e.mem[_t_15 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 80);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_K330)
  {
    WL_POPN(9);
    Term _rows_72 = STK(0);
    Term _rows_73 = STK(1);
    Term _rows_74 = STK(2);
    Term _rows_75 = STK(3);
    Term _rows_76 = STK(4);
    Term _rows_77 = STK(5);
    u32 _rows_78 = STK(6);
    Term _rows_79 = STK(7);
    u32 _rows_80 = STK(8);
    Term _h_14 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _rows_72;
    e.mem[_nd_0 + 1] = _rows_73;
    e.mem[_nd_0 + 2] = _rows_74;
    e.mem[_nd_0 + 3] = _rows_75;
    e.mem[_nd_0 + 4] = _rows_76;
    e.mem[_nd_0 + 5] = _rows_77;
    e.mem[_nd_0 + 6] = _rows_78;
    e.mem[_nd_0 + 7] = _rows_79;
    e.mem[_nd_0 + 8] = _rows_80;
    e.mem[_nd_0 + 9] = _h_14;
    r0 = term_clo(FID_ROWS_SHAPE_C331, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_C331)
  {
    Term _rows_81 = r0;
    Term _rows_82 = r1;
    Term _rows_83 = r2;
    Term _rows_84 = r3;
    Term _rows_85 = r4;
    Term _rows_86 = r5;
    u32 _rows_87 = r6;
    Term _rows_88 = r7;
    u32 _rows_89 = r8;
    Term _h_15 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_15;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _rows_81;
    e.mem[_nd_2 + 1] = _rows_82;
    e.mem[_nd_2 + 2] = _rows_83;
    e.mem[_nd_2 + 3] = _rows_84;
    e.mem[_nd_2 + 4] = _rows_85;
    e.mem[_nd_2 + 5] = _rows_86;
    e.mem[_nd_2 + 6] = _rows_87;
    e.mem[_nd_2 + 7] = _rows_88;
    e.mem[_nd_2 + 8] = _rows_89;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_17 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_17 + 1] = term_clo(FID_ROWS_SHAPE_C332, _nd_2);
      e.mem[_t_17 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_17);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_ROWS_SHAPE_C332, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_C332)
  {
    Term _rows_90 = r0;
    Term _rows_91 = r1;
    Term _rows_92 = r2;
    Term _rows_93 = r3;
    Term _rows_94 = r4;
    Term _rows_95 = r5;
    u32 _rows_96 = r6;
    Term _rows_97 = r7;
    u32 _rows_98 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _rows_90;
    e.mem[_nd_3 + 1] = _rows_91;
    e.mem[_nd_3 + 2] = _rows_92;
    e.mem[_nd_3 + 3] = _rows_93;
    e.mem[_nd_3 + 4] = _rows_94;
    e.mem[_nd_3 + 5] = _rows_95;
    e.mem[_nd_3 + 6] = _rows_96;
    e.mem[_nd_3 + 7] = _rows_97;
    e.mem[_nd_3 + 8] = _rows_98;
    r0 = term_clo(FID_ROWS_SHAPE_C333, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROWS_SHAPE_C333)
  {
    Term _rows_99 = r0;
    Term _rows_100 = r1;
    Term _rows_101 = r2;
    Term _rows_102 = r3;
    Term _rows_103 = r4;
    Term _rows_104 = r5;
    u32 _rows_105 = r6;
    Term _rows_106 = r7;
    u32 _rows_107 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _rows_99);
    e.mem[_nd_4 + 1] = rfc_seal(e, _rows_100);
    e.mem[_nd_4 + 2] = rfc_seal(e, _rows_101);
    e.mem[_nd_4 + 3] = rfc_seal(e, _rows_102);
    e.mem[_nd_4 + 4] = rfc_seal(e, _rows_103);
    e.mem[_nd_4 + 5] = rfc_seal(e, _rows_104);
    e.mem[_nd_4 + 6] = rfc_seal(e, _rows_105);
    e.mem[_nd_4 + 7] = rfc_seal(e, _rows_106);
    e.mem[_nd_4 + 8] = rfc_seal(e, _rows_107);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_16 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_16 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_16);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDENTITY_RENDER)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    Term _result_2 = r2;
    Term _result_3 = r3;
    Term _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    u32 _result_8 = r8;
    Term _result_9 = r9;
    u32 _result_10 = r10;
    Term _result_11 = r11;
    u32 _result_12 = r12;
    Term _result_13 = r13;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IDENTITY_VALUES)) {
      u64 _t_0 = task_node(e, FID_IDENTITY_VALUES, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _result_13;
      e.mem[_t_0 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_0 + 2] = _result_0;
      e.mem[_t_0 + 3] = _result_1;
      e.mem[_t_0 + 4] = _result_2;
      e.mem[_t_0 + 5] = _result_3;
      e.mem[_t_0 + 6] = _result_4;
      e.mem[_t_0 + 7] = _result_5;
      e.mem[_t_0 + 8] = _result_6;
      e.mem[_t_0 + 9] = _result_7;
      e.mem[_t_0 + 10] = _result_8;
      e.mem[_t_0 + 11] = _result_9;
      e.mem[_t_0 + 12] = _result_10;
      e.mem[_t_0 + 13] = _result_11;
      e.mem[_t_0 + 14] = _result_12;
      e.mem[_t_0 + 15] = 0;
      e.mem[_t_0 + 16] = 0;
      return term_tsk(FID_IDENTITY_VALUES, _t_0);
    }
    r0 = _result_13;
    r1 = term_pak(CID_NIL, 0);
    r2 = _result_0;
    r3 = _result_1;
    r4 = _result_2;
    r5 = _result_3;
    r6 = _result_4;
    r7 = _result_5;
    r8 = _result_6;
    r9 = _result_7;
    r10 = _result_8;
    r11 = _result_9;
    r12 = _result_10;
    r13 = _result_11;
    r14 = _result_12;
    r15 = 0;
    r16 = 0;
    WL_JMP(FID_IDENTITY_VALUES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 70);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K349;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K349, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K349, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K349)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PURE)
  {
    Term _x_0 = r0;
    Term _k_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _k_0;
      e.mem[_t_0 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_0);
    }
    r0 = _k_0;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP)
  {
    Term _prefix_0 = r0;
    u32 _selection_0 = r1;
    u32 _world_0 = r2;
    u32 _world_1 = r3;
    Term _world_2 = r4;
    Term _world_3 = r5;
    Term _world_4 = r6;
    Term _world_5 = r7;
    Term _world_6 = r8;
    Term _world_7 = r9;
    u32 _world_8 = r10;
    Term _world_9 = r11;
    u32 _world_10 = r12;
    Term _world_11 = r13;
    u32 _world_12 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _prefix_0;
      STK(1) = FID_LOOKUP_K353;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_LOOKUP_K353, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _prefix_0;
      WL_CONT = term_tsk(FID_LOOKUP_K353, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUERY_LOOKUP_0)) {
      u64 _t_1 = task_node(e, FID_QUERY_LOOKUP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _selection_0;
      e.mem[_t_1 + 1] = _world_0;
      e.mem[_t_1 + 2] = _world_1;
      e.mem[_t_1 + 3] = _world_2;
      e.mem[_t_1 + 4] = _world_3;
      e.mem[_t_1 + 5] = _world_4;
      e.mem[_t_1 + 6] = _world_5;
      e.mem[_t_1 + 7] = _world_6;
      e.mem[_t_1 + 8] = _world_7;
      e.mem[_t_1 + 9] = _world_8;
      e.mem[_t_1 + 10] = _world_9;
      e.mem[_t_1 + 11] = _world_10;
      e.mem[_t_1 + 12] = _world_11;
      e.mem[_t_1 + 13] = _world_12;
      e.mem[_t_1 + 14] = _handle_0;
      e.mem[_t_1 + 15] = _handle_1;
      return term_tsk(FID_QUERY_LOOKUP_0, _t_1);
    }
    r0 = _selection_0;
    r1 = _world_0;
    r2 = _world_1;
    r3 = _world_2;
    r4 = _world_3;
    r5 = _world_4;
    r6 = _world_5;
    r7 = _world_6;
    r8 = _world_7;
    r9 = _world_8;
    r10 = _world_9;
    r11 = _world_10;
    r12 = _world_11;
    r13 = _world_12;
    r14 = _handle_0;
    r15 = _handle_1;
    WL_JMP(FID_QUERY_LOOKUP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_K353)
  {
    WL_POPN(1);
    Term _prefix_1 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_88(e, _o_0, _h_13, _h_14, blk_loc(e.mem, _h_14)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = _h_3;
      STK(4) = _h_4;
      STK(5) = _h_5;
      STK(6) = _h_6;
      STK(7) = _h_7;
      STK(8) = _h_8;
      STK(9) = _h_9;
      STK(10) = _h_10;
      STK(11) = _h_11;
      STK(12) = _h_12;
      STK(13) = FID_LOOKUP_K354;
      WL_PUSHN(14);
    } else {
      u64 _t_2 = task_node(e, FID_LOOKUP_K354, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      e.mem[_t_2 + 3] = _h_3;
      e.mem[_t_2 + 4] = _h_4;
      e.mem[_t_2 + 5] = _h_5;
      e.mem[_t_2 + 6] = _h_6;
      e.mem[_t_2 + 7] = _h_7;
      e.mem[_t_2 + 8] = _h_8;
      e.mem[_t_2 + 9] = _h_9;
      e.mem[_t_2 + 10] = _h_10;
      e.mem[_t_2 + 11] = _h_11;
      e.mem[_t_2 + 12] = _h_12;
      WL_CONT = term_tsk(FID_LOOKUP_K354, _t_2);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _prefix_1;
      e.mem[_t_3 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _prefix_1;
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_K354)
  {
    WL_POPN(13);
    u32 _h_16 = STK(0);
    u32 _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_19 = STK(3);
    Term _h_20 = STK(4);
    Term _h_21 = STK(5);
    Term _h_22 = STK(6);
    Term _h_23 = STK(7);
    u32 _h_24 = STK(8);
    Term _h_25 = STK(9);
    u32 _h_26 = STK(10);
    Term _h_27 = STK(11);
    u32 _h_28 = STK(12);
    Term _h_15 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_0 + 0] = _h_16;
    e.mem[_nd_0 + 1] = _h_17;
    e.mem[_nd_0 + 2] = _h_18;
    e.mem[_nd_0 + 3] = _h_19;
    e.mem[_nd_0 + 4] = _h_20;
    e.mem[_nd_0 + 5] = _h_21;
    e.mem[_nd_0 + 6] = _h_22;
    e.mem[_nd_0 + 7] = _h_23;
    e.mem[_nd_0 + 8] = _h_24;
    e.mem[_nd_0 + 9] = _h_25;
    e.mem[_nd_0 + 10] = _h_26;
    e.mem[_nd_0 + 11] = _h_27;
    e.mem[_nd_0 + 12] = _h_28;
    e.mem[_nd_0 + 13] = _h_15;
    r0 = term_clo(FID_LOOKUP_C355, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_C355)
  {
    u32 _h_29 = r0;
    u32 _h_30 = r1;
    Term _h_31 = r2;
    Term _h_32 = r3;
    Term _h_33 = r4;
    Term _h_34 = r5;
    Term _h_35 = r6;
    Term _h_36 = r7;
    u32 _h_37 = r8;
    Term _h_38 = r9;
    u32 _h_39 = r10;
    Term _h_40 = r11;
    u32 _h_41 = r12;
    Term _h_42 = r13;
    Term _x_0 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_42;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _h_29;
    e.mem[_nd_2 + 1] = _h_30;
    e.mem[_nd_2 + 2] = _h_31;
    e.mem[_nd_2 + 3] = _h_32;
    e.mem[_nd_2 + 4] = _h_33;
    e.mem[_nd_2 + 5] = _h_34;
    e.mem[_nd_2 + 6] = _h_35;
    e.mem[_nd_2 + 7] = _h_36;
    e.mem[_nd_2 + 8] = _h_37;
    e.mem[_nd_2 + 9] = _h_38;
    e.mem[_nd_2 + 10] = _h_39;
    e.mem[_nd_2 + 11] = _h_40;
    e.mem[_nd_2 + 12] = _h_41;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_5 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_5 + 1] = term_clo(FID_LOOKUP_C356, _nd_2);
      e.mem[_t_5 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_5);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_LOOKUP_C356, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_C356)
  {
    u32 _h_43 = r0;
    u32 _h_44 = r1;
    Term _h_45 = r2;
    Term _h_46 = r3;
    Term _h_47 = r4;
    Term _h_48 = r5;
    Term _h_49 = r6;
    Term _h_50 = r7;
    u32 _h_51 = r8;
    Term _h_52 = r9;
    u32 _h_53 = r10;
    Term _h_54 = r11;
    u32 _h_55 = r12;
    Term _x_1 = r13;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_3 + 0] = _h_43;
    e.mem[_nd_3 + 1] = _h_44;
    e.mem[_nd_3 + 2] = _h_45;
    e.mem[_nd_3 + 3] = _h_46;
    e.mem[_nd_3 + 4] = _h_47;
    e.mem[_nd_3 + 5] = _h_48;
    e.mem[_nd_3 + 6] = _h_49;
    e.mem[_nd_3 + 7] = _h_50;
    e.mem[_nd_3 + 8] = _h_51;
    e.mem[_nd_3 + 9] = _h_52;
    e.mem[_nd_3 + 10] = _h_53;
    e.mem[_nd_3 + 11] = _h_54;
    e.mem[_nd_3 + 12] = _h_55;
    r0 = term_clo(FID_LOOKUP_C357, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_C357)
  {
    u32 _h_56 = r0;
    u32 _h_57 = r1;
    Term _h_58 = r2;
    Term _h_59 = r3;
    Term _h_60 = r4;
    Term _h_61 = r5;
    Term _h_62 = r6;
    Term _h_63 = r7;
    u32 _h_64 = r8;
    Term _h_65 = r9;
    u32 _h_66 = r10;
    Term _h_67 = r11;
    u32 _h_68 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_h_68 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      _o_2 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_56);
    e.mem[_nd_4 + 1] = rfc_seal(e, _h_57);
    e.mem[_nd_4 + 2] = rfc_seal(e, _h_58);
    e.mem[_nd_4 + 3] = rfc_seal(e, _h_59);
    e.mem[_nd_4 + 4] = rfc_seal(e, _h_60);
    e.mem[_nd_4 + 5] = rfc_seal(e, _h_61);
    e.mem[_nd_4 + 6] = rfc_seal(e, _h_62);
    e.mem[_nd_4 + 7] = rfc_seal(e, _h_63);
    e.mem[_nd_4 + 8] = rfc_seal(e, _h_64);
    e.mem[_nd_4 + 9] = rfc_seal(e, _h_65);
    e.mem[_nd_4 + 10] = rfc_seal(e, _h_66);
    e.mem[_nd_4 + 11] = rfc_seal(e, _h_67);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_1);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_2);
    e.mem[_nd_4 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_4 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_4);
      e.mem[_t_4 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_4);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_COMMANDS_DESPAWN_K361;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_COMMANDS_DESPAWN_K361, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_COMMANDS_DESPAWN_K361, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_1 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_pak(CID_UNIT, 0);
      e.mem[_t_1 + 18] = term_clo(FID_COMMANDS_DESPAWN_C359, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_pak(CID_UNIT, 0);
    r18 = term_clo(FID_COMMANDS_DESPAWN_C359, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN_C359)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_DESPAWN_C360, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN_C360)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_107(e, _o_0, _x_2) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN_K361)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    u32 _r_9 = r9;
    Term _r_10 = r10;
    u32 _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    Term _r_14 = r14;
    Term _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    Term _o_11 = 0;
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    if (_r_0 == 0) {
      _o_1 = 0;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    } else {
      _o_1 = 1;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    r14 = _o_15;
    r15 = _o_16;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _main_0 = r17;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_0 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _handle_0;
      e.mem[_t_0 + 16] = _handle_1;
      e.mem[_t_0 + 17] = _main_0;
      e.mem[_t_0 + 18] = term_clo(FID_COMMANDS_INSERT_MAIN_C363, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_0);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = _main_0;
    r18 = term_clo(FID_COMMANDS_INSERT_MAIN_C363, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_C363)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_INSERT_MAIN_C364, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_C364)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_108(e, _o_0, _x_2, _x_1, blk_loc(e.mem, _x_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_COMMANDS_REMOVE_FLAG_K368;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_COMMANDS_REMOVE_FLAG_K368, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_COMMANDS_REMOVE_FLAG_K368, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_1 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_pak(CID_UNIT, 0);
      e.mem[_t_1 + 18] = term_clo(FID_COMMANDS_REMOVE_FLAG_C366, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_pak(CID_UNIT, 0);
    r18 = term_clo(FID_COMMANDS_REMOVE_FLAG_C366, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG_C366)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_REMOVE_FLAG_C367, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG_C367)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_109(e, _o_0, _x_2) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG_K368)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    u32 _r_9 = r9;
    Term _r_10 = r10;
    u32 _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    Term _r_14 = r14;
    Term _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    Term _o_11 = 0;
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    if (_r_0 == 0) {
      _o_1 = 0;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    } else {
      _o_1 = 1;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    r14 = _o_15;
    r15 = _o_16;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_FLAG)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _flag_0 = r17;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_0 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _handle_0;
      e.mem[_t_0 + 16] = _handle_1;
      e.mem[_t_0 + 17] = _flag_0;
      e.mem[_t_0 + 18] = term_clo(FID_COMMANDS_INSERT_FLAG_C370, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_0);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = _flag_0;
    r18 = term_clo(FID_COMMANDS_INSERT_FLAG_C370, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_FLAG_C370)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_INSERT_FLAG_C371, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_FLAG_C371)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_110(e, _o_0, _x_2, _x_1, blk_loc(e.mem, _x_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED)
  {
    Term _prefix_0 = r0;
    u32 _result_0 = r1;
    u32 _result_1 = r2;
    u32 _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    Term _result_6 = r7;
    Term _result_7 = r8;
    Term _result_8 = r9;
    u32 _result_9 = r10;
    Term _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    Term _result_14 = r15;
    WL_OPEN
    if (_result_0 == 0) {
      if (seq) {
        WL_ROOM(14);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = FID_QUEUED_K373;
        WL_PUSHN(14);
      } else {
        u64 _t_0 = task_node(e, FID_QUEUED_K373, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_1;
        e.mem[_t_0 + 1] = _result_2;
        e.mem[_t_0 + 2] = _result_3;
        e.mem[_t_0 + 3] = _result_4;
        e.mem[_t_0 + 4] = _result_5;
        e.mem[_t_0 + 5] = _result_6;
        e.mem[_t_0 + 6] = _result_7;
        e.mem[_t_0 + 7] = _result_8;
        e.mem[_t_0 + 8] = _result_9;
        e.mem[_t_0 + 9] = _result_10;
        e.mem[_t_0 + 10] = _result_11;
        e.mem[_t_0 + 11] = _result_12;
        e.mem[_t_0 + 12] = _result_13;
        WL_CONT = term_tsk(FID_QUEUED_K373, _t_0);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _prefix_0;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 90);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 90);
      WL_JMP(FID_STRING_APPEND);
    } else {
      term_sink(e, _result_14);
      if (seq) {
        WL_ROOM(14);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = FID_QUEUED_K377;
        WL_PUSHN(14);
      } else {
        u64 _t_4 = task_node(e, FID_QUEUED_K377, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _result_1;
        e.mem[_t_4 + 1] = _result_2;
        e.mem[_t_4 + 2] = _result_3;
        e.mem[_t_4 + 3] = _result_4;
        e.mem[_t_4 + 4] = _result_5;
        e.mem[_t_4 + 5] = _result_6;
        e.mem[_t_4 + 6] = _result_7;
        e.mem[_t_4 + 7] = _result_8;
        e.mem[_t_4 + 8] = _result_9;
        e.mem[_t_4 + 9] = _result_10;
        e.mem[_t_4 + 10] = _result_11;
        e.mem[_t_4 + 11] = _result_12;
        e.mem[_t_4 + 12] = _result_13;
        WL_CONT = term_tsk(FID_QUEUED_K377, _t_4);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _prefix_0;
        e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 44);
        return term_tsk(FID_STRING_APPEND, _t_5);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 44);
      WL_JMP(FID_STRING_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_K373)
  {
    WL_POPN(13);
    u32 _result_15 = STK(0);
    u32 _result_16 = STK(1);
    Term _result_17 = STK(2);
    Term _result_18 = STK(3);
    Term _result_19 = STK(4);
    Term _result_20 = STK(5);
    Term _result_21 = STK(6);
    Term _result_22 = STK(7);
    u32 _result_23 = STK(8);
    Term _result_24 = STK(9);
    u32 _result_25 = STK(10);
    Term _result_26 = STK(11);
    u32 _result_27 = STK(12);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_0 + 0] = _result_15;
    e.mem[_nd_0 + 1] = _result_16;
    e.mem[_nd_0 + 2] = _result_17;
    e.mem[_nd_0 + 3] = _result_18;
    e.mem[_nd_0 + 4] = _result_19;
    e.mem[_nd_0 + 5] = _result_20;
    e.mem[_nd_0 + 6] = _result_21;
    e.mem[_nd_0 + 7] = _result_22;
    e.mem[_nd_0 + 8] = _result_23;
    e.mem[_nd_0 + 9] = _result_24;
    e.mem[_nd_0 + 10] = _result_25;
    e.mem[_nd_0 + 11] = _result_26;
    e.mem[_nd_0 + 12] = _result_27;
    e.mem[_nd_0 + 13] = _h_0;
    r0 = term_clo(FID_QUEUED_C374, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_C374)
  {
    u32 _result_28 = r0;
    u32 _result_29 = r1;
    Term _result_30 = r2;
    Term _result_31 = r3;
    Term _result_32 = r4;
    Term _result_33 = r5;
    Term _result_34 = r6;
    Term _result_35 = r7;
    u32 _result_36 = r8;
    Term _result_37 = r9;
    u32 _result_38 = r10;
    Term _result_39 = r11;
    u32 _result_40 = r12;
    Term _h_1 = r13;
    Term _x_0 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _result_28;
    e.mem[_nd_2 + 1] = _result_29;
    e.mem[_nd_2 + 2] = _result_30;
    e.mem[_nd_2 + 3] = _result_31;
    e.mem[_nd_2 + 4] = _result_32;
    e.mem[_nd_2 + 5] = _result_33;
    e.mem[_nd_2 + 6] = _result_34;
    e.mem[_nd_2 + 7] = _result_35;
    e.mem[_nd_2 + 8] = _result_36;
    e.mem[_nd_2 + 9] = _result_37;
    e.mem[_nd_2 + 10] = _result_38;
    e.mem[_nd_2 + 11] = _result_39;
    e.mem[_nd_2 + 12] = _result_40;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_QUEUED_C375, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_QUEUED_C375, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_C375)
  {
    u32 _result_41 = r0;
    u32 _result_42 = r1;
    Term _result_43 = r2;
    Term _result_44 = r3;
    Term _result_45 = r4;
    Term _result_46 = r5;
    Term _result_47 = r6;
    Term _result_48 = r7;
    u32 _result_49 = r8;
    Term _result_50 = r9;
    u32 _result_51 = r10;
    Term _result_52 = r11;
    u32 _result_53 = r12;
    Term _x_1 = r13;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_3 + 0] = _result_41;
    e.mem[_nd_3 + 1] = _result_42;
    e.mem[_nd_3 + 2] = _result_43;
    e.mem[_nd_3 + 3] = _result_44;
    e.mem[_nd_3 + 4] = _result_45;
    e.mem[_nd_3 + 5] = _result_46;
    e.mem[_nd_3 + 6] = _result_47;
    e.mem[_nd_3 + 7] = _result_48;
    e.mem[_nd_3 + 8] = _result_49;
    e.mem[_nd_3 + 9] = _result_50;
    e.mem[_nd_3 + 10] = _result_51;
    e.mem[_nd_3 + 11] = _result_52;
    e.mem[_nd_3 + 12] = _result_53;
    r0 = term_clo(FID_QUEUED_C376, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_C376)
  {
    u32 _result_54 = r0;
    u32 _result_55 = r1;
    Term _result_56 = r2;
    Term _result_57 = r3;
    Term _result_58 = r4;
    Term _result_59 = r5;
    Term _result_60 = r6;
    Term _result_61 = r7;
    u32 _result_62 = r8;
    Term _result_63 = r9;
    u32 _result_64 = r10;
    Term _result_65 = r11;
    u32 _result_66 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_result_66 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_54);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_55);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_56);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_57);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_58);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_59);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_60);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_61);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_62);
    e.mem[_nd_4 + 9] = rfc_seal(e, _result_63);
    e.mem[_nd_4 + 10] = rfc_seal(e, _result_64);
    e.mem[_nd_4 + 11] = rfc_seal(e, _result_65);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_4 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_K377)
  {
    WL_POPN(13);
    u32 _result_67 = STK(0);
    u32 _result_68 = STK(1);
    Term _result_69 = STK(2);
    Term _result_70 = STK(3);
    Term _result_71 = STK(4);
    Term _result_72 = STK(5);
    Term _result_73 = STK(6);
    Term _result_74 = STK(7);
    u32 _result_75 = STK(8);
    Term _result_76 = STK(9);
    u32 _result_77 = STK(10);
    Term _result_78 = STK(11);
    u32 _result_79 = STK(12);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_5 + 0] = _result_67;
    e.mem[_nd_5 + 1] = _result_68;
    e.mem[_nd_5 + 2] = _result_69;
    e.mem[_nd_5 + 3] = _result_70;
    e.mem[_nd_5 + 4] = _result_71;
    e.mem[_nd_5 + 5] = _result_72;
    e.mem[_nd_5 + 6] = _result_73;
    e.mem[_nd_5 + 7] = _result_74;
    e.mem[_nd_5 + 8] = _result_75;
    e.mem[_nd_5 + 9] = _result_76;
    e.mem[_nd_5 + 10] = _result_77;
    e.mem[_nd_5 + 11] = _result_78;
    e.mem[_nd_5 + 12] = _result_79;
    e.mem[_nd_5 + 13] = _h_2;
    r0 = term_clo(FID_QUEUED_C378, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_C378)
  {
    u32 _result_80 = r0;
    u32 _result_81 = r1;
    Term _result_82 = r2;
    Term _result_83 = r3;
    Term _result_84 = r4;
    Term _result_85 = r5;
    Term _result_86 = r6;
    Term _result_87 = r7;
    u32 _result_88 = r8;
    Term _result_89 = r9;
    u32 _result_90 = r10;
    Term _result_91 = r11;
    u32 _result_92 = r12;
    Term _h_3 = r13;
    Term _x_3 = r14;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_3;
    u64 _nd_7 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_7 + 0] = _result_80;
    e.mem[_nd_7 + 1] = _result_81;
    e.mem[_nd_7 + 2] = _result_82;
    e.mem[_nd_7 + 3] = _result_83;
    e.mem[_nd_7 + 4] = _result_84;
    e.mem[_nd_7 + 5] = _result_85;
    e.mem[_nd_7 + 6] = _result_86;
    e.mem[_nd_7 + 7] = _result_87;
    e.mem[_nd_7 + 8] = _result_88;
    e.mem[_nd_7 + 9] = _result_89;
    e.mem[_nd_7 + 10] = _result_90;
    e.mem[_nd_7 + 11] = _result_91;
    e.mem[_nd_7 + 12] = _result_92;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_7 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_7 + 1] = term_clo(FID_QUEUED_C379, _nd_7);
      e.mem[_t_7 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_7);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_QUEUED_C379, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_C379)
  {
    u32 _result_93 = r0;
    u32 _result_94 = r1;
    Term _result_95 = r2;
    Term _result_96 = r3;
    Term _result_97 = r4;
    Term _result_98 = r5;
    Term _result_99 = r6;
    Term _result_100 = r7;
    u32 _result_101 = r8;
    Term _result_102 = r9;
    u32 _result_103 = r10;
    Term _result_104 = r11;
    u32 _result_105 = r12;
    Term _x_4 = r13;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_8 + 0] = _result_93;
    e.mem[_nd_8 + 1] = _result_94;
    e.mem[_nd_8 + 2] = _result_95;
    e.mem[_nd_8 + 3] = _result_96;
    e.mem[_nd_8 + 4] = _result_97;
    e.mem[_nd_8 + 5] = _result_98;
    e.mem[_nd_8 + 6] = _result_99;
    e.mem[_nd_8 + 7] = _result_100;
    e.mem[_nd_8 + 8] = _result_101;
    e.mem[_nd_8 + 9] = _result_102;
    e.mem[_nd_8 + 10] = _result_103;
    e.mem[_nd_8 + 11] = _result_104;
    e.mem[_nd_8 + 12] = _result_105;
    r0 = term_clo(FID_QUEUED_C380, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_C380)
  {
    u32 _result_106 = r0;
    u32 _result_107 = r1;
    Term _result_108 = r2;
    Term _result_109 = r3;
    Term _result_110 = r4;
    Term _result_111 = r5;
    Term _result_112 = r6;
    Term _result_113 = r7;
    u32 _result_114 = r8;
    Term _result_115 = r9;
    u32 _result_116 = r10;
    Term _result_117 = r11;
    u32 _result_118 = r12;
    Term _x_5 = r13;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_result_118 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      _o_3 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_9 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_9 + 0] = rfc_seal(e, _result_106);
    e.mem[_nd_9 + 1] = rfc_seal(e, _result_107);
    e.mem[_nd_9 + 2] = rfc_seal(e, _result_108);
    e.mem[_nd_9 + 3] = rfc_seal(e, _result_109);
    e.mem[_nd_9 + 4] = rfc_seal(e, _result_110);
    e.mem[_nd_9 + 5] = rfc_seal(e, _result_111);
    e.mem[_nd_9 + 6] = rfc_seal(e, _result_112);
    e.mem[_nd_9 + 7] = rfc_seal(e, _result_113);
    e.mem[_nd_9 + 8] = rfc_seal(e, _result_114);
    e.mem[_nd_9 + 9] = rfc_seal(e, _result_115);
    e.mem[_nd_9 + 10] = rfc_seal(e, _result_116);
    e.mem[_nd_9 + 11] = rfc_seal(e, _result_117);
    e.mem[_nd_9 + 12] = rfc_seal(e, _o_2);
    e.mem[_nd_9 + 13] = rfc_seal(e, _o_3);
    e.mem[_nd_9 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_6 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_9);
      e.mem[_t_6 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_6);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_9);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT)
  {
    Term _prefix_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    Term _world_2 = r3;
    Term _world_3 = r4;
    Term _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    u32 _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    Term _world_11 = r12;
    u32 _world_12 = r13;
    u32 _id_0 = r14;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_0[19];
    if (spin_63(e, _o_0, _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _id_0) == 0) {
      return 0;
    }
    _v_19 = _o_0[0];
    _v_20 = _o_0[1];
    _v_21 = _o_0[2];
    _v_22 = _o_0[3];
    _v_23 = _o_0[4];
    _v_24 = _o_0[5];
    _v_25 = _o_0[6];
    _v_26 = _o_0[7];
    _v_27 = _o_0[8];
    _v_28 = _o_0[9];
    _v_29 = _o_0[10];
    _v_30 = _o_0[11];
    _v_31 = _o_0[12];
    _v_32 = _o_0[13];
    _v_33 = _o_0[14];
    _v_34 = _o_0[15];
    _v_35 = _o_0[16];
    _v_36 = _o_0[17];
    _v_37 = _o_0[18];
    _v_0 = _v_19;
    _v_1 = _v_20;
    _v_2 = _v_21;
    _v_3 = _v_22;
    _v_4 = _v_23;
    _v_5 = _v_24;
    _v_6 = _v_25;
    _v_7 = _v_26;
    _v_8 = _v_27;
    _v_9 = _v_28;
    _v_10 = _v_29;
    _v_11 = _v_30;
    _v_12 = _v_31;
    _v_13 = _v_32;
    _v_14 = _v_33;
    _v_15 = _v_34;
    _v_16 = _v_35;
    _v_17 = _v_36;
    _v_18 = _v_37;
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    Term _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    if (_v_9 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      u32 _o_12 = 0;
      Term _o_13 = 0;
      u32 _o_14 = 0;
      if (_v_11 == 0) {
        _o_12 = 0;
      } else {
        _o_12 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _v_12, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        u32 _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        _o_13 = _f_0;
        _o_14 = _f_1;
      }
      u32 _o_15 = 0;
      Term _o_16 = 0;
      u32 _o_17 = 0;
      if (_v_13 == 0) {
        _o_15 = 0;
      } else {
        _o_15 = 1;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _v_14, 2, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_16 = _f_2;
        _o_17 = _f_3;
      }
      u32 _o_18 = 0;
      if (_v_15 == 0) {
        _o_18 = 0;
      } else {
        _o_18 = 1;
      }
      _o_2 = _v_10;
      _o_3 = _o_12;
      _o_4 = _o_13;
      _o_5 = _o_14;
      _o_6 = _o_15;
      _o_7 = _o_16;
      _o_8 = _o_17;
      _o_9 = _o_18;
      _o_10 = _v_17;
      _o_11 = _v_18;
    }
    if (seq) {
      WL_ROOM(5);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_11;
      STK(3) = _world_12;
      STK(4) = FID_SNAPSHOT_K382;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID_SNAPSHOT_K382, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_11;
      e.mem[_t_0 + 3] = _world_12;
      WL_CONT = term_tsk(FID_SNAPSHOT_K382, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EXTRACTED_PRINT)) {
      u64 _t_1 = task_node(e, FID_EXTRACTED_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _prefix_0;
      e.mem[_t_1 + 1] = _v_0;
      e.mem[_t_1 + 2] = _v_1;
      e.mem[_t_1 + 3] = _v_2;
      e.mem[_t_1 + 4] = _v_3;
      e.mem[_t_1 + 5] = _v_4;
      e.mem[_t_1 + 6] = _v_5;
      e.mem[_t_1 + 7] = _v_6;
      e.mem[_t_1 + 8] = _v_7;
      e.mem[_t_1 + 9] = _v_8;
      e.mem[_t_1 + 10] = _o_1;
      e.mem[_t_1 + 11] = _o_2;
      e.mem[_t_1 + 12] = _o_3;
      e.mem[_t_1 + 13] = _o_4;
      e.mem[_t_1 + 14] = _o_5;
      e.mem[_t_1 + 15] = _o_6;
      e.mem[_t_1 + 16] = _o_7;
      e.mem[_t_1 + 17] = _o_8;
      e.mem[_t_1 + 18] = _o_9;
      e.mem[_t_1 + 19] = _o_10;
      e.mem[_t_1 + 20] = _o_11;
      return term_tsk(FID_EXTRACTED_PRINT, _t_1);
    }
    r0 = _prefix_0;
    r1 = _v_0;
    r2 = _v_1;
    r3 = _v_2;
    r4 = _v_3;
    r5 = _v_4;
    r6 = _v_5;
    r7 = _v_6;
    r8 = _v_7;
    r9 = _v_8;
    r10 = _o_1;
    r11 = _o_2;
    r12 = _o_3;
    r13 = _o_4;
    r14 = _o_5;
    r15 = _o_6;
    r16 = _o_7;
    r17 = _o_8;
    r18 = _o_9;
    r19 = _o_10;
    r20 = _o_11;
    WL_JMP(FID_EXTRACTED_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K382)
  {
    WL_POPN(4);
    u32 _world_13 = STK(0);
    u32 _world_14 = STK(1);
    Term _world_15 = STK(2);
    u32 _world_16 = STK(3);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_0 + 0] = _world_13;
    e.mem[_nd_0 + 1] = _world_14;
    e.mem[_nd_0 + 2] = _world_15;
    e.mem[_nd_0 + 3] = _world_16;
    e.mem[_nd_0 + 4] = _h_0;
    r0 = term_clo(FID_SNAPSHOT_C383, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_C383)
  {
    u32 _world_17 = r0;
    u32 _world_18 = r1;
    Term _world_19 = r2;
    u32 _world_20 = r3;
    Term _h_1 = r4;
    Term _x_0 = r5;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_1 + 0] = _world_17;
    e.mem[_nd_1 + 1] = _world_18;
    e.mem[_nd_1 + 2] = _world_19;
    e.mem[_nd_1 + 3] = _world_20;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = term_clo(FID_SNAPSHOT_C384, _nd_1);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = _h_1;
    r1 = term_clo(FID_SNAPSHOT_C384, _nd_1);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_C384)
  {
    u32 _world_21 = r0;
    u32 _world_22 = r1;
    Term _world_23 = r2;
    u32 _world_24 = r3;
    Term _x_1 = r4;
    WL_OPEN
    Term _fb_2[9];
    u64 _sp_2 = ctr_take(e, _x_1, 9, _fb_2);
    Term _f_4 = _fb_2[0];
    Term _f_5 = _fb_2[1];
    Term _f_6 = _fb_2[2];
    Term _f_7 = _fb_2[3];
    Term _f_8 = _fb_2[4];
    Term _f_9 = _fb_2[5];
    u32 _f_10 = _fb_2[6];
    Term _f_11 = _fb_2[7];
    u32 _f_12 = _fb_2[8];
    spare_free(e, cls_fit(9), _sp_2);
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _world_21;
    e.mem[_nd_2 + 1] = _world_22;
    e.mem[_nd_2 + 2] = _world_23;
    e.mem[_nd_2 + 3] = _world_24;
    e.mem[_nd_2 + 4] = _f_4;
    e.mem[_nd_2 + 5] = _f_5;
    e.mem[_nd_2 + 6] = _f_6;
    e.mem[_nd_2 + 7] = _f_7;
    e.mem[_nd_2 + 8] = _f_8;
    e.mem[_nd_2 + 9] = _f_9;
    e.mem[_nd_2 + 10] = _f_10;
    e.mem[_nd_2 + 11] = _f_11;
    e.mem[_nd_2 + 12] = _f_12;
    r0 = term_clo(FID_SNAPSHOT_C385, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_C385)
  {
    u32 _world_25 = r0;
    u32 _world_26 = r1;
    Term _world_27 = r2;
    u32 _world_28 = r3;
    Term _f_13 = r4;
    Term _f_14 = r5;
    Term _f_15 = r6;
    Term _f_16 = r7;
    Term _f_17 = r8;
    Term _f_18 = r9;
    u32 _f_19 = r10;
    Term _f_20 = r11;
    u32 _f_21 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_19 = 0;
    Term _o_20 = 0;
    if (_world_28 == 0) {
      _o_19 = 0;
    } else {
      _o_19 = 1;
      _o_20 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = rfc_seal(e, _world_25);
    e.mem[_nd_3 + 1] = rfc_seal(e, _world_26);
    e.mem[_nd_3 + 2] = rfc_seal(e, _f_13);
    e.mem[_nd_3 + 3] = rfc_seal(e, _f_14);
    e.mem[_nd_3 + 4] = rfc_seal(e, _f_15);
    e.mem[_nd_3 + 5] = rfc_seal(e, _f_16);
    e.mem[_nd_3 + 6] = rfc_seal(e, _f_17);
    e.mem[_nd_3 + 7] = rfc_seal(e, _f_18);
    e.mem[_nd_3 + 8] = rfc_seal(e, _f_19);
    e.mem[_nd_3 + 9] = rfc_seal(e, _f_20);
    e.mem[_nd_3 + 10] = rfc_seal(e, _f_21);
    e.mem[_nd_3 + 11] = rfc_seal(e, _world_27);
    e.mem[_nd_3 + 12] = rfc_seal(e, _o_19);
    e.mem[_nd_3 + 13] = rfc_seal(e, _o_20);
    e.mem[_nd_3 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_3);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_3);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHAPE)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_11;
      STK(3) = _world_12;
      STK(4) = FID_SHAPE_K387;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID_SHAPE_K387, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_11;
      e.mem[_t_0 + 3] = _world_12;
      WL_CONT = term_tsk(FID_SHAPE_K387, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ROWS_SHAPE)) {
      u64 _t_1 = task_node(e, FID_ROWS_SHAPE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_2;
      e.mem[_t_1 + 1] = _world_3;
      e.mem[_t_1 + 2] = _world_4;
      e.mem[_t_1 + 3] = _world_5;
      e.mem[_t_1 + 4] = _world_6;
      e.mem[_t_1 + 5] = _world_7;
      e.mem[_t_1 + 6] = _world_8;
      e.mem[_t_1 + 7] = _world_9;
      e.mem[_t_1 + 8] = _world_10;
      return term_tsk(FID_ROWS_SHAPE, _t_1);
    }
    r0 = _world_2;
    r1 = _world_3;
    r2 = _world_4;
    r3 = _world_5;
    r4 = _world_6;
    r5 = _world_7;
    r6 = _world_8;
    r7 = _world_9;
    r8 = _world_10;
    WL_JMP(FID_ROWS_SHAPE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHAPE_K387)
  {
    WL_POPN(4);
    u32 _world_13 = STK(0);
    u32 _world_14 = STK(1);
    Term _world_15 = STK(2);
    u32 _world_16 = STK(3);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_0 + 0] = _world_13;
    e.mem[_nd_0 + 1] = _world_14;
    e.mem[_nd_0 + 2] = _world_15;
    e.mem[_nd_0 + 3] = _world_16;
    e.mem[_nd_0 + 4] = _h_0;
    r0 = term_clo(FID_SHAPE_C388, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHAPE_C388)
  {
    u32 _world_17 = r0;
    u32 _world_18 = r1;
    Term _world_19 = r2;
    u32 _world_20 = r3;
    Term _h_1 = r4;
    Term _x_0 = r5;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_1 + 0] = _world_17;
    e.mem[_nd_1 + 1] = _world_18;
    e.mem[_nd_1 + 2] = _world_19;
    e.mem[_nd_1 + 3] = _world_20;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = term_clo(FID_SHAPE_C389, _nd_1);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = _h_1;
    r1 = term_clo(FID_SHAPE_C389, _nd_1);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHAPE_C389)
  {
    u32 _world_21 = r0;
    u32 _world_22 = r1;
    Term _world_23 = r2;
    u32 _world_24 = r3;
    Term _x_1 = r4;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_1, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    u32 _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _world_21;
    e.mem[_nd_2 + 1] = _world_22;
    e.mem[_nd_2 + 2] = _world_23;
    e.mem[_nd_2 + 3] = _world_24;
    e.mem[_nd_2 + 4] = _f_0;
    e.mem[_nd_2 + 5] = _f_1;
    e.mem[_nd_2 + 6] = _f_2;
    e.mem[_nd_2 + 7] = _f_3;
    e.mem[_nd_2 + 8] = _f_4;
    e.mem[_nd_2 + 9] = _f_5;
    e.mem[_nd_2 + 10] = _f_6;
    e.mem[_nd_2 + 11] = _f_7;
    e.mem[_nd_2 + 12] = _f_8;
    r0 = term_clo(FID_SHAPE_C390, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHAPE_C390)
  {
    u32 _world_25 = r0;
    u32 _world_26 = r1;
    Term _world_27 = r2;
    u32 _world_28 = r3;
    Term _f_9 = r4;
    Term _f_10 = r5;
    Term _f_11 = r6;
    Term _f_12 = r7;
    Term _f_13 = r8;
    Term _f_14 = r9;
    u32 _f_15 = r10;
    Term _f_16 = r11;
    u32 _f_17 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_world_28 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = rfc_seal(e, _world_25);
    e.mem[_nd_3 + 1] = rfc_seal(e, _world_26);
    e.mem[_nd_3 + 2] = rfc_seal(e, _f_9);
    e.mem[_nd_3 + 3] = rfc_seal(e, _f_10);
    e.mem[_nd_3 + 4] = rfc_seal(e, _f_11);
    e.mem[_nd_3 + 5] = rfc_seal(e, _f_12);
    e.mem[_nd_3 + 6] = rfc_seal(e, _f_13);
    e.mem[_nd_3 + 7] = rfc_seal(e, _f_14);
    e.mem[_nd_3 + 8] = rfc_seal(e, _f_15);
    e.mem[_nd_3 + 9] = rfc_seal(e, _f_16);
    e.mem[_nd_3 + 10] = rfc_seal(e, _f_17);
    e.mem[_nd_3 + 11] = rfc_seal(e, _world_27);
    e.mem[_nd_3 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_3 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_3 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_3);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_3);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_APPLY_CHECKED)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _tick_0 = r15;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_1[11];
    if (spin_111(e, _o_1, _world_11, blk_loc(e.mem, _world_11), _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    _v_14 = _o_1[3];
    _v_15 = _o_1[4];
    _v_16 = _o_1[5];
    _v_17 = _o_1[6];
    _v_18 = _o_1[7];
    _v_19 = _o_1[8];
    _v_20 = _o_1[9];
    _v_21 = _o_1[10];
    _v_0 = _v_11;
    _v_1 = _v_12;
    _v_2 = _v_13;
    _v_3 = _v_14;
    _v_4 = _v_15;
    _v_5 = _v_16;
    _v_6 = _v_17;
    _v_7 = _v_18;
    _v_8 = _v_19;
    _v_9 = _v_20;
    _v_10 = _v_21;
    if (_v_10 == 0) {
      r0 = 1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _v_0;
      r4 = _v_1;
      r5 = _v_2;
      r6 = _v_3;
      r7 = _v_4;
      r8 = _v_5;
      r9 = _v_6;
      r10 = _v_7;
      r11 = _v_8;
      r12 = _v_9;
      r13 = _world_12;
      r14 = _world_13;
      r15 = _world_14;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      WL_RETN(26);
    } else {
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_2[1];
      if (spin_91(e, _o_2, _v_9, blk_loc(e.mem, _v_9)) == 0) {
        return 0;
      }
      _v_45 = _o_2[0];
      _v_44 = _v_45;
      if (seq) {
        WL_ROOM(6);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_12;
        STK(3) = _world_13;
        STK(4) = _world_14;
        STK(5) = FID_COMMANDS_APPLY_CHECKED_K392;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_APPLY_CHECKED_K392, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_12;
        e.mem[_t_0 + 3] = _world_13;
        e.mem[_t_0 + 4] = _world_14;
        WL_CONT = term_tsk(FID_COMMANDS_APPLY_CHECKED_K392, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_BATCH)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_BATCH, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_44;
        e.mem[_t_1 + 1] = _world_0;
        e.mem[_t_1 + 2] = _tick_0;
        e.mem[_t_1 + 3] = 0;
        e.mem[_t_1 + 4] = _v_0;
        e.mem[_t_1 + 5] = _v_1;
        e.mem[_t_1 + 6] = _v_2;
        e.mem[_t_1 + 7] = _v_3;
        e.mem[_t_1 + 8] = _v_4;
        e.mem[_t_1 + 9] = _v_5;
        e.mem[_t_1 + 10] = _v_6;
        e.mem[_t_1 + 11] = _v_7;
        e.mem[_t_1 + 12] = _v_8;
        e.mem[_t_1 + 13] = term_pak(CID_NIL, 0);
        e.mem[_t_1 + 14] = 0;
        e.mem[_t_1 + 15] = 0;
        e.mem[_t_1 + 16] = 0;
        e.mem[_t_1 + 17] = 0;
        e.mem[_t_1 + 18] = 0;
        e.mem[_t_1 + 19] = 0;
        e.mem[_t_1 + 20] = 0;
        e.mem[_t_1 + 21] = 0;
        e.mem[_t_1 + 22] = 0;
        e.mem[_t_1 + 23] = 0;
        return term_tsk(FID_COMMANDS_BATCH, _t_1);
      }
      r0 = _v_44;
      r1 = _world_0;
      r2 = _tick_0;
      r3 = 0;
      r4 = _v_0;
      r5 = _v_1;
      r6 = _v_2;
      r7 = _v_3;
      r8 = _v_4;
      r9 = _v_5;
      r10 = _v_6;
      r11 = _v_7;
      r12 = _v_8;
      r13 = term_pak(CID_NIL, 0);
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      WL_JMP(FID_COMMANDS_BATCH);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_APPLY_CHECKED_K392)
  {
    WL_POPN(5);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    u32 _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    WL_OPEN
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _o_3[26];
    if (spin_103(e, _o_3, _world_15, _world_16, _world_17, _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_46 = _o_3[0];
    _v_47 = _o_3[1];
    _v_48 = _o_3[2];
    _v_49 = _o_3[3];
    _v_50 = _o_3[4];
    _v_51 = _o_3[5];
    _v_52 = _o_3[6];
    _v_53 = _o_3[7];
    _v_54 = _o_3[8];
    _v_55 = _o_3[9];
    _v_56 = _o_3[10];
    _v_57 = _o_3[11];
    _v_58 = _o_3[12];
    _v_59 = _o_3[13];
    _v_60 = _o_3[14];
    _v_61 = _o_3[15];
    _v_62 = _o_3[16];
    _v_63 = _o_3[17];
    _v_64 = _o_3[18];
    _v_65 = _o_3[19];
    _v_66 = _o_3[20];
    _v_67 = _o_3[21];
    _v_68 = _o_3[22];
    _v_69 = _o_3[23];
    _v_70 = _o_3[24];
    _v_71 = _o_3[25];
    r0 = _v_46;
    r1 = _v_47;
    r2 = _v_48;
    r3 = _v_49;
    r4 = _v_50;
    r5 = _v_51;
    r6 = _v_52;
    r7 = _v_53;
    r8 = _v_54;
    r9 = _v_55;
    r10 = _v_56;
    r11 = _v_57;
    r12 = _v_58;
    r13 = _v_59;
    r14 = _v_60;
    r15 = _v_61;
    r16 = _v_62;
    r17 = _v_63;
    r18 = _v_64;
    r19 = _v_65;
    r20 = _v_66;
    r21 = _v_67;
    r22 = _v_68;
    r23 = _v_69;
    r24 = _v_70;
    r25 = _v_71;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED)
  {
    Term _prefix_0 = r0;
    u32 _result_0 = r1;
    u32 _result_1 = r2;
    u32 _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    Term _result_6 = r7;
    Term _result_7 = r8;
    Term _result_8 = r9;
    u32 _result_9 = r10;
    Term _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    Term _result_14 = r15;
    u32 _result_15 = r16;
    Term _result_16 = r17;
    u32 _result_17 = r18;
    u32 _result_18 = r19;
    Term _result_19 = r20;
    u32 _result_20 = r21;
    u32 _result_21 = r22;
    u32 _result_22 = r23;
    u32 _result_23 = r24;
    Term _result_24 = r25;
    WL_OPEN
    if (_result_0 == 0) {
      term_sink(e, _result_14);
      if (seq) {
        WL_ROOM(14);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = FID_APPLIED_K394;
        WL_PUSHN(14);
      } else {
        u64 _t_0 = task_node(e, FID_APPLIED_K394, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_1;
        e.mem[_t_0 + 1] = _result_2;
        e.mem[_t_0 + 2] = _result_3;
        e.mem[_t_0 + 3] = _result_4;
        e.mem[_t_0 + 4] = _result_5;
        e.mem[_t_0 + 5] = _result_6;
        e.mem[_t_0 + 6] = _result_7;
        e.mem[_t_0 + 7] = _result_8;
        e.mem[_t_0 + 8] = _result_9;
        e.mem[_t_0 + 9] = _result_10;
        e.mem[_t_0 + 10] = _result_11;
        e.mem[_t_0 + 11] = _result_12;
        e.mem[_t_0 + 12] = _result_13;
        WL_CONT = term_tsk(FID_APPLIED_K394, _t_0);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _prefix_0;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 100);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 100);
      WL_JMP(FID_STRING_APPEND);
    } else if (_result_0 == 1) {
      if (seq) {
        WL_ROOM(14);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = FID_APPLIED_K398;
        WL_PUSHN(14);
      } else {
        u64 _t_4 = task_node(e, FID_APPLIED_K398, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _result_1;
        e.mem[_t_4 + 1] = _result_2;
        e.mem[_t_4 + 2] = _result_3;
        e.mem[_t_4 + 3] = _result_4;
        e.mem[_t_4 + 4] = _result_5;
        e.mem[_t_4 + 5] = _result_6;
        e.mem[_t_4 + 6] = _result_7;
        e.mem[_t_4 + 7] = _result_8;
        e.mem[_t_4 + 8] = _result_9;
        e.mem[_t_4 + 9] = _result_10;
        e.mem[_t_4 + 10] = _result_11;
        e.mem[_t_4 + 11] = _result_12;
        e.mem[_t_4 + 12] = _result_13;
        WL_CONT = term_tsk(FID_APPLIED_K398, _t_4);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _prefix_0;
        e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 130);
        return term_tsk(FID_STRING_APPEND, _t_5);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 130);
      WL_JMP(FID_STRING_APPEND);
    } else {
      term_sink(e, _result_16);
      term_sink(e, _result_19);
      term_sink(e, _result_24);
      if (seq) {
        WL_ROOM(14);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = FID_APPLIED_K402;
        WL_PUSHN(14);
      } else {
        u64 _t_8 = task_node(e, FID_APPLIED_K402, WL_CONT, WL_IDX, 1);
        e.mem[_t_8 + 0] = _result_1;
        e.mem[_t_8 + 1] = _result_2;
        e.mem[_t_8 + 2] = _result_3;
        e.mem[_t_8 + 3] = _result_4;
        e.mem[_t_8 + 4] = _result_5;
        e.mem[_t_8 + 5] = _result_6;
        e.mem[_t_8 + 6] = _result_7;
        e.mem[_t_8 + 7] = _result_8;
        e.mem[_t_8 + 8] = _result_9;
        e.mem[_t_8 + 9] = _result_10;
        e.mem[_t_8 + 10] = _result_11;
        e.mem[_t_8 + 11] = _result_12;
        e.mem[_t_8 + 12] = _result_13;
        WL_CONT = term_tsk(FID_APPLIED_K402, _t_8);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_9 + 0] = _prefix_0;
        e.mem[_t_9 + 1] = term_ctr(CID_SCON, STAT_OFF + 158);
        return term_tsk(FID_STRING_APPEND, _t_9);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 158);
      WL_JMP(FID_STRING_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K394)
  {
    WL_POPN(13);
    u32 _result_25 = STK(0);
    u32 _result_26 = STK(1);
    Term _result_27 = STK(2);
    Term _result_28 = STK(3);
    Term _result_29 = STK(4);
    Term _result_30 = STK(5);
    Term _result_31 = STK(6);
    Term _result_32 = STK(7);
    u32 _result_33 = STK(8);
    Term _result_34 = STK(9);
    u32 _result_35 = STK(10);
    Term _result_36 = STK(11);
    u32 _result_37 = STK(12);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_0 + 0] = _result_25;
    e.mem[_nd_0 + 1] = _result_26;
    e.mem[_nd_0 + 2] = _result_27;
    e.mem[_nd_0 + 3] = _result_28;
    e.mem[_nd_0 + 4] = _result_29;
    e.mem[_nd_0 + 5] = _result_30;
    e.mem[_nd_0 + 6] = _result_31;
    e.mem[_nd_0 + 7] = _result_32;
    e.mem[_nd_0 + 8] = _result_33;
    e.mem[_nd_0 + 9] = _result_34;
    e.mem[_nd_0 + 10] = _result_35;
    e.mem[_nd_0 + 11] = _result_36;
    e.mem[_nd_0 + 12] = _result_37;
    e.mem[_nd_0 + 13] = _h_0;
    r0 = term_clo(FID_APPLIED_C395, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C395)
  {
    u32 _result_38 = r0;
    u32 _result_39 = r1;
    Term _result_40 = r2;
    Term _result_41 = r3;
    Term _result_42 = r4;
    Term _result_43 = r5;
    Term _result_44 = r6;
    Term _result_45 = r7;
    u32 _result_46 = r8;
    Term _result_47 = r9;
    u32 _result_48 = r10;
    Term _result_49 = r11;
    u32 _result_50 = r12;
    Term _h_1 = r13;
    Term _x_0 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _result_38;
    e.mem[_nd_2 + 1] = _result_39;
    e.mem[_nd_2 + 2] = _result_40;
    e.mem[_nd_2 + 3] = _result_41;
    e.mem[_nd_2 + 4] = _result_42;
    e.mem[_nd_2 + 5] = _result_43;
    e.mem[_nd_2 + 6] = _result_44;
    e.mem[_nd_2 + 7] = _result_45;
    e.mem[_nd_2 + 8] = _result_46;
    e.mem[_nd_2 + 9] = _result_47;
    e.mem[_nd_2 + 10] = _result_48;
    e.mem[_nd_2 + 11] = _result_49;
    e.mem[_nd_2 + 12] = _result_50;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_APPLIED_C396, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_APPLIED_C396, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C396)
  {
    u32 _result_51 = r0;
    u32 _result_52 = r1;
    Term _result_53 = r2;
    Term _result_54 = r3;
    Term _result_55 = r4;
    Term _result_56 = r5;
    Term _result_57 = r6;
    Term _result_58 = r7;
    u32 _result_59 = r8;
    Term _result_60 = r9;
    u32 _result_61 = r10;
    Term _result_62 = r11;
    u32 _result_63 = r12;
    Term _x_1 = r13;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_3 + 0] = _result_51;
    e.mem[_nd_3 + 1] = _result_52;
    e.mem[_nd_3 + 2] = _result_53;
    e.mem[_nd_3 + 3] = _result_54;
    e.mem[_nd_3 + 4] = _result_55;
    e.mem[_nd_3 + 5] = _result_56;
    e.mem[_nd_3 + 6] = _result_57;
    e.mem[_nd_3 + 7] = _result_58;
    e.mem[_nd_3 + 8] = _result_59;
    e.mem[_nd_3 + 9] = _result_60;
    e.mem[_nd_3 + 10] = _result_61;
    e.mem[_nd_3 + 11] = _result_62;
    e.mem[_nd_3 + 12] = _result_63;
    r0 = term_clo(FID_APPLIED_C397, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C397)
  {
    u32 _result_64 = r0;
    u32 _result_65 = r1;
    Term _result_66 = r2;
    Term _result_67 = r3;
    Term _result_68 = r4;
    Term _result_69 = r5;
    Term _result_70 = r6;
    Term _result_71 = r7;
    u32 _result_72 = r8;
    Term _result_73 = r9;
    u32 _result_74 = r10;
    Term _result_75 = r11;
    u32 _result_76 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_result_76 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_64);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_65);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_66);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_67);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_68);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_69);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_70);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_71);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_72);
    e.mem[_nd_4 + 9] = rfc_seal(e, _result_73);
    e.mem[_nd_4 + 10] = rfc_seal(e, _result_74);
    e.mem[_nd_4 + 11] = rfc_seal(e, _result_75);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_4 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K398)
  {
    WL_POPN(13);
    u32 _result_77 = STK(0);
    u32 _result_78 = STK(1);
    Term _result_79 = STK(2);
    Term _result_80 = STK(3);
    Term _result_81 = STK(4);
    Term _result_82 = STK(5);
    Term _result_83 = STK(6);
    Term _result_84 = STK(7);
    u32 _result_85 = STK(8);
    Term _result_86 = STK(9);
    u32 _result_87 = STK(10);
    Term _result_88 = STK(11);
    u32 _result_89 = STK(12);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_5 + 0] = _result_77;
    e.mem[_nd_5 + 1] = _result_78;
    e.mem[_nd_5 + 2] = _result_79;
    e.mem[_nd_5 + 3] = _result_80;
    e.mem[_nd_5 + 4] = _result_81;
    e.mem[_nd_5 + 5] = _result_82;
    e.mem[_nd_5 + 6] = _result_83;
    e.mem[_nd_5 + 7] = _result_84;
    e.mem[_nd_5 + 8] = _result_85;
    e.mem[_nd_5 + 9] = _result_86;
    e.mem[_nd_5 + 10] = _result_87;
    e.mem[_nd_5 + 11] = _result_88;
    e.mem[_nd_5 + 12] = _result_89;
    e.mem[_nd_5 + 13] = _h_2;
    r0 = term_clo(FID_APPLIED_C399, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C399)
  {
    u32 _result_90 = r0;
    u32 _result_91 = r1;
    Term _result_92 = r2;
    Term _result_93 = r3;
    Term _result_94 = r4;
    Term _result_95 = r5;
    Term _result_96 = r6;
    Term _result_97 = r7;
    u32 _result_98 = r8;
    Term _result_99 = r9;
    u32 _result_100 = r10;
    Term _result_101 = r11;
    u32 _result_102 = r12;
    Term _h_3 = r13;
    Term _x_3 = r14;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_3;
    u64 _nd_7 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_7 + 0] = _result_90;
    e.mem[_nd_7 + 1] = _result_91;
    e.mem[_nd_7 + 2] = _result_92;
    e.mem[_nd_7 + 3] = _result_93;
    e.mem[_nd_7 + 4] = _result_94;
    e.mem[_nd_7 + 5] = _result_95;
    e.mem[_nd_7 + 6] = _result_96;
    e.mem[_nd_7 + 7] = _result_97;
    e.mem[_nd_7 + 8] = _result_98;
    e.mem[_nd_7 + 9] = _result_99;
    e.mem[_nd_7 + 10] = _result_100;
    e.mem[_nd_7 + 11] = _result_101;
    e.mem[_nd_7 + 12] = _result_102;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_7 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_7 + 1] = term_clo(FID_APPLIED_C400, _nd_7);
      e.mem[_t_7 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_7);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_APPLIED_C400, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C400)
  {
    u32 _result_103 = r0;
    u32 _result_104 = r1;
    Term _result_105 = r2;
    Term _result_106 = r3;
    Term _result_107 = r4;
    Term _result_108 = r5;
    Term _result_109 = r6;
    Term _result_110 = r7;
    u32 _result_111 = r8;
    Term _result_112 = r9;
    u32 _result_113 = r10;
    Term _result_114 = r11;
    u32 _result_115 = r12;
    Term _x_4 = r13;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_8 + 0] = _result_103;
    e.mem[_nd_8 + 1] = _result_104;
    e.mem[_nd_8 + 2] = _result_105;
    e.mem[_nd_8 + 3] = _result_106;
    e.mem[_nd_8 + 4] = _result_107;
    e.mem[_nd_8 + 5] = _result_108;
    e.mem[_nd_8 + 6] = _result_109;
    e.mem[_nd_8 + 7] = _result_110;
    e.mem[_nd_8 + 8] = _result_111;
    e.mem[_nd_8 + 9] = _result_112;
    e.mem[_nd_8 + 10] = _result_113;
    e.mem[_nd_8 + 11] = _result_114;
    e.mem[_nd_8 + 12] = _result_115;
    r0 = term_clo(FID_APPLIED_C401, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C401)
  {
    u32 _result_116 = r0;
    u32 _result_117 = r1;
    Term _result_118 = r2;
    Term _result_119 = r3;
    Term _result_120 = r4;
    Term _result_121 = r5;
    Term _result_122 = r6;
    Term _result_123 = r7;
    u32 _result_124 = r8;
    Term _result_125 = r9;
    u32 _result_126 = r10;
    Term _result_127 = r11;
    u32 _result_128 = r12;
    Term _x_5 = r13;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_result_128 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      _o_3 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_9 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_9 + 0] = rfc_seal(e, _result_116);
    e.mem[_nd_9 + 1] = rfc_seal(e, _result_117);
    e.mem[_nd_9 + 2] = rfc_seal(e, _result_118);
    e.mem[_nd_9 + 3] = rfc_seal(e, _result_119);
    e.mem[_nd_9 + 4] = rfc_seal(e, _result_120);
    e.mem[_nd_9 + 5] = rfc_seal(e, _result_121);
    e.mem[_nd_9 + 6] = rfc_seal(e, _result_122);
    e.mem[_nd_9 + 7] = rfc_seal(e, _result_123);
    e.mem[_nd_9 + 8] = rfc_seal(e, _result_124);
    e.mem[_nd_9 + 9] = rfc_seal(e, _result_125);
    e.mem[_nd_9 + 10] = rfc_seal(e, _result_126);
    e.mem[_nd_9 + 11] = rfc_seal(e, _result_127);
    e.mem[_nd_9 + 12] = rfc_seal(e, _o_2);
    e.mem[_nd_9 + 13] = rfc_seal(e, _o_3);
    e.mem[_nd_9 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_6 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_9);
      e.mem[_t_6 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_6);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_9);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K402)
  {
    WL_POPN(13);
    u32 _result_129 = STK(0);
    u32 _result_130 = STK(1);
    Term _result_131 = STK(2);
    Term _result_132 = STK(3);
    Term _result_133 = STK(4);
    Term _result_134 = STK(5);
    Term _result_135 = STK(6);
    Term _result_136 = STK(7);
    u32 _result_137 = STK(8);
    Term _result_138 = STK(9);
    u32 _result_139 = STK(10);
    Term _result_140 = STK(11);
    u32 _result_141 = STK(12);
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_10 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_10 + 0] = _result_129;
    e.mem[_nd_10 + 1] = _result_130;
    e.mem[_nd_10 + 2] = _result_131;
    e.mem[_nd_10 + 3] = _result_132;
    e.mem[_nd_10 + 4] = _result_133;
    e.mem[_nd_10 + 5] = _result_134;
    e.mem[_nd_10 + 6] = _result_135;
    e.mem[_nd_10 + 7] = _result_136;
    e.mem[_nd_10 + 8] = _result_137;
    e.mem[_nd_10 + 9] = _result_138;
    e.mem[_nd_10 + 10] = _result_139;
    e.mem[_nd_10 + 11] = _result_140;
    e.mem[_nd_10 + 12] = _result_141;
    e.mem[_nd_10 + 13] = _h_4;
    r0 = term_clo(FID_APPLIED_C403, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C403)
  {
    u32 _result_142 = r0;
    u32 _result_143 = r1;
    Term _result_144 = r2;
    Term _result_145 = r3;
    Term _result_146 = r4;
    Term _result_147 = r5;
    Term _result_148 = r6;
    Term _result_149 = r7;
    u32 _result_150 = r8;
    Term _result_151 = r9;
    u32 _result_152 = r10;
    Term _result_153 = r11;
    u32 _result_154 = r12;
    Term _h_5 = r13;
    Term _x_6 = r14;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_11 + 0] = _h_5;
    u64 _nd_12 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_12 + 0] = _result_142;
    e.mem[_nd_12 + 1] = _result_143;
    e.mem[_nd_12 + 2] = _result_144;
    e.mem[_nd_12 + 3] = _result_145;
    e.mem[_nd_12 + 4] = _result_146;
    e.mem[_nd_12 + 5] = _result_147;
    e.mem[_nd_12 + 6] = _result_148;
    e.mem[_nd_12 + 7] = _result_149;
    e.mem[_nd_12 + 8] = _result_150;
    e.mem[_nd_12 + 9] = _result_151;
    e.mem[_nd_12 + 10] = _result_152;
    e.mem[_nd_12 + 11] = _result_153;
    e.mem[_nd_12 + 12] = _result_154;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_11 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_clo(FID_IO_PRINT, _nd_11);
      e.mem[_t_11 + 1] = term_clo(FID_APPLIED_C404, _nd_12);
      e.mem[_t_11 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_11);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_11);
    r1 = term_clo(FID_APPLIED_C404, _nd_12);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C404)
  {
    u32 _result_155 = r0;
    u32 _result_156 = r1;
    Term _result_157 = r2;
    Term _result_158 = r3;
    Term _result_159 = r4;
    Term _result_160 = r5;
    Term _result_161 = r6;
    Term _result_162 = r7;
    u32 _result_163 = r8;
    Term _result_164 = r9;
    u32 _result_165 = r10;
    Term _result_166 = r11;
    u32 _result_167 = r12;
    Term _x_7 = r13;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_13 + 0] = _result_155;
    e.mem[_nd_13 + 1] = _result_156;
    e.mem[_nd_13 + 2] = _result_157;
    e.mem[_nd_13 + 3] = _result_158;
    e.mem[_nd_13 + 4] = _result_159;
    e.mem[_nd_13 + 5] = _result_160;
    e.mem[_nd_13 + 6] = _result_161;
    e.mem[_nd_13 + 7] = _result_162;
    e.mem[_nd_13 + 8] = _result_163;
    e.mem[_nd_13 + 9] = _result_164;
    e.mem[_nd_13 + 10] = _result_165;
    e.mem[_nd_13 + 11] = _result_166;
    e.mem[_nd_13 + 12] = _result_167;
    r0 = term_clo(FID_APPLIED_C405, _nd_13);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_C405)
  {
    u32 _result_168 = r0;
    u32 _result_169 = r1;
    Term _result_170 = r2;
    Term _result_171 = r3;
    Term _result_172 = r4;
    Term _result_173 = r5;
    Term _result_174 = r6;
    Term _result_175 = r7;
    u32 _result_176 = r8;
    Term _result_177 = r9;
    u32 _result_178 = r10;
    Term _result_179 = r11;
    u32 _result_180 = r12;
    Term _x_8 = r13;
    WL_OPEN
    u32 _o_4 = 0;
    Term _o_5 = 0;
    if (_result_180 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_14 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_14 + 0] = rfc_seal(e, _result_168);
    e.mem[_nd_14 + 1] = rfc_seal(e, _result_169);
    e.mem[_nd_14 + 2] = rfc_seal(e, _result_170);
    e.mem[_nd_14 + 3] = rfc_seal(e, _result_171);
    e.mem[_nd_14 + 4] = rfc_seal(e, _result_172);
    e.mem[_nd_14 + 5] = rfc_seal(e, _result_173);
    e.mem[_nd_14 + 6] = rfc_seal(e, _result_174);
    e.mem[_nd_14 + 7] = rfc_seal(e, _result_175);
    e.mem[_nd_14 + 8] = rfc_seal(e, _result_176);
    e.mem[_nd_14 + 9] = rfc_seal(e, _result_177);
    e.mem[_nd_14 + 10] = rfc_seal(e, _result_178);
    e.mem[_nd_14 + 11] = rfc_seal(e, _result_179);
    e.mem[_nd_14 + 12] = rfc_seal(e, _o_4);
    e.mem[_nd_14 + 13] = rfc_seal(e, _o_5);
    e.mem[_nd_14 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_10 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_14);
      e.mem[_t_10 + 1] = _x_8;
      return term_tsk(FID_IO_PURE, _t_10);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_14);
    r1 = _x_8;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH)
  {
    Term _prefix_0 = r0;
    u32 _selection_0 = r1;
    u32 _world_0 = r2;
    u32 _world_1 = r3;
    Term _world_2 = r4;
    Term _world_3 = r5;
    Term _world_4 = r6;
    Term _world_5 = r7;
    Term _world_6 = r8;
    Term _world_7 = r9;
    u32 _world_8 = r10;
    Term _world_9 = r11;
    u32 _world_10 = r12;
    Term _world_11 = r13;
    u32 _world_12 = r14;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    Term _o_5[14];
    if (spin_112(e, _o_5, _selection_0, _world_0, _world_1, _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, blk_loc(e.mem, _world_11), _world_12) == 0) {
      return 0;
    }
    _v_14 = _o_5[0];
    _v_15 = _o_5[1];
    _v_16 = _o_5[2];
    _v_17 = _o_5[3];
    _v_18 = _o_5[4];
    _v_19 = _o_5[5];
    _v_20 = _o_5[6];
    _v_21 = _o_5[7];
    _v_22 = _o_5[8];
    _v_23 = _o_5[9];
    _v_24 = _o_5[10];
    _v_25 = _o_5[11];
    _v_26 = _o_5[12];
    _v_27 = _o_5[13];
    _v_0 = _v_14;
    _v_1 = _v_15;
    _v_2 = _v_16;
    _v_3 = _v_17;
    _v_4 = _v_18;
    _v_5 = _v_19;
    _v_6 = _v_20;
    _v_7 = _v_21;
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _prefix_0;
      STK(1) = FID_EACH_K407;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_EACH_K407, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _prefix_0;
      WL_CONT = term_tsk(FID_EACH_K407, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_IDENTITY_RENDER)) {
      u64 _t_1 = task_node(e, FID_IDENTITY_RENDER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = _v_1;
      e.mem[_t_1 + 2] = _v_2;
      e.mem[_t_1 + 3] = _v_3;
      e.mem[_t_1 + 4] = _v_4;
      e.mem[_t_1 + 5] = _v_5;
      e.mem[_t_1 + 6] = _v_6;
      e.mem[_t_1 + 7] = _v_7;
      e.mem[_t_1 + 8] = _v_8;
      e.mem[_t_1 + 9] = _v_9;
      e.mem[_t_1 + 10] = _v_10;
      e.mem[_t_1 + 11] = _v_11;
      e.mem[_t_1 + 12] = _v_12;
      e.mem[_t_1 + 13] = _v_13;
      return term_tsk(FID_IDENTITY_RENDER, _t_1);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    WL_JMP(FID_IDENTITY_RENDER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH_K407)
  {
    WL_POPN(1);
    Term _prefix_1 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _prefix_1;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = _h_2;
      STK(4) = _h_3;
      STK(5) = _h_4;
      STK(6) = _h_5;
      STK(7) = _h_6;
      STK(8) = _h_7;
      STK(9) = _h_8;
      STK(10) = _h_9;
      STK(11) = _h_10;
      STK(12) = _h_11;
      STK(13) = _h_12;
      STK(14) = FID_EACH_K408;
      WL_PUSHN(15);
    } else {
      u64 _t_2 = task_node(e, FID_EACH_K408, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _prefix_1;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      e.mem[_t_2 + 4] = _h_3;
      e.mem[_t_2 + 5] = _h_4;
      e.mem[_t_2 + 6] = _h_5;
      e.mem[_t_2 + 7] = _h_6;
      e.mem[_t_2 + 8] = _h_7;
      e.mem[_t_2 + 9] = _h_8;
      e.mem[_t_2 + 10] = _h_9;
      e.mem[_t_2 + 11] = _h_10;
      e.mem[_t_2 + 12] = _h_11;
      e.mem[_t_2 + 13] = _h_12;
      WL_CONT = term_tsk(FID_EACH_K408, _t_2);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRINGS)) {
      u64 _t_3 = task_node(e, FID_STRINGS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_13;
      return term_tsk(FID_STRINGS, _t_3);
    }
    r0 = _h_13;
    WL_JMP(FID_STRINGS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH_K408)
  {
    WL_POPN(14);
    Term _prefix_2 = STK(0);
    u32 _h_15 = STK(1);
    u32 _h_16 = STK(2);
    Term _h_17 = STK(3);
    Term _h_18 = STK(4);
    Term _h_19 = STK(5);
    Term _h_20 = STK(6);
    Term _h_21 = STK(7);
    Term _h_22 = STK(8);
    u32 _h_23 = STK(9);
    Term _h_24 = STK(10);
    u32 _h_25 = STK(11);
    Term _h_26 = STK(12);
    u32 _h_27 = STK(13);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_15;
      STK(1) = _h_16;
      STK(2) = _h_17;
      STK(3) = _h_18;
      STK(4) = _h_19;
      STK(5) = _h_20;
      STK(6) = _h_21;
      STK(7) = _h_22;
      STK(8) = _h_23;
      STK(9) = _h_24;
      STK(10) = _h_25;
      STK(11) = _h_26;
      STK(12) = _h_27;
      STK(13) = FID_EACH_K409;
      WL_PUSHN(14);
    } else {
      u64 _t_4 = task_node(e, FID_EACH_K409, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_15;
      e.mem[_t_4 + 1] = _h_16;
      e.mem[_t_4 + 2] = _h_17;
      e.mem[_t_4 + 3] = _h_18;
      e.mem[_t_4 + 4] = _h_19;
      e.mem[_t_4 + 5] = _h_20;
      e.mem[_t_4 + 6] = _h_21;
      e.mem[_t_4 + 7] = _h_22;
      e.mem[_t_4 + 8] = _h_23;
      e.mem[_t_4 + 9] = _h_24;
      e.mem[_t_4 + 10] = _h_25;
      e.mem[_t_4 + 11] = _h_26;
      e.mem[_t_4 + 12] = _h_27;
      WL_CONT = term_tsk(FID_EACH_K409, _t_4);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _prefix_2;
      e.mem[_t_5 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _prefix_2;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH_K409)
  {
    WL_POPN(13);
    u32 _h_29 = STK(0);
    u32 _h_30 = STK(1);
    Term _h_31 = STK(2);
    Term _h_32 = STK(3);
    Term _h_33 = STK(4);
    Term _h_34 = STK(5);
    Term _h_35 = STK(6);
    Term _h_36 = STK(7);
    u32 _h_37 = STK(8);
    Term _h_38 = STK(9);
    u32 _h_39 = STK(10);
    Term _h_40 = STK(11);
    u32 _h_41 = STK(12);
    Term _h_28 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_0 + 0] = _h_29;
    e.mem[_nd_0 + 1] = _h_30;
    e.mem[_nd_0 + 2] = _h_31;
    e.mem[_nd_0 + 3] = _h_32;
    e.mem[_nd_0 + 4] = _h_33;
    e.mem[_nd_0 + 5] = _h_34;
    e.mem[_nd_0 + 6] = _h_35;
    e.mem[_nd_0 + 7] = _h_36;
    e.mem[_nd_0 + 8] = _h_37;
    e.mem[_nd_0 + 9] = _h_38;
    e.mem[_nd_0 + 10] = _h_39;
    e.mem[_nd_0 + 11] = _h_40;
    e.mem[_nd_0 + 12] = _h_41;
    e.mem[_nd_0 + 13] = _h_28;
    r0 = term_clo(FID_EACH_C410, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH_C410)
  {
    u32 _h_42 = r0;
    u32 _h_43 = r1;
    Term _h_44 = r2;
    Term _h_45 = r3;
    Term _h_46 = r4;
    Term _h_47 = r5;
    Term _h_48 = r6;
    Term _h_49 = r7;
    u32 _h_50 = r8;
    Term _h_51 = r9;
    u32 _h_52 = r10;
    Term _h_53 = r11;
    u32 _h_54 = r12;
    Term _h_55 = r13;
    Term _x_0 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_55;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _h_42;
    e.mem[_nd_2 + 1] = _h_43;
    e.mem[_nd_2 + 2] = _h_44;
    e.mem[_nd_2 + 3] = _h_45;
    e.mem[_nd_2 + 4] = _h_46;
    e.mem[_nd_2 + 5] = _h_47;
    e.mem[_nd_2 + 6] = _h_48;
    e.mem[_nd_2 + 7] = _h_49;
    e.mem[_nd_2 + 8] = _h_50;
    e.mem[_nd_2 + 9] = _h_51;
    e.mem[_nd_2 + 10] = _h_52;
    e.mem[_nd_2 + 11] = _h_53;
    e.mem[_nd_2 + 12] = _h_54;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_7 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_7 + 1] = term_clo(FID_EACH_C411, _nd_2);
      e.mem[_t_7 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_7);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_EACH_C411, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH_C411)
  {
    u32 _h_56 = r0;
    u32 _h_57 = r1;
    Term _h_58 = r2;
    Term _h_59 = r3;
    Term _h_60 = r4;
    Term _h_61 = r5;
    Term _h_62 = r6;
    Term _h_63 = r7;
    u32 _h_64 = r8;
    Term _h_65 = r9;
    u32 _h_66 = r10;
    Term _h_67 = r11;
    u32 _h_68 = r12;
    Term _x_1 = r13;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_3 + 0] = _h_56;
    e.mem[_nd_3 + 1] = _h_57;
    e.mem[_nd_3 + 2] = _h_58;
    e.mem[_nd_3 + 3] = _h_59;
    e.mem[_nd_3 + 4] = _h_60;
    e.mem[_nd_3 + 5] = _h_61;
    e.mem[_nd_3 + 6] = _h_62;
    e.mem[_nd_3 + 7] = _h_63;
    e.mem[_nd_3 + 8] = _h_64;
    e.mem[_nd_3 + 9] = _h_65;
    e.mem[_nd_3 + 10] = _h_66;
    e.mem[_nd_3 + 11] = _h_67;
    e.mem[_nd_3 + 12] = _h_68;
    r0 = term_clo(FID_EACH_C412, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EACH_C412)
  {
    u32 _h_69 = r0;
    u32 _h_70 = r1;
    Term _h_71 = r2;
    Term _h_72 = r3;
    Term _h_73 = r4;
    Term _h_74 = r5;
    Term _h_75 = r6;
    Term _h_76 = r7;
    u32 _h_77 = r8;
    Term _h_78 = r9;
    u32 _h_79 = r10;
    Term _h_80 = r11;
    u32 _h_81 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_6 = 0;
    Term _o_7 = 0;
    if (_h_81 == 0) {
      _o_6 = 0;
    } else {
      _o_6 = 1;
      _o_7 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_69);
    e.mem[_nd_4 + 1] = rfc_seal(e, _h_70);
    e.mem[_nd_4 + 2] = rfc_seal(e, _h_71);
    e.mem[_nd_4 + 3] = rfc_seal(e, _h_72);
    e.mem[_nd_4 + 4] = rfc_seal(e, _h_73);
    e.mem[_nd_4 + 5] = rfc_seal(e, _h_74);
    e.mem[_nd_4 + 6] = rfc_seal(e, _h_75);
    e.mem[_nd_4 + 7] = rfc_seal(e, _h_76);
    e.mem[_nd_4 + 8] = rfc_seal(e, _h_77);
    e.mem[_nd_4 + 9] = rfc_seal(e, _h_78);
    e.mem[_nd_4 + 10] = rfc_seal(e, _h_79);
    e.mem[_nd_4 + 11] = rfc_seal(e, _h_80);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_6);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_7);
    e.mem[_nd_4 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_6 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_4);
      e.mem[_t_6 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_6);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED)
  {
    Term _prefix_0 = r0;
    u32 _result_0 = r1;
    u32 _result_1 = r2;
    u32 _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    Term _result_6 = r7;
    Term _result_7 = r8;
    Term _result_8 = r9;
    u32 _result_9 = r10;
    Term _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    u32 _result_14 = r15;
    Term _result_15 = r16;
    u32 _result_16 = r17;
    u32 _result_17 = r18;
    Term _result_18 = r19;
    u32 _result_19 = r20;
    u32 _result_20 = r21;
    WL_OPEN
    if (_result_0 == 0) {
      if (seq) {
        WL_ROOM(16);
        STK(0) = _prefix_0;
        STK(1) = _result_1;
        STK(2) = _result_2;
        STK(3) = _result_3;
        STK(4) = _result_4;
        STK(5) = _result_5;
        STK(6) = _result_6;
        STK(7) = _result_7;
        STK(8) = _result_8;
        STK(9) = _result_9;
        STK(10) = _result_10;
        STK(11) = _result_11;
        STK(12) = _result_12;
        STK(13) = _result_13;
        STK(14) = _result_15;
        STK(15) = FID_RESERVED_K417;
        WL_PUSHN(16);
      } else {
        u64 _t_0 = task_node(e, FID_RESERVED_K417, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _prefix_0;
        e.mem[_t_0 + 1] = _result_1;
        e.mem[_t_0 + 2] = _result_2;
        e.mem[_t_0 + 3] = _result_3;
        e.mem[_t_0 + 4] = _result_4;
        e.mem[_t_0 + 5] = _result_5;
        e.mem[_t_0 + 6] = _result_6;
        e.mem[_t_0 + 7] = _result_7;
        e.mem[_t_0 + 8] = _result_8;
        e.mem[_t_0 + 9] = _result_9;
        e.mem[_t_0 + 10] = _result_10;
        e.mem[_t_0 + 11] = _result_11;
        e.mem[_t_0 + 12] = _result_12;
        e.mem[_t_0 + 13] = _result_13;
        e.mem[_t_0 + 14] = _result_15;
        WL_CONT = term_tsk(FID_RESERVED_K417, _t_0);
        WL_IDX = 15;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _result_14;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _result_14;
      WL_JMP(FID_U32_SHOW);
    } else {
      term_sink(e, _result_15);
      term_sink(e, _result_18);
      if (seq) {
        WL_ROOM(14);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = FID_RESERVED_K425;
        WL_PUSHN(14);
      } else {
        u64 _t_12 = task_node(e, FID_RESERVED_K425, WL_CONT, WL_IDX, 1);
        e.mem[_t_12 + 0] = _result_1;
        e.mem[_t_12 + 1] = _result_2;
        e.mem[_t_12 + 2] = _result_3;
        e.mem[_t_12 + 3] = _result_4;
        e.mem[_t_12 + 4] = _result_5;
        e.mem[_t_12 + 5] = _result_6;
        e.mem[_t_12 + 6] = _result_7;
        e.mem[_t_12 + 7] = _result_8;
        e.mem[_t_12 + 8] = _result_9;
        e.mem[_t_12 + 9] = _result_10;
        e.mem[_t_12 + 10] = _result_11;
        e.mem[_t_12 + 11] = _result_12;
        e.mem[_t_12 + 12] = _result_13;
        WL_CONT = term_tsk(FID_RESERVED_K425, _t_12);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _prefix_0;
        e.mem[_t_13 + 1] = term_ctr(CID_SCON, STAT_OFF + 112);
        return term_tsk(FID_STRING_APPEND, _t_13);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 112);
      WL_JMP(FID_STRING_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_K417)
  {
    WL_POPN(15);
    Term _prefix_1 = STK(0);
    u32 _result_21 = STK(1);
    u32 _result_22 = STK(2);
    Term _result_23 = STK(3);
    Term _result_24 = STK(4);
    Term _result_25 = STK(5);
    Term _result_26 = STK(6);
    Term _result_27 = STK(7);
    Term _result_28 = STK(8);
    u32 _result_29 = STK(9);
    Term _result_30 = STK(10);
    u32 _result_31 = STK(11);
    Term _result_32 = STK(12);
    u32 _result_33 = STK(13);
    u32 _result_34 = STK(14);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _prefix_1;
      STK(1) = _result_21;
      STK(2) = _result_22;
      STK(3) = _result_23;
      STK(4) = _result_24;
      STK(5) = _result_25;
      STK(6) = _result_26;
      STK(7) = _result_27;
      STK(8) = _result_28;
      STK(9) = _result_29;
      STK(10) = _result_30;
      STK(11) = _result_31;
      STK(12) = _result_32;
      STK(13) = _result_33;
      STK(14) = _h_0;
      STK(15) = FID_RESERVED_K418;
      WL_PUSHN(16);
    } else {
      u64 _t_2 = task_node(e, FID_RESERVED_K418, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _prefix_1;
      e.mem[_t_2 + 1] = _result_21;
      e.mem[_t_2 + 2] = _result_22;
      e.mem[_t_2 + 3] = _result_23;
      e.mem[_t_2 + 4] = _result_24;
      e.mem[_t_2 + 5] = _result_25;
      e.mem[_t_2 + 6] = _result_26;
      e.mem[_t_2 + 7] = _result_27;
      e.mem[_t_2 + 8] = _result_28;
      e.mem[_t_2 + 9] = _result_29;
      e.mem[_t_2 + 10] = _result_30;
      e.mem[_t_2 + 11] = _result_31;
      e.mem[_t_2 + 12] = _result_32;
      e.mem[_t_2 + 13] = _result_33;
      e.mem[_t_2 + 14] = _h_0;
      WL_CONT = term_tsk(FID_RESERVED_K418, _t_2);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _result_34;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _result_34;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_K418)
  {
    WL_POPN(15);
    Term _prefix_2 = STK(0);
    u32 _result_35 = STK(1);
    u32 _result_36 = STK(2);
    Term _result_37 = STK(3);
    Term _result_38 = STK(4);
    Term _result_39 = STK(5);
    Term _result_40 = STK(6);
    Term _result_41 = STK(7);
    Term _result_42 = STK(8);
    u32 _result_43 = STK(9);
    Term _result_44 = STK(10);
    u32 _result_45 = STK(11);
    Term _result_46 = STK(12);
    u32 _result_47 = STK(13);
    Term _h_2 = STK(14);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _prefix_2;
      STK(1) = _result_35;
      STK(2) = _result_36;
      STK(3) = _result_37;
      STK(4) = _result_38;
      STK(5) = _result_39;
      STK(6) = _result_40;
      STK(7) = _result_41;
      STK(8) = _result_42;
      STK(9) = _result_43;
      STK(10) = _result_44;
      STK(11) = _result_45;
      STK(12) = _result_46;
      STK(13) = _result_47;
      STK(14) = _h_2;
      STK(15) = FID_RESERVED_K419;
      WL_PUSHN(16);
    } else {
      u64 _t_4 = task_node(e, FID_RESERVED_K419, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _prefix_2;
      e.mem[_t_4 + 1] = _result_35;
      e.mem[_t_4 + 2] = _result_36;
      e.mem[_t_4 + 3] = _result_37;
      e.mem[_t_4 + 4] = _result_38;
      e.mem[_t_4 + 5] = _result_39;
      e.mem[_t_4 + 6] = _result_40;
      e.mem[_t_4 + 7] = _result_41;
      e.mem[_t_4 + 8] = _result_42;
      e.mem[_t_4 + 9] = _result_43;
      e.mem[_t_4 + 10] = _result_44;
      e.mem[_t_4 + 11] = _result_45;
      e.mem[_t_4 + 12] = _result_46;
      e.mem[_t_4 + 13] = _result_47;
      e.mem[_t_4 + 14] = _h_2;
      WL_CONT = term_tsk(FID_RESERVED_K419, _t_4);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 28);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_K419)
  {
    WL_POPN(15);
    Term _prefix_3 = STK(0);
    u32 _result_48 = STK(1);
    u32 _result_49 = STK(2);
    Term _result_50 = STK(3);
    Term _result_51 = STK(4);
    Term _result_52 = STK(5);
    Term _result_53 = STK(6);
    Term _result_54 = STK(7);
    Term _result_55 = STK(8);
    u32 _result_56 = STK(9);
    Term _result_57 = STK(10);
    u32 _result_58 = STK(11);
    Term _result_59 = STK(12);
    u32 _result_60 = STK(13);
    Term _h_4 = STK(14);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _prefix_3;
      STK(1) = _result_48;
      STK(2) = _result_49;
      STK(3) = _result_50;
      STK(4) = _result_51;
      STK(5) = _result_52;
      STK(6) = _result_53;
      STK(7) = _result_54;
      STK(8) = _result_55;
      STK(9) = _result_56;
      STK(10) = _result_57;
      STK(11) = _result_58;
      STK(12) = _result_59;
      STK(13) = _result_60;
      STK(14) = FID_RESERVED_K420;
      WL_PUSHN(15);
    } else {
      u64 _t_6 = task_node(e, FID_RESERVED_K420, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _prefix_3;
      e.mem[_t_6 + 1] = _result_48;
      e.mem[_t_6 + 2] = _result_49;
      e.mem[_t_6 + 3] = _result_50;
      e.mem[_t_6 + 4] = _result_51;
      e.mem[_t_6 + 5] = _result_52;
      e.mem[_t_6 + 6] = _result_53;
      e.mem[_t_6 + 7] = _result_54;
      e.mem[_t_6 + 8] = _result_55;
      e.mem[_t_6 + 9] = _result_56;
      e.mem[_t_6 + 10] = _result_57;
      e.mem[_t_6 + 11] = _result_58;
      e.mem[_t_6 + 12] = _result_59;
      e.mem[_t_6 + 13] = _result_60;
      WL_CONT = term_tsk(FID_RESERVED_K420, _t_6);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_K420)
  {
    WL_POPN(14);
    Term _prefix_4 = STK(0);
    u32 _result_61 = STK(1);
    u32 _result_62 = STK(2);
    Term _result_63 = STK(3);
    Term _result_64 = STK(4);
    Term _result_65 = STK(5);
    Term _result_66 = STK(6);
    Term _result_67 = STK(7);
    Term _result_68 = STK(8);
    u32 _result_69 = STK(9);
    Term _result_70 = STK(10);
    u32 _result_71 = STK(11);
    Term _result_72 = STK(12);
    u32 _result_73 = STK(13);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_61;
      STK(1) = _result_62;
      STK(2) = _result_63;
      STK(3) = _result_64;
      STK(4) = _result_65;
      STK(5) = _result_66;
      STK(6) = _result_67;
      STK(7) = _result_68;
      STK(8) = _result_69;
      STK(9) = _result_70;
      STK(10) = _result_71;
      STK(11) = _result_72;
      STK(12) = _result_73;
      STK(13) = FID_RESERVED_K421;
      WL_PUSHN(14);
    } else {
      u64 _t_8 = task_node(e, FID_RESERVED_K421, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _result_61;
      e.mem[_t_8 + 1] = _result_62;
      e.mem[_t_8 + 2] = _result_63;
      e.mem[_t_8 + 3] = _result_64;
      e.mem[_t_8 + 4] = _result_65;
      e.mem[_t_8 + 5] = _result_66;
      e.mem[_t_8 + 6] = _result_67;
      e.mem[_t_8 + 7] = _result_68;
      e.mem[_t_8 + 8] = _result_69;
      e.mem[_t_8 + 9] = _result_70;
      e.mem[_t_8 + 10] = _result_71;
      e.mem[_t_8 + 11] = _result_72;
      e.mem[_t_8 + 12] = _result_73;
      WL_CONT = term_tsk(FID_RESERVED_K421, _t_8);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _prefix_4;
      e.mem[_t_9 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _prefix_4;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_K421)
  {
    WL_POPN(13);
    u32 _result_74 = STK(0);
    u32 _result_75 = STK(1);
    Term _result_76 = STK(2);
    Term _result_77 = STK(3);
    Term _result_78 = STK(4);
    Term _result_79 = STK(5);
    Term _result_80 = STK(6);
    Term _result_81 = STK(7);
    u32 _result_82 = STK(8);
    Term _result_83 = STK(9);
    u32 _result_84 = STK(10);
    Term _result_85 = STK(11);
    u32 _result_86 = STK(12);
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_0 + 0] = _result_74;
    e.mem[_nd_0 + 1] = _result_75;
    e.mem[_nd_0 + 2] = _result_76;
    e.mem[_nd_0 + 3] = _result_77;
    e.mem[_nd_0 + 4] = _result_78;
    e.mem[_nd_0 + 5] = _result_79;
    e.mem[_nd_0 + 6] = _result_80;
    e.mem[_nd_0 + 7] = _result_81;
    e.mem[_nd_0 + 8] = _result_82;
    e.mem[_nd_0 + 9] = _result_83;
    e.mem[_nd_0 + 10] = _result_84;
    e.mem[_nd_0 + 11] = _result_85;
    e.mem[_nd_0 + 12] = _result_86;
    e.mem[_nd_0 + 13] = _h_6;
    r0 = term_clo(FID_RESERVED_C422, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_C422)
  {
    u32 _result_87 = r0;
    u32 _result_88 = r1;
    Term _result_89 = r2;
    Term _result_90 = r3;
    Term _result_91 = r4;
    Term _result_92 = r5;
    Term _result_93 = r6;
    Term _result_94 = r7;
    u32 _result_95 = r8;
    Term _result_96 = r9;
    u32 _result_97 = r10;
    Term _result_98 = r11;
    u32 _result_99 = r12;
    Term _h_7 = r13;
    Term _x_0 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_7;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _result_87;
    e.mem[_nd_2 + 1] = _result_88;
    e.mem[_nd_2 + 2] = _result_89;
    e.mem[_nd_2 + 3] = _result_90;
    e.mem[_nd_2 + 4] = _result_91;
    e.mem[_nd_2 + 5] = _result_92;
    e.mem[_nd_2 + 6] = _result_93;
    e.mem[_nd_2 + 7] = _result_94;
    e.mem[_nd_2 + 8] = _result_95;
    e.mem[_nd_2 + 9] = _result_96;
    e.mem[_nd_2 + 10] = _result_97;
    e.mem[_nd_2 + 11] = _result_98;
    e.mem[_nd_2 + 12] = _result_99;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_11 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_11 + 1] = term_clo(FID_RESERVED_C423, _nd_2);
      e.mem[_t_11 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_11);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_RESERVED_C423, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_C423)
  {
    u32 _result_100 = r0;
    u32 _result_101 = r1;
    Term _result_102 = r2;
    Term _result_103 = r3;
    Term _result_104 = r4;
    Term _result_105 = r5;
    Term _result_106 = r6;
    Term _result_107 = r7;
    u32 _result_108 = r8;
    Term _result_109 = r9;
    u32 _result_110 = r10;
    Term _result_111 = r11;
    u32 _result_112 = r12;
    Term _x_1 = r13;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_3 + 0] = _result_100;
    e.mem[_nd_3 + 1] = _result_101;
    e.mem[_nd_3 + 2] = _result_102;
    e.mem[_nd_3 + 3] = _result_103;
    e.mem[_nd_3 + 4] = _result_104;
    e.mem[_nd_3 + 5] = _result_105;
    e.mem[_nd_3 + 6] = _result_106;
    e.mem[_nd_3 + 7] = _result_107;
    e.mem[_nd_3 + 8] = _result_108;
    e.mem[_nd_3 + 9] = _result_109;
    e.mem[_nd_3 + 10] = _result_110;
    e.mem[_nd_3 + 11] = _result_111;
    e.mem[_nd_3 + 12] = _result_112;
    r0 = term_clo(FID_RESERVED_C424, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_C424)
  {
    u32 _result_113 = r0;
    u32 _result_114 = r1;
    Term _result_115 = r2;
    Term _result_116 = r3;
    Term _result_117 = r4;
    Term _result_118 = r5;
    Term _result_119 = r6;
    Term _result_120 = r7;
    u32 _result_121 = r8;
    Term _result_122 = r9;
    u32 _result_123 = r10;
    Term _result_124 = r11;
    u32 _result_125 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_result_125 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_113);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_114);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_115);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_116);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_117);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_118);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_119);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_120);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_121);
    e.mem[_nd_4 + 9] = rfc_seal(e, _result_122);
    e.mem[_nd_4 + 10] = rfc_seal(e, _result_123);
    e.mem[_nd_4 + 11] = rfc_seal(e, _result_124);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_4 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_10 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_4);
      e.mem[_t_10 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_10);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_K425)
  {
    WL_POPN(13);
    u32 _result_126 = STK(0);
    u32 _result_127 = STK(1);
    Term _result_128 = STK(2);
    Term _result_129 = STK(3);
    Term _result_130 = STK(4);
    Term _result_131 = STK(5);
    Term _result_132 = STK(6);
    Term _result_133 = STK(7);
    u32 _result_134 = STK(8);
    Term _result_135 = STK(9);
    u32 _result_136 = STK(10);
    Term _result_137 = STK(11);
    u32 _result_138 = STK(12);
    Term _h_8 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_5 + 0] = _result_126;
    e.mem[_nd_5 + 1] = _result_127;
    e.mem[_nd_5 + 2] = _result_128;
    e.mem[_nd_5 + 3] = _result_129;
    e.mem[_nd_5 + 4] = _result_130;
    e.mem[_nd_5 + 5] = _result_131;
    e.mem[_nd_5 + 6] = _result_132;
    e.mem[_nd_5 + 7] = _result_133;
    e.mem[_nd_5 + 8] = _result_134;
    e.mem[_nd_5 + 9] = _result_135;
    e.mem[_nd_5 + 10] = _result_136;
    e.mem[_nd_5 + 11] = _result_137;
    e.mem[_nd_5 + 12] = _result_138;
    e.mem[_nd_5 + 13] = _h_8;
    r0 = term_clo(FID_RESERVED_C426, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_C426)
  {
    u32 _result_139 = r0;
    u32 _result_140 = r1;
    Term _result_141 = r2;
    Term _result_142 = r3;
    Term _result_143 = r4;
    Term _result_144 = r5;
    Term _result_145 = r6;
    Term _result_146 = r7;
    u32 _result_147 = r8;
    Term _result_148 = r9;
    u32 _result_149 = r10;
    Term _result_150 = r11;
    u32 _result_151 = r12;
    Term _h_9 = r13;
    Term _x_3 = r14;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_9;
    u64 _nd_7 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_7 + 0] = _result_139;
    e.mem[_nd_7 + 1] = _result_140;
    e.mem[_nd_7 + 2] = _result_141;
    e.mem[_nd_7 + 3] = _result_142;
    e.mem[_nd_7 + 4] = _result_143;
    e.mem[_nd_7 + 5] = _result_144;
    e.mem[_nd_7 + 6] = _result_145;
    e.mem[_nd_7 + 7] = _result_146;
    e.mem[_nd_7 + 8] = _result_147;
    e.mem[_nd_7 + 9] = _result_148;
    e.mem[_nd_7 + 10] = _result_149;
    e.mem[_nd_7 + 11] = _result_150;
    e.mem[_nd_7 + 12] = _result_151;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_15 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_15 + 1] = term_clo(FID_RESERVED_C427, _nd_7);
      e.mem[_t_15 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_15);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_RESERVED_C427, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_C427)
  {
    u32 _result_152 = r0;
    u32 _result_153 = r1;
    Term _result_154 = r2;
    Term _result_155 = r3;
    Term _result_156 = r4;
    Term _result_157 = r5;
    Term _result_158 = r6;
    Term _result_159 = r7;
    u32 _result_160 = r8;
    Term _result_161 = r9;
    u32 _result_162 = r10;
    Term _result_163 = r11;
    u32 _result_164 = r12;
    Term _x_4 = r13;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_8 + 0] = _result_152;
    e.mem[_nd_8 + 1] = _result_153;
    e.mem[_nd_8 + 2] = _result_154;
    e.mem[_nd_8 + 3] = _result_155;
    e.mem[_nd_8 + 4] = _result_156;
    e.mem[_nd_8 + 5] = _result_157;
    e.mem[_nd_8 + 6] = _result_158;
    e.mem[_nd_8 + 7] = _result_159;
    e.mem[_nd_8 + 8] = _result_160;
    e.mem[_nd_8 + 9] = _result_161;
    e.mem[_nd_8 + 10] = _result_162;
    e.mem[_nd_8 + 11] = _result_163;
    e.mem[_nd_8 + 12] = _result_164;
    r0 = term_clo(FID_RESERVED_C428, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESERVED_C428)
  {
    u32 _result_165 = r0;
    u32 _result_166 = r1;
    Term _result_167 = r2;
    Term _result_168 = r3;
    Term _result_169 = r4;
    Term _result_170 = r5;
    Term _result_171 = r6;
    Term _result_172 = r7;
    u32 _result_173 = r8;
    Term _result_174 = r9;
    u32 _result_175 = r10;
    Term _result_176 = r11;
    u32 _result_177 = r12;
    Term _x_5 = r13;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_result_177 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      _o_3 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_9 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_9 + 0] = rfc_seal(e, _result_165);
    e.mem[_nd_9 + 1] = rfc_seal(e, _result_166);
    e.mem[_nd_9 + 2] = rfc_seal(e, _result_167);
    e.mem[_nd_9 + 3] = rfc_seal(e, _result_168);
    e.mem[_nd_9 + 4] = rfc_seal(e, _result_169);
    e.mem[_nd_9 + 5] = rfc_seal(e, _result_170);
    e.mem[_nd_9 + 6] = rfc_seal(e, _result_171);
    e.mem[_nd_9 + 7] = rfc_seal(e, _result_172);
    e.mem[_nd_9 + 8] = rfc_seal(e, _result_173);
    e.mem[_nd_9 + 9] = rfc_seal(e, _result_174);
    e.mem[_nd_9 + 10] = rfc_seal(e, _result_175);
    e.mem[_nd_9 + 11] = rfc_seal(e, _result_176);
    e.mem[_nd_9 + 12] = rfc_seal(e, _o_2);
    e.mem[_nd_9 + 13] = rfc_seal(e, _o_3);
    e.mem[_nd_9 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_14 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_9);
      e.mem[_t_14 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_14);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_9);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C430, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C430, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C430)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K431;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K431, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K431, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K431)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    Term _fv_0[2];
    _fv_0[0] = 0;
    _fv_0[1] = 0;
    Term _fv_1[2];
    _fv_1[0] = 0;
    _fv_1[1] = 0;
    Term _fv_2[1];
    _fv_2[0] = 0;
    Term _fv_3[2];
    _fv_3[0] = 0;
    _fv_3[1] = 0;
    Term _fv_4[1];
    _fv_4[0] = 0ull;
    Term _fv_5[1];
    _fv_5[0] = 0ull;
    u32 _world_0 = 7ull;
    u32 _world_1 = 1ull;
    Term _world_2 = blk_new(e, 1, 0, 1, 2, _fv_0);
    Term _world_3 = blk_new(e, 1, 0, 1, 2, _fv_1);
    Term _world_4 = blk_new(e, 0, 0, 0, 1, _fv_2);
    Term _world_5 = blk_new(e, 1, 0, 1, 2, _fv_3);
    Term _world_6 = blk_new(e, 0, 0, 0, 1, _fv_4);
    Term _world_7 = blk_new(e, 0, 0, 0, 1, _fv_5);
    u32 _world_8 = 1ull;
    Term _world_9 = 0;
    u32 _world_10 = 0ull;
    Term _world_11 = term_pak(CID_NIL, 0);
    u32 _world_12 = 0;
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _fv_6[1];
    _fv_6[0] = 10ull;
    Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_6);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, U32_BIN(10ull, +, 1ull));
    Term _at_2 = blk_loc(e.mem, _a_0);
    Term _at_3 = blk_at(_a_0, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, U32_BIN(10ull, +, 2ull));
    Term _at_4 = blk_loc(e.mem, _a_0);
    Term _at_5 = blk_at(_a_0, 3ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, U32_BIN(10ull, +, 3ull));
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _a_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, 10ull);
    Term _fv_7[1];
    _fv_7[0] = 110ull;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_7);
    Term _at_6 = blk_loc(e.mem, _a_1);
    Term _at_7 = blk_at(_a_1, 1ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, U32_BIN(110ull, +, 1ull));
    Term _at_8 = blk_loc(e.mem, _a_1);
    Term _at_9 = blk_at(_a_1, 2ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, U32_BIN(110ull, +, 2ull));
    Term _at_10 = blk_loc(e.mem, _a_1);
    Term _at_11 = blk_at(_a_1, 3ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, U32_BIN(110ull, +, 3ull));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _a_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, 110ull);
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_world_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    Term _o_9[22];
    Term _a_4 = term_pak(CID_UNIT, 0);
    Term _a_5 = term_ctr(CID_OWNERS_MOTION, _nd_0);
    Term _a_6 = term_ctr(CID_OWNERS_HEALTH, _nd_1);
    Term _a_7 = term_pak(CID_UNIT, 0);
    if (spin_115(e, _o_9, _world_0, _world_1, _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, blk_loc(e.mem, _world_11), _o_0, _o_1, blk_loc(e.mem, _o_1), _a_4, blk_loc(e.mem, _a_4), 1, _a_5, blk_loc(e.mem, _a_5), 1, _a_6, blk_loc(e.mem, _a_6), 1, _a_7, blk_loc(e.mem, _a_7)) == 0) {
      return 0;
    }
    _v_22 = _o_9[0];
    _v_23 = _o_9[1];
    _v_24 = _o_9[2];
    _v_25 = _o_9[3];
    _v_26 = _o_9[4];
    _v_27 = _o_9[5];
    _v_28 = _o_9[6];
    _v_29 = _o_9[7];
    _v_30 = _o_9[8];
    _v_31 = _o_9[9];
    _v_32 = _o_9[10];
    _v_33 = _o_9[11];
    _v_34 = _o_9[12];
    _v_35 = _o_9[13];
    _v_36 = _o_9[14];
    _v_37 = _o_9[15];
    _v_38 = _o_9[16];
    _v_39 = _o_9[17];
    _v_40 = _o_9[18];
    _v_41 = _o_9[19];
    _v_42 = _o_9[20];
    _v_43 = _o_9[21];
    _v_0 = _v_22;
    _v_1 = _v_23;
    _v_2 = _v_24;
    _v_3 = _v_25;
    _v_4 = _v_26;
    _v_5 = _v_27;
    _v_6 = _v_28;
    _v_7 = _v_29;
    _v_8 = _v_30;
    _v_9 = _v_31;
    _v_10 = _v_32;
    _v_11 = _v_33;
    _v_12 = _v_34;
    _v_13 = _v_35;
    _v_14 = _v_36;
    _v_15 = _v_37;
    _v_16 = _v_38;
    _v_17 = _v_39;
    _v_18 = _v_40;
    _v_19 = _v_41;
    _v_20 = _v_42;
    _v_21 = _v_43;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    u32 _o_12 = 0;
    Term _o_13 = 0;
    Term _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    Term _o_17 = 0;
    Term _o_18 = 0;
    u32 _o_19 = 0;
    Term _o_20 = 0;
    u32 _o_21 = 0;
    Term _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    Term _o_25 = 0;
    u32 _o_26 = 0;
    u32 _o_27 = 0;
    Term _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    if (_v_0 == 0) {
      _o_10 = 0;
      u32 _o_31 = 0;
      if (_v_13 == 0) {
        _o_31 = 0;
      } else {
        _o_31 = 1;
      }
      _o_11 = _v_1;
      _o_12 = _v_2;
      _o_13 = _v_3;
      _o_14 = _v_4;
      _o_15 = _v_5;
      _o_16 = _v_6;
      _o_17 = _v_7;
      _o_18 = _v_8;
      _o_19 = _v_9;
      _o_20 = _v_10;
      _o_21 = _v_11;
      _o_22 = _v_12;
      _o_23 = _o_31;
      _o_24 = _v_16;
      _o_25 = _v_17;
    } else {
      _o_10 = 1;
      u32 _o_32 = 0;
      if (_v_13 == 0) {
        _o_32 = 0;
      } else {
        _o_32 = 1;
      }
      u32 _o_33 = 0;
      Term _o_34 = 0;
      u32 _o_35 = 0;
      if (_v_16 == 0) {
        _o_33 = 0;
      } else {
        _o_33 = 1;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _v_17, 2, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_34 = _f_2;
        _o_35 = _f_3;
      }
      u32 _o_36 = 0;
      Term _o_37 = 0;
      u32 _o_38 = 0;
      if (_v_18 == 0) {
        _o_36 = 0;
      } else {
        _o_36 = 1;
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _v_19, 2, _fb_2);
        Term _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        _o_37 = _f_4;
        _o_38 = _f_5;
      }
      u32 _o_39 = 0;
      if (_v_20 == 0) {
        _o_39 = 0;
      } else {
        _o_39 = 1;
      }
      _o_11 = _v_1;
      _o_12 = _v_2;
      _o_13 = _v_3;
      _o_14 = _v_4;
      _o_15 = _v_5;
      _o_16 = _v_6;
      _o_17 = _v_7;
      _o_18 = _v_8;
      _o_19 = _v_9;
      _o_20 = _v_10;
      _o_21 = _v_11;
      _o_22 = _v_12;
      _o_23 = _o_32;
      _o_24 = _o_33;
      _o_25 = _o_34;
      _o_26 = _o_35;
      _o_27 = _o_36;
      _o_28 = _o_37;
      _o_29 = _o_38;
      _o_30 = _o_39;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K434;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K434, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K434, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RESERVED)) {
      u64 _t_1 = task_node(e, FID_RESERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 170);
      e.mem[_t_1 + 1] = _o_10;
      e.mem[_t_1 + 2] = _o_11;
      e.mem[_t_1 + 3] = _o_12;
      e.mem[_t_1 + 4] = _o_13;
      e.mem[_t_1 + 5] = _o_14;
      e.mem[_t_1 + 6] = _o_15;
      e.mem[_t_1 + 7] = _o_16;
      e.mem[_t_1 + 8] = _o_17;
      e.mem[_t_1 + 9] = _o_18;
      e.mem[_t_1 + 10] = _o_19;
      e.mem[_t_1 + 11] = _o_20;
      e.mem[_t_1 + 12] = _o_21;
      e.mem[_t_1 + 13] = _o_22;
      e.mem[_t_1 + 14] = _o_23;
      e.mem[_t_1 + 15] = _o_24;
      e.mem[_t_1 + 16] = _o_25;
      e.mem[_t_1 + 17] = _o_26;
      e.mem[_t_1 + 18] = _o_27;
      e.mem[_t_1 + 19] = _o_28;
      e.mem[_t_1 + 20] = _o_29;
      e.mem[_t_1 + 21] = _o_30;
      return term_tsk(FID_RESERVED, _t_1);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 170);
    r1 = _o_10;
    r2 = _o_11;
    r3 = _o_12;
    r4 = _o_13;
    r5 = _o_14;
    r6 = _o_15;
    r7 = _o_16;
    r8 = _o_17;
    r9 = _o_18;
    r10 = _o_19;
    r11 = _o_20;
    r12 = _o_21;
    r13 = _o_22;
    r14 = _o_23;
    r15 = _o_24;
    r16 = _o_25;
    r17 = _o_26;
    r18 = _o_27;
    r19 = _o_28;
    r20 = _o_29;
    r21 = _o_30;
    WL_JMP(FID_RESERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K434)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_5 + 0] = _h_0;
    r0 = term_clo(FID_MAIN_C435, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C435)
  {
    Term _h_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_134 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_134 + 0] = _h_1;
      e.mem[_t_134 + 1] = term_clo(FID_MAIN_C436, 0);
      e.mem[_t_134 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_134);
    }
    r0 = _h_1;
    r1 = term_clo(FID_MAIN_C436, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C436)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_3[15];
    u64 _sp_3 = ctr_take(e, _x_1, 15, _fb_3);
    u32 _f_6 = _fb_3[0];
    u32 _f_7 = _fb_3[1];
    Term _f_8 = _fb_3[2];
    Term _f_9 = _fb_3[3];
    Term _f_10 = _fb_3[4];
    Term _f_11 = _fb_3[5];
    Term _f_12 = _fb_3[6];
    Term _f_13 = _fb_3[7];
    u32 _f_14 = _fb_3[8];
    Term _f_15 = _fb_3[9];
    u32 _f_16 = _fb_3[10];
    Term _f_17 = _fb_3[11];
    u32 _f_18 = _fb_3[12];
    Term _f_19 = _fb_3[13];
    Term _f_20 = _fb_3[14];
    spare_free(e, cls_fit(15), _sp_3);
    u32 _o_40 = 0;
    if (_f_18 == 0) {
      _o_40 = 0;
    } else {
      _o_40 = 1;
    }
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    Term _v_255 = 0;
    Term _v_256 = 0;
    Term _v_257 = 0;
    Term _v_258 = 0;
    Term _v_259 = 0;
    Term _v_260 = 0;
    u32 _v_261 = 0;
    Term _v_262 = 0;
    u32 _v_263 = 0;
    Term _v_264 = 0;
    u32 _v_265 = 0;
    Term _v_266 = 0;
    Term _v_267 = 0;
    u32 _v_268 = 0;
    Term _v_269 = 0;
    u32 _v_270 = 0;
    Term _v_271 = 0;
    u32 _v_272 = 0;
    Term _v_273 = 0;
    Term _fv_8[1];
    _fv_8[0] = 120ull;
    Term _a_8 = blk_new(e, 0, 2ull, 0, 1, _fv_8);
    Term _at_12 = blk_loc(e.mem, _a_8);
    Term _at_13 = blk_at(_a_8, 1ull, 0);
    u32 _c_6 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, U32_BIN(120ull, +, 1ull));
    Term _at_14 = blk_loc(e.mem, _a_8);
    Term _at_15 = blk_at(_a_8, 2ull, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, U32_BIN(120ull, +, 2ull));
    Term _at_16 = blk_loc(e.mem, _a_8);
    Term _at_17 = blk_at(_a_8, 3ull, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_16, _at_17 + 0);
    blk_write(e.mem, 0, _at_16, _at_17 + 0, U32_BIN(120ull, +, 3ull));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _a_8);
    e.mem[_nd_6 + 1] = rfc_seal(e, 120ull);
    u32 _o_41 = 0;
    Term _o_42 = 0;
    if (_o_40 == 0) {
      _o_41 = 0;
    } else {
      _o_41 = 1;
      _o_42 = term_pak(CID_UNIT, 0);
    }
    u32 _v_274 = 0;
    u32 _v_275 = 0;
    u32 _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    Term _v_280 = 0;
    Term _v_281 = 0;
    Term _v_282 = 0;
    u32 _v_283 = 0;
    Term _v_284 = 0;
    u32 _v_285 = 0;
    Term _v_286 = 0;
    u32 _v_287 = 0;
    Term _v_288 = 0;
    Term _v_289 = 0;
    u32 _v_290 = 0;
    Term _v_291 = 0;
    u32 _v_292 = 0;
    Term _v_293 = 0;
    u32 _v_294 = 0;
    Term _v_295 = 0;
    Term _o_43[22];
    Term _a_9 = term_pak(CID_UNIT, 0);
    Term _a_10 = 0;
    Term _a_11 = term_ctr(CID_OWNERS_HEALTH, _nd_6);
    Term _a_12 = 0;
    if (spin_115(e, _o_43, _f_6, _f_7, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, blk_loc(e.mem, _f_11), _f_12, blk_loc(e.mem, _f_12), _f_13, blk_loc(e.mem, _f_13), _f_14, _f_15, _f_16, _f_17, blk_loc(e.mem, _f_17), _o_41, _o_42, blk_loc(e.mem, _o_42), _a_9, blk_loc(e.mem, _a_9), 0, _a_10, blk_loc(e.mem, _a_10), 1, _a_11, blk_loc(e.mem, _a_11), 0, _a_12, blk_loc(e.mem, _a_12)) == 0) {
      return 0;
    }
    _v_274 = _o_43[0];
    _v_275 = _o_43[1];
    _v_276 = _o_43[2];
    _v_277 = _o_43[3];
    _v_278 = _o_43[4];
    _v_279 = _o_43[5];
    _v_280 = _o_43[6];
    _v_281 = _o_43[7];
    _v_282 = _o_43[8];
    _v_283 = _o_43[9];
    _v_284 = _o_43[10];
    _v_285 = _o_43[11];
    _v_286 = _o_43[12];
    _v_287 = _o_43[13];
    _v_288 = _o_43[14];
    _v_289 = _o_43[15];
    _v_290 = _o_43[16];
    _v_291 = _o_43[17];
    _v_292 = _o_43[18];
    _v_293 = _o_43[19];
    _v_294 = _o_43[20];
    _v_295 = _o_43[21];
    _v_252 = _v_274;
    _v_253 = _v_275;
    _v_254 = _v_276;
    _v_255 = _v_277;
    _v_256 = _v_278;
    _v_257 = _v_279;
    _v_258 = _v_280;
    _v_259 = _v_281;
    _v_260 = _v_282;
    _v_261 = _v_283;
    _v_262 = _v_284;
    _v_263 = _v_285;
    _v_264 = _v_286;
    _v_265 = _v_287;
    _v_266 = _v_288;
    _v_267 = _v_289;
    _v_268 = _v_290;
    _v_269 = _v_291;
    _v_270 = _v_292;
    _v_271 = _v_293;
    _v_272 = _v_294;
    _v_273 = _v_295;
    u32 _o_44 = 0;
    u32 _o_45 = 0;
    u32 _o_46 = 0;
    Term _o_47 = 0;
    Term _o_48 = 0;
    Term _o_49 = 0;
    Term _o_50 = 0;
    Term _o_51 = 0;
    Term _o_52 = 0;
    u32 _o_53 = 0;
    Term _o_54 = 0;
    u32 _o_55 = 0;
    Term _o_56 = 0;
    u32 _o_57 = 0;
    u32 _o_58 = 0;
    Term _o_59 = 0;
    u32 _o_60 = 0;
    u32 _o_61 = 0;
    Term _o_62 = 0;
    u32 _o_63 = 0;
    u32 _o_64 = 0;
    if (_v_252 == 0) {
      _o_44 = 0;
      u32 _o_65 = 0;
      if (_v_265 == 0) {
        _o_65 = 0;
      } else {
        _o_65 = 1;
      }
      _o_45 = _v_253;
      _o_46 = _v_254;
      _o_47 = _v_255;
      _o_48 = _v_256;
      _o_49 = _v_257;
      _o_50 = _v_258;
      _o_51 = _v_259;
      _o_52 = _v_260;
      _o_53 = _v_261;
      _o_54 = _v_262;
      _o_55 = _v_263;
      _o_56 = _v_264;
      _o_57 = _o_65;
      _o_58 = _v_268;
      _o_59 = _v_269;
    } else {
      _o_44 = 1;
      u32 _o_66 = 0;
      if (_v_265 == 0) {
        _o_66 = 0;
      } else {
        _o_66 = 1;
      }
      u32 _o_67 = 0;
      Term _o_68 = 0;
      u32 _o_69 = 0;
      if (_v_268 == 0) {
        _o_67 = 0;
      } else {
        _o_67 = 1;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _v_269, 2, _fb_4);
        Term _f_21 = _fb_4[0];
        u32 _f_22 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        _o_68 = _f_21;
        _o_69 = _f_22;
      }
      u32 _o_70 = 0;
      Term _o_71 = 0;
      u32 _o_72 = 0;
      if (_v_270 == 0) {
        _o_70 = 0;
      } else {
        _o_70 = 1;
        Term _fb_5[2];
        u64 _sp_5 = ctr_take(e, _v_271, 2, _fb_5);
        Term _f_23 = _fb_5[0];
        u32 _f_24 = _fb_5[1];
        spare_free(e, cls_fit(2), _sp_5);
        _o_71 = _f_23;
        _o_72 = _f_24;
      }
      u32 _o_73 = 0;
      if (_v_272 == 0) {
        _o_73 = 0;
      } else {
        _o_73 = 1;
      }
      _o_45 = _v_253;
      _o_46 = _v_254;
      _o_47 = _v_255;
      _o_48 = _v_256;
      _o_49 = _v_257;
      _o_50 = _v_258;
      _o_51 = _v_259;
      _o_52 = _v_260;
      _o_53 = _v_261;
      _o_54 = _v_262;
      _o_55 = _v_263;
      _o_56 = _v_264;
      _o_57 = _o_66;
      _o_58 = _o_67;
      _o_59 = _o_68;
      _o_60 = _o_69;
      _o_61 = _o_70;
      _o_62 = _o_71;
      _o_63 = _o_72;
      _o_64 = _o_73;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K437;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K437, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K437, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RESERVED)) {
      u64 _t_3 = task_node(e, FID_RESERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 182);
      e.mem[_t_3 + 1] = _o_44;
      e.mem[_t_3 + 2] = _o_45;
      e.mem[_t_3 + 3] = _o_46;
      e.mem[_t_3 + 4] = _o_47;
      e.mem[_t_3 + 5] = _o_48;
      e.mem[_t_3 + 6] = _o_49;
      e.mem[_t_3 + 7] = _o_50;
      e.mem[_t_3 + 8] = _o_51;
      e.mem[_t_3 + 9] = _o_52;
      e.mem[_t_3 + 10] = _o_53;
      e.mem[_t_3 + 11] = _o_54;
      e.mem[_t_3 + 12] = _o_55;
      e.mem[_t_3 + 13] = _o_56;
      e.mem[_t_3 + 14] = _o_57;
      e.mem[_t_3 + 15] = _o_58;
      e.mem[_t_3 + 16] = _o_59;
      e.mem[_t_3 + 17] = _o_60;
      e.mem[_t_3 + 18] = _o_61;
      e.mem[_t_3 + 19] = _o_62;
      e.mem[_t_3 + 20] = _o_63;
      e.mem[_t_3 + 21] = _o_64;
      return term_tsk(FID_RESERVED, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 182);
    r1 = _o_44;
    r2 = _o_45;
    r3 = _o_46;
    r4 = _o_47;
    r5 = _o_48;
    r6 = _o_49;
    r7 = _o_50;
    r8 = _o_51;
    r9 = _o_52;
    r10 = _o_53;
    r11 = _o_54;
    r12 = _o_55;
    r13 = _o_56;
    r14 = _o_57;
    r15 = _o_58;
    r16 = _o_59;
    r17 = _o_60;
    r18 = _o_61;
    r19 = _o_62;
    r20 = _o_63;
    r21 = _o_64;
    WL_JMP(FID_RESERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K437)
  {
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_7 + 0] = _h_2;
    r0 = term_clo(FID_MAIN_C438, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C438)
  {
    Term _h_3 = r0;
    Term _x_2 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_133 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_133 + 0] = _h_3;
      e.mem[_t_133 + 1] = term_clo(FID_MAIN_C439, 0);
      e.mem[_t_133 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_133);
    }
    r0 = _h_3;
    r1 = term_clo(FID_MAIN_C439, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C439)
  {
    Term _x_3 = r0;
    WL_OPEN
    Term _fb_6[15];
    u64 _sp_6 = ctr_take(e, _x_3, 15, _fb_6);
    u32 _f_25 = _fb_6[0];
    u32 _f_26 = _fb_6[1];
    Term _f_27 = _fb_6[2];
    Term _f_28 = _fb_6[3];
    Term _f_29 = _fb_6[4];
    Term _f_30 = _fb_6[5];
    Term _f_31 = _fb_6[6];
    Term _f_32 = _fb_6[7];
    u32 _f_33 = _fb_6[8];
    Term _f_34 = _fb_6[9];
    u32 _f_35 = _fb_6[10];
    Term _f_36 = _fb_6[11];
    u32 _f_37 = _fb_6[12];
    Term _f_38 = _fb_6[13];
    Term _f_39 = _fb_6[14];
    spare_free(e, cls_fit(15), _sp_6);
    u32 _o_74 = 0;
    if (_f_37 == 0) {
      _o_74 = 0;
    } else {
      _o_74 = 1;
    }
    u32 _v_296 = 0;
    u32 _v_297 = 0;
    u32 _v_298 = 0;
    Term _v_299 = 0;
    Term _v_300 = 0;
    Term _v_301 = 0;
    Term _v_302 = 0;
    Term _v_303 = 0;
    Term _v_304 = 0;
    u32 _v_305 = 0;
    Term _v_306 = 0;
    u32 _v_307 = 0;
    Term _v_308 = 0;
    u32 _v_309 = 0;
    Term _v_310 = 0;
    Term _v_311 = 0;
    u32 _v_312 = 0;
    Term _v_313 = 0;
    u32 _v_314 = 0;
    Term _v_315 = 0;
    u32 _v_316 = 0;
    Term _v_317 = 0;
    Term _fv_9[1];
    _fv_9[0] = 30ull;
    Term _a_13 = blk_new(e, 0, 2ull, 0, 1, _fv_9);
    Term _at_18 = blk_loc(e.mem, _a_13);
    Term _at_19 = blk_at(_a_13, 1ull, 0);
    u32 _c_9 = blk_read(e.mem, 0, _at_18, _at_19 + 0);
    blk_write(e.mem, 0, _at_18, _at_19 + 0, U32_BIN(30ull, +, 1ull));
    Term _at_20 = blk_loc(e.mem, _a_13);
    Term _at_21 = blk_at(_a_13, 2ull, 0);
    u32 _c_10 = blk_read(e.mem, 0, _at_20, _at_21 + 0);
    blk_write(e.mem, 0, _at_20, _at_21 + 0, U32_BIN(30ull, +, 2ull));
    Term _at_22 = blk_loc(e.mem, _a_13);
    Term _at_23 = blk_at(_a_13, 3ull, 0);
    u32 _c_11 = blk_read(e.mem, 0, _at_22, _at_23 + 0);
    blk_write(e.mem, 0, _at_22, _at_23 + 0, U32_BIN(30ull, +, 3ull));
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _a_13);
    e.mem[_nd_8 + 1] = rfc_seal(e, 30ull);
    u32 _o_75 = 0;
    Term _o_76 = 0;
    if (_o_74 == 0) {
      _o_75 = 0;
    } else {
      _o_75 = 1;
      _o_76 = term_pak(CID_UNIT, 0);
    }
    u32 _v_318 = 0;
    u32 _v_319 = 0;
    u32 _v_320 = 0;
    Term _v_321 = 0;
    Term _v_322 = 0;
    Term _v_323 = 0;
    Term _v_324 = 0;
    Term _v_325 = 0;
    Term _v_326 = 0;
    u32 _v_327 = 0;
    Term _v_328 = 0;
    u32 _v_329 = 0;
    Term _v_330 = 0;
    u32 _v_331 = 0;
    Term _v_332 = 0;
    Term _v_333 = 0;
    u32 _v_334 = 0;
    Term _v_335 = 0;
    u32 _v_336 = 0;
    Term _v_337 = 0;
    u32 _v_338 = 0;
    Term _v_339 = 0;
    Term _o_77[22];
    Term _a_14 = term_pak(CID_UNIT, 0);
    Term _a_15 = term_ctr(CID_OWNERS_MOTION, _nd_8);
    Term _a_16 = 0;
    Term _a_17 = 0;
    if (spin_115(e, _o_77, _f_25, _f_26, _f_27, blk_loc(e.mem, _f_27), _f_28, blk_loc(e.mem, _f_28), _f_29, blk_loc(e.mem, _f_29), _f_30, blk_loc(e.mem, _f_30), _f_31, blk_loc(e.mem, _f_31), _f_32, blk_loc(e.mem, _f_32), _f_33, _f_34, _f_35, _f_36, blk_loc(e.mem, _f_36), _o_75, _o_76, blk_loc(e.mem, _o_76), _a_14, blk_loc(e.mem, _a_14), 1, _a_15, blk_loc(e.mem, _a_15), 0, _a_16, blk_loc(e.mem, _a_16), 0, _a_17, blk_loc(e.mem, _a_17)) == 0) {
      return 0;
    }
    _v_318 = _o_77[0];
    _v_319 = _o_77[1];
    _v_320 = _o_77[2];
    _v_321 = _o_77[3];
    _v_322 = _o_77[4];
    _v_323 = _o_77[5];
    _v_324 = _o_77[6];
    _v_325 = _o_77[7];
    _v_326 = _o_77[8];
    _v_327 = _o_77[9];
    _v_328 = _o_77[10];
    _v_329 = _o_77[11];
    _v_330 = _o_77[12];
    _v_331 = _o_77[13];
    _v_332 = _o_77[14];
    _v_333 = _o_77[15];
    _v_334 = _o_77[16];
    _v_335 = _o_77[17];
    _v_336 = _o_77[18];
    _v_337 = _o_77[19];
    _v_338 = _o_77[20];
    _v_339 = _o_77[21];
    _v_296 = _v_318;
    _v_297 = _v_319;
    _v_298 = _v_320;
    _v_299 = _v_321;
    _v_300 = _v_322;
    _v_301 = _v_323;
    _v_302 = _v_324;
    _v_303 = _v_325;
    _v_304 = _v_326;
    _v_305 = _v_327;
    _v_306 = _v_328;
    _v_307 = _v_329;
    _v_308 = _v_330;
    _v_309 = _v_331;
    _v_310 = _v_332;
    _v_311 = _v_333;
    _v_312 = _v_334;
    _v_313 = _v_335;
    _v_314 = _v_336;
    _v_315 = _v_337;
    _v_316 = _v_338;
    _v_317 = _v_339;
    u32 _o_78 = 0;
    u32 _o_79 = 0;
    u32 _o_80 = 0;
    Term _o_81 = 0;
    Term _o_82 = 0;
    Term _o_83 = 0;
    Term _o_84 = 0;
    Term _o_85 = 0;
    Term _o_86 = 0;
    u32 _o_87 = 0;
    Term _o_88 = 0;
    u32 _o_89 = 0;
    Term _o_90 = 0;
    u32 _o_91 = 0;
    u32 _o_92 = 0;
    Term _o_93 = 0;
    u32 _o_94 = 0;
    u32 _o_95 = 0;
    Term _o_96 = 0;
    u32 _o_97 = 0;
    u32 _o_98 = 0;
    if (_v_296 == 0) {
      _o_78 = 0;
      u32 _o_99 = 0;
      if (_v_309 == 0) {
        _o_99 = 0;
      } else {
        _o_99 = 1;
      }
      _o_79 = _v_297;
      _o_80 = _v_298;
      _o_81 = _v_299;
      _o_82 = _v_300;
      _o_83 = _v_301;
      _o_84 = _v_302;
      _o_85 = _v_303;
      _o_86 = _v_304;
      _o_87 = _v_305;
      _o_88 = _v_306;
      _o_89 = _v_307;
      _o_90 = _v_308;
      _o_91 = _o_99;
      _o_92 = _v_312;
      _o_93 = _v_313;
    } else {
      _o_78 = 1;
      u32 _o_100 = 0;
      if (_v_309 == 0) {
        _o_100 = 0;
      } else {
        _o_100 = 1;
      }
      u32 _o_101 = 0;
      Term _o_102 = 0;
      u32 _o_103 = 0;
      if (_v_312 == 0) {
        _o_101 = 0;
      } else {
        _o_101 = 1;
        Term _fb_7[2];
        u64 _sp_7 = ctr_take(e, _v_313, 2, _fb_7);
        Term _f_40 = _fb_7[0];
        u32 _f_41 = _fb_7[1];
        spare_free(e, cls_fit(2), _sp_7);
        _o_102 = _f_40;
        _o_103 = _f_41;
      }
      u32 _o_104 = 0;
      Term _o_105 = 0;
      u32 _o_106 = 0;
      if (_v_314 == 0) {
        _o_104 = 0;
      } else {
        _o_104 = 1;
        Term _fb_8[2];
        u64 _sp_8 = ctr_take(e, _v_315, 2, _fb_8);
        Term _f_42 = _fb_8[0];
        u32 _f_43 = _fb_8[1];
        spare_free(e, cls_fit(2), _sp_8);
        _o_105 = _f_42;
        _o_106 = _f_43;
      }
      u32 _o_107 = 0;
      if (_v_316 == 0) {
        _o_107 = 0;
      } else {
        _o_107 = 1;
      }
      _o_79 = _v_297;
      _o_80 = _v_298;
      _o_81 = _v_299;
      _o_82 = _v_300;
      _o_83 = _v_301;
      _o_84 = _v_302;
      _o_85 = _v_303;
      _o_86 = _v_304;
      _o_87 = _v_305;
      _o_88 = _v_306;
      _o_89 = _v_307;
      _o_90 = _v_308;
      _o_91 = _o_100;
      _o_92 = _o_101;
      _o_93 = _o_102;
      _o_94 = _o_103;
      _o_95 = _o_104;
      _o_96 = _o_105;
      _o_97 = _o_106;
      _o_98 = _o_107;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K440;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K440, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K440, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RESERVED)) {
      u64 _t_5 = task_node(e, FID_RESERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 194);
      e.mem[_t_5 + 1] = _o_78;
      e.mem[_t_5 + 2] = _o_79;
      e.mem[_t_5 + 3] = _o_80;
      e.mem[_t_5 + 4] = _o_81;
      e.mem[_t_5 + 5] = _o_82;
      e.mem[_t_5 + 6] = _o_83;
      e.mem[_t_5 + 7] = _o_84;
      e.mem[_t_5 + 8] = _o_85;
      e.mem[_t_5 + 9] = _o_86;
      e.mem[_t_5 + 10] = _o_87;
      e.mem[_t_5 + 11] = _o_88;
      e.mem[_t_5 + 12] = _o_89;
      e.mem[_t_5 + 13] = _o_90;
      e.mem[_t_5 + 14] = _o_91;
      e.mem[_t_5 + 15] = _o_92;
      e.mem[_t_5 + 16] = _o_93;
      e.mem[_t_5 + 17] = _o_94;
      e.mem[_t_5 + 18] = _o_95;
      e.mem[_t_5 + 19] = _o_96;
      e.mem[_t_5 + 20] = _o_97;
      e.mem[_t_5 + 21] = _o_98;
      return term_tsk(FID_RESERVED, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 194);
    r1 = _o_78;
    r2 = _o_79;
    r3 = _o_80;
    r4 = _o_81;
    r5 = _o_82;
    r6 = _o_83;
    r7 = _o_84;
    r8 = _o_85;
    r9 = _o_86;
    r10 = _o_87;
    r11 = _o_88;
    r12 = _o_89;
    r13 = _o_90;
    r14 = _o_91;
    r15 = _o_92;
    r16 = _o_93;
    r17 = _o_94;
    r18 = _o_95;
    r19 = _o_96;
    r20 = _o_97;
    r21 = _o_98;
    WL_JMP(FID_RESERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K440)
  {
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_9 + 0] = _h_4;
    r0 = term_clo(FID_MAIN_C441, _nd_9);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C441)
  {
    Term _h_5 = r0;
    Term _x_4 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_132 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_132 + 0] = _h_5;
      e.mem[_t_132 + 1] = term_clo(FID_MAIN_C442, 0);
      e.mem[_t_132 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_132);
    }
    r0 = _h_5;
    r1 = term_clo(FID_MAIN_C442, 0);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C442)
  {
    Term _x_5 = r0;
    WL_OPEN
    Term _fb_9[15];
    u64 _sp_9 = ctr_take(e, _x_5, 15, _fb_9);
    u32 _f_44 = _fb_9[0];
    u32 _f_45 = _fb_9[1];
    Term _f_46 = _fb_9[2];
    Term _f_47 = _fb_9[3];
    Term _f_48 = _fb_9[4];
    Term _f_49 = _fb_9[5];
    Term _f_50 = _fb_9[6];
    Term _f_51 = _fb_9[7];
    u32 _f_52 = _fb_9[8];
    Term _f_53 = _fb_9[9];
    u32 _f_54 = _fb_9[10];
    Term _f_55 = _fb_9[11];
    u32 _f_56 = _fb_9[12];
    Term _f_57 = _fb_9[13];
    Term _f_58 = _fb_9[14];
    spare_free(e, cls_fit(15), _sp_9);
    u32 _o_108 = 0;
    if (_f_56 == 0) {
      _o_108 = 0;
    } else {
      _o_108 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K443;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K443, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K443, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_7 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 222);
      e.mem[_t_7 + 1] = 0;
      e.mem[_t_7 + 2] = _f_44;
      e.mem[_t_7 + 3] = _f_45;
      e.mem[_t_7 + 4] = _f_46;
      e.mem[_t_7 + 5] = _f_47;
      e.mem[_t_7 + 6] = _f_48;
      e.mem[_t_7 + 7] = _f_49;
      e.mem[_t_7 + 8] = _f_50;
      e.mem[_t_7 + 9] = _f_51;
      e.mem[_t_7 + 10] = _f_52;
      e.mem[_t_7 + 11] = _f_53;
      e.mem[_t_7 + 12] = _f_54;
      e.mem[_t_7 + 13] = _f_55;
      e.mem[_t_7 + 14] = _o_108;
      return term_tsk(FID_EACH, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 222);
    r1 = 0;
    r2 = _f_44;
    r3 = _f_45;
    r4 = _f_46;
    r5 = _f_47;
    r6 = _f_48;
    r7 = _f_49;
    r8 = _f_50;
    r9 = _f_51;
    r10 = _f_52;
    r11 = _f_53;
    r12 = _f_54;
    r13 = _f_55;
    r14 = _o_108;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K443)
  {
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_10 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_10 + 0] = _h_6;
    r0 = term_clo(FID_MAIN_C444, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C444)
  {
    Term _h_7 = r0;
    Term _x_6 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_131 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_131 + 0] = _h_7;
      e.mem[_t_131 + 1] = term_clo(FID_MAIN_C445, 0);
      e.mem[_t_131 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_131);
    }
    r0 = _h_7;
    r1 = term_clo(FID_MAIN_C445, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C445)
  {
    Term _x_7 = r0;
    WL_OPEN
    Term _fb_10[15];
    u64 _sp_10 = ctr_take(e, _x_7, 15, _fb_10);
    u32 _f_59 = _fb_10[0];
    u32 _f_60 = _fb_10[1];
    Term _f_61 = _fb_10[2];
    Term _f_62 = _fb_10[3];
    Term _f_63 = _fb_10[4];
    Term _f_64 = _fb_10[5];
    Term _f_65 = _fb_10[6];
    Term _f_66 = _fb_10[7];
    u32 _f_67 = _fb_10[8];
    Term _f_68 = _fb_10[9];
    u32 _f_69 = _fb_10[10];
    Term _f_70 = _fb_10[11];
    u32 _f_71 = _fb_10[12];
    Term _f_72 = _fb_10[13];
    Term _f_73 = _fb_10[14];
    spare_free(e, cls_fit(15), _sp_10);
    u32 _o_109 = 0;
    if (_f_71 == 0) {
      _o_109 = 0;
    } else {
      _o_109 = 1;
    }
    u32 _o_110 = 0;
    Term _o_111 = 0;
    if (_o_109 == 0) {
      _o_110 = 0;
    } else {
      _o_110 = 1;
      _o_111 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K446;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K446, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K446, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_APPLY_CHECKED)) {
      u64 _t_9 = task_node(e, FID_COMMANDS_APPLY_CHECKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _f_59;
      e.mem[_t_9 + 1] = _f_60;
      e.mem[_t_9 + 2] = _f_61;
      e.mem[_t_9 + 3] = _f_62;
      e.mem[_t_9 + 4] = _f_63;
      e.mem[_t_9 + 5] = _f_64;
      e.mem[_t_9 + 6] = _f_65;
      e.mem[_t_9 + 7] = _f_66;
      e.mem[_t_9 + 8] = _f_67;
      e.mem[_t_9 + 9] = _f_68;
      e.mem[_t_9 + 10] = _f_69;
      e.mem[_t_9 + 11] = _f_70;
      e.mem[_t_9 + 12] = _o_110;
      e.mem[_t_9 + 13] = _o_111;
      e.mem[_t_9 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_9 + 15] = 10ull;
      return term_tsk(FID_COMMANDS_APPLY_CHECKED, _t_9);
    }
    r0 = _f_59;
    r1 = _f_60;
    r2 = _f_61;
    r3 = _f_62;
    r4 = _f_63;
    r5 = _f_64;
    r6 = _f_65;
    r7 = _f_66;
    r8 = _f_67;
    r9 = _f_68;
    r10 = _f_69;
    r11 = _f_70;
    r12 = _o_110;
    r13 = _o_111;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 10ull;
    WL_JMP(FID_COMMANDS_APPLY_CHECKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K446)
  {
    u32 _h_8 = r0;
    u32 _h_9 = r1;
    u32 _h_10 = r2;
    Term _h_11 = r3;
    Term _h_12 = r4;
    Term _h_13 = r5;
    Term _h_14 = r6;
    Term _h_15 = r7;
    Term _h_16 = r8;
    u32 _h_17 = r9;
    Term _h_18 = r10;
    u32 _h_19 = r11;
    Term _h_20 = r12;
    u32 _h_21 = r13;
    Term _h_22 = r14;
    Term _h_23 = r15;
    Term _h_24 = r16;
    u32 _h_25 = r17;
    Term _h_26 = r18;
    u32 _h_27 = r19;
    Term _h_28 = r20;
    u32 _h_29 = r21;
    Term _h_30 = r22;
    u32 _h_31 = r23;
    u32 _h_32 = r24;
    Term _h_33 = r25;
    WL_OPEN
    u32 _o_112 = 0;
    u32 _o_113 = 0;
    u32 _o_114 = 0;
    Term _o_115 = 0;
    Term _o_116 = 0;
    Term _o_117 = 0;
    Term _o_118 = 0;
    Term _o_119 = 0;
    Term _o_120 = 0;
    u32 _o_121 = 0;
    Term _o_122 = 0;
    u32 _o_123 = 0;
    Term _o_124 = 0;
    u32 _o_125 = 0;
    Term _o_126 = 0;
    u32 _o_127 = 0;
    Term _o_128 = 0;
    u32 _o_129 = 0;
    u32 _o_130 = 0;
    Term _o_131 = 0;
    u32 _o_132 = 0;
    u32 _o_133 = 0;
    u32 _o_134 = 0;
    u32 _o_135 = 0;
    Term _o_136 = 0;
    if (_h_8 == 0) {
      _o_112 = 0;
      u32 _o_137 = 0;
      if (_h_21 == 0) {
        _o_137 = 0;
      } else {
        _o_137 = 1;
      }
      _o_113 = _h_9;
      _o_114 = _h_10;
      _o_115 = _h_11;
      _o_116 = _h_12;
      _o_117 = _h_13;
      _o_118 = _h_14;
      _o_119 = _h_15;
      _o_120 = _h_16;
      _o_121 = _h_17;
      _o_122 = _h_18;
      _o_123 = _h_19;
      _o_124 = _h_20;
      _o_125 = _o_137;
      _o_126 = _h_24;
    } else if (_h_8 == 1) {
      _o_112 = 1;
      u32 _o_138 = 0;
      if (_h_21 == 0) {
        _o_138 = 0;
      } else {
        _o_138 = 1;
      }
      _o_113 = _h_9;
      _o_114 = _h_10;
      _o_115 = _h_11;
      _o_116 = _h_12;
      _o_117 = _h_13;
      _o_118 = _h_14;
      _o_119 = _h_15;
      _o_120 = _h_16;
      _o_121 = _h_17;
      _o_122 = _h_18;
      _o_123 = _h_19;
      _o_124 = _h_20;
      _o_125 = _o_138;
    } else {
      _o_112 = 2;
      u32 _o_139 = 0;
      if (_h_21 == 0) {
        _o_139 = 0;
      } else {
        _o_139 = 1;
      }
      u32 _o_140 = 0;
      Term _o_141 = 0;
      u32 _o_142 = 0;
      if (_h_25 == 0) {
        _o_140 = 0;
      } else {
        _o_140 = 1;
        Term _fb_11[2];
        u64 _sp_11 = ctr_take(e, _h_26, 2, _fb_11);
        Term _f_74 = _fb_11[0];
        u32 _f_75 = _fb_11[1];
        spare_free(e, cls_fit(2), _sp_11);
        _o_141 = _f_74;
        _o_142 = _f_75;
      }
      u32 _o_143 = 0;
      Term _o_144 = 0;
      u32 _o_145 = 0;
      if (_h_27 == 0) {
        _o_143 = 0;
      } else {
        _o_143 = 1;
        Term _fb_12[2];
        u64 _sp_12 = ctr_take(e, _h_28, 2, _fb_12);
        Term _f_76 = _fb_12[0];
        u32 _f_77 = _fb_12[1];
        spare_free(e, cls_fit(2), _sp_12);
        _o_144 = _f_76;
        _o_145 = _f_77;
      }
      u32 _o_146 = 0;
      if (_h_29 == 0) {
        _o_146 = 0;
      } else {
        _o_146 = 1;
      }
      _o_113 = _h_9;
      _o_114 = _h_10;
      _o_115 = _h_11;
      _o_116 = _h_12;
      _o_117 = _h_13;
      _o_118 = _h_14;
      _o_119 = _h_15;
      _o_120 = _h_16;
      _o_121 = _h_17;
      _o_122 = _h_18;
      _o_123 = _h_19;
      _o_124 = _h_20;
      _o_125 = _o_139;
      _o_126 = _h_24;
      _o_127 = _o_140;
      _o_128 = _o_141;
      _o_129 = _o_142;
      _o_130 = _o_143;
      _o_131 = _o_144;
      _o_132 = _o_145;
      _o_133 = _o_146;
      _o_134 = _h_31;
      _o_135 = _h_32;
      _o_136 = _h_33;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K447;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K447, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K447, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_APPLIED)) {
      u64 _t_11 = task_node(e, FID_APPLIED, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 240);
      e.mem[_t_11 + 1] = _o_112;
      e.mem[_t_11 + 2] = _o_113;
      e.mem[_t_11 + 3] = _o_114;
      e.mem[_t_11 + 4] = _o_115;
      e.mem[_t_11 + 5] = _o_116;
      e.mem[_t_11 + 6] = _o_117;
      e.mem[_t_11 + 7] = _o_118;
      e.mem[_t_11 + 8] = _o_119;
      e.mem[_t_11 + 9] = _o_120;
      e.mem[_t_11 + 10] = _o_121;
      e.mem[_t_11 + 11] = _o_122;
      e.mem[_t_11 + 12] = _o_123;
      e.mem[_t_11 + 13] = _o_124;
      e.mem[_t_11 + 14] = _o_125;
      e.mem[_t_11 + 15] = _o_126;
      e.mem[_t_11 + 16] = _o_127;
      e.mem[_t_11 + 17] = _o_128;
      e.mem[_t_11 + 18] = _o_129;
      e.mem[_t_11 + 19] = _o_130;
      e.mem[_t_11 + 20] = _o_131;
      e.mem[_t_11 + 21] = _o_132;
      e.mem[_t_11 + 22] = _o_133;
      e.mem[_t_11 + 23] = _o_134;
      e.mem[_t_11 + 24] = _o_135;
      e.mem[_t_11 + 25] = _o_136;
      return term_tsk(FID_APPLIED, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 240);
    r1 = _o_112;
    r2 = _o_113;
    r3 = _o_114;
    r4 = _o_115;
    r5 = _o_116;
    r6 = _o_117;
    r7 = _o_118;
    r8 = _o_119;
    r9 = _o_120;
    r10 = _o_121;
    r11 = _o_122;
    r12 = _o_123;
    r13 = _o_124;
    r14 = _o_125;
    r15 = _o_126;
    r16 = _o_127;
    r17 = _o_128;
    r18 = _o_129;
    r19 = _o_130;
    r20 = _o_131;
    r21 = _o_132;
    r22 = _o_133;
    r23 = _o_134;
    r24 = _o_135;
    r25 = _o_136;
    WL_JMP(FID_APPLIED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K447)
  {
    Term _h_34 = r0;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_11 + 0] = _h_34;
    r0 = term_clo(FID_MAIN_C448, _nd_11);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C448)
  {
    Term _h_35 = r0;
    Term _x_8 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_130 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_130 + 0] = _h_35;
      e.mem[_t_130 + 1] = term_clo(FID_MAIN_C449, 0);
      e.mem[_t_130 + 2] = _x_8;
      return term_tsk(FID_IO_BIND, _t_130);
    }
    r0 = _h_35;
    r1 = term_clo(FID_MAIN_C449, 0);
    r2 = _x_8;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C449)
  {
    Term _x_9 = r0;
    WL_OPEN
    Term _fb_13[15];
    u64 _sp_13 = ctr_take(e, _x_9, 15, _fb_13);
    u32 _f_78 = _fb_13[0];
    u32 _f_79 = _fb_13[1];
    Term _f_80 = _fb_13[2];
    Term _f_81 = _fb_13[3];
    Term _f_82 = _fb_13[4];
    Term _f_83 = _fb_13[5];
    Term _f_84 = _fb_13[6];
    Term _f_85 = _fb_13[7];
    u32 _f_86 = _fb_13[8];
    Term _f_87 = _fb_13[9];
    u32 _f_88 = _fb_13[10];
    Term _f_89 = _fb_13[11];
    u32 _f_90 = _fb_13[12];
    Term _f_91 = _fb_13[13];
    Term _f_92 = _fb_13[14];
    spare_free(e, cls_fit(15), _sp_13);
    u32 _o_147 = 0;
    if (_f_90 == 0) {
      _o_147 = 0;
    } else {
      _o_147 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K450;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K450, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K450, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SHAPE)) {
      u64 _t_13 = task_node(e, FID_SHAPE, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _f_78;
      e.mem[_t_13 + 1] = _f_79;
      e.mem[_t_13 + 2] = _f_80;
      e.mem[_t_13 + 3] = _f_81;
      e.mem[_t_13 + 4] = _f_82;
      e.mem[_t_13 + 5] = _f_83;
      e.mem[_t_13 + 6] = _f_84;
      e.mem[_t_13 + 7] = _f_85;
      e.mem[_t_13 + 8] = _f_86;
      e.mem[_t_13 + 9] = _f_87;
      e.mem[_t_13 + 10] = _f_88;
      e.mem[_t_13 + 11] = _f_89;
      e.mem[_t_13 + 12] = _o_147;
      return term_tsk(FID_SHAPE, _t_13);
    }
    r0 = _f_78;
    r1 = _f_79;
    r2 = _f_80;
    r3 = _f_81;
    r4 = _f_82;
    r5 = _f_83;
    r6 = _f_84;
    r7 = _f_85;
    r8 = _f_86;
    r9 = _f_87;
    r10 = _f_88;
    r11 = _f_89;
    r12 = _o_147;
    WL_JMP(FID_SHAPE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K450)
  {
    Term _h_36 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_12 + 0] = _h_36;
    r0 = term_clo(FID_MAIN_C451, _nd_12);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C451)
  {
    Term _h_37 = r0;
    Term _x_10 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_129 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_129 + 0] = _h_37;
      e.mem[_t_129 + 1] = term_clo(FID_MAIN_C452, 0);
      e.mem[_t_129 + 2] = _x_10;
      return term_tsk(FID_IO_BIND, _t_129);
    }
    r0 = _h_37;
    r1 = term_clo(FID_MAIN_C452, 0);
    r2 = _x_10;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C452)
  {
    Term _x_11 = r0;
    WL_OPEN
    Term _fb_14[15];
    u64 _sp_14 = ctr_take(e, _x_11, 15, _fb_14);
    u32 _f_93 = _fb_14[0];
    u32 _f_94 = _fb_14[1];
    Term _f_95 = _fb_14[2];
    Term _f_96 = _fb_14[3];
    Term _f_97 = _fb_14[4];
    Term _f_98 = _fb_14[5];
    Term _f_99 = _fb_14[6];
    Term _f_100 = _fb_14[7];
    u32 _f_101 = _fb_14[8];
    Term _f_102 = _fb_14[9];
    u32 _f_103 = _fb_14[10];
    Term _f_104 = _fb_14[11];
    u32 _f_105 = _fb_14[12];
    Term _f_106 = _fb_14[13];
    Term _f_107 = _fb_14[14];
    spare_free(e, cls_fit(15), _sp_14);
    u32 _o_148 = 0;
    if (_f_105 == 0) {
      _o_148 = 0;
    } else {
      _o_148 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K453;
      WL_PUSHN(1);
    } else {
      u64 _t_14 = task_node(e, FID_MAIN_K453, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K453, _t_14);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_15 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 272);
      e.mem[_t_15 + 1] = 0;
      e.mem[_t_15 + 2] = _f_93;
      e.mem[_t_15 + 3] = _f_94;
      e.mem[_t_15 + 4] = _f_95;
      e.mem[_t_15 + 5] = _f_96;
      e.mem[_t_15 + 6] = _f_97;
      e.mem[_t_15 + 7] = _f_98;
      e.mem[_t_15 + 8] = _f_99;
      e.mem[_t_15 + 9] = _f_100;
      e.mem[_t_15 + 10] = _f_101;
      e.mem[_t_15 + 11] = _f_102;
      e.mem[_t_15 + 12] = _f_103;
      e.mem[_t_15 + 13] = _f_104;
      e.mem[_t_15 + 14] = _o_148;
      return term_tsk(FID_EACH, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 272);
    r1 = 0;
    r2 = _f_93;
    r3 = _f_94;
    r4 = _f_95;
    r5 = _f_96;
    r6 = _f_97;
    r7 = _f_98;
    r8 = _f_99;
    r9 = _f_100;
    r10 = _f_101;
    r11 = _f_102;
    r12 = _f_103;
    r13 = _f_104;
    r14 = _o_148;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K453)
  {
    Term _h_38 = r0;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_13 + 0] = _h_38;
    r0 = term_clo(FID_MAIN_C454, _nd_13);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C454)
  {
    Term _h_39 = r0;
    Term _x_12 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_128 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_128 + 0] = _h_39;
      e.mem[_t_128 + 1] = term_clo(FID_MAIN_C455, 0);
      e.mem[_t_128 + 2] = _x_12;
      return term_tsk(FID_IO_BIND, _t_128);
    }
    r0 = _h_39;
    r1 = term_clo(FID_MAIN_C455, 0);
    r2 = _x_12;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C455)
  {
    Term _x_13 = r0;
    WL_OPEN
    Term _fb_15[15];
    u64 _sp_15 = ctr_take(e, _x_13, 15, _fb_15);
    u32 _f_108 = _fb_15[0];
    u32 _f_109 = _fb_15[1];
    Term _f_110 = _fb_15[2];
    Term _f_111 = _fb_15[3];
    Term _f_112 = _fb_15[4];
    Term _f_113 = _fb_15[5];
    Term _f_114 = _fb_15[6];
    Term _f_115 = _fb_15[7];
    u32 _f_116 = _fb_15[8];
    Term _f_117 = _fb_15[9];
    u32 _f_118 = _fb_15[10];
    Term _f_119 = _fb_15[11];
    u32 _f_120 = _fb_15[12];
    Term _f_121 = _fb_15[13];
    Term _f_122 = _fb_15[14];
    spare_free(e, cls_fit(15), _sp_15);
    u32 _o_149 = 0;
    if (_f_120 == 0) {
      _o_149 = 0;
    } else {
      _o_149 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K456;
      WL_PUSHN(1);
    } else {
      u64 _t_16 = task_node(e, FID_MAIN_K456, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K456, _t_16);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_17 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 302);
      e.mem[_t_17 + 1] = 1;
      e.mem[_t_17 + 2] = _f_108;
      e.mem[_t_17 + 3] = _f_109;
      e.mem[_t_17 + 4] = _f_110;
      e.mem[_t_17 + 5] = _f_111;
      e.mem[_t_17 + 6] = _f_112;
      e.mem[_t_17 + 7] = _f_113;
      e.mem[_t_17 + 8] = _f_114;
      e.mem[_t_17 + 9] = _f_115;
      e.mem[_t_17 + 10] = _f_116;
      e.mem[_t_17 + 11] = _f_117;
      e.mem[_t_17 + 12] = _f_118;
      e.mem[_t_17 + 13] = _f_119;
      e.mem[_t_17 + 14] = _o_149;
      return term_tsk(FID_EACH, _t_17);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 302);
    r1 = 1;
    r2 = _f_108;
    r3 = _f_109;
    r4 = _f_110;
    r5 = _f_111;
    r6 = _f_112;
    r7 = _f_113;
    r8 = _f_114;
    r9 = _f_115;
    r10 = _f_116;
    r11 = _f_117;
    r12 = _f_118;
    r13 = _f_119;
    r14 = _o_149;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K456)
  {
    Term _h_40 = r0;
    WL_OPEN
    u64 _nd_14 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_14 + 0] = _h_40;
    r0 = term_clo(FID_MAIN_C457, _nd_14);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C457)
  {
    Term _h_41 = r0;
    Term _x_14 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_127 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_127 + 0] = _h_41;
      e.mem[_t_127 + 1] = term_clo(FID_MAIN_C458, 0);
      e.mem[_t_127 + 2] = _x_14;
      return term_tsk(FID_IO_BIND, _t_127);
    }
    r0 = _h_41;
    r1 = term_clo(FID_MAIN_C458, 0);
    r2 = _x_14;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C458)
  {
    Term _x_15 = r0;
    WL_OPEN
    Term _fb_16[15];
    u64 _sp_16 = ctr_take(e, _x_15, 15, _fb_16);
    u32 _f_123 = _fb_16[0];
    u32 _f_124 = _fb_16[1];
    Term _f_125 = _fb_16[2];
    Term _f_126 = _fb_16[3];
    Term _f_127 = _fb_16[4];
    Term _f_128 = _fb_16[5];
    Term _f_129 = _fb_16[6];
    Term _f_130 = _fb_16[7];
    u32 _f_131 = _fb_16[8];
    Term _f_132 = _fb_16[9];
    u32 _f_133 = _fb_16[10];
    Term _f_134 = _fb_16[11];
    u32 _f_135 = _fb_16[12];
    Term _f_136 = _fb_16[13];
    Term _f_137 = _fb_16[14];
    spare_free(e, cls_fit(15), _sp_16);
    u32 _o_150 = 0;
    if (_f_135 == 0) {
      _o_150 = 0;
    } else {
      _o_150 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K459;
      WL_PUSHN(1);
    } else {
      u64 _t_18 = task_node(e, FID_MAIN_K459, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K459, _t_18);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_19 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 322);
      e.mem[_t_19 + 1] = 2;
      e.mem[_t_19 + 2] = _f_123;
      e.mem[_t_19 + 3] = _f_124;
      e.mem[_t_19 + 4] = _f_125;
      e.mem[_t_19 + 5] = _f_126;
      e.mem[_t_19 + 6] = _f_127;
      e.mem[_t_19 + 7] = _f_128;
      e.mem[_t_19 + 8] = _f_129;
      e.mem[_t_19 + 9] = _f_130;
      e.mem[_t_19 + 10] = _f_131;
      e.mem[_t_19 + 11] = _f_132;
      e.mem[_t_19 + 12] = _f_133;
      e.mem[_t_19 + 13] = _f_134;
      e.mem[_t_19 + 14] = _o_150;
      return term_tsk(FID_EACH, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 322);
    r1 = 2;
    r2 = _f_123;
    r3 = _f_124;
    r4 = _f_125;
    r5 = _f_126;
    r6 = _f_127;
    r7 = _f_128;
    r8 = _f_129;
    r9 = _f_130;
    r10 = _f_131;
    r11 = _f_132;
    r12 = _f_133;
    r13 = _f_134;
    r14 = _o_150;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K459)
  {
    Term _h_42 = r0;
    WL_OPEN
    u64 _nd_15 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_15 + 0] = _h_42;
    r0 = term_clo(FID_MAIN_C460, _nd_15);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C460)
  {
    Term _h_43 = r0;
    Term _x_16 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_126 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_126 + 0] = _h_43;
      e.mem[_t_126 + 1] = term_clo(FID_MAIN_C461, 0);
      e.mem[_t_126 + 2] = _x_16;
      return term_tsk(FID_IO_BIND, _t_126);
    }
    r0 = _h_43;
    r1 = term_clo(FID_MAIN_C461, 0);
    r2 = _x_16;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C461)
  {
    Term _x_17 = r0;
    WL_OPEN
    Term _fb_17[15];
    u64 _sp_17 = ctr_take(e, _x_17, 15, _fb_17);
    u32 _f_138 = _fb_17[0];
    u32 _f_139 = _fb_17[1];
    Term _f_140 = _fb_17[2];
    Term _f_141 = _fb_17[3];
    Term _f_142 = _fb_17[4];
    Term _f_143 = _fb_17[5];
    Term _f_144 = _fb_17[6];
    Term _f_145 = _fb_17[7];
    u32 _f_146 = _fb_17[8];
    Term _f_147 = _fb_17[9];
    u32 _f_148 = _fb_17[10];
    Term _f_149 = _fb_17[11];
    u32 _f_150 = _fb_17[12];
    Term _f_151 = _fb_17[13];
    Term _f_152 = _fb_17[14];
    spare_free(e, cls_fit(15), _sp_17);
    u32 _o_151 = 0;
    if (_f_150 == 0) {
      _o_151 = 0;
    } else {
      _o_151 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K462;
      WL_PUSHN(1);
    } else {
      u64 _t_20 = task_node(e, FID_MAIN_K462, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K462, _t_20);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_21 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 354);
      e.mem[_t_21 + 1] = 3;
      e.mem[_t_21 + 2] = _f_138;
      e.mem[_t_21 + 3] = _f_139;
      e.mem[_t_21 + 4] = _f_140;
      e.mem[_t_21 + 5] = _f_141;
      e.mem[_t_21 + 6] = _f_142;
      e.mem[_t_21 + 7] = _f_143;
      e.mem[_t_21 + 8] = _f_144;
      e.mem[_t_21 + 9] = _f_145;
      e.mem[_t_21 + 10] = _f_146;
      e.mem[_t_21 + 11] = _f_147;
      e.mem[_t_21 + 12] = _f_148;
      e.mem[_t_21 + 13] = _f_149;
      e.mem[_t_21 + 14] = _o_151;
      return term_tsk(FID_EACH, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 354);
    r1 = 3;
    r2 = _f_138;
    r3 = _f_139;
    r4 = _f_140;
    r5 = _f_141;
    r6 = _f_142;
    r7 = _f_143;
    r8 = _f_144;
    r9 = _f_145;
    r10 = _f_146;
    r11 = _f_147;
    r12 = _f_148;
    r13 = _f_149;
    r14 = _o_151;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K462)
  {
    Term _h_44 = r0;
    WL_OPEN
    u64 _nd_16 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_16 + 0] = _h_44;
    r0 = term_clo(FID_MAIN_C463, _nd_16);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C463)
  {
    Term _h_45 = r0;
    Term _x_18 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_125 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_125 + 0] = _h_45;
      e.mem[_t_125 + 1] = term_clo(FID_MAIN_C464, 0);
      e.mem[_t_125 + 2] = _x_18;
      return term_tsk(FID_IO_BIND, _t_125);
    }
    r0 = _h_45;
    r1 = term_clo(FID_MAIN_C464, 0);
    r2 = _x_18;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C464)
  {
    Term _x_19 = r0;
    WL_OPEN
    Term _fb_18[15];
    u64 _sp_18 = ctr_take(e, _x_19, 15, _fb_18);
    u32 _f_153 = _fb_18[0];
    u32 _f_154 = _fb_18[1];
    Term _f_155 = _fb_18[2];
    Term _f_156 = _fb_18[3];
    Term _f_157 = _fb_18[4];
    Term _f_158 = _fb_18[5];
    Term _f_159 = _fb_18[6];
    Term _f_160 = _fb_18[7];
    u32 _f_161 = _fb_18[8];
    Term _f_162 = _fb_18[9];
    u32 _f_163 = _fb_18[10];
    Term _f_164 = _fb_18[11];
    u32 _f_165 = _fb_18[12];
    Term _f_166 = _fb_18[13];
    Term _f_167 = _fb_18[14];
    spare_free(e, cls_fit(15), _sp_18);
    u32 _o_152 = 0;
    if (_f_165 == 0) {
      _o_152 = 0;
    } else {
      _o_152 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K465;
      WL_PUSHN(1);
    } else {
      u64 _t_22 = task_node(e, FID_MAIN_K465, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K465, _t_22);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_23 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 360);
      e.mem[_t_23 + 1] = _f_153;
      e.mem[_t_23 + 2] = _f_154;
      e.mem[_t_23 + 3] = _f_155;
      e.mem[_t_23 + 4] = _f_156;
      e.mem[_t_23 + 5] = _f_157;
      e.mem[_t_23 + 6] = _f_158;
      e.mem[_t_23 + 7] = _f_159;
      e.mem[_t_23 + 8] = _f_160;
      e.mem[_t_23 + 9] = _f_161;
      e.mem[_t_23 + 10] = _f_162;
      e.mem[_t_23 + 11] = _f_163;
      e.mem[_t_23 + 12] = _f_164;
      e.mem[_t_23 + 13] = _o_152;
      e.mem[_t_23 + 14] = 1ull;
      return term_tsk(FID_SNAPSHOT, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 360);
    r1 = _f_153;
    r2 = _f_154;
    r3 = _f_155;
    r4 = _f_156;
    r5 = _f_157;
    r6 = _f_158;
    r7 = _f_159;
    r8 = _f_160;
    r9 = _f_161;
    r10 = _f_162;
    r11 = _f_163;
    r12 = _f_164;
    r13 = _o_152;
    r14 = 1ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K465)
  {
    Term _h_46 = r0;
    WL_OPEN
    u64 _nd_17 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_17 + 0] = _h_46;
    r0 = term_clo(FID_MAIN_C466, _nd_17);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C466)
  {
    Term _h_47 = r0;
    Term _x_20 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_124 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_124 + 0] = _h_47;
      e.mem[_t_124 + 1] = term_clo(FID_MAIN_C467, 0);
      e.mem[_t_124 + 2] = _x_20;
      return term_tsk(FID_IO_BIND, _t_124);
    }
    r0 = _h_47;
    r1 = term_clo(FID_MAIN_C467, 0);
    r2 = _x_20;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C467)
  {
    Term _x_21 = r0;
    WL_OPEN
    Term _fb_19[15];
    u64 _sp_19 = ctr_take(e, _x_21, 15, _fb_19);
    u32 _f_168 = _fb_19[0];
    u32 _f_169 = _fb_19[1];
    Term _f_170 = _fb_19[2];
    Term _f_171 = _fb_19[3];
    Term _f_172 = _fb_19[4];
    Term _f_173 = _fb_19[5];
    Term _f_174 = _fb_19[6];
    Term _f_175 = _fb_19[7];
    u32 _f_176 = _fb_19[8];
    Term _f_177 = _fb_19[9];
    u32 _f_178 = _fb_19[10];
    Term _f_179 = _fb_19[11];
    u32 _f_180 = _fb_19[12];
    Term _f_181 = _fb_19[13];
    Term _f_182 = _fb_19[14];
    spare_free(e, cls_fit(15), _sp_19);
    u32 _o_153 = 0;
    if (_f_180 == 0) {
      _o_153 = 0;
    } else {
      _o_153 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K468;
      WL_PUSHN(1);
    } else {
      u64 _t_24 = task_node(e, FID_MAIN_K468, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K468, _t_24);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_25 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 366);
      e.mem[_t_25 + 1] = _f_168;
      e.mem[_t_25 + 2] = _f_169;
      e.mem[_t_25 + 3] = _f_170;
      e.mem[_t_25 + 4] = _f_171;
      e.mem[_t_25 + 5] = _f_172;
      e.mem[_t_25 + 6] = _f_173;
      e.mem[_t_25 + 7] = _f_174;
      e.mem[_t_25 + 8] = _f_175;
      e.mem[_t_25 + 9] = _f_176;
      e.mem[_t_25 + 10] = _f_177;
      e.mem[_t_25 + 11] = _f_178;
      e.mem[_t_25 + 12] = _f_179;
      e.mem[_t_25 + 13] = _o_153;
      e.mem[_t_25 + 14] = 2ull;
      return term_tsk(FID_SNAPSHOT, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 366);
    r1 = _f_168;
    r2 = _f_169;
    r3 = _f_170;
    r4 = _f_171;
    r5 = _f_172;
    r6 = _f_173;
    r7 = _f_174;
    r8 = _f_175;
    r9 = _f_176;
    r10 = _f_177;
    r11 = _f_178;
    r12 = _f_179;
    r13 = _o_153;
    r14 = 2ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K468)
  {
    Term _h_48 = r0;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_18 + 0] = _h_48;
    r0 = term_clo(FID_MAIN_C469, _nd_18);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C469)
  {
    Term _h_49 = r0;
    Term _x_22 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_123 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_123 + 0] = _h_49;
      e.mem[_t_123 + 1] = term_clo(FID_MAIN_C470, 0);
      e.mem[_t_123 + 2] = _x_22;
      return term_tsk(FID_IO_BIND, _t_123);
    }
    r0 = _h_49;
    r1 = term_clo(FID_MAIN_C470, 0);
    r2 = _x_22;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C470)
  {
    Term _x_23 = r0;
    WL_OPEN
    Term _fb_20[15];
    u64 _sp_20 = ctr_take(e, _x_23, 15, _fb_20);
    u32 _f_183 = _fb_20[0];
    u32 _f_184 = _fb_20[1];
    Term _f_185 = _fb_20[2];
    Term _f_186 = _fb_20[3];
    Term _f_187 = _fb_20[4];
    Term _f_188 = _fb_20[5];
    Term _f_189 = _fb_20[6];
    Term _f_190 = _fb_20[7];
    u32 _f_191 = _fb_20[8];
    Term _f_192 = _fb_20[9];
    u32 _f_193 = _fb_20[10];
    Term _f_194 = _fb_20[11];
    u32 _f_195 = _fb_20[12];
    Term _f_196 = _fb_20[13];
    Term _f_197 = _fb_20[14];
    spare_free(e, cls_fit(15), _sp_20);
    u32 _o_154 = 0;
    if (_f_195 == 0) {
      _o_154 = 0;
    } else {
      _o_154 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K471;
      WL_PUSHN(1);
    } else {
      u64 _t_26 = task_node(e, FID_MAIN_K471, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K471, _t_26);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_27 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 372);
      e.mem[_t_27 + 1] = _f_183;
      e.mem[_t_27 + 2] = _f_184;
      e.mem[_t_27 + 3] = _f_185;
      e.mem[_t_27 + 4] = _f_186;
      e.mem[_t_27 + 5] = _f_187;
      e.mem[_t_27 + 6] = _f_188;
      e.mem[_t_27 + 7] = _f_189;
      e.mem[_t_27 + 8] = _f_190;
      e.mem[_t_27 + 9] = _f_191;
      e.mem[_t_27 + 10] = _f_192;
      e.mem[_t_27 + 11] = _f_193;
      e.mem[_t_27 + 12] = _f_194;
      e.mem[_t_27 + 13] = _o_154;
      e.mem[_t_27 + 14] = 3ull;
      return term_tsk(FID_SNAPSHOT, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 372);
    r1 = _f_183;
    r2 = _f_184;
    r3 = _f_185;
    r4 = _f_186;
    r5 = _f_187;
    r6 = _f_188;
    r7 = _f_189;
    r8 = _f_190;
    r9 = _f_191;
    r10 = _f_192;
    r11 = _f_193;
    r12 = _f_194;
    r13 = _o_154;
    r14 = 3ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K471)
  {
    Term _h_50 = r0;
    WL_OPEN
    u64 _nd_19 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_19 + 0] = _h_50;
    r0 = term_clo(FID_MAIN_C472, _nd_19);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C472)
  {
    Term _h_51 = r0;
    Term _x_24 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_122 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_122 + 0] = _h_51;
      e.mem[_t_122 + 1] = term_clo(FID_MAIN_C473, 0);
      e.mem[_t_122 + 2] = _x_24;
      return term_tsk(FID_IO_BIND, _t_122);
    }
    r0 = _h_51;
    r1 = term_clo(FID_MAIN_C473, 0);
    r2 = _x_24;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C473)
  {
    Term _x_25 = r0;
    WL_OPEN
    Term _fb_21[15];
    u64 _sp_21 = ctr_take(e, _x_25, 15, _fb_21);
    u32 _f_198 = _fb_21[0];
    u32 _f_199 = _fb_21[1];
    Term _f_200 = _fb_21[2];
    Term _f_201 = _fb_21[3];
    Term _f_202 = _fb_21[4];
    Term _f_203 = _fb_21[5];
    Term _f_204 = _fb_21[6];
    Term _f_205 = _fb_21[7];
    u32 _f_206 = _fb_21[8];
    Term _f_207 = _fb_21[9];
    u32 _f_208 = _fb_21[10];
    Term _f_209 = _fb_21[11];
    u32 _f_210 = _fb_21[12];
    Term _f_211 = _fb_21[13];
    Term _f_212 = _fb_21[14];
    spare_free(e, cls_fit(15), _sp_21);
    u32 _o_155 = 0;
    if (_f_210 == 0) {
      _o_155 = 0;
    } else {
      _o_155 = 1;
    }
    u32 _o_156 = 0;
    Term _o_157 = 0;
    if (_o_155 == 0) {
      _o_156 = 0;
    } else {
      _o_156 = 1;
      _o_157 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K474;
      WL_PUSHN(1);
    } else {
      u64 _t_28 = task_node(e, FID_MAIN_K474, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K474, _t_28);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_FLAG)) {
      u64 _t_29 = task_node(e, FID_COMMANDS_INSERT_FLAG, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _f_198;
      e.mem[_t_29 + 1] = _f_199;
      e.mem[_t_29 + 2] = _f_200;
      e.mem[_t_29 + 3] = _f_201;
      e.mem[_t_29 + 4] = _f_202;
      e.mem[_t_29 + 5] = _f_203;
      e.mem[_t_29 + 6] = _f_204;
      e.mem[_t_29 + 7] = _f_205;
      e.mem[_t_29 + 8] = _f_206;
      e.mem[_t_29 + 9] = _f_207;
      e.mem[_t_29 + 10] = _f_208;
      e.mem[_t_29 + 11] = _f_209;
      e.mem[_t_29 + 12] = _o_156;
      e.mem[_t_29 + 13] = _o_157;
      e.mem[_t_29 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_29 + 15] = 7ull;
      e.mem[_t_29 + 16] = 3ull;
      e.mem[_t_29 + 17] = term_pak(CID_UNIT, 0);
      return term_tsk(FID_COMMANDS_INSERT_FLAG, _t_29);
    }
    r0 = _f_198;
    r1 = _f_199;
    r2 = _f_200;
    r3 = _f_201;
    r4 = _f_202;
    r5 = _f_203;
    r6 = _f_204;
    r7 = _f_205;
    r8 = _f_206;
    r9 = _f_207;
    r10 = _f_208;
    r11 = _f_209;
    r12 = _o_156;
    r13 = _o_157;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 7ull;
    r16 = 3ull;
    r17 = term_pak(CID_UNIT, 0);
    WL_JMP(FID_COMMANDS_INSERT_FLAG);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K474)
  {
    u32 _h_52 = r0;
    u32 _h_53 = r1;
    u32 _h_54 = r2;
    Term _h_55 = r3;
    Term _h_56 = r4;
    Term _h_57 = r5;
    Term _h_58 = r6;
    Term _h_59 = r7;
    Term _h_60 = r8;
    u32 _h_61 = r9;
    Term _h_62 = r10;
    u32 _h_63 = r11;
    Term _h_64 = r12;
    u32 _h_65 = r13;
    Term _h_66 = r14;
    Term _h_67 = r15;
    Term _h_68 = r16;
    WL_OPEN
    u32 _o_158 = 0;
    u32 _o_159 = 0;
    u32 _o_160 = 0;
    Term _o_161 = 0;
    Term _o_162 = 0;
    Term _o_163 = 0;
    Term _o_164 = 0;
    Term _o_165 = 0;
    Term _o_166 = 0;
    u32 _o_167 = 0;
    Term _o_168 = 0;
    u32 _o_169 = 0;
    Term _o_170 = 0;
    u32 _o_171 = 0;
    Term _o_172 = 0;
    if (_h_52 == 0) {
      _o_158 = 0;
      u32 _o_173 = 0;
      if (_h_65 == 0) {
        _o_173 = 0;
      } else {
        _o_173 = 1;
      }
      _o_159 = _h_53;
      _o_160 = _h_54;
      _o_161 = _h_55;
      _o_162 = _h_56;
      _o_163 = _h_57;
      _o_164 = _h_58;
      _o_165 = _h_59;
      _o_166 = _h_60;
      _o_167 = _h_61;
      _o_168 = _h_62;
      _o_169 = _h_63;
      _o_170 = _h_64;
      _o_171 = _o_173;
    } else {
      _o_158 = 1;
      u32 _o_174 = 0;
      if (_h_65 == 0) {
        _o_174 = 0;
      } else {
        _o_174 = 1;
      }
      _o_159 = _h_53;
      _o_160 = _h_54;
      _o_161 = _h_55;
      _o_162 = _h_56;
      _o_163 = _h_57;
      _o_164 = _h_58;
      _o_165 = _h_59;
      _o_166 = _h_60;
      _o_167 = _h_61;
      _o_168 = _h_62;
      _o_169 = _h_63;
      _o_170 = _h_64;
      _o_171 = _o_174;
      _o_172 = _h_68;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K475;
      WL_PUSHN(1);
    } else {
      u64 _t_30 = task_node(e, FID_MAIN_K475, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K475, _t_30);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUEUED)) {
      u64 _t_31 = task_node(e, FID_QUEUED, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 380);
      e.mem[_t_31 + 1] = _o_158;
      e.mem[_t_31 + 2] = _o_159;
      e.mem[_t_31 + 3] = _o_160;
      e.mem[_t_31 + 4] = _o_161;
      e.mem[_t_31 + 5] = _o_162;
      e.mem[_t_31 + 6] = _o_163;
      e.mem[_t_31 + 7] = _o_164;
      e.mem[_t_31 + 8] = _o_165;
      e.mem[_t_31 + 9] = _o_166;
      e.mem[_t_31 + 10] = _o_167;
      e.mem[_t_31 + 11] = _o_168;
      e.mem[_t_31 + 12] = _o_169;
      e.mem[_t_31 + 13] = _o_170;
      e.mem[_t_31 + 14] = _o_171;
      e.mem[_t_31 + 15] = _o_172;
      return term_tsk(FID_QUEUED, _t_31);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 380);
    r1 = _o_158;
    r2 = _o_159;
    r3 = _o_160;
    r4 = _o_161;
    r5 = _o_162;
    r6 = _o_163;
    r7 = _o_164;
    r8 = _o_165;
    r9 = _o_166;
    r10 = _o_167;
    r11 = _o_168;
    r12 = _o_169;
    r13 = _o_170;
    r14 = _o_171;
    r15 = _o_172;
    WL_JMP(FID_QUEUED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K475)
  {
    Term _h_69 = r0;
    WL_OPEN
    u64 _nd_20 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_20 + 0] = _h_69;
    r0 = term_clo(FID_MAIN_C476, _nd_20);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C476)
  {
    Term _h_70 = r0;
    Term _x_26 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_121 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_121 + 0] = _h_70;
      e.mem[_t_121 + 1] = term_clo(FID_MAIN_C477, 0);
      e.mem[_t_121 + 2] = _x_26;
      return term_tsk(FID_IO_BIND, _t_121);
    }
    r0 = _h_70;
    r1 = term_clo(FID_MAIN_C477, 0);
    r2 = _x_26;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C477)
  {
    Term _x_27 = r0;
    WL_OPEN
    Term _fb_22[15];
    u64 _sp_22 = ctr_take(e, _x_27, 15, _fb_22);
    u32 _f_213 = _fb_22[0];
    u32 _f_214 = _fb_22[1];
    Term _f_215 = _fb_22[2];
    Term _f_216 = _fb_22[3];
    Term _f_217 = _fb_22[4];
    Term _f_218 = _fb_22[5];
    Term _f_219 = _fb_22[6];
    Term _f_220 = _fb_22[7];
    u32 _f_221 = _fb_22[8];
    Term _f_222 = _fb_22[9];
    u32 _f_223 = _fb_22[10];
    Term _f_224 = _fb_22[11];
    u32 _f_225 = _fb_22[12];
    Term _f_226 = _fb_22[13];
    Term _f_227 = _fb_22[14];
    spare_free(e, cls_fit(15), _sp_22);
    u32 _o_175 = 0;
    if (_f_225 == 0) {
      _o_175 = 0;
    } else {
      _o_175 = 1;
    }
    u32 _o_176 = 0;
    Term _o_177 = 0;
    if (_o_175 == 0) {
      _o_176 = 0;
    } else {
      _o_176 = 1;
      _o_177 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K478;
      WL_PUSHN(1);
    } else {
      u64 _t_32 = task_node(e, FID_MAIN_K478, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K478, _t_32);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_REMOVE_FLAG)) {
      u64 _t_33 = task_node(e, FID_COMMANDS_REMOVE_FLAG, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _f_213;
      e.mem[_t_33 + 1] = _f_214;
      e.mem[_t_33 + 2] = _f_215;
      e.mem[_t_33 + 3] = _f_216;
      e.mem[_t_33 + 4] = _f_217;
      e.mem[_t_33 + 5] = _f_218;
      e.mem[_t_33 + 6] = _f_219;
      e.mem[_t_33 + 7] = _f_220;
      e.mem[_t_33 + 8] = _f_221;
      e.mem[_t_33 + 9] = _f_222;
      e.mem[_t_33 + 10] = _f_223;
      e.mem[_t_33 + 11] = _f_224;
      e.mem[_t_33 + 12] = _o_176;
      e.mem[_t_33 + 13] = _o_177;
      e.mem[_t_33 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_33 + 15] = 7ull;
      e.mem[_t_33 + 16] = 1ull;
      return term_tsk(FID_COMMANDS_REMOVE_FLAG, _t_33);
    }
    r0 = _f_213;
    r1 = _f_214;
    r2 = _f_215;
    r3 = _f_216;
    r4 = _f_217;
    r5 = _f_218;
    r6 = _f_219;
    r7 = _f_220;
    r8 = _f_221;
    r9 = _f_222;
    r10 = _f_223;
    r11 = _f_224;
    r12 = _o_176;
    r13 = _o_177;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 7ull;
    r16 = 1ull;
    WL_JMP(FID_COMMANDS_REMOVE_FLAG);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K478)
  {
    u32 _h_71 = r0;
    u32 _h_72 = r1;
    u32 _h_73 = r2;
    Term _h_74 = r3;
    Term _h_75 = r4;
    Term _h_76 = r5;
    Term _h_77 = r6;
    Term _h_78 = r7;
    Term _h_79 = r8;
    u32 _h_80 = r9;
    Term _h_81 = r10;
    u32 _h_82 = r11;
    Term _h_83 = r12;
    u32 _h_84 = r13;
    Term _h_85 = r14;
    Term _h_86 = r15;
    WL_OPEN
    u32 _o_178 = 0;
    u32 _o_179 = 0;
    u32 _o_180 = 0;
    Term _o_181 = 0;
    Term _o_182 = 0;
    Term _o_183 = 0;
    Term _o_184 = 0;
    Term _o_185 = 0;
    Term _o_186 = 0;
    u32 _o_187 = 0;
    Term _o_188 = 0;
    u32 _o_189 = 0;
    Term _o_190 = 0;
    u32 _o_191 = 0;
    Term _o_192 = 0;
    if (_h_71 == 0) {
      _o_178 = 0;
      u32 _o_193 = 0;
      if (_h_84 == 0) {
        _o_193 = 0;
      } else {
        _o_193 = 1;
      }
      _o_179 = _h_72;
      _o_180 = _h_73;
      _o_181 = _h_74;
      _o_182 = _h_75;
      _o_183 = _h_76;
      _o_184 = _h_77;
      _o_185 = _h_78;
      _o_186 = _h_79;
      _o_187 = _h_80;
      _o_188 = _h_81;
      _o_189 = _h_82;
      _o_190 = _h_83;
      _o_191 = _o_193;
    } else {
      _o_178 = 1;
      u32 _o_194 = 0;
      if (_h_84 == 0) {
        _o_194 = 0;
      } else {
        _o_194 = 1;
      }
      _o_179 = _h_72;
      _o_180 = _h_73;
      _o_181 = _h_74;
      _o_182 = _h_75;
      _o_183 = _h_76;
      _o_184 = _h_77;
      _o_185 = _h_78;
      _o_186 = _h_79;
      _o_187 = _h_80;
      _o_188 = _h_81;
      _o_189 = _h_82;
      _o_190 = _h_83;
      _o_191 = _o_194;
      _o_192 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K479;
      WL_PUSHN(1);
    } else {
      u64 _t_34 = task_node(e, FID_MAIN_K479, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K479, _t_34);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUEUED)) {
      u64 _t_35 = task_node(e, FID_QUEUED, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 392);
      e.mem[_t_35 + 1] = _o_178;
      e.mem[_t_35 + 2] = _o_179;
      e.mem[_t_35 + 3] = _o_180;
      e.mem[_t_35 + 4] = _o_181;
      e.mem[_t_35 + 5] = _o_182;
      e.mem[_t_35 + 6] = _o_183;
      e.mem[_t_35 + 7] = _o_184;
      e.mem[_t_35 + 8] = _o_185;
      e.mem[_t_35 + 9] = _o_186;
      e.mem[_t_35 + 10] = _o_187;
      e.mem[_t_35 + 11] = _o_188;
      e.mem[_t_35 + 12] = _o_189;
      e.mem[_t_35 + 13] = _o_190;
      e.mem[_t_35 + 14] = _o_191;
      e.mem[_t_35 + 15] = _o_192;
      return term_tsk(FID_QUEUED, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 392);
    r1 = _o_178;
    r2 = _o_179;
    r3 = _o_180;
    r4 = _o_181;
    r5 = _o_182;
    r6 = _o_183;
    r7 = _o_184;
    r8 = _o_185;
    r9 = _o_186;
    r10 = _o_187;
    r11 = _o_188;
    r12 = _o_189;
    r13 = _o_190;
    r14 = _o_191;
    r15 = _o_192;
    WL_JMP(FID_QUEUED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K479)
  {
    Term _h_87 = r0;
    WL_OPEN
    u64 _nd_21 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_21 + 0] = _h_87;
    r0 = term_clo(FID_MAIN_C480, _nd_21);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C480)
  {
    Term _h_88 = r0;
    Term _x_28 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_120 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_120 + 0] = _h_88;
      e.mem[_t_120 + 1] = term_clo(FID_MAIN_C481, 0);
      e.mem[_t_120 + 2] = _x_28;
      return term_tsk(FID_IO_BIND, _t_120);
    }
    r0 = _h_88;
    r1 = term_clo(FID_MAIN_C481, 0);
    r2 = _x_28;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C481)
  {
    Term _x_29 = r0;
    WL_OPEN
    Term _fb_23[15];
    u64 _sp_23 = ctr_take(e, _x_29, 15, _fb_23);
    u32 _f_228 = _fb_23[0];
    u32 _f_229 = _fb_23[1];
    Term _f_230 = _fb_23[2];
    Term _f_231 = _fb_23[3];
    Term _f_232 = _fb_23[4];
    Term _f_233 = _fb_23[5];
    Term _f_234 = _fb_23[6];
    Term _f_235 = _fb_23[7];
    u32 _f_236 = _fb_23[8];
    Term _f_237 = _fb_23[9];
    u32 _f_238 = _fb_23[10];
    Term _f_239 = _fb_23[11];
    u32 _f_240 = _fb_23[12];
    Term _f_241 = _fb_23[13];
    Term _f_242 = _fb_23[14];
    spare_free(e, cls_fit(15), _sp_23);
    u32 _o_195 = 0;
    if (_f_240 == 0) {
      _o_195 = 0;
    } else {
      _o_195 = 1;
    }
    Term _fv_10[1];
    _fv_10[0] = 20ull;
    Term _a_18 = blk_new(e, 0, 2ull, 0, 1, _fv_10);
    Term _at_24 = blk_loc(e.mem, _a_18);
    Term _at_25 = blk_at(_a_18, 1ull, 0);
    u32 _c_12 = blk_read(e.mem, 0, _at_24, _at_25 + 0);
    blk_write(e.mem, 0, _at_24, _at_25 + 0, U32_BIN(20ull, +, 1ull));
    Term _at_26 = blk_loc(e.mem, _a_18);
    Term _at_27 = blk_at(_a_18, 2ull, 0);
    u32 _c_13 = blk_read(e.mem, 0, _at_26, _at_27 + 0);
    blk_write(e.mem, 0, _at_26, _at_27 + 0, U32_BIN(20ull, +, 2ull));
    Term _at_28 = blk_loc(e.mem, _a_18);
    Term _at_29 = blk_at(_a_18, 3ull, 0);
    u32 _c_14 = blk_read(e.mem, 0, _at_28, _at_29 + 0);
    blk_write(e.mem, 0, _at_28, _at_29 + 0, U32_BIN(20ull, +, 3ull));
    u64 _nd_22 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_22 + 0] = rfc_seal(e, _a_18);
    e.mem[_nd_22 + 1] = rfc_seal(e, 20ull);
    u32 _o_196 = 0;
    Term _o_197 = 0;
    if (_o_195 == 0) {
      _o_196 = 0;
    } else {
      _o_196 = 1;
      _o_197 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K482;
      WL_PUSHN(1);
    } else {
      u64 _t_36 = task_node(e, FID_MAIN_K482, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K482, _t_36);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_MAIN)) {
      u64 _t_37 = task_node(e, FID_COMMANDS_INSERT_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _f_228;
      e.mem[_t_37 + 1] = _f_229;
      e.mem[_t_37 + 2] = _f_230;
      e.mem[_t_37 + 3] = _f_231;
      e.mem[_t_37 + 4] = _f_232;
      e.mem[_t_37 + 5] = _f_233;
      e.mem[_t_37 + 6] = _f_234;
      e.mem[_t_37 + 7] = _f_235;
      e.mem[_t_37 + 8] = _f_236;
      e.mem[_t_37 + 9] = _f_237;
      e.mem[_t_37 + 10] = _f_238;
      e.mem[_t_37 + 11] = _f_239;
      e.mem[_t_37 + 12] = _o_196;
      e.mem[_t_37 + 13] = _o_197;
      e.mem[_t_37 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_37 + 15] = 7ull;
      e.mem[_t_37 + 16] = 2ull;
      e.mem[_t_37 + 17] = term_ctr(CID_OWNERS_MOTION, _nd_22);
      return term_tsk(FID_COMMANDS_INSERT_MAIN, _t_37);
    }
    r0 = _f_228;
    r1 = _f_229;
    r2 = _f_230;
    r3 = _f_231;
    r4 = _f_232;
    r5 = _f_233;
    r6 = _f_234;
    r7 = _f_235;
    r8 = _f_236;
    r9 = _f_237;
    r10 = _f_238;
    r11 = _f_239;
    r12 = _o_196;
    r13 = _o_197;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 7ull;
    r16 = 2ull;
    r17 = term_ctr(CID_OWNERS_MOTION, _nd_22);
    WL_JMP(FID_COMMANDS_INSERT_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K482)
  {
    u32 _h_89 = r0;
    u32 _h_90 = r1;
    u32 _h_91 = r2;
    Term _h_92 = r3;
    Term _h_93 = r4;
    Term _h_94 = r5;
    Term _h_95 = r6;
    Term _h_96 = r7;
    Term _h_97 = r8;
    u32 _h_98 = r9;
    Term _h_99 = r10;
    u32 _h_100 = r11;
    Term _h_101 = r12;
    u32 _h_102 = r13;
    Term _h_103 = r14;
    Term _h_104 = r15;
    Term _h_105 = r16;
    WL_OPEN
    u32 _o_198 = 0;
    u32 _o_199 = 0;
    u32 _o_200 = 0;
    Term _o_201 = 0;
    Term _o_202 = 0;
    Term _o_203 = 0;
    Term _o_204 = 0;
    Term _o_205 = 0;
    Term _o_206 = 0;
    u32 _o_207 = 0;
    Term _o_208 = 0;
    u32 _o_209 = 0;
    Term _o_210 = 0;
    u32 _o_211 = 0;
    Term _o_212 = 0;
    if (_h_89 == 0) {
      _o_198 = 0;
      u32 _o_213 = 0;
      if (_h_102 == 0) {
        _o_213 = 0;
      } else {
        _o_213 = 1;
      }
      _o_199 = _h_90;
      _o_200 = _h_91;
      _o_201 = _h_92;
      _o_202 = _h_93;
      _o_203 = _h_94;
      _o_204 = _h_95;
      _o_205 = _h_96;
      _o_206 = _h_97;
      _o_207 = _h_98;
      _o_208 = _h_99;
      _o_209 = _h_100;
      _o_210 = _h_101;
      _o_211 = _o_213;
    } else {
      _o_198 = 1;
      u32 _o_214 = 0;
      if (_h_102 == 0) {
        _o_214 = 0;
      } else {
        _o_214 = 1;
      }
      _o_199 = _h_90;
      _o_200 = _h_91;
      _o_201 = _h_92;
      _o_202 = _h_93;
      _o_203 = _h_94;
      _o_204 = _h_95;
      _o_205 = _h_96;
      _o_206 = _h_97;
      _o_207 = _h_98;
      _o_208 = _h_99;
      _o_209 = _h_100;
      _o_210 = _h_101;
      _o_211 = _o_214;
      _o_212 = _h_105;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K483;
      WL_PUSHN(1);
    } else {
      u64 _t_38 = task_node(e, FID_MAIN_K483, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K483, _t_38);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUEUED)) {
      u64 _t_39 = task_node(e, FID_QUEUED, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = term_ctr(CID_SCON, STAT_OFF + 398);
      e.mem[_t_39 + 1] = _o_198;
      e.mem[_t_39 + 2] = _o_199;
      e.mem[_t_39 + 3] = _o_200;
      e.mem[_t_39 + 4] = _o_201;
      e.mem[_t_39 + 5] = _o_202;
      e.mem[_t_39 + 6] = _o_203;
      e.mem[_t_39 + 7] = _o_204;
      e.mem[_t_39 + 8] = _o_205;
      e.mem[_t_39 + 9] = _o_206;
      e.mem[_t_39 + 10] = _o_207;
      e.mem[_t_39 + 11] = _o_208;
      e.mem[_t_39 + 12] = _o_209;
      e.mem[_t_39 + 13] = _o_210;
      e.mem[_t_39 + 14] = _o_211;
      e.mem[_t_39 + 15] = _o_212;
      return term_tsk(FID_QUEUED, _t_39);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 398);
    r1 = _o_198;
    r2 = _o_199;
    r3 = _o_200;
    r4 = _o_201;
    r5 = _o_202;
    r6 = _o_203;
    r7 = _o_204;
    r8 = _o_205;
    r9 = _o_206;
    r10 = _o_207;
    r11 = _o_208;
    r12 = _o_209;
    r13 = _o_210;
    r14 = _o_211;
    r15 = _o_212;
    WL_JMP(FID_QUEUED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K483)
  {
    Term _h_106 = r0;
    WL_OPEN
    u64 _nd_23 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_23 + 0] = _h_106;
    r0 = term_clo(FID_MAIN_C484, _nd_23);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C484)
  {
    Term _h_107 = r0;
    Term _x_30 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_119 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_119 + 0] = _h_107;
      e.mem[_t_119 + 1] = term_clo(FID_MAIN_C485, 0);
      e.mem[_t_119 + 2] = _x_30;
      return term_tsk(FID_IO_BIND, _t_119);
    }
    r0 = _h_107;
    r1 = term_clo(FID_MAIN_C485, 0);
    r2 = _x_30;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C485)
  {
    Term _x_31 = r0;
    WL_OPEN
    Term _fb_24[15];
    u64 _sp_24 = ctr_take(e, _x_31, 15, _fb_24);
    u32 _f_243 = _fb_24[0];
    u32 _f_244 = _fb_24[1];
    Term _f_245 = _fb_24[2];
    Term _f_246 = _fb_24[3];
    Term _f_247 = _fb_24[4];
    Term _f_248 = _fb_24[5];
    Term _f_249 = _fb_24[6];
    Term _f_250 = _fb_24[7];
    u32 _f_251 = _fb_24[8];
    Term _f_252 = _fb_24[9];
    u32 _f_253 = _fb_24[10];
    Term _f_254 = _fb_24[11];
    u32 _f_255 = _fb_24[12];
    Term _f_256 = _fb_24[13];
    Term _f_257 = _fb_24[14];
    spare_free(e, cls_fit(15), _sp_24);
    u32 _o_215 = 0;
    if (_f_255 == 0) {
      _o_215 = 0;
    } else {
      _o_215 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K486;
      WL_PUSHN(1);
    } else {
      u64 _t_40 = task_node(e, FID_MAIN_K486, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K486, _t_40);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_41 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 410);
      e.mem[_t_41 + 1] = 0;
      e.mem[_t_41 + 2] = _f_243;
      e.mem[_t_41 + 3] = _f_244;
      e.mem[_t_41 + 4] = _f_245;
      e.mem[_t_41 + 5] = _f_246;
      e.mem[_t_41 + 6] = _f_247;
      e.mem[_t_41 + 7] = _f_248;
      e.mem[_t_41 + 8] = _f_249;
      e.mem[_t_41 + 9] = _f_250;
      e.mem[_t_41 + 10] = _f_251;
      e.mem[_t_41 + 11] = _f_252;
      e.mem[_t_41 + 12] = _f_253;
      e.mem[_t_41 + 13] = _f_254;
      e.mem[_t_41 + 14] = _o_215;
      return term_tsk(FID_EACH, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 410);
    r1 = 0;
    r2 = _f_243;
    r3 = _f_244;
    r4 = _f_245;
    r5 = _f_246;
    r6 = _f_247;
    r7 = _f_248;
    r8 = _f_249;
    r9 = _f_250;
    r10 = _f_251;
    r11 = _f_252;
    r12 = _f_253;
    r13 = _f_254;
    r14 = _o_215;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K486)
  {
    Term _h_108 = r0;
    WL_OPEN
    u64 _nd_24 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_24 + 0] = _h_108;
    r0 = term_clo(FID_MAIN_C487, _nd_24);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C487)
  {
    Term _h_109 = r0;
    Term _x_32 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_118 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_118 + 0] = _h_109;
      e.mem[_t_118 + 1] = term_clo(FID_MAIN_C488, 0);
      e.mem[_t_118 + 2] = _x_32;
      return term_tsk(FID_IO_BIND, _t_118);
    }
    r0 = _h_109;
    r1 = term_clo(FID_MAIN_C488, 0);
    r2 = _x_32;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C488)
  {
    Term _x_33 = r0;
    WL_OPEN
    Term _fb_25[15];
    u64 _sp_25 = ctr_take(e, _x_33, 15, _fb_25);
    u32 _f_258 = _fb_25[0];
    u32 _f_259 = _fb_25[1];
    Term _f_260 = _fb_25[2];
    Term _f_261 = _fb_25[3];
    Term _f_262 = _fb_25[4];
    Term _f_263 = _fb_25[5];
    Term _f_264 = _fb_25[6];
    Term _f_265 = _fb_25[7];
    u32 _f_266 = _fb_25[8];
    Term _f_267 = _fb_25[9];
    u32 _f_268 = _fb_25[10];
    Term _f_269 = _fb_25[11];
    u32 _f_270 = _fb_25[12];
    Term _f_271 = _fb_25[13];
    Term _f_272 = _fb_25[14];
    spare_free(e, cls_fit(15), _sp_25);
    u32 _o_216 = 0;
    if (_f_270 == 0) {
      _o_216 = 0;
    } else {
      _o_216 = 1;
    }
    u32 _o_217 = 0;
    Term _o_218 = 0;
    if (_o_216 == 0) {
      _o_217 = 0;
    } else {
      _o_217 = 1;
      _o_218 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K489;
      WL_PUSHN(1);
    } else {
      u64 _t_42 = task_node(e, FID_MAIN_K489, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K489, _t_42);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_APPLY_CHECKED)) {
      u64 _t_43 = task_node(e, FID_COMMANDS_APPLY_CHECKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _f_258;
      e.mem[_t_43 + 1] = _f_259;
      e.mem[_t_43 + 2] = _f_260;
      e.mem[_t_43 + 3] = _f_261;
      e.mem[_t_43 + 4] = _f_262;
      e.mem[_t_43 + 5] = _f_263;
      e.mem[_t_43 + 6] = _f_264;
      e.mem[_t_43 + 7] = _f_265;
      e.mem[_t_43 + 8] = _f_266;
      e.mem[_t_43 + 9] = _f_267;
      e.mem[_t_43 + 10] = _f_268;
      e.mem[_t_43 + 11] = _f_269;
      e.mem[_t_43 + 12] = _o_217;
      e.mem[_t_43 + 13] = _o_218;
      e.mem[_t_43 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_43 + 15] = 20ull;
      return term_tsk(FID_COMMANDS_APPLY_CHECKED, _t_43);
    }
    r0 = _f_258;
    r1 = _f_259;
    r2 = _f_260;
    r3 = _f_261;
    r4 = _f_262;
    r5 = _f_263;
    r6 = _f_264;
    r7 = _f_265;
    r8 = _f_266;
    r9 = _f_267;
    r10 = _f_268;
    r11 = _f_269;
    r12 = _o_217;
    r13 = _o_218;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 20ull;
    WL_JMP(FID_COMMANDS_APPLY_CHECKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K489)
  {
    u32 _h_110 = r0;
    u32 _h_111 = r1;
    u32 _h_112 = r2;
    Term _h_113 = r3;
    Term _h_114 = r4;
    Term _h_115 = r5;
    Term _h_116 = r6;
    Term _h_117 = r7;
    Term _h_118 = r8;
    u32 _h_119 = r9;
    Term _h_120 = r10;
    u32 _h_121 = r11;
    Term _h_122 = r12;
    u32 _h_123 = r13;
    Term _h_124 = r14;
    Term _h_125 = r15;
    Term _h_126 = r16;
    u32 _h_127 = r17;
    Term _h_128 = r18;
    u32 _h_129 = r19;
    Term _h_130 = r20;
    u32 _h_131 = r21;
    Term _h_132 = r22;
    u32 _h_133 = r23;
    u32 _h_134 = r24;
    Term _h_135 = r25;
    WL_OPEN
    u32 _o_219 = 0;
    u32 _o_220 = 0;
    u32 _o_221 = 0;
    Term _o_222 = 0;
    Term _o_223 = 0;
    Term _o_224 = 0;
    Term _o_225 = 0;
    Term _o_226 = 0;
    Term _o_227 = 0;
    u32 _o_228 = 0;
    Term _o_229 = 0;
    u32 _o_230 = 0;
    Term _o_231 = 0;
    u32 _o_232 = 0;
    Term _o_233 = 0;
    u32 _o_234 = 0;
    Term _o_235 = 0;
    u32 _o_236 = 0;
    u32 _o_237 = 0;
    Term _o_238 = 0;
    u32 _o_239 = 0;
    u32 _o_240 = 0;
    u32 _o_241 = 0;
    u32 _o_242 = 0;
    Term _o_243 = 0;
    if (_h_110 == 0) {
      _o_219 = 0;
      u32 _o_244 = 0;
      if (_h_123 == 0) {
        _o_244 = 0;
      } else {
        _o_244 = 1;
      }
      _o_220 = _h_111;
      _o_221 = _h_112;
      _o_222 = _h_113;
      _o_223 = _h_114;
      _o_224 = _h_115;
      _o_225 = _h_116;
      _o_226 = _h_117;
      _o_227 = _h_118;
      _o_228 = _h_119;
      _o_229 = _h_120;
      _o_230 = _h_121;
      _o_231 = _h_122;
      _o_232 = _o_244;
      _o_233 = _h_126;
    } else if (_h_110 == 1) {
      _o_219 = 1;
      u32 _o_245 = 0;
      if (_h_123 == 0) {
        _o_245 = 0;
      } else {
        _o_245 = 1;
      }
      _o_220 = _h_111;
      _o_221 = _h_112;
      _o_222 = _h_113;
      _o_223 = _h_114;
      _o_224 = _h_115;
      _o_225 = _h_116;
      _o_226 = _h_117;
      _o_227 = _h_118;
      _o_228 = _h_119;
      _o_229 = _h_120;
      _o_230 = _h_121;
      _o_231 = _h_122;
      _o_232 = _o_245;
    } else {
      _o_219 = 2;
      u32 _o_246 = 0;
      if (_h_123 == 0) {
        _o_246 = 0;
      } else {
        _o_246 = 1;
      }
      u32 _o_247 = 0;
      Term _o_248 = 0;
      u32 _o_249 = 0;
      if (_h_127 == 0) {
        _o_247 = 0;
      } else {
        _o_247 = 1;
        Term _fb_26[2];
        u64 _sp_26 = ctr_take(e, _h_128, 2, _fb_26);
        Term _f_273 = _fb_26[0];
        u32 _f_274 = _fb_26[1];
        spare_free(e, cls_fit(2), _sp_26);
        _o_248 = _f_273;
        _o_249 = _f_274;
      }
      u32 _o_250 = 0;
      Term _o_251 = 0;
      u32 _o_252 = 0;
      if (_h_129 == 0) {
        _o_250 = 0;
      } else {
        _o_250 = 1;
        Term _fb_27[2];
        u64 _sp_27 = ctr_take(e, _h_130, 2, _fb_27);
        Term _f_275 = _fb_27[0];
        u32 _f_276 = _fb_27[1];
        spare_free(e, cls_fit(2), _sp_27);
        _o_251 = _f_275;
        _o_252 = _f_276;
      }
      u32 _o_253 = 0;
      if (_h_131 == 0) {
        _o_253 = 0;
      } else {
        _o_253 = 1;
      }
      _o_220 = _h_111;
      _o_221 = _h_112;
      _o_222 = _h_113;
      _o_223 = _h_114;
      _o_224 = _h_115;
      _o_225 = _h_116;
      _o_226 = _h_117;
      _o_227 = _h_118;
      _o_228 = _h_119;
      _o_229 = _h_120;
      _o_230 = _h_121;
      _o_231 = _h_122;
      _o_232 = _o_246;
      _o_233 = _h_126;
      _o_234 = _o_247;
      _o_235 = _o_248;
      _o_236 = _o_249;
      _o_237 = _o_250;
      _o_238 = _o_251;
      _o_239 = _o_252;
      _o_240 = _o_253;
      _o_241 = _h_133;
      _o_242 = _h_134;
      _o_243 = _h_135;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K490;
      WL_PUSHN(1);
    } else {
      u64 _t_44 = task_node(e, FID_MAIN_K490, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K490, _t_44);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_APPLIED)) {
      u64 _t_45 = task_node(e, FID_APPLIED, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 426);
      e.mem[_t_45 + 1] = _o_219;
      e.mem[_t_45 + 2] = _o_220;
      e.mem[_t_45 + 3] = _o_221;
      e.mem[_t_45 + 4] = _o_222;
      e.mem[_t_45 + 5] = _o_223;
      e.mem[_t_45 + 6] = _o_224;
      e.mem[_t_45 + 7] = _o_225;
      e.mem[_t_45 + 8] = _o_226;
      e.mem[_t_45 + 9] = _o_227;
      e.mem[_t_45 + 10] = _o_228;
      e.mem[_t_45 + 11] = _o_229;
      e.mem[_t_45 + 12] = _o_230;
      e.mem[_t_45 + 13] = _o_231;
      e.mem[_t_45 + 14] = _o_232;
      e.mem[_t_45 + 15] = _o_233;
      e.mem[_t_45 + 16] = _o_234;
      e.mem[_t_45 + 17] = _o_235;
      e.mem[_t_45 + 18] = _o_236;
      e.mem[_t_45 + 19] = _o_237;
      e.mem[_t_45 + 20] = _o_238;
      e.mem[_t_45 + 21] = _o_239;
      e.mem[_t_45 + 22] = _o_240;
      e.mem[_t_45 + 23] = _o_241;
      e.mem[_t_45 + 24] = _o_242;
      e.mem[_t_45 + 25] = _o_243;
      return term_tsk(FID_APPLIED, _t_45);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 426);
    r1 = _o_219;
    r2 = _o_220;
    r3 = _o_221;
    r4 = _o_222;
    r5 = _o_223;
    r6 = _o_224;
    r7 = _o_225;
    r8 = _o_226;
    r9 = _o_227;
    r10 = _o_228;
    r11 = _o_229;
    r12 = _o_230;
    r13 = _o_231;
    r14 = _o_232;
    r15 = _o_233;
    r16 = _o_234;
    r17 = _o_235;
    r18 = _o_236;
    r19 = _o_237;
    r20 = _o_238;
    r21 = _o_239;
    r22 = _o_240;
    r23 = _o_241;
    r24 = _o_242;
    r25 = _o_243;
    WL_JMP(FID_APPLIED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K490)
  {
    Term _h_136 = r0;
    WL_OPEN
    u64 _nd_25 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_25 + 0] = _h_136;
    r0 = term_clo(FID_MAIN_C491, _nd_25);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C491)
  {
    Term _h_137 = r0;
    Term _x_34 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_117 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_117 + 0] = _h_137;
      e.mem[_t_117 + 1] = term_clo(FID_MAIN_C492, 0);
      e.mem[_t_117 + 2] = _x_34;
      return term_tsk(FID_IO_BIND, _t_117);
    }
    r0 = _h_137;
    r1 = term_clo(FID_MAIN_C492, 0);
    r2 = _x_34;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C492)
  {
    Term _x_35 = r0;
    WL_OPEN
    Term _fb_28[15];
    u64 _sp_28 = ctr_take(e, _x_35, 15, _fb_28);
    u32 _f_277 = _fb_28[0];
    u32 _f_278 = _fb_28[1];
    Term _f_279 = _fb_28[2];
    Term _f_280 = _fb_28[3];
    Term _f_281 = _fb_28[4];
    Term _f_282 = _fb_28[5];
    Term _f_283 = _fb_28[6];
    Term _f_284 = _fb_28[7];
    u32 _f_285 = _fb_28[8];
    Term _f_286 = _fb_28[9];
    u32 _f_287 = _fb_28[10];
    Term _f_288 = _fb_28[11];
    u32 _f_289 = _fb_28[12];
    Term _f_290 = _fb_28[13];
    Term _f_291 = _fb_28[14];
    spare_free(e, cls_fit(15), _sp_28);
    u32 _o_254 = 0;
    if (_f_289 == 0) {
      _o_254 = 0;
    } else {
      _o_254 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K493;
      WL_PUSHN(1);
    } else {
      u64 _t_46 = task_node(e, FID_MAIN_K493, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K493, _t_46);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_47 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 436);
      e.mem[_t_47 + 1] = 0;
      e.mem[_t_47 + 2] = _f_277;
      e.mem[_t_47 + 3] = _f_278;
      e.mem[_t_47 + 4] = _f_279;
      e.mem[_t_47 + 5] = _f_280;
      e.mem[_t_47 + 6] = _f_281;
      e.mem[_t_47 + 7] = _f_282;
      e.mem[_t_47 + 8] = _f_283;
      e.mem[_t_47 + 9] = _f_284;
      e.mem[_t_47 + 10] = _f_285;
      e.mem[_t_47 + 11] = _f_286;
      e.mem[_t_47 + 12] = _f_287;
      e.mem[_t_47 + 13] = _f_288;
      e.mem[_t_47 + 14] = _o_254;
      return term_tsk(FID_EACH, _t_47);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 436);
    r1 = 0;
    r2 = _f_277;
    r3 = _f_278;
    r4 = _f_279;
    r5 = _f_280;
    r6 = _f_281;
    r7 = _f_282;
    r8 = _f_283;
    r9 = _f_284;
    r10 = _f_285;
    r11 = _f_286;
    r12 = _f_287;
    r13 = _f_288;
    r14 = _o_254;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K493)
  {
    Term _h_138 = r0;
    WL_OPEN
    u64 _nd_26 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_26 + 0] = _h_138;
    r0 = term_clo(FID_MAIN_C494, _nd_26);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C494)
  {
    Term _h_139 = r0;
    Term _x_36 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_116 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_116 + 0] = _h_139;
      e.mem[_t_116 + 1] = term_clo(FID_MAIN_C495, 0);
      e.mem[_t_116 + 2] = _x_36;
      return term_tsk(FID_IO_BIND, _t_116);
    }
    r0 = _h_139;
    r1 = term_clo(FID_MAIN_C495, 0);
    r2 = _x_36;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C495)
  {
    Term _x_37 = r0;
    WL_OPEN
    Term _fb_29[15];
    u64 _sp_29 = ctr_take(e, _x_37, 15, _fb_29);
    u32 _f_292 = _fb_29[0];
    u32 _f_293 = _fb_29[1];
    Term _f_294 = _fb_29[2];
    Term _f_295 = _fb_29[3];
    Term _f_296 = _fb_29[4];
    Term _f_297 = _fb_29[5];
    Term _f_298 = _fb_29[6];
    Term _f_299 = _fb_29[7];
    u32 _f_300 = _fb_29[8];
    Term _f_301 = _fb_29[9];
    u32 _f_302 = _fb_29[10];
    Term _f_303 = _fb_29[11];
    u32 _f_304 = _fb_29[12];
    Term _f_305 = _fb_29[13];
    Term _f_306 = _fb_29[14];
    spare_free(e, cls_fit(15), _sp_29);
    u32 _o_255 = 0;
    if (_f_304 == 0) {
      _o_255 = 0;
    } else {
      _o_255 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K496;
      WL_PUSHN(1);
    } else {
      u64 _t_48 = task_node(e, FID_MAIN_K496, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K496, _t_48);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_49 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 450);
      e.mem[_t_49 + 1] = 1;
      e.mem[_t_49 + 2] = _f_292;
      e.mem[_t_49 + 3] = _f_293;
      e.mem[_t_49 + 4] = _f_294;
      e.mem[_t_49 + 5] = _f_295;
      e.mem[_t_49 + 6] = _f_296;
      e.mem[_t_49 + 7] = _f_297;
      e.mem[_t_49 + 8] = _f_298;
      e.mem[_t_49 + 9] = _f_299;
      e.mem[_t_49 + 10] = _f_300;
      e.mem[_t_49 + 11] = _f_301;
      e.mem[_t_49 + 12] = _f_302;
      e.mem[_t_49 + 13] = _f_303;
      e.mem[_t_49 + 14] = _o_255;
      return term_tsk(FID_EACH, _t_49);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 450);
    r1 = 1;
    r2 = _f_292;
    r3 = _f_293;
    r4 = _f_294;
    r5 = _f_295;
    r6 = _f_296;
    r7 = _f_297;
    r8 = _f_298;
    r9 = _f_299;
    r10 = _f_300;
    r11 = _f_301;
    r12 = _f_302;
    r13 = _f_303;
    r14 = _o_255;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K496)
  {
    Term _h_140 = r0;
    WL_OPEN
    u64 _nd_27 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_27 + 0] = _h_140;
    r0 = term_clo(FID_MAIN_C497, _nd_27);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C497)
  {
    Term _h_141 = r0;
    Term _x_38 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_115 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_115 + 0] = _h_141;
      e.mem[_t_115 + 1] = term_clo(FID_MAIN_C498, 0);
      e.mem[_t_115 + 2] = _x_38;
      return term_tsk(FID_IO_BIND, _t_115);
    }
    r0 = _h_141;
    r1 = term_clo(FID_MAIN_C498, 0);
    r2 = _x_38;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C498)
  {
    Term _x_39 = r0;
    WL_OPEN
    Term _fb_30[15];
    u64 _sp_30 = ctr_take(e, _x_39, 15, _fb_30);
    u32 _f_307 = _fb_30[0];
    u32 _f_308 = _fb_30[1];
    Term _f_309 = _fb_30[2];
    Term _f_310 = _fb_30[3];
    Term _f_311 = _fb_30[4];
    Term _f_312 = _fb_30[5];
    Term _f_313 = _fb_30[6];
    Term _f_314 = _fb_30[7];
    u32 _f_315 = _fb_30[8];
    Term _f_316 = _fb_30[9];
    u32 _f_317 = _fb_30[10];
    Term _f_318 = _fb_30[11];
    u32 _f_319 = _fb_30[12];
    Term _f_320 = _fb_30[13];
    Term _f_321 = _fb_30[14];
    spare_free(e, cls_fit(15), _sp_30);
    u32 _o_256 = 0;
    if (_f_319 == 0) {
      _o_256 = 0;
    } else {
      _o_256 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K499;
      WL_PUSHN(1);
    } else {
      u64 _t_50 = task_node(e, FID_MAIN_K499, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K499, _t_50);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_51 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 464);
      e.mem[_t_51 + 1] = 2;
      e.mem[_t_51 + 2] = _f_307;
      e.mem[_t_51 + 3] = _f_308;
      e.mem[_t_51 + 4] = _f_309;
      e.mem[_t_51 + 5] = _f_310;
      e.mem[_t_51 + 6] = _f_311;
      e.mem[_t_51 + 7] = _f_312;
      e.mem[_t_51 + 8] = _f_313;
      e.mem[_t_51 + 9] = _f_314;
      e.mem[_t_51 + 10] = _f_315;
      e.mem[_t_51 + 11] = _f_316;
      e.mem[_t_51 + 12] = _f_317;
      e.mem[_t_51 + 13] = _f_318;
      e.mem[_t_51 + 14] = _o_256;
      return term_tsk(FID_EACH, _t_51);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 464);
    r1 = 2;
    r2 = _f_307;
    r3 = _f_308;
    r4 = _f_309;
    r5 = _f_310;
    r6 = _f_311;
    r7 = _f_312;
    r8 = _f_313;
    r9 = _f_314;
    r10 = _f_315;
    r11 = _f_316;
    r12 = _f_317;
    r13 = _f_318;
    r14 = _o_256;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K499)
  {
    Term _h_142 = r0;
    WL_OPEN
    u64 _nd_28 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_28 + 0] = _h_142;
    r0 = term_clo(FID_MAIN_C500, _nd_28);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C500)
  {
    Term _h_143 = r0;
    Term _x_40 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_114 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_114 + 0] = _h_143;
      e.mem[_t_114 + 1] = term_clo(FID_MAIN_C501, 0);
      e.mem[_t_114 + 2] = _x_40;
      return term_tsk(FID_IO_BIND, _t_114);
    }
    r0 = _h_143;
    r1 = term_clo(FID_MAIN_C501, 0);
    r2 = _x_40;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C501)
  {
    Term _x_41 = r0;
    WL_OPEN
    Term _fb_31[15];
    u64 _sp_31 = ctr_take(e, _x_41, 15, _fb_31);
    u32 _f_322 = _fb_31[0];
    u32 _f_323 = _fb_31[1];
    Term _f_324 = _fb_31[2];
    Term _f_325 = _fb_31[3];
    Term _f_326 = _fb_31[4];
    Term _f_327 = _fb_31[5];
    Term _f_328 = _fb_31[6];
    Term _f_329 = _fb_31[7];
    u32 _f_330 = _fb_31[8];
    Term _f_331 = _fb_31[9];
    u32 _f_332 = _fb_31[10];
    Term _f_333 = _fb_31[11];
    u32 _f_334 = _fb_31[12];
    Term _f_335 = _fb_31[13];
    Term _f_336 = _fb_31[14];
    spare_free(e, cls_fit(15), _sp_31);
    u32 _o_257 = 0;
    if (_f_334 == 0) {
      _o_257 = 0;
    } else {
      _o_257 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K502;
      WL_PUSHN(1);
    } else {
      u64 _t_52 = task_node(e, FID_MAIN_K502, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K502, _t_52);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_53 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 480);
      e.mem[_t_53 + 1] = _f_322;
      e.mem[_t_53 + 2] = _f_323;
      e.mem[_t_53 + 3] = _f_324;
      e.mem[_t_53 + 4] = _f_325;
      e.mem[_t_53 + 5] = _f_326;
      e.mem[_t_53 + 6] = _f_327;
      e.mem[_t_53 + 7] = _f_328;
      e.mem[_t_53 + 8] = _f_329;
      e.mem[_t_53 + 9] = _f_330;
      e.mem[_t_53 + 10] = _f_331;
      e.mem[_t_53 + 11] = _f_332;
      e.mem[_t_53 + 12] = _f_333;
      e.mem[_t_53 + 13] = _o_257;
      e.mem[_t_53 + 14] = 1ull;
      return term_tsk(FID_SNAPSHOT, _t_53);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 480);
    r1 = _f_322;
    r2 = _f_323;
    r3 = _f_324;
    r4 = _f_325;
    r5 = _f_326;
    r6 = _f_327;
    r7 = _f_328;
    r8 = _f_329;
    r9 = _f_330;
    r10 = _f_331;
    r11 = _f_332;
    r12 = _f_333;
    r13 = _o_257;
    r14 = 1ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K502)
  {
    Term _h_144 = r0;
    WL_OPEN
    u64 _nd_29 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_29 + 0] = _h_144;
    r0 = term_clo(FID_MAIN_C503, _nd_29);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C503)
  {
    Term _h_145 = r0;
    Term _x_42 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_113 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_113 + 0] = _h_145;
      e.mem[_t_113 + 1] = term_clo(FID_MAIN_C504, 0);
      e.mem[_t_113 + 2] = _x_42;
      return term_tsk(FID_IO_BIND, _t_113);
    }
    r0 = _h_145;
    r1 = term_clo(FID_MAIN_C504, 0);
    r2 = _x_42;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C504)
  {
    Term _x_43 = r0;
    WL_OPEN
    Term _fb_32[15];
    u64 _sp_32 = ctr_take(e, _x_43, 15, _fb_32);
    u32 _f_337 = _fb_32[0];
    u32 _f_338 = _fb_32[1];
    Term _f_339 = _fb_32[2];
    Term _f_340 = _fb_32[3];
    Term _f_341 = _fb_32[4];
    Term _f_342 = _fb_32[5];
    Term _f_343 = _fb_32[6];
    Term _f_344 = _fb_32[7];
    u32 _f_345 = _fb_32[8];
    Term _f_346 = _fb_32[9];
    u32 _f_347 = _fb_32[10];
    Term _f_348 = _fb_32[11];
    u32 _f_349 = _fb_32[12];
    Term _f_350 = _fb_32[13];
    Term _f_351 = _fb_32[14];
    spare_free(e, cls_fit(15), _sp_32);
    u32 _o_258 = 0;
    if (_f_349 == 0) {
      _o_258 = 0;
    } else {
      _o_258 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K505;
      WL_PUSHN(1);
    } else {
      u64 _t_54 = task_node(e, FID_MAIN_K505, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K505, _t_54);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_55 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = term_ctr(CID_SCON, STAT_OFF + 496);
      e.mem[_t_55 + 1] = _f_337;
      e.mem[_t_55 + 2] = _f_338;
      e.mem[_t_55 + 3] = _f_339;
      e.mem[_t_55 + 4] = _f_340;
      e.mem[_t_55 + 5] = _f_341;
      e.mem[_t_55 + 6] = _f_342;
      e.mem[_t_55 + 7] = _f_343;
      e.mem[_t_55 + 8] = _f_344;
      e.mem[_t_55 + 9] = _f_345;
      e.mem[_t_55 + 10] = _f_346;
      e.mem[_t_55 + 11] = _f_347;
      e.mem[_t_55 + 12] = _f_348;
      e.mem[_t_55 + 13] = _o_258;
      e.mem[_t_55 + 14] = 2ull;
      return term_tsk(FID_SNAPSHOT, _t_55);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 496);
    r1 = _f_337;
    r2 = _f_338;
    r3 = _f_339;
    r4 = _f_340;
    r5 = _f_341;
    r6 = _f_342;
    r7 = _f_343;
    r8 = _f_344;
    r9 = _f_345;
    r10 = _f_346;
    r11 = _f_347;
    r12 = _f_348;
    r13 = _o_258;
    r14 = 2ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K505)
  {
    Term _h_146 = r0;
    WL_OPEN
    u64 _nd_30 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_30 + 0] = _h_146;
    r0 = term_clo(FID_MAIN_C506, _nd_30);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C506)
  {
    Term _h_147 = r0;
    Term _x_44 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_112 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_112 + 0] = _h_147;
      e.mem[_t_112 + 1] = term_clo(FID_MAIN_C507, 0);
      e.mem[_t_112 + 2] = _x_44;
      return term_tsk(FID_IO_BIND, _t_112);
    }
    r0 = _h_147;
    r1 = term_clo(FID_MAIN_C507, 0);
    r2 = _x_44;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C507)
  {
    Term _x_45 = r0;
    WL_OPEN
    Term _fb_33[15];
    u64 _sp_33 = ctr_take(e, _x_45, 15, _fb_33);
    u32 _f_352 = _fb_33[0];
    u32 _f_353 = _fb_33[1];
    Term _f_354 = _fb_33[2];
    Term _f_355 = _fb_33[3];
    Term _f_356 = _fb_33[4];
    Term _f_357 = _fb_33[5];
    Term _f_358 = _fb_33[6];
    Term _f_359 = _fb_33[7];
    u32 _f_360 = _fb_33[8];
    Term _f_361 = _fb_33[9];
    u32 _f_362 = _fb_33[10];
    Term _f_363 = _fb_33[11];
    u32 _f_364 = _fb_33[12];
    Term _f_365 = _fb_33[13];
    Term _f_366 = _fb_33[14];
    spare_free(e, cls_fit(15), _sp_33);
    u32 _o_259 = 0;
    if (_f_364 == 0) {
      _o_259 = 0;
    } else {
      _o_259 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K508;
      WL_PUSHN(1);
    } else {
      u64 _t_56 = task_node(e, FID_MAIN_K508, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K508, _t_56);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_57 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = term_ctr(CID_SCON, STAT_OFF + 512);
      e.mem[_t_57 + 1] = _f_352;
      e.mem[_t_57 + 2] = _f_353;
      e.mem[_t_57 + 3] = _f_354;
      e.mem[_t_57 + 4] = _f_355;
      e.mem[_t_57 + 5] = _f_356;
      e.mem[_t_57 + 6] = _f_357;
      e.mem[_t_57 + 7] = _f_358;
      e.mem[_t_57 + 8] = _f_359;
      e.mem[_t_57 + 9] = _f_360;
      e.mem[_t_57 + 10] = _f_361;
      e.mem[_t_57 + 11] = _f_362;
      e.mem[_t_57 + 12] = _f_363;
      e.mem[_t_57 + 13] = _o_259;
      e.mem[_t_57 + 14] = 3ull;
      return term_tsk(FID_SNAPSHOT, _t_57);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 512);
    r1 = _f_352;
    r2 = _f_353;
    r3 = _f_354;
    r4 = _f_355;
    r5 = _f_356;
    r6 = _f_357;
    r7 = _f_358;
    r8 = _f_359;
    r9 = _f_360;
    r10 = _f_361;
    r11 = _f_362;
    r12 = _f_363;
    r13 = _o_259;
    r14 = 3ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K508)
  {
    Term _h_148 = r0;
    WL_OPEN
    u64 _nd_31 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_31 + 0] = _h_148;
    r0 = term_clo(FID_MAIN_C509, _nd_31);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C509)
  {
    Term _h_149 = r0;
    Term _x_46 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_111 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_111 + 0] = _h_149;
      e.mem[_t_111 + 1] = term_clo(FID_MAIN_C510, 0);
      e.mem[_t_111 + 2] = _x_46;
      return term_tsk(FID_IO_BIND, _t_111);
    }
    r0 = _h_149;
    r1 = term_clo(FID_MAIN_C510, 0);
    r2 = _x_46;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C510)
  {
    Term _x_47 = r0;
    WL_OPEN
    Term _fb_34[15];
    u64 _sp_34 = ctr_take(e, _x_47, 15, _fb_34);
    u32 _f_367 = _fb_34[0];
    u32 _f_368 = _fb_34[1];
    Term _f_369 = _fb_34[2];
    Term _f_370 = _fb_34[3];
    Term _f_371 = _fb_34[4];
    Term _f_372 = _fb_34[5];
    Term _f_373 = _fb_34[6];
    Term _f_374 = _fb_34[7];
    u32 _f_375 = _fb_34[8];
    Term _f_376 = _fb_34[9];
    u32 _f_377 = _fb_34[10];
    Term _f_378 = _fb_34[11];
    u32 _f_379 = _fb_34[12];
    Term _f_380 = _fb_34[13];
    Term _f_381 = _fb_34[14];
    spare_free(e, cls_fit(15), _sp_34);
    u32 _o_260 = 0;
    if (_f_379 == 0) {
      _o_260 = 0;
    } else {
      _o_260 = 1;
    }
    u32 _o_261 = 0;
    Term _o_262 = 0;
    if (_o_260 == 0) {
      _o_261 = 0;
    } else {
      _o_261 = 1;
      _o_262 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K511;
      WL_PUSHN(1);
    } else {
      u64 _t_58 = task_node(e, FID_MAIN_K511, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K511, _t_58);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_DESPAWN)) {
      u64 _t_59 = task_node(e, FID_COMMANDS_DESPAWN, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = _f_367;
      e.mem[_t_59 + 1] = _f_368;
      e.mem[_t_59 + 2] = _f_369;
      e.mem[_t_59 + 3] = _f_370;
      e.mem[_t_59 + 4] = _f_371;
      e.mem[_t_59 + 5] = _f_372;
      e.mem[_t_59 + 6] = _f_373;
      e.mem[_t_59 + 7] = _f_374;
      e.mem[_t_59 + 8] = _f_375;
      e.mem[_t_59 + 9] = _f_376;
      e.mem[_t_59 + 10] = _f_377;
      e.mem[_t_59 + 11] = _f_378;
      e.mem[_t_59 + 12] = _o_261;
      e.mem[_t_59 + 13] = _o_262;
      e.mem[_t_59 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_59 + 15] = 7ull;
      e.mem[_t_59 + 16] = 2ull;
      return term_tsk(FID_COMMANDS_DESPAWN, _t_59);
    }
    r0 = _f_367;
    r1 = _f_368;
    r2 = _f_369;
    r3 = _f_370;
    r4 = _f_371;
    r5 = _f_372;
    r6 = _f_373;
    r7 = _f_374;
    r8 = _f_375;
    r9 = _f_376;
    r10 = _f_377;
    r11 = _f_378;
    r12 = _o_261;
    r13 = _o_262;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 7ull;
    r16 = 2ull;
    WL_JMP(FID_COMMANDS_DESPAWN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K511)
  {
    u32 _h_150 = r0;
    u32 _h_151 = r1;
    u32 _h_152 = r2;
    Term _h_153 = r3;
    Term _h_154 = r4;
    Term _h_155 = r5;
    Term _h_156 = r6;
    Term _h_157 = r7;
    Term _h_158 = r8;
    u32 _h_159 = r9;
    Term _h_160 = r10;
    u32 _h_161 = r11;
    Term _h_162 = r12;
    u32 _h_163 = r13;
    Term _h_164 = r14;
    Term _h_165 = r15;
    WL_OPEN
    u32 _o_263 = 0;
    u32 _o_264 = 0;
    u32 _o_265 = 0;
    Term _o_266 = 0;
    Term _o_267 = 0;
    Term _o_268 = 0;
    Term _o_269 = 0;
    Term _o_270 = 0;
    Term _o_271 = 0;
    u32 _o_272 = 0;
    Term _o_273 = 0;
    u32 _o_274 = 0;
    Term _o_275 = 0;
    u32 _o_276 = 0;
    Term _o_277 = 0;
    if (_h_150 == 0) {
      _o_263 = 0;
      u32 _o_278 = 0;
      if (_h_163 == 0) {
        _o_278 = 0;
      } else {
        _o_278 = 1;
      }
      _o_264 = _h_151;
      _o_265 = _h_152;
      _o_266 = _h_153;
      _o_267 = _h_154;
      _o_268 = _h_155;
      _o_269 = _h_156;
      _o_270 = _h_157;
      _o_271 = _h_158;
      _o_272 = _h_159;
      _o_273 = _h_160;
      _o_274 = _h_161;
      _o_275 = _h_162;
      _o_276 = _o_278;
    } else {
      _o_263 = 1;
      u32 _o_279 = 0;
      if (_h_163 == 0) {
        _o_279 = 0;
      } else {
        _o_279 = 1;
      }
      _o_264 = _h_151;
      _o_265 = _h_152;
      _o_266 = _h_153;
      _o_267 = _h_154;
      _o_268 = _h_155;
      _o_269 = _h_156;
      _o_270 = _h_157;
      _o_271 = _h_158;
      _o_272 = _h_159;
      _o_273 = _h_160;
      _o_274 = _h_161;
      _o_275 = _h_162;
      _o_276 = _o_279;
      _o_277 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K512;
      WL_PUSHN(1);
    } else {
      u64 _t_60 = task_node(e, FID_MAIN_K512, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K512, _t_60);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUEUED)) {
      u64 _t_61 = task_node(e, FID_QUEUED, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = term_ctr(CID_SCON, STAT_OFF + 516);
      e.mem[_t_61 + 1] = _o_263;
      e.mem[_t_61 + 2] = _o_264;
      e.mem[_t_61 + 3] = _o_265;
      e.mem[_t_61 + 4] = _o_266;
      e.mem[_t_61 + 5] = _o_267;
      e.mem[_t_61 + 6] = _o_268;
      e.mem[_t_61 + 7] = _o_269;
      e.mem[_t_61 + 8] = _o_270;
      e.mem[_t_61 + 9] = _o_271;
      e.mem[_t_61 + 10] = _o_272;
      e.mem[_t_61 + 11] = _o_273;
      e.mem[_t_61 + 12] = _o_274;
      e.mem[_t_61 + 13] = _o_275;
      e.mem[_t_61 + 14] = _o_276;
      e.mem[_t_61 + 15] = _o_277;
      return term_tsk(FID_QUEUED, _t_61);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 516);
    r1 = _o_263;
    r2 = _o_264;
    r3 = _o_265;
    r4 = _o_266;
    r5 = _o_267;
    r6 = _o_268;
    r7 = _o_269;
    r8 = _o_270;
    r9 = _o_271;
    r10 = _o_272;
    r11 = _o_273;
    r12 = _o_274;
    r13 = _o_275;
    r14 = _o_276;
    r15 = _o_277;
    WL_JMP(FID_QUEUED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K512)
  {
    Term _h_166 = r0;
    WL_OPEN
    u64 _nd_32 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_32 + 0] = _h_166;
    r0 = term_clo(FID_MAIN_C513, _nd_32);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C513)
  {
    Term _h_167 = r0;
    Term _x_48 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_110 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_110 + 0] = _h_167;
      e.mem[_t_110 + 1] = term_clo(FID_MAIN_C514, 0);
      e.mem[_t_110 + 2] = _x_48;
      return term_tsk(FID_IO_BIND, _t_110);
    }
    r0 = _h_167;
    r1 = term_clo(FID_MAIN_C514, 0);
    r2 = _x_48;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C514)
  {
    Term _x_49 = r0;
    WL_OPEN
    Term _fb_35[15];
    u64 _sp_35 = ctr_take(e, _x_49, 15, _fb_35);
    u32 _f_382 = _fb_35[0];
    u32 _f_383 = _fb_35[1];
    Term _f_384 = _fb_35[2];
    Term _f_385 = _fb_35[3];
    Term _f_386 = _fb_35[4];
    Term _f_387 = _fb_35[5];
    Term _f_388 = _fb_35[6];
    Term _f_389 = _fb_35[7];
    u32 _f_390 = _fb_35[8];
    Term _f_391 = _fb_35[9];
    u32 _f_392 = _fb_35[10];
    Term _f_393 = _fb_35[11];
    u32 _f_394 = _fb_35[12];
    Term _f_395 = _fb_35[13];
    Term _f_396 = _fb_35[14];
    spare_free(e, cls_fit(15), _sp_35);
    u32 _o_280 = 0;
    if (_f_394 == 0) {
      _o_280 = 0;
    } else {
      _o_280 = 1;
    }
    u32 _v_340 = 0;
    u32 _v_341 = 0;
    u32 _v_342 = 0;
    Term _v_343 = 0;
    Term _v_344 = 0;
    Term _v_345 = 0;
    Term _v_346 = 0;
    Term _v_347 = 0;
    Term _v_348 = 0;
    u32 _v_349 = 0;
    Term _v_350 = 0;
    u32 _v_351 = 0;
    Term _v_352 = 0;
    u32 _v_353 = 0;
    Term _v_354 = 0;
    Term _v_355 = 0;
    u32 _v_356 = 0;
    Term _v_357 = 0;
    u32 _v_358 = 0;
    Term _v_359 = 0;
    u32 _v_360 = 0;
    Term _v_361 = 0;
    Term _fv_11[1];
    _fv_11[0] = 40ull;
    Term _a_19 = blk_new(e, 0, 2ull, 0, 1, _fv_11);
    Term _at_30 = blk_loc(e.mem, _a_19);
    Term _at_31 = blk_at(_a_19, 1ull, 0);
    u32 _c_15 = blk_read(e.mem, 0, _at_30, _at_31 + 0);
    blk_write(e.mem, 0, _at_30, _at_31 + 0, U32_BIN(40ull, +, 1ull));
    Term _at_32 = blk_loc(e.mem, _a_19);
    Term _at_33 = blk_at(_a_19, 2ull, 0);
    u32 _c_16 = blk_read(e.mem, 0, _at_32, _at_33 + 0);
    blk_write(e.mem, 0, _at_32, _at_33 + 0, U32_BIN(40ull, +, 2ull));
    Term _at_34 = blk_loc(e.mem, _a_19);
    Term _at_35 = blk_at(_a_19, 3ull, 0);
    u32 _c_17 = blk_read(e.mem, 0, _at_34, _at_35 + 0);
    blk_write(e.mem, 0, _at_34, _at_35 + 0, U32_BIN(40ull, +, 3ull));
    u64 _nd_33 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_33 + 0] = rfc_seal(e, _a_19);
    e.mem[_nd_33 + 1] = rfc_seal(e, 40ull);
    Term _fv_12[1];
    _fv_12[0] = 140ull;
    Term _a_20 = blk_new(e, 0, 2ull, 0, 1, _fv_12);
    Term _at_36 = blk_loc(e.mem, _a_20);
    Term _at_37 = blk_at(_a_20, 1ull, 0);
    u32 _c_18 = blk_read(e.mem, 0, _at_36, _at_37 + 0);
    blk_write(e.mem, 0, _at_36, _at_37 + 0, U32_BIN(140ull, +, 1ull));
    Term _at_38 = blk_loc(e.mem, _a_20);
    Term _at_39 = blk_at(_a_20, 2ull, 0);
    u32 _c_19 = blk_read(e.mem, 0, _at_38, _at_39 + 0);
    blk_write(e.mem, 0, _at_38, _at_39 + 0, U32_BIN(140ull, +, 2ull));
    Term _at_40 = blk_loc(e.mem, _a_20);
    Term _at_41 = blk_at(_a_20, 3ull, 0);
    u32 _c_20 = blk_read(e.mem, 0, _at_40, _at_41 + 0);
    blk_write(e.mem, 0, _at_40, _at_41 + 0, U32_BIN(140ull, +, 3ull));
    u64 _nd_34 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_34 + 0] = rfc_seal(e, _a_20);
    e.mem[_nd_34 + 1] = rfc_seal(e, 140ull);
    u32 _o_281 = 0;
    Term _o_282 = 0;
    if (_o_280 == 0) {
      _o_281 = 0;
    } else {
      _o_281 = 1;
      _o_282 = term_pak(CID_UNIT, 0);
    }
    u32 _v_362 = 0;
    u32 _v_363 = 0;
    u32 _v_364 = 0;
    Term _v_365 = 0;
    Term _v_366 = 0;
    Term _v_367 = 0;
    Term _v_368 = 0;
    Term _v_369 = 0;
    Term _v_370 = 0;
    u32 _v_371 = 0;
    Term _v_372 = 0;
    u32 _v_373 = 0;
    Term _v_374 = 0;
    u32 _v_375 = 0;
    Term _v_376 = 0;
    Term _v_377 = 0;
    u32 _v_378 = 0;
    Term _v_379 = 0;
    u32 _v_380 = 0;
    Term _v_381 = 0;
    u32 _v_382 = 0;
    Term _v_383 = 0;
    Term _o_283[22];
    Term _a_21 = term_pak(CID_UNIT, 0);
    Term _a_22 = term_ctr(CID_OWNERS_MOTION, _nd_33);
    Term _a_23 = term_ctr(CID_OWNERS_HEALTH, _nd_34);
    Term _a_24 = term_pak(CID_UNIT, 0);
    if (spin_115(e, _o_283, _f_382, _f_383, _f_384, blk_loc(e.mem, _f_384), _f_385, blk_loc(e.mem, _f_385), _f_386, blk_loc(e.mem, _f_386), _f_387, blk_loc(e.mem, _f_387), _f_388, blk_loc(e.mem, _f_388), _f_389, blk_loc(e.mem, _f_389), _f_390, _f_391, _f_392, _f_393, blk_loc(e.mem, _f_393), _o_281, _o_282, blk_loc(e.mem, _o_282), _a_21, blk_loc(e.mem, _a_21), 1, _a_22, blk_loc(e.mem, _a_22), 1, _a_23, blk_loc(e.mem, _a_23), 1, _a_24, blk_loc(e.mem, _a_24)) == 0) {
      return 0;
    }
    _v_362 = _o_283[0];
    _v_363 = _o_283[1];
    _v_364 = _o_283[2];
    _v_365 = _o_283[3];
    _v_366 = _o_283[4];
    _v_367 = _o_283[5];
    _v_368 = _o_283[6];
    _v_369 = _o_283[7];
    _v_370 = _o_283[8];
    _v_371 = _o_283[9];
    _v_372 = _o_283[10];
    _v_373 = _o_283[11];
    _v_374 = _o_283[12];
    _v_375 = _o_283[13];
    _v_376 = _o_283[14];
    _v_377 = _o_283[15];
    _v_378 = _o_283[16];
    _v_379 = _o_283[17];
    _v_380 = _o_283[18];
    _v_381 = _o_283[19];
    _v_382 = _o_283[20];
    _v_383 = _o_283[21];
    _v_340 = _v_362;
    _v_341 = _v_363;
    _v_342 = _v_364;
    _v_343 = _v_365;
    _v_344 = _v_366;
    _v_345 = _v_367;
    _v_346 = _v_368;
    _v_347 = _v_369;
    _v_348 = _v_370;
    _v_349 = _v_371;
    _v_350 = _v_372;
    _v_351 = _v_373;
    _v_352 = _v_374;
    _v_353 = _v_375;
    _v_354 = _v_376;
    _v_355 = _v_377;
    _v_356 = _v_378;
    _v_357 = _v_379;
    _v_358 = _v_380;
    _v_359 = _v_381;
    _v_360 = _v_382;
    _v_361 = _v_383;
    u32 _o_284 = 0;
    u32 _o_285 = 0;
    u32 _o_286 = 0;
    Term _o_287 = 0;
    Term _o_288 = 0;
    Term _o_289 = 0;
    Term _o_290 = 0;
    Term _o_291 = 0;
    Term _o_292 = 0;
    u32 _o_293 = 0;
    Term _o_294 = 0;
    u32 _o_295 = 0;
    Term _o_296 = 0;
    u32 _o_297 = 0;
    u32 _o_298 = 0;
    Term _o_299 = 0;
    u32 _o_300 = 0;
    u32 _o_301 = 0;
    Term _o_302 = 0;
    u32 _o_303 = 0;
    u32 _o_304 = 0;
    if (_v_340 == 0) {
      _o_284 = 0;
      u32 _o_305 = 0;
      if (_v_353 == 0) {
        _o_305 = 0;
      } else {
        _o_305 = 1;
      }
      _o_285 = _v_341;
      _o_286 = _v_342;
      _o_287 = _v_343;
      _o_288 = _v_344;
      _o_289 = _v_345;
      _o_290 = _v_346;
      _o_291 = _v_347;
      _o_292 = _v_348;
      _o_293 = _v_349;
      _o_294 = _v_350;
      _o_295 = _v_351;
      _o_296 = _v_352;
      _o_297 = _o_305;
      _o_298 = _v_356;
      _o_299 = _v_357;
    } else {
      _o_284 = 1;
      u32 _o_306 = 0;
      if (_v_353 == 0) {
        _o_306 = 0;
      } else {
        _o_306 = 1;
      }
      u32 _o_307 = 0;
      Term _o_308 = 0;
      u32 _o_309 = 0;
      if (_v_356 == 0) {
        _o_307 = 0;
      } else {
        _o_307 = 1;
        Term _fb_36[2];
        u64 _sp_36 = ctr_take(e, _v_357, 2, _fb_36);
        Term _f_397 = _fb_36[0];
        u32 _f_398 = _fb_36[1];
        spare_free(e, cls_fit(2), _sp_36);
        _o_308 = _f_397;
        _o_309 = _f_398;
      }
      u32 _o_310 = 0;
      Term _o_311 = 0;
      u32 _o_312 = 0;
      if (_v_358 == 0) {
        _o_310 = 0;
      } else {
        _o_310 = 1;
        Term _fb_37[2];
        u64 _sp_37 = ctr_take(e, _v_359, 2, _fb_37);
        Term _f_399 = _fb_37[0];
        u32 _f_400 = _fb_37[1];
        spare_free(e, cls_fit(2), _sp_37);
        _o_311 = _f_399;
        _o_312 = _f_400;
      }
      u32 _o_313 = 0;
      if (_v_360 == 0) {
        _o_313 = 0;
      } else {
        _o_313 = 1;
      }
      _o_285 = _v_341;
      _o_286 = _v_342;
      _o_287 = _v_343;
      _o_288 = _v_344;
      _o_289 = _v_345;
      _o_290 = _v_346;
      _o_291 = _v_347;
      _o_292 = _v_348;
      _o_293 = _v_349;
      _o_294 = _v_350;
      _o_295 = _v_351;
      _o_296 = _v_352;
      _o_297 = _o_306;
      _o_298 = _o_307;
      _o_299 = _o_308;
      _o_300 = _o_309;
      _o_301 = _o_310;
      _o_302 = _o_311;
      _o_303 = _o_312;
      _o_304 = _o_313;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K515;
      WL_PUSHN(1);
    } else {
      u64 _t_62 = task_node(e, FID_MAIN_K515, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K515, _t_62);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RESERVED)) {
      u64 _t_63 = task_node(e, FID_RESERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = term_ctr(CID_SCON, STAT_OFF + 528);
      e.mem[_t_63 + 1] = _o_284;
      e.mem[_t_63 + 2] = _o_285;
      e.mem[_t_63 + 3] = _o_286;
      e.mem[_t_63 + 4] = _o_287;
      e.mem[_t_63 + 5] = _o_288;
      e.mem[_t_63 + 6] = _o_289;
      e.mem[_t_63 + 7] = _o_290;
      e.mem[_t_63 + 8] = _o_291;
      e.mem[_t_63 + 9] = _o_292;
      e.mem[_t_63 + 10] = _o_293;
      e.mem[_t_63 + 11] = _o_294;
      e.mem[_t_63 + 12] = _o_295;
      e.mem[_t_63 + 13] = _o_296;
      e.mem[_t_63 + 14] = _o_297;
      e.mem[_t_63 + 15] = _o_298;
      e.mem[_t_63 + 16] = _o_299;
      e.mem[_t_63 + 17] = _o_300;
      e.mem[_t_63 + 18] = _o_301;
      e.mem[_t_63 + 19] = _o_302;
      e.mem[_t_63 + 20] = _o_303;
      e.mem[_t_63 + 21] = _o_304;
      return term_tsk(FID_RESERVED, _t_63);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 528);
    r1 = _o_284;
    r2 = _o_285;
    r3 = _o_286;
    r4 = _o_287;
    r5 = _o_288;
    r6 = _o_289;
    r7 = _o_290;
    r8 = _o_291;
    r9 = _o_292;
    r10 = _o_293;
    r11 = _o_294;
    r12 = _o_295;
    r13 = _o_296;
    r14 = _o_297;
    r15 = _o_298;
    r16 = _o_299;
    r17 = _o_300;
    r18 = _o_301;
    r19 = _o_302;
    r20 = _o_303;
    r21 = _o_304;
    WL_JMP(FID_RESERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K515)
  {
    Term _h_168 = r0;
    WL_OPEN
    u64 _nd_35 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_35 + 0] = _h_168;
    r0 = term_clo(FID_MAIN_C516, _nd_35);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C516)
  {
    Term _h_169 = r0;
    Term _x_50 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_109 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_109 + 0] = _h_169;
      e.mem[_t_109 + 1] = term_clo(FID_MAIN_C517, 0);
      e.mem[_t_109 + 2] = _x_50;
      return term_tsk(FID_IO_BIND, _t_109);
    }
    r0 = _h_169;
    r1 = term_clo(FID_MAIN_C517, 0);
    r2 = _x_50;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C517)
  {
    Term _x_51 = r0;
    WL_OPEN
    Term _fb_38[15];
    u64 _sp_38 = ctr_take(e, _x_51, 15, _fb_38);
    u32 _f_401 = _fb_38[0];
    u32 _f_402 = _fb_38[1];
    Term _f_403 = _fb_38[2];
    Term _f_404 = _fb_38[3];
    Term _f_405 = _fb_38[4];
    Term _f_406 = _fb_38[5];
    Term _f_407 = _fb_38[6];
    Term _f_408 = _fb_38[7];
    u32 _f_409 = _fb_38[8];
    Term _f_410 = _fb_38[9];
    u32 _f_411 = _fb_38[10];
    Term _f_412 = _fb_38[11];
    u32 _f_413 = _fb_38[12];
    Term _f_414 = _fb_38[13];
    Term _f_415 = _fb_38[14];
    spare_free(e, cls_fit(15), _sp_38);
    u32 _o_314 = 0;
    if (_f_413 == 0) {
      _o_314 = 0;
    } else {
      _o_314 = 1;
    }
    u32 _o_315 = 0;
    Term _o_316 = 0;
    if (_o_314 == 0) {
      _o_315 = 0;
    } else {
      _o_315 = 1;
      _o_316 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K518;
      WL_PUSHN(1);
    } else {
      u64 _t_64 = task_node(e, FID_MAIN_K518, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K518, _t_64);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_APPLY_CHECKED)) {
      u64 _t_65 = task_node(e, FID_COMMANDS_APPLY_CHECKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = _f_401;
      e.mem[_t_65 + 1] = _f_402;
      e.mem[_t_65 + 2] = _f_403;
      e.mem[_t_65 + 3] = _f_404;
      e.mem[_t_65 + 4] = _f_405;
      e.mem[_t_65 + 5] = _f_406;
      e.mem[_t_65 + 6] = _f_407;
      e.mem[_t_65 + 7] = _f_408;
      e.mem[_t_65 + 8] = _f_409;
      e.mem[_t_65 + 9] = _f_410;
      e.mem[_t_65 + 10] = _f_411;
      e.mem[_t_65 + 11] = _f_412;
      e.mem[_t_65 + 12] = _o_315;
      e.mem[_t_65 + 13] = _o_316;
      e.mem[_t_65 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_65 + 15] = 30ull;
      return term_tsk(FID_COMMANDS_APPLY_CHECKED, _t_65);
    }
    r0 = _f_401;
    r1 = _f_402;
    r2 = _f_403;
    r3 = _f_404;
    r4 = _f_405;
    r5 = _f_406;
    r6 = _f_407;
    r7 = _f_408;
    r8 = _f_409;
    r9 = _f_410;
    r10 = _f_411;
    r11 = _f_412;
    r12 = _o_315;
    r13 = _o_316;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 30ull;
    WL_JMP(FID_COMMANDS_APPLY_CHECKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K518)
  {
    u32 _h_170 = r0;
    u32 _h_171 = r1;
    u32 _h_172 = r2;
    Term _h_173 = r3;
    Term _h_174 = r4;
    Term _h_175 = r5;
    Term _h_176 = r6;
    Term _h_177 = r7;
    Term _h_178 = r8;
    u32 _h_179 = r9;
    Term _h_180 = r10;
    u32 _h_181 = r11;
    Term _h_182 = r12;
    u32 _h_183 = r13;
    Term _h_184 = r14;
    Term _h_185 = r15;
    Term _h_186 = r16;
    u32 _h_187 = r17;
    Term _h_188 = r18;
    u32 _h_189 = r19;
    Term _h_190 = r20;
    u32 _h_191 = r21;
    Term _h_192 = r22;
    u32 _h_193 = r23;
    u32 _h_194 = r24;
    Term _h_195 = r25;
    WL_OPEN
    u32 _o_317 = 0;
    u32 _o_318 = 0;
    u32 _o_319 = 0;
    Term _o_320 = 0;
    Term _o_321 = 0;
    Term _o_322 = 0;
    Term _o_323 = 0;
    Term _o_324 = 0;
    Term _o_325 = 0;
    u32 _o_326 = 0;
    Term _o_327 = 0;
    u32 _o_328 = 0;
    Term _o_329 = 0;
    u32 _o_330 = 0;
    Term _o_331 = 0;
    u32 _o_332 = 0;
    Term _o_333 = 0;
    u32 _o_334 = 0;
    u32 _o_335 = 0;
    Term _o_336 = 0;
    u32 _o_337 = 0;
    u32 _o_338 = 0;
    u32 _o_339 = 0;
    u32 _o_340 = 0;
    Term _o_341 = 0;
    if (_h_170 == 0) {
      _o_317 = 0;
      u32 _o_342 = 0;
      if (_h_183 == 0) {
        _o_342 = 0;
      } else {
        _o_342 = 1;
      }
      _o_318 = _h_171;
      _o_319 = _h_172;
      _o_320 = _h_173;
      _o_321 = _h_174;
      _o_322 = _h_175;
      _o_323 = _h_176;
      _o_324 = _h_177;
      _o_325 = _h_178;
      _o_326 = _h_179;
      _o_327 = _h_180;
      _o_328 = _h_181;
      _o_329 = _h_182;
      _o_330 = _o_342;
      _o_331 = _h_186;
    } else if (_h_170 == 1) {
      _o_317 = 1;
      u32 _o_343 = 0;
      if (_h_183 == 0) {
        _o_343 = 0;
      } else {
        _o_343 = 1;
      }
      _o_318 = _h_171;
      _o_319 = _h_172;
      _o_320 = _h_173;
      _o_321 = _h_174;
      _o_322 = _h_175;
      _o_323 = _h_176;
      _o_324 = _h_177;
      _o_325 = _h_178;
      _o_326 = _h_179;
      _o_327 = _h_180;
      _o_328 = _h_181;
      _o_329 = _h_182;
      _o_330 = _o_343;
    } else {
      _o_317 = 2;
      u32 _o_344 = 0;
      if (_h_183 == 0) {
        _o_344 = 0;
      } else {
        _o_344 = 1;
      }
      u32 _o_345 = 0;
      Term _o_346 = 0;
      u32 _o_347 = 0;
      if (_h_187 == 0) {
        _o_345 = 0;
      } else {
        _o_345 = 1;
        Term _fb_39[2];
        u64 _sp_39 = ctr_take(e, _h_188, 2, _fb_39);
        Term _f_416 = _fb_39[0];
        u32 _f_417 = _fb_39[1];
        spare_free(e, cls_fit(2), _sp_39);
        _o_346 = _f_416;
        _o_347 = _f_417;
      }
      u32 _o_348 = 0;
      Term _o_349 = 0;
      u32 _o_350 = 0;
      if (_h_189 == 0) {
        _o_348 = 0;
      } else {
        _o_348 = 1;
        Term _fb_40[2];
        u64 _sp_40 = ctr_take(e, _h_190, 2, _fb_40);
        Term _f_418 = _fb_40[0];
        u32 _f_419 = _fb_40[1];
        spare_free(e, cls_fit(2), _sp_40);
        _o_349 = _f_418;
        _o_350 = _f_419;
      }
      u32 _o_351 = 0;
      if (_h_191 == 0) {
        _o_351 = 0;
      } else {
        _o_351 = 1;
      }
      _o_318 = _h_171;
      _o_319 = _h_172;
      _o_320 = _h_173;
      _o_321 = _h_174;
      _o_322 = _h_175;
      _o_323 = _h_176;
      _o_324 = _h_177;
      _o_325 = _h_178;
      _o_326 = _h_179;
      _o_327 = _h_180;
      _o_328 = _h_181;
      _o_329 = _h_182;
      _o_330 = _o_344;
      _o_331 = _h_186;
      _o_332 = _o_345;
      _o_333 = _o_346;
      _o_334 = _o_347;
      _o_335 = _o_348;
      _o_336 = _o_349;
      _o_337 = _o_350;
      _o_338 = _o_351;
      _o_339 = _h_193;
      _o_340 = _h_194;
      _o_341 = _h_195;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K519;
      WL_PUSHN(1);
    } else {
      u64 _t_66 = task_node(e, FID_MAIN_K519, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K519, _t_66);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_APPLIED)) {
      u64 _t_67 = task_node(e, FID_APPLIED, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = term_ctr(CID_SCON, STAT_OFF + 544);
      e.mem[_t_67 + 1] = _o_317;
      e.mem[_t_67 + 2] = _o_318;
      e.mem[_t_67 + 3] = _o_319;
      e.mem[_t_67 + 4] = _o_320;
      e.mem[_t_67 + 5] = _o_321;
      e.mem[_t_67 + 6] = _o_322;
      e.mem[_t_67 + 7] = _o_323;
      e.mem[_t_67 + 8] = _o_324;
      e.mem[_t_67 + 9] = _o_325;
      e.mem[_t_67 + 10] = _o_326;
      e.mem[_t_67 + 11] = _o_327;
      e.mem[_t_67 + 12] = _o_328;
      e.mem[_t_67 + 13] = _o_329;
      e.mem[_t_67 + 14] = _o_330;
      e.mem[_t_67 + 15] = _o_331;
      e.mem[_t_67 + 16] = _o_332;
      e.mem[_t_67 + 17] = _o_333;
      e.mem[_t_67 + 18] = _o_334;
      e.mem[_t_67 + 19] = _o_335;
      e.mem[_t_67 + 20] = _o_336;
      e.mem[_t_67 + 21] = _o_337;
      e.mem[_t_67 + 22] = _o_338;
      e.mem[_t_67 + 23] = _o_339;
      e.mem[_t_67 + 24] = _o_340;
      e.mem[_t_67 + 25] = _o_341;
      return term_tsk(FID_APPLIED, _t_67);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 544);
    r1 = _o_317;
    r2 = _o_318;
    r3 = _o_319;
    r4 = _o_320;
    r5 = _o_321;
    r6 = _o_322;
    r7 = _o_323;
    r8 = _o_324;
    r9 = _o_325;
    r10 = _o_326;
    r11 = _o_327;
    r12 = _o_328;
    r13 = _o_329;
    r14 = _o_330;
    r15 = _o_331;
    r16 = _o_332;
    r17 = _o_333;
    r18 = _o_334;
    r19 = _o_335;
    r20 = _o_336;
    r21 = _o_337;
    r22 = _o_338;
    r23 = _o_339;
    r24 = _o_340;
    r25 = _o_341;
    WL_JMP(FID_APPLIED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K519)
  {
    Term _h_196 = r0;
    WL_OPEN
    u64 _nd_36 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_36 + 0] = _h_196;
    r0 = term_clo(FID_MAIN_C520, _nd_36);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C520)
  {
    Term _h_197 = r0;
    Term _x_52 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_108 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_108 + 0] = _h_197;
      e.mem[_t_108 + 1] = term_clo(FID_MAIN_C521, 0);
      e.mem[_t_108 + 2] = _x_52;
      return term_tsk(FID_IO_BIND, _t_108);
    }
    r0 = _h_197;
    r1 = term_clo(FID_MAIN_C521, 0);
    r2 = _x_52;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C521)
  {
    Term _x_53 = r0;
    WL_OPEN
    Term _fb_41[15];
    u64 _sp_41 = ctr_take(e, _x_53, 15, _fb_41);
    u32 _f_420 = _fb_41[0];
    u32 _f_421 = _fb_41[1];
    Term _f_422 = _fb_41[2];
    Term _f_423 = _fb_41[3];
    Term _f_424 = _fb_41[4];
    Term _f_425 = _fb_41[5];
    Term _f_426 = _fb_41[6];
    Term _f_427 = _fb_41[7];
    u32 _f_428 = _fb_41[8];
    Term _f_429 = _fb_41[9];
    u32 _f_430 = _fb_41[10];
    Term _f_431 = _fb_41[11];
    u32 _f_432 = _fb_41[12];
    Term _f_433 = _fb_41[13];
    Term _f_434 = _fb_41[14];
    spare_free(e, cls_fit(15), _sp_41);
    u32 _o_352 = 0;
    if (_f_432 == 0) {
      _o_352 = 0;
    } else {
      _o_352 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K522;
      WL_PUSHN(1);
    } else {
      u64 _t_68 = task_node(e, FID_MAIN_K522, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K522, _t_68);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_69 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = term_ctr(CID_SCON, STAT_OFF + 550);
      e.mem[_t_69 + 1] = 0;
      e.mem[_t_69 + 2] = _f_420;
      e.mem[_t_69 + 3] = _f_421;
      e.mem[_t_69 + 4] = _f_422;
      e.mem[_t_69 + 5] = _f_423;
      e.mem[_t_69 + 6] = _f_424;
      e.mem[_t_69 + 7] = _f_425;
      e.mem[_t_69 + 8] = _f_426;
      e.mem[_t_69 + 9] = _f_427;
      e.mem[_t_69 + 10] = _f_428;
      e.mem[_t_69 + 11] = _f_429;
      e.mem[_t_69 + 12] = _f_430;
      e.mem[_t_69 + 13] = _f_431;
      e.mem[_t_69 + 14] = _o_352;
      return term_tsk(FID_EACH, _t_69);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 550);
    r1 = 0;
    r2 = _f_420;
    r3 = _f_421;
    r4 = _f_422;
    r5 = _f_423;
    r6 = _f_424;
    r7 = _f_425;
    r8 = _f_426;
    r9 = _f_427;
    r10 = _f_428;
    r11 = _f_429;
    r12 = _f_430;
    r13 = _f_431;
    r14 = _o_352;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K522)
  {
    Term _h_198 = r0;
    WL_OPEN
    u64 _nd_37 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_37 + 0] = _h_198;
    r0 = term_clo(FID_MAIN_C523, _nd_37);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C523)
  {
    Term _h_199 = r0;
    Term _x_54 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_107 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_107 + 0] = _h_199;
      e.mem[_t_107 + 1] = term_clo(FID_MAIN_C524, 0);
      e.mem[_t_107 + 2] = _x_54;
      return term_tsk(FID_IO_BIND, _t_107);
    }
    r0 = _h_199;
    r1 = term_clo(FID_MAIN_C524, 0);
    r2 = _x_54;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C524)
  {
    Term _x_55 = r0;
    WL_OPEN
    Term _fb_42[15];
    u64 _sp_42 = ctr_take(e, _x_55, 15, _fb_42);
    u32 _f_435 = _fb_42[0];
    u32 _f_436 = _fb_42[1];
    Term _f_437 = _fb_42[2];
    Term _f_438 = _fb_42[3];
    Term _f_439 = _fb_42[4];
    Term _f_440 = _fb_42[5];
    Term _f_441 = _fb_42[6];
    Term _f_442 = _fb_42[7];
    u32 _f_443 = _fb_42[8];
    Term _f_444 = _fb_42[9];
    u32 _f_445 = _fb_42[10];
    Term _f_446 = _fb_42[11];
    u32 _f_447 = _fb_42[12];
    Term _f_448 = _fb_42[13];
    Term _f_449 = _fb_42[14];
    spare_free(e, cls_fit(15), _sp_42);
    u32 _o_353 = 0;
    if (_f_447 == 0) {
      _o_353 = 0;
    } else {
      _o_353 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K525;
      WL_PUSHN(1);
    } else {
      u64 _t_70 = task_node(e, FID_MAIN_K525, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K525, _t_70);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_71 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = term_ctr(CID_SCON, STAT_OFF + 556);
      e.mem[_t_71 + 1] = 1;
      e.mem[_t_71 + 2] = _f_435;
      e.mem[_t_71 + 3] = _f_436;
      e.mem[_t_71 + 4] = _f_437;
      e.mem[_t_71 + 5] = _f_438;
      e.mem[_t_71 + 6] = _f_439;
      e.mem[_t_71 + 7] = _f_440;
      e.mem[_t_71 + 8] = _f_441;
      e.mem[_t_71 + 9] = _f_442;
      e.mem[_t_71 + 10] = _f_443;
      e.mem[_t_71 + 11] = _f_444;
      e.mem[_t_71 + 12] = _f_445;
      e.mem[_t_71 + 13] = _f_446;
      e.mem[_t_71 + 14] = _o_353;
      return term_tsk(FID_EACH, _t_71);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 556);
    r1 = 1;
    r2 = _f_435;
    r3 = _f_436;
    r4 = _f_437;
    r5 = _f_438;
    r6 = _f_439;
    r7 = _f_440;
    r8 = _f_441;
    r9 = _f_442;
    r10 = _f_443;
    r11 = _f_444;
    r12 = _f_445;
    r13 = _f_446;
    r14 = _o_353;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K525)
  {
    Term _h_200 = r0;
    WL_OPEN
    u64 _nd_38 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_38 + 0] = _h_200;
    r0 = term_clo(FID_MAIN_C526, _nd_38);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C526)
  {
    Term _h_201 = r0;
    Term _x_56 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_106 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_106 + 0] = _h_201;
      e.mem[_t_106 + 1] = term_clo(FID_MAIN_C527, 0);
      e.mem[_t_106 + 2] = _x_56;
      return term_tsk(FID_IO_BIND, _t_106);
    }
    r0 = _h_201;
    r1 = term_clo(FID_MAIN_C527, 0);
    r2 = _x_56;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C527)
  {
    Term _x_57 = r0;
    WL_OPEN
    Term _fb_43[15];
    u64 _sp_43 = ctr_take(e, _x_57, 15, _fb_43);
    u32 _f_450 = _fb_43[0];
    u32 _f_451 = _fb_43[1];
    Term _f_452 = _fb_43[2];
    Term _f_453 = _fb_43[3];
    Term _f_454 = _fb_43[4];
    Term _f_455 = _fb_43[5];
    Term _f_456 = _fb_43[6];
    Term _f_457 = _fb_43[7];
    u32 _f_458 = _fb_43[8];
    Term _f_459 = _fb_43[9];
    u32 _f_460 = _fb_43[10];
    Term _f_461 = _fb_43[11];
    u32 _f_462 = _fb_43[12];
    Term _f_463 = _fb_43[13];
    Term _f_464 = _fb_43[14];
    spare_free(e, cls_fit(15), _sp_43);
    u32 _o_354 = 0;
    if (_f_462 == 0) {
      _o_354 = 0;
    } else {
      _o_354 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K528;
      WL_PUSHN(1);
    } else {
      u64 _t_72 = task_node(e, FID_MAIN_K528, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K528, _t_72);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_73 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = term_ctr(CID_SCON, STAT_OFF + 562);
      e.mem[_t_73 + 1] = 2;
      e.mem[_t_73 + 2] = _f_450;
      e.mem[_t_73 + 3] = _f_451;
      e.mem[_t_73 + 4] = _f_452;
      e.mem[_t_73 + 5] = _f_453;
      e.mem[_t_73 + 6] = _f_454;
      e.mem[_t_73 + 7] = _f_455;
      e.mem[_t_73 + 8] = _f_456;
      e.mem[_t_73 + 9] = _f_457;
      e.mem[_t_73 + 10] = _f_458;
      e.mem[_t_73 + 11] = _f_459;
      e.mem[_t_73 + 12] = _f_460;
      e.mem[_t_73 + 13] = _f_461;
      e.mem[_t_73 + 14] = _o_354;
      return term_tsk(FID_EACH, _t_73);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 562);
    r1 = 2;
    r2 = _f_450;
    r3 = _f_451;
    r4 = _f_452;
    r5 = _f_453;
    r6 = _f_454;
    r7 = _f_455;
    r8 = _f_456;
    r9 = _f_457;
    r10 = _f_458;
    r11 = _f_459;
    r12 = _f_460;
    r13 = _f_461;
    r14 = _o_354;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K528)
  {
    Term _h_202 = r0;
    WL_OPEN
    u64 _nd_39 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_39 + 0] = _h_202;
    r0 = term_clo(FID_MAIN_C529, _nd_39);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C529)
  {
    Term _h_203 = r0;
    Term _x_58 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_105 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_105 + 0] = _h_203;
      e.mem[_t_105 + 1] = term_clo(FID_MAIN_C530, 0);
      e.mem[_t_105 + 2] = _x_58;
      return term_tsk(FID_IO_BIND, _t_105);
    }
    r0 = _h_203;
    r1 = term_clo(FID_MAIN_C530, 0);
    r2 = _x_58;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C530)
  {
    Term _x_59 = r0;
    WL_OPEN
    Term _fb_44[15];
    u64 _sp_44 = ctr_take(e, _x_59, 15, _fb_44);
    u32 _f_465 = _fb_44[0];
    u32 _f_466 = _fb_44[1];
    Term _f_467 = _fb_44[2];
    Term _f_468 = _fb_44[3];
    Term _f_469 = _fb_44[4];
    Term _f_470 = _fb_44[5];
    Term _f_471 = _fb_44[6];
    Term _f_472 = _fb_44[7];
    u32 _f_473 = _fb_44[8];
    Term _f_474 = _fb_44[9];
    u32 _f_475 = _fb_44[10];
    Term _f_476 = _fb_44[11];
    u32 _f_477 = _fb_44[12];
    Term _f_478 = _fb_44[13];
    Term _f_479 = _fb_44[14];
    spare_free(e, cls_fit(15), _sp_44);
    u32 _o_355 = 0;
    if (_f_477 == 0) {
      _o_355 = 0;
    } else {
      _o_355 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K531;
      WL_PUSHN(1);
    } else {
      u64 _t_74 = task_node(e, FID_MAIN_K531, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K531, _t_74);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EACH)) {
      u64 _t_75 = task_node(e, FID_EACH, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = term_ctr(CID_SCON, STAT_OFF + 568);
      e.mem[_t_75 + 1] = 3;
      e.mem[_t_75 + 2] = _f_465;
      e.mem[_t_75 + 3] = _f_466;
      e.mem[_t_75 + 4] = _f_467;
      e.mem[_t_75 + 5] = _f_468;
      e.mem[_t_75 + 6] = _f_469;
      e.mem[_t_75 + 7] = _f_470;
      e.mem[_t_75 + 8] = _f_471;
      e.mem[_t_75 + 9] = _f_472;
      e.mem[_t_75 + 10] = _f_473;
      e.mem[_t_75 + 11] = _f_474;
      e.mem[_t_75 + 12] = _f_475;
      e.mem[_t_75 + 13] = _f_476;
      e.mem[_t_75 + 14] = _o_355;
      return term_tsk(FID_EACH, _t_75);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 568);
    r1 = 3;
    r2 = _f_465;
    r3 = _f_466;
    r4 = _f_467;
    r5 = _f_468;
    r6 = _f_469;
    r7 = _f_470;
    r8 = _f_471;
    r9 = _f_472;
    r10 = _f_473;
    r11 = _f_474;
    r12 = _f_475;
    r13 = _f_476;
    r14 = _o_355;
    WL_JMP(FID_EACH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K531)
  {
    Term _h_204 = r0;
    WL_OPEN
    u64 _nd_40 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_40 + 0] = _h_204;
    r0 = term_clo(FID_MAIN_C532, _nd_40);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C532)
  {
    Term _h_205 = r0;
    Term _x_60 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_104 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_104 + 0] = _h_205;
      e.mem[_t_104 + 1] = term_clo(FID_MAIN_C533, 0);
      e.mem[_t_104 + 2] = _x_60;
      return term_tsk(FID_IO_BIND, _t_104);
    }
    r0 = _h_205;
    r1 = term_clo(FID_MAIN_C533, 0);
    r2 = _x_60;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C533)
  {
    Term _x_61 = r0;
    WL_OPEN
    Term _fb_45[15];
    u64 _sp_45 = ctr_take(e, _x_61, 15, _fb_45);
    u32 _f_480 = _fb_45[0];
    u32 _f_481 = _fb_45[1];
    Term _f_482 = _fb_45[2];
    Term _f_483 = _fb_45[3];
    Term _f_484 = _fb_45[4];
    Term _f_485 = _fb_45[5];
    Term _f_486 = _fb_45[6];
    Term _f_487 = _fb_45[7];
    u32 _f_488 = _fb_45[8];
    Term _f_489 = _fb_45[9];
    u32 _f_490 = _fb_45[10];
    Term _f_491 = _fb_45[11];
    u32 _f_492 = _fb_45[12];
    Term _f_493 = _fb_45[13];
    Term _f_494 = _fb_45[14];
    spare_free(e, cls_fit(15), _sp_45);
    u32 _o_356 = 0;
    if (_f_492 == 0) {
      _o_356 = 0;
    } else {
      _o_356 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K534;
      WL_PUSHN(1);
    } else {
      u64 _t_76 = task_node(e, FID_MAIN_K534, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K534, _t_76);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP)) {
      u64 _t_77 = task_node(e, FID_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = term_ctr(CID_SCON, STAT_OFF + 582);
      e.mem[_t_77 + 1] = 1;
      e.mem[_t_77 + 2] = _f_480;
      e.mem[_t_77 + 3] = _f_481;
      e.mem[_t_77 + 4] = _f_482;
      e.mem[_t_77 + 5] = _f_483;
      e.mem[_t_77 + 6] = _f_484;
      e.mem[_t_77 + 7] = _f_485;
      e.mem[_t_77 + 8] = _f_486;
      e.mem[_t_77 + 9] = _f_487;
      e.mem[_t_77 + 10] = _f_488;
      e.mem[_t_77 + 11] = _f_489;
      e.mem[_t_77 + 12] = _f_490;
      e.mem[_t_77 + 13] = _f_491;
      e.mem[_t_77 + 14] = _o_356;
      e.mem[_t_77 + 15] = 7ull;
      e.mem[_t_77 + 16] = 1ull;
      return term_tsk(FID_LOOKUP, _t_77);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 582);
    r1 = 1;
    r2 = _f_480;
    r3 = _f_481;
    r4 = _f_482;
    r5 = _f_483;
    r6 = _f_484;
    r7 = _f_485;
    r8 = _f_486;
    r9 = _f_487;
    r10 = _f_488;
    r11 = _f_489;
    r12 = _f_490;
    r13 = _f_491;
    r14 = _o_356;
    r15 = 7ull;
    r16 = 1ull;
    WL_JMP(FID_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K534)
  {
    Term _h_206 = r0;
    WL_OPEN
    u64 _nd_41 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_41 + 0] = _h_206;
    r0 = term_clo(FID_MAIN_C535, _nd_41);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C535)
  {
    Term _h_207 = r0;
    Term _x_62 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_103 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_103 + 0] = _h_207;
      e.mem[_t_103 + 1] = term_clo(FID_MAIN_C536, 0);
      e.mem[_t_103 + 2] = _x_62;
      return term_tsk(FID_IO_BIND, _t_103);
    }
    r0 = _h_207;
    r1 = term_clo(FID_MAIN_C536, 0);
    r2 = _x_62;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C536)
  {
    Term _x_63 = r0;
    WL_OPEN
    Term _fb_46[15];
    u64 _sp_46 = ctr_take(e, _x_63, 15, _fb_46);
    u32 _f_495 = _fb_46[0];
    u32 _f_496 = _fb_46[1];
    Term _f_497 = _fb_46[2];
    Term _f_498 = _fb_46[3];
    Term _f_499 = _fb_46[4];
    Term _f_500 = _fb_46[5];
    Term _f_501 = _fb_46[6];
    Term _f_502 = _fb_46[7];
    u32 _f_503 = _fb_46[8];
    Term _f_504 = _fb_46[9];
    u32 _f_505 = _fb_46[10];
    Term _f_506 = _fb_46[11];
    u32 _f_507 = _fb_46[12];
    Term _f_508 = _fb_46[13];
    Term _f_509 = _fb_46[14];
    spare_free(e, cls_fit(15), _sp_46);
    u32 _o_357 = 0;
    if (_f_507 == 0) {
      _o_357 = 0;
    } else {
      _o_357 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K537;
      WL_PUSHN(1);
    } else {
      u64 _t_78 = task_node(e, FID_MAIN_K537, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K537, _t_78);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP)) {
      u64 _t_79 = task_node(e, FID_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = term_ctr(CID_SCON, STAT_OFF + 596);
      e.mem[_t_79 + 1] = 2;
      e.mem[_t_79 + 2] = _f_495;
      e.mem[_t_79 + 3] = _f_496;
      e.mem[_t_79 + 4] = _f_497;
      e.mem[_t_79 + 5] = _f_498;
      e.mem[_t_79 + 6] = _f_499;
      e.mem[_t_79 + 7] = _f_500;
      e.mem[_t_79 + 8] = _f_501;
      e.mem[_t_79 + 9] = _f_502;
      e.mem[_t_79 + 10] = _f_503;
      e.mem[_t_79 + 11] = _f_504;
      e.mem[_t_79 + 12] = _f_505;
      e.mem[_t_79 + 13] = _f_506;
      e.mem[_t_79 + 14] = _o_357;
      e.mem[_t_79 + 15] = 7ull;
      e.mem[_t_79 + 16] = 3ull;
      return term_tsk(FID_LOOKUP, _t_79);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 596);
    r1 = 2;
    r2 = _f_495;
    r3 = _f_496;
    r4 = _f_497;
    r5 = _f_498;
    r6 = _f_499;
    r7 = _f_500;
    r8 = _f_501;
    r9 = _f_502;
    r10 = _f_503;
    r11 = _f_504;
    r12 = _f_505;
    r13 = _f_506;
    r14 = _o_357;
    r15 = 7ull;
    r16 = 3ull;
    WL_JMP(FID_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K537)
  {
    Term _h_208 = r0;
    WL_OPEN
    u64 _nd_42 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_42 + 0] = _h_208;
    r0 = term_clo(FID_MAIN_C538, _nd_42);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C538)
  {
    Term _h_209 = r0;
    Term _x_64 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_102 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_102 + 0] = _h_209;
      e.mem[_t_102 + 1] = term_clo(FID_MAIN_C539, 0);
      e.mem[_t_102 + 2] = _x_64;
      return term_tsk(FID_IO_BIND, _t_102);
    }
    r0 = _h_209;
    r1 = term_clo(FID_MAIN_C539, 0);
    r2 = _x_64;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C539)
  {
    Term _x_65 = r0;
    WL_OPEN
    Term _fb_47[15];
    u64 _sp_47 = ctr_take(e, _x_65, 15, _fb_47);
    u32 _f_510 = _fb_47[0];
    u32 _f_511 = _fb_47[1];
    Term _f_512 = _fb_47[2];
    Term _f_513 = _fb_47[3];
    Term _f_514 = _fb_47[4];
    Term _f_515 = _fb_47[5];
    Term _f_516 = _fb_47[6];
    Term _f_517 = _fb_47[7];
    u32 _f_518 = _fb_47[8];
    Term _f_519 = _fb_47[9];
    u32 _f_520 = _fb_47[10];
    Term _f_521 = _fb_47[11];
    u32 _f_522 = _fb_47[12];
    Term _f_523 = _fb_47[13];
    Term _f_524 = _fb_47[14];
    spare_free(e, cls_fit(15), _sp_47);
    u32 _o_358 = 0;
    if (_f_522 == 0) {
      _o_358 = 0;
    } else {
      _o_358 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K540;
      WL_PUSHN(1);
    } else {
      u64 _t_80 = task_node(e, FID_MAIN_K540, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K540, _t_80);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP)) {
      u64 _t_81 = task_node(e, FID_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = term_ctr(CID_SCON, STAT_OFF + 618);
      e.mem[_t_81 + 1] = 0;
      e.mem[_t_81 + 2] = _f_510;
      e.mem[_t_81 + 3] = _f_511;
      e.mem[_t_81 + 4] = _f_512;
      e.mem[_t_81 + 5] = _f_513;
      e.mem[_t_81 + 6] = _f_514;
      e.mem[_t_81 + 7] = _f_515;
      e.mem[_t_81 + 8] = _f_516;
      e.mem[_t_81 + 9] = _f_517;
      e.mem[_t_81 + 10] = _f_518;
      e.mem[_t_81 + 11] = _f_519;
      e.mem[_t_81 + 12] = _f_520;
      e.mem[_t_81 + 13] = _f_521;
      e.mem[_t_81 + 14] = _o_358;
      e.mem[_t_81 + 15] = 7ull;
      e.mem[_t_81 + 16] = 2ull;
      return term_tsk(FID_LOOKUP, _t_81);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 618);
    r1 = 0;
    r2 = _f_510;
    r3 = _f_511;
    r4 = _f_512;
    r5 = _f_513;
    r6 = _f_514;
    r7 = _f_515;
    r8 = _f_516;
    r9 = _f_517;
    r10 = _f_518;
    r11 = _f_519;
    r12 = _f_520;
    r13 = _f_521;
    r14 = _o_358;
    r15 = 7ull;
    r16 = 2ull;
    WL_JMP(FID_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K540)
  {
    Term _h_210 = r0;
    WL_OPEN
    u64 _nd_43 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_43 + 0] = _h_210;
    r0 = term_clo(FID_MAIN_C541, _nd_43);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C541)
  {
    Term _h_211 = r0;
    Term _x_66 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_101 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_101 + 0] = _h_211;
      e.mem[_t_101 + 1] = term_clo(FID_MAIN_C542, 0);
      e.mem[_t_101 + 2] = _x_66;
      return term_tsk(FID_IO_BIND, _t_101);
    }
    r0 = _h_211;
    r1 = term_clo(FID_MAIN_C542, 0);
    r2 = _x_66;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C542)
  {
    Term _x_67 = r0;
    WL_OPEN
    Term _fb_48[15];
    u64 _sp_48 = ctr_take(e, _x_67, 15, _fb_48);
    u32 _f_525 = _fb_48[0];
    u32 _f_526 = _fb_48[1];
    Term _f_527 = _fb_48[2];
    Term _f_528 = _fb_48[3];
    Term _f_529 = _fb_48[4];
    Term _f_530 = _fb_48[5];
    Term _f_531 = _fb_48[6];
    Term _f_532 = _fb_48[7];
    u32 _f_533 = _fb_48[8];
    Term _f_534 = _fb_48[9];
    u32 _f_535 = _fb_48[10];
    Term _f_536 = _fb_48[11];
    u32 _f_537 = _fb_48[12];
    Term _f_538 = _fb_48[13];
    Term _f_539 = _fb_48[14];
    spare_free(e, cls_fit(15), _sp_48);
    u32 _o_359 = 0;
    if (_f_537 == 0) {
      _o_359 = 0;
    } else {
      _o_359 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K543;
      WL_PUSHN(1);
    } else {
      u64 _t_82 = task_node(e, FID_MAIN_K543, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K543, _t_82);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP)) {
      u64 _t_83 = task_node(e, FID_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = term_ctr(CID_SCON, STAT_OFF + 630);
      e.mem[_t_83 + 1] = 3;
      e.mem[_t_83 + 2] = _f_525;
      e.mem[_t_83 + 3] = _f_526;
      e.mem[_t_83 + 4] = _f_527;
      e.mem[_t_83 + 5] = _f_528;
      e.mem[_t_83 + 6] = _f_529;
      e.mem[_t_83 + 7] = _f_530;
      e.mem[_t_83 + 8] = _f_531;
      e.mem[_t_83 + 9] = _f_532;
      e.mem[_t_83 + 10] = _f_533;
      e.mem[_t_83 + 11] = _f_534;
      e.mem[_t_83 + 12] = _f_535;
      e.mem[_t_83 + 13] = _f_536;
      e.mem[_t_83 + 14] = _o_359;
      e.mem[_t_83 + 15] = 7ull;
      e.mem[_t_83 + 16] = 4ull;
      return term_tsk(FID_LOOKUP, _t_83);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 630);
    r1 = 3;
    r2 = _f_525;
    r3 = _f_526;
    r4 = _f_527;
    r5 = _f_528;
    r6 = _f_529;
    r7 = _f_530;
    r8 = _f_531;
    r9 = _f_532;
    r10 = _f_533;
    r11 = _f_534;
    r12 = _f_535;
    r13 = _f_536;
    r14 = _o_359;
    r15 = 7ull;
    r16 = 4ull;
    WL_JMP(FID_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K543)
  {
    Term _h_212 = r0;
    WL_OPEN
    u64 _nd_44 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_44 + 0] = _h_212;
    r0 = term_clo(FID_MAIN_C544, _nd_44);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C544)
  {
    Term _h_213 = r0;
    Term _x_68 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_100 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_100 + 0] = _h_213;
      e.mem[_t_100 + 1] = term_clo(FID_MAIN_C545, 0);
      e.mem[_t_100 + 2] = _x_68;
      return term_tsk(FID_IO_BIND, _t_100);
    }
    r0 = _h_213;
    r1 = term_clo(FID_MAIN_C545, 0);
    r2 = _x_68;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C545)
  {
    Term _x_69 = r0;
    WL_OPEN
    Term _fb_49[15];
    u64 _sp_49 = ctr_take(e, _x_69, 15, _fb_49);
    u32 _f_540 = _fb_49[0];
    u32 _f_541 = _fb_49[1];
    Term _f_542 = _fb_49[2];
    Term _f_543 = _fb_49[3];
    Term _f_544 = _fb_49[4];
    Term _f_545 = _fb_49[5];
    Term _f_546 = _fb_49[6];
    Term _f_547 = _fb_49[7];
    u32 _f_548 = _fb_49[8];
    Term _f_549 = _fb_49[9];
    u32 _f_550 = _fb_49[10];
    Term _f_551 = _fb_49[11];
    u32 _f_552 = _fb_49[12];
    Term _f_553 = _fb_49[13];
    Term _f_554 = _fb_49[14];
    spare_free(e, cls_fit(15), _sp_49);
    u32 _o_360 = 0;
    if (_f_552 == 0) {
      _o_360 = 0;
    } else {
      _o_360 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K546;
      WL_PUSHN(1);
    } else {
      u64 _t_84 = task_node(e, FID_MAIN_K546, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K546, _t_84);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP)) {
      u64 _t_85 = task_node(e, FID_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = term_ctr(CID_SCON, STAT_OFF + 658);
      e.mem[_t_85 + 1] = 0;
      e.mem[_t_85 + 2] = _f_540;
      e.mem[_t_85 + 3] = _f_541;
      e.mem[_t_85 + 4] = _f_542;
      e.mem[_t_85 + 5] = _f_543;
      e.mem[_t_85 + 6] = _f_544;
      e.mem[_t_85 + 7] = _f_545;
      e.mem[_t_85 + 8] = _f_546;
      e.mem[_t_85 + 9] = _f_547;
      e.mem[_t_85 + 10] = _f_548;
      e.mem[_t_85 + 11] = _f_549;
      e.mem[_t_85 + 12] = _f_550;
      e.mem[_t_85 + 13] = _f_551;
      e.mem[_t_85 + 14] = _o_360;
      e.mem[_t_85 + 15] = 8ull;
      e.mem[_t_85 + 16] = 1ull;
      return term_tsk(FID_LOOKUP, _t_85);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 658);
    r1 = 0;
    r2 = _f_540;
    r3 = _f_541;
    r4 = _f_542;
    r5 = _f_543;
    r6 = _f_544;
    r7 = _f_545;
    r8 = _f_546;
    r9 = _f_547;
    r10 = _f_548;
    r11 = _f_549;
    r12 = _f_550;
    r13 = _f_551;
    r14 = _o_360;
    r15 = 8ull;
    r16 = 1ull;
    WL_JMP(FID_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K546)
  {
    Term _h_214 = r0;
    WL_OPEN
    u64 _nd_45 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_45 + 0] = _h_214;
    r0 = term_clo(FID_MAIN_C547, _nd_45);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C547)
  {
    Term _h_215 = r0;
    Term _x_70 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_99 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = _h_215;
      e.mem[_t_99 + 1] = term_clo(FID_MAIN_C548, 0);
      e.mem[_t_99 + 2] = _x_70;
      return term_tsk(FID_IO_BIND, _t_99);
    }
    r0 = _h_215;
    r1 = term_clo(FID_MAIN_C548, 0);
    r2 = _x_70;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C548)
  {
    Term _x_71 = r0;
    WL_OPEN
    Term _fb_50[15];
    u64 _sp_50 = ctr_take(e, _x_71, 15, _fb_50);
    u32 _f_555 = _fb_50[0];
    u32 _f_556 = _fb_50[1];
    Term _f_557 = _fb_50[2];
    Term _f_558 = _fb_50[3];
    Term _f_559 = _fb_50[4];
    Term _f_560 = _fb_50[5];
    Term _f_561 = _fb_50[6];
    Term _f_562 = _fb_50[7];
    u32 _f_563 = _fb_50[8];
    Term _f_564 = _fb_50[9];
    u32 _f_565 = _fb_50[10];
    Term _f_566 = _fb_50[11];
    u32 _f_567 = _fb_50[12];
    Term _f_568 = _fb_50[13];
    Term _f_569 = _fb_50[14];
    spare_free(e, cls_fit(15), _sp_50);
    u32 _o_361 = 0;
    if (_f_567 == 0) {
      _o_361 = 0;
    } else {
      _o_361 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K549;
      WL_PUSHN(1);
    } else {
      u64 _t_86 = task_node(e, FID_MAIN_K549, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K549, _t_86);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_87 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_87 + 0] = term_ctr(CID_SCON, STAT_OFF + 668);
      e.mem[_t_87 + 1] = _f_555;
      e.mem[_t_87 + 2] = _f_556;
      e.mem[_t_87 + 3] = _f_557;
      e.mem[_t_87 + 4] = _f_558;
      e.mem[_t_87 + 5] = _f_559;
      e.mem[_t_87 + 6] = _f_560;
      e.mem[_t_87 + 7] = _f_561;
      e.mem[_t_87 + 8] = _f_562;
      e.mem[_t_87 + 9] = _f_563;
      e.mem[_t_87 + 10] = _f_564;
      e.mem[_t_87 + 11] = _f_565;
      e.mem[_t_87 + 12] = _f_566;
      e.mem[_t_87 + 13] = _o_361;
      e.mem[_t_87 + 14] = 1ull;
      return term_tsk(FID_SNAPSHOT, _t_87);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 668);
    r1 = _f_555;
    r2 = _f_556;
    r3 = _f_557;
    r4 = _f_558;
    r5 = _f_559;
    r6 = _f_560;
    r7 = _f_561;
    r8 = _f_562;
    r9 = _f_563;
    r10 = _f_564;
    r11 = _f_565;
    r12 = _f_566;
    r13 = _o_361;
    r14 = 1ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K549)
  {
    Term _h_216 = r0;
    WL_OPEN
    u64 _nd_46 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_46 + 0] = _h_216;
    r0 = term_clo(FID_MAIN_C550, _nd_46);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C550)
  {
    Term _h_217 = r0;
    Term _x_72 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_98 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_98 + 0] = _h_217;
      e.mem[_t_98 + 1] = term_clo(FID_MAIN_C551, 0);
      e.mem[_t_98 + 2] = _x_72;
      return term_tsk(FID_IO_BIND, _t_98);
    }
    r0 = _h_217;
    r1 = term_clo(FID_MAIN_C551, 0);
    r2 = _x_72;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C551)
  {
    Term _x_73 = r0;
    WL_OPEN
    Term _fb_51[15];
    u64 _sp_51 = ctr_take(e, _x_73, 15, _fb_51);
    u32 _f_570 = _fb_51[0];
    u32 _f_571 = _fb_51[1];
    Term _f_572 = _fb_51[2];
    Term _f_573 = _fb_51[3];
    Term _f_574 = _fb_51[4];
    Term _f_575 = _fb_51[5];
    Term _f_576 = _fb_51[6];
    Term _f_577 = _fb_51[7];
    u32 _f_578 = _fb_51[8];
    Term _f_579 = _fb_51[9];
    u32 _f_580 = _fb_51[10];
    Term _f_581 = _fb_51[11];
    u32 _f_582 = _fb_51[12];
    Term _f_583 = _fb_51[13];
    Term _f_584 = _fb_51[14];
    spare_free(e, cls_fit(15), _sp_51);
    u32 _o_362 = 0;
    if (_f_582 == 0) {
      _o_362 = 0;
    } else {
      _o_362 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K552;
      WL_PUSHN(1);
    } else {
      u64 _t_88 = task_node(e, FID_MAIN_K552, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K552, _t_88);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_89 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_89 + 0] = term_ctr(CID_SCON, STAT_OFF + 678);
      e.mem[_t_89 + 1] = _f_570;
      e.mem[_t_89 + 2] = _f_571;
      e.mem[_t_89 + 3] = _f_572;
      e.mem[_t_89 + 4] = _f_573;
      e.mem[_t_89 + 5] = _f_574;
      e.mem[_t_89 + 6] = _f_575;
      e.mem[_t_89 + 7] = _f_576;
      e.mem[_t_89 + 8] = _f_577;
      e.mem[_t_89 + 9] = _f_578;
      e.mem[_t_89 + 10] = _f_579;
      e.mem[_t_89 + 11] = _f_580;
      e.mem[_t_89 + 12] = _f_581;
      e.mem[_t_89 + 13] = _o_362;
      e.mem[_t_89 + 14] = 2ull;
      return term_tsk(FID_SNAPSHOT, _t_89);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 678);
    r1 = _f_570;
    r2 = _f_571;
    r3 = _f_572;
    r4 = _f_573;
    r5 = _f_574;
    r6 = _f_575;
    r7 = _f_576;
    r8 = _f_577;
    r9 = _f_578;
    r10 = _f_579;
    r11 = _f_580;
    r12 = _f_581;
    r13 = _o_362;
    r14 = 2ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K552)
  {
    Term _h_218 = r0;
    WL_OPEN
    u64 _nd_47 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_47 + 0] = _h_218;
    r0 = term_clo(FID_MAIN_C553, _nd_47);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C553)
  {
    Term _h_219 = r0;
    Term _x_74 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_97 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = _h_219;
      e.mem[_t_97 + 1] = term_clo(FID_MAIN_C554, 0);
      e.mem[_t_97 + 2] = _x_74;
      return term_tsk(FID_IO_BIND, _t_97);
    }
    r0 = _h_219;
    r1 = term_clo(FID_MAIN_C554, 0);
    r2 = _x_74;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C554)
  {
    Term _x_75 = r0;
    WL_OPEN
    Term _fb_52[15];
    u64 _sp_52 = ctr_take(e, _x_75, 15, _fb_52);
    u32 _f_585 = _fb_52[0];
    u32 _f_586 = _fb_52[1];
    Term _f_587 = _fb_52[2];
    Term _f_588 = _fb_52[3];
    Term _f_589 = _fb_52[4];
    Term _f_590 = _fb_52[5];
    Term _f_591 = _fb_52[6];
    Term _f_592 = _fb_52[7];
    u32 _f_593 = _fb_52[8];
    Term _f_594 = _fb_52[9];
    u32 _f_595 = _fb_52[10];
    Term _f_596 = _fb_52[11];
    u32 _f_597 = _fb_52[12];
    Term _f_598 = _fb_52[13];
    Term _f_599 = _fb_52[14];
    spare_free(e, cls_fit(15), _sp_52);
    u32 _o_363 = 0;
    if (_f_597 == 0) {
      _o_363 = 0;
    } else {
      _o_363 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K555;
      WL_PUSHN(1);
    } else {
      u64 _t_90 = task_node(e, FID_MAIN_K555, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K555, _t_90);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_91 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_91 + 0] = term_ctr(CID_SCON, STAT_OFF + 688);
      e.mem[_t_91 + 1] = _f_585;
      e.mem[_t_91 + 2] = _f_586;
      e.mem[_t_91 + 3] = _f_587;
      e.mem[_t_91 + 4] = _f_588;
      e.mem[_t_91 + 5] = _f_589;
      e.mem[_t_91 + 6] = _f_590;
      e.mem[_t_91 + 7] = _f_591;
      e.mem[_t_91 + 8] = _f_592;
      e.mem[_t_91 + 9] = _f_593;
      e.mem[_t_91 + 10] = _f_594;
      e.mem[_t_91 + 11] = _f_595;
      e.mem[_t_91 + 12] = _f_596;
      e.mem[_t_91 + 13] = _o_363;
      e.mem[_t_91 + 14] = 3ull;
      return term_tsk(FID_SNAPSHOT, _t_91);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 688);
    r1 = _f_585;
    r2 = _f_586;
    r3 = _f_587;
    r4 = _f_588;
    r5 = _f_589;
    r6 = _f_590;
    r7 = _f_591;
    r8 = _f_592;
    r9 = _f_593;
    r10 = _f_594;
    r11 = _f_595;
    r12 = _f_596;
    r13 = _o_363;
    r14 = 3ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K555)
  {
    Term _h_220 = r0;
    WL_OPEN
    u64 _nd_48 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_48 + 0] = _h_220;
    r0 = term_clo(FID_MAIN_C556, _nd_48);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C556)
  {
    Term _h_221 = r0;
    Term _x_76 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_96 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_96 + 0] = _h_221;
      e.mem[_t_96 + 1] = term_clo(FID_MAIN_C557, 0);
      e.mem[_t_96 + 2] = _x_76;
      return term_tsk(FID_IO_BIND, _t_96);
    }
    r0 = _h_221;
    r1 = term_clo(FID_MAIN_C557, 0);
    r2 = _x_76;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C557)
  {
    Term _x_77 = r0;
    WL_OPEN
    Term _fb_53[15];
    u64 _sp_53 = ctr_take(e, _x_77, 15, _fb_53);
    u32 _f_600 = _fb_53[0];
    u32 _f_601 = _fb_53[1];
    Term _f_602 = _fb_53[2];
    Term _f_603 = _fb_53[3];
    Term _f_604 = _fb_53[4];
    Term _f_605 = _fb_53[5];
    Term _f_606 = _fb_53[6];
    Term _f_607 = _fb_53[7];
    u32 _f_608 = _fb_53[8];
    Term _f_609 = _fb_53[9];
    u32 _f_610 = _fb_53[10];
    Term _f_611 = _fb_53[11];
    u32 _f_612 = _fb_53[12];
    Term _f_613 = _fb_53[13];
    Term _f_614 = _fb_53[14];
    spare_free(e, cls_fit(15), _sp_53);
    u32 _o_364 = 0;
    if (_f_612 == 0) {
      _o_364 = 0;
    } else {
      _o_364 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K558;
      WL_PUSHN(1);
    } else {
      u64 _t_92 = task_node(e, FID_MAIN_K558, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K558, _t_92);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_93 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_93 + 0] = term_ctr(CID_SCON, STAT_OFF + 706);
      e.mem[_t_93 + 1] = _f_600;
      e.mem[_t_93 + 2] = _f_601;
      e.mem[_t_93 + 3] = _f_602;
      e.mem[_t_93 + 4] = _f_603;
      e.mem[_t_93 + 5] = _f_604;
      e.mem[_t_93 + 6] = _f_605;
      e.mem[_t_93 + 7] = _f_606;
      e.mem[_t_93 + 8] = _f_607;
      e.mem[_t_93 + 9] = _f_608;
      e.mem[_t_93 + 10] = _f_609;
      e.mem[_t_93 + 11] = _f_610;
      e.mem[_t_93 + 12] = _f_611;
      e.mem[_t_93 + 13] = _o_364;
      e.mem[_t_93 + 14] = 4ull;
      return term_tsk(FID_SNAPSHOT, _t_93);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 706);
    r1 = _f_600;
    r2 = _f_601;
    r3 = _f_602;
    r4 = _f_603;
    r5 = _f_604;
    r6 = _f_605;
    r7 = _f_606;
    r8 = _f_607;
    r9 = _f_608;
    r10 = _f_609;
    r11 = _f_610;
    r12 = _f_611;
    r13 = _o_364;
    r14 = 4ull;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K558)
  {
    Term _h_222 = r0;
    WL_OPEN
    u64 _nd_49 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_49 + 0] = _h_222;
    r0 = term_clo(FID_MAIN_C559, _nd_49);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C559)
  {
    Term _h_223 = r0;
    Term _x_78 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_95 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_95 + 0] = _h_223;
      e.mem[_t_95 + 1] = term_clo(FID_MAIN_C560, 0);
      e.mem[_t_95 + 2] = _x_78;
      return term_tsk(FID_IO_BIND, _t_95);
    }
    r0 = _h_223;
    r1 = term_clo(FID_MAIN_C560, 0);
    r2 = _x_78;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C560)
  {
    Term _x_79 = r0;
    WL_OPEN
    Term _fb_54[15];
    u64 _sp_54 = ctr_take(e, _x_79, 15, _fb_54);
    u32 _f_615 = _fb_54[0];
    u32 _f_616 = _fb_54[1];
    Term _f_617 = _fb_54[2];
    Term _f_618 = _fb_54[3];
    Term _f_619 = _fb_54[4];
    Term _f_620 = _fb_54[5];
    Term _f_621 = _fb_54[6];
    Term _f_622 = _fb_54[7];
    u32 _f_623 = _fb_54[8];
    Term _f_624 = _fb_54[9];
    u32 _f_625 = _fb_54[10];
    Term _f_626 = _fb_54[11];
    u32 _f_627 = _fb_54[12];
    Term _f_628 = _fb_54[13];
    Term _f_629 = _fb_54[14];
    spare_free(e, cls_fit(15), _sp_54);
    u32 _o_365 = 0;
    if (_f_627 == 0) {
      _o_365 = 0;
    } else {
      _o_365 = 1;
    }
    term_sink(e, _f_617);
    term_sink(e, _f_618);
    term_sink(e, _f_619);
    term_sink(e, _f_620);
    term_sink(e, _f_621);
    term_sink(e, _f_622);
    term_sink(e, _f_626);
    r0 = term_clo(FID_MAIN_C561, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C561)
  {
    Term _x_80 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_94 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_94 + 0] = term_pak(CID_UNIT, 0);
      e.mem[_t_94 + 1] = _x_80;
      return term_tsk(FID_IO_PURE, _t_94);
    }
    r0 = term_pak(CID_UNIT, 0);
    r1 = _x_80;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_2 = r0;
    Term _k_2 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _text_2;
    e.mem[_nd_2 + 1] = _k_2;
    r0 = term_ctr(CID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
