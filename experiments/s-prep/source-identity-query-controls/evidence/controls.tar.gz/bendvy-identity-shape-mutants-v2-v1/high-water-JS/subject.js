function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  const _x_1 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Required"}, ($world0$())))));
  return $IO$bind$((_x_2) => $IO$print$(("d0-Required:" + _x_1), _x_2), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  const _x_5 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Present"}, ($world0$())))));
  return $IO$bind$((_x_6) => $IO$print$(("d0-Present:" + _x_5), _x_6), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  const _x_9 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Absent"}, ($world0$())))));
  return $IO$bind$((_x_10) => $IO$print$(("d0-Absent:" + _x_9), _x_10), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  const _x_13 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Optional"}, ($world0$())))));
  return $IO$bind$((_x_14) => $IO$print$(("d0-Optional:" + _x_13), _x_14), run_clo((_x_15) => {
  return run_clo((_x_16) => {
  const _x_17 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Required"}, ($world1$())))));
  return $IO$bind$((_x_18) => $IO$print$(("d1-Required:" + _x_17), _x_18), run_clo((_x_19) => {
  return run_clo((_x_20) => {
  const _x_21 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Present"}, ($world1$())))));
  return $IO$bind$((_x_22) => $IO$print$(("d1-Present:" + _x_21), _x_22), run_clo((_x_23) => {
  return run_clo((_x_24) => {
  const _x_25 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Absent"}, ($world1$())))));
  return $IO$bind$((_x_26) => $IO$print$(("d1-Absent:" + _x_25), _x_26), run_clo((_x_27) => {
  return run_clo((_x_28) => {
  const _x_29 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Optional"}, ($world1$())))));
  return $IO$bind$((_x_30) => $IO$print$(("d1-Optional:" + _x_29), _x_30), run_clo((_x_31) => {
  return run_clo((_x_32) => {
  const _x_33 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Required"}, ($world2$())))));
  return $IO$bind$((_x_34) => $IO$print$(("d2-Required:" + _x_33), _x_34), run_clo((_x_35) => {
  return run_clo((_x_36) => {
  const _x_37 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Present"}, ($world2$())))));
  return $IO$bind$((_x_38) => $IO$print$(("d2-Present:" + _x_37), _x_38), run_clo((_x_39) => {
  return run_clo((_x_40) => {
  const _x_41 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Absent"}, ($world2$())))));
  return $IO$bind$((_x_42) => $IO$print$(("d2-Absent:" + _x_41), _x_42), run_clo((_x_43) => {
  return run_clo((_x_44) => {
  const _x_45 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Optional"}, ($world2$())))));
  return $IO$bind$((_x_46) => $IO$print$(("d2-Optional:" + _x_45), _x_46), run_clo((_x_47) => {
  return run_clo((_x_48) => {
  const _x_49 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Required"}, ($world3$())))));
  return $IO$bind$((_x_50) => $IO$print$(("d3-Required:" + _x_49), _x_50), run_clo((_x_51) => {
  return run_clo((_x_52) => {
  const _x_53 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Present"}, ($world3$())))));
  return $IO$bind$((_x_54) => $IO$print$(("d3-Present:" + _x_53), _x_54), run_clo((_x_55) => {
  return run_clo((_x_56) => {
  const _x_57 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Absent"}, ($world3$())))));
  return $IO$bind$((_x_58) => $IO$print$(("d3-Absent:" + _x_57), _x_58), run_clo((_x_59) => {
  return run_clo((_x_60) => {
  const _x_61 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Optional"}, ($world3$())))));
  return $IO$bind$((_x_62) => $IO$print$(("d3-Optional:" + _x_61), _x_62), run_clo((_x_63) => {
  return run_clo((_x_64) => {
  const _x_65 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Required"}, ($world4$())))));
  return $IO$bind$((_x_66) => $IO$print$(("d4-Required:" + _x_65), _x_66), run_clo((_x_67) => {
  return run_clo((_x_68) => {
  const _x_69 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Present"}, ($world4$())))));
  return $IO$bind$((_x_70) => $IO$print$(("d4-Present:" + _x_69), _x_70), run_clo((_x_71) => {
  return run_clo((_x_72) => {
  const _x_73 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Absent"}, ($world4$())))));
  return $IO$bind$((_x_74) => $IO$print$(("d4-Absent:" + _x_73), _x_74), run_clo((_x_75) => {
  return run_clo((_x_76) => {
  const _x_77 = ($snapshot$(($query$058prototype_identity_each$1260$({$: "query.Optional"}, ($world4$())))));
  return $IO$bind$((_x_78) => $IO$print$(("d4-Optional:" + _x_77), _x_78), run_clo((_x_79) => {
  return run_clo((_x_80) => {
  return $IO$pure$({$: "Unit"}, _x_80);
});
}), _x_76);
});
}), _x_72);
});
}), _x_68);
});
}), _x_64);
});
}), _x_60);
});
}), _x_56);
});
}), _x_52);
});
}), _x_48);
});
}), _x_44);
});
}), _x_40);
});
}), _x_36);
});
}), _x_32);
});
}), _x_28);
});
}), _x_24);
});
}), _x_20);
});
}), _x_16);
});
}), _x_12);
});
}), _x_8);
});
}), _x_4);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $snapshot$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _t_1 = _t_0["pending"];
  if (_t_1.$ === "Nil") {
    const _t_2 = _t_0["ledger"];
    if (_t_2.$ === "Some") {
      const _ledger_0 = _t_2["value"];
      const _mode_0 = _t_0["mode"];
      const _values_0 = _result_0["snd"];
      return $snapshot_rows$(_ns_0, _next_0, _ledger_0, _mode_0, _values_0, _rows_0);
    } else {
      return "unexpected-context";
    }
  } else {
    return "unexpected-context";
  }
}

function $query$058prototype_identity_each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($query$058prototype_identity_read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $world0$() {
  return {$: "storage.World", "namespace": 7, "next": 999, "rows": {$: "storage.Rows", "main": [{$: "Some", "value": {$: "Owned", "items": [1000], "scalar": 1}}], "aux": [{$: "Some", "value": {$: "Owned", "items": [101000], "scalar": 101}}], "metadata": {$: "storage.MetadataColumns", "live": [true], "flags": [{$: "Some", "value": {$: "Unit"}}], "added": [100], "changed": [200]}, "capacity": 1, "depth": 0, "high_water": 1}, "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Owned", "items": [999000], "scalar": 999}}, "mode": 123};
}

function $world1$() {
  return {$: "storage.World", "namespace": 7, "next": 999, "rows": {$: "storage.Rows", "main": array_node([{$: "Some", "value": {$: "Owned", "items": array_node([1000], [1001]), "scalar": 1}}], [{$: "None"}]), "aux": array_node([{$: "Some", "value": {$: "Owned", "items": array_node([101000], [101001]), "scalar": 101}}], [{$: "Some", "value": {$: "Owned", "items": array_node([102000], [102001]), "scalar": 102}}]), "metadata": {$: "storage.MetadataColumns", "live": array_node([true], [true]), "flags": array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), "added": array_node([100], [101]), "changed": array_node([200], [201])}, "capacity": 2, "depth": 1, "high_water": 1}, "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Owned", "items": array_node([999000], [999001]), "scalar": 999}}, "mode": 123};
}

function $world2$() {
  return {$: "storage.World", "namespace": 7, "next": 999, "rows": {$: "storage.Rows", "main": array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node([1000], [1001]), array_node([1002], [1003])), "scalar": 1}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node([3000], [3001]), array_node([3002], [3003])), "scalar": 3}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node([4000], [4001]), array_node([4002], [4003])), "scalar": 4}}])), "aux": array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node([101000], [101001]), array_node([101002], [101003])), "scalar": 101}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node([102000], [102001]), array_node([102002], [102003])), "scalar": 102}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node([103000], [103001]), array_node([103002], [103003])), "scalar": 103}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node([104000], [104001]), array_node([104002], [104003])), "scalar": 104}}])), "metadata": {$: "storage.MetadataColumns", "live": array_node(array_node([true], [true]), array_node([false], [true])), "flags": array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}])), "added": array_node(array_node([100], [101]), array_node([102], [103])), "changed": array_node(array_node([200], [201]), array_node([202], [203]))}, "capacity": 4, "depth": 2, "high_water": 3}, "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Owned", "items": array_node(array_node([999000], [999001]), array_node([999002], [999003])), "scalar": 999}}, "mode": 123};
}

function $world3$() {
  return {$: "storage.World", "namespace": 7, "next": 999, "rows": {$: "storage.Rows", "main": array_node(array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([1000], [1001]), array_node([1002], [1003])), array_node(array_node([1004], [1005]), array_node([1006], [1007]))), "scalar": 1}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([3000], [3001]), array_node([3002], [3003])), array_node(array_node([3004], [3005]), array_node([3006], [3007]))), "scalar": 3}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([4000], [4001]), array_node([4002], [4003])), array_node(array_node([4004], [4005]), array_node([4006], [4007]))), "scalar": 4}}])), array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([5000], [5001]), array_node([5002], [5003])), array_node(array_node([5004], [5005]), array_node([5006], [5007]))), "scalar": 5}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([6000], [6001]), array_node([6002], [6003])), array_node(array_node([6004], [6005]), array_node([6006], [6007]))), "scalar": 6}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([7000], [7001]), array_node([7002], [7003])), array_node(array_node([7004], [7005]), array_node([7006], [7007]))), "scalar": 7}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([8000], [8001]), array_node([8002], [8003])), array_node(array_node([8004], [8005]), array_node([8006], [8007]))), "scalar": 8}}]))), "aux": array_node(array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([101000], [101001]), array_node([101002], [101003])), array_node(array_node([101004], [101005]), array_node([101006], [101007]))), "scalar": 101}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([102000], [102001]), array_node([102002], [102003])), array_node(array_node([102004], [102005]), array_node([102006], [102007]))), "scalar": 102}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([103000], [103001]), array_node([103002], [103003])), array_node(array_node([103004], [103005]), array_node([103006], [103007]))), "scalar": 103}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([104000], [104001]), array_node([104002], [104003])), array_node(array_node([104004], [104005]), array_node([104006], [104007]))), "scalar": 104}}])), array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([105000], [105001]), array_node([105002], [105003])), array_node(array_node([105004], [105005]), array_node([105006], [105007]))), "scalar": 105}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([106000], [106001]), array_node([106002], [106003])), array_node(array_node([106004], [106005]), array_node([106006], [106007]))), "scalar": 106}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([107000], [107001]), array_node([107002], [107003])), array_node(array_node([107004], [107005]), array_node([107006], [107007]))), "scalar": 107}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([108000], [108001]), array_node([108002], [108003])), array_node(array_node([108004], [108005]), array_node([108006], [108007]))), "scalar": 108}}]))), "metadata": {$: "storage.MetadataColumns", "live": array_node(array_node(array_node([true], [true]), array_node([false], [true])), array_node(array_node([true], [true]), array_node([true], [true]))), "flags": array_node(array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}])), array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]))), "added": array_node(array_node(array_node([100], [101]), array_node([102], [103])), array_node(array_node([104], [105]), array_node([106], [107]))), "changed": array_node(array_node(array_node([200], [201]), array_node([202], [203])), array_node(array_node([204], [205]), array_node([206], [207])))}, "capacity": 8, "depth": 3, "high_water": 7}, "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node([999000], [999001]), array_node([999002], [999003])), array_node(array_node([999004], [999005]), array_node([999006], [999007]))), "scalar": 999}}, "mode": 123};
}

function $world4$() {
  return {$: "storage.World", "namespace": 7, "next": 999, "rows": {$: "storage.Rows", "main": array_node(array_node(array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([1000], [1001]), array_node([1002], [1003])), array_node(array_node([1004], [1005]), array_node([1006], [1007]))), array_node(array_node(array_node([1008], [1009]), array_node([1010], [1011])), array_node(array_node([1012], [1013]), array_node([1014], [1015])))), "scalar": 1}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([3000], [3001]), array_node([3002], [3003])), array_node(array_node([3004], [3005]), array_node([3006], [3007]))), array_node(array_node(array_node([3008], [3009]), array_node([3010], [3011])), array_node(array_node([3012], [3013]), array_node([3014], [3015])))), "scalar": 3}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([4000], [4001]), array_node([4002], [4003])), array_node(array_node([4004], [4005]), array_node([4006], [4007]))), array_node(array_node(array_node([4008], [4009]), array_node([4010], [4011])), array_node(array_node([4012], [4013]), array_node([4014], [4015])))), "scalar": 4}}])), array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([5000], [5001]), array_node([5002], [5003])), array_node(array_node([5004], [5005]), array_node([5006], [5007]))), array_node(array_node(array_node([5008], [5009]), array_node([5010], [5011])), array_node(array_node([5012], [5013]), array_node([5014], [5015])))), "scalar": 5}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([6000], [6001]), array_node([6002], [6003])), array_node(array_node([6004], [6005]), array_node([6006], [6007]))), array_node(array_node(array_node([6008], [6009]), array_node([6010], [6011])), array_node(array_node([6012], [6013]), array_node([6014], [6015])))), "scalar": 6}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([7000], [7001]), array_node([7002], [7003])), array_node(array_node([7004], [7005]), array_node([7006], [7007]))), array_node(array_node(array_node([7008], [7009]), array_node([7010], [7011])), array_node(array_node([7012], [7013]), array_node([7014], [7015])))), "scalar": 7}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([8000], [8001]), array_node([8002], [8003])), array_node(array_node([8004], [8005]), array_node([8006], [8007]))), array_node(array_node(array_node([8008], [8009]), array_node([8010], [8011])), array_node(array_node([8012], [8013]), array_node([8014], [8015])))), "scalar": 8}}]))), array_node(array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([9000], [9001]), array_node([9002], [9003])), array_node(array_node([9004], [9005]), array_node([9006], [9007]))), array_node(array_node(array_node([9008], [9009]), array_node([9010], [9011])), array_node(array_node([9012], [9013]), array_node([9014], [9015])))), "scalar": 9}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([10000], [10001]), array_node([10002], [10003])), array_node(array_node([10004], [10005]), array_node([10006], [10007]))), array_node(array_node(array_node([10008], [10009]), array_node([10010], [10011])), array_node(array_node([10012], [10013]), array_node([10014], [10015])))), "scalar": 10}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([11000], [11001]), array_node([11002], [11003])), array_node(array_node([11004], [11005]), array_node([11006], [11007]))), array_node(array_node(array_node([11008], [11009]), array_node([11010], [11011])), array_node(array_node([11012], [11013]), array_node([11014], [11015])))), "scalar": 11}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([12000], [12001]), array_node([12002], [12003])), array_node(array_node([12004], [12005]), array_node([12006], [12007]))), array_node(array_node(array_node([12008], [12009]), array_node([12010], [12011])), array_node(array_node([12012], [12013]), array_node([12014], [12015])))), "scalar": 12}}])), array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([13000], [13001]), array_node([13002], [13003])), array_node(array_node([13004], [13005]), array_node([13006], [13007]))), array_node(array_node(array_node([13008], [13009]), array_node([13010], [13011])), array_node(array_node([13012], [13013]), array_node([13014], [13015])))), "scalar": 13}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([14000], [14001]), array_node([14002], [14003])), array_node(array_node([14004], [14005]), array_node([14006], [14007]))), array_node(array_node(array_node([14008], [14009]), array_node([14010], [14011])), array_node(array_node([14012], [14013]), array_node([14014], [14015])))), "scalar": 14}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([15000], [15001]), array_node([15002], [15003])), array_node(array_node([15004], [15005]), array_node([15006], [15007]))), array_node(array_node(array_node([15008], [15009]), array_node([15010], [15011])), array_node(array_node([15012], [15013]), array_node([15014], [15015])))), "scalar": 15}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([16000], [16001]), array_node([16002], [16003])), array_node(array_node([16004], [16005]), array_node([16006], [16007]))), array_node(array_node(array_node([16008], [16009]), array_node([16010], [16011])), array_node(array_node([16012], [16013]), array_node([16014], [16015])))), "scalar": 16}}])))), "aux": array_node(array_node(array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([101000], [101001]), array_node([101002], [101003])), array_node(array_node([101004], [101005]), array_node([101006], [101007]))), array_node(array_node(array_node([101008], [101009]), array_node([101010], [101011])), array_node(array_node([101012], [101013]), array_node([101014], [101015])))), "scalar": 101}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([102000], [102001]), array_node([102002], [102003])), array_node(array_node([102004], [102005]), array_node([102006], [102007]))), array_node(array_node(array_node([102008], [102009]), array_node([102010], [102011])), array_node(array_node([102012], [102013]), array_node([102014], [102015])))), "scalar": 102}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([103000], [103001]), array_node([103002], [103003])), array_node(array_node([103004], [103005]), array_node([103006], [103007]))), array_node(array_node(array_node([103008], [103009]), array_node([103010], [103011])), array_node(array_node([103012], [103013]), array_node([103014], [103015])))), "scalar": 103}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([104000], [104001]), array_node([104002], [104003])), array_node(array_node([104004], [104005]), array_node([104006], [104007]))), array_node(array_node(array_node([104008], [104009]), array_node([104010], [104011])), array_node(array_node([104012], [104013]), array_node([104014], [104015])))), "scalar": 104}}])), array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([105000], [105001]), array_node([105002], [105003])), array_node(array_node([105004], [105005]), array_node([105006], [105007]))), array_node(array_node(array_node([105008], [105009]), array_node([105010], [105011])), array_node(array_node([105012], [105013]), array_node([105014], [105015])))), "scalar": 105}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([106000], [106001]), array_node([106002], [106003])), array_node(array_node([106004], [106005]), array_node([106006], [106007]))), array_node(array_node(array_node([106008], [106009]), array_node([106010], [106011])), array_node(array_node([106012], [106013]), array_node([106014], [106015])))), "scalar": 106}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([107000], [107001]), array_node([107002], [107003])), array_node(array_node([107004], [107005]), array_node([107006], [107007]))), array_node(array_node(array_node([107008], [107009]), array_node([107010], [107011])), array_node(array_node([107012], [107013]), array_node([107014], [107015])))), "scalar": 107}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([108000], [108001]), array_node([108002], [108003])), array_node(array_node([108004], [108005]), array_node([108006], [108007]))), array_node(array_node(array_node([108008], [108009]), array_node([108010], [108011])), array_node(array_node([108012], [108013]), array_node([108014], [108015])))), "scalar": 108}}]))), array_node(array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([109000], [109001]), array_node([109002], [109003])), array_node(array_node([109004], [109005]), array_node([109006], [109007]))), array_node(array_node(array_node([109008], [109009]), array_node([109010], [109011])), array_node(array_node([109012], [109013]), array_node([109014], [109015])))), "scalar": 109}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([110000], [110001]), array_node([110002], [110003])), array_node(array_node([110004], [110005]), array_node([110006], [110007]))), array_node(array_node(array_node([110008], [110009]), array_node([110010], [110011])), array_node(array_node([110012], [110013]), array_node([110014], [110015])))), "scalar": 110}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([111000], [111001]), array_node([111002], [111003])), array_node(array_node([111004], [111005]), array_node([111006], [111007]))), array_node(array_node(array_node([111008], [111009]), array_node([111010], [111011])), array_node(array_node([111012], [111013]), array_node([111014], [111015])))), "scalar": 111}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([112000], [112001]), array_node([112002], [112003])), array_node(array_node([112004], [112005]), array_node([112006], [112007]))), array_node(array_node(array_node([112008], [112009]), array_node([112010], [112011])), array_node(array_node([112012], [112013]), array_node([112014], [112015])))), "scalar": 112}}])), array_node(array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([113000], [113001]), array_node([113002], [113003])), array_node(array_node([113004], [113005]), array_node([113006], [113007]))), array_node(array_node(array_node([113008], [113009]), array_node([113010], [113011])), array_node(array_node([113012], [113013]), array_node([113014], [113015])))), "scalar": 113}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([114000], [114001]), array_node([114002], [114003])), array_node(array_node([114004], [114005]), array_node([114006], [114007]))), array_node(array_node(array_node([114008], [114009]), array_node([114010], [114011])), array_node(array_node([114012], [114013]), array_node([114014], [114015])))), "scalar": 114}}]), array_node([{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([115000], [115001]), array_node([115002], [115003])), array_node(array_node([115004], [115005]), array_node([115006], [115007]))), array_node(array_node(array_node([115008], [115009]), array_node([115010], [115011])), array_node(array_node([115012], [115013]), array_node([115014], [115015])))), "scalar": 115}}], [{$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([116000], [116001]), array_node([116002], [116003])), array_node(array_node([116004], [116005]), array_node([116006], [116007]))), array_node(array_node(array_node([116008], [116009]), array_node([116010], [116011])), array_node(array_node([116012], [116013]), array_node([116014], [116015])))), "scalar": 116}}])))), "metadata": {$: "storage.MetadataColumns", "live": array_node(array_node(array_node(array_node([true], [true]), array_node([false], [true])), array_node(array_node([true], [true]), array_node([true], [true]))), array_node(array_node(array_node([true], [true]), array_node([true], [true])), array_node(array_node([true], [true]), array_node([true], [true])))), "flags": array_node(array_node(array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}])), array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]))), array_node(array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}])), array_node(array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}]), array_node([{$: "Some", "value": {$: "Unit"}}], [{$: "None"}])))), "added": array_node(array_node(array_node(array_node([100], [101]), array_node([102], [103])), array_node(array_node([104], [105]), array_node([106], [107]))), array_node(array_node(array_node([108], [109]), array_node([110], [111])), array_node(array_node([112], [113]), array_node([114], [115])))), "changed": array_node(array_node(array_node(array_node([200], [201]), array_node([202], [203])), array_node(array_node([204], [205]), array_node([206], [207]))), array_node(array_node(array_node([208], [209]), array_node([210], [211])), array_node(array_node([212], [213]), array_node([214], [215]))))}, "capacity": 16, "depth": 4, "high_water": 15}, "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Owned", "items": array_node(array_node(array_node(array_node([999000], [999001]), array_node([999002], [999003])), array_node(array_node([999004], [999005]), array_node([999006], [999007]))), array_node(array_node(array_node([999008], [999009]), array_node([999010], [999011])), array_node(array_node([999012], [999013]), array_node([999014], [999015])))), "scalar": 999}}, "mode": 123};
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $snapshot_rows$(_ns_0, _next_0, _ledger_0, _mode_0, _values_0, _rows_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flag_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $snapshot_fields$(_ns_0, _next_0, _capacity_0, _depth_0, _high_0, _live_0, _flag_0, _added_0, _changed_0, _mode_0, _values_0, {$: "Tuple", "fst": ($owners$(_main_0)), "snd": {$: "Tuple", "fst": ($owners$(_aux_0)), "snd": ($owned$(_ledger_0))}});
}

function $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observations_0};
}

function $query$058prototype_identity_read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $query$058prototype_identity_struct_idx_go$1260$(_capacity_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $snapshot_fields$(_ns_0, _next_0, _capacity_0, _depth_0, _high_0, _live_0, _flag_0, _added_0, _changed_0, _mode_0, _values_0, _parts_0) {
  const _t_0 = _parts_0["fst"];
  const _mt_0 = _t_0["snd"];
  const _t_1 = _parts_0["snd"];
  const _t_2 = _t_1["fst"];
  const _at_0 = _t_2["snd"];
  const _t_3 = _t_1["snd"];
  const _lt_0 = _t_3["snd"];
  const _x_0 = ($handles$(_values_0));
  const _x_1 = ($U32$show$(_mode_0));
  const _x_2 = ("|" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|" + _x_3);
  const _x_5 = (_lt_0 + _x_4);
  const _x_6 = ($words_text$(($words$(_changed_0))));
  const _x_7 = ("|" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($words_text$(($words$(_added_0))));
  const _x_10 = ("|" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($flags$(_flag_0));
  const _x_13 = ("|" + _x_11);
  const _x_14 = (_x_12 + _x_13);
  const _x_15 = ($bools$(_live_0));
  const _x_16 = ("|" + _x_14);
  const _x_17 = (_x_15 + _x_16);
  const _x_18 = ("|" + _x_17);
  const _x_19 = (_at_0 + _x_18);
  const _x_20 = ("|" + _x_19);
  const _x_21 = (_mt_0 + _x_20);
  const _x_22 = ($U32$show$(_high_0));
  const _x_23 = ("|" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  const _x_25 = ($Nat$show$(_depth_0));
  const _x_26 = (":" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($U32$show$(_capacity_0));
  const _x_29 = (":" + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ($U32$show$(_next_0));
  const _x_32 = ("|" + _x_30);
  const _x_33 = (_x_31 + _x_32);
  const _x_34 = ($U32$show$(_ns_0));
  const _x_35 = (":" + _x_33);
  return (_x_34 + _x_35);
}

function $owners$(_array_0) {
  if (_array_0.length === 1) {
    const _t_0 = _array_0[0];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": [{$: "None"}], "snd": "none"};
    } else {
      const _owner_0 = _t_0["value"];
      return $maybe_owned$(($owned$(_owner_0)));
    }
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $owners_join$({$: "Tuple", "fst": ($owners$(_left_0)), "snd": ($owners$(_right_0))});
  }
}

function $owned$(_owner_0) {
  const _items_0 = _owner_0["items"];
  const _scalar_0 = _owner_0["scalar"];
  return $owned_words$(_scalar_0, ($words$(_items_0)));
}

function $query$058prototype_identity_struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($query$058prototype_identity_struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $bools$(_values_0) {
  if (_values_0.length === 1) {
    const _t_0 = _values_0[0];
    if (!_t_0) {
      return "0";
    } else {
      return "1";
    }
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    const _x_0 = ($bools$(_right_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($bools$(_left_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("(" + _x_4);
  }
}

function $flags$(_values_0) {
  if (_values_0.length === 1) {
    const _t_0 = _values_0[0];
    if (_t_0.$ === "None") {
      return "0";
    } else {
      return "1";
    }
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    const _x_0 = ($flags$(_right_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($flags$(_left_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("(" + _x_4);
  }
}

function $words_text$(_result_0) {
  const _text_0 = _result_0["snd"];
  return _text_0;
}

function $words$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return $words_leaf$(_value_0);
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $words_join$({$: "Tuple", "fst": ($words$(_left_0)), "snd": ($words$(_right_0))});
  }
}

function $handles$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "end";
  } else {
    const _t_0 = _values_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($handles$(_tail_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (";" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_ns_0));
    const _x_5 = (":" + _x_3);
    return (_x_4 + _x_5);
  }
}

function $maybe_owned$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [{$: "Some", "value": _owner_0}], "snd": _text_0};
}

function $owners_join$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _left_0 = _t_0["fst"];
  const _lt_0 = _t_0["snd"];
  const _t_1 = _result_0["snd"];
  const _right_0 = _t_1["fst"];
  const _rt_0 = _t_1["snd"];
  const _x_0 = (_rt_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_lt_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("(" + _x_2)};
}

function $owned_words$(_scalar_0, _result_0) {
  const _items_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_scalar_0));
  const _x_1 = ("@" + _x_0);
  return {$: "Tuple", "fst": {$: "Owned", "items": _items_0, "scalar": _scalar_0}, "snd": (_text_0 + _x_1)};
}

function $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, {$: "query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "values": _values_0});
}

function $query$058prototype_identity_struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058prototype_identity_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]});
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $words_leaf$(_value_0) {
  return {$: "Tuple", "fst": [_value_0], "snd": ($U32$show$(_value_0))};
}

function $words_join$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _left_0 = _t_0["fst"];
  const _lt_0 = _t_0["snd"];
  const _t_1 = _result_0["snd"];
  const _right_0 = _t_1["fst"];
  const _rt_0 = _t_1["snd"];
  const _x_0 = (_rt_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_lt_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("(" + _x_2)};
}

function $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": ($List$reverse$(_values_0))};
}

function $query$058prototype_identity_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058prototype_identity_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, {$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]});
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $query$058prototype_identity_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $query$058prototype_identity_struct_idx_selected$1260$(($query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $query$058prototype_identity_struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    return $query$058prototype_identity_struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, ($query$058prototype_identity_array_inspect$(_main_0, ((_id_0 - 1) >>> 0))));
  }
}

function $query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $query$058prototype_identity_struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _values_0}};
  }
}

function $query$058prototype_identity_array_inspect$(_array_0, _index_0) {
  const _x_0 = {$: "None"};
  return $query$058prototype_identity_array_restore$(_index_0, array_rmw(_array_0, _index_0, () => _x_0));
}

function $query$058prototype_identity_array_restore$(_index_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _array_0, "snd": false};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = {$: "Some", "value": _owner_0};
    return {$: "Tuple", "fst": (_array_0[_index_0 % _array_0.length] = _x_0, _array_0), "snd": true};
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);