let __allocation_active=false;
const __allocation_counts=new Float64Array(1602);
function __allocation_literal(site,value){if(__allocation_active)__allocation_counts[site]++;return value;}
function __allocation_phase(phase){if(phase==='start')__allocation_active=true;else {__allocation_active=false;console.error('ALLOCATION-COUNTS:'+JSON.stringify(Array.from(__allocation_counts)));}}
function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = __allocation_literal(0, ({$: "WNil"}));
  for (let i = 31; i >= 0; i--) {
    w = __allocation_literal(1, ({$: "WCon", head: ((x >>> i) & 1) === 1, tail: w}));
  }
  return w;
}

function cmp_new(a, b) {
  return __allocation_literal(2, ({$: a < b ? "LT"
    : a === b ? "EQ" : "GT"}));
}

function nat_divmod(a, b) {
  return b === 0 ? __allocation_literal(3, ({$: "Tuple", fst: 0, snd: a}))
    : __allocation_literal(4, ({$: "Tuple", fst: Math.trunc(a / b), snd: a % b}));
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return __allocation_literal(5, ({ [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } }));
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array(__allocation_literal(6, ([x]))).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array(__allocation_literal(7, ([u]))).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? __allocation_literal(8, ({$: "Some", value: v})) : __allocation_literal(9, ({$: "None"}));
}

const f32_round = __allocation_literal(10, (function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
}));

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return __allocation_literal(11, ({$: "Tuple", fst: a, snd: old}));
}

// Run
// ===

function run_tail(f, x) {
  return __allocation_literal(12, ({$: "$JMP", f: f.j?.f === f ? f.j : f, x: __allocation_literal(13, ([x]))}));
}

function run_clo(j) {
  const f = __allocation_literal(14, ((x) => run_loop(j(x))));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return __allocation_literal(15, ((...a) => a.length < n ? run_lib(__allocation_literal(16, ((...b) => f(...a, ...b))), n - a.length)
    : f(...a)));
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = __allocation_literal(17, ({ run, need }));
}
(__allocation_literal(18, (() => {
// IO
// ==

function io_now() {
  return BigInt(Math.floor(performance.now()));
}

io_eff("IO.now", io_now);

})))();

(__allocation_literal(19, (() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return __allocation_literal(20, ({ $: "Unit" }));
}

io_eff("IO.print", io_print);

})))();

for (const k of __allocation_literal(21, (["IO.now","IO.print"]))) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return $choose$(0, 256, 64);
}

function $choose$(_schema_0, _count_0, _batch_0) {
  if (_schema_0 == 0) {
    return $motion_batch$(_count_0, _batch_0);
  } else {
    return $health_batch$(_count_0, _batch_0);
  }
}

function $motion_batch$(_count_0, _batch_0) {
  return run_clo(__allocation_literal(22, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_start$(_count_0, false)), run_clo(__allocation_literal(23, ((_x_1) => {
  return run_clo(__allocation_literal(24, ((_x_2) => {
  return $IO$bind$(($motion_prepared$(_batch_0, _count_0, __allocation_literal(25, ({$: "Nil"})))), run_clo(__allocation_literal(26, ((_x_3) => {
  return $motion_timed$(_x_3);
}))), _x_2);
})));
}))), _x_0);
})));
}

function $health_batch$(_count_0, _batch_0) {
  return run_clo(__allocation_literal(27, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058health_start$(_count_0, false)), run_clo(__allocation_literal(28, ((_x_1) => {
  return run_clo(__allocation_literal(29, ((_x_2) => {
  return $IO$bind$(($health_prepared$(_batch_0, _count_0, __allocation_literal(30, ({$: "Nil"})))), run_clo(__allocation_literal(31, ((_x_3) => {
  return $health_timed$(_x_3);
}))), _x_2);
})));
}))), _x_0);
})));
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo(__allocation_literal(32, ((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}))));
}

function $measurement$045bend$058motion_start$(_count_0, _sparse_0) {
  return run_clo(__allocation_literal(33, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_created$(_count_0, _sparse_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_create$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058factory$()), __allocation_literal(34, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionOn"})))))), run_clo(__allocation_literal(35, ((_x_1) => {
  return $measurement$045bend$058motion_measured$(_x_1);
}))), _x_0);
})));
}

function $motion_prepared$(_fuel_0, _count_0, _owners_0) {
  if (_fuel_0 === 0) {
    return run_clo(__allocation_literal(36, ((_x_0) => {
  return $IO$pure$(($List$reverse$(_owners_0)), _x_0);
})));
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo(__allocation_literal(37, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_fresh$(_count_0)), run_clo(__allocation_literal(38, ((_x_2) => {
  return $motion_prepared$(_rest_0, _count_0, __allocation_literal(39, ({$: "Con", "head": _x_2, "tail": _owners_0})));
}))), _x_1);
})));
  }
}

function $motion_timed$(_owners_0) {
  return run_clo(__allocation_literal(40, ((_x_0) => {
  return $IO$bind$(__allocation_literal(41, ((_x_1) => $IO$now$(_x_1))), run_clo(__allocation_literal(42, ((_x_2) => {
  return run_clo(__allocation_literal(43, ((_x_3) => {
  return $IO$bind$(($motion_execute$(_owners_0, __allocation_literal(44, ({$: "Nil"})))), run_clo(__allocation_literal(45, ((_x_4) => {
  return run_clo(__allocation_literal(46, ((_x_5) => {
  return $IO$bind$(__allocation_literal(47, ((_x_6) => $IO$now$(_x_6))), run_clo(__allocation_literal(48, ((_x_7) => {
  return run_clo(__allocation_literal(49, ((_x_8) => {
  const _x_9 = ($Nat$show$((_x_7 < _x_2 ? 0 : _x_7 - _x_2)));
  return $IO$bind$(__allocation_literal(50, ((_x_10) => $IO$print$(("BATCH-MILLISECONDS:" + _x_9), _x_10))), run_clo(__allocation_literal(51, ((_x_11) => {
  return $motion_dump$(_x_4);
}))), _x_8);
})));
}))), _x_5);
})));
}))), _x_3);
})));
}))), _x_0);
})));
}

function $measurement$045bend$058health_start$(_count_0, _sparse_0) {
  return run_clo(__allocation_literal(52, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058health_created$(_count_0, _sparse_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_create$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058factory$()), __allocation_literal(53, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthOn"})))))), run_clo(__allocation_literal(54, ((_x_1) => {
  return $measurement$045bend$058health_measured$(_x_1);
}))), _x_0);
})));
}

function $health_prepared$(_fuel_0, _count_0, _owners_0) {
  if (_fuel_0 === 0) {
    return run_clo(__allocation_literal(55, ((_x_0) => {
  return $IO$pure$(($List$reverse$(_owners_0)), _x_0);
})));
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo(__allocation_literal(56, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058health_fresh$(_count_0)), run_clo(__allocation_literal(57, ((_x_2) => {
  return $health_prepared$(_rest_0, _count_0, __allocation_literal(58, ({$: "Con", "head": _x_2, "tail": _owners_0})));
}))), _x_1);
})));
  }
}

function $health_timed$(_owners_0) {
  return run_clo(__allocation_literal(59, ((_x_0) => {
  return $IO$bind$(__allocation_literal(60, ((_x_1) => $IO$now$(_x_1))), run_clo(__allocation_literal(61, ((_x_2) => {
  return run_clo(__allocation_literal(62, ((_x_3) => {
  return $IO$bind$(($health_execute$(_owners_0, __allocation_literal(63, ({$: "Nil"})))), run_clo(__allocation_literal(64, ((_x_4) => {
  return run_clo(__allocation_literal(65, ((_x_5) => {
  return $IO$bind$(__allocation_literal(66, ((_x_6) => $IO$now$(_x_6))), run_clo(__allocation_literal(67, ((_x_7) => {
  return run_clo(__allocation_literal(68, ((_x_8) => {
  const _x_9 = ($Nat$show$((_x_7 < _x_2 ? 0 : _x_7 - _x_2)));
  return $IO$bind$(__allocation_literal(69, ((_x_10) => $IO$print$(("BATCH-MILLISECONDS:" + _x_9), _x_10))), run_clo(__allocation_literal(70, ((_x_11) => {
  return $health_dump$(_x_4);
}))), _x_8);
})));
}))), _x_5);
})));
}))), _x_3);
})));
}))), _x_0);
})));
}

function $measurement$045bend$058motion_created$(_count_0, _sparse_0, _result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Created") {
    const _world_0 = _result_0["world"];
    return $measurement$045bend$058motion_registered$(_count_0, _sparse_0, _world_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047schedule$058register$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047schedule$058initial$()), "BenchUpdate", __allocation_literal(71, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Snapshot"})), true, false, false, false)));
  } else {
    return run_clo(__allocation_literal(72, ((_x_0) => {
  return $IO$die$(4, "factory rejected", _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_create$1260$(_factory_0, _mode_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create$1260$(_factory_0, _mode_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058factory$() {
  return __allocation_literal(73, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Factory", "next": 1}));
}

function $measurement$045bend$058motion_measured$(_pair_0) {
  const _state_0 = _pair_0["fst"];
  const _system_0 = _pair_0["snd"];
  return run_clo(__allocation_literal(74, ((_x_0) => {
  return $IO$bind$(__allocation_literal(75, ((_x_1) => $IO$now$(_x_1))), run_clo(__allocation_literal(76, ((_x_2) => {
  return run_clo(__allocation_literal(77, ((_x_3) => {
  return $IO$bind$(($measurement$045bend$058motion_loops$(64, _system_0, _state_0)), run_clo(__allocation_literal(78, ((_x_4) => {
  return $measurement$045bend$058motion_stop$(_x_2, _x_4);
}))), _x_3);
})));
}))), _x_0);
})));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, __allocation_literal(79, ({$: "Nil"})));
}

function $measurement$045bend$058motion_fresh$(_count_0) {
  return $measurement$045bend$058motion_created$(_count_0, false, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_create$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058factory$()), __allocation_literal(80, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionOn"})))));
}

function $IO$now$(_k_0) {
  return __allocation_literal(81, ({ $: "$FFI", run: $0eff["IO.now"].run, need: $0eff["IO.now"].need, args: __allocation_literal(82, ([])), kont: (__allocation_literal(83, ((f) => __allocation_literal(84, ((x) => (f(nat_host(x))))))))(_k_0) }));
}
function $motion_execute$(_owners_0, _done_0) {
  if (_owners_0.$ === "Nil") {
    return run_clo(__allocation_literal(85, ((_x_0) => {
  return $IO$pure$(($List$reverse$(_done_0)), _x_0);
})));
  } else {
    const _t_0 = _owners_0["head"];
    const _owner_0 = _t_0["fst"];
    const _system_0 = _t_0["snd"];
    const _rest_0 = _owners_0["tail"];
    return run_clo(__allocation_literal(86, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_loops$(64, _system_0, _owner_0)), run_clo(__allocation_literal(87, ((_x_2) => {
  return $motion_returned$(run_clo(__allocation_literal(88, ((_x_3) => {
  return $motion_execute$(_rest_0, _x_3);
}))), _done_0, _x_2);
}))), _x_1);
})));
  }
}

function $IO$print$(_text_0, _k_0) {
  return __allocation_literal(89, ({ $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: __allocation_literal(90, ([(_text_0)])), kont: (_k_0) }));
}
function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $motion_dump$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return run_clo(__allocation_literal(91, ((_x_0) => {
  return $IO$pure$(__allocation_literal(92, ({$: "Unit"})), _x_0);
})));
  } else {
    const _owner_0 = _owners_0["head"];
    const _rest_0 = _owners_0["tail"];
    return run_clo(__allocation_literal(93, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_dump$(0, _owner_0)), run_clo(__allocation_literal(94, ((_x_2) => {
  return $motion_dump$(_rest_0);
}))), _x_1);
})));
  }
}

function $measurement$045bend$058health_created$(_count_0, _sparse_0, _result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Created") {
    const _world_0 = _result_0["world"];
    return $measurement$045bend$058health_registered$(_count_0, _sparse_0, _world_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047schedule$058register$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047schedule$058initial$()), "BenchUpdate", __allocation_literal(95, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Snapshot"})), true, false, false, false)));
  } else {
    return run_clo(__allocation_literal(96, ((_x_0) => {
  return $IO$die$(4, "factory rejected", _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_create$1260$(_factory_0, _mode_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create$1261$(_factory_0, _mode_0);
}

function $measurement$045bend$058health_measured$(_pair_0) {
  const _state_0 = _pair_0["fst"];
  const _system_0 = _pair_0["snd"];
  return run_clo(__allocation_literal(97, ((_x_0) => {
  return $IO$bind$(__allocation_literal(98, ((_x_1) => $IO$now$(_x_1))), run_clo(__allocation_literal(99, ((_x_2) => {
  return run_clo(__allocation_literal(100, ((_x_3) => {
  return $IO$bind$(($measurement$045bend$058health_loops$(64, _system_0, _state_0)), run_clo(__allocation_literal(101, ((_x_4) => {
  return $measurement$045bend$058health_stop$(_x_2, _x_4);
}))), _x_3);
})));
}))), _x_0);
})));
}

function $measurement$045bend$058health_fresh$(_count_0) {
  return $measurement$045bend$058health_created$(_count_0, false, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_create$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058factory$()), __allocation_literal(102, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthOn"})))));
}

function $health_execute$(_owners_0, _done_0) {
  if (_owners_0.$ === "Nil") {
    return run_clo(__allocation_literal(103, ((_x_0) => {
  return $IO$pure$(($List$reverse$(_done_0)), _x_0);
})));
  } else {
    const _t_0 = _owners_0["head"];
    const _owner_0 = _t_0["fst"];
    const _system_0 = _t_0["snd"];
    const _rest_0 = _owners_0["tail"];
    return run_clo(__allocation_literal(104, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058health_loops$(64, _system_0, _owner_0)), run_clo(__allocation_literal(105, ((_x_2) => {
  return $health_returned$(run_clo(__allocation_literal(106, ((_x_3) => {
  return $health_execute$(_rest_0, _x_3);
}))), _done_0, _x_2);
}))), _x_1);
})));
  }
}

function $health_dump$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return run_clo(__allocation_literal(107, ((_x_0) => {
  return $IO$pure$(__allocation_literal(108, ({$: "Unit"})), _x_0);
})));
  } else {
    const _owner_0 = _owners_0["head"];
    const _rest_0 = _owners_0["tail"];
    return run_clo(__allocation_literal(109, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058health_dump$(0, _owner_0)), run_clo(__allocation_literal(110, ((_x_2) => {
  return $health_dump$(_rest_0);
}))), _x_1);
})));
  }
}

function $measurement$045bend$058motion_registered$(_count_0, _sparse_0, _world_0, _registered_0) {
  const _registry_0 = _registered_0["registry"];
  const _system_0 = _registered_0["system"];
  return run_clo(__allocation_literal(111, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_tick$(__allocation_literal(112, ({$: "Con", "head": __allocation_literal(113, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Deferred"})), "tail": __allocation_literal(114, ({$: "Nil"}))})), __allocation_literal(115, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": __allocation_literal(116, ({$: "measurement-bend.MotionBench", "host": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058initial$("motion", ($measurement$045bend$058motion_seed$(_count_0, 0, _sparse_0, _world_0)), 65536)), "sparse": _sparse_0, "readsum": 0, "calls": 0})), "registry": _registry_0, "readers": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058initial$()), "clock": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058clock$()), "audit": __allocation_literal(117, ({$: "None"})), "style": __allocation_literal(118, ({$: "../bendvy-query-live-first/experiments/s-integrate/capture.Returned"})), "escaped": __allocation_literal(119, ({$: "Nil"})), "observations": __allocation_literal(120, ({$: "Nil"})), "nextMode": __allocation_literal(121, ({$: "None"}))})))), run_clo(__allocation_literal(122, ((_x_1) => {
  return run_clo(__allocation_literal(123, ((_x_2) => {
  return $IO$bind$(run_loop($measurement$045bend$058motion_continue$(run_clo(__allocation_literal(124, ((_x_3) => {
  return run_clo(__allocation_literal(125, ((_x_4) => {
  return $IO$pure$(_x_3, _x_4);
})));
}))), _x_1)), run_clo(__allocation_literal(126, ((_x_5) => {
  return run_clo(__allocation_literal(127, ((_x_6) => {
  return $IO$pure$(__allocation_literal(128, ({$: "Tuple", "fst": _x_5, "snd": _system_0})), _x_6);
})));
}))), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047schedule$058register$(_registry_0, _name_0, _kind_0, _ledger_0, _audit_0, _gated_0, _reader_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _system_0 = __allocation_literal(129, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _next_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0}));
  return __allocation_literal(130, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Registered", "registry": __allocation_literal(131, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Registry", "next": ((_next_0 + 1) >>> 0), "entries": __allocation_literal(132, ({$: "Con", "head": __allocation_literal(133, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058initial$())})), "tail": _entries_0}))})), "system": _system_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047schedule$058initial$() {
  return __allocation_literal(134, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Registry", "next": 1, "entries": __allocation_literal(135, ({$: "Nil"}))}));
}

function $IO$die$(_code_0, _msg_0, _k_0) {
  return __allocation_literal(136, ({$: "Halt", "code": _code_0, "message": _msg_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create$1260$(_factory_0, _mode_0) {
  const _namespace_0 = _factory_0["next"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _mode_0);
}

function $measurement$045bend$058motion_loops$(_fuel_0, _system_0, _runtime_0) {
  if (_fuel_0 === 0) {
    return run_clo(__allocation_literal(137, ((_x_0) => {
  return $IO$pure$(_runtime_0, _x_0);
})));
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo(__allocation_literal(138, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_tick$(__allocation_literal(139, ({$: "Con", "head": __allocation_literal(140, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Call", "system": _system_0, "mode": __allocation_literal(141, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Normal"}))})), "tail": __allocation_literal(142, ({$: "Nil"}))})), _runtime_0)), run_clo(__allocation_literal(143, ((_x_2) => {
  return $measurement$045bend$058motion_continue$(run_clo(__allocation_literal(144, ((_x_3) => {
  return $measurement$045bend$058motion_loops$(_rest_0, _system_0, _x_3);
}))), _x_2);
}))), _x_1);
})));
  }
}

function $measurement$045bend$058motion_stop$(_start_0, _state_0) {
  return run_clo(__allocation_literal(145, ((_x_0) => {
  return $IO$bind$(__allocation_literal(146, ((_x_1) => $IO$now$(_x_1))), run_clo(__allocation_literal(147, ((_x_2) => {
  return $measurement$045bend$058motion_dump$((_x_2 < _start_0 ? 0 : _x_2 - _start_0), _state_0);
}))), _x_0);
})));
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = __allocation_literal(148, ({$: "Con", "head": _h_0, "tail": _acc_0}));
        continue;
      }
    }
  }
}

function $motion_returned$(_next_0, _done_0, _owner_0) {
  return run_tail(_next_0, __allocation_literal(149, ({$: "Con", "head": _owner_0, "tail": _done_0})));
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return __allocation_literal(150, ({$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0}));
}

function $measurement$045bend$058motion_dump$(_elapsed_0, _state_0) {
  const _t_0 = _state_0["world"];
  const _t_1 = _t_0["host"];
  const _world_0 = _t_1["world"];
  const _total_0 = _t_0["readsum"];
  const _calls_0 = _t_0["calls"];
  const _clock_0 = _state_0["clock"];
  return $measurement$045bend$058motion_print$(_elapsed_0, _total_0, _calls_0, _clock_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world$1260$(_world_0)));
}

function $measurement$045bend$058health_registered$(_count_0, _sparse_0, _world_0, _registered_0) {
  const _registry_0 = _registered_0["registry"];
  const _system_0 = _registered_0["system"];
  return run_clo(__allocation_literal(151, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058health_tick$(__allocation_literal(152, ({$: "Con", "head": __allocation_literal(153, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Deferred"})), "tail": __allocation_literal(154, ({$: "Nil"}))})), __allocation_literal(155, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": __allocation_literal(156, ({$: "measurement-bend.HealthBench", "host": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058initial$("health", ($measurement$045bend$058health_seed$(_count_0, 0, _sparse_0, _world_0)), 65536)), "sparse": _sparse_0, "readsum": 0, "calls": 0})), "registry": _registry_0, "readers": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058initial$()), "clock": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058clock$()), "audit": __allocation_literal(157, ({$: "None"})), "style": __allocation_literal(158, ({$: "../bendvy-query-live-first/experiments/s-integrate/capture.Returned"})), "escaped": __allocation_literal(159, ({$: "Nil"})), "observations": __allocation_literal(160, ({$: "Nil"})), "nextMode": __allocation_literal(161, ({$: "None"}))})))), run_clo(__allocation_literal(162, ((_x_1) => {
  return run_clo(__allocation_literal(163, ((_x_2) => {
  return $IO$bind$(run_loop($measurement$045bend$058health_continue$(run_clo(__allocation_literal(164, ((_x_3) => {
  return run_clo(__allocation_literal(165, ((_x_4) => {
  return $IO$pure$(_x_3, _x_4);
})));
}))), _x_1)), run_clo(__allocation_literal(166, ((_x_5) => {
  return run_clo(__allocation_literal(167, ((_x_6) => {
  return $IO$pure$(__allocation_literal(168, ({$: "Tuple", "fst": _x_5, "snd": _system_0})), _x_6);
})));
}))), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create$1261$(_factory_0, _mode_0) {
  const _namespace_0 = _factory_0["next"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _mode_0);
}

function $measurement$045bend$058health_loops$(_fuel_0, _system_0, _runtime_0) {
  if (_fuel_0 === 0) {
    return run_clo(__allocation_literal(169, ((_x_0) => {
  return $IO$pure$(_runtime_0, _x_0);
})));
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo(__allocation_literal(170, ((_x_1) => {
  return $IO$bind$(($measurement$045bend$058health_tick$(__allocation_literal(171, ({$: "Con", "head": __allocation_literal(172, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Call", "system": _system_0, "mode": __allocation_literal(173, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Normal"}))})), "tail": __allocation_literal(174, ({$: "Nil"}))})), _runtime_0)), run_clo(__allocation_literal(175, ((_x_2) => {
  return $measurement$045bend$058health_continue$(run_clo(__allocation_literal(176, ((_x_3) => {
  return $measurement$045bend$058health_loops$(_rest_0, _system_0, _x_3);
}))), _x_2);
}))), _x_1);
})));
  }
}

function $measurement$045bend$058health_stop$(_start_0, _state_0) {
  return run_clo(__allocation_literal(177, ((_x_0) => {
  return $IO$bind$(__allocation_literal(178, ((_x_1) => $IO$now$(_x_1))), run_clo(__allocation_literal(179, ((_x_2) => {
  return $measurement$045bend$058health_dump$((_x_2 < _start_0 ? 0 : _x_2 - _start_0), _state_0);
}))), _x_0);
})));
}

function $health_returned$(_next_0, _done_0, _owner_0) {
  return run_tail(_next_0, __allocation_literal(180, ({$: "Con", "head": _owner_0, "tail": _done_0})));
}

function $measurement$045bend$058health_dump$(_elapsed_0, _state_0) {
  const _t_0 = _state_0["world"];
  const _t_1 = _t_0["host"];
  const _world_0 = _t_1["world"];
  const _total_0 = _t_0["readsum"];
  const _calls_0 = _t_0["calls"];
  const _clock_0 = _state_0["clock"];
  return $measurement$045bend$058health_print$(_elapsed_0, _total_0, _calls_0, _clock_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world$1261$(_world_0)));
}

function $measurement$045bend$058motion_tick$(_nodes_0, _runtime_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick$1262$(_nodes_0, "MotionLedger", "Mode", _runtime_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058initial$(_worldName_0, _world_0, _capacity_0) {
  return __allocation_literal(181, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": _world_0, "logs": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058initial$(_capacity_0)), "bindings": __allocation_literal(182, ({$: "Nil"})), "worldName": _worldName_0, "step": "", "prior": __allocation_literal(183, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"})), "events": __allocation_literal(184, ({$: "Nil"}))}));
}

function $measurement$045bend$058motion_seed$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _j_0 = $1;
      const _sparse_0 = $2;
      const _world_0 = $3;
      if (_fuel_0 === 0) {
        return _world_0;
      } else {
        const _rest_0 = (_fuel_0 - 1);
        $0 = _rest_0;
        $1 = ((_j_0 + 1) >>> 0);
        $2 = _sparse_0;
        $3 = ($measurement$045bend$058motion_reserved$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve$(_world_0, ($measurement$045bend$058motion_bundle$(_j_0, _sparse_0))))));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058initial$() {
  return __allocation_literal(185, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Readers", "slots": __allocation_literal(186, ({$: "Nil"}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058clock$() {
  return __allocation_literal(187, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Clock", "tick": 0, "frameStart": 0, "retainedAfter": 0, "frameNo": 0}));
}

function $measurement$045bend$058motion_continue$(_next_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete") {
    return run_tail(_next_0, _runtime_0);
  } else {
    return run_clo(__allocation_literal(188, ((_x_0) => {
  return $IO$die$(3, "dispatch failure", _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058initial$() {
  return __allocation_literal(189, ({$: "../bendvy-query-live-first/experiments/s-integrate/capture.Local", "count": array_new(2, 0)}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create_checked$1260$(_available_0, _namespace_0, _mode_0) {
  if (!_available_0) {
    return __allocation_literal(190, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.CreateRejected", "factory": __allocation_literal(191, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Factory", "next": _namespace_0}))}));
  } else {
    return __allocation_literal(192, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Created", "factory": __allocation_literal(193, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Factory", "next": ((_namespace_0 + 1) >>> 0)})), "world": __allocation_literal(194, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": 1, "rows": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_empty$()), "pending": __allocation_literal(195, ({$: "Nil"})), "ledger": __allocation_literal(196, ({$: "Some", "value": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_ledger$1260$(__allocation_literal(197, ({$: "Unit"}))))})), "mode": _mode_0}))}));
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $measurement$045bend$058motion_print$(_elapsed_0, _total_0, _calls_0, _clock_0, _pair_0) {
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_world$1260$(_view_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(($measurement$045bend$058clock_frame$(_clock_0))));
  const _x_3 = (",\"world\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0))));
  const _x_6 = (",\"frames\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_calls_0));
  const _x_9 = (",\"tick\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($U32$show$(_total_0));
  const _x_12 = (",\"calls\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_elapsed_0));
  const _x_15 = (",\"readsum\":" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  return __allocation_literal(198, ((_x_17) => $IO$print$(("{\"milliseconds\":" + _x_16), _x_17)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world$1260$(_owner_0) {
  const _namespace_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["next"];
  const _owners_0 = _owner_0["rows"];
  const _pending_0 = _owner_0["pending"];
  const _ledger_0 = _owner_0["ledger"];
  const _mode_0 = _owner_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_rows$1260$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows$1260$(_owners_0)));
}

function $measurement$045bend$058health_tick$(_nodes_0, _runtime_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick$1263$(_nodes_0, "HealthLedger", "Mode", _runtime_0);
}

function $measurement$045bend$058health_seed$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _j_0 = $1;
      const _sparse_0 = $2;
      const _world_0 = $3;
      if (_fuel_0 === 0) {
        return _world_0;
      } else {
        const _rest_0 = (_fuel_0 - 1);
        $0 = _rest_0;
        $1 = ((_j_0 + 1) >>> 0);
        $2 = _sparse_0;
        $3 = ($measurement$045bend$058health_reserved$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_reserve$(_world_0, ($measurement$045bend$058health_bundle$(_j_0, _sparse_0))))));
        continue;
      }
    }
  }
}

function $measurement$045bend$058health_continue$(_next_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete") {
    return run_tail(_next_0, _runtime_0);
  } else {
    return run_clo(__allocation_literal(199, ((_x_0) => {
  return $IO$die$(3, "dispatch failure", _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058create_checked$1261$(_available_0, _namespace_0, _mode_0) {
  if (!_available_0) {
    return __allocation_literal(200, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.CreateRejected", "factory": __allocation_literal(201, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Factory", "next": _namespace_0}))}));
  } else {
    return __allocation_literal(202, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Created", "factory": __allocation_literal(203, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Factory", "next": ((_namespace_0 + 1) >>> 0)})), "world": __allocation_literal(204, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": 1, "rows": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_empty$()), "pending": __allocation_literal(205, ({$: "Nil"})), "ledger": __allocation_literal(206, ({$: "Some", "value": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_ledger$1260$(__allocation_literal(207, ({$: "Unit"}))))})), "mode": _mode_0}))}));
  }
}

function $measurement$045bend$058health_print$(_elapsed_0, _total_0, _calls_0, _clock_0, _pair_0) {
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_world$1261$(_view_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(($measurement$045bend$058clock_frame$(_clock_0))));
  const _x_3 = (",\"world\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0))));
  const _x_6 = (",\"frames\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_calls_0));
  const _x_9 = (",\"tick\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($U32$show$(_total_0));
  const _x_12 = (",\"calls\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_elapsed_0));
  const _x_15 = (",\"readsum\":" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  return __allocation_literal(208, ((_x_17) => $IO$print$(("{\"milliseconds\":" + _x_16), _x_17)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world$1261$(_owner_0) {
  const _namespace_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["next"];
  const _owners_0 = _owner_0["rows"];
  const _pending_0 = _owner_0["pending"];
  const _ledger_0 = _owner_0["ledger"];
  const _mode_0 = _owner_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_rows$1261$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows$1261$(_owners_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick$1262$(_nodes_0, _ledgerName_0, _stateName_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_registry$1262$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_values$(_registry_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058initial$(_capacity_0) {
  return __allocation_literal(209, ({$: "../bendvy-query-live-first/experiments/s-integrate/reader-host.Logs", "ping": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058initial$(_capacity_0)), "removed": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058life_initial$(_capacity_0)), "despawned": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058life_initial$(_capacity_0))}));
}

function $measurement$045bend$058motion_reserved$(_result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Reserved") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve$(_world_0, _raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058reserve$(_world_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_bundle$(_raw_0)))));
}

function $measurement$045bend$058motion_bundle$(_j_0, _sparse_0) {
  const _x_0 = (8 === 0 ? _j_0 : _j_0 % 8);
  const _x_1 = ($Bool$not$(_sparse_0));
  const _x_2 = (_x_0 === 0);
  const _x_3 = (3 === 0 ? _j_0 : _j_0 % 3);
  const _x_4 = (3 === 0 ? _j_0 : _j_0 % 3);
  return __allocation_literal(210, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": ($measurement$045bend$058motion_main$(_j_0, (_x_1 || _x_2))), "aux": ($measurement$045bend$058motion_aux$((_x_3 === 0))), "flag": ($measurement$045bend$058motion_flag$((_x_4 === 1)))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_empty$() {
  return __allocation_literal(211, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": __allocation_literal(212, ([__allocation_literal(213, ({$: "None"}))])), "aux": __allocation_literal(214, ([__allocation_literal(215, ({$: "None"}))])), "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_ledger$1260$(_unit_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_new$(($measurement$045bend$058motion_ledger$(_unit_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0) {
  const _tick_0 = _clock_0["tick"];
  return _tick_0;
}

function $measurement$045bend$058clock_frame$(_clock_0) {
  const _frames_0 = _clock_0["frameNo"];
  return _frames_0;
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_world$1260$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _next_0 = _value_0["next"];
  const _rows_0 = _value_0["rows"];
  const _pending_0 = _value_0["pending"];
  const _ledger_0 = _value_0["ledger"];
  const _mode_0 = _value_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(216, ({$: "Con", "head": "{\"namespace\":", "tail": __allocation_literal(217, ({$: "Con", "head": ($U32$show$(_namespace_0)), "tail": __allocation_literal(218, ({$: "Con", "head": ",\"next\":", "tail": __allocation_literal(219, ({$: "Con", "head": ($U32$show$(_next_0)), "tail": __allocation_literal(220, ({$: "Con", "head": ",\"rows\":", "tail": __allocation_literal(221, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$1265$(_rows_0)), "tail": __allocation_literal(222, ({$: "Con", "head": ",\"pending\":", "tail": __allocation_literal(223, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$1266$(_pending_0)), "tail": __allocation_literal(224, ({$: "Con", "head": ",\"ledger\":", "tail": __allocation_literal(225, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_ledger_0)), "tail": __allocation_literal(226, ({$: "Con", "head": ",\"mode\":", "tail": __allocation_literal(227, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_motion_mode$(_mode_0)), "tail": __allocation_literal(228, ({$: "Con", "head": "}", "tail": __allocation_literal(229, ({$: "Nil"}))}))}))}))}))}))}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_rows$1260$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_commands$1260$(_namespace_0, _next_0, _owners_0, _values_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands$1260$(_pending_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows$1260$(_owners_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_start$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_high_water$(_owners_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick$1263$(_nodes_0, _ledgerName_0, _stateName_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_registry$1263$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_values$(_registry_0)));
}

function $measurement$045bend$058health_reserved$(_result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Reserved") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_reserve$(_world_0, _raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_reserve_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058reserve$(_world_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_bundle$(_raw_0)))));
}

function $measurement$045bend$058health_bundle$(_j_0, _sparse_0) {
  const _x_0 = (8 === 0 ? _j_0 : _j_0 % 8);
  const _x_1 = ($Bool$not$(_sparse_0));
  const _x_2 = (_x_0 === 0);
  const _x_3 = (3 === 0 ? _j_0 : _j_0 % 3);
  const _x_4 = (3 === 0 ? _j_0 : _j_0 % 3);
  return __allocation_literal(230, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": ($measurement$045bend$058health_main$(_j_0, (_x_1 || _x_2))), "aux": ($measurement$045bend$058health_aux$((_x_3 === 0))), "flag": ($measurement$045bend$058health_flag$((_x_4 === 1)))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_ledger$1260$(_unit_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_new$(($measurement$045bend$058health_ledger$(_unit_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_world$1261$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _next_0 = _value_0["next"];
  const _rows_0 = _value_0["rows"];
  const _pending_0 = _value_0["pending"];
  const _ledger_0 = _value_0["ledger"];
  const _mode_0 = _value_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(231, ({$: "Con", "head": "{\"namespace\":", "tail": __allocation_literal(232, ({$: "Con", "head": ($U32$show$(_namespace_0)), "tail": __allocation_literal(233, ({$: "Con", "head": ",\"next\":", "tail": __allocation_literal(234, ({$: "Con", "head": ($U32$show$(_next_0)), "tail": __allocation_literal(235, ({$: "Con", "head": ",\"rows\":", "tail": __allocation_literal(236, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$12613$(_rows_0)), "tail": __allocation_literal(237, ({$: "Con", "head": ",\"pending\":", "tail": __allocation_literal(238, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$12614$(_pending_0)), "tail": __allocation_literal(239, ({$: "Con", "head": ",\"ledger\":", "tail": __allocation_literal(240, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_ledger_0)), "tail": __allocation_literal(241, ({$: "Con", "head": ",\"mode\":", "tail": __allocation_literal(242, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_health_mode$(_mode_0)), "tail": __allocation_literal(243, ({$: "Con", "head": "}", "tail": __allocation_literal(244, ({$: "Nil"}))}))}))}))}))}))}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_rows$1261$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_commands$1261$(_namespace_0, _next_0, _owners_0, _values_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands$1261$(_pending_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows$1261$(_owners_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_start$1261$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_high_water$(_owners_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_registry$1262$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _scan_0) {
  const _registry_0 = _scan_0["fst"];
  const _systems_0 = _scan_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_canonical$1262$(_ledgerName_0, _stateName_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nodes_0)), __allocation_literal(245, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_values$(_registry_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_return$(_next_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_entries$(_entries_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058initial$(_capacity_0) {
  return __allocation_literal(246, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.PingLog", "buffer": __allocation_literal(247, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": 0, "dropped": 0, "front": __allocation_literal(248, ({$: "Nil"})), "rear": __allocation_literal(249, ({$: "Nil"}))}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058life_initial$(_capacity_0) {
  return __allocation_literal(250, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.LifeLog", "buffer": __allocation_literal(251, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": 0, "dropped": 0, "front": __allocation_literal(252, ({$: "Nil"})), "rear": __allocation_literal(253, ({$: "Nil"}))}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve_return$(_result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return __allocation_literal(254, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Reserved", "world": _world_0, "handle": _handle_0}));
  } else {
    const _world_1 = _result_0["world"];
    const _bundle_0 = _result_0["payload"];
    return __allocation_literal(255, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReserveRejected", "world": _world_1, "payload": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_bundle$(_bundle_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058reserve$(_world_0, _bundle_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058reserved$(_bundle_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058reserve_id$(_world_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_bundle$(_raw_0) {
  const _main_0 = _raw_0["main"];
  const _aux_0 = _raw_0["aux"];
  const _flag_0 = _raw_0["flag"];
  return __allocation_literal(256, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_main$(_main_0)), "aux": _aux_0, "flag": _flag_0}));
}

function $measurement$045bend$058motion_main$(_j_0, _present_0) {
  if (!_present_0) {
    return __allocation_literal(257, ({$: "None"}));
  } else {
    return __allocation_literal(258, ({$: "Some", "value": __allocation_literal(259, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Position", "coordinates": ($measurement$045bend$058quad$(_j_0, ((_j_0 + 1) >>> 0), ((_j_0 + 2) >>> 0), ((_j_0 + 3) >>> 0))), "frame": 7}))}));
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $measurement$045bend$058motion_aux$(_present_0) {
  if (!_present_0) {
    return __allocation_literal(260, ({$: "None"}));
  } else {
    return __allocation_literal(261, ({$: "Some", "value": __allocation_literal(262, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Velocity", "rates": ($measurement$045bend$058quad$(1, 2, 3, 4)), "moving": true}))}));
  }
}

function $measurement$045bend$058motion_flag$(_present_0) {
  if (!_present_0) {
    return __allocation_literal(263, ({$: "None"}));
  } else {
    return __allocation_literal(264, ({$: "Some", "value": __allocation_literal(265, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Selected", "group": 8}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_empty$(_depth_0) {
  const _x_0 = __allocation_literal(266, ({$: "None"}));
  return __allocation_literal(267, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_new$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1262$(_raw_0);
}

function $measurement$045bend$058motion_ledger$(_unit_0) {
  return __allocation_literal(268, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedger", "totals": ($measurement$045bend$058quad$(0, 101, 102, 103)), "epoch": 4}));
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(_values_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_chunks$(_values_0, "");
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$1265$(_values_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(269, ({$: "Con", "head": "[", "tail": __allocation_literal(270, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$1265$(_values_0, __allocation_literal(271, ({$: "Nil"})), true)))), "tail": __allocation_literal(272, ({$: "Con", "head": "]", "tail": __allocation_literal(273, ({$: "Nil"}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$1266$(_values_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(274, ({$: "Con", "head": "[", "tail": __allocation_literal(275, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$1266$(_values_0, __allocation_literal(276, ({$: "Nil"})), true)))), "tail": __allocation_literal(277, ({$: "Con", "head": "]", "tail": __allocation_literal(278, ({$: "Nil"}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_ledger$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_motion_mode$(_value_0) {
  if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.MotionOn") {
    return "\"MotionOn\"";
  } else {
    return "\"MotionOff\"";
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_commands$1260$(_namespace_0, _next_0, _rows_0, _rowViews_0, _ledger_0, _mode_0, _result_0) {
  const _pending_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _values_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1264$(_ledger_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands$1260$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return __allocation_literal(279, ({$: "Tuple", "fst": __allocation_literal(280, ({$: "Nil"})), "snd": __allocation_literal(281, ({$: "Nil"}))}));
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands_head$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command$1260$(_head_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands$1260$(_tail_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_start$1260$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _high_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_go$1260$(_high_0, 1, __allocation_literal(282, ({$: "Tuple", "fst": _owners_0, "snd": __allocation_literal(283, ({$: "Nil"}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_high_water$(_rows_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return __allocation_literal(284, ({$: "Tuple", "fst": __allocation_literal(285, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), "snd": _h_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_registry$1263$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _scan_0) {
  const _registry_0 = _scan_0["fst"];
  const _systems_0 = _scan_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_canonical$1263$(_ledgerName_0, _stateName_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nodes_0)), __allocation_literal(286, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_reserve_return$(_result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return __allocation_literal(287, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Reserved", "world": _world_0, "handle": _handle_0}));
  } else {
    const _world_1 = _result_0["world"];
    const _bundle_0 = _result_0["payload"];
    return __allocation_literal(288, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReserveRejected", "world": _world_1, "payload": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_raw_bundle$(_bundle_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_bundle$(_raw_0) {
  const _main_0 = _raw_0["main"];
  const _aux_0 = _raw_0["aux"];
  const _flag_0 = _raw_0["flag"];
  return __allocation_literal(289, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_main$(_main_0)), "aux": _aux_0, "flag": _flag_0}));
}

function $measurement$045bend$058health_main$(_j_0, _present_0) {
  if (!_present_0) {
    return __allocation_literal(290, ({$: "None"}));
  } else {
    return __allocation_literal(291, ({$: "Some", "value": __allocation_literal(292, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Vitals", "levels": ($measurement$045bend$058quad$(_j_0, ((_j_0 + 1) >>> 0), ((_j_0 + 2) >>> 0), ((_j_0 + 3) >>> 0))), "reserve": 9, "class": 2}))}));
  }
}

function $measurement$045bend$058health_aux$(_present_0) {
  if (!_present_0) {
    return __allocation_literal(293, ({$: "None"}));
  } else {
    return __allocation_literal(294, ({$: "Some", "value": __allocation_literal(295, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Armor", "layers": ($measurement$045bend$058quad$(1, 2, 3, 4)), "grade": 3}))}));
  }
}

function $measurement$045bend$058health_flag$(_present_0) {
  if (!_present_0) {
    return __allocation_literal(296, ({$: "None"}));
  } else {
    return __allocation_literal(297, ({$: "Some", "value": __allocation_literal(298, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Tracked", "group": 8}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_new$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1263$(_raw_0);
}

function $measurement$045bend$058health_ledger$(_unit_0) {
  return __allocation_literal(299, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedger", "totals": ($measurement$045bend$058quad$(0, 101, 102, 103)), "epoch": 4}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$12613$(_values_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(300, ({$: "Con", "head": "[", "tail": __allocation_literal(301, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$12613$(_values_0, __allocation_literal(302, ({$: "Nil"})), true)))), "tail": __allocation_literal(303, ({$: "Con", "head": "]", "tail": __allocation_literal(304, ({$: "Nil"}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list$12614$(_values_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(305, ({$: "Con", "head": "[", "tail": __allocation_literal(306, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$12614$(_values_0, __allocation_literal(307, ({$: "Nil"})), true)))), "tail": __allocation_literal(308, ({$: "Con", "head": "]", "tail": __allocation_literal(309, ({$: "Nil"}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_health_mode$(_value_0) {
  if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.HealthOn") {
    return "\"HealthOn\"";
  } else {
    return "\"HealthOff\"";
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_commands$1261$(_namespace_0, _next_0, _rows_0, _rowViews_0, _ledger_0, _mode_0, _result_0) {
  const _pending_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _values_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1265$(_ledger_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands$1261$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return __allocation_literal(310, ({$: "Tuple", "fst": __allocation_literal(311, ({$: "Nil"})), "snd": __allocation_literal(312, ({$: "Nil"}))}));
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands_head$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command$1261$(_head_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands$1261$(_tail_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_start$1261$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _high_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_go$1261$(_high_0, 1, __allocation_literal(313, ({$: "Tuple", "fst": _owners_0, "snd": __allocation_literal(314, ({$: "Nil"}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_canonical$1262$(_ledgerName_0, _stateName_0, _checked_0, _runtime_0) {
  if (_checked_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Unknown") {
    const _base_0 = _checked_0["base"];
    return run_clo(__allocation_literal(315, ((_x_0) => {
  const _x_1 = ($U32$show$(_base_0));
  return $IO$pure$(__allocation_literal(316, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": __allocation_literal(317, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SetupRejected", "reason": ("unregistered base:" + _x_1)}))})), _x_0);
})));
  } else {
    const _nodes_0 = _checked_0["nodes"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_presence$1262$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058motion_presence$(_world_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nodes_0) {
  if (_nodes_0.$ === "Nil") {
    return __allocation_literal(318, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Accepted", "nodes": __allocation_literal(319, ({$: "Nil"}))}));
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Call") {
      const _t_1 = _t_0["system"];
      const _base_0 = _t_1["base"];
      const _mode_0 = _t_0["mode"];
      const _tail_0 = _nodes_0["tail"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_call$(_base_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058system_find$(_base_0, _systems_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _tail_0)));
    } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_1 = _nodes_0["tail"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_nested$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nested_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _tail_1)));
    } else {
      const _tail_2 = _nodes_0["tail"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_cons$(_t_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _tail_2)));
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_return$(_next_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _systems_0 = _pair_0["snd"];
  return __allocation_literal(320, ({$: "Tuple", "fst": __allocation_literal(321, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Registry", "next": _next_0, "entries": _entries_0})), "snd": _systems_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_entries$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return __allocation_literal(322, ({$: "Tuple", "fst": __allocation_literal(323, ({$: "Nil"})), "snd": __allocation_literal(324, ({$: "Nil"}))}));
  } else {
    const _t_0 = _entries_0["head"];
    const _system_0 = _t_0["system"];
    const _local_0 = _t_0["local"];
    const _tail_0 = _entries_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_join$(_system_0, _local_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_entries$(_tail_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_bundle$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return __allocation_literal(325, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_main$(_main_0)), "aux": _aux_0, "flag": _flag_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058reserved$(_bundle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(326, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReserveRejected", "world": _world_0, "payload": _bundle_0}));
  } else {
    const _t_1 = _t_0["value"];
    const _namespace_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    return __allocation_literal(327, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Reserved", "world": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058publish$(_world_0, __allocation_literal(328, ({$: "Con", "head": __allocation_literal(329, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _bundle_0})), "tail": __allocation_literal(330, ({$: "Nil"}))})))), "handle": __allocation_literal(331, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058reserve_id$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058reserve_checked$((_next_0 < 4294967295), _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_main$(_raw_0) {
  if (_raw_0.$ === "None") {
    return __allocation_literal(332, ({$: "None"}));
  } else {
    const _raw_1 = _raw_0["value"];
    return __allocation_literal(333, ({$: "Some", "value": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_new$(_raw_1))}));
  }
}

function $measurement$045bend$058quad$(_a_0, _b_0, _c_0, _d_0) {
  const _x_0 = array_new(2, _a_0);
  const _x_1 = (_x_0[1 % _x_0.length] = _b_0, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = _c_0, _x_1);
  return (_x_2[3 % _x_2.length] = _d_0, _x_2);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1262$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_get$(_raw_0)));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$1265$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_row$1260$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$1266$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_pending$1260$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(334, ({$: "Con", "head": "{\"totals\":", "tail": __allocation_literal(335, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_four$(_totals_0)), "tail": __allocation_literal(336, ({$: "Con", "head": ",\"epoch\":", "tail": __allocation_literal(337, ({$: "Con", "head": ($U32$show$(_epoch_0)), "tail": __allocation_literal(338, ({$: "Con", "head": "}", "tail": __allocation_literal(339, ({$: "Nil"}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _pendingViews_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(340, ({$: "Tuple", "fst": __allocation_literal(341, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": __allocation_literal(342, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.WorldView", "namespace": _namespace_0, "next": _next_0, "rows": _rowViews_0, "pending": ($List$reverse$(_pendingViews_0)), "ledger": _value_0, "mode": _mode_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1264$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(343, ({$: "Tuple", "fst": __allocation_literal(344, ({$: "None"})), "snd": __allocation_literal(345, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands_head$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _value_0 = _head_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands_tail$(_owner_0, _value_0, _tail_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command$1260$(_owner_0) {
  if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _owner_0["id"];
    const _value_0 = _owner_0["bundle"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle$1260$(_value_0)));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _owner_0["id"];
    const _value_1 = _owner_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command_main$(_id_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_get$(_value_1)));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag") {
    const _id_2 = _owner_0["id"];
    const _value_2 = _owner_0["flag"];
    return __allocation_literal(346, ({$: "Tuple", "fst": __allocation_literal(347, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag", "id": _id_2, "flag": _value_2})), "snd": __allocation_literal(348, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.FlagView", "id": _id_2, "flag": _value_2}))}));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain") {
    const _id_3 = _owner_0["id"];
    return __allocation_literal(349, ({$: "Tuple", "fst": __allocation_literal(350, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain", "id": _id_3})), "snd": __allocation_literal(351, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveMainView", "id": _id_3}))}));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag") {
    const _id_4 = _owner_0["id"];
    return __allocation_literal(352, ({$: "Tuple", "fst": __allocation_literal(353, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag", "id": _id_4})), "snd": __allocation_literal(354, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveFlagView", "id": _id_4}))}));
  } else {
    const _id_5 = _owner_0["id"];
    return __allocation_literal(355, ({$: "Tuple", "fst": __allocation_literal(356, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Despawn", "id": _id_5})), "snd": __allocation_literal(357, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.DespawnView", "id": _id_5}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_go$1260$($0, $1, $2) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _state_0 = $2;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0);
      } else {
        const _remaining_1 = (_remaining_0 - 1);
        $0 = _remaining_1;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_advance$1260$(_id_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_canonical$1263$(_ledgerName_0, _stateName_0, _checked_0, _runtime_0) {
  if (_checked_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Unknown") {
    const _base_0 = _checked_0["base"];
    return run_clo(__allocation_literal(358, ((_x_0) => {
  const _x_1 = ($U32$show$(_base_0));
  return $IO$pure$(__allocation_literal(359, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": __allocation_literal(360, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SetupRejected", "reason": ("unregistered base:" + _x_1)}))})), _x_0);
})));
  } else {
    const _nodes_0 = _checked_0["nodes"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_presence$1263$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058health_presence$(_world_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_raw_bundle$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return __allocation_literal(361, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_raw_main$(_main_0)), "aux": _aux_0, "flag": _flag_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_main$(_raw_0) {
  if (_raw_0.$ === "None") {
    return __allocation_literal(362, ({$: "None"}));
  } else {
    const _raw_1 = _raw_0["value"];
    return __allocation_literal(363, ({$: "Some", "value": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_new$(_raw_1))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1263$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_get$(_raw_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$12613$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_row$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_tail$12614$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_pending$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1265$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(364, ({$: "Tuple", "fst": __allocation_literal(365, ({$: "None"})), "snd": __allocation_literal(366, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command$1261$(_owner_0) {
  if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _owner_0["id"];
    const _value_0 = _owner_0["bundle"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle$1261$(_value_0)));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _owner_0["id"];
    const _value_1 = _owner_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command_main$(_id_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_get$(_value_1)));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag") {
    const _id_2 = _owner_0["id"];
    const _value_2 = _owner_0["flag"];
    return __allocation_literal(367, ({$: "Tuple", "fst": __allocation_literal(368, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag", "id": _id_2, "flag": _value_2})), "snd": __allocation_literal(369, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.FlagView", "id": _id_2, "flag": _value_2}))}));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain") {
    const _id_3 = _owner_0["id"];
    return __allocation_literal(370, ({$: "Tuple", "fst": __allocation_literal(371, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain", "id": _id_3})), "snd": __allocation_literal(372, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveMainView", "id": _id_3}))}));
  } else if (_owner_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag") {
    const _id_4 = _owner_0["id"];
    return __allocation_literal(373, ({$: "Tuple", "fst": __allocation_literal(374, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag", "id": _id_4})), "snd": __allocation_literal(375, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveFlagView", "id": _id_4}))}));
  } else {
    const _id_5 = _owner_0["id"];
    return __allocation_literal(376, ({$: "Tuple", "fst": __allocation_literal(377, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Despawn", "id": _id_5})), "snd": __allocation_literal(378, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.DespawnView", "id": _id_5}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_go$1261$($0, $1, $2) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _state_0 = $2;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0);
      } else {
        const _remaining_1 = (_remaining_0 - 1);
        $0 = _remaining_1;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_advance$1261$(_id_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_presence$1262$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _ledger_0 = _t_0["ledger"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_audit$1262$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058audit_present$(_audit_0)));
}

function $measurement$045bend$058motion_presence$(_owner_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058motion_presence_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_presence$(_host_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_call$(_base_0, _mode_0, _found_0, _tail_0) {
  if (_found_0.$ === "None") {
    return __allocation_literal(379, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Unknown", "base": _base_0}));
  } else {
    const _system_0 = _found_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_cons$(__allocation_literal(380, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Call", "system": _system_0, "mode": _mode_0})), _tail_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058system_find$(_base_0, _systems_0) {
  if (_systems_0.$ === "Nil") {
    return __allocation_literal(381, ({$: "None"}));
  } else {
    const _t_0 = _systems_0["head"];
    const _key_0 = _t_0["base"];
    const _name_0 = _t_0["name"];
    const _kind_0 = _t_0["kind"];
    const _ledger_0 = _t_0["ledger"];
    const _audit_0 = _t_0["audit"];
    const _gated_0 = _t_0["gated"];
    const _reader_0 = _t_0["reader"];
    const _tail_0 = _systems_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058system_hit$((_base_0 === _key_0), __allocation_literal(382, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058system_find$(_base_0, _tail_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_nested$(_nested_0, _tail_0) {
  if (_nested_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Accepted") {
    const _nodes_0 = _nested_0["nodes"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_cons$(__allocation_literal(383, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Nested", "steps": _nodes_0})), _tail_0);
  } else {
    return _nested_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058canonical_cons$(_node_0, _tail_0) {
  if (_tail_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Accepted") {
    const _nodes_0 = _tail_0["nodes"];
    return __allocation_literal(384, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Accepted", "nodes": __allocation_literal(385, ({$: "Con", "head": _node_0, "tail": _nodes_0}))}));
  } else {
    return _tail_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058registry_join$(_system_0, _local_0, _tail_0) {
  const _entries_0 = _tail_0["fst"];
  const _systems_0 = _tail_0["snd"];
  return __allocation_literal(386, ({$: "Tuple", "fst": __allocation_literal(387, ({$: "Con", "head": __allocation_literal(388, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": _local_0})), "tail": _entries_0})), "snd": __allocation_literal(389, ({$: "Con", "head": _system_0, "tail": _systems_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_main$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(390, ({$: "None"}));
  } else {
    const _t_0 = _owner_0["value"];
    const _raw_0 = _t_0["raw"];
    return __allocation_literal(391, ({$: "Some", "value": _raw_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return __allocation_literal(392, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047identity$058reserve_checked$(_available_0, _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0) {
  if (!_available_0) {
    return __allocation_literal(393, ({$: "Tuple", "fst": __allocation_literal(394, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": __allocation_literal(395, ({$: "None"}))}));
  } else {
    return __allocation_literal(396, ({$: "Tuple", "fst": __allocation_literal(397, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": ((_next_0 + 1) >>> 0), "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": __allocation_literal(398, ({$: "Some", "value": __allocation_literal(399, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _next_0}))}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_new$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1260$(_raw_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init_done$(_result_0) {
  const _raw_0 = _result_0["fst"];
  const _cached_0 = _result_0["snd"];
  return __allocation_literal(400, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_get$(_owner_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_observed$(_epoch_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return __allocation_literal(401, ({$: "Con", "head": _value_0, "tail": _acc_0}));
  } else {
    return __allocation_literal(402, ({$: "Con", "head": _value_0, "tail": __allocation_literal(403, ({$: "Con", "head": ",", "tail": _acc_0}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_row$1260$(_value_0) {
  const _id_0 = _value_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(404, ({$: "Con", "head": "{\"id\":", "tail": __allocation_literal(405, ({$: "Con", "head": ($U32$show$(_id_0)), "tail": __allocation_literal(406, ({$: "Con", "head": ",\"main\":", "tail": __allocation_literal(407, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1263$(_main_0)), "tail": __allocation_literal(408, ({$: "Con", "head": ",\"aux\":", "tail": __allocation_literal(409, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1261$(_aux_0)), "tail": __allocation_literal(410, ({$: "Con", "head": ",\"flag\":", "tail": __allocation_literal(411, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1262$(_flag_0)), "tail": __allocation_literal(412, ({$: "Con", "head": ",\"added\":", "tail": __allocation_literal(413, ({$: "Con", "head": ($U32$show$(_added_0)), "tail": __allocation_literal(414, ({$: "Con", "head": ",\"changed\":", "tail": __allocation_literal(415, ({$: "Con", "head": ($U32$show$(_changed_0)), "tail": __allocation_literal(416, ({$: "Con", "head": "}", "tail": __allocation_literal(417, ({$: "Nil"}))}))}))}))}))}))}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_pending$1260$(_value_0) {
  if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.SpawnView") {
    const _id_0 = _value_0["id"];
    const _bundle_0 = _value_0["bundle"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(418, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(419, ({$: "Con", "head": "\"SpawnView\"", "tail": __allocation_literal(420, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(421, ({$: "Con", "head": ($U32$show$(_id_0)), "tail": __allocation_literal(422, ({$: "Con", "head": ",\"bundle\":", "tail": __allocation_literal(423, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_bundle$1260$(_bundle_0)), "tail": __allocation_literal(424, ({$: "Con", "head": "}", "tail": __allocation_literal(425, ({$: "Nil"}))}))}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.MainView") {
    const _id_1 = _value_0["id"];
    const _main_0 = _value_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(426, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(427, ({$: "Con", "head": "\"MainView\"", "tail": __allocation_literal(428, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(429, ({$: "Con", "head": ($U32$show$(_id_1)), "tail": __allocation_literal(430, ({$: "Con", "head": ",\"main\":", "tail": __allocation_literal(431, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_position$(_main_0)), "tail": __allocation_literal(432, ({$: "Con", "head": "}", "tail": __allocation_literal(433, ({$: "Nil"}))}))}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.FlagView") {
    const _id_2 = _value_0["id"];
    const _flag_0 = _value_0["flag"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(434, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(435, ({$: "Con", "head": "\"FlagView\"", "tail": __allocation_literal(436, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(437, ({$: "Con", "head": ($U32$show$(_id_2)), "tail": __allocation_literal(438, ({$: "Con", "head": ",\"flag\":", "tail": __allocation_literal(439, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_selected$(_flag_0)), "tail": __allocation_literal(440, ({$: "Con", "head": "}", "tail": __allocation_literal(441, ({$: "Nil"}))}))}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveMainView") {
    const _id_3 = _value_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(442, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(443, ({$: "Con", "head": "\"RemoveMainView\"", "tail": __allocation_literal(444, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(445, ({$: "Con", "head": ($U32$show$(_id_3)), "tail": __allocation_literal(446, ({$: "Con", "head": "}", "tail": __allocation_literal(447, ({$: "Nil"}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveFlagView") {
    const _id_4 = _value_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(448, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(449, ({$: "Con", "head": "\"RemoveFlagView\"", "tail": __allocation_literal(450, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(451, ({$: "Con", "head": ($U32$show$(_id_4)), "tail": __allocation_literal(452, ({$: "Con", "head": "}", "tail": __allocation_literal(453, ({$: "Nil"}))}))}))}))}))})));
  } else {
    const _id_5 = _value_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(454, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(455, ({$: "Con", "head": "\"DespawnView\"", "tail": __allocation_literal(456, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(457, ({$: "Con", "head": ($U32$show$(_id_5)), "tail": __allocation_literal(458, ({$: "Con", "head": "}", "tail": __allocation_literal(459, ({$: "Nil"}))}))}))}))}))})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(460, ({$: "Con", "head": "{\"a\":", "tail": __allocation_literal(461, ({$: "Con", "head": ($U32$show$(_a_0)), "tail": __allocation_literal(462, ({$: "Con", "head": ",\"b\":", "tail": __allocation_literal(463, ({$: "Con", "head": ($U32$show$(_b_0)), "tail": __allocation_literal(464, ({$: "Con", "head": ",\"c\":", "tail": __allocation_literal(465, ({$: "Con", "head": ($U32$show$(_c_0)), "tail": __allocation_literal(466, ({$: "Con", "head": ",\"d\":", "tail": __allocation_literal(467, ({$: "Con", "head": ($U32$show$(_d_0)), "tail": __allocation_literal(468, ({$: "Con", "head": "}", "tail": __allocation_literal(469, ({$: "Nil"}))}))}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(470, ({$: "Tuple", "fst": __allocation_literal(471, ({$: "Some", "value": _owner_0})), "snd": __allocation_literal(472, ({$: "Some", "value": _value_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_get$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058commands_tail$(_owner_0, _value_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(473, ({$: "Tuple", "fst": __allocation_literal(474, ({$: "Con", "head": _owner_0, "tail": _tail_0})), "snd": __allocation_literal(475, ({$: "Con", "head": _value_0, "tail": _values_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(476, ({$: "Tuple", "fst": __allocation_literal(477, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _owner_0})), "snd": __allocation_literal(478, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.SpawnView", "id": _id_0, "bundle": _value_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle$1260$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_main$1260$(_aux_0, _flag_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_main_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058command_main$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(479, ({$: "Tuple", "fst": __allocation_literal(480, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain", "id": _id_0, "main": _owner_0})), "snd": __allocation_literal(481, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.MainView", "id": _id_0, "main": _value_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_get$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return __allocation_literal(482, ({$: "Tuple", "fst": _owners_0, "snd": ($List$reverse$(_values_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_advance$1260$(_id_0, _state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_slot$1260$(_values_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_extract$(_owners_0, _id_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_presence$1263$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _ledger_0 = _t_0["ledger"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_audit$1263$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058audit_present$(_audit_0)));
}

function $measurement$045bend$058health_presence$(_owner_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058health_presence_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_presence$(_host_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047raw$045boundaries$058health_raw_main$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(483, ({$: "None"}));
  } else {
    const _t_0 = _owner_0["value"];
    const _raw_0 = _t_0["raw"];
    return __allocation_literal(484, ({$: "Some", "value": _raw_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_new$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1261$(_raw_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_get$(_owner_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_observed$(_epoch_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_row$1261$(_value_0) {
  const _id_0 = _value_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(485, ({$: "Con", "head": "{\"id\":", "tail": __allocation_literal(486, ({$: "Con", "head": ($U32$show$(_id_0)), "tail": __allocation_literal(487, ({$: "Con", "head": ",\"main\":", "tail": __allocation_literal(488, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1266$(_main_0)), "tail": __allocation_literal(489, ({$: "Con", "head": ",\"aux\":", "tail": __allocation_literal(490, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1264$(_aux_0)), "tail": __allocation_literal(491, ({$: "Con", "head": ",\"flag\":", "tail": __allocation_literal(492, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1265$(_flag_0)), "tail": __allocation_literal(493, ({$: "Con", "head": ",\"added\":", "tail": __allocation_literal(494, ({$: "Con", "head": ($U32$show$(_added_0)), "tail": __allocation_literal(495, ({$: "Con", "head": ",\"changed\":", "tail": __allocation_literal(496, ({$: "Con", "head": ($U32$show$(_changed_0)), "tail": __allocation_literal(497, ({$: "Con", "head": "}", "tail": __allocation_literal(498, ({$: "Nil"}))}))}))}))}))}))}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_pending$1261$(_value_0) {
  if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.SpawnView") {
    const _id_0 = _value_0["id"];
    const _bundle_0 = _value_0["bundle"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(499, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(500, ({$: "Con", "head": "\"SpawnView\"", "tail": __allocation_literal(501, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(502, ({$: "Con", "head": ($U32$show$(_id_0)), "tail": __allocation_literal(503, ({$: "Con", "head": ",\"bundle\":", "tail": __allocation_literal(504, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_bundle$1261$(_bundle_0)), "tail": __allocation_literal(505, ({$: "Con", "head": "}", "tail": __allocation_literal(506, ({$: "Nil"}))}))}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.MainView") {
    const _id_1 = _value_0["id"];
    const _main_0 = _value_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(507, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(508, ({$: "Con", "head": "\"MainView\"", "tail": __allocation_literal(509, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(510, ({$: "Con", "head": ($U32$show$(_id_1)), "tail": __allocation_literal(511, ({$: "Con", "head": ",\"main\":", "tail": __allocation_literal(512, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_vitals$(_main_0)), "tail": __allocation_literal(513, ({$: "Con", "head": "}", "tail": __allocation_literal(514, ({$: "Nil"}))}))}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.FlagView") {
    const _id_2 = _value_0["id"];
    const _flag_0 = _value_0["flag"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(515, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(516, ({$: "Con", "head": "\"FlagView\"", "tail": __allocation_literal(517, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(518, ({$: "Con", "head": ($U32$show$(_id_2)), "tail": __allocation_literal(519, ({$: "Con", "head": ",\"flag\":", "tail": __allocation_literal(520, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_tracked$(_flag_0)), "tail": __allocation_literal(521, ({$: "Con", "head": "}", "tail": __allocation_literal(522, ({$: "Nil"}))}))}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveMainView") {
    const _id_3 = _value_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(523, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(524, ({$: "Con", "head": "\"RemoveMainView\"", "tail": __allocation_literal(525, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(526, ({$: "Con", "head": ($U32$show$(_id_3)), "tail": __allocation_literal(527, ({$: "Con", "head": "}", "tail": __allocation_literal(528, ({$: "Nil"}))}))}))}))}))})));
  } else if (_value_0.$ === "../bendvy-query-live-first/experiments/s-integrate/observations.RemoveFlagView") {
    const _id_4 = _value_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(529, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(530, ({$: "Con", "head": "\"RemoveFlagView\"", "tail": __allocation_literal(531, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(532, ({$: "Con", "head": ($U32$show$(_id_4)), "tail": __allocation_literal(533, ({$: "Con", "head": "}", "tail": __allocation_literal(534, ({$: "Nil"}))}))}))}))}))})));
  } else {
    const _id_5 = _value_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(535, ({$: "Con", "head": "{\"kind\":", "tail": __allocation_literal(536, ({$: "Con", "head": "\"DespawnView\"", "tail": __allocation_literal(537, ({$: "Con", "head": ",\"id\":", "tail": __allocation_literal(538, ({$: "Con", "head": ($U32$show$(_id_5)), "tail": __allocation_literal(539, ({$: "Con", "head": "}", "tail": __allocation_literal(540, ({$: "Nil"}))}))}))}))}))})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_get$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle$1261$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_main$1261$(_aux_0, _flag_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1263$(_main_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_get$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_advance$1261$(_id_0, _state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_slot$1261$(_values_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_extract$(_owners_0, _id_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_audit$1262$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _service_0) {
  const _audit_0 = _service_0["fst"];
  const _available_0 = _service_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_missing$1262$(_nodes_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058preflight$(_nodes_0, _ledger_0, _available_0, true, _ledgerName_0, _stateName_0)), __allocation_literal(541, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058audit_present$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(542, ({$: "Tuple", "fst": __allocation_literal(543, ({$: "None"})), "snd": false}));
  } else {
    const _audit_0 = _owner_0["value"];
    return __allocation_literal(544, ({$: "Tuple", "fst": __allocation_literal(545, ({$: "Some", "value": _audit_0})), "snd": true}));
  }
}

function $measurement$045bend$058motion_presence_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return __allocation_literal(546, ({$: "Tuple", "fst": __allocation_literal(547, ({$: "measurement-bend.MotionBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0})), "snd": _view_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_presence$(_owner_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058ledger_presence$(_ledger_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058system_hit$(_equal_0, _system_0, _tail_0) {
  if (_equal_0) {
    return __allocation_literal(548, ({$: "Some", "value": _system_0}));
  } else {
    return _tail_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1260$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_get$(_raw_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_observed$(_epoch_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(549, ({$: "Tuple", "fst": __allocation_literal(550, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedger", "totals": _array_0, "epoch": _epoch_0})), "snd": __allocation_literal(551, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.LedgerView", "totals": _values_0, "epoch": _epoch_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_a$(__allocation_literal(552, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1263$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_position$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_velocity$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1262$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_selected$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_bundle$1260$(_value_0) {
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(553, ({$: "Con", "head": "{\"main\":", "tail": __allocation_literal(554, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1263$(_main_0)), "tail": __allocation_literal(555, ({$: "Con", "head": ",\"aux\":", "tail": __allocation_literal(556, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1261$(_aux_0)), "tail": __allocation_literal(557, ({$: "Con", "head": ",\"flag\":", "tail": __allocation_literal(558, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1262$(_flag_0)), "tail": __allocation_literal(559, ({$: "Con", "head": "}", "tail": __allocation_literal(560, ({$: "Nil"}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_position$(_value_0) {
  const _coordinates_0 = _value_0["coordinates"];
  const _frame_0 = _value_0["frame"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(561, ({$: "Con", "head": "{\"coordinates\":", "tail": __allocation_literal(562, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_four$(_coordinates_0)), "tail": __allocation_literal(563, ({$: "Con", "head": ",\"frame\":", "tail": __allocation_literal(564, ({$: "Con", "head": ($U32$show$(_frame_0)), "tail": __allocation_literal(565, ({$: "Con", "head": "}", "tail": __allocation_literal(566, ({$: "Nil"}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_selected$(_value_0) {
  const _group_0 = _value_0["group"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(567, ({$: "Con", "head": "{\"group\":", "tail": __allocation_literal(568, ({$: "Con", "head": ($U32$show$(_group_0)), "tail": __allocation_literal(569, ({$: "Con", "head": "}", "tail": __allocation_literal(570, ({$: "Nil"}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058get$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return __allocation_literal(571, ({$: "Tuple", "fst": __allocation_literal(572, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0})), "snd": _cached_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_main$1260$(_aux_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_aux_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(573, ({$: "Tuple", "fst": __allocation_literal(574, ({$: "None"})), "snd": __allocation_literal(575, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_slot$1260$(_values_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(576, ({$: "Tuple", "fst": _owners_0, "snd": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row$1260$(_owner_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, __allocation_literal(577, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_audit$1263$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _service_0) {
  const _audit_0 = _service_0["fst"];
  const _available_0 = _service_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_missing$1263$(_nodes_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058preflight$(_nodes_0, _ledger_0, _available_0, true, _ledgerName_0, _stateName_0)), __allocation_literal(578, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $measurement$045bend$058health_presence_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return __allocation_literal(579, ({$: "Tuple", "fst": __allocation_literal(580, ({$: "measurement-bend.HealthBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0})), "snd": _view_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_presence$(_owner_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058ledger_presence$(_ledger_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init$1261$(_raw_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_get$(_raw_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_observed$(_epoch_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(581, ({$: "Tuple", "fst": __allocation_literal(582, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedger", "totals": _array_0, "epoch": _epoch_0})), "snd": __allocation_literal(583, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.LedgerView", "totals": _values_0, "epoch": _epoch_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1266$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_vitals$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1264$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_armor$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1265$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_tracked$(_value_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_bundle$1261$(_value_0) {
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(584, ({$: "Con", "head": "{\"main\":", "tail": __allocation_literal(585, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1266$(_main_0)), "tail": __allocation_literal(586, ({$: "Con", "head": ",\"aux\":", "tail": __allocation_literal(587, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1264$(_aux_0)), "tail": __allocation_literal(588, ({$: "Con", "head": ",\"flag\":", "tail": __allocation_literal(589, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_optional$1265$(_flag_0)), "tail": __allocation_literal(590, ({$: "Con", "head": "}", "tail": __allocation_literal(591, ({$: "Nil"}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_vitals$(_value_0) {
  const _levels_0 = _value_0["levels"];
  const _reserve_0 = _value_0["reserve"];
  const _class_0 = _value_0["class"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(592, ({$: "Con", "head": "{\"levels\":", "tail": __allocation_literal(593, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_four$(_levels_0)), "tail": __allocation_literal(594, ({$: "Con", "head": ",\"reserve\":", "tail": __allocation_literal(595, ({$: "Con", "head": ($U32$show$(_reserve_0)), "tail": __allocation_literal(596, ({$: "Con", "head": ",\"class\":", "tail": __allocation_literal(597, ({$: "Con", "head": ($U32$show$(_class_0)), "tail": __allocation_literal(598, ({$: "Con", "head": "}", "tail": __allocation_literal(599, ({$: "Nil"}))}))}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_tracked$(_value_0) {
  const _group_0 = _value_0["group"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(600, ({$: "Con", "head": "{\"group\":", "tail": __allocation_literal(601, ({$: "Con", "head": ($U32$show$(_group_0)), "tail": __allocation_literal(602, ({$: "Con", "head": "}", "tail": __allocation_literal(603, ({$: "Nil"}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_main$1261$(_aux_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1262$(_aux_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1263$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(604, ({$: "Tuple", "fst": __allocation_literal(605, ({$: "None"})), "snd": __allocation_literal(606, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_slot$1261$(_values_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(607, ({$: "Tuple", "fst": _owners_0, "snd": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row$1261$(_owner_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_missing$1262$(_nodes_0, _missing_0, _runtime_0) {
  if (_missing_0.$ === "Nil") {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_frame$1262$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058motion_frame$(_world_0, _readers_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058frame$(_clock_0)))));
  } else {
    return run_clo(__allocation_literal(608, ((_x_0) => {
  return $IO$pure$(__allocation_literal(609, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": __allocation_literal(610, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.MissingRuntimeRequirements", "requirements": _missing_0}))})), _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058preflight$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _nodes_0 = $0;
      const _ledger_0 = $1;
      const _audit_0 = $2;
      const _state_0 = $3;
      const _ledgerName_0 = $4;
      const _stateName_0 = $5;
      if (_nodes_0.$ === "Nil") {
        return __allocation_literal(611, ({$: "Nil"}));
      } else {
        const _t_0 = _nodes_0["head"];
        if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Call") {
          const _system_0 = _t_0["system"];
          const _tail_0 = _nodes_0["tail"];
          return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058requirements$(_system_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058preflight$(_tail_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)));
        } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Nested") {
          const _nested_0 = _t_0["steps"];
          const _tail_1 = _nodes_0["tail"];
          return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058preflight$(_nested_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058preflight$(_tail_1, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)));
        } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Deferred") {
          const _tail_2 = _nodes_0["tail"];
          $0 = _tail_2;
          $1 = _ledger_0;
          $2 = _audit_0;
          $3 = _state_0;
          $4 = _ledgerName_0;
          $5 = _stateName_0;
          continue;
        } else {
          const _tail_3 = _nodes_0["tail"];
          $0 = _tail_3;
          $1 = _ledger_0;
          $2 = _audit_0;
          $3 = _state_0;
          $4 = _ledgerName_0;
          $5 = _stateName_0;
          continue;
        }
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _pair_0) {
  const _ledger_0 = _pair_0["fst"];
  const _available_0 = _pair_0["snd"];
  return __allocation_literal(612, ({$: "Tuple", "fst": __allocation_literal(613, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": __allocation_literal(614, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": __allocation_literal(615, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Presence", "ledger": _available_0, "modeOn": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_on$(_mode_0))}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058ledger_presence$(_ledger_0) {
  if (_ledger_0.$ === "None") {
    return __allocation_literal(616, ({$: "Tuple", "fst": __allocation_literal(617, ({$: "None"})), "snd": false}));
  } else {
    const _owner_0 = _ledger_0["value"];
    return __allocation_literal(618, ({$: "Tuple", "fst": __allocation_literal(619, ({$: "Some", "value": _owner_0})), "snd": true}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_get$(_owner_0) {
  const _array_0 = _owner_0["coordinates"];
  const _frame_0 = _owner_0["frame"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_observed$(_frame_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, __allocation_literal(620, ({$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_velocity$(_value_0) {
  const _rates_0 = _value_0["rates"];
  const _moving_0 = _value_0["moving"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(621, ({$: "Con", "head": "{\"rates\":", "tail": __allocation_literal(622, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_four$(_rates_0)), "tail": __allocation_literal(623, ({$: "Con", "head": ",\"moving\":", "tail": __allocation_literal(624, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_boolean$(_moving_0)), "tail": __allocation_literal(625, ({$: "Con", "head": "}", "tail": __allocation_literal(626, ({$: "Nil"}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return __allocation_literal(627, ({$: "Tuple", "fst": __allocation_literal(628, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Bundle", "main": _main_0, "aux": _aux_0, "flag": _flag_0})), "snd": __allocation_literal(629, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.BundleView", "main": _value_0, "aux": _auxView_0, "flag": _flag_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(630, ({$: "Tuple", "fst": __allocation_literal(631, ({$: "None"})), "snd": __allocation_literal(632, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058velocity_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(633, ({$: "Tuple", "fst": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_restore$(_owners_0, _owner_0)), "snd": __allocation_literal(634, ({$: "Con", "head": _value_0, "tail": _values_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row$1260$(_owner_0) {
  const _id_0 = _owner_0["id"];
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  const _added_0 = _owner_0["added"];
  const _changed_0 = _owner_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_main$1260$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_main_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return __allocation_literal(635, ({$: "Tuple", "fst": _rows_0, "snd": __allocation_literal(636, ({$: "None"}))}));
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_missing$1263$(_nodes_0, _missing_0, _runtime_0) {
  if (_missing_0.$ === "Nil") {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_frame$1263$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058health_frame$(_world_0, _readers_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058frame$(_clock_0)))));
  } else {
    return run_clo(__allocation_literal(637, ((_x_0) => {
  return $IO$pure$(__allocation_literal(638, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": __allocation_literal(639, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.MissingRuntimeRequirements", "requirements": _missing_0}))})), _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _pair_0) {
  const _ledger_0 = _pair_0["fst"];
  const _available_0 = _pair_0["snd"];
  return __allocation_literal(640, ({$: "Tuple", "fst": __allocation_literal(641, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": __allocation_literal(642, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": __allocation_literal(643, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Presence", "ledger": _available_0, "modeOn": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_on$(_mode_0))}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_get$(_owner_0) {
  const _array_0 = _owner_0["levels"];
  const _reserve_0 = _owner_0["reserve"];
  const _class_0 = _owner_0["class"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_observed$(_reserve_0, _class_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_armor$(_value_0) {
  const _layers_0 = _value_0["layers"];
  const _grade_0 = _value_0["grade"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_concat$(__allocation_literal(644, ({$: "Con", "head": "{\"layers\":", "tail": __allocation_literal(645, ({$: "Con", "head": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_four$(_layers_0)), "tail": __allocation_literal(646, ({$: "Con", "head": ",\"grade\":", "tail": __allocation_literal(647, ({$: "Con", "head": ($U32$show$(_grade_0)), "tail": __allocation_literal(648, ({$: "Con", "head": "}", "tail": __allocation_literal(649, ({$: "Nil"}))}))}))}))}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(650, ({$: "Tuple", "fst": __allocation_literal(651, ({$: "None"})), "snd": __allocation_literal(652, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058armor_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row$1261$(_owner_0) {
  const _id_0 = _owner_0["id"];
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  const _added_0 = _owner_0["added"];
  const _changed_0 = _owner_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_main$1261$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1263$(_main_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_frame$1262$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _readers_0 = _t_0["fst"];
  const _clock_0 = _t_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_nodes_0, __allocation_literal(653, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $measurement$045bend$058motion_frame$(_owner_0, _readers_0, _boundary_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058motion_frame_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058frame$(_host_0, _readers_0, _boundary_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058frame$(_clock_0) {
  const _now_0 = _clock_0["tick"];
  const _start_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058frame_case$((_start_0 > 0), _now_0, _start_0, _retained_0, _number_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union$(_values_0, _other_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union_acc$(_other_0, _values_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058requirements$(_system_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0) {
  const _needLedger_0 = _system_0["ledger"];
  const _needAudit_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058missing_case$(_needLedger_0, _ledger_0, __allocation_literal(654, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.ResourceRequired", "name": _ledgerName_0})))), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058missing_case$(_needAudit_0, _audit_0, __allocation_literal(655, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.ServiceRequired", "name": "Audit"})))))), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058missing_case$(_gated_0, _state_0, __allocation_literal(656, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.StateRequired", "name": _stateName_0})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_on$(_mode_0) {
  if (_mode_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.MotionOn") {
    return true;
  } else {
    return false;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_observed$(_frame_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(657, ({$: "Tuple", "fst": __allocation_literal(658, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Position", "coordinates": _array_0, "frame": _frame_0})), "snd": __allocation_literal(659, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionView", "coordinates": _values_0, "frame": _frame_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, __allocation_literal(660, ({$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$045render$058render_boolean$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058velocity_get$(_owner_0) {
  const _array_0 = _owner_0["rates"];
  const _moving_0 = _owner_0["moving"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058velocity_observed$(_moving_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return __allocation_literal(661, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), __allocation_literal(662, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})))), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_main$1260$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _value_0, _flag_0, _added_0, _changed_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_aux_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return __allocation_literal(663, ({$: "Tuple", "fst": __allocation_literal(664, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(665, ({$: "None"}))}));
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(666, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __allocation_literal(667, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1})), array_rmw(_main_0, _x_0, __allocation_literal(668, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, __allocation_literal(669, ({$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058tick_frame$1263$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _readers_0 = _t_0["fst"];
  const _clock_0 = _t_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_nodes_0, __allocation_literal(670, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $measurement$045bend$058health_frame$(_owner_0, _readers_0, _boundary_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058health_frame_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058frame$(_host_0, _readers_0, _boundary_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_on$(_mode_0) {
  if (_mode_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.HealthOn") {
    return true;
  } else {
    return false;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_observed$(_reserve_0, _class_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(671, ({$: "Tuple", "fst": __allocation_literal(672, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Vitals", "levels": _array_0, "reserve": _reserve_0, "class": _class_0})), "snd": __allocation_literal(673, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsView", "levels": _values_0, "reserve": _reserve_0, "class": _class_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058armor_get$(_owner_0) {
  const _array_0 = _owner_0["layers"];
  const _grade_0 = _owner_0["grade"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058armor_observed$(_grade_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_main$1261$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _value_0, _flag_0, _added_0, _changed_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058maybe_get$1262$(_aux_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_nodes_0, _runtime_0) {
  if (_nodes_0.$ === "Nil") {
    return run_clo(__allocation_literal(674, ((_x_0) => {
  return $IO$pure$(__allocation_literal(675, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": __allocation_literal(676, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"}))})), _x_0);
})));
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_0 = _nodes_0["tail"];
      return run_clo(__allocation_literal(677, ((_x_1) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_nested_0, _runtime_0)), run_clo(__allocation_literal(678, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058continue_case$(run_clo(__allocation_literal(679, ((_x_3) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_0, _x_3);
}))), _x_2);
}))), _x_1);
})));
    } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Call") {
      const _system_0 = _t_0["system"];
      const _mode_0 = _t_0["mode"];
      const _tail_1 = _nodes_0["tail"];
      return run_clo(__allocation_literal(680, ((_x_4) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call$1262$(_system_0, _mode_0, _runtime_0)), run_clo(__allocation_literal(681, ((_x_5) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058continue_case$(run_clo(__allocation_literal(682, ((_x_6) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_1, _x_6);
}))), _x_5);
}))), _x_4);
})));
    } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Deferred") {
      const _tail_2 = _nodes_0["tail"];
      return run_clo(__allocation_literal(683, ((_x_7) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058deferred$1262$(_runtime_0)), run_clo(__allocation_literal(684, ((_x_8) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_2, _x_8);
}))), _x_7);
})));
    } else {
      const _tail_3 = _nodes_0["tail"];
      return run_clo(__allocation_literal(685, ((_x_9) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058state_transition$1262$(_runtime_0)), run_clo(__allocation_literal(686, ((_x_10) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_3, _x_10);
}))), _x_9);
})));
    }
  }
}

function $measurement$045bend$058motion_frame_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _rest_0 = _pair_0["snd"];
  return __allocation_literal(687, ({$: "Tuple", "fst": __allocation_literal(688, ({$: "measurement-bend.MotionBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0})), "snd": _rest_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058frame$(_owner_0, _readers_0, _boundary_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058frame_return$(_world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame$(_logs_0, _readers_0, _boundary_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058frame_case$(_old_0, _now_0, _start_0, _retained_0, _number_0) {
  if (_old_0) {
    return __allocation_literal(689, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Frame", "clock": __allocation_literal(690, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Clock", "tick": _now_0, "frameStart": _now_0, "retainedAfter": _start_0, "frameNo": ((_number_0 + 1) >>> 0)})), "lifecycle": __allocation_literal(691, ({$: "Some", "value": _start_0})), "messages": _start_0}));
  } else {
    return __allocation_literal(692, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Frame", "clock": __allocation_literal(693, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Clock", "tick": _now_0, "frameStart": _now_0, "retainedAfter": _retained_0, "frameNo": ((_number_0 + 1) >>> 0)})), "lifecycle": __allocation_literal(694, ({$: "None"})), "messages": _retained_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058union_acc$($0, $1) {
  for (;;) {
    {
      const _other_0 = $0;
      const _values_0 = $1;
      if (_other_0.$ === "Nil") {
        return _values_0;
      } else {
        const _head_0 = _other_0["head"];
        const _tail_0 = _other_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058unique_case$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058contains$(_head_0, _values_0)), _head_0, _values_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058missing_case$(_wanted_0, _present_0, _value_0) {
  if (_wanted_0) {
    if (!_present_0) {
      return __allocation_literal(695, ({$: "Con", "head": _value_0, "tail": __allocation_literal(696, ({$: "Nil"}))}));
    } else {
      return __allocation_literal(697, ({$: "Nil"}));
    }
  } else {
    return __allocation_literal(698, ({$: "Nil"}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, __allocation_literal(699, ({$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058velocity_observed$(_moving_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(700, ({$: "Tuple", "fst": __allocation_literal(701, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Velocity", "rates": _array_0, "moving": _moving_0})), "snd": __allocation_literal(702, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VelocityView", "rates": _values_0, "moving": _moving_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four$(_array_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_a$(__allocation_literal(703, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return __allocation_literal(704, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _mainView_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return __allocation_literal(705, ({$: "Tuple", "fst": __allocation_literal(706, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0})), "snd": __allocation_literal(707, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.RowView", "id": _id_0, "main": _mainView_0, "aux": _auxView_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = __allocation_literal(708, ({$: "None"}));
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, __allocation_literal(709, (() => _x_1))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, __allocation_literal(710, ({$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_nodes_0, _runtime_0) {
  if (_nodes_0.$ === "Nil") {
    return run_clo(__allocation_literal(711, ((_x_0) => {
  return $IO$pure$(__allocation_literal(712, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": __allocation_literal(713, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"}))})), _x_0);
})));
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_0 = _nodes_0["tail"];
      return run_clo(__allocation_literal(714, ((_x_1) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_nested_0, _runtime_0)), run_clo(__allocation_literal(715, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058continue_case$(run_clo(__allocation_literal(716, ((_x_3) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_tail_0, _x_3);
}))), _x_2);
}))), _x_1);
})));
    } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Call") {
      const _system_0 = _t_0["system"];
      const _mode_0 = _t_0["mode"];
      const _tail_1 = _nodes_0["tail"];
      return run_clo(__allocation_literal(717, ((_x_4) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call$1263$(_system_0, _mode_0, _runtime_0)), run_clo(__allocation_literal(718, ((_x_5) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058continue_case$(run_clo(__allocation_literal(719, ((_x_6) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_tail_1, _x_6);
}))), _x_5);
}))), _x_4);
})));
    } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.Deferred") {
      const _tail_2 = _nodes_0["tail"];
      return run_clo(__allocation_literal(720, ((_x_7) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058deferred$1263$(_runtime_0)), run_clo(__allocation_literal(721, ((_x_8) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_tail_2, _x_8);
}))), _x_7);
})));
    } else {
      const _tail_3 = _nodes_0["tail"];
      return run_clo(__allocation_literal(722, ((_x_9) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058state_transition$1263$(_runtime_0)), run_clo(__allocation_literal(723, ((_x_10) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058run$1263$(_tail_3, _x_10);
}))), _x_9);
})));
    }
  }
}

function $measurement$045bend$058health_frame_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _rest_0 = _pair_0["snd"];
  return __allocation_literal(724, ({$: "Tuple", "fst": __allocation_literal(725, ({$: "measurement-bend.HealthBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0})), "snd": _rest_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058armor_observed$(_grade_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(726, ({$: "Tuple", "fst": __allocation_literal(727, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Armor", "layers": _array_0, "grade": _grade_0})), "snd": __allocation_literal(728, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ArmorView", "layers": _values_0, "grade": _grade_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058continue_case$(_continuation_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete") {
    return run_tail(_continuation_0, _runtime_0);
  } else {
    return run_clo(__allocation_literal(729, ((_x_0) => {
  return $IO$pure$(__allocation_literal(730, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": _t_0})), _x_0);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call$1262$(_system_0, _mode_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo(__allocation_literal(731, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_presence$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058motion_presence$(_world_0)))), run_clo(__allocation_literal(732, ((_x_1) => {
  return run_clo(__allocation_literal(733, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058record_mode$(_system_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058deferred$1262$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo(__allocation_literal(734, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_barrier$(_world_0, _clock_0)), run_clo(__allocation_literal(735, ((_x_1) => {
  return run_clo(__allocation_literal(736, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058state_transition$1262$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo(__allocation_literal(737, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_barrier$(_world_0, _clock_0)), run_clo(__allocation_literal(738, ((_x_1) => {
  return run_clo(__allocation_literal(739, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, __allocation_literal(740, ({$: "None"})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058transition_after$1262$(_nextMode_0, _x_1)))), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058frame_return$(_world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _result_0) {
  const _logs_0 = _result_0["logs"];
  const _readers_0 = _result_0["readers"];
  const _clock_0 = _result_0["clock"];
  return __allocation_literal(741, ({$: "Tuple", "fst": __allocation_literal(742, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": __allocation_literal(743, ({$: "Tuple", "fst": _readers_0, "snd": _clock_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame$(_logs_0, _readers_0, _frame_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  const _clock_0 = _frame_0["clock"];
  const _window_0 = _frame_0["lifecycle"];
  const _messageWindow_0 = _frame_0["messages"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame_ping$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _messageWindow_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058holders$(_readers_0, __allocation_literal(744, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Messages"})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058unique_case$(_found_0, _value_0, _values_0) {
  if (_found_0) {
    return _values_0;
  } else {
    return $List$append$(_values_0, __allocation_literal(745, ({$: "Con", "head": _value_0, "tail": __allocation_literal(746, ({$: "Nil"}))})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058contains$(_value_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058requirement_equal$(_value_0, _head_0));
    const _x_1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058contains$(_value_0, _tail_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return __allocation_literal(747, ({$: "Tuple", "fst": _array_0, "snd": __allocation_literal(748, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_b$(_a_0, __allocation_literal(749, ({$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, __allocation_literal(750, ({$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call$1263$(_system_0, _mode_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo(__allocation_literal(751, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_presence$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058health_presence$(_world_0)))), run_clo(__allocation_literal(752, ((_x_1) => {
  return run_clo(__allocation_literal(753, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058record_mode$(_system_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058deferred$1263$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo(__allocation_literal(754, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058health_barrier$(_world_0, _clock_0)), run_clo(__allocation_literal(755, ((_x_1) => {
  return run_clo(__allocation_literal(756, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058state_transition$1263$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo(__allocation_literal(757, ((_x_0) => {
  return $IO$bind$(($measurement$045bend$058health_barrier$(_world_0, _clock_0)), run_clo(__allocation_literal(758, ((_x_1) => {
  return run_clo(__allocation_literal(759, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, __allocation_literal(760, ({$: "None"})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058transition_after$1263$(_nextMode_0, _x_1)))), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_presence$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_actual$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058record_mode$(_system_0, _result_0) {
  const _kind_0 = _system_0["kind"];
  const _t_0 = _result_0["runtime"];
  const _world_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _t_1 = _result_0["outcome"];
  if (_t_1.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete") {
    return __allocation_literal(761, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": __allocation_literal(762, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058pending_kind$(_kind_0, _nextMode_0))})), "outcome": __allocation_literal(763, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"}))}));
  } else {
    return __allocation_literal(764, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": __allocation_literal(765, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})), "outcome": _t_1}));
  }
}

function $measurement$045bend$058motion_barrier$(_owner_0, _clock_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return run_clo(__allocation_literal(766, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058barrier$(_host_0, _clock_0)), run_clo(__allocation_literal(767, ((_x_1) => {
  return run_clo(__allocation_literal(768, ((_x_2) => {
  return $IO$pure$(($measurement$045bend$058motion_clock_return$(_sparse_0, _total_0, _calls_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return __allocation_literal(769, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058transition_after$1262$(_nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return $measurement$045bend$058motion_transition$(_world_0, _nextMode_0, _clock_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame_ping$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _messageWindow_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame_removed$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim$(_ping_0, _messageWindow_0, _holds_0)), _removed_0, _despawned_0, _clock_0, _window_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058holders$(_readers_0, __allocation_literal(770, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Removed", "component": 0})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058holders$(_readers_0, _kind_0) {
  const _slots_0 = _readers_0["slots"];
  return __allocation_literal(771, ({$: "Tuple", "fst": __allocation_literal(772, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Readers", "slots": _slots_0})), "snd": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058collect$(_kind_0, _slots_0))}));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return __allocation_literal(773, ({$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058requirement_equal$(_left_0, _right_0) {
  if (_left_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.ResourceRequired") {
    const _a_0 = _left_0["name"];
    if (_right_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.ResourceRequired") {
      const _b_0 = _right_0["name"];
      return $String$eq$(_a_0, _b_0);
    } else {
      return false;
    }
  } else if (_left_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.ServiceRequired") {
    const _a_1 = _left_0["name"];
    if (_right_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.ServiceRequired") {
      const _b_1 = _right_0["name"];
      return $String$eq$(_a_1, _b_1);
    } else {
      return false;
    }
  } else {
    const _a_2 = _left_0["name"];
    if (_right_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.StateRequired") {
      const _b_2 = _right_0["name"];
      return $String$eq$(_a_2, _b_2);
    } else {
      return false;
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_c$(_a_0, _b_0, __allocation_literal(774, ({$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return __allocation_literal(775, ({$: "Tuple", "fst": __allocation_literal(776, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(777, ({$: "Some", "value": __allocation_literal(778, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}))}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, __allocation_literal(779, ({$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_presence$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_actual$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0);
}

function $measurement$045bend$058health_barrier$(_owner_0, _clock_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return run_clo(__allocation_literal(780, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058barrier$(_host_0, _clock_0)), run_clo(__allocation_literal(781, ((_x_1) => {
  return run_clo(__allocation_literal(782, ((_x_2) => {
  return $IO$pure$(($measurement$045bend$058health_clock_return$(_sparse_0, _total_0, _calls_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058transition_after$1263$(_nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return $measurement$045bend$058health_transition$(_world_0, _nextMode_0, _clock_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_actual$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _on_0 = _actual_0["modeOn"];
  const _x_0 = ($Bool$not$(_gated_0));
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_condition$1262$((_x_0 || _on_0), __allocation_literal(783, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0})), _mode_0, __allocation_literal(784, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058pending_kind$(_kind_0, _previous_0) {
  if (_kind_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.SetOn") {
    return __allocation_literal(785, ({$: "Some", "value": true}));
  } else if (_kind_0.$ === "../bendvy-query-live-first/experiments/s-integrate/schedule.SetOff") {
    return __allocation_literal(786, ({$: "Some", "value": false}));
  } else {
    return _previous_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058barrier$(_owner_0, _clock_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  const _next_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058advance$(_clock_0));
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058barrier_applied$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _next_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058apply_checked$(_world_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_next_0)))));
}

function $measurement$045bend$058motion_clock_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _clock_0 = _pair_0["snd"];
  return __allocation_literal(787, ({$: "Tuple", "fst": __allocation_literal(788, ({$: "measurement-bend.MotionBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0})), "snd": _clock_0}));
}

function $measurement$045bend$058motion_transition$(_owner_0, _pending_0, _clock_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058motion_clock_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_transition$(_host_0, _pending_0, _clock_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame_removed$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame_despawned$(_ping_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058life_trim$(_removed_0, _window_0, _holds_0)), _despawned_0, _clock_0, _window_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058holders$(_readers_0, __allocation_literal(789, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Despawned"})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim$(_log_0, _window_0, _holders_0) {
  const _buffer_0 = _log_0["buffer"];
  return __allocation_literal(790, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.PingLog", "buffer": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_buffer$(_buffer_0, _window_0, _holders_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058collect$(_kind_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return __allocation_literal(791, ({$: "Nil"}));
  } else {
    const _t_0 = _slots_0["head"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058held$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058interested$(_kind_0, _interests_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058position$(_kind_0, _state_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058collect$(_kind_0, _tail_0)));
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_done$(_a_0, _b_0, _c_0, __allocation_literal(792, ({$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return __allocation_literal(793, ({$: "Tuple", "fst": __allocation_literal(794, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), "snd": __allocation_literal(795, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058call_actual$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _on_0 = _actual_0["modeOn"];
  const _x_0 = ($Bool$not$(_gated_0));
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_condition$1263$((_x_0 || _on_0), __allocation_literal(796, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0})), _mode_0, __allocation_literal(797, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})));
}

function $measurement$045bend$058health_clock_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _clock_0 = _pair_0["snd"];
  return __allocation_literal(798, ({$: "Tuple", "fst": __allocation_literal(799, ({$: "measurement-bend.HealthBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0})), "snd": _clock_0}));
}

function $measurement$045bend$058health_transition$(_owner_0, _pending_0, _clock_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058health_clock_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_transition$(_host_0, _pending_0, _clock_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_condition$1262$(_allowed_0, _system_0, _mode_0, _runtime_0) {
  if (!_allowed_0) {
    const _base_0 = _system_0["base"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return run_clo(__allocation_literal(800, ((_x_0) => {
  return $IO$pure$(__allocation_literal(801, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": __allocation_literal(802, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058skip$(_readers_0, _base_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)))), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})), "outcome": __allocation_literal(803, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"}))})), _x_0);
})));
  } else {
    const _base_1 = _system_0["base"];
    const _reader_0 = _system_0["reader"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_reader$1262$(_reader_0, _base_1, _mode_0, _runtime_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058advance$(_clock_0) {
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return __allocation_literal(804, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Clock", "tick": ((_now_0 + 1) >>> 0), "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058barrier_applied$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _clock_0, _result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/commands.Applied") {
    const _world_0 = _result_0["world"];
    const _changes_0 = _result_0["changes"];
    return run_clo(__allocation_literal(805, ((_x_0) => {
  return $IO$pure$(__allocation_literal(806, ({$: "Tuple", "fst": __allocation_literal(807, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": _world_0, "logs": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058append_changes$(_logs_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)), _changes_0)), "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": _clock_0})), _x_0);
})));
  } else if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/commands.CapacityRejected") {
    return run_clo(__allocation_literal(808, ((_x_1) => {
  return $IO$die$(20, "indexed capacity capability rejected", _x_1);
})));
  } else {
    return run_clo(__allocation_literal(809, ((_x_2) => {
  return $IO$die$(21, "indexed placement invariant failed", _x_2);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058apply_checked$(_world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight$(_pending_0, _rows_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_transition$(_owner_0, _pending_0, _clock_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _commands_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const __0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  if (_pending_0.$ === "None") {
    return __allocation_literal(810, ({$: "Tuple", "fst": __allocation_literal(811, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": __allocation_literal(812, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": __0})), "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": _clock_0}));
  } else {
    const _value_0 = _pending_0["value"];
    return __allocation_literal(813, ({$: "Tuple", "fst": __allocation_literal(814, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": __allocation_literal(815, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_desired$(_value_0))})), "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058advance$(_clock_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058frame_despawned$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return __allocation_literal(816, ({$: "../bendvy-query-live-first/experiments/s-integrate/reader-host.Framed", "logs": __allocation_literal(817, ({$: "../bendvy-query-live-first/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058life_trim$(_despawned_0, _window_0, _holds_0))})), "readers": _readers_0, "clock": _clock_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058life_trim$(_log_0, _window_0, _holds_0) {
  if (_window_0.$ === "None") {
    return _log_0;
  } else {
    const _tick_0 = _window_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_lifecycle$(_log_0, _tick_0, _holds_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_buffer$(_buffer_0, _window_0, _holders_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  const _oldest_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058boundary$(_holders_0, _window_0));
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_second$(_capacity_0, _oldest_0, _rear_0, run_loop($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_front$(_front_0, _capacity_0, _oldest_0, _size_0, _dropped_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058held$(_yes_0, _value_0, _tail_0) {
  if (_yes_0) {
    return __allocation_literal(818, ({$: "Con", "head": _value_0, "tail": _tail_0}));
  } else {
    return _tail_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058interested$(_kind_0, _interests_0) {
  if (_kind_0.$ === "../bendvy-query-live-first/experiments/s-integrate/readers.Messages") {
    const _yes_0 = _interests_0["messages"];
    return _yes_0;
  } else if (_kind_0.$ === "../bendvy-query-live-first/experiments/s-integrate/readers.Removed") {
    const _component_0 = _kind_0["component"];
    const _components_0 = _interests_0["removed"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058contains$(_component_0, _components_0);
  } else {
    const _yes_1 = _interests_0["despawned"];
    return _yes_1;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058position$(_kind_0, _state_0) {
  if (_kind_0.$ === "../bendvy-query-live-first/experiments/s-integrate/readers.Messages") {
    const _stream_0 = _state_0["streamLastRun"];
    return _stream_0;
  } else {
    const _last_0 = _state_0["lastRun"];
    return _last_0;
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return __allocation_literal(819, ({$: "Tuple", "fst": _array_0, "snd": __allocation_literal(820, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_condition$1263$(_allowed_0, _system_0, _mode_0, _runtime_0) {
  if (!_allowed_0) {
    const _base_0 = _system_0["base"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return run_clo(__allocation_literal(821, ((_x_0) => {
  return $IO$pure$(__allocation_literal(822, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": __allocation_literal(823, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058skip$(_readers_0, _base_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)))), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0})), "outcome": __allocation_literal(824, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"}))})), _x_0);
})));
  } else {
    const _base_1 = _system_0["base"];
    const _reader_0 = _system_0["reader"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_reader$1263$(_reader_0, _base_1, _mode_0, _runtime_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_transition$(_owner_0, _pending_0, _clock_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _commands_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const __0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  if (_pending_0.$ === "None") {
    return __allocation_literal(825, ({$: "Tuple", "fst": __allocation_literal(826, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": __allocation_literal(827, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": __0})), "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": _clock_0}));
  } else {
    const _value_0 = _pending_0["value"];
    return __allocation_literal(828, ({$: "Tuple", "fst": __allocation_literal(829, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": __allocation_literal(830, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_desired$(_value_0))})), "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "snd": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058advance$(_clock_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058skip$(_readers_0, _key_0, _now_0) {
  const _slots_0 = _readers_0["slots"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058skip_found$(_key_0, _now_0, _slots_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058find$(_key_0, _slots_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_reader$1262$(_reader_0, _base_0, _mode_0, _runtime_0) {
  if (_reader_0) {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_started$1262$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin$(_readers_0, _base_0, __allocation_literal(831, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Interests", "messages": true, "removed": __allocation_literal(832, ({$: "Con", "head": 0, "tail": __allocation_literal(833, ({$: "Nil"}))})), "despawned": true})), _clock_0)));
  } else {
    const _world_1 = _runtime_0["world"];
    const _registry_1 = _runtime_0["registry"];
    const _readers_1 = _runtime_0["readers"];
    const _clock_1 = _runtime_0["clock"];
    const _audit_1 = _runtime_0["audit"];
    const _style_1 = _runtime_0["style"];
    const _escaped_1 = _runtime_0["escaped"];
    const _observations_1 = _runtime_0["observations"];
    const _nextMode_1 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_unread$1262$(_base_0, _mode_0, _world_1, _registry_1, _readers_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058advance$(_clock_1)), _audit_1, _style_1, _escaped_1, _observations_1, _nextMode_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058append_changes$(_logs_0, _tick_0, _changes_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058append_all$(_changes_0, _tick_0, _logs_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, _result_0) {
  const _rows_0 = _result_0["rows"];
  const _pending_0 = _result_0["commands"];
  const _t_0 = _result_0["valid"];
  if (!_t_0) {
    return __allocation_literal(834, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.CapacityRejected", "world": __allocation_literal(835, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}))}));
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058batch$(($List$reverse$(_pending_0)), _namespace_0, _tick_0, __allocation_literal(836, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Running", "rows": _rows_0, "reverseChanges": __allocation_literal(837, ({$: "Nil"}))})))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight$(_commands_0, _rows_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight_go$(_commands_0, __allocation_literal(838, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Preflight", "rows": _rows_0, "commands": __allocation_literal(839, ({$: "Nil"})), "valid": true})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058motion_desired$(_value_0) {
  if (_value_0) {
    return __allocation_literal(840, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionOn"}));
  } else {
    return __allocation_literal(841, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionOff"}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_lifecycle$(_log_0, _window_0, _holders_0) {
  const _buffer_0 = _log_0["buffer"];
  return __allocation_literal(842, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.LifeLog", "buffer": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_buffer$(_buffer_0, _window_0, _holders_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058boundary$($0, $1) {
  for (;;) {
    {
      const _holders_0 = $0;
      const _window_0 = $1;
      if (_holders_0.$ === "Nil") {
        return _window_0;
      } else {
        const _head_0 = _holders_0["head"];
        const _tail_0 = _holders_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058minimum$(_window_0, _head_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_second$(_capacity_0, _window_0, _rear_0, _cut_0) {
  const _t_0 = _cut_0["front"];
  if (_t_0.$ === "Nil") {
    const _size_0 = _cut_0["size"];
    const _dropped_0 = _cut_0["dropped"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058finish_cut$(_capacity_0, run_loop($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_front$(($List$reverse$(_rear_0)), _capacity_0, _window_0, _size_0, _dropped_0)));
  } else {
    const _head_0 = _t_0["head"];
    const _tail_0 = _t_0["tail"];
    const _size_1 = _cut_0["size"];
    const _dropped_1 = _cut_0["dropped"];
    return __allocation_literal(843, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": _size_1, "dropped": _dropped_1, "front": __allocation_literal(844, ({$: "Con", "head": _head_0, "tail": _tail_0})), "rear": _rear_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_front$(_front_0, _capacity_0, _window_0, _size_0, _dropped_0) {
  if (_front_0.$ === "Nil") {
    return __allocation_literal(845, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Cut", "front": __allocation_literal(846, ({$: "Nil"})), "size": _size_0, "dropped": _dropped_0}));
  } else {
    const _t_0 = _front_0["head"];
    const _tick_0 = _t_0["tick"];
    const _n_0 = _t_0["count"];
    const _values_0 = _t_0["values"];
    const _tail_0 = _front_0["tail"];
    const _x_0 = (_tick_0 <= _window_0);
    const _x_1 = (_size_0 > _capacity_0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_decision$((_x_0 || _x_1), __allocation_literal(847, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Batch", "tick": _tick_0, "count": _n_0, "values": _values_0})), _tail_0, _size_0, _dropped_0, run_clo(__allocation_literal(848, ((_x_2) => {
  return run_clo(__allocation_literal(849, ((_x_3) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_front$(_tail_0, _capacity_0, _window_0, _x_2, _x_3);
})));
}))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058contains$(_key_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = (_key_0 === _head_0);
    const _x_1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058contains$(_key_0, _tail_0));
    return (_x_0 || _x_1);
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return __allocation_literal(850, ({$: "Tuple", "fst": __allocation_literal(851, ({$: "Tuple", "fst": "", "snd": ""})), "snd": __allocation_literal(852, ({$: "EQ"}))}));
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return __allocation_literal(853, ({$: "Tuple", "fst": __allocation_literal(854, ({$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)})), "snd": __allocation_literal(855, ({$: "LT"}))}));
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return __allocation_literal(856, ({$: "Tuple", "fst": __allocation_literal(857, ({$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""})), "snd": __allocation_literal(858, ({$: "GT"}))}));
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_reader$1263$(_reader_0, _base_0, _mode_0, _runtime_0) {
  if (_reader_0) {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_started$1263$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin$(_readers_0, _base_0, __allocation_literal(859, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Interests", "messages": true, "removed": __allocation_literal(860, ({$: "Con", "head": 0, "tail": __allocation_literal(861, ({$: "Nil"}))})), "despawned": true})), _clock_0)));
  } else {
    const _world_1 = _runtime_0["world"];
    const _registry_1 = _runtime_0["registry"];
    const _readers_1 = _runtime_0["readers"];
    const _clock_1 = _runtime_0["clock"];
    const _audit_1 = _runtime_0["audit"];
    const _style_1 = _runtime_0["style"];
    const _escaped_1 = _runtime_0["escaped"];
    const _observations_1 = _runtime_0["observations"];
    const _nextMode_1 = _runtime_0["nextMode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_unread$1263$(_base_0, _mode_0, _world_1, _registry_1, _readers_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058advance$(_clock_1)), _audit_1, _style_1, _escaped_1, _observations_1, _nextMode_1);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047host$058health_desired$(_value_0) {
  if (_value_0) {
    return __allocation_literal(862, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthOn"}));
  } else {
    return __allocation_literal(863, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthOff"}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058skip_found$(_key_0, _now_0, _slots_0, _found_0) {
  if (_found_0.$ === "None") {
    return __allocation_literal(864, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Readers", "slots": _slots_0}));
  } else {
    const _t_0 = _found_0["value"];
    const _interests_0 = _t_0["interests"];
    const _t_1 = _t_0["state"];
    const _registered_0 = _t_1["registeredAt"];
    const _last_0 = _t_1["lastRun"];
    return __allocation_literal(865, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Readers", "slots": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058replace$(_key_0, __allocation_literal(866, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Slot", "key": _key_0, "interests": _interests_0, "state": __allocation_literal(867, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReaderState", "registeredAt": _registered_0, "lastRun": _last_0, "streamLastRun": _now_0}))})), _slots_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058find$(_key_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return __allocation_literal(868, ({$: "None"}));
  } else {
    const _t_0 = _slots_0["head"];
    const _id_0 = _t_0["key"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058find_case$((_key_0 === _id_0), __allocation_literal(869, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Slot", "key": _id_0, "interests": _interests_0, "state": _state_0})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058find$(_key_0, _tail_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_started$1262$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _started_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _readers_0 = _started_0["readers"];
  const _clock_0 = _started_0["clock"];
  const _run_0 = _started_0["run"];
  return run_clo(__allocation_literal(870, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, __allocation_literal(871, ({$: "Some", "value": _run_0})))), run_clo(__allocation_literal(872, ((_x_1) => {
  return run_clo(__allocation_literal(873, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin$(_readers_0, _key_0, _interests_0, _clock_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin_clock$(_readers_0, _key_0, _interests_0, _clock_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_unread$1262$(_base_0, _mode_0, _world_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return run_clo(__allocation_literal(874, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, __allocation_literal(875, ({$: "None"})))), run_clo(__allocation_literal(876, ((_x_1) => {
  return run_clo(__allocation_literal(877, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058append_all$($0, $1, $2) {
  for (;;) {
    {
      const _changes_0 = $0;
      const _tick_0 = $1;
      const _logs_0 = $2;
      if (_changes_0.$ === "Nil") {
        return _logs_0;
      } else {
        const _head_0 = _changes_0["head"];
        const _tail_0 = _changes_0["tail"];
        $0 = _tail_0;
        $1 = _tick_0;
        $2 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058append_change$(_logs_0, _tick_0, _head_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/commands.Completed") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return __allocation_literal(878, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Applied", "world": __allocation_literal(879, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": __allocation_literal(880, ({$: "Nil"})), "ledger": _ledger_0, "mode": _mode_0})), "changes": _changes_0}));
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    const _remaining_0 = _result_0["remaining"];
    const _changes_1 = _result_0["changes"];
    return __allocation_literal(881, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.InvariantFault", "world": __allocation_literal(882, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_1, "pending": ($List$reverse$(_remaining_0)), "ledger": _ledger_0, "mode": _mode_0})), "row": _row_0, "changes": _changes_1}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058batch$($0, $1, $2, $3) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _namespace_0 = $1;
      const _tick_0 = $2;
      const _state_0 = $3;
      if (_commands_0.$ === "Nil") {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058state_finish$(_state_0);
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = _namespace_0;
        $2 = _tick_0;
        $3 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight_go$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        const _rows_0 = _state_0["rows"];
        const _reverse_0 = _state_0["commands"];
        const _valid_0 = _state_0["valid"];
        return __allocation_literal(883, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Preflight", "rows": _rows_0, "commands": ($List$reverse$(_reverse_0)), "valid": _valid_0}));
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        const _rows_1 = _state_0["rows"];
        const _reverse_1 = _state_0["commands"];
        const _valid_1 = _state_0["valid"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight_step$(_reverse_1, _valid_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058command_bound$(_rows_1, _command_0))));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058minimum$(_a_0, _b_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058choose_min$((_a_0 < _b_0), _a_0, _b_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058finish_cut$(_capacity_0, _cut_0) {
  const _front_0 = _cut_0["front"];
  const _size_0 = _cut_0["size"];
  const _dropped_0 = _cut_0["dropped"];
  return __allocation_literal(884, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": __allocation_literal(885, ({$: "Nil"}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058trim_decision$(_drop_0, _head_0, _tail_0, _size_0, _dropped_0, _ih_0) {
  if (!_drop_0) {
    return __allocation_literal(886, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Cut", "front": __allocation_literal(887, ({$: "Con", "head": _head_0, "tail": _tail_0})), "size": _size_0, "dropped": _dropped_0}));
  } else {
    const _tick_0 = _head_0["tick"];
    const _n_0 = _head_0["count"];
    return run_tail(_ih_0(((_size_0 - _n_0) >>> 0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058maximum$(_dropped_0, _tick_0)));
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return __allocation_literal(888, ({$: "Tuple", "fst": __allocation_literal(889, ({$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)})), "snd": __allocation_literal(890, ({$: "LT"}))}));
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return __allocation_literal(891, ({$: "Tuple", "fst": __allocation_literal(892, ({$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)})), "snd": __allocation_literal(893, ({$: "GT"}))}));
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return __allocation_literal(894, ({$: "Tuple", "fst": __allocation_literal(895, ({$: "Tuple", "fst": _a_0, "snd": _b_0})), "snd": cmp_new(_x_0, _x_1)}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_started$1263$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _started_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _readers_0 = _started_0["readers"];
  const _clock_0 = _started_0["clock"];
  const _run_0 = _started_0["run"];
  return run_clo(__allocation_literal(896, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1263$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, __allocation_literal(897, ({$: "Some", "value": _run_0})))), run_clo(__allocation_literal(898, ((_x_1) => {
  return run_clo(__allocation_literal(899, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_unread$1263$(_base_0, _mode_0, _world_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return run_clo(__allocation_literal(900, ((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1263$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, __allocation_literal(901, ({$: "None"})))), run_clo(__allocation_literal(902, ((_x_1) => {
  return run_clo(__allocation_literal(903, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058replace$(_key_0, _value_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return __allocation_literal(904, ({$: "Nil"}));
  } else {
    const _t_0 = _slots_0["head"];
    const _id_0 = _t_0["key"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058replace_case$((_key_0 === _id_0), __allocation_literal(905, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Slot", "key": _id_0, "interests": _interests_0, "state": _state_0})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058replace$(_key_0, _value_0, _tail_0)), _value_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058find_case$(_hit_0, _head_0, _rest_0) {
  if (_hit_0) {
    return __allocation_literal(906, ({$: "Some", "value": _head_0}));
  } else {
    return _rest_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_fuel_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, _run_0) {
  if (_fuel_0 === 0) {
    return run_clo(__allocation_literal(907, ((_x_0) => {
  return $IO$pure$(__allocation_literal(908, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": _entries_0, "outcome": __allocation_literal(909, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SetupRejected", "reason": "system-search bound"})), "clock": _clock_0, "escaped": __allocation_literal(910, ({$: "None"})), "observations": __allocation_literal(911, ({$: "Nil"}))})), _x_0);
})));
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_entries_0.$ === "Nil") {
      return run_clo(__allocation_literal(912, ((_x_1) => {
  return $IO$pure$(__allocation_literal(913, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": __allocation_literal(914, ({$: "Nil"})), "outcome": __allocation_literal(915, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SetupRejected", "reason": "unregistered base"})), "clock": _clock_0, "escaped": __allocation_literal(916, ({$: "None"})), "observations": __allocation_literal(917, ({$: "Nil"}))})), _x_1);
})));
    } else {
      const _t_0 = _entries_0["head"];
      const _t_1 = _t_0["system"];
      const _key_0 = _t_1["base"];
      const _name_0 = _t_1["name"];
      const _kind_0 = _t_1["kind"];
      const _ledger_0 = _t_1["ledger"];
      const _service_0 = _t_1["audit"];
      const _gated_0 = _t_1["gated"];
      const _reader_0 = _t_1["reader"];
      const _local_0 = _t_0["local"];
      const _tail_0 = _entries_0["tail"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_decide$1262$(run_clo(__allocation_literal(918, ((_x_2) => {
  return run_clo(__allocation_literal(919, ((_x_3) => {
  return run_clo(__allocation_literal(920, ((_x_4) => {
  return run_clo(__allocation_literal(921, ((_x_5) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_rest_0, _base_0, _mode_0, _clock_0, _style_0, _x_2, _x_3, _x_4, _x_5);
})));
})));
})));
}))), (_base_0 === _key_0), _base_0, _mode_0, _clock_0, _style_0, __allocation_literal(922, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0})), _local_0, _tail_0, _world_0, _audit_0, _run_0);
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _visit_0) {
  const _world_0 = _visit_0["world"];
  const _audit_0 = _visit_0["audit"];
  const _run_0 = _visit_0["run"];
  const _entries_0 = _visit_0["entries"];
  const _outcome_0 = _visit_0["outcome"];
  const _clock_0 = _visit_0["clock"];
  const _handle_0 = _visit_0["escaped"];
  const _seen_0 = _visit_0["observations"];
  return __allocation_literal(923, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Dispatched", "runtime": __allocation_literal(924, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": __allocation_literal(925, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Registry", "next": _next_0, "entries": _entries_0})), "readers": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058reader_finish$(_readers_0, _run_0, _outcome_0)), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058add_escape$(_escaped_0, _handle_0)), "observations": ($List$append$(_observations_0, _seen_0)), "nextMode": _nextMode_0})), "outcome": _outcome_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin_clock$(_readers_0, _key_0, _interests_0, _clock_0) {
  const _slots_0 = _readers_0["slots"];
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin_slot$(_key_0, _interests_0, _now_0, _slots_0, __allocation_literal(926, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Clock", "tick": _now_0, "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058find$(_key_0, _slots_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047reader$045host$058append_change$(_logs_0, _tick_0, _change_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  if (_change_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.MainRemoved") {
    const _handle_0 = _change_0["handle"];
    return __allocation_literal(927, ({$: "../bendvy-query-live-first/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_lifecycle$(_removed_0, _tick_0, __allocation_literal(928, ({$: "Con", "head": _handle_0, "tail": __allocation_literal(929, ({$: "Nil"}))})))), "despawned": _despawned_0}));
  } else if (_change_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Despawned") {
    const _handle_1 = _change_0["handle"];
    return __allocation_literal(930, ({$: "../bendvy-query-live-first/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_lifecycle$(_despawned_0, _tick_0, __allocation_literal(931, ({$: "Con", "head": _handle_1, "tail": __allocation_literal(932, ({$: "Nil"}))}))))}));
  } else {
    return __allocation_literal(933, ({$: "../bendvy-query-live-first/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": _despawned_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058state_finish$(_state_0) {
  if (_state_0.$ === "../bendvy-query-live-first/experiments/s-integrate/commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return __allocation_literal(934, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Completed", "rows": _rows_0, "changes": ($List$reverse$(_changes_0))}));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return __allocation_literal(935, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.BatchFault", "rows": _rows_1, "row": _row_0, "remaining": ($List$reverse$(_remaining_0)), "changes": _changes_1}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0) {
  if (_state_0.$ === "../bendvy-query-live-first/experiments/s-integrate/commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058state_step$(_changes_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0)));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return __allocation_literal(936, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": __allocation_literal(937, ({$: "Con", "head": _command_0, "tail": _remaining_0})), "changes": _changes_1}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058preflight_step$(_reverse_0, _valid_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _command_0 = _t_0["fst"];
  const _bounded_0 = _t_0["snd"];
  return __allocation_literal(938, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Preflight", "rows": _rows_0, "commands": __allocation_literal(939, ({$: "Con", "head": _command_0, "tail": _reverse_0})), "valid": ($Bool$and$(_valid_0, _bounded_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058command_bound$(_rows_0, _command_0) {
  if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058bounded_spawn$(_id_0, _bundle_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_can_place$(_rows_0, _id_0)));
  } else {
    return __allocation_literal(940, ({$: "Tuple", "fst": _rows_0, "snd": __allocation_literal(941, ({$: "Tuple", "fst": _command_0, "snd": true}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058choose_min$(_smaller_0, _a_0, _b_0) {
  if (_smaller_0) {
    return _a_0;
  } else {
    return _b_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058maximum$(_a_0, _b_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058choose_min$((_a_0 < _b_0), _b_0, _a_0);
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return __allocation_literal(942, ({$: "Tuple", "fst": __allocation_literal(943, ({$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)})), "snd": _r_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1263$(_fuel_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, _run_0) {
  if (_fuel_0 === 0) {
    return run_clo(__allocation_literal(944, ((_x_0) => {
  return $IO$pure$(__allocation_literal(945, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": _entries_0, "outcome": __allocation_literal(946, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SetupRejected", "reason": "system-search bound"})), "clock": _clock_0, "escaped": __allocation_literal(947, ({$: "None"})), "observations": __allocation_literal(948, ({$: "Nil"}))})), _x_0);
})));
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_entries_0.$ === "Nil") {
      return run_clo(__allocation_literal(949, ((_x_1) => {
  return $IO$pure$(__allocation_literal(950, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": __allocation_literal(951, ({$: "Nil"})), "outcome": __allocation_literal(952, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SetupRejected", "reason": "unregistered base"})), "clock": _clock_0, "escaped": __allocation_literal(953, ({$: "None"})), "observations": __allocation_literal(954, ({$: "Nil"}))})), _x_1);
})));
    } else {
      const _t_0 = _entries_0["head"];
      const _t_1 = _t_0["system"];
      const _key_0 = _t_1["base"];
      const _name_0 = _t_1["name"];
      const _kind_0 = _t_1["kind"];
      const _ledger_0 = _t_1["ledger"];
      const _service_0 = _t_1["audit"];
      const _gated_0 = _t_1["gated"];
      const _reader_0 = _t_1["reader"];
      const _local_0 = _t_0["local"];
      const _tail_0 = _entries_0["tail"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_decide$1263$(run_clo(__allocation_literal(955, ((_x_2) => {
  return run_clo(__allocation_literal(956, ((_x_3) => {
  return run_clo(__allocation_literal(957, ((_x_4) => {
  return run_clo(__allocation_literal(958, ((_x_5) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit$1263$(_rest_0, _base_0, _mode_0, _clock_0, _style_0, _x_2, _x_3, _x_4, _x_5);
})));
})));
})));
}))), (_base_0 === _key_0), _base_0, _mode_0, _clock_0, _style_0, __allocation_literal(959, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0})), _local_0, _tail_0, _world_0, _audit_0, _run_0);
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058replace_case$(_hit_0, _head_0, _tail_0, _value_0) {
  if (_hit_0) {
    return __allocation_literal(960, ({$: "Con", "head": _value_0, "tail": _tail_0}));
  } else {
    return __allocation_literal(961, ({$: "Con", "head": _head_0, "tail": _tail_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_decide$1262$(_ih_0, _hit_0, _base_0, _mode_0, _clock_0, _style_0, _system_0, _local_0, _tail_0, _world_0, _audit_0, _run_0) {
  if (_hit_0) {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, run_loop($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058invoke$(_style_0, _local_0)), run_clo(__allocation_literal(962, ((_x_0) => {
  return run_clo(__allocation_literal(963, ((_x_1) => {
  return run_clo(__allocation_literal(964, ((_x_2) => {
  return run_clo(__allocation_literal(965, ((_x_3) => {
  return run_clo(__allocation_literal(966, ((_x_4) => {
  return run_clo(__allocation_literal(967, ((_x_5) => {
  return run_clo(__allocation_literal(968, ((_x_6) => {
  return $measurement$045bend$058motion_invoke$(_x_0, _x_1, _x_2, _x_3, _x_4, _x_5, _x_6);
})));
})));
})));
})));
})));
})));
}))));
  } else {
    return run_clo(__allocation_literal(969, ((_x_7) => {
  return $IO$bind$(_ih_0(_tail_0)(_world_0)(_audit_0)(_run_0), run_clo(__allocation_literal(970, ((_x_8) => {
  return run_clo(__allocation_literal(971, ((_x_9) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_restore$(__allocation_literal(972, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": _local_0})), _x_8)), _x_9);
})));
}))), _x_7);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058reader_finish$(_readers_0, _run_0, _outcome_0) {
  if (_run_0.$ === "None") {
    return _readers_0;
  } else {
    const _run_1 = _run_0["value"];
    if (_outcome_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete") {
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_1, __allocation_literal(973, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Success"})));
    } else if (_outcome_0.$ === "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SystemFailure") {
      const _code_0 = _outcome_0["code"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_1, __allocation_literal(974, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Failure", "code": _code_0})));
    } else {
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_1, __allocation_literal(975, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Failure", "code": 7})));
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058add_escape$(_escaped_0, _handle_0) {
  if (_handle_0.$ === "None") {
    return _escaped_0;
  } else {
    const _h_0 = _handle_0["value"];
    return $List$append$(_escaped_0, __allocation_literal(976, ({$: "Con", "head": _h_0, "tail": __allocation_literal(977, ({$: "Nil"}))})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058begin_slot$(_key_0, _interests_0, _now_0, _slots_0, _clock_0, _found_0) {
  if (_found_0.$ === "None") {
    const _entry_0 = __allocation_literal(978, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Slot", "key": _key_0, "interests": _interests_0, "state": __allocation_literal(979, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReaderState", "registeredAt": _now_0, "lastRun": 0, "streamLastRun": 0}))}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058started$(_key_0, _interests_0, __allocation_literal(980, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReaderState", "registeredAt": _now_0, "lastRun": 0, "streamLastRun": 0})), __allocation_literal(981, ({$: "Con", "head": _entry_0, "tail": _slots_0})), _clock_0);
  } else {
    const _t_0 = _found_0["value"];
    const _saved_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058started$(_key_0, _saved_0, _state_0, _slots_0, _clock_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_lifecycle$(_log_0, _tick_0, _handles_0) {
  const _buffer_0 = _log_0["buffer"];
  return __allocation_literal(982, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.LifeLog", "buffer": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_units$(_handles_0, _tick_0, _buffer_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058state_step$(_reverseChanges_0, _result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return __allocation_literal(983, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Running", "rows": _rows_0, "reverseChanges": ($List$reverse$go$(_changes_0, _reverseChanges_0))}));
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return __allocation_literal(984, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": __allocation_literal(985, ({$: "Nil"})), "changes": ($List$reverse$(_reverseChanges_0))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0) {
  if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0);
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058main_effect$(_namespace_0, _id_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_replace_main$(_rows_0, _id_1, __allocation_literal(986, ({$: "Some", "value": _main_0})), _tick_0)));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain") {
    const _id_2 = _command_0["id"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058main_effect$(_namespace_0, _id_2, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_replace_main$(_rows_0, _id_2, __allocation_literal(987, ({$: "None"})), _tick_0)));
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058edit_target$(_namespace_0, _tick_0, _rows_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058targeted$(_command_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058bounded_spawn$(_id_0, _bundle_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _valid_0 = _result_0["snd"];
  return __allocation_literal(988, ({$: "Tuple", "fst": _rows_0, "snd": __allocation_literal(989, ({$: "Tuple", "fst": __allocation_literal(990, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _bundle_0})), "snd": _valid_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_can_place$(_rows_0, _id_0) {
  return __allocation_literal(991, ({$: "Tuple", "fst": _rows_0, "snd": ($Bool$and$((0 < _id_0), (_id_0 <= 131072)))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_decide$1263$(_ih_0, _hit_0, _base_0, _mode_0, _clock_0, _style_0, _system_0, _local_0, _tail_0, _world_0, _audit_0, _run_0) {
  if (_hit_0) {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, run_loop($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058invoke$(_style_0, _local_0)), run_clo(__allocation_literal(992, ((_x_0) => {
  return run_clo(__allocation_literal(993, ((_x_1) => {
  return run_clo(__allocation_literal(994, ((_x_2) => {
  return run_clo(__allocation_literal(995, ((_x_3) => {
  return run_clo(__allocation_literal(996, ((_x_4) => {
  return run_clo(__allocation_literal(997, ((_x_5) => {
  return run_clo(__allocation_literal(998, ((_x_6) => {
  return $measurement$045bend$058health_invoke$(_x_0, _x_1, _x_2, _x_3, _x_4, _x_5, _x_6);
})));
})));
})));
})));
})));
})));
}))));
  } else {
    return run_clo(__allocation_literal(999, ((_x_7) => {
  return $IO$bind$(_ih_0(_tail_0)(_world_0)(_audit_0)(_run_0), run_clo(__allocation_literal(1000, ((_x_8) => {
  return run_clo(__allocation_literal(1001, ((_x_9) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_restore$(__allocation_literal(1002, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": _local_0})), _x_8)), _x_9);
})));
}))), _x_7);
})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, _pair_0, _invoke_0) {
  const _local_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return run_clo(__allocation_literal(1003, ((_x_0) => {
  return $IO$bind$(_invoke_0(_system_0)(_mode_0)(_count_0)(_clock_0)(_world_0)(_audit_0)(_run_0), run_clo(__allocation_literal(1004, ((_x_1) => {
  return run_clo(__allocation_literal(1005, ((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_done$(_system_0, _local_0, _tail_0, _x_1)), _x_2);
})));
}))), _x_0);
})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058invoke$(_style_0, _local_0) {
  if (_style_0.$ === "../bendvy-query-live-first/experiments/s-integrate/capture.Returned") {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058increment$(_local_0);
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058call$(run_clo(__allocation_literal(1006, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058closure$(_local_0, _x_0);
}))));
  }
}

function $measurement$045bend$058motion_invoke$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  const _t_0 = _owner_0["host"];
  const _world_0 = _t_0["world"];
  const _logs_0 = _t_0["logs"];
  const _bindings_0 = _t_0["bindings"];
  const _name_0 = _t_0["worldName"];
  const _step_0 = _t_0["step"];
  const _prior_0 = _t_0["prior"];
  const _events_0 = _t_0["events"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  return $measurement$045bend$058motion_queried$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058motion_handles$(_world_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_restore$(_head_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _audit_0 = _result_0["audit"];
  const _run_0 = _result_0["run"];
  const _entries_0 = _result_0["entries"];
  const _outcome_0 = _result_0["outcome"];
  const _clock_0 = _result_0["clock"];
  const _escaped_0 = _result_0["escaped"];
  const _observations_0 = _result_0["observations"];
  return __allocation_literal(1007, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": __allocation_literal(1008, ({$: "Con", "head": _head_0, "tail": _entries_0})), "outcome": _outcome_0, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_0, _outcome_0) {
  if (_outcome_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Failure") {
    return _readers_0;
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058completed$(_readers_0, _run_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058started$(_key_0, _interests_0, _state_0, _slots_0, _clock_0) {
  const _at_0 = _state_0["registeredAt"];
  const _last_0 = _state_0["lastRun"];
  const _stream_0 = _state_0["streamLastRun"];
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  const _next_0 = ((_now_0 + 1) >>> 0);
  return __allocation_literal(1009, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Started", "readers": __allocation_literal(1010, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Readers", "slots": _slots_0})), "clock": __allocation_literal(1011, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Clock", "tick": _next_0, "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0})), "run": __allocation_literal(1012, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Run", "key": _key_0, "interests": _interests_0, "state": __allocation_literal(1013, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReaderState", "registeredAt": _at_0, "lastRun": _last_0, "streamLastRun": _stream_0})), "boundary": __allocation_literal(1014, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReadBoundary", "since": _last_0, "streamSince": _stream_0, "thisRun": _next_0}))}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_units$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _tick_0 = $1;
      const _buffer_0 = $2;
      if (_values_0.$ === "Nil") {
        return _buffer_0;
      } else {
        const _value_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = _tick_0;
        $2 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_buffer$(_buffer_0, _tick_0, __allocation_literal(1015, ({$: "Con", "head": _value_0, "tail": __allocation_literal(1016, ({$: "Nil"}))}))));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0) {
  const _t_0 = _bundle_0["main"];
  if (_t_0.$ === "None") {
    const _aux_0 = _bundle_0["aux"];
    const _flag_0 = _bundle_0["flag"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058placed$(__allocation_literal(1017, ({$: "Nil"})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_place$(_rows_0, __allocation_literal(1018, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": __allocation_literal(1019, ({$: "None"})), "aux": _aux_0, "flag": _flag_0, "added": 0, "changed": 0})))));
  } else {
    const _main_0 = _t_0["value"];
    const _aux_1 = _bundle_0["aux"];
    const _flag_1 = _bundle_0["flag"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058placed$(__allocation_literal(1020, ({$: "Con", "head": __allocation_literal(1021, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainAdded", "handle": __allocation_literal(1022, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))})), "tail": __allocation_literal(1023, ({$: "Con", "head": __allocation_literal(1024, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainChanged", "handle": __allocation_literal(1025, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))})), "tail": __allocation_literal(1026, ({$: "Nil"}))}))})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_place$(_rows_0, __allocation_literal(1027, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": __allocation_literal(1028, ({$: "Some", "value": _main_0})), "aux": _aux_1, "flag": _flag_1, "added": _tick_0, "changed": _tick_0})))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058main_effect$(_namespace_0, _id_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.AddedMain") {
    return __allocation_literal(1029, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": __allocation_literal(1030, ({$: "Con", "head": __allocation_literal(1031, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainAdded", "handle": __allocation_literal(1032, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))})), "tail": __allocation_literal(1033, ({$: "Con", "head": __allocation_literal(1034, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainChanged", "handle": __allocation_literal(1035, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))})), "tail": __allocation_literal(1036, ({$: "Nil"}))}))}))}));
  } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.ChangedMain") {
    return __allocation_literal(1037, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": __allocation_literal(1038, ({$: "Con", "head": __allocation_literal(1039, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainChanged", "handle": __allocation_literal(1040, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))})), "tail": __allocation_literal(1041, ({$: "Nil"}))}))}));
  } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemovedMain") {
    return __allocation_literal(1042, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": __allocation_literal(1043, ({$: "Con", "head": __allocation_literal(1044, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainRemoved", "handle": __allocation_literal(1045, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}))})), "tail": __allocation_literal(1046, ({$: "Nil"}))}))}));
  } else if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.MissingMainTarget") {
    return __allocation_literal(1047, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": __allocation_literal(1048, ({$: "Nil"}))}));
  } else {
    return __allocation_literal(1049, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": __allocation_literal(1050, ({$: "Nil"}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, __allocation_literal(1051, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), _replacement_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058edit_target$(_namespace_0, _tick_0, _rows_0, _result_0) {
  const _command_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058targeted$(_command_0) {
  if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return __allocation_literal(1052, ({$: "Tuple", "fst": __allocation_literal(1053, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _bundle_0})), "snd": _id_0}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return __allocation_literal(1054, ({$: "Tuple", "fst": __allocation_literal(1055, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain", "id": _id_1, "main": _main_0})), "snd": _id_1}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    return __allocation_literal(1056, ({$: "Tuple", "fst": __allocation_literal(1057, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag", "id": _id_2, "flag": _flag_0})), "snd": _id_2}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    return __allocation_literal(1058, ({$: "Tuple", "fst": __allocation_literal(1059, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain", "id": _id_3})), "snd": _id_3}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    return __allocation_literal(1060, ({$: "Tuple", "fst": __allocation_literal(1061, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag", "id": _id_4})), "snd": _id_4}));
  } else {
    const _id_5 = _command_0["id"];
    return __allocation_literal(1062, ({$: "Tuple", "fst": __allocation_literal(1063, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Despawn", "id": _id_5})), "snd": _id_5}));
  }
}

function $measurement$045bend$058health_invoke$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  const _t_0 = _owner_0["host"];
  const _world_0 = _t_0["world"];
  const _logs_0 = _t_0["logs"];
  const _bindings_0 = _t_0["bindings"];
  const _name_0 = _t_0["worldName"];
  const _step_0 = _t_0["step"];
  const _prior_0 = _t_0["prior"];
  const _events_0 = _t_0["events"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  return $measurement$045bend$058health_queried$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058health_handles$(_world_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058visit_done$(_system_0, _local_0, _tail_0, _result_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _world_0 = _result_0["world"];
  const _audit_0 = _result_0["audit"];
  const _run_0 = _result_0["run"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Success") {
    const _clock_0 = _result_0["clock"];
    const _escaped_0 = _result_0["escaped"];
    const _observations_0 = _result_0["observations"];
    return __allocation_literal(1064, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": __allocation_literal(1065, ({$: "Con", "head": __allocation_literal(1066, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Entry", "system": __allocation_literal(1067, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0})), "local": _local_0})), "tail": _tail_0})), "outcome": __allocation_literal(1068, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Complete"})), "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0}));
  } else {
    const _code_0 = _t_0["code"];
    const _clock_1 = _result_0["clock"];
    const _escaped_1 = _result_0["escaped"];
    const _observations_1 = _result_0["observations"];
    return __allocation_literal(1069, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": __allocation_literal(1070, ({$: "Con", "head": __allocation_literal(1071, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.Entry", "system": __allocation_literal(1072, ({$: "../bendvy-query-live-first/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0})), "local": _local_0})), "tail": _tail_0})), "outcome": __allocation_literal(1073, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.SystemFailure", "system": _name_0, "code": _code_0})), "clock": _clock_1, "escaped": _escaped_1, "observations": _observations_1}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058increment$(_local_0) {
  const _array_0 = _local_0["count"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058incremented$(__allocation_literal(1074, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058call$(_callback_0) {
  return run_tail(_callback_0, __allocation_literal(1075, ({$: "Unit"})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058closure$(_local_0, __0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058increment$(_local_0);
}

function $measurement$045bend$058motion_queried$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _handles_0 = _pair_0["snd"];
  return $measurement$045bend$058motion_updated$(_sparse_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058motion_rows$(_handles_0, __allocation_literal(1076, ({$: "measurement-bend.MotionRows", "owner": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_begin$(_world_0, __allocation_literal(1077, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": 0, "id": 0})))), "total": _total_0})))));
}

function $measurement$045bend$058motion_handles$(_world_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1262$(__allocation_literal(1078, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.Required"})), _world_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058completed$(_readers_0, _run_0) {
  const _slots_0 = _readers_0["slots"];
  const _key_0 = _run_0["key"];
  const _interests_0 = _run_0["interests"];
  const _t_0 = _run_0["state"];
  const _registered_0 = _t_0["registeredAt"];
  const _t_1 = _run_0["boundary"];
  const _thisRun_0 = _t_1["thisRun"];
  return __allocation_literal(1079, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Readers", "slots": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047readers$058replace$(_key_0, __allocation_literal(1080, ({$: "../bendvy-query-live-first/experiments/s-integrate/readers.Slot", "key": _key_0, "interests": _interests_0, "state": __allocation_literal(1081, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.ReaderState", "registeredAt": _registered_0, "lastRun": _thisRun_0, "streamLastRun": _thisRun_0}))})), _slots_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058append_buffer$(_buffer_0, _tick_0, _values_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  if (_values_0.$ === "Nil") {
    return __allocation_literal(1082, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": _rear_0}));
  } else {
    const _v_0 = _values_0["head"];
    const _vs_0 = _values_0["tail"];
    const _n_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058count$(__allocation_literal(1083, ({$: "Con", "head": _v_0, "tail": _vs_0})), 0));
    return __allocation_literal(1084, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": ((_size_0 + _n_0) >>> 0), "dropped": _dropped_0, "front": _front_0, "rear": __allocation_literal(1085, ({$: "Con", "head": __allocation_literal(1086, ({$: "../bendvy-query-live-first/experiments/s-integrate/streams.Batch", "tick": _tick_0, "count": _n_0, "values": __allocation_literal(1087, ({$: "Con", "head": _v_0, "tail": _vs_0}))})), "tail": _rear_0}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058placed$(_changes_0, _result_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return __allocation_literal(1088, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": _changes_0}));
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return __allocation_literal(1089, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.PlacementFault", "rows": _rows_1, "row": _row_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, __allocation_literal(1090, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return __allocation_literal(1091, ({$: "Tuple", "fst": _rows_0, "snd": __allocation_literal(1092, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MissingMainTarget"}))}));
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1093, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": __allocation_literal(1094, ({$: "Nil"}))}));
  } else {
    const _row_0 = _t_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058edited$(_rows_0, _id_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0)));
  }
}

function $measurement$045bend$058health_queried$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _handles_0 = _pair_0["snd"];
  return $measurement$045bend$058health_updated$(_sparse_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058health_rows$(_handles_0, __allocation_literal(1095, ({$: "measurement-bend.HealthRows", "owner": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_begin$(_world_0, __allocation_literal(1096, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": 0, "id": 0})))), "total": _total_0})))));
}

function $measurement$045bend$058health_handles$(_world_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1263$(__allocation_literal(1097, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.Required"})), _world_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047capture$058incremented$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ((_count_0 + 1) >>> 0);
  return __allocation_literal(1098, ({$: "Tuple", "fst": __allocation_literal(1099, ({$: "../bendvy-query-live-first/experiments/s-integrate/capture.Local", "count": (_array_0[0 % _array_0.length] = _x_0, _array_0)})), "snd": ((_count_0 + 1) >>> 0)}));
}

function $measurement$045bend$058motion_updated$(_sparse_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _total_0 = _result_0["total"];
  return $measurement$045bend$058motion_committed$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058motion_committed_queries$(_sparse_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_commit$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_finish_success$(_owner_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)))))));
}

function $measurement$045bend$058motion_rows$($0, $1) {
  for (;;) {
    {
      const _handles_0 = $0;
      const _state_0 = $1;
      if (_handles_0.$ === "Nil") {
        return _state_0;
      } else {
        const _handle_0 = _handles_0["head"];
        const _tail_0 = _handles_0["tail"];
        const _owner_0 = _state_0["owner"];
        const _total_0 = _state_0["total"];
        $0 = _tail_0;
        $1 = ($measurement$045bend$058motion_rows_next$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_row$1260$(($measurement$045bend$058motion_select$(_owner_0, _handle_0)))), _total_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_begin$(_world_0, _selected_0) {
  return __allocation_literal(1100, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": __allocation_literal(1101, ({$: "Nil"})), "commands": __allocation_literal(1102, ({$: "Nil"})), "pings": __allocation_literal(1103, ({$: "Nil"})), "marks": __allocation_literal(1104, ({$: "Nil"}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1262$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1262$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047streams$058count$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ((_acc_0 + 1) >>> 0);
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return __allocation_literal(1105, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rejected", "rows": _rows_0, "row": _row_0}));
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_grown$(run_loop($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow$(17, _id_0, _rows_0)), __allocation_literal(1106, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058edited$(_rows_0, _id_0, _result_0) {
  const _t_0 = _result_0["row"];
  if (_t_0.$ === "Some") {
    const _row_0 = _t_0["value"];
    const _changes_0 = _result_0["changes"];
    return __allocation_literal(1107, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_restore$(_rows_0, _row_0)), "changes": _changes_0}));
  } else {
    const _changes_1 = _result_0["changes"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058removed$(_changes_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_remove$(_rows_0, _id_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0) {
  if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertFlag") {
    const _flag_0 = _command_0["flag"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return __allocation_literal(1108, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1109, ({$: "Some", "value": __allocation_literal(1110, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": __allocation_literal(1111, ({$: "Some", "value": _flag_0})), "added": _added_0, "changed": _changed_0}))})), "changes": __allocation_literal(1112, ({$: "Nil"}))}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveFlag") {
    const _id_1 = _row_0["id"];
    const _main_1 = _row_0["main"];
    const _aux_1 = _row_0["aux"];
    const _added_1 = _row_0["added"];
    const _changed_1 = _row_0["changed"];
    return __allocation_literal(1113, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1114, ({$: "Some", "value": __allocation_literal(1115, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_1, "main": _main_1, "aux": _aux_1, "flag": __allocation_literal(1116, ({$: "None"})), "added": _added_1, "changed": _changed_1}))})), "changes": __allocation_literal(1117, ({$: "Nil"}))}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.InsertMain") {
    return __allocation_literal(1118, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1119, ({$: "Some", "value": _row_0})), "changes": __allocation_literal(1120, ({$: "Nil"}))}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.RemoveMain") {
    return __allocation_literal(1121, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1122, ({$: "Some", "value": _row_0})), "changes": __allocation_literal(1123, ({$: "Nil"}))}));
  } else if (_command_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Despawn") {
    const _id_2 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "Some") {
      return __allocation_literal(1124, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1125, ({$: "None"})), "changes": __allocation_literal(1126, ({$: "Con", "head": __allocation_literal(1127, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MainRemoved", "handle": __allocation_literal(1128, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_2}))})), "tail": __allocation_literal(1129, ({$: "Con", "head": __allocation_literal(1130, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Despawned", "handle": __allocation_literal(1131, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_2}))})), "tail": __allocation_literal(1132, ({$: "Nil"}))}))}))}));
    } else {
      return __allocation_literal(1133, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1134, ({$: "None"})), "changes": __allocation_literal(1135, ({$: "Con", "head": __allocation_literal(1136, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Despawned", "handle": __allocation_literal(1137, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_2}))})), "tail": __allocation_literal(1138, ({$: "Nil"}))}))}));
    }
  } else {
    return __allocation_literal(1139, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.RowEdit", "row": __allocation_literal(1140, ({$: "Some", "value": _row_0})), "changes": __allocation_literal(1141, ({$: "Nil"}))}));
  }
}

function $measurement$045bend$058health_updated$(_sparse_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _total_0 = _result_0["total"];
  return $measurement$045bend$058health_committed$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058health_committed_queries$(_sparse_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_commit$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_finish_success$(_owner_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)))))));
}

function $measurement$045bend$058health_rows$($0, $1) {
  for (;;) {
    {
      const _handles_0 = $0;
      const _state_0 = $1;
      if (_handles_0.$ === "Nil") {
        return _state_0;
      } else {
        const _handle_0 = _handles_0["head"];
        const _tail_0 = _handles_0["tail"];
        const _owner_0 = _state_0["owner"];
        const _total_0 = _state_0["total"];
        $0 = _tail_0;
        $1 = ($measurement$045bend$058health_rows_next$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_row$1260$(($measurement$045bend$058health_select$(_owner_0, _handle_0)))), _total_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1263$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1263$(_rows_0, _selection_0, _namespace_0)));
}

function $measurement$045bend$058motion_committed$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _querysum_0 = _pair_0["snd"];
  return run_clo(__allocation_literal(1142, ((_x_0) => {
  return $IO$pure$(__allocation_literal(1143, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Invoked", "world": __allocation_literal(1144, ({$: "measurement-bend.MotionBench", "host": __allocation_literal(1145, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _name_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "sparse": _sparse_0, "readsum": ((_total_0 + _querysum_0) >>> 0), "calls": _count_0})), "audit": _audit_0, "run": _run_0, "outcome": __allocation_literal(1146, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Success"})), "clock": _clock_0, "escaped": __allocation_literal(1147, ({$: "None"})), "observations": __allocation_literal(1148, ({$: "Nil"}))})), _x_0);
})));
}

function $measurement$045bend$058motion_committed_queries$(_sparse_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  return $measurement$045bend$058motion_queries$(_sparse_0, _world_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_commit$(_result_0, _tick_0) {
  if (_result_0.$ === "../bendvy-query-live-first/experiments/s-integrate/transaction.Committed") {
    const _world_0 = _result_0["world"];
    const _commands_0 = _result_0["commands"];
    const _pings_0 = _result_0["pings"];
    const _marks_0 = _result_0["marks"];
    return __allocation_literal(1149, ({$: "Tuple", "fst": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058publish$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_mark_all$(_marks_0, _world_0, _tick_0)), ($List$reverse$(_commands_0)))), "snd": _pings_0}));
  } else {
    const _world_1 = _result_0["world"];
    return __allocation_literal(1150, ({$: "Tuple", "fst": _world_1, "snd": __allocation_literal(1151, ({$: "Nil"}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_finish_success$(_t_0) {
  const _world_0 = _t_0["world"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return __allocation_literal(1152, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Committed", "world": _world_0, "commands": ($List$reverse$(_commands_0)), "pings": ($List$reverse$(_pings_0)), "marks": _marks_0}));
}

function $measurement$045bend$058motion_rows_next$(_result_0, _total_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(1153, ({$: "measurement-bend.MotionRows", "owner": _owner_0, "total": ((_total_0 + _value_0) >>> 0)}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_row$1260$(_owner_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _t_1 = _owner_0["selected"];
  const _space_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_fields_checked$1260$((_ns_0 === _space_0), _ns_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0, _space_0, _id_0, _undo_0, _commands_0, _pings_0, _marks_0);
}

function $measurement$045bend$058motion_select$(_owner_0, _handle_0) {
  const _world_0 = _owner_0["world"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return __allocation_literal(1154, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return __allocation_literal(1155, ({$: "Tuple", "fst": __allocation_literal(1156, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": _observations_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1262$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1262$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, __allocation_literal(1157, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(1158, ({$: "Nil"}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), __allocation_literal(1159, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), __allocation_literal(1160, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), __allocation_literal(1161, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), run_clo(__allocation_literal(1162, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow$(_n_0, _id_0, _x_0);
}))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return __allocation_literal(1163, ({$: "Tuple", "fst": __allocation_literal(1164, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1165, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MissingMainTarget"}))}));
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047commands$058removed$(_changes_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  return __allocation_literal(1166, ({$: "../bendvy-query-live-first/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": _changes_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_remove$(_rows_0, _id_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058remove_done$(_id_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0)));
}

function $measurement$045bend$058health_committed$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _querysum_0 = _pair_0["snd"];
  return run_clo(__allocation_literal(1167, ((_x_0) => {
  return $IO$pure$(__allocation_literal(1168, ({$: "../bendvy-query-live-first/experiments/s-integrate/dispatcher.Invoked", "world": __allocation_literal(1169, ({$: "measurement-bend.HealthBench", "host": __allocation_literal(1170, ({$: "../bendvy-query-live-first/experiments/s-integrate/host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _name_0, "step": _step_0, "prior": _prior_0, "events": _events_0})), "sparse": _sparse_0, "readsum": ((_total_0 + _querysum_0) >>> 0), "calls": _count_0})), "audit": _audit_0, "run": _run_0, "outcome": __allocation_literal(1171, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Success"})), "clock": _clock_0, "escaped": __allocation_literal(1172, ({$: "None"})), "observations": __allocation_literal(1173, ({$: "Nil"}))})), _x_0);
})));
}

function $measurement$045bend$058health_committed_queries$(_sparse_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  return $measurement$045bend$058health_queries$(_sparse_0, _world_0);
}

function $measurement$045bend$058health_rows_next$(_result_0, _total_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(1174, ({$: "measurement-bend.HealthRows", "owner": _owner_0, "total": ((_total_0 + _value_0) >>> 0)}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_row$1260$(_owner_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _t_1 = _owner_0["selected"];
  const _space_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_fields_checked$1260$((_ns_0 === _space_0), _ns_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0, _space_0, _id_0, _undo_0, _commands_0, _pings_0, _marks_0);
}

function $measurement$045bend$058health_select$(_owner_0, _handle_0) {
  const _world_0 = _owner_0["world"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return __allocation_literal(1175, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1263$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1263$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, __allocation_literal(1176, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(1177, ({$: "Nil"}))})));
}

function $measurement$045bend$058motion_queries$(_sparse_0, _world_0) {
  if (!_sparse_0) {
    return __allocation_literal(1178, ({$: "Tuple", "fst": _world_0, "snd": 0}));
  } else {
    return $measurement$045bend$058motion_query1$(($measurement$045bend$058motion_views$(_world_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_mark_all$(_marks_0, _world_0, _tick_0) {
  if (_marks_0.$ === "Nil") {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _t_1 = _t_0["metadata"];
    const _live_0 = _t_1["live"];
    const _flags_0 = _t_1["flags"];
    const _added_0 = _t_1["added"];
    const _changed_0 = _t_1["changed"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return __allocation_literal(1179, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": __allocation_literal(1180, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": __allocation_literal(1181, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}));
  } else {
    const _namespace_1 = _world_0["namespace"];
    const _next_1 = _world_0["next"];
    const _t_2 = _world_0["rows"];
    const _main_1 = _t_2["main"];
    const _aux_1 = _t_2["aux"];
    const _t_3 = _t_2["metadata"];
    const _live_1 = _t_3["live"];
    const _flags_1 = _t_3["flags"];
    const _added_1 = _t_3["added"];
    const _changed_1 = _t_3["changed"];
    const _capacity_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _high_1 = _t_2["high_water"];
    const _pending_1 = _world_0["pending"];
    const _ledger_1 = _world_0["ledger"];
    const _mode_1 = _world_0["mode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_loop$(_marks_0, _namespace_1, _next_1, _main_1, _aux_1, _flags_1, _added_1, __allocation_literal(1182, ({$: "Tuple", "fst": _live_1, "snd": _changed_1})), _capacity_1, _depth_1, _high_1, _pending_1, _ledger_1, _mode_1, _tick_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_fields_checked$1260$(_valid_0, _ns_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0, _space_0, _id_0, _undo_0, _commands_0, _pings_0, _marks_0) {
  if (_valid_0) {
    if (_ledger_0.$ === "Some") {
      const _ledger_1 = _ledger_0["value"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_taken$1260$(_ns_0, _next_0, _pending_0, _ledger_1, _mode_0, __allocation_literal(1183, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), _undo_0, _commands_0, _pings_0, _marks_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_rows$(_rows_0, _id_0)));
    } else {
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1261$(__allocation_literal(1184, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1185, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "selected": __allocation_literal(1186, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})));
    }
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1261$(__allocation_literal(1187, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1188, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "selected": __allocation_literal(1189, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1262$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return __allocation_literal(1190, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rejected", "rows": _rows_0, "row": _row_0}));
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, __allocation_literal(1191, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0})), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, __allocation_literal(1192, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": array_node(_m_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0))), "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1193, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, __allocation_literal(1194, (() => _x_1))));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = __allocation_literal(1195, ({$: "Some", "value": _value_0}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, __allocation_literal(1196, (() => _x_3))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return __allocation_literal(1197, ({$: "Tuple", "fst": __allocation_literal(1198, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), "snd": __allocation_literal(1199, ({$: "None"}))}));
  } else {
    const _row_0 = _t_1["value"];
    return __allocation_literal(1200, ({$: "Tuple", "fst": __allocation_literal(1201, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), __allocation_literal(1202, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": false, "flag": __allocation_literal(1203, ({$: "None"})), "added": 0, "changed": 0})))), "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), "snd": __allocation_literal(1204, ({$: "Some", "value": _row_0}))}));
  }
}

function $measurement$045bend$058health_queries$(_sparse_0, _world_0) {
  if (!_sparse_0) {
    return __allocation_literal(1205, ({$: "Tuple", "fst": _world_0, "snd": 0}));
  } else {
    return $measurement$045bend$058health_query1$(($measurement$045bend$058health_views$(_world_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_fields_checked$1260$(_valid_0, _ns_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0, _space_0, _id_0, _undo_0, _commands_0, _pings_0, _marks_0) {
  if (_valid_0) {
    if (_ledger_0.$ === "Some") {
      const _ledger_1 = _ledger_0["value"];
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_taken$1260$(_ns_0, _next_0, _pending_0, _ledger_1, _mode_0, __allocation_literal(1206, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), _undo_0, _commands_0, _pings_0, _marks_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_rows$(_rows_0, _id_0)));
    } else {
      return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body$1261$(__allocation_literal(1207, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1208, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "selected": __allocation_literal(1209, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})));
    }
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body$1261$(__allocation_literal(1210, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1211, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "selected": __allocation_literal(1212, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1263$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $measurement$045bend$058motion_query1$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $measurement$045bend$058motion_query2$(run_loop($measurement$045bend$058motion_sum_go$(_values_0, 0, 1, 0)), ($measurement$045bend$058motion_views$(_world_0)));
}

function $measurement$045bend$058motion_views$(_world_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1260$(__allocation_literal(1213, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.Optional"})), _world_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_loop$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) {
  for (;;) {
    {
      const _marks_0 = $0;
      const _namespace_0 = $1;
      const _next_0 = $2;
      const _main_0 = $3;
      const _aux_0 = $4;
      const _flags_0 = $5;
      const _added_0 = $6;
      const _transport_0 = $7;
      const _capacity_0 = $8;
      const _depth_0 = $9;
      const _high_0 = $10;
      const _pending_0 = $11;
      const _ledger_0 = $12;
      const _mode_0 = $13;
      const _tick_0 = $14;
      if (_marks_0.$ === "Nil") {
        const _live_0 = _transport_0["fst"];
        const _changed_0 = _transport_0["snd"];
        return __allocation_literal(1214, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": __allocation_literal(1215, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": __allocation_literal(1216, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}));
      } else {
        const _t_0 = _marks_0["head"];
        const _foreign_0 = _t_0["namespace"];
        const _id_0 = _t_0["id"];
        const _rest_0 = _marks_0["tail"];
        const _live_1 = _transport_0["fst"];
        const _changed_1 = _transport_0["snd"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = _next_0;
        $3 = _main_0;
        $4 = _aux_0;
        $5 = _flags_0;
        $6 = _added_0;
        $7 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _live_1, _changed_1, _id_0, _tick_0));
        $8 = _capacity_0;
        $9 = _depth_0;
        $10 = _high_0;
        $11 = _pending_0;
        $12 = _ledger_0;
        $13 = _mode_0;
        $14 = _tick_0;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_taken$1260$(_ns_0, _next_0, _pending_0, _ledger_0, _mode_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _pair_0) {
  const _rows_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Taken") {
    const _main_0 = _t_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_invoke$1260$(__allocation_literal(1217, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": __allocation_literal(1218, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": __allocation_literal(1219, ({$: "None"})), "mode": _mode_0})), "main": _main_0, "ledger": _ledger_0, "handle": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))));
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1261$(__allocation_literal(1220, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1221, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": __allocation_literal(1222, ({$: "Some", "value": _ledger_0})), "mode": _mode_0})), "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_rows$(_rows_0, _target_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_checked$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), _target_0, __allocation_literal(1223, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1261$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1261$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_main$(_owner_0, __allocation_literal(1224, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionToken"})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, __allocation_literal(1225, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": __allocation_literal(1226, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), "values": _values_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1262$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1262$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __allocation_literal(1227, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, __allocation_literal(1228, ({$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return __allocation_literal(1229, ([__allocation_literal(1230, ({$: "None"}))]));
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = __allocation_literal(1231, ({$: "None"}));
  return __allocation_literal(1232, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $measurement$045bend$058health_query1$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $measurement$045bend$058health_query2$(run_loop($measurement$045bend$058health_sum_go$(_values_0, 0, 1, 0)), ($measurement$045bend$058health_views$(_world_0)));
}

function $measurement$045bend$058health_views$(_world_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1261$(__allocation_literal(1233, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.Optional"})), _world_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_taken$1260$(_ns_0, _next_0, _pending_0, _ledger_0, _mode_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _pair_0) {
  const _rows_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/storage.Taken") {
    const _main_0 = _t_0["main"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_invoke$1260$(__allocation_literal(1234, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": __allocation_literal(1235, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": __allocation_literal(1236, ({$: "None"})), "mode": _mode_0})), "main": _main_0, "ledger": _ledger_0, "handle": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))));
  } else {
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body$1261$(__allocation_literal(1237, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1238, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": __allocation_literal(1239, ({$: "Some", "value": _ledger_0})), "mode": _mode_0})), "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body$1261$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_read$1261$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_read_main$(_owner_0, __allocation_literal(1240, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsToken"})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1263$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __allocation_literal(1241, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
  }
}

function $measurement$045bend$058motion_query2$(_total_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  const _x_0 = run_loop($measurement$045bend$058motion_sum_go$(_values_0, 1, 1, 0));
  const _x_1 = (Math.imul(3, _x_0) >>> 0);
  return $measurement$045bend$058motion_query3$(((_total_0 + _x_1) >>> 0), ($measurement$045bend$058motion_views$(_world_0)));
}

function $measurement$045bend$058motion_sum_go$(_values_0, _kind_0, _index_0, _total_0) {
  if (_values_0.$ === "Nil") {
    return ((_total_0 + _index_0) >>> 0);
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $measurement$045bend$058motion_sum_next$(run_clo(__allocation_literal(1242, ((_x_0) => {
  return run_clo(__allocation_literal(1243, ((_x_1) => {
  return $measurement$045bend$058motion_sum_go$(_tail_0, _kind_0, _x_0, _x_1);
})));
}))), ($measurement$045bend$058motion_score$(($measurement$045bend$058motion_included$(_kind_0, _head_0)), _head_0, _index_0, _total_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(_valid_0, _live_0, _changed_0, _id_0, _tick_0) {
  if (!_valid_0) {
    return __allocation_literal(1244, ({$: "Tuple", "fst": _live_0, "snd": _changed_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_live$(_changed_0, ((_id_0 - 1) >>> 0), _tick_0, __allocation_literal(1245, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_return$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["world"];
  const _ns_0 = _t_1["namespace"];
  const _next_0 = _t_1["next"];
  const _t_2 = _t_1["rows"];
  const _columns_0 = _t_2["main"];
  const _aux_0 = _t_2["aux"];
  const _meta_0 = _t_2["metadata"];
  const _cap_0 = _t_2["capacity"];
  const _depth_0 = _t_2["depth"];
  const _high_0 = _t_2["high_water"];
  const _pending_0 = _t_1["pending"];
  const _mode_0 = _t_1["mode"];
  const _main_0 = _t_0["main"];
  const _ledger_0 = _t_0["ledger"];
  const _t_3 = _t_0["handle"];
  const _space_0 = _t_3["namespace"];
  const _id_0 = _t_3["id"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _total_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = __allocation_literal(1246, ({$: "Some", "value": _main_0}));
  return __allocation_literal(1247, ({$: "Tuple", "fst": __allocation_literal(1248, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1249, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": __allocation_literal(1250, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0), "aux": _aux_0, "metadata": _meta_0, "capacity": _cap_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": __allocation_literal(1251, ({$: "Some", "value": _ledger_0})), "mode": _mode_0})), "selected": __allocation_literal(1252, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": _total_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_invoke$1260$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return __allocation_literal(1253, ({$: "Tuple", "fst": _rows_0, "snd": __allocation_literal(1254, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.NoEntity"}))}));
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_take_columns$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1261$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Found") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["coordinates"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1261$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_values_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_ledger$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_main0$(_owner_0, __allocation_literal(1255, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionToken"})), ((_x_0 + 1) >>> 0))), __allocation_literal(1256, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedgerToken"})))));
  } else {
    return __allocation_literal(1257, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_main$(_t_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_read_main$(run_clo(__allocation_literal(1258, ((_x_0) => {
  return run_clo(__allocation_literal(1259, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_read$(_x_0, _x_1);
})));
}))), _t_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return __allocation_literal(1260, ({$: "Tuple", "fst": __allocation_literal(1261, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": ($List$reverse$(_values_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1262$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return __allocation_literal(1262, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1262$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, __allocation_literal(1263, ({$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(1264, ({$: "Tuple", "fst": __allocation_literal(1265, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), "snd": _value_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return __allocation_literal(1266, ({$: "Tuple", "fst": __allocation_literal(1267, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1268, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.NoMainChange"}))}));
    } else {
      return __allocation_literal(1269, ({$: "Tuple", "fst": __allocation_literal(1270, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), __allocation_literal(1271, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})))), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1272, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.RemovedMain"}))}));
    }
  } else {
    if (_old_0.$ === "None") {
      return __allocation_literal(1273, ({$: "Tuple", "fst": __allocation_literal(1274, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), __allocation_literal(1275, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})))), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1276, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.AddedMain"}))}));
    } else {
      return __allocation_literal(1277, ({$: "Tuple", "fst": __allocation_literal(1278, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), __allocation_literal(1279, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})))), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1280, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.ChangedMain"}))}));
    }
  }
}

function $measurement$045bend$058health_query2$(_total_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  const _x_0 = run_loop($measurement$045bend$058health_sum_go$(_values_0, 1, 1, 0));
  const _x_1 = (Math.imul(3, _x_0) >>> 0);
  return $measurement$045bend$058health_query3$(((_total_0 + _x_1) >>> 0), ($measurement$045bend$058health_views$(_world_0)));
}

function $measurement$045bend$058health_sum_go$(_values_0, _kind_0, _index_0, _total_0) {
  if (_values_0.$ === "Nil") {
    return ((_total_0 + _index_0) >>> 0);
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $measurement$045bend$058health_sum_next$(run_clo(__allocation_literal(1281, ((_x_0) => {
  return run_clo(__allocation_literal(1282, ((_x_1) => {
  return $measurement$045bend$058health_sum_go$(_tail_0, _kind_0, _x_0, _x_1);
})));
}))), ($measurement$045bend$058health_score$(($measurement$045bend$058health_included$(_kind_0, _head_0)), _head_0, _index_0, _total_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each$1261$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1261$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_return$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["world"];
  const _ns_0 = _t_1["namespace"];
  const _next_0 = _t_1["next"];
  const _t_2 = _t_1["rows"];
  const _columns_0 = _t_2["main"];
  const _aux_0 = _t_2["aux"];
  const _meta_0 = _t_2["metadata"];
  const _cap_0 = _t_2["capacity"];
  const _depth_0 = _t_2["depth"];
  const _high_0 = _t_2["high_water"];
  const _pending_0 = _t_1["pending"];
  const _mode_0 = _t_1["mode"];
  const _main_0 = _t_0["main"];
  const _ledger_0 = _t_0["ledger"];
  const _t_3 = _t_0["handle"];
  const _space_0 = _t_3["namespace"];
  const _id_0 = _t_3["id"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _total_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = __allocation_literal(1283, ({$: "Some", "value": _main_0}));
  return __allocation_literal(1284, ({$: "Tuple", "fst": __allocation_literal(1285, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": __allocation_literal(1286, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": __allocation_literal(1287, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0), "aux": _aux_0, "metadata": _meta_0, "capacity": _cap_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": __allocation_literal(1288, ({$: "Some", "value": _ledger_0})), "mode": _mode_0})), "selected": __allocation_literal(1289, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0})), "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": _total_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_invoke$1260$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body$1260$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_read$1261$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Found") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["levels"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_ledger$1261$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_values_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_read_ledger$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_set_main0$(_owner_0, __allocation_literal(1290, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsToken"})), ((_x_0 + 1) >>> 0))), __allocation_literal(1291, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedgerToken"})))));
  } else {
    return __allocation_literal(1292, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_read_main$(_t_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_read_main$(run_clo(__allocation_literal(1293, ((_x_0) => {
  return run_clo(__allocation_literal(1294, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_read$(_x_0, _x_1);
})));
}))), _t_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return __allocation_literal(1295, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, __allocation_literal(1296, ({$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]})));
  }
}

function $measurement$045bend$058motion_query3$(_total_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  const _x_0 = run_loop($measurement$045bend$058motion_sum_go$(_values_0, 2, 1, 0));
  const _x_1 = (Math.imul(5, _x_0) >>> 0);
  return __allocation_literal(1297, ({$: "Tuple", "fst": _world_0, "snd": ((_total_0 + _x_1) >>> 0)}));
}

function $measurement$045bend$058motion_sum_next$(_ih_0, _pair_0) {
  const _index_0 = _pair_0["fst"];
  const _total_0 = _pair_0["snd"];
  return run_tail(_ih_0(_index_0), _total_0);
}

function $measurement$045bend$058motion_score$(_included_0, _value_0, _index_0, _total_0) {
  if (!_included_0) {
    return __allocation_literal(1298, ({$: "Tuple", "fst": _index_0, "snd": _total_0}));
  } else {
    const _x_0 = ($measurement$045bend$058motion_row_sum$(_value_0));
    const _x_1 = (Math.imul(_index_0, _x_0) >>> 0);
    return __allocation_literal(1299, ({$: "Tuple", "fst": ((_index_0 + 1) >>> 0), "snd": ((_total_0 + _x_1) >>> 0)}));
  }
}

function $measurement$045bend$058motion_included$(_kind_0, _value_0) {
  if (_kind_0 == 1) {
    const _aux_0 = _value_0["aux"];
    return $measurement$045bend$058motion_has_aux$(_aux_0);
  } else if ((_kind_0 & 1) == 1) {
    return true;
  } else if (_kind_0 == 2) {
    const _aux_1 = _value_0["aux"];
    return $Bool$not$(($measurement$045bend$058motion_has_aux$(_aux_1)));
  } else {
    return true;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1260$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, __allocation_literal(1300, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(1301, ({$: "Nil"}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_live$(_changed_0, _index_0, _tick_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return __allocation_literal(1302, ({$: "Tuple", "fst": _live_0, "snd": _changed_0}));
  } else {
    return __allocation_literal(1303, ({$: "Tuple", "fst": _live_0, "snd": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_get$(_owner_0, __allocation_literal(1304, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionToken"})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_take_columns$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_take_live$(_id_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, __allocation_literal(1305, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1261$(_readsum_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["totals"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return __allocation_literal(1306, ({$: "Tuple", "fst": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_ledger0$(_owner_0, __allocation_literal(1307, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedgerToken"})), ((_x_0 + 1) >>> 0))), "snd": _readsum_0}));
  } else {
    return __allocation_literal(1308, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  const _x_0 = ((_a_0 + _b_0) >>> 0);
  const _x_1 = ((_c_0 + _d_0) >>> 0);
  return ((_x_0 + _x_1) >>> 0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_ledger$(_t_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(run_clo(__allocation_literal(1309, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_read$(_x_0);
}))), _t_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_main0$(_t_0, _token_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_set_main0$(run_clo(__allocation_literal(1310, ((_x_0) => {
  return run_clo(__allocation_literal(1311, ((_x_1) => {
  return run_clo(__allocation_literal(1312, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_write$(_x_0, _x_1, _x_2);
})));
})));
}))), _t_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_value_0) {
  const _a_0 = _value_0["a"];
  return _a_0;
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_read_main$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0)(_selected_0));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_read$(_world_0, _handle_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo(__allocation_literal(1313, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_get$(_x_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1262$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return __allocation_literal(1314, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1262$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return __allocation_literal(1315, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rejected", "rows": __allocation_literal(1316, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "row": _row_0}));
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return __allocation_literal(1317, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Placed", "rows": __allocation_literal(1318, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), __allocation_literal(1319, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})))), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}))}));
  }
}

function $measurement$045bend$058health_query3$(_total_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  const _x_0 = run_loop($measurement$045bend$058health_sum_go$(_values_0, 2, 1, 0));
  const _x_1 = (Math.imul(5, _x_0) >>> 0);
  return __allocation_literal(1320, ({$: "Tuple", "fst": _world_0, "snd": ((_total_0 + _x_1) >>> 0)}));
}

function $measurement$045bend$058health_sum_next$(_ih_0, _pair_0) {
  const _index_0 = _pair_0["fst"];
  const _total_0 = _pair_0["snd"];
  return run_tail(_ih_0(_index_0), _total_0);
}

function $measurement$045bend$058health_score$(_included_0, _value_0, _index_0, _total_0) {
  if (!_included_0) {
    return __allocation_literal(1321, ({$: "Tuple", "fst": _index_0, "snd": _total_0}));
  } else {
    const _x_0 = ($measurement$045bend$058health_row_sum$(_value_0));
    const _x_1 = (Math.imul(_index_0, _x_0) >>> 0);
    return __allocation_literal(1322, ({$: "Tuple", "fst": ((_index_0 + 1) >>> 0), "snd": ((_total_0 + _x_1) >>> 0)}));
  }
}

function $measurement$045bend$058health_included$(_kind_0, _value_0) {
  if (_kind_0 == 1) {
    const _aux_0 = _value_0["aux"];
    return $measurement$045bend$058health_has_aux$(_aux_0);
  } else if ((_kind_0 & 1) == 1) {
    return true;
  } else if (_kind_0 == 2) {
    const _aux_1 = _value_0["aux"];
    return $Bool$not$(($measurement$045bend$058health_has_aux$(_aux_1)));
  } else {
    return true;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1261$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1261$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, __allocation_literal(1323, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(1324, ({$: "Nil"}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body$1260$(_owner_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_read$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_get$(_owner_0, __allocation_literal(1325, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsToken"})))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_ledger$1261$(_readsum_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["totals"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return __allocation_literal(1326, ({$: "Tuple", "fst": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_set_ledger0$(_owner_0, __allocation_literal(1327, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedgerToken"})), ((_x_0 + 1) >>> 0))), "snd": _readsum_0}));
  } else {
    return __allocation_literal(1328, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_read_ledger$(_t_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(run_clo(__allocation_literal(1329, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_ledger_read$(_x_0);
}))), _t_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_set_main0$(_t_0, _token_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_set_main0$(run_clo(__allocation_literal(1330, ((_x_0) => {
  return run_clo(__allocation_literal(1331, ((_x_1) => {
  return run_clo(__allocation_literal(1332, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_write$(_x_0, _x_1, _x_2);
})));
})));
}))), _t_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_read$(_world_0, _handle_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo(__allocation_literal(1333, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_get$(_x_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return __allocation_literal(1334, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1263$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $measurement$045bend$058motion_row_sum$(_value_0) {
  const _t_0 = _value_0["handle"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _x_0 = ($measurement$045bend$058motion_aux_sum$(_aux_0));
  const _x_1 = ($measurement$045bend$058motion_flag_sum$(_flag_0));
  const _x_2 = ($measurement$045bend$058motion_main_sum$(_main_0));
  const _x_3 = ((_x_0 + _x_1) >>> 0);
  const _x_4 = ((_namespace_0 + _id_0) >>> 0);
  const _x_5 = ((_x_2 + _x_3) >>> 0);
  return ((_x_4 + _x_5) >>> 0);
}

function $measurement$045bend$058motion_has_aux$(_value_0) {
  if (_value_0.$ === "None") {
    return false;
  } else {
    return true;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1260$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Found") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["coordinates"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_values_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_ledger$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_set$(_owner_0, __allocation_literal(1335, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionToken"})), ((_x_0 + 1) >>> 0))), __allocation_literal(1336, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedgerToken"})))));
  } else {
    return __allocation_literal(1337, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_get$(_owner_0, _token_0) {
  const _world_0 = _owner_0["world"];
  const _t_0 = _owner_0["main"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _ledger_0 = _owner_0["ledger"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return __allocation_literal(1338, ({$: "Tuple", "fst": __allocation_literal(1339, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": __allocation_literal(1340, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0})), "ledger": _ledger_0, "handle": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": __allocation_literal(1341, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Found", "value": _cached_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_take_live$(_id_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_meta$(_id_0, _main_0, _aux_0, __allocation_literal(1342, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), _capacity_0, _depth_0, _high_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_ledger0$(_t_0, _token_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(run_clo(__allocation_literal(1343, ((_x_0) => {
  return run_clo(__allocation_literal(1344, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_write$(_x_0, _x_1);
})));
}))), _t_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_read$(_world_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo(__allocation_literal(1345, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_get$(_x_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_set_main0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058record_main$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_selected_0)(_value_0));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_write$(_world_0, _handle_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_main0$1260$(_world_0, _handle_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return __allocation_literal(1346, ({$: "Tuple", "fst": __allocation_literal(1347, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": _view_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058hook_checked$((_namespace_0 === _foreign_0), __allocation_literal(1348, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), _id_0, _transform_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1262$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return __allocation_literal(1349, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1350, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1262$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, __allocation_literal(1351, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "../bendvy-query-live-first/experiments/s-integrate/query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "../bendvy-query-live-first/experiments/s-integrate/query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $measurement$045bend$058health_row_sum$(_value_0) {
  const _t_0 = _value_0["handle"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _x_0 = ($measurement$045bend$058health_aux_sum$(_aux_0));
  const _x_1 = ($measurement$045bend$058health_flag_sum$(_flag_0));
  const _x_2 = ($measurement$045bend$058health_main_sum$(_main_0));
  const _x_3 = ((_x_0 + _x_1) >>> 0);
  const _x_4 = ((_namespace_0 + _id_0) >>> 0);
  const _x_5 = ((_x_2 + _x_3) >>> 0);
  return ((_x_4 + _x_5) >>> 0);
}

function $measurement$045bend$058health_has_aux$(_value_0) {
  if (_value_0.$ === "None") {
    return false;
  } else {
    return true;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1261$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_read$1260$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Found") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["levels"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_ledger$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_values_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_ledger$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_set$(_owner_0, __allocation_literal(1352, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsToken"})), ((_x_0 + 1) >>> 0))), __allocation_literal(1353, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedgerToken"})))));
  } else {
    return __allocation_literal(1354, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_get$(_owner_0, _token_0) {
  const _world_0 = _owner_0["world"];
  const _t_0 = _owner_0["main"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _ledger_0 = _owner_0["ledger"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return __allocation_literal(1355, ({$: "Tuple", "fst": __allocation_literal(1356, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": __allocation_literal(1357, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0})), "ledger": _ledger_0, "handle": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": __allocation_literal(1358, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Found", "value": _cached_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_set_ledger0$(_t_0, _token_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(run_clo(__allocation_literal(1359, ((_x_0) => {
  return run_clo(__allocation_literal(1360, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_ledger_write$(_x_0, _x_1);
})));
}))), _t_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_ledger_read$(_world_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo(__allocation_literal(1361, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_get$(_x_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_write$(_world_0, _handle_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_main0$1261$(_world_0, _handle_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1263$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return __allocation_literal(1362, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1363, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1263$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, __allocation_literal(1364, (() => _x_1))));
  }
}

function $measurement$045bend$058motion_main_sum$(_value_0) {
  const _values_0 = _value_0["coordinates"];
  const _meta_0 = _value_0["frame"];
  const _x_0 = ($measurement$045bend$058sum$(_values_0));
  return ((_x_0 + _meta_0) >>> 0);
}

function $measurement$045bend$058motion_aux_sum$(_value_0) {
  if (_value_0.$ === "None") {
    return 0;
  } else {
    const _t_0 = _value_0["value"];
    const _values_0 = _t_0["rates"];
    const _moving_0 = _t_0["moving"];
    const _x_0 = ($measurement$045bend$058boolnum$(_moving_0));
    const _x_1 = ($measurement$045bend$058sum$(_values_0));
    const _x_2 = ((_x_0 + 1) >>> 0);
    return ((_x_1 + _x_2) >>> 0);
  }
}

function $measurement$045bend$058motion_flag_sum$(_value_0) {
  if (_value_0.$ === "None") {
    return 0;
  } else {
    const _t_0 = _value_0["value"];
    const _group_0 = _t_0["group"];
    return ((_group_0 + 1) >>> 0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __allocation_literal(1365, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1260$(_readsum_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["totals"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return __allocation_literal(1366, ({$: "Tuple", "fst": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_setledger$(_owner_0, __allocation_literal(1367, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedgerToken"})), ((_x_0 + 1) >>> 0))), "snd": _readsum_0}));
  } else {
    return __allocation_literal(1368, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_ledger$(_owner_0, _token_0) {
  const _world_0 = _owner_0["world"];
  const _main_0 = _owner_0["main"];
  const _t_0 = _owner_0["ledger"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return __allocation_literal(1369, ({$: "Tuple", "fst": __allocation_literal(1370, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": _main_0, "ledger": __allocation_literal(1371, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0})), "handle": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": __allocation_literal(1372, ({$: "Some", "value": _cached_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_set$(_owner_0, _token_0, _value_0) {
  const _world_0 = _owner_0["world"];
  const _t_0 = _owner_0["main"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _ledger_0 = _owner_0["ledger"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_set_fused_done$(_world_0, _ledger_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_position_raw_swap$(_raw_0, _value_1)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_meta$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  if (!_meta_0) {
    return __allocation_literal(1373, ({$: "Tuple", "fst": __allocation_literal(1374, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1375, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.NoEntity"}))}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1376, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_main_done$(_aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, array_rmw(_main_0, _x_0, __allocation_literal(1377, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_value_0));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_write$(_world_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1260$(_world_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return __allocation_literal(1378, ({$: "Tuple", "fst": __allocation_literal(1379, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": _view_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _t_0 = _world_0["ledger"];
  if (_t_0.$ === "None") {
    const _mode_0 = _world_0["mode"];
    return __allocation_literal(1380, ({$: "Tuple", "fst": __allocation_literal(1381, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": __allocation_literal(1382, ({$: "None"})), "mode": _mode_0})), "snd": __allocation_literal(1383, ({$: "None"}))}));
  } else {
    const _ledger_0 = _t_0["value"];
    const _mode_1 = _world_0["mode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_1, _transform_0(_ledger_0));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058record_main$(_handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../bendvy-query-live-first/experiments/s-integrate/types.Found") {
    const _old_0 = _t_0["value"];
    return __allocation_literal(1384, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": __allocation_literal(1385, ({$: "Con", "head": __allocation_literal(1386, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.MainInverse", "handle": _handle_0, "old": _old_0})), "tail": _undo_0})), "commands": _commands_0, "pings": _pings_0, "marks": __allocation_literal(1387, ({$: "Con", "head": _handle_0, "tail": _marks_0}))}));
  } else {
    return __allocation_literal(1388, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_main0$1260$(_world_0, _handle_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo(__allocation_literal(1389, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_swap$(_x_0, _value_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return __allocation_literal(1390, ({$: "Tuple", "fst": _world_0, "snd": __allocation_literal(1391, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Missing"}))}));
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), __allocation_literal(1392, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": __allocation_literal(1393, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), _target_0, _transform_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1262$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1394, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1395, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1262$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, __allocation_literal(1396, (() => _x_1))));
  }
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

function $measurement$045bend$058health_main_sum$(_value_0) {
  const _values_0 = _value_0["levels"];
  const _meta_0 = _value_0["reserve"];
  const _other_0 = _value_0["class"];
  const _x_0 = ($measurement$045bend$058sum$(_values_0));
  const _x_1 = ((_meta_0 + _other_0) >>> 0);
  return ((_x_0 + _x_1) >>> 0);
}

function $measurement$045bend$058health_aux_sum$(_value_0) {
  if (_value_0.$ === "None") {
    return 0;
  } else {
    const _t_0 = _value_0["value"];
    const _values_0 = _t_0["layers"];
    const _meta_0 = _t_0["grade"];
    const _x_0 = ($measurement$045bend$058sum$(_values_0));
    const _x_1 = ((_meta_0 + 1) >>> 0);
    return ((_x_0 + _x_1) >>> 0);
  }
}

function $measurement$045bend$058health_flag_sum$(_value_0) {
  if (_value_0.$ === "None") {
    return 0;
  } else {
    const _t_0 = _value_0["value"];
    const _group_0 = _t_0["group"];
    return ((_group_0 + 1) >>> 0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1261$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1261$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __allocation_literal(1397, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058health_body_ledger$1260$(_readsum_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["totals"];
    const _x_0 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return __allocation_literal(1398, ({$: "Tuple", "fst": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_setledger$(_owner_0, __allocation_literal(1399, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedgerToken"})), ((_x_0 + 1) >>> 0))), "snd": _readsum_0}));
  } else {
    return __allocation_literal(1400, ({$: "Tuple", "fst": _owner_0, "snd": 4294967295}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_ledger$(_owner_0, _token_0) {
  const _world_0 = _owner_0["world"];
  const _main_0 = _owner_0["main"];
  const _t_0 = _owner_0["ledger"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return __allocation_literal(1401, ({$: "Tuple", "fst": __allocation_literal(1402, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": _main_0, "ledger": __allocation_literal(1403, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0})), "handle": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), "snd": __allocation_literal(1404, ({$: "Some", "value": _cached_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_set$(_owner_0, _token_0, _value_0) {
  const _world_0 = _owner_0["world"];
  const _t_0 = _owner_0["main"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _ledger_0 = _owner_0["ledger"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_set_fused_done$(_world_0, _ledger_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_vitals_raw_swap$(_raw_0, _value_1)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058health_world_ledger_write$(_world_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1261$(_world_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_main0$1261$(_world_0, _handle_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo(__allocation_literal(1405, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_swap$(_x_0, _value_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1263$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1406, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1407, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1263$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, __allocation_literal(1408, (() => _x_1))));
  }
}

function $measurement$045bend$058sum$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  const _x_0 = ((_a_0 + _b_0) >>> 0);
  const _x_1 = ((_c_0 + _d_0) >>> 0);
  return ((_x_0 + _x_1) >>> 0);
}

function $measurement$045bend$058boolnum$(_value_0) {
  if (_value_0) {
    return 1;
  } else {
    return 0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return __allocation_literal(1409, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, __allocation_literal(1410, ({$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_setledger$(_owner_0, _token_0, _value_0) {
  const _world_0 = _owner_0["world"];
  const _main_0 = _owner_0["main"];
  const _t_0 = _owner_0["ledger"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_setledger_fused_done$(_world_0, _main_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_motion_ledger_raw_swap$(_raw_0, _value_1)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_set_fused_done$(_world_0, _ledger_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1411, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": __allocation_literal(1412, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_patch$(_cached_0, _value_0))})), "ledger": _ledger_0, "handle": _handle_0, "undo": __allocation_literal(1413, ({$: "Con", "head": __allocation_literal(1414, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.MainInverse", "handle": _handle_0, "old": _old_0})), "tail": _undo_0})), "commands": _commands_0, "pings": _pings_0, "marks": __allocation_literal(1415, ({$: "Con", "head": _handle_0, "tail": _marks_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_position_raw_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_swap$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058take_main_done$(_aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1416, ({$: "Tuple", "fst": __allocation_literal(1417, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1418, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.NoMain"}))}));
  } else {
    const _value_0 = _t_0["value"];
    return __allocation_literal(1419, ({$: "Tuple", "fst": __allocation_literal(1420, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": __allocation_literal(1421, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Taken", "main": _value_0}))}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _old_0 = _t_0["value"];
    return __allocation_literal(1422, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": __allocation_literal(1423, ({$: "Con", "head": __allocation_literal(1424, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.LedgerInverse", "old": _old_0})), "tail": _undo_0})), "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
  } else {
    return __allocation_literal(1425, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1260$(_world_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo(__allocation_literal(1426, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_swap$(_x_0, _value_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return __allocation_literal(1427, ({$: "Tuple", "fst": __allocation_literal(1428, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": __allocation_literal(1429, ({$: "Some", "value": _ledger_0})), "mode": _mode_0})), "snd": __allocation_literal(1430, ({$: "Some", "value": _observation_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1260$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return __allocation_literal(1431, ({$: "Tuple", "fst": _world_0, "snd": __allocation_literal(1432, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Missing"}))}));
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1262$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($measurement$045bend$058handle_client$1260$(run_clo(__allocation_literal(1433, ((_x_0) => {
  return run_clo(__allocation_literal(1434, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1262$(_x_0, _x_1);
})));
}))), run_clo(__allocation_literal(1435, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1262$(_x_2);
}))), __allocation_literal(1436, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0})), _flag_0, _owner_0, _a_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1261$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return __allocation_literal(1437, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1261$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, __allocation_literal(1438, ({$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_setledger$(_owner_0, _token_0, _value_0) {
  const _world_0 = _owner_0["world"];
  const _main_0 = _owner_0["main"];
  const _t_0 = _owner_0["ledger"];
  const _raw_0 = _t_0["raw"];
  const _cached_0 = _t_0["cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_setledger_fused_done$(_world_0, _main_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_1, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_health_ledger_raw_swap$(_raw_0, _value_1)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_set_fused_done$(_world_0, _ledger_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1439, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": __allocation_literal(1440, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_patch$(_cached_0, _value_0))})), "ledger": _ledger_0, "handle": _handle_0, "undo": __allocation_literal(1441, ({$: "Con", "head": __allocation_literal(1442, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.MainInverse", "handle": _handle_0, "old": _old_0})), "tail": _undo_0})), "commands": _commands_0, "pings": _pings_0, "marks": __allocation_literal(1443, ({$: "Con", "head": _handle_0, "tail": _marks_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_vitals_raw_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_swap$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1261$(_world_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo(__allocation_literal(1444, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_swap$(_x_0, _value_0);
}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1261$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1263$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($measurement$045bend$058handle_client$1261$(run_clo(__allocation_literal(1445, ((_x_0) => {
  return run_clo(__allocation_literal(1446, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1263$(_x_0, _x_1);
})));
}))), run_clo(__allocation_literal(1447, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1263$(_x_2);
}))), __allocation_literal(1448, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0})), _flag_0, _owner_0, _a_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return __allocation_literal(1449, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058motion_setledger_fused_done$(_world_0, _main_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1450, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": _main_0, "ledger": __allocation_literal(1451, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_patch$(_cached_0, _value_0))})), "handle": _handle_0, "undo": __allocation_literal(1452, ({$: "Con", "head": __allocation_literal(1453, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.LedgerInverse", "old": _old_0})), "tail": _undo_0})), "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_motion_ledger_raw_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_swap$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["coordinates"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _frame_0 = _view_0["frame"];
  return __allocation_literal(1454, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionView", "coordinates": __allocation_literal(1455, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0})), "frame": _frame_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["coordinates"];
  const _frame_0 = _owner_0["frame"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_position_swap$(_frame_0, _value_0, __allocation_literal(1456, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1262$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1260$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1260$(_cached_0, _value_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_swap$(_raw_0, _value_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, __allocation_literal(1457, ({$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(_index_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _m_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _a_0 = _t_0["fst"];
  const _value_0 = _t_0["snd"];
  const _x_0 = __allocation_literal(1458, ({$: "Some", "value": _m_0}));
  return __allocation_literal(1459, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": (_aux_0[_index_0 % _aux_0.length] = _a_0, _aux_0), "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(1460, ({$: "Con", "head": _value_0, "tail": _values_0}))}));
}

function $measurement$045bend$058handle_client$1260$(_get_0, _ag_0, _handle_0, _flag_0, _owner_0, _aux_0) {
  return __allocation_literal(1461, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1462, ({$: "Tuple", "fst": _aux_0, "snd": _handle_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1262$(_owner_0, _token_0) {
  return $measurement$045bend$058keep$1260$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(1463, ({$: "Tuple", "fst": __allocation_literal(1464, ({$: "None"})), "snd": __allocation_literal(1465, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(($measurement$045bend$058keep$1261$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1261$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return __allocation_literal(1466, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1261$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047held$045adapter$058health_setledger_fused_done$(_world_0, _main_0, _handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1467, ({$: "../bendvy-query-live-first/experiments/s-integrate/held.Held", "world": _world_0, "main": _main_0, "ledger": __allocation_literal(1468, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_cached_0, _value_0))})), "handle": _handle_0, "undo": __allocation_literal(1469, ({$: "Con", "head": __allocation_literal(1470, ({$: "../bendvy-query-live-first/experiments/s-integrate/transaction.LedgerInverse", "old": _old_0})), "tail": _undo_0})), "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058prototype_health_ledger_raw_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_swap$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["levels"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _reserve_0 = _view_0["reserve"];
  const _class_0 = _view_0["class"];
  return __allocation_literal(1471, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsView", "levels": __allocation_literal(1472, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0})), "reserve": _reserve_0, "class": _class_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["levels"];
  const _reserve_0 = _owner_0["reserve"];
  const _class_0 = _owner_0["class"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_vitals_swap$(_reserve_0, _class_0, _value_0, __allocation_literal(1473, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1263$(_owner_0, _value_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1261$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1261$(_cached_0, _value_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058vitals_swap$(_raw_0, _value_0)));
}

function $measurement$045bend$058handle_client$1261$(_get_0, _ag_0, _handle_0, _flag_0, _owner_0, _aux_0) {
  return __allocation_literal(1474, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1475, ({$: "Tuple", "fst": _aux_0, "snd": _handle_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1263$(_owner_0, _token_0) {
  return $measurement$045bend$058keep$1262$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1263$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(1476, ({$: "Tuple", "fst": __allocation_literal(1477, ({$: "None"})), "snd": __allocation_literal(1478, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(($measurement$045bend$058keep$1263$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return __allocation_literal(1479, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1480, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, __allocation_literal(1481, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return __allocation_literal(1482, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.LedgerView", "totals": __allocation_literal(1483, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0})), "epoch": _epoch_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_motion_ledger_swap$(_epoch_0, _value_0, __allocation_literal(1484, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_position_swap$(_frame_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1485, ({$: "Tuple", "fst": __allocation_literal(1486, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Position", "coordinates": (_array_0[0 % _array_0.length] = _value_0, _array_0), "frame": _frame_0})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1262$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1262$(_cached_0, _value_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_swap$(_raw_0, _value_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1260$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1487, ({$: "Tuple", "fst": __allocation_literal(1488, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_patch$(_cached_0, _value_0))})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, __allocation_literal(1489, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $measurement$045bend$058keep$1260$(_owner_0) {
  return __allocation_literal(1490, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1491, ({$: "Unit"}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(1492, ({$: "Tuple", "fst": __allocation_literal(1493, ({$: "Some", "value": _owner_0})), "snd": __allocation_literal(1494, ({$: "Some", "value": _value_0}))}));
}

function $measurement$045bend$058keep$1261$(_owner_0) {
  return __allocation_literal(1495, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1496, ({$: "Unit"}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1261$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return __allocation_literal(1497, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1498, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1261$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, __allocation_literal(1499, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return __allocation_literal(1500, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.LedgerView", "totals": __allocation_literal(1501, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0})), "epoch": _epoch_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_health_ledger_swap$(_epoch_0, _value_0, __allocation_literal(1502, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_vitals_swap$(_reserve_0, _class_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1503, ({$: "Tuple", "fst": __allocation_literal(1504, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Vitals", "levels": (_array_0[0 % _array_0.length] = _value_0, _array_0), "reserve": _reserve_0, "class": _class_0})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap$1263$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1263$(_cached_0, _value_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_swap$(_raw_0, _value_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1261$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1505, ({$: "Tuple", "fst": __allocation_literal(1506, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_patch$(_cached_0, _value_0))})), "snd": _old_0}));
}

function $measurement$045bend$058keep$1262$(_owner_0) {
  return __allocation_literal(1507, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1508, ({$: "Unit"}))}));
}

function $measurement$045bend$058keep$1263$(_owner_0) {
  return __allocation_literal(1509, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1510, ({$: "Unit"}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1511, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1512, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, __allocation_literal(1513, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_motion_ledger_swap$(_epoch_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1514, ({$: "Tuple", "fst": __allocation_literal(1515, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.MotionLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1262$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1516, ({$: "Tuple", "fst": __allocation_literal(1517, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_patch$(_cached_0, _value_0))})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return __allocation_literal(1518, ({$: "Tuple", "fst": __allocation_literal(1519, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": __allocation_literal(1520, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": __allocation_literal(1521, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Missing"}))}));
  } else {
    const _x_0 = __allocation_literal(1522, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, __allocation_literal(1523, (() => _x_0))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1261$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1524, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(1525, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1261$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, __allocation_literal(1526, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_health_ledger_swap$(_epoch_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1527, ({$: "Tuple", "fst": __allocation_literal(1528, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.HealthLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cache$058static_swap_done$1263$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return __allocation_literal(1529, ({$: "Tuple", "fst": __allocation_literal(1530, ({$: "../bendvy-query-live-first/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_cached_0, _value_0))})), "snd": _old_0}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client$1260$(run_clo(__allocation_literal(1531, ((_x_0) => {
  return run_clo(__allocation_literal(1532, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1260$(_x_0, _x_1);
})));
}))), run_clo(__allocation_literal(1533, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1260$(_x_2);
}))), __allocation_literal(1534, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0})), _flag_0, _owner_0, _a_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(1535, ({$: "Tuple", "fst": __allocation_literal(1536, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": __allocation_literal(1537, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": __allocation_literal(1538, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Mismatch"}))}));
  } else {
    const _value_0 = _t_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1261$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client$1261$(run_clo(__allocation_literal(1539, ((_x_0) => {
  return run_clo(__allocation_literal(1540, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1261$(_x_0, _x_1);
})));
}))), run_clo(__allocation_literal(1541, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1261$(_x_2);
}))), __allocation_literal(1542, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0})), _flag_0, _owner_0, _a_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client$1260$(_main_get_0, _aux_get_0, _handle_0, _flag_0, _main_0, _aux_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client_main$(_aux_get_0, _handle_0, _flag_0, _aux_0, _main_get_0(_main_0)(__allocation_literal(1543, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionToken"}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1260$(_owner_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058position_get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(1544, ({$: "Tuple", "fst": __allocation_literal(1545, ({$: "None"})), "snd": __allocation_literal(1546, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058velocity_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = __allocation_literal(1547, ({$: "Some", "value": _value_0}));
  return __allocation_literal(1548, ({$: "Tuple", "fst": __allocation_literal(1549, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": __allocation_literal(1550, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})), "snd": __allocation_literal(1551, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Found", "value": _observation_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client$1261$(_main_get_0, _aux_get_0, _handle_0, _flag_0, _main_0, _aux_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client_main$(_aux_get_0, _handle_0, _flag_0, _aux_0, _main_get_0(_main_0)(__allocation_literal(1552, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VitalsToken"}))));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1261$(_owner_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047cached$045payload$058vitals_get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(1553, ({$: "Tuple", "fst": __allocation_literal(1554, ({$: "None"})), "snd": __allocation_literal(1555, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047payload$058armor_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client_main$(_aux_get_0, _handle_0, _flag_0, _aux_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client_aux$(_handle_0, _flag_0, _owner_0, _value_0, _aux_get_0(_aux_0));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047observations$058client_aux$(_handle_0, _flag_0, _owner_0, _main_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(1556, ({$: "Tuple", "fst": _owner_0, "snd": __allocation_literal(1557, ({$: "Tuple", "fst": _aux_0, "snd": __allocation_literal(1558, ({$: "../bendvy-query-live-first/experiments/s-integrate/observations.QueryRow", "handle": _handle_0, "main": _main_0, "aux": _value_0, "flag": _flag_0}))}))}));
}

// Cli
// ===

let cli_args = __allocation_literal(1559, ([]));

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = __allocation_literal(1560, ({ 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }))[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? __allocation_literal(1561, ({ $: v ? "True" : "False" })) : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + __allocation_literal(1562, ([...v])).map(__allocation_literal(1563, ((c) =>
      show_chr(c.codePointAt(0), "\"")))).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map(__allocation_literal(1564, ((x) => show_val(D, N, D[d + 1], x, 0)))).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = __allocation_literal(1565, ({ i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" }));
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map(__allocation_literal(1566, ((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return __allocation_literal(1567, ([name, __allocation_literal(1568, ({ args: __allocation_literal(1569, ([...args])).map(__allocation_literal(1570, ((a) => T[a]))), returns: T[ret] }))]));
      }))))).symbols;
    const fcntl = __allocation_literal(1571, ((fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg)));
    globalThis.BEND_SYS = __allocation_literal(1572, ({ ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: __allocation_literal(1573, (() => ffi.read.i32(lib[err](), 0))) }));
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return __allocation_literal(1574, ({ $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) }));
}

function io_done(value) {
  return __allocation_literal(1575, ({ $: "Done", value }));
}

function io_tup(...xs) {
  return xs.reduceRight(__allocation_literal(1576, ((snd, fst) => (__allocation_literal(1577, ({ $: "Tuple", fst, snd }))))));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", __allocation_literal(1578, ({ ignoreBOM: true }))).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = __allocation_literal(1579, ({ $: "Nil" }));
  while (n > 0) {
    xs = __allocation_literal(1580, ({ $: "Con", head: b[--n], tail: xs }));
  }
  return xs;
}

function io_unlist(xs) {
  const b = __allocation_literal(1581, ([]));
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some(__allocation_literal(1582, ((x) => x > 255))) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = __allocation_literal(1583, ((p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256));
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? __allocation_literal(1584, ([16, 2])) : __allocation_literal(1585, ([2, 0]));
  b.set(__allocation_literal(1586, ([...head, port >> 8, port & 255, ...part.map(Number)])));
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push(__allocation_literal(1587, ({ fun, arg })));
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter(__allocation_literal(1588, ((w) => w.fd !== undefined)));
  const top = fds.reduce(__allocation_literal(1589, ((m, w) => Math.max(m, w.fd))), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = __allocation_literal(1590, ((w) => (w.out ? len : 0) + (w.fd >> 3)));
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array(__allocation_literal(1591, ([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)])));
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter(__allocation_literal(1592, ((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  })));
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex(__allocation_literal(1593, ((w) => (w.at ?? Infinity) <= (at ?? Infinity))));
  ws.splice(i + 1, 0, __allocation_literal(1594, ({ fd, out, k, more, at })));
}

function io_run(m) {
  const io = __allocation_literal(1595, ({ runs: __allocation_literal(1596, ([])), live: 0, waits: __allocation_literal(1597, ([])) }));
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), __allocation_literal(1598, ((x) => (__allocation_literal(1599, ({ $: "Emit", value: x }))))), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? __allocation_literal(1600, ({}));
        if (need.time || need.read) {
          const more = __allocation_literal(1601, (() => op.run(...op.args, op.kont)));
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);