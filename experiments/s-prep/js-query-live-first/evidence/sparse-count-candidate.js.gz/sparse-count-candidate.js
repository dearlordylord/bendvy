process.on("exit",()=>__allocation_phase("end"));
let __allocation_active=true;
const __allocation_counts=new Float64Array(149);
function __allocation_literal(site,value){if(__allocation_active)__allocation_counts[site]++;return value;}
function __allocation_phase(phase){if(phase==='start')__allocation_active=true;else {__allocation_active=false;console.error('ALLOCATION-COUNTS:'+JSON.stringify(Array.from(__allocation_counts)));}}
function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = __allocation_literal(0, ({$: "WNil"}));
  for (let i = 31; i >= 0; i--) {
    w = __allocation_literal(1, ({$: "WCon", head: ((x >>> i) & 1) === 1, tail: w}));
  }
  return w;
}

function cmp_new(a, b) {
  return __allocation_literal(2, ({$: a < b ? "LT"
    : a === b ? "EQ" : "GT"}));
}

function nat_divmod(a, b) {
  return b === 0 ? __allocation_literal(3, ({$: "Tuple", fst: 0, snd: a}))
    : __allocation_literal(4, ({$: "Tuple", fst: Math.trunc(a / b), snd: a % b}));
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return __allocation_literal(5, ({ [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } }));
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array(__allocation_literal(6, ([x]))).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array(__allocation_literal(7, ([u]))).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? __allocation_literal(8, ({$: "Some", value: v})) : __allocation_literal(9, ({$: "None"}));
}

const f32_round = __allocation_literal(10, (function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
}));

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return __allocation_literal(11, ({$: "Tuple", fst: a, snd: old}));
}

// Run
// ===

function run_tail(f, x) {
  return __allocation_literal(12, ({$: "$JMP", f: f.j?.f === f ? f.j : f, x: __allocation_literal(13, ([x]))}));
}

function run_clo(j) {
  const f = __allocation_literal(14, ((x) => run_loop(j(x))));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return __allocation_literal(15, ((...a) => a.length < n ? run_lib(__allocation_literal(16, ((...b) => f(...a, ...b))), n - a.length)
    : f(...a)));
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = __allocation_literal(17, ({ run, need }));
}
(__allocation_literal(18, (() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return __allocation_literal(19, ({ $: "Unit" }));
}

io_eff("IO.print", io_print);

})))();

for (const k of __allocation_literal(20, (["IO.print"]))) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return $sparse_grown$(run_loop($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow$(17, 65538, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_empty$()))));
}

function $sparse_grown$(_rows_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  return $sparse_finished$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1260$(__allocation_literal(21, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": 65538})), __allocation_literal(22, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.Optional"})), 1)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), __allocation_literal(23, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0})), run_clo(__allocation_literal(24, ((_x_0) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow$(_n_0, _id_0, _x_0);
}))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058rows_empty$() {
  return __allocation_literal(25, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": __allocation_literal(26, ([__allocation_literal(27, ({$: "None"}))])), "aux": __allocation_literal(28, ([__allocation_literal(29, ({$: "None"}))])), "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0}));
}

function $sparse_finished$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["capacity"];
  if (_t_1 == 131072) {
    const _t_2 = _t_0["depth"];
    if (_t_2 === 0) {
      return __allocation_literal(30, ((_x_0) => $IO$print$("SPARSE-HIGH-FAIL", _x_0)));
    } else if (_t_2 === 1) {
      return __allocation_literal(31, ((_x_1) => $IO$print$("SPARSE-HIGH-FAIL", _x_1)));
    } else if (_t_2 === 2) {
      return __allocation_literal(32, ((_x_2) => $IO$print$("SPARSE-HIGH-FAIL", _x_2)));
    } else if (_t_2 === 3) {
      return __allocation_literal(33, ((_x_3) => $IO$print$("SPARSE-HIGH-FAIL", _x_3)));
    } else if (_t_2 === 4) {
      return __allocation_literal(34, ((_x_4) => $IO$print$("SPARSE-HIGH-FAIL", _x_4)));
    } else if (_t_2 === 5) {
      return __allocation_literal(35, ((_x_5) => $IO$print$("SPARSE-HIGH-FAIL", _x_5)));
    } else if (_t_2 === 6) {
      return __allocation_literal(36, ((_x_6) => $IO$print$("SPARSE-HIGH-FAIL", _x_6)));
    } else if (_t_2 === 7) {
      return __allocation_literal(37, ((_x_7) => $IO$print$("SPARSE-HIGH-FAIL", _x_7)));
    } else if (_t_2 === 8) {
      return __allocation_literal(38, ((_x_8) => $IO$print$("SPARSE-HIGH-FAIL", _x_8)));
    } else if (_t_2 === 9) {
      return __allocation_literal(39, ((_x_9) => $IO$print$("SPARSE-HIGH-FAIL", _x_9)));
    } else if (_t_2 === 10) {
      return __allocation_literal(40, ((_x_10) => $IO$print$("SPARSE-HIGH-FAIL", _x_10)));
    } else if (_t_2 === 11) {
      return __allocation_literal(41, ((_x_11) => $IO$print$("SPARSE-HIGH-FAIL", _x_11)));
    } else if (_t_2 === 12) {
      return __allocation_literal(42, ((_x_12) => $IO$print$("SPARSE-HIGH-FAIL", _x_12)));
    } else if (_t_2 === 13) {
      return __allocation_literal(43, ((_x_13) => $IO$print$("SPARSE-HIGH-FAIL", _x_13)));
    } else if (_t_2 === 14) {
      return __allocation_literal(44, ((_x_14) => $IO$print$("SPARSE-HIGH-FAIL", _x_14)));
    } else if (_t_2 === 15) {
      return __allocation_literal(45, ((_x_15) => $IO$print$("SPARSE-HIGH-FAIL", _x_15)));
    } else if (_t_2 === 16) {
      return __allocation_literal(46, ((_x_16) => $IO$print$("SPARSE-HIGH-FAIL", _x_16)));
    } else if (_t_2 === 17) {
      const _t_3 = _t_0["high_water"];
      if (_t_3 == 65538) {
        const _t_4 = _result_0["snd"];
        if (_t_4.$ === "Nil") {
          return __allocation_literal(47, ((_x_17) => $IO$print$("SPARSE-HIGH-PASS", _x_17)));
        } else {
          return __allocation_literal(48, ((_x_18) => $IO$print$("SPARSE-HIGH-FAIL", _x_18)));
        }
      } else {
        return __allocation_literal(49, ((_x_19) => $IO$print$("SPARSE-HIGH-FAIL", _x_19)));
      }
    } else {
      return __allocation_literal(50, ((_x_20) => $IO$print$("SPARSE-HIGH-FAIL", _x_20)));
    }
  } else {
    return __allocation_literal(51, ((_x_21) => $IO$print$("SPARSE-HIGH-FAIL", _x_21)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1260$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, __allocation_literal(52, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(53, ({$: "Nil"}))})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, __allocation_literal(54, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": array_node(_m_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0))), "metadata": ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0})));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_empty$(_depth_0) {
  const _x_0 = __allocation_literal(55, ({$: "None"}));
  return __allocation_literal(56, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)}));
}

function $IO$print$(_text_0, _k_0) {
  return __allocation_literal(57, ({ $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: __allocation_literal(58, ([(_text_0)])), kont: (_k_0) }));
}
function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return __allocation_literal(59, ([__allocation_literal(60, ({$: "None"}))]));
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0)), ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = __allocation_literal(61, ({$: "None"}));
  return __allocation_literal(62, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, __allocation_literal(63, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": __allocation_literal(64, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0})), "values": _values_0})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __allocation_literal(65, ({$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]})));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return __allocation_literal(66, ({$: "Tuple", "fst": __allocation_literal(67, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0})), "snd": ($List$reverse$(_values_0))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return __allocation_literal(68, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, __allocation_literal(69, ({$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]})));
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, __allocation_literal(70, ({$: "Nil"})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return __allocation_literal(71, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = __allocation_literal(72, ({$: "Con", "head": _h_0, "tail": _acc_0}));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return __allocation_literal(73, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(74, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, __allocation_literal(75, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "../bendvy-query-live-first/experiments/s-integrate/query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "../bendvy-query-live-first/experiments/s-integrate/query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return __allocation_literal(76, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0}));
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = __allocation_literal(77, ({$: "None"}));
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, __allocation_literal(78, (() => _x_1))));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($sparse_client$1260$(run_clo(__allocation_literal(79, ((_x_0) => {
  return run_clo(__allocation_literal(80, ((_x_1) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1260$(_x_0, _x_1);
})));
}))), run_clo(__allocation_literal(81, ((_x_2) => {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1260$(_x_2);
}))), __allocation_literal(82, ({$: "../bendvy-query-live-first/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0})), _flag_0, _owner_0, _a_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058struct_idx_return$(_index_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _m_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _a_0 = _t_0["fst"];
  const _value_0 = _t_0["snd"];
  const _x_0 = __allocation_literal(83, ({$: "Some", "value": _m_0}));
  return __allocation_literal(84, ({$: "../bendvy-query-live-first/experiments/s-integrate/query.StructColsState", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": (_aux_0[_index_0 % _aux_0.length] = _a_0, _aux_0), "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": __allocation_literal(85, ({$: "Con", "head": _value_0, "tail": _values_0}))}));
}

function $sparse_client$1260$(_get_0, _aux_get_0, _handle_0, _flag_0, _main_0, _aux_0) {
  return __allocation_literal(86, ({$: "Tuple", "fst": _main_0, "snd": __allocation_literal(87, ({$: "Tuple", "fst": _aux_0, "snd": 999}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058main_read$1260$(_owner_0, _token_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_get$(_owner_0);
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_read$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return __allocation_literal(88, ({$: "Tuple", "fst": __allocation_literal(89, ({$: "None"})), "snd": __allocation_literal(90, ({$: "None"}))}));
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058velocity_get$(_owner_1)));
  }
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_get$(_owner_0) {
  const _array_0 = _owner_0["coordinates"];
  const _frame_0 = _owner_0["frame"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_observed$(_frame_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047query$058aux_return$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return __allocation_literal(91, ({$: "Tuple", "fst": __allocation_literal(92, ({$: "Some", "value": _owner_0})), "snd": __allocation_literal(93, ({$: "Some", "value": _value_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058velocity_get$(_owner_0) {
  const _array_0 = _owner_0["rates"];
  const _moving_0 = _owner_0["moving"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058velocity_observed$(_moving_0, ($$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058position_observed$(_frame_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(94, ({$: "Tuple", "fst": __allocation_literal(95, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Position", "coordinates": _array_0, "frame": _frame_0})), "snd": __allocation_literal(96, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.PositionView", "coordinates": _values_0, "frame": _frame_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0) {
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_a$(__allocation_literal(97, ({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058velocity_observed$(_moving_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return __allocation_literal(98, ({$: "Tuple", "fst": __allocation_literal(99, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Velocity", "rates": _array_0, "moving": _moving_0})), "snd": __allocation_literal(100, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.VelocityView", "rates": _values_0, "moving": _moving_0}))}));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, __allocation_literal(101, ({$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, __allocation_literal(102, ({$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, __allocation_literal(103, ({$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]})));
}

function $$$$047bendvy$045query$045live$045first$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return __allocation_literal(104, ({$: "Tuple", "fst": _array_0, "snd": __allocation_literal(105, ({$: "../bendvy-query-live-first/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}))}));
}

// Cli
// ===

let cli_args = __allocation_literal(106, ([]));

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = __allocation_literal(107, ({ 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }))[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? __allocation_literal(108, ({ $: v ? "True" : "False" })) : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + __allocation_literal(109, ([...v])).map(__allocation_literal(110, ((c) =>
      show_chr(c.codePointAt(0), "\"")))).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map(__allocation_literal(111, ((x) => show_val(D, N, D[d + 1], x, 0)))).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = __allocation_literal(112, ({ i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" }));
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map(__allocation_literal(113, ((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return __allocation_literal(114, ([name, __allocation_literal(115, ({ args: __allocation_literal(116, ([...args])).map(__allocation_literal(117, ((a) => T[a]))), returns: T[ret] }))]));
      }))))).symbols;
    const fcntl = __allocation_literal(118, ((fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg)));
    globalThis.BEND_SYS = __allocation_literal(119, ({ ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: __allocation_literal(120, (() => ffi.read.i32(lib[err](), 0))) }));
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return __allocation_literal(121, ({ $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) }));
}

function io_done(value) {
  return __allocation_literal(122, ({ $: "Done", value }));
}

function io_tup(...xs) {
  return xs.reduceRight(__allocation_literal(123, ((snd, fst) => (__allocation_literal(124, ({ $: "Tuple", fst, snd }))))));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", __allocation_literal(125, ({ ignoreBOM: true }))).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = __allocation_literal(126, ({ $: "Nil" }));
  while (n > 0) {
    xs = __allocation_literal(127, ({ $: "Con", head: b[--n], tail: xs }));
  }
  return xs;
}

function io_unlist(xs) {
  const b = __allocation_literal(128, ([]));
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some(__allocation_literal(129, ((x) => x > 255))) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = __allocation_literal(130, ((p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256));
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? __allocation_literal(131, ([16, 2])) : __allocation_literal(132, ([2, 0]));
  b.set(__allocation_literal(133, ([...head, port >> 8, port & 255, ...part.map(Number)])));
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push(__allocation_literal(134, ({ fun, arg })));
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter(__allocation_literal(135, ((w) => w.fd !== undefined)));
  const top = fds.reduce(__allocation_literal(136, ((m, w) => Math.max(m, w.fd))), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = __allocation_literal(137, ((w) => (w.out ? len : 0) + (w.fd >> 3)));
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array(__allocation_literal(138, ([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)])));
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter(__allocation_literal(139, ((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  })));
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex(__allocation_literal(140, ((w) => (w.at ?? Infinity) <= (at ?? Infinity))));
  ws.splice(i + 1, 0, __allocation_literal(141, ({ fd, out, k, more, at })));
}

function io_run(m) {
  const io = __allocation_literal(142, ({ runs: __allocation_literal(143, ([])), live: 0, waits: __allocation_literal(144, ([])) }));
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), __allocation_literal(145, ((x) => (__allocation_literal(146, ({ $: "Emit", value: x }))))), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? __allocation_literal(147, ({}));
        if (need.time || need.read) {
          const more = __allocation_literal(148, (() => op.run(...op.args, op.kont)));
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);