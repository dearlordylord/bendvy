function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($run$(1, array_new(0, 100))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  const _x_3 = array_new(1, 100);
  return $IO$bind$(($run$(2, (_x_3[1 % _x_3.length] = 101, _x_3))), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  const _x_6 = array_new(2, 100);
  const _x_7 = (_x_6[1 % _x_6.length] = 101, _x_6);
  const _x_8 = (_x_7[2 % _x_7.length] = 102, _x_7);
  return $IO$bind$(($run$(4, (_x_8[3 % _x_8.length] = 103, _x_8))), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  const _x_11 = array_new(3, 100);
  const _x_12 = (_x_11[1 % _x_11.length] = 101, _x_11);
  const _x_13 = (_x_12[2 % _x_12.length] = 102, _x_12);
  const _x_14 = (_x_13[3 % _x_13.length] = 103, _x_13);
  const _x_15 = (_x_14[4 % _x_14.length] = 104, _x_14);
  const _x_16 = (_x_15[5 % _x_15.length] = 105, _x_15);
  const _x_17 = (_x_16[6 % _x_16.length] = 106, _x_16);
  return $IO$bind$(($run$(8, (_x_17[7 % _x_17.length] = 107, _x_17))), run_clo((_x_18) => {
  return run_clo((_x_19) => {
  return $IO$pure$({$: "Unit"}, _x_19);
});
}), _x_10);
});
}), _x_5);
});
}), _x_2);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $run$(_label_0, _array_0) {
  const _x_0 = array_new(2, 10);
  const _x_1 = (_x_0[1 % _x_0.length] = 11, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = 12, _x_1);
  return $taken$(_label_0, ($held$045adapter$058prototype_packed_prototype_journalledger_health_get$({$: "held-adapter.PrototypePackedHealthRowOwner", "levels": _array_0, "rawreserve": 4, "rawclass": 5, "a": 999, "b": 200, "c": 300, "d": 400, "cachedreserve": 77, "cachedclass": 88, "totals": (_x_2[3 % _x_2.length] = 13, _x_2), "epoch": 6, "ledger_cached": {$: "types.LedgerView", "totals": {$: "types.Four", "a": 900, "b": 901, "c": 902, "d": 903}, "epoch": 88}, "handle": {$: "storage.Handle", "namespace": 7, "id": 3}, "undo": {$: "held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": {$: "transaction.PrototypeFlatEnd"}}, "marks": {$: "transaction.PrototypeFlatMarksEnd"}}, {$: "types.VitalsToken"})));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $taken$(_label_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "types.Found") {
    const _retained_0 = _t_0["value"];
    return $observe$(_label_0, _retained_0, ($flushed$(($held$045adapter$058prototype_packed_prototype_journalledger_health_invoke$1260$(_owner_0)))));
  } else {
    return (_x_0) => $IO$print$("unexpected-read", _x_0);
  }
}

function $held$045adapter$058prototype_packed_prototype_journalledger_health_get$(_owner_0, _token_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return {$: "Tuple", "fst": {$: "held-adapter.PrototypePackedHealthRowOwner", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0, "totals": _totals_0, "epoch": _epoch_0, "ledger_cached": _ledger_cached_0, "handle": _handle_0, "undo": _undo_0, "marks": _marks_0}, "snd": {$: "types.Found", "value": {$: "types.VitalsView", "levels": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "reserve": _cachedreserve_0, "class": _cachedclass_0}}};
}

function $observe$(_label_0, _retained_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _array_0 = _t_0["levels"];
  const _frame_0 = _t_0["rawreserve"];
  const _class_0 = _t_0["rawclass"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _cf_0 = _t_0["cachedreserve"];
  const _cc_0 = _t_0["cachedclass"];
  const _totals_0 = _t_0["totals"];
  const _epoch_0 = _t_0["epoch"];
  const _lc_0 = _t_0["ledger_cached"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _t_2 = _t_0["undo"];
  const _t_3 = _t_2["pending"];
  if (!_t_3) {
    const _t_4 = _t_2["tail"];
    if (_t_4.$ === "transaction.PrototypeFlatPair") {
      const _space_0 = _t_4["namespace"];
      const _mid_0 = _t_4["id"];
      const _old_0 = _t_4["main_old"];
      const _ledgerold_0 = _t_4["ledger_old"];
      const _t_5 = _t_4["tail"];
      if (_t_5.$ === "transaction.PrototypeFlatPair") {
        const _ps_0 = _t_5["namespace"];
        const _pid_0 = _t_5["id"];
        const _prior_0 = _t_5["main_old"];
        const _ledgerprior_0 = _t_5["ledger_old"];
        const _t_6 = _t_5["tail"];
        if (_t_6.$ === "transaction.PrototypeFlatEnd") {
          const _t_7 = _t_0["marks"];
          if (_t_7.$ === "transaction.PrototypeFlatMark") {
            const _ms_0 = _t_7["namespace"];
            const _mi_0 = _t_7["id"];
            const _t_8 = _t_7["tail"];
            if (_t_8.$ === "transaction.PrototypeFlatMark") {
              const _pms_0 = _t_8["namespace"];
              const _pmi_0 = _t_8["id"];
              const _t_9 = _t_8["tail"];
              if (_t_9.$ === "transaction.PrototypeFlatMarksEnd") {
                const _value_0 = _result_0["snd"];
                const _x_0 = ($U32$show$(_value_0));
                const _x_1 = (_x_0 + "}");
                const _x_2 = ($U32$show$(_pmi_0));
                const _x_3 = ("]],\"clientValue\":" + _x_1);
                const _x_4 = (_x_2 + _x_3);
                const _x_5 = ($U32$show$(_pms_0));
                const _x_6 = ("," + _x_4);
                const _x_7 = (_x_5 + _x_6);
                const _x_8 = ($U32$show$(_mi_0));
                const _x_9 = ("],[" + _x_7);
                const _x_10 = (_x_8 + _x_9);
                const _x_11 = ($U32$show$(_ms_0));
                const _x_12 = ("," + _x_10);
                const _x_13 = (_x_11 + _x_12);
                const _x_14 = ($U32$show$(_ledgerprior_0));
                const _x_15 = ("]],\"marks\":[[" + _x_13);
                const _x_16 = (_x_14 + _x_15);
                const _x_17 = ($U32$show$(_prior_0));
                const _x_18 = ("," + _x_16);
                const _x_19 = (_x_17 + _x_18);
                const _x_20 = ($U32$show$(_pid_0));
                const _x_21 = ("," + _x_19);
                const _x_22 = (_x_20 + _x_21);
                const _x_23 = ($U32$show$(_ps_0));
                const _x_24 = ("," + _x_22);
                const _x_25 = (_x_23 + _x_24);
                const _x_26 = ($U32$show$(_ledgerold_0));
                const _x_27 = ("],[" + _x_25);
                const _x_28 = (_x_26 + _x_27);
                const _x_29 = ($U32$show$(_old_0));
                const _x_30 = ("," + _x_28);
                const _x_31 = (_x_29 + _x_30);
                const _x_32 = ($U32$show$(_mid_0));
                const _x_33 = ("," + _x_31);
                const _x_34 = (_x_32 + _x_33);
                const _x_35 = ($U32$show$(_space_0));
                const _x_36 = ("," + _x_34);
                const _x_37 = (_x_35 + _x_36);
                const _x_38 = ($U32$show$(_id_0));
                const _x_39 = ("],\"inverse\":[[" + _x_37);
                const _x_40 = (_x_38 + _x_39);
                const _x_41 = ($U32$show$(_ns_0));
                const _x_42 = ("," + _x_40);
                const _x_43 = (_x_41 + _x_42);
                const _x_44 = ($host$045render$058render_ledger$(_lc_0));
                const _x_45 = (",\"handle\":[" + _x_43);
                const _x_46 = (_x_44 + _x_45);
                const _x_47 = ($U32$show$(_epoch_0));
                const _x_48 = (",\"ledgerCached\":" + _x_46);
                const _x_49 = (_x_47 + _x_48);
                const _x_50 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_totals_0))))));
                const _x_51 = (",\"epoch\":" + _x_49);
                const _x_52 = (_x_50 + _x_51);
                const _x_53 = ($host$045render$058render_vitals$(_retained_0));
                const _x_54 = (",\"ledger\":" + _x_52);
                const _x_55 = (_x_53 + _x_54);
                const _x_56 = ($host$045render$058render_vitals$({$: "types.VitalsView", "levels": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "reserve": _cf_0, "class": _cc_0}));
                const _x_57 = (",\"retained\":" + _x_55);
                const _x_58 = (_x_56 + _x_57);
                const _x_59 = ($U32$show$(_class_0));
                const _x_60 = (",\"cached\":" + _x_58);
                const _x_61 = (_x_59 + _x_60);
                const _x_62 = ($U32$show$(_frame_0));
                const _x_63 = (",\"rawClass\":" + _x_61);
                const _x_64 = (_x_62 + _x_63);
                const _x_65 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_array_0))))));
                const _x_66 = (",\"rawReserve\":" + _x_64);
                const _x_67 = (_x_65 + _x_66);
                const _x_68 = ($U32$show$(_label_0));
                const _x_69 = (",\"array\":" + _x_67);
                const _x_70 = (_x_68 + _x_69);
                return (_x_71) => $IO$print$(("{\"length\":" + _x_70), _x_71);
              } else {
                return (_x_72) => $IO$print$("unexpected-row", _x_72);
              }
            } else {
              return (_x_73) => $IO$print$("unexpected-row", _x_73);
            }
          } else {
            return (_x_74) => $IO$print$("unexpected-row", _x_74);
          }
        } else {
          return (_x_75) => $IO$print$("unexpected-row", _x_75);
        }
      } else {
        return (_x_76) => $IO$print$("unexpected-row", _x_76);
      }
    } else {
      return (_x_77) => $IO$print$("unexpected-row", _x_77);
    }
  } else {
    return (_x_78) => $IO$print$("unexpected-row", _x_78);
  }
}

function $flushed$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _array_0 = _t_0["levels"];
  const _frame_0 = _t_0["rawreserve"];
  const _class_0 = _t_0["rawclass"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _cf_0 = _t_0["cachedreserve"];
  const _cc_0 = _t_0["cachedclass"];
  const _totals_0 = _t_0["totals"];
  const _epoch_0 = _t_0["epoch"];
  const _cached_0 = _t_0["ledger_cached"];
  const _handle_0 = _t_0["handle"];
  const _undo_0 = _t_0["undo"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "held-adapter.PrototypePackedHealthRowOwner", "levels": _array_0, "rawreserve": _frame_0, "rawclass": _class_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cf_0, "cachedclass": _cc_0, "totals": _totals_0, "epoch": _epoch_0, "ledger_cached": _cached_0, "handle": _handle_0, "undo": {$: "held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": ($held$045adapter$058prototype_pending_flush$1261$(_undo_0))}, "marks": _marks_0}, "snd": _value_0};
}

function $held$045adapter$058prototype_packed_prototype_journalledger_health_invoke$1260$(_owner_0) {
  return $client$1260$(_owner_0);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $host$045render$058render_list$12616$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12616$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $data$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": _head_0, "tail": ($data$(_tail_0))};
  }
}

function $Array$to_list$1260$(_a_0) {
  return $Array$to_list$go$1260$(_a_0, {$: "Nil"});
}

function $host$045render$058render_vitals$(_value_0) {
  const _levels_0 = _value_0["levels"];
  const _reserve_0 = _value_0["reserve"];
  const _class_0 = _value_0["class"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"levels\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_levels_0)), "tail": {$: "Con", "head": ",\"reserve\":", "tail": {$: "Con", "head": ($U32$show$(_reserve_0)), "tail": {$: "Con", "head": ",\"class\":", "tail": {$: "Con", "head": ($U32$show$(_class_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"totals\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_totals_0)), "tail": {$: "Con", "head": ",\"epoch\":", "tail": {$: "Con", "head": ($U32$show$(_epoch_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $held$045adapter$058prototype_pending_flush$1261$(_state_0) {
  const _t_0 = _state_0["pending"];
  if (!_t_0) {
    const _tail_0 = _state_0["tail"];
    return _tail_0;
  } else {
    const __3 = _state_0["namespace"];
    const __4 = _state_0["id"];
    const __5 = _state_0["old"];
    const _tail_1 = _state_0["tail"];
    return {$: "transaction.PrototypeFlatMain", "namespace": __3, "id": __4, "old": __5, "tail": _tail_1};
  }
}

function $client$1260$(_owner_0) {
  return $client_observed$1260$(($held$045adapter$058prototype_packed_prototype_journalledger_health_get$(($held$045adapter$058prototype_packed_prototype_journalledger_health_setledger$(($held$045adapter$058prototype_packed_prototype_journalledger_health_set$(($held$045adapter$058prototype_packed_prototype_journalledger_health_setledger$(($held$045adapter$058prototype_packed_prototype_journalledger_health_set$(_owner_0, {$: "types.VitalsToken"}, 500)), {$: "types.HealthLedgerToken"}, 700)), {$: "types.VitalsToken"}, 600)), {$: "types.HealthLedgerToken"}, 800)), {$: "types.VitalsToken"})));
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $host$045render$058render_concat$(_values_0) {
  return $host$045render$058render_chunks$(_values_0, "");
}

function $host$045render$058render_list_tail$12616$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($U32$show$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $Array$to_list$go$1260$($0, $1) {
  for (;;) {
    {
      const _a_0 = $0;
      const _acc_0 = $1;
      if (_a_0.length === 1) {
        const _x_0 = _a_0[0];
        return {$: "Con", "head": _x_0, "tail": _acc_0};
      } else {
        const _xs_0 = _a_0.slice(0, _a_0.length >> 1);
        const _ys_0 = _a_0.slice(_a_0.length >> 1);
        $0 = _xs_0;
        $1 = ($Array$to_list$go$1260$(_ys_0, _acc_0));
        continue;
      }
    }
  }
}

function $host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"a\":", "tail": {$: "Con", "head": ($U32$show$(_a_0)), "tail": {$: "Con", "head": ",\"b\":", "tail": {$: "Con", "head": ($U32$show$(_b_0)), "tail": {$: "Con", "head": ",\"c\":", "tail": {$: "Con", "head": ($U32$show$(_c_0)), "tail": {$: "Con", "head": ",\"d\":", "tail": {$: "Con", "head": ($U32$show$(_d_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $client_observed$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $client_after$1260$(_owner_0, _view_0);
}

function $held$045adapter$058prototype_packed_prototype_journalledger_health_setledger$(_owner_0, _token_0, _value_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $held$045adapter$058prototype_packed_prototype_journalledger_health_setledger_done$(_levels_0, _rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _epoch_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_1, {$: "Tuple", fst: _totals_0, snd: _totals_0[0 % _totals_0.length]});
}

function $held$045adapter$058prototype_packed_prototype_journalledger_health_set$(_owner_0, _token_0, _value_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $held$045adapter$058prototype_packed_prototype_journalledger_health_set_fused_done$(_totals_0, _epoch_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_1, {$: "Tuple", fst: _levels_0, snd: _levels_0[0 % _levels_0.length]});
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return {$: "Con", "head": _value_0, "tail": _acc_0};
  } else {
    return {$: "Con", "head": _value_0, "tail": {$: "Con", "head": ",", "tail": _acc_0}};
  }
}

function $client_after$1260$(_owner_0, _result_0) {
  if (_result_0.$ === "types.Found") {
    const _view_0 = _result_0["value"];
    return {$: "Tuple", "fst": _owner_0, "snd": ($view_sum$(_view_0))};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 0};
  }
}

function $held$045adapter$058prototype_packed_prototype_journalledger_health_setledger_done$(_levels_0, _rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _epoch_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_0, _result_0) {
  const _totals_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "held-adapter.PrototypePackedHealthRowOwner", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0, "totals": (_totals_0[0 % _totals_0.length] = _value_0, _totals_0), "epoch": _epoch_0, "ledger_cached": ($cached$045payload$058health_ledger_patch$(_cached_0, _value_0)), "handle": _handle_0, "undo": ($held$045adapter$058prototype_pending_ledger$1261$(_old_0, _undo_0)), "marks": _marks_0};
}

function $held$045adapter$058prototype_packed_prototype_journalledger_health_set_fused_done$(_totals_0, _epoch_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, _result_0) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _levels_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "held-adapter.PrototypePackedHealthRowOwner", "levels": (_levels_0[0 % _levels_0.length] = _value_0, _levels_0), "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0, "totals": _totals_0, "epoch": _epoch_0, "ledger_cached": _ledger_cached_0, "handle": {$: "storage.Handle", "namespace": _space_0, "id": _id_0}, "undo": ($held$045adapter$058prototype_pending_main$1261$(_space_0, _id_0, _old_0, _undo_0)), "marks": {$: "transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": _marks_0}};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $view_sum$(_view_0) {
  const _t_0 = _view_0["levels"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _frame_0 = _view_0["reserve"];
  const _class_0 = _view_0["class"];
  const _x_0 = ((_c_0 + _d_0) >>> 0);
  const _x_1 = ((_x_0 + _class_0) >>> 0);
  const _x_2 = ((_a_0 + _b_0) >>> 0);
  const _x_3 = ((_x_1 + _frame_0) >>> 0);
  return ((_x_2 + _x_3) >>> 0);
}

function $cached$045payload$058health_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return {$: "types.LedgerView", "totals": {$: "types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0}, "epoch": _epoch_0};
}

function $held$045adapter$058prototype_pending_ledger$1261$(_old_0, _state_0) {
  const _t_0 = _state_0["pending"];
  if (!_t_0) {
    const _tail_0 = _state_0["tail"];
    return {$: "held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": {$: "transaction.PrototypeFlatLedger", "old": _old_0, "tail": _tail_0}};
  } else {
    const __3 = _state_0["namespace"];
    const __4 = _state_0["id"];
    const __5 = _state_0["old"];
    const _tail_1 = _state_0["tail"];
    return {$: "held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": {$: "transaction.PrototypeFlatPair", "namespace": __3, "id": __4, "main_old": __5, "ledger_old": _old_0, "tail": _tail_1}};
  }
}

function $held$045adapter$058prototype_pending_main$1261$(_space_0, _id_0, _old_0, _state_0) {
  return {$: "held-adapter.PrototypePendingUndo", "pending": true, "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": ($held$045adapter$058prototype_pending_flush$1261$(_state_0))};
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);