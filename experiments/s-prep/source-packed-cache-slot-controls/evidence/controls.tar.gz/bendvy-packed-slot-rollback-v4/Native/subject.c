
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_CHR 13
#define CID_HELD_ADAPTER_PROTOTYPEPACKEDMOTIONROWOWNER 14
#define CID_TYPES_FOUND 15
#define CID_TYPES_MISMATCH 16
#define CID_TYPES_MISSING 17
#define CID_TYPES_POSITIONVIEW 18
#define CID_TYPES_POSITIONTOKEN 19
#define CID_TYPES_MOTIONLEDGER 20
#define CID_TYPES_LEDGERVIEW 21
#define CID_STORAGE_HANDLE 22
#define CID_TYPES_MOTIONSCHEMA 23
#define CID_TRANSACTION_PROTOTYPEFLATMAIN 24
#define CID_TRANSACTION_PROTOTYPEFLATLEDGER 25
#define CID_TRANSACTION_PROTOTYPEFLATEND 26
#define CID_TRANSACTION_PROTOTYPEFLATMARK 27
#define CID_TRANSACTION_PROTOTYPEFLATMARKSEND 28
#define CID_TYPES_FOUR 29
#define CID_TRANSACTION_COMMITTED 30
#define CID_TRANSACTION_REVERTED 31
#define CID_STORAGE_WORLD 32
#define CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT 33
#define CID_TYPES_VELOCITY 34
#define CID_TYPES_SELECTED 35
#define CID_CACHE_CACHE 36
#define CID_TYPES_MOTIONON 37
#define CID_TYPES_MOTIONOFF 38
#define CID_STORAGE_SPAWN 39
#define CID_STORAGE_INSERTMAIN 40
#define CID_STORAGE_INSERTFLAG 41
#define CID_STORAGE_REMOVEMAIN 42
#define CID_STORAGE_REMOVEFLAG 43
#define CID_STORAGE_DESPAWN 44
#define CID_TRANSACTION_TX 45
#define CID_TRANSACTION_PROTOTYPEFLATTX 46
#define CID_STORAGE_ROWS 47
#define CID_STORAGE_METADATACOLUMNS 48
#define CID_NIL 49
#define CID_CON 50
#define CID_STORAGE_BUNDLE 51
#define CID_TRANSACTION_MAININVERSE 52
#define CID_TRANSACTION_LEDGERINVERSE 53
#define CID_WNIL 54
#define CID_IO_PRINT 55
#define FID_TRANSACTION_STORAGE_SET_LEDGER0_2 0
#define FID_TRANSACTION_STORAGE_SET_LEDGER0_2_C28 1
#define FID_TRANSACTION_STORAGE_SET_LEDGER0_2_K29 2
#define FID_TRANSACTION_STORAGE_SET_MAIN0_2 3
#define FID_TRANSACTION_STORAGE_SET_MAIN0_2_C32 4
#define FID_TRANSACTION_STORAGE_SET_MAIN0_2_K33 5
#define FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE 6
#define FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE_K46 7
#define FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE 8
#define FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE_K48 9
#define FID_U32_SHOW_GO 10
#define FID_TRANSACTION_UNWIND_2 11
#define FID_TRANSACTION_UNWIND_2_K57 12
#define FID_TRANSACTION_UNWIND_2_K58 13
#define FID_NAT_SHOW_FIN 14
#define FID_HOST_RENDER_RENDER_FOUR 15
#define FID_HOST_RENDER_RENDER_FOUR_K62 16
#define FID_HOST_RENDER_RENDER_FOUR_K63 17
#define FID_HOST_RENDER_RENDER_FOUR_K64 18
#define FID_HOST_RENDER_RENDER_FOUR_K65 19
#define FID_ARRAY_TO_LIST_GO_0 20
#define FID_ARRAY_TO_LIST_GO_0_K67 21
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16 22
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16_K69 23
#define FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0 24
#define FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0_K75 25
#define FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0 26
#define FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K77 27
#define FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K78 28
#define FID_HOST_RENDER_RENDER_LEDGER 29
#define FID_HOST_RENDER_RENDER_LEDGER_K82 30
#define FID_HOST_RENDER_RENDER_LEDGER_K83 31
#define FID_NAT_SHOW 32
#define FID_HOST_RENDER_RENDER_POSITION 33
#define FID_HOST_RENDER_RENDER_POSITION_K86 34
#define FID_HOST_RENDER_RENDER_POSITION_K87 35
#define FID_ARRAY_TO_LIST_0 36
#define FID_DATA 37
#define FID_DATA_K90 38
#define FID_HOST_RENDER_RENDER_LIST_16 39
#define FID_HOST_RENDER_RENDER_LIST_16_K92 40
#define FID_U32_SHOW 41
#define FID_STRING_APPEND 42
#define FID_STRING_APPEND_K95 43
#define FID_STORAGE_SLOTS_EMPTY 44
#define FID_STORAGE_SLOTS_EMPTY_K98 45
#define FID_STORAGE_SLOTS_EMPTY_K99 46
#define FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0 47
#define FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K101 48
#define FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K102 49
#define FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE 50
#define FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE_K104 51
#define FID_RUN 52
#define FID_RUN_K288 53
#define FID_RUN_K289 54
#define FID_RUN_K290 55
#define FID_RUN_K291 56
#define FID_RUN_K292 57
#define FID_RUN_K293 58
#define FID_RUN_K294 59
#define FID_RUN_K295 60
#define FID_RUN_K296 61
#define FID_RUN_K297 62
#define FID_RUN_K298 63
#define FID_RUN_K299 64
#define FID_RUN_K300 65
#define FID_RUN_K301 66
#define FID_RUN_K302 67
#define FID_RUN_K303 68
#define FID_RUN_K304 69
#define FID_RUN_K305 70
#define FID_RUN_K306 71
#define FID_RUN_K307 72
#define FID_RUN_K308 73
#define FID_RUN_K309 74
#define FID_RUN_K310 75
#define FID_RUN_K311 76
#define FID_RUN_K312 77
#define FID_RUN_K313 78
#define FID_RUN_K314 79
#define FID_RUN_K315 80
#define FID_RUN_K316 81
#define FID_RUN_K317 82
#define FID_RUN_K318 83
#define FID_RUN_K319 84
#define FID_RUN_K320 85
#define FID_RUN_K321 86
#define FID_RUN_K322 87
#define FID_RUN_K323 88
#define FID_RUN_K324 89
#define FID_RUN_K325 90
#define FID_RUN_K326 91
#define FID_RUN_K327 92
#define FID_RUN_K328 93
#define FID_RUN_K329 94
#define FID_RUN_K330 95
#define FID_RUN_K331 96
#define FID_RUN_K332 97
#define FID_RUN_K333 98
#define FID_RUN_K334 99
#define FID_RUN_K335 100
#define FID_RUN_K336 101
#define FID_RUN_K337 102
#define FID_RUN_K338 103
#define FID_RUN_K339 104
#define FID_RUN_K340 105
#define FID_RUN_K341 106
#define FID_RUN_K342 107
#define FID_RUN_K343 108
#define FID_RUN_K344 109
#define FID_RUN_K345 110
#define FID_RUN_K346 111
#define FID_RUN_K347 112
#define FID_IO_BIND 113
#define FID_IO_BIND_C349 114
#define FID_IO_BIND_K350 115
#define FID_MAIN 116
#define FID_MAIN_K352 117
#define FID_MAIN_C353 118
#define FID_MAIN_C354 119
#define FID_MAIN_K355 120
#define FID_MAIN_C356 121
#define FID_MAIN_C357 122
#define FID_MAIN_K358 123
#define FID_MAIN_C359 124
#define FID_MAIN_C360 125
#define FID_MAIN_K361 126
#define FID_MAIN_C362 127
#define FID_MAIN_C363 128
#define FID_MAIN_C364 129
#define FID_IO_PRINT 130
#define FID_IO_EMIT 131
#define FID_CLO_APPLY 132
#define FID_EXIT 133
#define FID_ENTER 134
CONSTV u8 FID_T[][3] = { { 22, 0, 2 }, { 2, 0, 2 }, { 14, 1, 2 }, { 24, 0, 2 }, { 2, 0, 2 }, { 17, 1, 2 }, { 22, 0, 2 }, { 23, 23, 2 }, { 24, 0, 2 }, { 23, 23, 2 }, { 3, 0, 2 }, { 22, 0, 2 }, { 22, 21, 2 }, { 22, 21, 2 }, { 4, 0, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 1, 0, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 4, 1, 2 }, { 2, 1, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 27, 0, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 27, 0, 2 }, { 21, 21, 2 }, { 2, 0, 2 }, { 25, 1, 2 }, { 26, 1, 2 }, { 33, 27, 2 }, { 31, 25, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 24, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 0 }, { 2, 0 }, { 2, 0 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 1, 0 }, { 18, 0 }, { 1, 0 }, { 0, 0 }, { 0, 0 }, { 5, 0 }, { 0, 0 }, { 2, 0 }, { 5, 0 }, { 2, 0 }, { 0, 0 }, { 4, 0 }, { 2, 0 }, { 0, 0 }, { 3, 0 }, { 0, 0 }, { 4, 0 }, { 4, 0 }, { 1, 0 }, { 15, 0 }, { 7, 0 }, { 2, 0 }, { 1, 0 }, { 2, 0 }, { 0, 0 }, { 0, 0 }, { 7, 0 }, { 2, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 1, 0 }, { 6, 0 }, { 7, 0 }, { 9, 0 }, { 4, 0 }, { 0, 0 }, { 2, 0 }, { 6, 0 }, { 2, 0 }, { 1, 0 }, { 0, 0 }, { 2, 0 } };
#define STAT_LEN 410

#define WL_RESW 27
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25; (V)[26] = r26;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25]; r26 = (V)[26];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26

#define WL_TABLE WL_X(FID_TRANSACTION_STORAGE_SET_LEDGER0_2) WL_X(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_C28) WL_X(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_K29) WL_X(FID_TRANSACTION_STORAGE_SET_MAIN0_2) WL_X(FID_TRANSACTION_STORAGE_SET_MAIN0_2_C32) WL_X(FID_TRANSACTION_STORAGE_SET_MAIN0_2_K33) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE_K46) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE_K48) WL_X(FID_U32_SHOW_GO) WL_X(FID_TRANSACTION_UNWIND_2) WL_X(FID_TRANSACTION_UNWIND_2_K57) WL_X(FID_TRANSACTION_UNWIND_2_K58) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_HOST_RENDER_RENDER_FOUR) WL_X(FID_HOST_RENDER_RENDER_FOUR_K62) WL_X(FID_HOST_RENDER_RENDER_FOUR_K63) WL_X(FID_HOST_RENDER_RENDER_FOUR_K64) WL_X(FID_HOST_RENDER_RENDER_FOUR_K65) WL_X(FID_ARRAY_TO_LIST_GO_0) WL_X(FID_ARRAY_TO_LIST_GO_0_K67) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K69) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0_K75) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K77) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K78) WL_X(FID_HOST_RENDER_RENDER_LEDGER) WL_X(FID_HOST_RENDER_RENDER_LEDGER_K82) WL_X(FID_HOST_RENDER_RENDER_LEDGER_K83) WL_X(FID_NAT_SHOW) WL_X(FID_HOST_RENDER_RENDER_POSITION) WL_X(FID_HOST_RENDER_RENDER_POSITION_K86) WL_X(FID_HOST_RENDER_RENDER_POSITION_K87) WL_X(FID_ARRAY_TO_LIST_0) WL_X(FID_DATA) WL_X(FID_DATA_K90) WL_X(FID_HOST_RENDER_RENDER_LIST_16) WL_X(FID_HOST_RENDER_RENDER_LIST_16_K92) WL_X(FID_U32_SHOW) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K95) WL_X(FID_STORAGE_SLOTS_EMPTY) WL_X(FID_STORAGE_SLOTS_EMPTY_K98) WL_X(FID_STORAGE_SLOTS_EMPTY_K99) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K101) WL_X(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K102) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE) WL_X(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE_K104) WL_X(FID_RUN) WL_X(FID_RUN_K288) WL_X(FID_RUN_K289) WL_X(FID_RUN_K290) WL_X(FID_RUN_K291) WL_X(FID_RUN_K292) WL_X(FID_RUN_K293) WL_X(FID_RUN_K294) WL_X(FID_RUN_K295) WL_X(FID_RUN_K296) WL_X(FID_RUN_K297) WL_X(FID_RUN_K298) WL_X(FID_RUN_K299) WL_X(FID_RUN_K300) WL_X(FID_RUN_K301) WL_X(FID_RUN_K302) WL_X(FID_RUN_K303) WL_X(FID_RUN_K304) WL_X(FID_RUN_K305) WL_X(FID_RUN_K306) WL_X(FID_RUN_K307) WL_X(FID_RUN_K308) WL_X(FID_RUN_K309) WL_X(FID_RUN_K310) WL_X(FID_RUN_K311) WL_X(FID_RUN_K312) WL_X(FID_RUN_K313) WL_X(FID_RUN_K314) WL_X(FID_RUN_K315) WL_X(FID_RUN_K316) WL_X(FID_RUN_K317) WL_X(FID_RUN_K318) WL_X(FID_RUN_K319) WL_X(FID_RUN_K320) WL_X(FID_RUN_K321) WL_X(FID_RUN_K322) WL_X(FID_RUN_K323) WL_X(FID_RUN_K324) WL_X(FID_RUN_K325) WL_X(FID_RUN_K326) WL_X(FID_RUN_K327) WL_X(FID_RUN_K328) WL_X(FID_RUN_K329) WL_X(FID_RUN_K330) WL_X(FID_RUN_K331) WL_X(FID_RUN_K332) WL_X(FID_RUN_K333) WL_X(FID_RUN_K334) WL_X(FID_RUN_K335) WL_X(FID_RUN_K336) WL_X(FID_RUN_K337) WL_X(FID_RUN_K338) WL_X(FID_RUN_K339) WL_X(FID_RUN_K340) WL_X(FID_RUN_K341) WL_X(FID_RUN_K342) WL_X(FID_RUN_K343) WL_X(FID_RUN_K344) WL_X(FID_RUN_K345) WL_X(FID_RUN_K346) WL_X(FID_RUN_K347) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C349) WL_X(FID_IO_BIND_K350) WL_X(FID_MAIN) WL_X(FID_MAIN_K352) WL_X(FID_MAIN_C353) WL_X(FID_MAIN_C354) WL_X(FID_MAIN_K355) WL_X(FID_MAIN_C356) WL_X(FID_MAIN_C357) WL_X(FID_MAIN_K358) WL_X(FID_MAIN_C359) WL_X(FID_MAIN_C360) WL_X(FID_MAIN_K361) WL_X(FID_MAIN_C362) WL_X(FID_MAIN_C363) WL_X(FID_MAIN_C364) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 0

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 44ull, term_pak(CID_SNIL, 0), 58ull, term_pak(CID_SNIL, 0), 34ull, term_ctr(CID_SCON, STAT_OFF + 2), 97ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 6), 123ull, term_ctr(CID_SCON, STAT_OFF + 8), 98ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 12), 44ull, term_ctr(CID_SCON, STAT_OFF + 14), 99ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 18), 44ull, term_ctr(CID_SCON, STAT_OFF + 20), 100ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 24), 44ull, term_ctr(CID_SCON, STAT_OFF + 26), 125ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 30), term_pak(CID_NIL, 0), 48ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 4), 108ull, term_ctr(CID_SCON, STAT_OFF + 36), 97ull, term_ctr(CID_SCON, STAT_OFF + 38), 116ull, term_ctr(CID_SCON, STAT_OFF + 40), 111ull, term_ctr(CID_SCON, STAT_OFF + 42), 116ull, term_ctr(CID_SCON, STAT_OFF + 44), 34ull, term_ctr(CID_SCON, STAT_OFF + 46), 123ull, term_ctr(CID_SCON, STAT_OFF + 48), 104ull, term_ctr(CID_SCON, STAT_OFF + 4), 99ull, term_ctr(CID_SCON, STAT_OFF + 52), 111ull, term_ctr(CID_SCON, STAT_OFF + 54), 112ull, term_ctr(CID_SCON, STAT_OFF + 56), 101ull, term_ctr(CID_SCON, STAT_OFF + 58), 34ull, term_ctr(CID_SCON, STAT_OFF + 60), 44ull, term_ctr(CID_SCON, STAT_OFF + 62), 101ull, term_ctr(CID_SCON, STAT_OFF + 36), 116ull, term_ctr(CID_SCON, STAT_OFF + 66), 97ull, term_ctr(CID_SCON, STAT_OFF + 68), 110ull, term_ctr(CID_SCON, STAT_OFF + 70), 105ull, term_ctr(CID_SCON, STAT_OFF + 72), 100ull, term_ctr(CID_SCON, STAT_OFF + 74), 114ull, term_ctr(CID_SCON, STAT_OFF + 76), 111ull, term_ctr(CID_SCON, STAT_OFF + 78), 111ull, term_ctr(CID_SCON, STAT_OFF + 80), 99ull, term_ctr(CID_SCON, STAT_OFF + 82), 34ull, term_ctr(CID_SCON, STAT_OFF + 84), 123ull, term_ctr(CID_SCON, STAT_OFF + 86), 101ull, term_ctr(CID_SCON, STAT_OFF + 4), 109ull, term_ctr(CID_SCON, STAT_OFF + 90), 97ull, term_ctr(CID_SCON, STAT_OFF + 92), 114ull, term_ctr(CID_SCON, STAT_OFF + 94), 102ull, term_ctr(CID_SCON, STAT_OFF + 96), 34ull, term_ctr(CID_SCON, STAT_OFF + 98), 44ull, term_ctr(CID_SCON, STAT_OFF + 100), 91ull, term_pak(CID_SNIL, 0), 93ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 106), term_pak(CID_NIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 24), 104ull, term_ctr(CID_SCON, STAT_OFF + 110), 99ull, term_ctr(CID_SCON, STAT_OFF + 112), 97ull, term_ctr(CID_SCON, STAT_OFF + 114), 67ull, term_ctr(CID_SCON, STAT_OFF + 116), 114ull, term_ctr(CID_SCON, STAT_OFF + 118), 101ull, term_ctr(CID_SCON, STAT_OFF + 120), 103ull, term_ctr(CID_SCON, STAT_OFF + 122), 100ull, term_ctr(CID_SCON, STAT_OFF + 124), 101ull, term_ctr(CID_SCON, STAT_OFF + 126), 108ull, term_ctr(CID_SCON, STAT_OFF + 128), 34ull, term_ctr(CID_SCON, STAT_OFF + 130), 44ull, term_ctr(CID_SCON, STAT_OFF + 132), 114ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 136), 103ull, term_ctr(CID_SCON, STAT_OFF + 138), 100ull, term_ctr(CID_SCON, STAT_OFF + 140), 101ull, term_ctr(CID_SCON, STAT_OFF + 142), 108ull, term_ctr(CID_SCON, STAT_OFF + 144), 34ull, term_ctr(CID_SCON, STAT_OFF + 146), 44ull, term_ctr(CID_SCON, STAT_OFF + 148), 103ull, term_ctr(CID_SCON, STAT_OFF + 110), 110ull, term_ctr(CID_SCON, STAT_OFF + 152), 97ull, term_ctr(CID_SCON, STAT_OFF + 154), 104ull, term_ctr(CID_SCON, STAT_OFF + 156), 99ull, term_ctr(CID_SCON, STAT_OFF + 158), 34ull, term_ctr(CID_SCON, STAT_OFF + 160), 44ull, term_ctr(CID_SCON, STAT_OFF + 162), 100ull, term_ctr(CID_SCON, STAT_OFF + 110), 100ull, term_ctr(CID_SCON, STAT_OFF + 166), 97ull, term_ctr(CID_SCON, STAT_OFF + 168), 34ull, term_ctr(CID_SCON, STAT_OFF + 170), 44ull, term_ctr(CID_SCON, STAT_OFF + 172), 103ull, term_ctr(CID_SCON, STAT_OFF + 4), 110ull, term_ctr(CID_SCON, STAT_OFF + 176), 105ull, term_ctr(CID_SCON, STAT_OFF + 178), 100ull, term_ctr(CID_SCON, STAT_OFF + 180), 110ull, term_ctr(CID_SCON, STAT_OFF + 182), 101ull, term_ctr(CID_SCON, STAT_OFF + 184), 112ull, term_ctr(CID_SCON, STAT_OFF + 186), 34ull, term_ctr(CID_SCON, STAT_OFF + 188), 44ull, term_ctr(CID_SCON, STAT_OFF + 190), 103ull, term_ctr(CID_SCON, STAT_OFF + 52), 105ull, term_ctr(CID_SCON, STAT_OFF + 194), 104ull, term_ctr(CID_SCON, STAT_OFF + 196), 34ull, term_ctr(CID_SCON, STAT_OFF + 198), 44ull, term_ctr(CID_SCON, STAT_OFF + 200), 116ull, term_ctr(CID_SCON, STAT_OFF + 52), 112ull, term_ctr(CID_SCON, STAT_OFF + 204), 101ull, term_ctr(CID_SCON, STAT_OFF + 206), 100ull, term_ctr(CID_SCON, STAT_OFF + 208), 34ull, term_ctr(CID_SCON, STAT_OFF + 210), 44ull, term_ctr(CID_SCON, STAT_OFF + 212), 121ull, term_ctr(CID_SCON, STAT_OFF + 4), 116ull, term_ctr(CID_SCON, STAT_OFF + 216), 105ull, term_ctr(CID_SCON, STAT_OFF + 218), 99ull, term_ctr(CID_SCON, STAT_OFF + 220), 97ull, term_ctr(CID_SCON, STAT_OFF + 222), 112ull, term_ctr(CID_SCON, STAT_OFF + 224), 97ull, term_ctr(CID_SCON, STAT_OFF + 226), 99ull, term_ctr(CID_SCON, STAT_OFF + 228), 34ull, term_ctr(CID_SCON, STAT_OFF + 230), 44ull, term_ctr(CID_SCON, STAT_OFF + 232), 116ull, term_ctr(CID_SCON, STAT_OFF + 4), 120ull, term_ctr(CID_SCON, STAT_OFF + 236), 101ull, term_ctr(CID_SCON, STAT_OFF + 238), 110ull, term_ctr(CID_SCON, STAT_OFF + 240), 34ull, term_ctr(CID_SCON, STAT_OFF + 242), 44ull, term_ctr(CID_SCON, STAT_OFF + 244), 99ull, term_ctr(CID_SCON, STAT_OFF + 90), 97ull, term_ctr(CID_SCON, STAT_OFF + 248), 112ull, term_ctr(CID_SCON, STAT_OFF + 250), 115ull, term_ctr(CID_SCON, STAT_OFF + 252), 101ull, term_ctr(CID_SCON, STAT_OFF + 254), 109ull, term_ctr(CID_SCON, STAT_OFF + 256), 97ull, term_ctr(CID_SCON, STAT_OFF + 258), 110ull, term_ctr(CID_SCON, STAT_OFF + 260), 34ull, term_ctr(CID_SCON, STAT_OFF + 262), 44ull, term_ctr(CID_SCON, STAT_OFF + 264), 110ull, term_ctr(CID_SCON, STAT_OFF + 110), 105ull, term_ctr(CID_SCON, STAT_OFF + 268), 97ull, term_ctr(CID_SCON, STAT_OFF + 270), 116ull, term_ctr(CID_SCON, STAT_OFF + 272), 101ull, term_ctr(CID_SCON, STAT_OFF + 274), 114ull, term_ctr(CID_SCON, STAT_OFF + 276), 34ull, term_ctr(CID_SCON, STAT_OFF + 278), 44ull, term_ctr(CID_SCON, STAT_OFF + 280), 99ull, term_ctr(CID_SCON, STAT_OFF + 116), 34ull, term_ctr(CID_SCON, STAT_OFF + 284), 44ull, term_ctr(CID_SCON, STAT_OFF + 286), 70ull, term_ctr(CID_SCON, STAT_OFF + 96), 119ull, term_ctr(CID_SCON, STAT_OFF + 290), 97ull, term_ctr(CID_SCON, STAT_OFF + 292), 114ull, term_ctr(CID_SCON, STAT_OFF + 294), 34ull, term_ctr(CID_SCON, STAT_OFF + 296), 44ull, term_ctr(CID_SCON, STAT_OFF + 298), 97ull, term_ctr(CID_SCON, STAT_OFF + 216), 114ull, term_ctr(CID_SCON, STAT_OFF + 302), 114ull, term_ctr(CID_SCON, STAT_OFF + 304), 97ull, term_ctr(CID_SCON, STAT_OFF + 306), 34ull, term_ctr(CID_SCON, STAT_OFF + 308), 44ull, term_ctr(CID_SCON, STAT_OFF + 310), 103ull, term_ctr(CID_SCON, STAT_OFF + 204), 110ull, term_ctr(CID_SCON, STAT_OFF + 314), 101ull, term_ctr(CID_SCON, STAT_OFF + 316), 108ull, term_ctr(CID_SCON, STAT_OFF + 318), 34ull, term_ctr(CID_SCON, STAT_OFF + 320), 123ull, term_ctr(CID_SCON, STAT_OFF + 322), 100ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 326), 114ull, term_ctr(CID_SCON, STAT_OFF + 328), 111ull, term_ctr(CID_SCON, STAT_OFF + 330), 119ull, term_ctr(CID_SCON, STAT_OFF + 332), 45ull, term_ctr(CID_SCON, STAT_OFF + 334), 100ull, term_ctr(CID_SCON, STAT_OFF + 336), 101ull, term_ctr(CID_SCON, STAT_OFF + 338), 116ull, term_ctr(CID_SCON, STAT_OFF + 340), 114ull, term_ctr(CID_SCON, STAT_OFF + 342), 101ull, term_ctr(CID_SCON, STAT_OFF + 344), 118ull, term_ctr(CID_SCON, STAT_OFF + 346), 101ull, term_ctr(CID_SCON, STAT_OFF + 348), 114ull, term_ctr(CID_SCON, STAT_OFF + 350), 45ull, term_ctr(CID_SCON, STAT_OFF + 352), 100ull, term_ctr(CID_SCON, STAT_OFF + 354), 101ull, term_ctr(CID_SCON, STAT_OFF + 356), 116ull, term_ctr(CID_SCON, STAT_OFF + 358), 99ull, term_ctr(CID_SCON, STAT_OFF + 360), 101ull, term_ctr(CID_SCON, STAT_OFF + 362), 112ull, term_ctr(CID_SCON, STAT_OFF + 364), 120ull, term_ctr(CID_SCON, STAT_OFF + 366), 101ull, term_ctr(CID_SCON, STAT_OFF + 368), 110ull, term_ctr(CID_SCON, STAT_OFF + 370), 117ull, term_ctr(CID_SCON, STAT_OFF + 372), term_pak(CID_STORAGE_DESPAWN, 2ull), term_pak(CID_NIL, 0), term_pak(CID_STORAGE_DESPAWN, 3ull), term_pak(CID_NIL, 0), 44ull, term_pak(CID_NIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 326), 101ull, term_ctr(CID_SCON, STAT_OFF + 382), 114ull, term_ctr(CID_SCON, STAT_OFF + 384), 45ull, term_ctr(CID_SCON, STAT_OFF + 386), 100ull, term_ctr(CID_SCON, STAT_OFF + 388), 101ull, term_ctr(CID_SCON, STAT_OFF + 390), 116ull, term_ctr(CID_SCON, STAT_OFF + 392), 99ull, term_ctr(CID_SCON, STAT_OFF + 394), 101ull, term_ctr(CID_SCON, STAT_OFF + 396), 112ull, term_ctr(CID_SCON, STAT_OFF + 398), 120ull, term_ctr(CID_SCON, STAT_OFF + 400), 101ull, term_ctr(CID_SCON, STAT_OFF + 402), 110ull, term_ctr(CID_SCON, STAT_OFF + 404), 117ull, term_ctr(CID_SCON, STAT_OFF + 406) };

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u32 r3) {
  u32 wpoll = 0;
  Term _v_3 = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  u32 _epoch_0 = r0;
  u32 _value_1 = r1;
  Term _result_0 = r2;
  u32 _result_1 = r3;
  WL_SPIN
    Term _at_2 = blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 0ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _value_1);
    _v_3 = _result_0;
    _v_4 = _epoch_0;
    _v_5 = _result_1;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _view_0 = r0;
  u32 _view_1 = r1;
  u32 _view_2 = r2;
  u32 _view_3 = r3;
  u32 _view_4 = r4;
  u32 _value_1 = r5;
  WL_SPIN
    _v_10 = _value_1;
    _v_11 = _view_1;
    _v_12 = _view_2;
    _v_13 = _view_3;
    _v_14 = _view_4;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  Term _owner_7 = r0;
  u32 _owner_8 = r1;
  u32 _value_1 = r2;
  WL_SPIN
    Term _at_0 = blk_loc(e.mem, _owner_7);
    Term _at_1 = blk_at(_owner_7, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_0[3];
    if (spin_1(e, _o_0, _owner_8, _value_1, _owner_7, _c_0) == 0) {
      return 0;
    }
    _v_9 = _o_0[0];
    _v_10 = _o_0[1];
    _v_11 = _o_0[2];
    _v_6 = _v_9;
    _v_7 = _v_10;
    _v_8 = _v_11;
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u32 r7, u32 r8) {
  u32 wpoll = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _cached_0 = r0;
  u32 _cached_1 = r1;
  u32 _cached_2 = r2;
  u32 _cached_3 = r3;
  u32 _cached_4 = r4;
  u32 _value_2 = r5;
  Term _result_0 = r6;
  u32 _result_1 = r7;
  u32 _result_2 = r8;
  WL_SPIN
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_2[5];
    if (spin_2(e, _o_2, _cached_0, _cached_1, _cached_2, _cached_3, _cached_4, _value_2) == 0) {
      return 0;
    }
    _v_33 = _o_2[0];
    _v_34 = _o_2[1];
    _v_35 = _o_2[2];
    _v_36 = _o_2[3];
    _v_37 = _o_2[4];
    _v_28 = _v_33;
    _v_29 = _v_34;
    _v_30 = _v_35;
    _v_31 = _v_36;
    _v_32 = _v_37;
    _v_20 = _result_0;
    _v_21 = _result_1;
    _v_22 = _v_28;
    _v_23 = _v_29;
    _v_24 = _v_30;
    _v_25 = _v_31;
    _v_26 = _v_32;
    _v_27 = _result_2;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_3 = 0;
    } else {
      _v_3 = _b_0;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _owner_7 = r0;
  u32 _owner_8 = r1;
  u32 _owner_9 = r2;
  u32 _owner_10 = r3;
  u32 _owner_11 = r4;
  u32 _owner_12 = r5;
  u32 _owner_13 = r6;
  u32 _value_1 = r7;
  WL_SPIN
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_0[3];
    if (spin_3(e, _o_0, _owner_7, _owner_8, _value_1) == 0) {
      return 0;
    }
    _v_19 = _o_0[0];
    _v_20 = _o_0[1];
    _v_21 = _o_0[2];
    _v_16 = _v_19;
    _v_17 = _v_20;
    _v_18 = _v_21;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_1[8];
    if (spin_4(e, _o_1, _owner_9, _owner_10, _owner_11, _owner_12, _owner_13, _value_1, _v_16, _v_17, _v_18) == 0) {
      return 0;
    }
    _v_22 = _o_1[0];
    _v_23 = _o_1[1];
    _v_24 = _o_1[2];
    _v_25 = _o_1[3];
    _v_26 = _o_1[4];
    _v_27 = _o_1[5];
    _v_28 = _o_1[6];
    _v_29 = _o_1[7];
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    _v_14 = _v_28;
    _v_15 = _v_29;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u32 r7) {
  u32 wpoll = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _rawframe_0 = r0;
  u32 _b_0 = r1;
  u32 _c_1 = r2;
  u32 _d_0 = r3;
  u32 _cachedframe_0 = r4;
  u32 _value_1 = r5;
  Term _result_0 = r6;
  u32 _result_1 = r7;
  WL_SPIN
    Term _at_2 = blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 0ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _value_1);
    _v_8 = _result_0;
    _v_9 = _rawframe_0;
    _v_10 = _value_1;
    _v_11 = _b_0;
    _v_12 = _c_1;
    _v_13 = _d_0;
    _v_14 = _cachedframe_0;
    _v_15 = _result_1;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _value_2 = r7;
  WL_SPIN
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[8];
    if (spin_6(e, _o_0, _owner_0, _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _value_2) == 0) {
      return 0;
    }
    _v_16 = _o_0[0];
    _v_17 = _o_0[1];
    _v_18 = _o_0[2];
    _v_19 = _o_0[3];
    _v_20 = _o_0[4];
    _v_21 = _o_0[5];
    _v_22 = _o_0[6];
    _v_23 = _o_0[7];
    _v_8 = _v_16;
    _v_9 = _v_17;
    _v_10 = _v_18;
    _v_11 = _v_19;
    _v_12 = _v_20;
    _v_13 = _v_21;
    _v_14 = _v_22;
    _v_15 = _v_23;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, Term r4, Term r5, Term r6, Term r7, u32 r8, Term r9, u32 r10, Term r11, Term r12, Term r13, Term r14) {
  u32 wpoll = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  u32 _namespace_0 = r0;
  u32 _next_0 = r1;
  Term _rows_0 = r2;
  Term _rows_1 = r3;
  Term _rows_2 = r4;
  Term _rows_3 = r5;
  Term _rows_4 = r6;
  Term _rows_5 = r7;
  u32 _rows_6 = r8;
  Term _rows_7 = r9;
  u32 _rows_8 = r10;
  Term _pending_0 = r11;
  Term _mode_0 = r12;
  Term _result_0 = r13;
  Term _result_1 = r14;
  WL_SPIN
    _v_41 = _namespace_0;
    _v_42 = _next_0;
    _v_43 = _rows_0;
    _v_44 = _rows_1;
    _v_45 = _rows_2;
    _v_46 = _rows_3;
    _v_47 = _rows_4;
    _v_48 = _rows_5;
    _v_49 = _rows_6;
    _v_50 = _rows_7;
    _v_51 = _rows_8;
    _v_52 = _pending_0;
    _v_53 = 1;
    _v_54 = _result_0;
    _v_55 = _mode_0;
    _v_56 = 1;
    _v_57 = _result_1;
  break;
  }
  o[0] = _v_41;
  o[1] = _v_42;
  o[2] = _v_43;
  o[3] = _v_44;
  o[4] = _v_45;
  o[5] = _v_46;
  o[6] = _v_47;
  o[7] = _v_48;
  o[8] = _v_49;
  o[9] = _v_50;
  o[10] = _v_51;
  o[11] = _v_52;
  o[12] = _v_53;
  o[13] = _v_54;
  o[14] = _v_55;
  o[15] = _v_56;
  o[16] = _v_57;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7) {
  u32 wpoll = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  u32 _value_2 = r7;
  WL_SPIN
    Term _at_0 = blk_loc(e.mem, _owner_0);
    Term _at_1 = blk_at(_owner_0, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[8];
    if (spin_8(e, _o_0, _owner_1, _owner_3, _owner_4, _owner_5, _owner_6, _value_2, _owner_0, _c_0) == 0) {
      return 0;
    }
    _v_16 = _o_0[0];
    _v_17 = _o_0[1];
    _v_18 = _o_0[2];
    _v_19 = _o_0[3];
    _v_20 = _o_0[4];
    _v_21 = _o_0[5];
    _v_22 = _o_0[6];
    _v_23 = _o_0[7];
    _v_8 = _v_16;
    _v_9 = _v_17;
    _v_10 = _v_18;
    _v_11 = _v_19;
    _v_12 = _v_20;
    _v_13 = _v_21;
    _v_14 = _v_22;
    _v_15 = _v_23;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, Term r4, Term r5, Term r6, u32 r7, Term r8, u32 r9, Term r10, u32 r11, Term r12, Term r13, Term r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _namespace_0 = r0;
  u32 _next_0 = r1;
  Term _aux_0 = r2;
  Term _metadata_0 = r3;
  Term _metadata_1 = r4;
  Term _metadata_2 = r5;
  Term _metadata_3 = r6;
  u32 _capacity_0 = r7;
  Term _depth_0 = r8;
  u32 _high_0 = r9;
  Term _pending_0 = r10;
  u32 _ledger_0 = r11;
  Term _ledger_1 = r12;
  Term _mode_0 = r13;
  Term _main_0 = r14;
  u32 _index_2 = r15;
  Term _result_0 = r16;
  Term _result_1 = r17;
  WL_SPIN
    Term _at_6 = blk_loc(e.mem, _main_0);
    Term _at_7 = blk_at(_main_0, _index_2, 1);
    u32 _c_4 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_5 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, 1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _result_0);
    term_sink(e, _c_5);
    _v_45 = _namespace_0;
    _v_46 = _next_0;
    _v_47 = _main_0;
    _v_48 = _aux_0;
    _v_49 = _metadata_0;
    _v_50 = _metadata_1;
    _v_51 = _metadata_2;
    _v_52 = _metadata_3;
    _v_53 = _capacity_0;
    _v_54 = _depth_0;
    _v_55 = _high_0;
    _v_56 = _pending_0;
    _v_57 = _ledger_0;
    _v_58 = _ledger_1;
    _v_59 = _mode_0;
    _v_60 = 0;
    _v_61 = _result_1;
  break;
  }
  o[0] = _v_45;
  o[1] = _v_46;
  o[2] = _v_47;
  o[3] = _v_48;
  o[4] = _v_49;
  o[5] = _v_50;
  o[6] = _v_51;
  o[7] = _v_52;
  o[8] = _v_53;
  o[9] = _v_54;
  o[10] = _v_55;
  o[11] = _v_56;
  o[12] = _v_57;
  o[13] = _v_58;
  o[14] = _v_59;
  o[15] = _v_60;
  o[16] = _v_61;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  WL_SPIN
    _v_1 = _result_0;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  WL_SPIN
    _v_1 = _result_0;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _s_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_s_1) == CID_SNIL) {
      _v_1 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _s_1, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = _f_1;
      r1 = term_ctr(CID_SCON, _nd_0);
      _s_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_15);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_1 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_17);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _s_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    if (spin_15(e, _o_0, _s_0, term_pak(CID_SNIL, 0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_5 = 0;
  Term _value_0 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_value_0) == CID_SNIL) {
      _v_5 = _acc_1;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _value_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_0 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_2;
      e.mem[_nd_0 + 1] = _acc_1;
      r0 = _f_3;
      r1 = term_ctr(CID_SCON, _nd_0);
      _value_0 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_19);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _view_0 = r0;
  u32 _view_1 = r1;
  u32 _view_2 = r2;
  u32 _view_3 = r3;
  u32 _view_4 = r4;
  WL_SPIN
    _v_2 = U32_BIN(U32_BIN(_view_0, +, _view_1), +, U32_BIN(U32_BIN(_view_2, +, _view_3), +, _view_4));
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_3 = 0;
  Term _values_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_values_1) == CID_NIL) {
      Term _v_4 = 0;
      Term _o_0[1];
      if (spin_18(e, _o_0, _acc_0) == 0) {
        return 0;
      }
      _v_4 = _o_0[0];
      _v_3 = _v_4;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _o_1[1];
      if (spin_19(e, _o_1, _f_0, _acc_0) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_5 = _v_6;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_5;
      _values_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_22);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _values_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_2[1];
    if (spin_22(e, _o_2, _values_0, term_pak(CID_SNIL, 0)) == 0) {
      return 0;
    }
    _v_2 = _o_2[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    if (spin_17(e, _o_0, _xs_0, term_pak(CID_NIL, 0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, Term r0, Term r1, u32 r2) {
  u32 wpoll = 0;
  Term _v_5 = 0;
  Term _value_0 = r0;
  Term _acc_2 = r1;
  u32 _first_2 = r2;
  WL_SPIN
    if (_first_2 == 1) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _value_0;
      e.mem[_nd_0 + 1] = _acc_2;
      _v_5 = term_ctr(CID_CON, _nd_0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_nd_1 + 1] = _acc_2;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = _value_0;
      e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
      _v_5 = term_ctr(CID_CON, _nd_2);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, Term r15, u32 r16, Term r17, u32 r18) {
  u32 wpoll = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _rawframe_0 = r0;
  u32 _b_0 = r1;
  u32 _c_1 = r2;
  u32 _d_0 = r3;
  u32 _cachedframe_0 = r4;
  Term _ledger_raw_0 = r5;
  u32 _ledger_raw_1 = r6;
  u32 _ledger_cached_0 = r7;
  u32 _ledger_cached_1 = r8;
  u32 _ledger_cached_2 = r9;
  u32 _ledger_cached_3 = r10;
  u32 _ledger_cached_4 = r11;
  u32 _handle_0 = r12;
  u32 _handle_1 = r13;
  Term _undo_0 = r14;
  Term _marks_0 = r15;
  u32 _value_1 = r16;
  Term _result_0 = r17;
  u32 _result_1 = r18;
  WL_SPIN
    Term _at_2 = blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 0ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _value_1);
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = _handle_0;
    e.mem[_nd_0 + 1] = _handle_1;
    e.mem[_nd_0 + 2] = _result_1;
    e.mem[_nd_0 + 3] = _undo_0;
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = _handle_0;
    e.mem[_nd_1 + 1] = _handle_1;
    e.mem[_nd_1 + 2] = _marks_0;
    _v_18 = _result_0;
    _v_19 = _rawframe_0;
    _v_20 = _value_1;
    _v_21 = _b_0;
    _v_22 = _c_1;
    _v_23 = _d_0;
    _v_24 = _cachedframe_0;
    _v_25 = _ledger_raw_0;
    _v_26 = _ledger_raw_1;
    _v_27 = _ledger_cached_0;
    _v_28 = _ledger_cached_1;
    _v_29 = _ledger_cached_2;
    _v_30 = _ledger_cached_3;
    _v_31 = _ledger_cached_4;
    _v_32 = _handle_0;
    _v_33 = _handle_1;
    _v_34 = term_ctr(CID_TRANSACTION_PROTOTYPEFLATMAIN, _nd_0);
    _v_35 = term_ctr(CID_TRANSACTION_PROTOTYPEFLATMARK, _nd_1);
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  o[9] = _v_27;
  o[10] = _v_28;
  o[11] = _v_29;
  o[12] = _v_30;
  o[13] = _v_31;
  o[14] = _v_32;
  o[15] = _v_33;
  o[16] = _v_34;
  o[17] = _v_35;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  Term _owner_7 = r7;
  u32 _owner_8 = r8;
  u32 _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  Term _owner_16 = r16;
  Term _owner_17 = r17;
  u32 _result_24 = r18;
  u32 _result_25 = r19;
  u32 _result_26 = r20;
  u32 _result_27 = r21;
  u32 _result_28 = r22;
  u32 _result_29 = r23;
  WL_SPIN
    if (_result_24 == 0) {
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      Term _o_0[1];
      if (spin_20(e, _o_0, _result_25, _result_26, _result_27, _result_28, _result_29) == 0) {
        return 0;
      }
      _v_39 = _o_0[0];
      _v_38 = _v_39;
      _v_19 = _owner_0;
      _v_20 = _owner_1;
      _v_21 = _owner_2;
      _v_22 = _owner_3;
      _v_23 = _owner_4;
      _v_24 = _owner_5;
      _v_25 = _owner_6;
      _v_26 = _owner_7;
      _v_27 = _owner_8;
      _v_28 = _owner_9;
      _v_29 = _owner_10;
      _v_30 = _owner_11;
      _v_31 = _owner_12;
      _v_32 = _owner_13;
      _v_33 = _owner_14;
      _v_34 = _owner_15;
      _v_35 = _owner_16;
      _v_36 = _owner_17;
      _v_37 = _v_38;
    } else {
      _v_19 = _owner_0;
      _v_20 = _owner_1;
      _v_21 = _owner_2;
      _v_22 = _owner_3;
      _v_23 = _owner_4;
      _v_24 = _owner_5;
      _v_25 = _owner_6;
      _v_26 = _owner_7;
      _v_27 = _owner_8;
      _v_28 = _owner_9;
      _v_29 = _owner_10;
      _v_30 = _owner_11;
      _v_31 = _owner_12;
      _v_32 = _owner_13;
      _v_33 = _owner_14;
      _v_34 = _owner_15;
      _v_35 = _owner_16;
      _v_36 = _owner_17;
      _v_37 = 0ull;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17, u32 r18) {
  u32 wpoll = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  u32 _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  Term _v_94 = 0;
  Term _v_95 = 0;
  Term _owner_18 = r0;
  u32 _owner_19 = r1;
  u32 _owner_20 = r2;
  u32 _owner_21 = r3;
  u32 _owner_22 = r4;
  u32 _owner_23 = r5;
  u32 _owner_24 = r6;
  Term _owner_25 = r7;
  u32 _owner_26 = r8;
  u32 _owner_27 = r9;
  u32 _owner_28 = r10;
  u32 _owner_29 = r11;
  u32 _owner_30 = r12;
  u32 _owner_31 = r13;
  u32 _owner_32 = r14;
  u32 _owner_33 = r15;
  Term _owner_34 = r16;
  Term _owner_35 = r17;
  u32 _value_0 = r18;
  WL_SPIN
    Term _at_0 = blk_loc(e.mem, _owner_18);
    Term _at_1 = blk_at(_owner_18, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    Term _o_0[18];
    if (spin_25(e, _o_0, _owner_19, _owner_21, _owner_22, _owner_23, _owner_24, _owner_25, _owner_26, _owner_27, _owner_28, _owner_29, _owner_30, _owner_31, _owner_32, _owner_33, _owner_34, _owner_35, _value_0, _owner_18, _c_0) == 0) {
      return 0;
    }
    _v_96 = _o_0[0];
    _v_97 = _o_0[1];
    _v_98 = _o_0[2];
    _v_99 = _o_0[3];
    _v_100 = _o_0[4];
    _v_101 = _o_0[5];
    _v_102 = _o_0[6];
    _v_103 = _o_0[7];
    _v_104 = _o_0[8];
    _v_105 = _o_0[9];
    _v_106 = _o_0[10];
    _v_107 = _o_0[11];
    _v_108 = _o_0[12];
    _v_109 = _o_0[13];
    _v_110 = _o_0[14];
    _v_111 = _o_0[15];
    _v_112 = _o_0[16];
    _v_113 = _o_0[17];
    _v_78 = _v_96;
    _v_79 = _v_97;
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    _v_89 = _v_107;
    _v_90 = _v_108;
    _v_91 = _v_109;
    _v_92 = _v_110;
    _v_93 = _v_111;
    _v_94 = _v_112;
    _v_95 = _v_113;
  break;
  }
  o[0] = _v_78;
  o[1] = _v_79;
  o[2] = _v_80;
  o[3] = _v_81;
  o[4] = _v_82;
  o[5] = _v_83;
  o[6] = _v_84;
  o[7] = _v_85;
  o[8] = _v_86;
  o[9] = _v_87;
  o[10] = _v_88;
  o[11] = _v_89;
  o[12] = _v_90;
  o[13] = _v_91;
  o[14] = _v_92;
  o[15] = _v_93;
  o[16] = _v_94;
  o[17] = _v_95;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  u32 _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  u32 _v_162 = 0;
  Term _v_163 = 0;
  u32 _v_164 = 0;
  u32 _v_165 = 0;
  u32 _v_166 = 0;
  u32 _v_167 = 0;
  u32 _v_168 = 0;
  u32 _v_169 = 0;
  u32 _v_170 = 0;
  u32 _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  u32 _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  u32 _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  Term _owner_36 = r0;
  u32 _owner_37 = r1;
  u32 _owner_38 = r2;
  u32 _owner_39 = r3;
  u32 _owner_40 = r4;
  u32 _owner_41 = r5;
  u32 _owner_42 = r6;
  Term _owner_43 = r7;
  u32 _owner_44 = r8;
  u32 _owner_45 = r9;
  u32 _owner_46 = r10;
  u32 _owner_47 = r11;
  u32 _owner_48 = r12;
  u32 _owner_49 = r13;
  u32 _owner_50 = r14;
  u32 _owner_51 = r15;
  Term _owner_52 = r16;
  Term _owner_53 = r17;
  WL_SPIN
    _v_156 = _owner_36;
    _v_157 = _owner_37;
    _v_158 = _owner_38;
    _v_159 = _owner_39;
    _v_160 = _owner_40;
    _v_161 = _owner_41;
    _v_162 = _owner_42;
    _v_163 = _owner_43;
    _v_164 = _owner_44;
    _v_165 = _owner_45;
    _v_166 = _owner_46;
    _v_167 = _owner_47;
    _v_168 = _owner_48;
    _v_169 = _owner_49;
    _v_170 = _owner_50;
    _v_171 = _owner_51;
    _v_172 = _owner_52;
    _v_173 = _owner_53;
    _v_174 = 0;
    _v_175 = _owner_38;
    _v_176 = _owner_39;
    _v_177 = _owner_40;
    _v_178 = _owner_41;
    _v_179 = _owner_42;
  break;
  }
  o[0] = _v_156;
  o[1] = _v_157;
  o[2] = _v_158;
  o[3] = _v_159;
  o[4] = _v_160;
  o[5] = _v_161;
  o[6] = _v_162;
  o[7] = _v_163;
  o[8] = _v_164;
  o[9] = _v_165;
  o[10] = _v_166;
  o[11] = _v_167;
  o[12] = _v_168;
  o[13] = _v_169;
  o[14] = _v_170;
  o[15] = _v_171;
  o[16] = _v_172;
  o[17] = _v_173;
  o[18] = _v_174;
  o[19] = _v_175;
  o[20] = _v_176;
  o[21] = _v_177;
  o[22] = _v_178;
  o[23] = _v_179;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term _v_199 = 0;
  u32 _v_200 = 0;
  u32 _v_201 = 0;
  u32 _v_202 = 0;
  u32 _v_203 = 0;
  u32 _v_204 = 0;
  u32 _v_205 = 0;
  Term _v_206 = 0;
  u32 _v_207 = 0;
  u32 _v_208 = 0;
  u32 _v_209 = 0;
  u32 _v_210 = 0;
  u32 _v_211 = 0;
  u32 _v_212 = 0;
  u32 _v_213 = 0;
  u32 _v_214 = 0;
  Term _v_215 = 0;
  Term _v_216 = 0;
  u32 _v_217 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  u32 _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  u32 _result_14 = r14;
  u32 _result_15 = r15;
  Term _result_16 = r16;
  Term _result_17 = r17;
  u32 _result_18 = r18;
  u32 _result_19 = r19;
  u32 _result_20 = r20;
  u32 _result_21 = r21;
  u32 _result_22 = r22;
  u32 _result_23 = r23;
  WL_SPIN
    Term _v_218 = 0;
    u32 _v_219 = 0;
    u32 _v_220 = 0;
    u32 _v_221 = 0;
    u32 _v_222 = 0;
    u32 _v_223 = 0;
    u32 _v_224 = 0;
    Term _v_225 = 0;
    u32 _v_226 = 0;
    u32 _v_227 = 0;
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    u32 _v_230 = 0;
    u32 _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    Term _v_234 = 0;
    Term _v_235 = 0;
    u32 _v_236 = 0;
    Term _o_4[19];
    if (spin_26(e, _o_4, _result_0, _result_1, _result_2, _result_3, _result_4, _result_5, _result_6, _result_7, _result_8, _result_9, _result_10, _result_11, _result_12, _result_13, _result_14, _result_15, _result_16, _result_17, _result_18, _result_19, _result_20, _result_21, _result_22, _result_23) == 0) {
      return 0;
    }
    _v_218 = _o_4[0];
    _v_219 = _o_4[1];
    _v_220 = _o_4[2];
    _v_221 = _o_4[3];
    _v_222 = _o_4[4];
    _v_223 = _o_4[5];
    _v_224 = _o_4[6];
    _v_225 = _o_4[7];
    _v_226 = _o_4[8];
    _v_227 = _o_4[9];
    _v_228 = _o_4[10];
    _v_229 = _o_4[11];
    _v_230 = _o_4[12];
    _v_231 = _o_4[13];
    _v_232 = _o_4[14];
    _v_233 = _o_4[15];
    _v_234 = _o_4[16];
    _v_235 = _o_4[17];
    _v_236 = _o_4[18];
    _v_199 = _v_218;
    _v_200 = _v_219;
    _v_201 = _v_220;
    _v_202 = _v_221;
    _v_203 = _v_222;
    _v_204 = _v_223;
    _v_205 = _v_224;
    _v_206 = _v_225;
    _v_207 = _v_226;
    _v_208 = _v_227;
    _v_209 = _v_228;
    _v_210 = _v_229;
    _v_211 = _v_230;
    _v_212 = _v_231;
    _v_213 = _v_232;
    _v_214 = _v_233;
    _v_215 = _v_234;
    _v_216 = _v_235;
    _v_217 = _v_236;
  break;
  }
  o[0] = _v_199;
  o[1] = _v_200;
  o[2] = _v_201;
  o[3] = _v_202;
  o[4] = _v_203;
  o[5] = _v_204;
  o[6] = _v_205;
  o[7] = _v_206;
  o[8] = _v_207;
  o[9] = _v_208;
  o[10] = _v_209;
  o[11] = _v_210;
  o[12] = _v_211;
  o[13] = _v_212;
  o[14] = _v_213;
  o[15] = _v_214;
  o[16] = _v_215;
  o[17] = _v_216;
  o[18] = _v_217;
  return 1;
}

FAR Term spin_30(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _owner_18 = r0;
  u32 _owner_19 = r1;
  u32 _owner_20 = r2;
  u32 _owner_21 = r3;
  u32 _owner_22 = r4;
  u32 _owner_23 = r5;
  u32 _owner_24 = r6;
  Term _owner_25 = r7;
  u32 _owner_26 = r8;
  u32 _owner_27 = r9;
  u32 _owner_28 = r10;
  u32 _owner_29 = r11;
  u32 _owner_30 = r12;
  u32 _owner_31 = r13;
  u32 _owner_32 = r14;
  u32 _owner_33 = r15;
  Term _owner_34 = r16;
  Term _owner_35 = r17;
  WL_SPIN
    Term _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    Term _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    Term _o_0[18];
    if (spin_27(e, _o_0, _owner_18, _owner_19, _owner_20, _owner_21, _owner_22, _owner_23, _owner_24, _owner_25, _owner_26, _owner_27, _owner_28, _owner_29, _owner_30, _owner_31, _owner_32, _owner_33, _owner_34, _owner_35, 500ull) == 0) {
      return 0;
    }
    _v_98 = _o_0[0];
    _v_99 = _o_0[1];
    _v_100 = _o_0[2];
    _v_101 = _o_0[3];
    _v_102 = _o_0[4];
    _v_103 = _o_0[5];
    _v_104 = _o_0[6];
    _v_105 = _o_0[7];
    _v_106 = _o_0[8];
    _v_107 = _o_0[9];
    _v_108 = _o_0[10];
    _v_109 = _o_0[11];
    _v_110 = _o_0[12];
    _v_111 = _o_0[13];
    _v_112 = _o_0[14];
    _v_113 = _o_0[15];
    _v_114 = _o_0[16];
    _v_115 = _o_0[17];
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    _v_89 = _v_107;
    _v_90 = _v_108;
    _v_91 = _v_109;
    _v_92 = _v_110;
    _v_93 = _v_111;
    _v_94 = _v_112;
    _v_95 = _v_113;
    _v_96 = _v_114;
    _v_97 = _v_115;
    Term _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    Term _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _o_1[18];
    if (spin_27(e, _o_1, _v_80, _v_81, _v_82, _v_83, _v_84, _v_85, _v_86, _v_87, _v_88, _v_89, _v_90, _v_91, _v_92, _v_93, _v_94, _v_95, _v_96, _v_97, 700ull) == 0) {
      return 0;
    }
    _v_116 = _o_1[0];
    _v_117 = _o_1[1];
    _v_118 = _o_1[2];
    _v_119 = _o_1[3];
    _v_120 = _o_1[4];
    _v_121 = _o_1[5];
    _v_122 = _o_1[6];
    _v_123 = _o_1[7];
    _v_124 = _o_1[8];
    _v_125 = _o_1[9];
    _v_126 = _o_1[10];
    _v_127 = _o_1[11];
    _v_128 = _o_1[12];
    _v_129 = _o_1[13];
    _v_130 = _o_1[14];
    _v_131 = _o_1[15];
    _v_132 = _o_1[16];
    _v_133 = _o_1[17];
    _v_62 = _v_116;
    _v_63 = _v_117;
    _v_64 = _v_118;
    _v_65 = _v_119;
    _v_66 = _v_120;
    _v_67 = _v_121;
    _v_68 = _v_122;
    _v_69 = _v_123;
    _v_70 = _v_124;
    _v_71 = _v_125;
    _v_72 = _v_126;
    _v_73 = _v_127;
    _v_74 = _v_128;
    _v_75 = _v_129;
    _v_76 = _v_130;
    _v_77 = _v_131;
    _v_78 = _v_132;
    _v_79 = _v_133;
    Term _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    Term _v_141 = 0;
    u32 _v_142 = 0;
    u32 _v_143 = 0;
    u32 _v_144 = 0;
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    Term _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    u32 _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    Term _o_2[24];
    if (spin_28(e, _o_2, _v_62, _v_63, _v_64, _v_65, _v_66, _v_67, _v_68, _v_69, _v_70, _v_71, _v_72, _v_73, _v_74, _v_75, _v_76, _v_77, _v_78, _v_79) == 0) {
      return 0;
    }
    _v_134 = _o_2[0];
    _v_135 = _o_2[1];
    _v_136 = _o_2[2];
    _v_137 = _o_2[3];
    _v_138 = _o_2[4];
    _v_139 = _o_2[5];
    _v_140 = _o_2[6];
    _v_141 = _o_2[7];
    _v_142 = _o_2[8];
    _v_143 = _o_2[9];
    _v_144 = _o_2[10];
    _v_145 = _o_2[11];
    _v_146 = _o_2[12];
    _v_147 = _o_2[13];
    _v_148 = _o_2[14];
    _v_149 = _o_2[15];
    _v_150 = _o_2[16];
    _v_151 = _o_2[17];
    _v_152 = _o_2[18];
    _v_153 = _o_2[19];
    _v_154 = _o_2[20];
    _v_155 = _o_2[21];
    _v_156 = _o_2[22];
    _v_157 = _o_2[23];
    _v_38 = _v_134;
    _v_39 = _v_135;
    _v_40 = _v_136;
    _v_41 = _v_137;
    _v_42 = _v_138;
    _v_43 = _v_139;
    _v_44 = _v_140;
    _v_45 = _v_141;
    _v_46 = _v_142;
    _v_47 = _v_143;
    _v_48 = _v_144;
    _v_49 = _v_145;
    _v_50 = _v_146;
    _v_51 = _v_147;
    _v_52 = _v_148;
    _v_53 = _v_149;
    _v_54 = _v_150;
    _v_55 = _v_151;
    _v_56 = _v_152;
    _v_57 = _v_153;
    _v_58 = _v_154;
    _v_59 = _v_155;
    _v_60 = _v_156;
    _v_61 = _v_157;
    Term _v_158 = 0;
    u32 _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    u32 _v_172 = 0;
    u32 _v_173 = 0;
    Term _v_174 = 0;
    Term _v_175 = 0;
    u32 _v_176 = 0;
    Term _o_3[19];
    if (spin_29(e, _o_3, _v_38, _v_39, _v_40, _v_41, _v_42, _v_43, _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_50, _v_51, _v_52, _v_53, _v_54, _v_55, _v_56, _v_57, _v_58, _v_59, _v_60, _v_61) == 0) {
      return 0;
    }
    _v_158 = _o_3[0];
    _v_159 = _o_3[1];
    _v_160 = _o_3[2];
    _v_161 = _o_3[3];
    _v_162 = _o_3[4];
    _v_163 = _o_3[5];
    _v_164 = _o_3[6];
    _v_165 = _o_3[7];
    _v_166 = _o_3[8];
    _v_167 = _o_3[9];
    _v_168 = _o_3[10];
    _v_169 = _o_3[11];
    _v_170 = _o_3[12];
    _v_171 = _o_3[13];
    _v_172 = _o_3[14];
    _v_173 = _o_3[15];
    _v_174 = _o_3[16];
    _v_175 = _o_3[17];
    _v_176 = _o_3[18];
    _v_19 = _v_158;
    _v_20 = _v_159;
    _v_21 = _v_160;
    _v_22 = _v_161;
    _v_23 = _v_162;
    _v_24 = _v_163;
    _v_25 = _v_164;
    _v_26 = _v_165;
    _v_27 = _v_166;
    _v_28 = _v_167;
    _v_29 = _v_168;
    _v_30 = _v_169;
    _v_31 = _v_170;
    _v_32 = _v_171;
    _v_33 = _v_172;
    _v_34 = _v_173;
    _v_35 = _v_174;
    _v_36 = _v_175;
    _v_37 = _v_176;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  Term _owner_7 = r7;
  u32 _owner_8 = r8;
  u32 _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  Term _owner_16 = r16;
  Term _owner_17 = r17;
  WL_SPIN
    Term _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _o_0[19];
    if (spin_30(e, _o_0, _owner_0, _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _owner_7, _owner_8, _owner_9, _owner_10, _owner_11, _owner_12, _owner_13, _owner_14, _owner_15, _owner_16, _owner_17) == 0) {
      return 0;
    }
    _v_57 = _o_0[0];
    _v_58 = _o_0[1];
    _v_59 = _o_0[2];
    _v_60 = _o_0[3];
    _v_61 = _o_0[4];
    _v_62 = _o_0[5];
    _v_63 = _o_0[6];
    _v_64 = _o_0[7];
    _v_65 = _o_0[8];
    _v_66 = _o_0[9];
    _v_67 = _o_0[10];
    _v_68 = _o_0[11];
    _v_69 = _o_0[12];
    _v_70 = _o_0[13];
    _v_71 = _o_0[14];
    _v_72 = _o_0[15];
    _v_73 = _o_0[16];
    _v_74 = _o_0[17];
    _v_75 = _o_0[18];
    _v_38 = _v_57;
    _v_39 = _v_58;
    _v_40 = _v_59;
    _v_41 = _v_60;
    _v_42 = _v_61;
    _v_43 = _v_62;
    _v_44 = _v_63;
    _v_45 = _v_64;
    _v_46 = _v_65;
    _v_47 = _v_66;
    _v_48 = _v_67;
    _v_49 = _v_68;
    _v_50 = _v_69;
    _v_51 = _v_70;
    _v_52 = _v_71;
    _v_53 = _v_72;
    _v_54 = _v_73;
    _v_55 = _v_74;
    _v_56 = _v_75;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_LEDGER0_2)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _value_0 = r21;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _value_0;
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_world_12 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = _world_13;
      e.mem[_nd_5 + 1] = _world_14;
      u64 _nd_6 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_6 + 0] = _world_15;
      e.mem[_nd_6 + 1] = _world_16;
      e.mem[_nd_6 + 2] = _world_17;
      e.mem[_nd_6 + 3] = _world_18;
      e.mem[_nd_6 + 4] = _world_19;
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = term_ctr(CID_TYPES_MOTIONLEDGER, _nd_5);
      e.mem[_nd_7 + 1] = term_ctr(CID_TYPES_LEDGERVIEW, _nd_6);
      _o_3 = term_ctr(CID_CACHE_CACHE, _nd_7);
    }
    Term _b_0 = 0;
    if (_world_20 == 0) {
      _b_0 = term_pak(CID_TYPES_MOTIONON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_MOTIONOFF, 0);
    }
    if (_o_2 == 0) {
      Term _transform_0 = term_clo(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_C28, _nd_0);
      term_sink(e, _transform_0);
      u32 _o_4 = 0;
      if (term_aux(_b_0) == CID_TYPES_MOTIONON) {
        _o_4 = 0;
      } else {
        _o_4 = 1;
      }
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = _o_4;
      r21 = 0;
      r22 = 0;
      WL_RETN(23);
    } else {
      Term _transform_1 = term_clo(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_C28, _nd_0);
      if (seq) {
        WL_ROOM(14);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_2;
        STK(3) = _world_3;
        STK(4) = _world_4;
        STK(5) = _world_5;
        STK(6) = _world_6;
        STK(7) = _world_7;
        STK(8) = _world_8;
        STK(9) = _world_9;
        STK(10) = _world_10;
        STK(11) = _world_11;
        STK(12) = _b_0;
        STK(13) = FID_TRANSACTION_STORAGE_SET_LEDGER0_2_K29;
        WL_PUSHN(14);
      } else {
        u64 _t_0 = task_node(e, FID_TRANSACTION_STORAGE_SET_LEDGER0_2_K29, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_2;
        e.mem[_t_0 + 3] = _world_3;
        e.mem[_t_0 + 4] = _world_4;
        e.mem[_t_0 + 5] = _world_5;
        e.mem[_t_0 + 6] = _world_6;
        e.mem[_t_0 + 7] = _world_7;
        e.mem[_t_0 + 8] = _world_8;
        e.mem[_t_0 + 9] = _world_9;
        e.mem[_t_0 + 10] = _world_10;
        e.mem[_t_0 + 11] = _world_11;
        e.mem[_t_0 + 12] = _b_0;
        WL_CONT = term_tsk(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_K29, _t_0);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _transform_1;
        e.mem[_t_1 + 1] = _o_3;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _transform_1;
      r1 = _o_3;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_C28)
  {
    u32 _value_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    u64 _sp_0 = term_loc(_x_0);
    Term _f_0 = e.mem[_sp_0 + 0];
    Term _f_1 = e.mem[_sp_0 + 1];
    heap_free(e, cls_fit(2), _sp_0);
    u64 _sp_1 = term_loc(_f_0);
    Term _f_2 = e.mem[_sp_1 + 0];
    u32 _f_3 = e.mem[_sp_1 + 1];
    heap_free(e, cls_fit(2), _sp_1);
    u64 _sp_2 = term_loc(_f_1);
    u32 _f_4 = e.mem[_sp_2 + 0];
    u32 _f_5 = e.mem[_sp_2 + 1];
    u32 _f_6 = e.mem[_sp_2 + 2];
    u32 _f_7 = e.mem[_sp_2 + 3];
    u32 _f_8 = e.mem[_sp_2 + 4];
    heap_free(e, cls_fit(5), _sp_2);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _o_1[8];
    if (spin_9(e, _o_1, _f_2, _f_3, _f_4, _f_5, _f_6, _f_7, _f_8, _value_1) == 0) {
      return 0;
    }
    _v_0 = _o_1[0];
    _v_1 = _o_1[1];
    _v_2 = _o_1[2];
    _v_3 = _o_1[3];
    _v_4 = _o_1[4];
    _v_5 = _o_1[5];
    _v_6 = _o_1[6];
    _v_7 = _o_1[7];
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _v_0;
    e.mem[_nd_1 + 1] = _v_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_2 + 0] = _v_2;
    e.mem[_nd_2 + 1] = _v_3;
    e.mem[_nd_2 + 2] = _v_4;
    e.mem[_nd_2 + 3] = _v_5;
    e.mem[_nd_2 + 4] = _v_6;
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_TYPES_MOTIONLEDGER, _nd_1);
    e.mem[_nd_3 + 1] = term_ctr(CID_TYPES_LEDGERVIEW, _nd_2);
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = term_ctr(CID_CACHE_CACHE, _nd_3);
    e.mem[_nd_4 + 1] = _v_7;
    r0 = term_ctr(CID_TUPLE, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_LEDGER0_2_K29)
  {
    WL_POPN(13);
    u32 _world_21 = STK(0);
    u32 _world_22 = STK(1);
    Term _world_23 = STK(2);
    Term _world_24 = STK(3);
    Term _world_25 = STK(4);
    Term _world_26 = STK(5);
    Term _world_27 = STK(6);
    Term _world_28 = STK(7);
    u32 _world_29 = STK(8);
    Term _world_30 = STK(9);
    u32 _world_31 = STK(10);
    Term _world_32 = STK(11);
    Term _b_1 = STK(12);
    Term _h_0 = r0;
    WL_OPEN
    u64 _sp_3 = term_loc(_h_0);
    Term _f_9 = e.mem[_sp_3 + 0];
    Term _f_10 = e.mem[_sp_3 + 1];
    heap_free(e, cls_fit(2), _sp_3);
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    Term _o_5[17];
    if (spin_10(e, _o_5, _world_21, _world_22, _world_23, _world_24, _world_25, _world_26, _world_27, _world_28, _world_29, _world_30, _world_31, _world_32, _b_1, _f_9, _f_10) == 0) {
      return 0;
    }
    _v_24 = _o_5[0];
    _v_25 = _o_5[1];
    _v_26 = _o_5[2];
    _v_27 = _o_5[3];
    _v_28 = _o_5[4];
    _v_29 = _o_5[5];
    _v_30 = _o_5[6];
    _v_31 = _o_5[7];
    _v_32 = _o_5[8];
    _v_33 = _o_5[9];
    _v_34 = _o_5[10];
    _v_35 = _o_5[11];
    _v_36 = _o_5[12];
    _v_37 = _o_5[13];
    _v_38 = _o_5[14];
    _v_39 = _o_5[15];
    _v_40 = _o_5[16];
    u32 _o_6 = 0;
    Term _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    u32 _o_12 = 0;
    u32 _o_13 = 0;
    if (_v_36 == 0) {
      _o_6 = 0;
    } else {
      _o_6 = 1;
      u64 _sp_4 = term_loc(_v_37);
      Term _f_11 = e.mem[_sp_4 + 0];
      Term _f_12 = e.mem[_sp_4 + 1];
      heap_free(e, cls_fit(2), _sp_4);
      u64 _sp_5 = term_loc(_f_11);
      Term _f_13 = e.mem[_sp_5 + 0];
      u32 _f_14 = e.mem[_sp_5 + 1];
      heap_free(e, cls_fit(2), _sp_5);
      u64 _sp_6 = term_loc(_f_12);
      u32 _f_15 = e.mem[_sp_6 + 0];
      u32 _f_16 = e.mem[_sp_6 + 1];
      u32 _f_17 = e.mem[_sp_6 + 2];
      u32 _f_18 = e.mem[_sp_6 + 3];
      u32 _f_19 = e.mem[_sp_6 + 4];
      heap_free(e, cls_fit(5), _sp_6);
      _o_7 = _f_13;
      _o_8 = _f_14;
      _o_9 = _f_15;
      _o_10 = _f_16;
      _o_11 = _f_17;
      _o_12 = _f_18;
      _o_13 = _f_19;
    }
    u32 _o_14 = 0;
    if (term_aux(_v_38) == CID_TYPES_MOTIONON) {
      _o_14 = 0;
    } else {
      _o_14 = 1;
    }
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    if (_v_39 == 0) {
      _o_15 = 0;
    } else {
      _o_15 = 1;
      _o_16 = _v_40;
    }
    r0 = _v_24;
    r1 = _v_25;
    r2 = _v_26;
    r3 = _v_27;
    r4 = _v_28;
    r5 = _v_29;
    r6 = _v_30;
    r7 = _v_31;
    r8 = _v_32;
    r9 = _v_33;
    r10 = _v_34;
    r11 = _v_35;
    r12 = _o_6;
    r13 = _o_7;
    r14 = _o_8;
    r15 = _o_9;
    r16 = _o_10;
    r17 = _o_11;
    r18 = _o_12;
    r19 = _o_13;
    r20 = _o_14;
    r21 = _o_15;
    r22 = _o_16;
    WL_RETN(23);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_MAIN0_2)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _handle_0 = r21;
    u32 _handle_1 = r22;
    u32 _value_0 = r23;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _value_0;
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_world_12 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = _world_13;
      e.mem[_nd_3 + 1] = _world_14;
      u64 _nd_4 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_4 + 0] = _world_15;
      e.mem[_nd_4 + 1] = _world_16;
      e.mem[_nd_4 + 2] = _world_17;
      e.mem[_nd_4 + 3] = _world_18;
      e.mem[_nd_4 + 4] = _world_19;
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = term_ctr(CID_TYPES_MOTIONLEDGER, _nd_3);
      e.mem[_nd_5 + 1] = term_ctr(CID_TYPES_LEDGERVIEW, _nd_4);
      _o_3 = term_ctr(CID_CACHE_CACHE, _nd_5);
    }
    Term _b_0 = 0;
    if (_world_20 == 0) {
      _b_0 = term_pak(CID_TYPES_MOTIONON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_MOTIONOFF, 0);
    }
    Term _transform_0 = term_clo(FID_TRANSACTION_STORAGE_SET_MAIN0_2_C32, _nd_0);
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _transform_0);
      u32 _o_4 = 0;
      Term _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      if (_o_2 == 0) {
        _o_4 = 0;
      } else {
        _o_4 = 1;
        u64 _sp_1 = term_loc(_o_3);
        Term _f_7 = e.mem[_sp_1 + 0];
        Term _f_8 = e.mem[_sp_1 + 1];
        heap_free(e, cls_fit(2), _sp_1);
        u64 _sp_2 = term_loc(_f_7);
        Term _f_9 = e.mem[_sp_2 + 0];
        u32 _f_10 = e.mem[_sp_2 + 1];
        heap_free(e, cls_fit(2), _sp_2);
        u64 _sp_3 = term_loc(_f_8);
        u32 _f_11 = e.mem[_sp_3 + 0];
        u32 _f_12 = e.mem[_sp_3 + 1];
        u32 _f_13 = e.mem[_sp_3 + 2];
        u32 _f_14 = e.mem[_sp_3 + 3];
        u32 _f_15 = e.mem[_sp_3 + 4];
        heap_free(e, cls_fit(5), _sp_3);
        _o_5 = _f_9;
        _o_6 = _f_10;
        _o_7 = _f_11;
        _o_8 = _f_12;
        _o_9 = _f_13;
        _o_10 = _f_14;
        _o_11 = _f_15;
      }
      u32 _o_12 = 0;
      if (term_aux(_b_0) == CID_TYPES_MOTIONON) {
        _o_12 = 0;
      } else {
        _o_12 = 1;
      }
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _o_4;
      r13 = _o_5;
      r14 = _o_6;
      r15 = _o_7;
      r16 = _o_8;
      r17 = _o_9;
      r18 = _o_10;
      r19 = _o_11;
      r20 = _o_12;
      r21 = 2;
      r22 = 0;
      WL_RETN(23);
    } else {
      u32 _v_24 = 0;
      u32 _v_25 = 0;
      u32 _v_26 = 0;
      Term _o_13[1];
      if (spin_5(e, _o_13, U32_BIN(_handle_1, <=, _world_8), U32_BIN(_handle_1, <=, _world_10)) == 0) {
        return 0;
      }
      _v_26 = _o_13[0];
      _v_25 = _v_26;
      u32 _v_27 = 0;
      Term _o_14[1];
      if (spin_5(e, _o_14, U32_BIN(0ull, <, _handle_1), _v_25) == 0) {
        return 0;
      }
      _v_27 = _o_14[0];
      _v_24 = _v_27;
      if (_v_24 == 0) {
        term_sink(e, _transform_0);
        u32 _o_15 = 0;
        Term _o_16 = 0;
        u32 _o_17 = 0;
        u32 _o_18 = 0;
        u32 _o_19 = 0;
        u32 _o_20 = 0;
        u32 _o_21 = 0;
        u32 _o_22 = 0;
        if (_o_2 == 0) {
          _o_15 = 0;
        } else {
          _o_15 = 1;
          u64 _sp_4 = term_loc(_o_3);
          Term _f_16 = e.mem[_sp_4 + 0];
          Term _f_17 = e.mem[_sp_4 + 1];
          heap_free(e, cls_fit(2), _sp_4);
          u64 _sp_5 = term_loc(_f_16);
          Term _f_18 = e.mem[_sp_5 + 0];
          u32 _f_19 = e.mem[_sp_5 + 1];
          heap_free(e, cls_fit(2), _sp_5);
          u64 _sp_6 = term_loc(_f_17);
          u32 _f_20 = e.mem[_sp_6 + 0];
          u32 _f_21 = e.mem[_sp_6 + 1];
          u32 _f_22 = e.mem[_sp_6 + 2];
          u32 _f_23 = e.mem[_sp_6 + 3];
          u32 _f_24 = e.mem[_sp_6 + 4];
          heap_free(e, cls_fit(5), _sp_6);
          _o_16 = _f_18;
          _o_17 = _f_19;
          _o_18 = _f_20;
          _o_19 = _f_21;
          _o_20 = _f_22;
          _o_21 = _f_23;
          _o_22 = _f_24;
        }
        u32 _o_23 = 0;
        if (term_aux(_b_0) == CID_TYPES_MOTIONON) {
          _o_23 = 0;
        } else {
          _o_23 = 1;
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _o_15;
        r13 = _o_16;
        r14 = _o_17;
        r15 = _o_18;
        r16 = _o_19;
        r17 = _o_20;
        r18 = _o_21;
        r19 = _o_22;
        r20 = _o_23;
        r21 = 2;
        r22 = 0;
        WL_RETN(23);
      } else {
        u32 _index_0 = U32_BIN(_handle_1, -, 1ull);
        Term _at_2 = blk_loc(e.mem, _world_4);
        Term _at_3 = blk_at(_world_4, _index_0, 0);
        u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
        if (_c_1 == 0) {
          term_sink(e, _transform_0);
          u32 _o_24 = 0;
          Term _o_25 = 0;
          u32 _o_26 = 0;
          u32 _o_27 = 0;
          u32 _o_28 = 0;
          u32 _o_29 = 0;
          u32 _o_30 = 0;
          u32 _o_31 = 0;
          if (_o_2 == 0) {
            _o_24 = 0;
          } else {
            _o_24 = 1;
            u64 _sp_7 = term_loc(_o_3);
            Term _f_25 = e.mem[_sp_7 + 0];
            Term _f_26 = e.mem[_sp_7 + 1];
            heap_free(e, cls_fit(2), _sp_7);
            u64 _sp_8 = term_loc(_f_25);
            Term _f_27 = e.mem[_sp_8 + 0];
            u32 _f_28 = e.mem[_sp_8 + 1];
            heap_free(e, cls_fit(2), _sp_8);
            u64 _sp_9 = term_loc(_f_26);
            u32 _f_29 = e.mem[_sp_9 + 0];
            u32 _f_30 = e.mem[_sp_9 + 1];
            u32 _f_31 = e.mem[_sp_9 + 2];
            u32 _f_32 = e.mem[_sp_9 + 3];
            u32 _f_33 = e.mem[_sp_9 + 4];
            heap_free(e, cls_fit(5), _sp_9);
            _o_25 = _f_27;
            _o_26 = _f_28;
            _o_27 = _f_29;
            _o_28 = _f_30;
            _o_29 = _f_31;
            _o_30 = _f_32;
            _o_31 = _f_33;
          }
          u32 _o_32 = 0;
          if (term_aux(_b_0) == CID_TYPES_MOTIONON) {
            _o_32 = 0;
          } else {
            _o_32 = 1;
          }
          r0 = _world_0;
          r1 = _world_1;
          r2 = _world_2;
          r3 = _world_3;
          r4 = _world_4;
          r5 = _world_5;
          r6 = _world_6;
          r7 = _world_7;
          r8 = _world_8;
          r9 = _world_9;
          r10 = _world_10;
          r11 = _world_11;
          r12 = _o_24;
          r13 = _o_25;
          r14 = _o_26;
          r15 = _o_27;
          r16 = _o_28;
          r17 = _o_29;
          r18 = _o_30;
          r19 = _o_31;
          r20 = _o_32;
          r21 = 2;
          r22 = 0;
          WL_RETN(23);
        } else {
          Term _at_4 = blk_loc(e.mem, _world_2);
          Term _at_5 = blk_at(_world_2, _index_0, 1);
          u32 _c_2 = blk_read(e.mem, 1, _at_4, _at_5 + 0);
          Term _c_3 = e.mem[_at_4 + _at_5 + 1];
          blk_write(e.mem, 1, _at_4, _at_5 + 0, 0);
          blk_write(e.mem, 1, _at_4, _at_5 + 1, 0);
          if (_c_2 == 0) {
            term_sink(e, _transform_0);
            u32 _o_33 = 0;
            Term _o_34 = 0;
            u32 _o_35 = 0;
            u32 _o_36 = 0;
            u32 _o_37 = 0;
            u32 _o_38 = 0;
            u32 _o_39 = 0;
            u32 _o_40 = 0;
            if (_o_2 == 0) {
              _o_33 = 0;
            } else {
              _o_33 = 1;
              u64 _sp_10 = term_loc(_o_3);
              Term _f_34 = e.mem[_sp_10 + 0];
              Term _f_35 = e.mem[_sp_10 + 1];
              heap_free(e, cls_fit(2), _sp_10);
              u64 _sp_11 = term_loc(_f_34);
              Term _f_36 = e.mem[_sp_11 + 0];
              u32 _f_37 = e.mem[_sp_11 + 1];
              heap_free(e, cls_fit(2), _sp_11);
              u64 _sp_12 = term_loc(_f_35);
              u32 _f_38 = e.mem[_sp_12 + 0];
              u32 _f_39 = e.mem[_sp_12 + 1];
              u32 _f_40 = e.mem[_sp_12 + 2];
              u32 _f_41 = e.mem[_sp_12 + 3];
              u32 _f_42 = e.mem[_sp_12 + 4];
              heap_free(e, cls_fit(5), _sp_12);
              _o_34 = _f_36;
              _o_35 = _f_37;
              _o_36 = _f_38;
              _o_37 = _f_39;
              _o_38 = _f_40;
              _o_39 = _f_41;
              _o_40 = _f_42;
            }
            u32 _o_41 = 0;
            if (term_aux(_b_0) == CID_TYPES_MOTIONON) {
              _o_41 = 0;
            } else {
              _o_41 = 1;
            }
            r0 = _world_0;
            r1 = _world_1;
            r2 = _world_2;
            r3 = _world_3;
            r4 = _world_4;
            r5 = _world_5;
            r6 = _world_6;
            r7 = _world_7;
            r8 = _world_8;
            r9 = _world_9;
            r10 = _world_10;
            r11 = _world_11;
            r12 = _o_33;
            r13 = _o_34;
            r14 = _o_35;
            r15 = _o_36;
            r16 = _o_37;
            r17 = _o_38;
            r18 = _o_39;
            r19 = _o_40;
            r20 = _o_41;
            r21 = 1;
            r22 = 0;
            WL_RETN(23);
          } else {
            if (seq) {
              WL_ROOM(17);
              STK(0) = _world_0;
              STK(1) = _world_1;
              STK(2) = _world_3;
              STK(3) = _world_4;
              STK(4) = _world_5;
              STK(5) = _world_6;
              STK(6) = _world_7;
              STK(7) = _world_8;
              STK(8) = _world_9;
              STK(9) = _world_10;
              STK(10) = _world_11;
              STK(11) = _o_2;
              STK(12) = _o_3;
              STK(13) = _b_0;
              STK(14) = _index_0;
              STK(15) = _world_2;
              STK(16) = FID_TRANSACTION_STORAGE_SET_MAIN0_2_K33;
              WL_PUSHN(17);
            } else {
              u64 _t_0 = task_node(e, FID_TRANSACTION_STORAGE_SET_MAIN0_2_K33, WL_CONT, WL_IDX, 1);
              e.mem[_t_0 + 0] = _world_0;
              e.mem[_t_0 + 1] = _world_1;
              e.mem[_t_0 + 2] = _world_3;
              e.mem[_t_0 + 3] = _world_4;
              e.mem[_t_0 + 4] = _world_5;
              e.mem[_t_0 + 5] = _world_6;
              e.mem[_t_0 + 6] = _world_7;
              e.mem[_t_0 + 7] = _world_8;
              e.mem[_t_0 + 8] = _world_9;
              e.mem[_t_0 + 9] = _world_10;
              e.mem[_t_0 + 10] = _world_11;
              e.mem[_t_0 + 11] = _o_2;
              e.mem[_t_0 + 12] = _o_3;
              e.mem[_t_0 + 13] = _b_0;
              e.mem[_t_0 + 14] = _index_0;
              e.mem[_t_0 + 15] = _world_2;
              WL_CONT = term_tsk(FID_TRANSACTION_STORAGE_SET_MAIN0_2_K33, _t_0);
              WL_IDX = 16;
            }
            if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
              u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
              e.mem[_t_1 + 0] = _transform_0;
              e.mem[_t_1 + 1] = _c_3;
              return term_tsk(FID_CLO_APPLY, _t_1);
            }
            r0 = _transform_0;
            r1 = _c_3;
            WL_JMP(FID_CLO_APPLY);
          }
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_MAIN0_2_C32)
  {
    u32 _value_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    u64 _sp_0 = term_loc(_x_0);
    Term _f_0 = e.mem[_sp_0 + 0];
    u32 _f_1 = e.mem[_sp_0 + 1];
    u32 _f_2 = e.mem[_sp_0 + 2];
    u32 _f_3 = e.mem[_sp_0 + 3];
    u32 _f_4 = e.mem[_sp_0 + 4];
    u32 _f_5 = e.mem[_sp_0 + 5];
    u32 _f_6 = e.mem[_sp_0 + 6];
    heap_free(e, cls_fit(7), _sp_0);
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _o_1[8];
    if (spin_11(e, _o_1, _f_0, _f_1, _f_2, _f_3, _f_4, _f_5, _f_6, _value_1) == 0) {
      return 0;
    }
    _v_0 = _o_1[0];
    _v_1 = _o_1[1];
    _v_2 = _o_1[2];
    _v_3 = _o_1[3];
    _v_4 = _o_1[4];
    _v_5 = _o_1[5];
    _v_6 = _o_1[6];
    _v_7 = _o_1[7];
    u64 _nd_1 = heap_alloc(e, cls_fit(7));
    e.mem[_nd_1 + 0] = _v_0;
    e.mem[_nd_1 + 1] = _v_1;
    e.mem[_nd_1 + 2] = _v_2;
    e.mem[_nd_1 + 3] = _v_3;
    e.mem[_nd_1 + 4] = _v_4;
    e.mem[_nd_1 + 5] = _v_5;
    e.mem[_nd_1 + 6] = _v_6;
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT, _nd_1);
    e.mem[_nd_2 + 1] = _v_7;
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_STORAGE_SET_MAIN0_2_K33)
  {
    WL_POPN(16);
    u32 _world_21 = STK(0);
    u32 _world_22 = STK(1);
    Term _world_23 = STK(2);
    Term _world_24 = STK(3);
    Term _world_25 = STK(4);
    Term _world_26 = STK(5);
    Term _world_27 = STK(6);
    u32 _world_28 = STK(7);
    Term _world_29 = STK(8);
    u32 _world_30 = STK(9);
    Term _world_31 = STK(10);
    u32 _o_42 = STK(11);
    Term _o_43 = STK(12);
    Term _b_1 = STK(13);
    u32 _index_1 = STK(14);
    Term _world_32 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    u64 _sp_13 = term_loc(_h_0);
    Term _f_43 = e.mem[_sp_13 + 0];
    Term _f_44 = e.mem[_sp_13 + 1];
    heap_free(e, cls_fit(2), _sp_13);
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    Term _o_44[17];
    if (spin_12(e, _o_44, _world_21, _world_22, _world_23, _world_24, _world_25, _world_26, _world_27, _world_28, _world_29, _world_30, _world_31, _o_42, _o_43, _b_1, _world_32, _index_1, _f_43, _f_44) == 0) {
      return 0;
    }
    _v_28 = _o_44[0];
    _v_29 = _o_44[1];
    _v_30 = _o_44[2];
    _v_31 = _o_44[3];
    _v_32 = _o_44[4];
    _v_33 = _o_44[5];
    _v_34 = _o_44[6];
    _v_35 = _o_44[7];
    _v_36 = _o_44[8];
    _v_37 = _o_44[9];
    _v_38 = _o_44[10];
    _v_39 = _o_44[11];
    _v_40 = _o_44[12];
    _v_41 = _o_44[13];
    _v_42 = _o_44[14];
    _v_43 = _o_44[15];
    _v_44 = _o_44[16];
    u32 _o_45 = 0;
    Term _o_46 = 0;
    u32 _o_47 = 0;
    u32 _o_48 = 0;
    u32 _o_49 = 0;
    u32 _o_50 = 0;
    u32 _o_51 = 0;
    u32 _o_52 = 0;
    if (_v_40 == 0) {
      _o_45 = 0;
    } else {
      _o_45 = 1;
      u64 _sp_14 = term_loc(_v_41);
      Term _f_45 = e.mem[_sp_14 + 0];
      Term _f_46 = e.mem[_sp_14 + 1];
      heap_free(e, cls_fit(2), _sp_14);
      u64 _sp_15 = term_loc(_f_45);
      Term _f_47 = e.mem[_sp_15 + 0];
      u32 _f_48 = e.mem[_sp_15 + 1];
      heap_free(e, cls_fit(2), _sp_15);
      u64 _sp_16 = term_loc(_f_46);
      u32 _f_49 = e.mem[_sp_16 + 0];
      u32 _f_50 = e.mem[_sp_16 + 1];
      u32 _f_51 = e.mem[_sp_16 + 2];
      u32 _f_52 = e.mem[_sp_16 + 3];
      u32 _f_53 = e.mem[_sp_16 + 4];
      heap_free(e, cls_fit(5), _sp_16);
      _o_46 = _f_47;
      _o_47 = _f_48;
      _o_48 = _f_49;
      _o_49 = _f_50;
      _o_50 = _f_51;
      _o_51 = _f_52;
      _o_52 = _f_53;
    }
    u32 _o_53 = 0;
    if (term_aux(_v_42) == CID_TYPES_MOTIONON) {
      _o_53 = 0;
    } else {
      _o_53 = 1;
    }
    u32 _o_54 = 0;
    u32 _o_55 = 0;
    if (_v_43 == 0) {
      _o_54 = 0;
      _o_55 = _v_44;
    } else if (_v_43 == 1) {
      _o_54 = 1;
    } else {
      _o_54 = 2;
    }
    r0 = _v_28;
    r1 = _v_29;
    r2 = _v_30;
    r3 = _v_31;
    r4 = _v_32;
    r5 = _v_33;
    r6 = _v_34;
    r7 = _v_35;
    r8 = _v_36;
    r9 = _v_37;
    r10 = _v_38;
    r11 = _v_39;
    r12 = _o_45;
    r13 = _o_46;
    r14 = _o_47;
    r15 = _o_48;
    r16 = _o_49;
    r17 = _o_50;
    r18 = _o_51;
    r19 = _o_52;
    r20 = _o_53;
    r21 = _o_54;
    r22 = _o_55;
    WL_RETN(23);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _old_0 = r21;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE_K46;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE_K46, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE_K46, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_STORAGE_SET_LEDGER0_2)) {
      u64 _t_1 = task_node(e, FID_TRANSACTION_STORAGE_SET_LEDGER0_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _world_15;
      e.mem[_t_1 + 16] = _world_16;
      e.mem[_t_1 + 17] = _world_17;
      e.mem[_t_1 + 18] = _world_18;
      e.mem[_t_1 + 19] = _world_19;
      e.mem[_t_1 + 20] = _world_20;
      e.mem[_t_1 + 21] = _old_0;
      return term_tsk(FID_TRANSACTION_STORAGE_SET_LEDGER0_2, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _world_15;
    r16 = _world_16;
    r17 = _world_17;
    r18 = _world_18;
    r19 = _world_19;
    r20 = _world_20;
    r21 = _old_0;
    WL_JMP(FID_TRANSACTION_STORAGE_SET_LEDGER0_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE_K46)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _h_13;
      e.mem[_nd_0 + 1] = _h_14;
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = _h_15;
      e.mem[_nd_1 + 1] = _h_16;
      e.mem[_nd_1 + 2] = _h_17;
      e.mem[_nd_1 + 3] = _h_18;
      e.mem[_nd_1 + 4] = _h_19;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = term_ctr(CID_TYPES_MOTIONLEDGER, _nd_0);
      e.mem[_nd_2 + 1] = term_ctr(CID_TYPES_LEDGERVIEW, _nd_1);
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    Term _b_0 = 0;
    if (_h_20 == 0) {
      _b_0 = term_pak(CID_TYPES_MOTIONON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_MOTIONOFF, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = _h_0;
    e.mem[_nd_3 + 1] = _h_1;
    e.mem[_nd_3 + 2] = _h_2;
    e.mem[_nd_3 + 3] = _h_3;
    e.mem[_nd_3 + 4] = _h_4;
    e.mem[_nd_3 + 5] = _h_5;
    e.mem[_nd_3 + 6] = _h_6;
    e.mem[_nd_3 + 7] = _h_7;
    e.mem[_nd_3 + 8] = _h_8;
    e.mem[_nd_3 + 9] = _h_9;
    e.mem[_nd_3 + 10] = _h_10;
    e.mem[_nd_3 + 11] = _h_11;
    e.mem[_nd_3 + 12] = _o_0;
    e.mem[_nd_3 + 13] = _o_1;
    e.mem[_nd_3 + 14] = _b_0;
    Term _v_0 = 0;
    Term _o_2[1];
    if (spin_13(e, _o_2, term_ctr(CID_STORAGE_WORLD, _nd_3), _h_21, _h_22) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    u64 _sp_0 = term_loc(_v_0);
    u32 _f_0 = e.mem[_sp_0 + 0];
    u32 _f_1 = e.mem[_sp_0 + 1];
    Term _f_2 = e.mem[_sp_0 + 2];
    Term _f_3 = e.mem[_sp_0 + 3];
    Term _f_4 = e.mem[_sp_0 + 4];
    Term _f_5 = e.mem[_sp_0 + 5];
    Term _f_6 = e.mem[_sp_0 + 6];
    Term _f_7 = e.mem[_sp_0 + 7];
    u32 _f_8 = e.mem[_sp_0 + 8];
    Term _f_9 = e.mem[_sp_0 + 9];
    u32 _f_10 = e.mem[_sp_0 + 10];
    Term _f_11 = e.mem[_sp_0 + 11];
    u32 _f_12 = e.mem[_sp_0 + 12];
    Term _f_13 = e.mem[_sp_0 + 13];
    Term _f_14 = e.mem[_sp_0 + 14];
    heap_free(e, cls_fit(15), _sp_0);
    u32 _o_3 = 0;
    Term _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    if (_f_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _sp_1 = term_loc(_f_13);
      Term _f_15 = e.mem[_sp_1 + 0];
      Term _f_16 = e.mem[_sp_1 + 1];
      heap_free(e, cls_fit(2), _sp_1);
      u64 _sp_2 = term_loc(_f_15);
      Term _f_17 = e.mem[_sp_2 + 0];
      u32 _f_18 = e.mem[_sp_2 + 1];
      heap_free(e, cls_fit(2), _sp_2);
      u64 _sp_3 = term_loc(_f_16);
      u32 _f_19 = e.mem[_sp_3 + 0];
      u32 _f_20 = e.mem[_sp_3 + 1];
      u32 _f_21 = e.mem[_sp_3 + 2];
      u32 _f_22 = e.mem[_sp_3 + 3];
      u32 _f_23 = e.mem[_sp_3 + 4];
      heap_free(e, cls_fit(5), _sp_3);
      _o_4 = _f_17;
      _o_5 = _f_18;
      _o_6 = _f_19;
      _o_7 = _f_20;
      _o_8 = _f_21;
      _o_9 = _f_22;
      _o_10 = _f_23;
    }
    u32 _o_11 = 0;
    if (term_aux(_f_14) == CID_TYPES_MOTIONON) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
    }
    r0 = _f_0;
    r1 = _f_1;
    r2 = _f_2;
    r3 = _f_3;
    r4 = _f_4;
    r5 = _f_5;
    r6 = _f_6;
    r7 = _f_7;
    r8 = _f_8;
    r9 = _f_9;
    r10 = _f_10;
    r11 = _f_11;
    r12 = _o_3;
    r13 = _o_4;
    r14 = _o_5;
    r15 = _o_6;
    r16 = _o_7;
    r17 = _o_8;
    r18 = _o_9;
    r19 = _o_10;
    r20 = _o_11;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _handle_0 = r21;
    u32 _handle_1 = r22;
    u32 _old_0 = r23;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE_K48;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE_K48, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE_K48, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_STORAGE_SET_MAIN0_2)) {
      u64 _t_1 = task_node(e, FID_TRANSACTION_STORAGE_SET_MAIN0_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _world_15;
      e.mem[_t_1 + 16] = _world_16;
      e.mem[_t_1 + 17] = _world_17;
      e.mem[_t_1 + 18] = _world_18;
      e.mem[_t_1 + 19] = _world_19;
      e.mem[_t_1 + 20] = _world_20;
      e.mem[_t_1 + 21] = _handle_0;
      e.mem[_t_1 + 22] = _handle_1;
      e.mem[_t_1 + 23] = _old_0;
      return term_tsk(FID_TRANSACTION_STORAGE_SET_MAIN0_2, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _world_15;
    r16 = _world_16;
    r17 = _world_17;
    r18 = _world_18;
    r19 = _world_19;
    r20 = _world_20;
    r21 = _handle_0;
    r22 = _handle_1;
    r23 = _old_0;
    WL_JMP(FID_TRANSACTION_STORAGE_SET_MAIN0_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE_K48)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _h_13;
      e.mem[_nd_0 + 1] = _h_14;
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = _h_15;
      e.mem[_nd_1 + 1] = _h_16;
      e.mem[_nd_1 + 2] = _h_17;
      e.mem[_nd_1 + 3] = _h_18;
      e.mem[_nd_1 + 4] = _h_19;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = term_ctr(CID_TYPES_MOTIONLEDGER, _nd_0);
      e.mem[_nd_2 + 1] = term_ctr(CID_TYPES_LEDGERVIEW, _nd_1);
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    Term _b_0 = 0;
    if (_h_20 == 0) {
      _b_0 = term_pak(CID_TYPES_MOTIONON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_MOTIONOFF, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = _h_0;
    e.mem[_nd_3 + 1] = _h_1;
    e.mem[_nd_3 + 2] = _h_2;
    e.mem[_nd_3 + 3] = _h_3;
    e.mem[_nd_3 + 4] = _h_4;
    e.mem[_nd_3 + 5] = _h_5;
    e.mem[_nd_3 + 6] = _h_6;
    e.mem[_nd_3 + 7] = _h_7;
    e.mem[_nd_3 + 8] = _h_8;
    e.mem[_nd_3 + 9] = _h_9;
    e.mem[_nd_3 + 10] = _h_10;
    e.mem[_nd_3 + 11] = _h_11;
    e.mem[_nd_3 + 12] = _o_0;
    e.mem[_nd_3 + 13] = _o_1;
    e.mem[_nd_3 + 14] = _b_0;
    Term _v_0 = 0;
    Term _o_2[1];
    if (spin_14(e, _o_2, term_ctr(CID_STORAGE_WORLD, _nd_3), _h_21, _h_22) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    u64 _sp_0 = term_loc(_v_0);
    u32 _f_0 = e.mem[_sp_0 + 0];
    u32 _f_1 = e.mem[_sp_0 + 1];
    Term _f_2 = e.mem[_sp_0 + 2];
    Term _f_3 = e.mem[_sp_0 + 3];
    Term _f_4 = e.mem[_sp_0 + 4];
    Term _f_5 = e.mem[_sp_0 + 5];
    Term _f_6 = e.mem[_sp_0 + 6];
    Term _f_7 = e.mem[_sp_0 + 7];
    u32 _f_8 = e.mem[_sp_0 + 8];
    Term _f_9 = e.mem[_sp_0 + 9];
    u32 _f_10 = e.mem[_sp_0 + 10];
    Term _f_11 = e.mem[_sp_0 + 11];
    u32 _f_12 = e.mem[_sp_0 + 12];
    Term _f_13 = e.mem[_sp_0 + 13];
    Term _f_14 = e.mem[_sp_0 + 14];
    heap_free(e, cls_fit(15), _sp_0);
    u32 _o_3 = 0;
    Term _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    if (_f_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _sp_1 = term_loc(_f_13);
      Term _f_15 = e.mem[_sp_1 + 0];
      Term _f_16 = e.mem[_sp_1 + 1];
      heap_free(e, cls_fit(2), _sp_1);
      u64 _sp_2 = term_loc(_f_15);
      Term _f_17 = e.mem[_sp_2 + 0];
      u32 _f_18 = e.mem[_sp_2 + 1];
      heap_free(e, cls_fit(2), _sp_2);
      u64 _sp_3 = term_loc(_f_16);
      u32 _f_19 = e.mem[_sp_3 + 0];
      u32 _f_20 = e.mem[_sp_3 + 1];
      u32 _f_21 = e.mem[_sp_3 + 2];
      u32 _f_22 = e.mem[_sp_3 + 3];
      u32 _f_23 = e.mem[_sp_3 + 4];
      heap_free(e, cls_fit(5), _sp_3);
      _o_4 = _f_17;
      _o_5 = _f_18;
      _o_6 = _f_19;
      _o_7 = _f_20;
      _o_8 = _f_21;
      _o_9 = _f_22;
      _o_10 = _f_23;
    }
    u32 _o_11 = 0;
    if (term_aux(_f_14) == CID_TYPES_MOTIONON) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
    }
    r0 = _f_0;
    r1 = _f_1;
    r2 = _f_2;
    r3 = _f_3;
    r4 = _f_4;
    r5 = _f_5;
    r6 = _f_6;
    r7 = _f_7;
    r8 = _f_8;
    r9 = _f_9;
    r10 = _f_10;
    r11 = _f_11;
    r12 = _o_3;
    r13 = _o_4;
    r14 = _o_5;
    r15 = _o_6;
    r16 = _o_7;
    r17 = _o_8;
    r18 = _o_9;
    r19 = _o_10;
    r20 = _o_11;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1)));
        e.mem[_nd_0 + 1] = _acc_0;
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_UNWIND_2)
  {
    Term _undo_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    Term _world_2 = r3;
    Term _world_3 = r4;
    Term _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    u32 _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    Term _world_11 = r12;
    u32 _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    u32 _world_16 = r17;
    u32 _world_17 = r18;
    u32 _world_18 = r19;
    u32 _world_19 = r20;
    u32 _world_20 = r21;
    WL_OPEN
    if (term_aux(_undo_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = _world_15;
      r16 = _world_16;
      r17 = _world_17;
      r18 = _world_18;
      r19 = _world_19;
      r20 = _world_20;
      WL_RETN(21);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _undo_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      if (term_aux(_f_0) == CID_TRANSACTION_MAININVERSE) {
        _o_0 = 0;
        u64 _sp_1 = term_loc(_f_0);
        Term _f_2 = e.mem[_sp_1 + 0];
        u32 _f_3 = e.mem[_sp_1 + 1];
        heap_free(e, cls_fit(2), _sp_1);
        u64 _sp_2 = term_loc(_f_2);
        u32 _f_4 = e.mem[_sp_2 + 0];
        u32 _f_5 = e.mem[_sp_2 + 1];
        heap_free(e, cls_fit(2), _sp_2);
        _o_1 = _f_4;
        _o_2 = _f_5;
        _o_3 = _f_3;
      } else {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      }
      if (_o_0 == 0) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_TRANSACTION_UNWIND_2_K57;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID_TRANSACTION_UNWIND_2_K57, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          WL_CONT = term_tsk(FID_TRANSACTION_UNWIND_2_K57, _t_0);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE)) {
          u64 _t_1 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _world_0;
          e.mem[_t_1 + 1] = _world_1;
          e.mem[_t_1 + 2] = _world_2;
          e.mem[_t_1 + 3] = _world_3;
          e.mem[_t_1 + 4] = _world_4;
          e.mem[_t_1 + 5] = _world_5;
          e.mem[_t_1 + 6] = _world_6;
          e.mem[_t_1 + 7] = _world_7;
          e.mem[_t_1 + 8] = _world_8;
          e.mem[_t_1 + 9] = _world_9;
          e.mem[_t_1 + 10] = _world_10;
          e.mem[_t_1 + 11] = _world_11;
          e.mem[_t_1 + 12] = _world_12;
          e.mem[_t_1 + 13] = _world_13;
          e.mem[_t_1 + 14] = _world_14;
          e.mem[_t_1 + 15] = _world_15;
          e.mem[_t_1 + 16] = _world_16;
          e.mem[_t_1 + 17] = _world_17;
          e.mem[_t_1 + 18] = _world_18;
          e.mem[_t_1 + 19] = _world_19;
          e.mem[_t_1 + 20] = _world_20;
          e.mem[_t_1 + 21] = _o_1;
          e.mem[_t_1 + 22] = _o_2;
          e.mem[_t_1 + 23] = _o_3;
          return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE, _t_1);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = _world_15;
        r16 = _world_16;
        r17 = _world_17;
        r18 = _world_18;
        r19 = _world_19;
        r20 = _world_20;
        r21 = _o_1;
        r22 = _o_2;
        r23 = _o_3;
        WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_RESTORE);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_TRANSACTION_UNWIND_2_K58;
          WL_PUSHN(2);
        } else {
          u64 _t_3 = task_node(e, FID_TRANSACTION_UNWIND_2_K58, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_1;
          WL_CONT = term_tsk(FID_TRANSACTION_UNWIND_2_K58, _t_3);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE)) {
          u64 _t_4 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _world_0;
          e.mem[_t_4 + 1] = _world_1;
          e.mem[_t_4 + 2] = _world_2;
          e.mem[_t_4 + 3] = _world_3;
          e.mem[_t_4 + 4] = _world_4;
          e.mem[_t_4 + 5] = _world_5;
          e.mem[_t_4 + 6] = _world_6;
          e.mem[_t_4 + 7] = _world_7;
          e.mem[_t_4 + 8] = _world_8;
          e.mem[_t_4 + 9] = _world_9;
          e.mem[_t_4 + 10] = _world_10;
          e.mem[_t_4 + 11] = _world_11;
          e.mem[_t_4 + 12] = _world_12;
          e.mem[_t_4 + 13] = _world_13;
          e.mem[_t_4 + 14] = _world_14;
          e.mem[_t_4 + 15] = _world_15;
          e.mem[_t_4 + 16] = _world_16;
          e.mem[_t_4 + 17] = _world_17;
          e.mem[_t_4 + 18] = _world_18;
          e.mem[_t_4 + 19] = _world_19;
          e.mem[_t_4 + 20] = _world_20;
          e.mem[_t_4 + 21] = _o_1;
          return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE, _t_4);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = _world_15;
        r16 = _world_16;
        r17 = _world_17;
        r18 = _world_18;
        r19 = _world_19;
        r20 = _world_20;
        r21 = _o_1;
        WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_WORLD_LEDGER_RESTORE);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_UNWIND_2_K57)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_UNWIND_2)) {
      u64 _t_2 = task_node(e, FID_TRANSACTION_UNWIND_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      e.mem[_t_2 + 4] = _h_3;
      e.mem[_t_2 + 5] = _h_4;
      e.mem[_t_2 + 6] = _h_5;
      e.mem[_t_2 + 7] = _h_6;
      e.mem[_t_2 + 8] = _h_7;
      e.mem[_t_2 + 9] = _h_8;
      e.mem[_t_2 + 10] = _h_9;
      e.mem[_t_2 + 11] = _h_10;
      e.mem[_t_2 + 12] = _h_11;
      e.mem[_t_2 + 13] = _h_12;
      e.mem[_t_2 + 14] = _h_13;
      e.mem[_t_2 + 15] = _h_14;
      e.mem[_t_2 + 16] = _h_15;
      e.mem[_t_2 + 17] = _h_16;
      e.mem[_t_2 + 18] = _h_17;
      e.mem[_t_2 + 19] = _h_18;
      e.mem[_t_2 + 20] = _h_19;
      e.mem[_t_2 + 21] = _h_20;
      return term_tsk(FID_TRANSACTION_UNWIND_2, _t_2);
    }
    r0 = _f_6;
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _h_5;
    r7 = _h_6;
    r8 = _h_7;
    r9 = _h_8;
    r10 = _h_9;
    r11 = _h_10;
    r12 = _h_11;
    r13 = _h_12;
    r14 = _h_13;
    r15 = _h_14;
    r16 = _h_15;
    r17 = _h_16;
    r18 = _h_17;
    r19 = _h_18;
    r20 = _h_19;
    r21 = _h_20;
    WL_JMP(FID_TRANSACTION_UNWIND_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_UNWIND_2_K58)
  {
    WL_POPN(1);
    Term _f_7 = STK(0);
    u32 _h_21 = r0;
    u32 _h_22 = r1;
    Term _h_23 = r2;
    Term _h_24 = r3;
    Term _h_25 = r4;
    Term _h_26 = r5;
    Term _h_27 = r6;
    Term _h_28 = r7;
    u32 _h_29 = r8;
    Term _h_30 = r9;
    u32 _h_31 = r10;
    Term _h_32 = r11;
    u32 _h_33 = r12;
    Term _h_34 = r13;
    u32 _h_35 = r14;
    u32 _h_36 = r15;
    u32 _h_37 = r16;
    u32 _h_38 = r17;
    u32 _h_39 = r18;
    u32 _h_40 = r19;
    u32 _h_41 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_UNWIND_2)) {
      u64 _t_5 = task_node(e, FID_TRANSACTION_UNWIND_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_7;
      e.mem[_t_5 + 1] = _h_21;
      e.mem[_t_5 + 2] = _h_22;
      e.mem[_t_5 + 3] = _h_23;
      e.mem[_t_5 + 4] = _h_24;
      e.mem[_t_5 + 5] = _h_25;
      e.mem[_t_5 + 6] = _h_26;
      e.mem[_t_5 + 7] = _h_27;
      e.mem[_t_5 + 8] = _h_28;
      e.mem[_t_5 + 9] = _h_29;
      e.mem[_t_5 + 10] = _h_30;
      e.mem[_t_5 + 11] = _h_31;
      e.mem[_t_5 + 12] = _h_32;
      e.mem[_t_5 + 13] = _h_33;
      e.mem[_t_5 + 14] = _h_34;
      e.mem[_t_5 + 15] = _h_35;
      e.mem[_t_5 + 16] = _h_36;
      e.mem[_t_5 + 17] = _h_37;
      e.mem[_t_5 + 18] = _h_38;
      e.mem[_t_5 + 19] = _h_39;
      e.mem[_t_5 + 20] = _h_40;
      e.mem[_t_5 + 21] = _h_41;
      return term_tsk(FID_TRANSACTION_UNWIND_2, _t_5);
    }
    r0 = _f_7;
    r1 = _h_21;
    r2 = _h_22;
    r3 = _h_23;
    r4 = _h_24;
    r5 = _h_25;
    r6 = _h_26;
    r7 = _h_27;
    r8 = _h_28;
    r9 = _h_29;
    r10 = _h_30;
    r11 = _h_31;
    r12 = _h_32;
    r13 = _h_33;
    r14 = _h_34;
    r15 = _h_35;
    r16 = _h_36;
    r17 = _h_37;
    r18 = _h_38;
    r19 = _h_39;
    r20 = _h_40;
    r21 = _h_41;
    WL_JMP(FID_TRANSACTION_UNWIND_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _dq_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = _dq_0;
      e.mem[_nd_1 + 1] = _acc_0;
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_16(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = _value_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K62;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K62, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      e.mem[_t_0 + 2] = _value_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K62, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K62)
  {
    WL_POPN(3);
    u32 _value_4 = STK(0);
    u32 _value_5 = STK(1);
    u32 _value_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_5;
      STK(1) = _value_6;
      STK(2) = _h_0;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K63;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K63, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_5;
      e.mem[_t_2 + 1] = _value_6;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K63, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K63)
  {
    WL_POPN(3);
    u32 _value_7 = STK(0);
    u32 _value_8 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_8;
      STK(1) = _h_2;
      STK(2) = _h_1;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K64;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K64, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_8;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K64, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_7;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _value_7;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K64)
  {
    WL_POPN(3);
    u32 _value_9 = STK(0);
    Term _h_4 = STK(1);
    Term _h_5 = STK(2);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K65;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K65, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K65, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_9;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _value_9;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K65)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_6;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 32);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _h_9;
    e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 22);
    e.mem[_nd_3 + 1] = term_ctr(CID_CON, _nd_2);
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = _h_8;
    e.mem[_nd_4 + 1] = term_ctr(CID_CON, _nd_3);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 16);
    e.mem[_nd_5 + 1] = term_ctr(CID_CON, _nd_4);
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = _h_7;
    e.mem[_nd_6 + 1] = term_ctr(CID_CON, _nd_5);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 10);
    e.mem[_nd_7 + 1] = term_ctr(CID_CON, _nd_6);
    Term _v_0 = 0;
    Term _o_3[1];
    if (spin_21(e, _o_3, term_ctr(CID_CON, _nd_7)) == 0) {
      return 0;
    }
    _v_0 = _o_3[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_GO_0)
  {
    Term _a_0 = r0;
    Term _acc_0 = r1;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_a_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _a_0), 0 + 0);
      blk_free(e, _a_0);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _c_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = term_ctr(CID_CON, _nd_0);
      WL_RETN(1);
    } else {
      Term _h_0 = blk_half(e, _a_0, 0);
      Term _h_1 = blk_half(e, _a_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_0;
        STK(1) = FID_ARRAY_TO_LIST_GO_0_K67;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_ARRAY_TO_LIST_GO_0_K67, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _h_0;
        WL_CONT = term_tsk(FID_ARRAY_TO_LIST_GO_0_K67, _t_0);
        WL_IDX = 1;
      }
      r0 = _h_1;
      r1 = _acc_0;
      _a_0 = r0;
      _acc_0 = r1;
      WL_AGAIN(FID_ARRAY_TO_LIST_GO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_GO_0_K67)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_GO_0)) {
      u64 _t_1 = task_node(e, FID_ARRAY_TO_LIST_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _h_3;
      e.mem[_t_1 + 1] = _h_2;
      return term_tsk(FID_ARRAY_TO_LIST_GO_0, _t_1);
    }
    r0 = _h_3;
    r1 = _h_2;
    WL_JMP(FID_ARRAY_TO_LIST_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_1[1];
      if (spin_23(e, _o_1, _acc_0) == 0) {
        return 0;
      }
      _v_0 = _o_1[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_16_K69;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16_K69, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K69, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K69)
  {
    WL_POPN(3);
    Term _f_2 = STK(0);
    Term _acc_1 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_2[1];
    if (spin_24(e, _o_2, _h_0, _acc_1, _first_1) == 0) {
      return 0;
    }
    _v_4 = _o_2[0];
    _v_3 = _v_4;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _v_3;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_2);
    }
    r0 = _f_2;
    r1 = _v_3;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_TRANSACTION_PROTOTYPEFLATMARKSEND) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_loc(_values_0);
      u32 _f_0 = e.mem[_sp_0 + 0];
      u32 _f_1 = e.mem[_sp_0 + 1];
      Term _f_2 = e.mem[_sp_0 + 2];
      heap_free(e, cls_fit(3), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _f_1;
        STK(2) = FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0_K75;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0_K75, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _f_1;
        WL_CONT = term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0_K75, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_2;
      _values_0 = r0;
      WL_AGAIN(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0_K75)
  {
    WL_POPN(2);
    u32 _f_3 = STK(0);
    u32 _f_4 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_3;
    e.mem[_nd_0 + 1] = _f_4;
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_STORAGE_HANDLE, _nd_0);
    e.mem[_nd_1 + 1] = _h_0;
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_TRANSACTION_PROTOTYPEFLATEND) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else if (term_aux(_values_0) == CID_TRANSACTION_PROTOTYPEFLATMAIN) {
      u64 _sp_0 = term_loc(_values_0);
      u32 _f_0 = e.mem[_sp_0 + 0];
      u32 _f_1 = e.mem[_sp_0 + 1];
      u32 _f_2 = e.mem[_sp_0 + 2];
      Term _f_3 = e.mem[_sp_0 + 3];
      heap_free(e, cls_fit(4), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_0;
        STK(1) = _f_1;
        STK(2) = _f_2;
        STK(3) = FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K77;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K77, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _f_1;
        e.mem[_t_0 + 2] = _f_2;
        WL_CONT = term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K77, _t_0);
        WL_IDX = 3;
      }
      r0 = _f_3;
      _values_0 = r0;
      WL_AGAIN(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0);
    } else {
      u64 _sp_1 = term_loc(_values_0);
      u32 _f_7 = e.mem[_sp_1 + 0];
      Term _f_8 = e.mem[_sp_1 + 1];
      heap_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_7;
        STK(1) = FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K78;
        WL_PUSHN(2);
      } else {
        u64 _t_1 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K78, WL_CONT, WL_IDX, 1);
        e.mem[_t_1 + 0] = _f_7;
        WL_CONT = term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K78, _t_1);
        WL_IDX = 1;
      }
      r0 = _f_8;
      _values_0 = r0;
      WL_AGAIN(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K77)
  {
    WL_POPN(3);
    u32 _f_4 = STK(0);
    u32 _f_5 = STK(1);
    u32 _f_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_4;
    e.mem[_nd_0 + 1] = _f_5;
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_STORAGE_HANDLE, _nd_0);
    e.mem[_nd_1 + 1] = _f_6;
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = term_ctr(CID_TRANSACTION_MAININVERSE, _nd_1);
    e.mem[_nd_2 + 1] = _h_0;
    r0 = term_ctr(CID_CON, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0_K78)
  {
    WL_POPN(1);
    u32 _f_9 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_pak(CID_TRANSACTION_LEDGERINVERSE, _f_9);
    e.mem[_nd_3 + 1] = _h_1;
    r0 = term_ctr(CID_CON, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_4;
      STK(1) = FID_HOST_RENDER_RENDER_LEDGER_K82;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER_K82, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LEDGER_K82, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER_K82)
  {
    WL_POPN(1);
    u32 _value_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_LEDGER_K83;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER_K83, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LEDGER_K83, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_5;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_5;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER_K83)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_1;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 32);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _h_2;
    e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 50);
    e.mem[_nd_3 + 1] = term_ctr(CID_CON, _nd_2);
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_21(e, _o_0, term_ctr(CID_CON, _nd_3)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_16(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_4;
      STK(1) = FID_HOST_RENDER_RENDER_POSITION_K86;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_POSITION_K86, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_POSITION_K86, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION_K86)
  {
    WL_POPN(1);
    u32 _value_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_POSITION_K87;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_POSITION_K87, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_POSITION_K87, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_5;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_5;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION_K87)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_1;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 32);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 102);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _h_2;
    e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 88);
    e.mem[_nd_3 + 1] = term_ctr(CID_CON, _nd_2);
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_21(e, _o_0, term_ctr(CID_CON, _nd_3)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_0)
  {
    Term _a_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_GO_0)) {
      u64 _t_0 = task_node(e, FID_ARRAY_TO_LIST_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _a_0;
      e.mem[_t_0 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_ARRAY_TO_LIST_GO_0, _t_0);
    }
    r0 = _a_0;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_ARRAY_TO_LIST_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DATA)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_DATA_K90;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_DATA_K90, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_DATA_K90, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _values_0 = r0;
      WL_AGAIN(FID_DATA);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DATA_K90)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _h_0;
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_16_K92;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16_K92, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_16_K92, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16_K92)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_21(e, _o_0, _h_0) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _v_0;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 108);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 104);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    Term _v_2 = 0;
    Term _o_1[1];
    if (spin_21(e, _o_1, term_ctr(CID_CON, _nd_1)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 34);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K95;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K95, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K95, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K95)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _h_0;
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY)
  {
    Term _depth_0 = r0;
    WL_OPEN
    WL_SPIN
    if (_depth_0 == 0) {
      Term _fv_0[2];
      _fv_0[0] = 0;
      _fv_0[1] = 0;
      r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
      WL_RETN(1);
    } else {
      Term _d_0 = (_depth_0 - 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _d_0;
        STK(1) = FID_STORAGE_SLOTS_EMPTY_K98;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K98, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _d_0;
        WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K98, _t_0);
        WL_IDX = 1;
      }
      r0 = _d_0;
      _depth_0 = r0;
      WL_AGAIN(FID_STORAGE_SLOTS_EMPTY);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K98)
  {
    WL_POPN(1);
    Term _d_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_STORAGE_SLOTS_EMPTY_K99;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K99, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K99, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_2 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _d_1;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_2);
    }
    r0 = _d_1;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K99)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_2, _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    Term _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    u32 _owner_8 = r8;
    Term _owner_9 = r9;
    u32 _owner_10 = r10;
    Term _owner_11 = r11;
    u32 _owner_12 = r12;
    Term _owner_13 = r13;
    u32 _owner_14 = r14;
    u32 _owner_15 = r15;
    u32 _owner_16 = r16;
    u32 _owner_17 = r17;
    u32 _owner_18 = r18;
    u32 _owner_19 = r19;
    u32 _owner_20 = r20;
    u32 _owner_21 = r21;
    u32 _owner_22 = r22;
    Term _owner_23 = r23;
    Term _owner_24 = r24;
    Term _owner_25 = r25;
    Term _owner_26 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _owner_0;
      STK(1) = _owner_1;
      STK(2) = _owner_2;
      STK(3) = _owner_3;
      STK(4) = _owner_4;
      STK(5) = _owner_5;
      STK(6) = _owner_6;
      STK(7) = _owner_7;
      STK(8) = _owner_8;
      STK(9) = _owner_9;
      STK(10) = _owner_10;
      STK(11) = _owner_11;
      STK(12) = _owner_12;
      STK(13) = _owner_13;
      STK(14) = _owner_14;
      STK(15) = _owner_15;
      STK(16) = _owner_16;
      STK(17) = _owner_17;
      STK(18) = _owner_18;
      STK(19) = _owner_19;
      STK(20) = _owner_20;
      STK(21) = _owner_21;
      STK(22) = _owner_22;
      STK(23) = _owner_24;
      STK(24) = _owner_25;
      STK(25) = _owner_26;
      STK(26) = FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K101;
      WL_PUSHN(27);
    } else {
      u64 _t_0 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K101, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_0;
      e.mem[_t_0 + 1] = _owner_1;
      e.mem[_t_0 + 2] = _owner_2;
      e.mem[_t_0 + 3] = _owner_3;
      e.mem[_t_0 + 4] = _owner_4;
      e.mem[_t_0 + 5] = _owner_5;
      e.mem[_t_0 + 6] = _owner_6;
      e.mem[_t_0 + 7] = _owner_7;
      e.mem[_t_0 + 8] = _owner_8;
      e.mem[_t_0 + 9] = _owner_9;
      e.mem[_t_0 + 10] = _owner_10;
      e.mem[_t_0 + 11] = _owner_11;
      e.mem[_t_0 + 12] = _owner_12;
      e.mem[_t_0 + 13] = _owner_13;
      e.mem[_t_0 + 14] = _owner_14;
      e.mem[_t_0 + 15] = _owner_15;
      e.mem[_t_0 + 16] = _owner_16;
      e.mem[_t_0 + 17] = _owner_17;
      e.mem[_t_0 + 18] = _owner_18;
      e.mem[_t_0 + 19] = _owner_19;
      e.mem[_t_0 + 20] = _owner_20;
      e.mem[_t_0 + 21] = _owner_21;
      e.mem[_t_0 + 22] = _owner_22;
      e.mem[_t_0 + 23] = _owner_24;
      e.mem[_t_0 + 24] = _owner_25;
      e.mem[_t_0 + 25] = _owner_26;
      WL_CONT = term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K101, _t_0);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0)) {
      u64 _t_1 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_23;
      return term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0, _t_1);
    }
    r0 = _owner_23;
    WL_JMP(FID_TRANSACTION_PROTOTYPE_FLAT_INVERSE_UNPACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K101)
  {
    WL_POPN(26);
    u32 _owner_27 = STK(0);
    u32 _owner_28 = STK(1);
    Term _owner_29 = STK(2);
    Term _owner_30 = STK(3);
    Term _owner_31 = STK(4);
    Term _owner_32 = STK(5);
    Term _owner_33 = STK(6);
    Term _owner_34 = STK(7);
    u32 _owner_35 = STK(8);
    Term _owner_36 = STK(9);
    u32 _owner_37 = STK(10);
    Term _owner_38 = STK(11);
    u32 _owner_39 = STK(12);
    Term _owner_40 = STK(13);
    u32 _owner_41 = STK(14);
    u32 _owner_42 = STK(15);
    u32 _owner_43 = STK(16);
    u32 _owner_44 = STK(17);
    u32 _owner_45 = STK(18);
    u32 _owner_46 = STK(19);
    u32 _owner_47 = STK(20);
    u32 _owner_48 = STK(21);
    u32 _owner_49 = STK(22);
    Term _owner_50 = STK(23);
    Term _owner_51 = STK(24);
    Term _owner_52 = STK(25);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _owner_27;
      STK(1) = _owner_28;
      STK(2) = _owner_29;
      STK(3) = _owner_30;
      STK(4) = _owner_31;
      STK(5) = _owner_32;
      STK(6) = _owner_33;
      STK(7) = _owner_34;
      STK(8) = _owner_35;
      STK(9) = _owner_36;
      STK(10) = _owner_37;
      STK(11) = _owner_38;
      STK(12) = _owner_39;
      STK(13) = _owner_40;
      STK(14) = _owner_41;
      STK(15) = _owner_42;
      STK(16) = _owner_43;
      STK(17) = _owner_44;
      STK(18) = _owner_45;
      STK(19) = _owner_46;
      STK(20) = _owner_47;
      STK(21) = _owner_48;
      STK(22) = _owner_49;
      STK(23) = _owner_50;
      STK(24) = _owner_51;
      STK(25) = _h_0;
      STK(26) = FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K102;
      WL_PUSHN(27);
    } else {
      u64 _t_2 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K102, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_27;
      e.mem[_t_2 + 1] = _owner_28;
      e.mem[_t_2 + 2] = _owner_29;
      e.mem[_t_2 + 3] = _owner_30;
      e.mem[_t_2 + 4] = _owner_31;
      e.mem[_t_2 + 5] = _owner_32;
      e.mem[_t_2 + 6] = _owner_33;
      e.mem[_t_2 + 7] = _owner_34;
      e.mem[_t_2 + 8] = _owner_35;
      e.mem[_t_2 + 9] = _owner_36;
      e.mem[_t_2 + 10] = _owner_37;
      e.mem[_t_2 + 11] = _owner_38;
      e.mem[_t_2 + 12] = _owner_39;
      e.mem[_t_2 + 13] = _owner_40;
      e.mem[_t_2 + 14] = _owner_41;
      e.mem[_t_2 + 15] = _owner_42;
      e.mem[_t_2 + 16] = _owner_43;
      e.mem[_t_2 + 17] = _owner_44;
      e.mem[_t_2 + 18] = _owner_45;
      e.mem[_t_2 + 19] = _owner_46;
      e.mem[_t_2 + 20] = _owner_47;
      e.mem[_t_2 + 21] = _owner_48;
      e.mem[_t_2 + 22] = _owner_49;
      e.mem[_t_2 + 23] = _owner_50;
      e.mem[_t_2 + 24] = _owner_51;
      e.mem[_t_2 + 25] = _h_0;
      WL_CONT = term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K102, _t_2);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0)) {
      u64 _t_3 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _owner_52;
      return term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0, _t_3);
    }
    r0 = _owner_52;
    WL_JMP(FID_TRANSACTION_PROTOTYPE_FLAT_MARK_UNPACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0_K102)
  {
    WL_POPN(26);
    u32 _owner_53 = STK(0);
    u32 _owner_54 = STK(1);
    Term _owner_55 = STK(2);
    Term _owner_56 = STK(3);
    Term _owner_57 = STK(4);
    Term _owner_58 = STK(5);
    Term _owner_59 = STK(6);
    Term _owner_60 = STK(7);
    u32 _owner_61 = STK(8);
    Term _owner_62 = STK(9);
    u32 _owner_63 = STK(10);
    Term _owner_64 = STK(11);
    u32 _owner_65 = STK(12);
    Term _owner_66 = STK(13);
    u32 _owner_67 = STK(14);
    u32 _owner_68 = STK(15);
    u32 _owner_69 = STK(16);
    u32 _owner_70 = STK(17);
    u32 _owner_71 = STK(18);
    u32 _owner_72 = STK(19);
    u32 _owner_73 = STK(20);
    u32 _owner_74 = STK(21);
    u32 _owner_75 = STK(22);
    Term _owner_76 = STK(23);
    Term _owner_77 = STK(24);
    Term _h_2 = STK(25);
    Term _h_1 = r0;
    WL_OPEN
    r0 = _owner_53;
    r1 = _owner_54;
    r2 = _owner_55;
    r3 = _owner_56;
    r4 = _owner_57;
    r5 = _owner_58;
    r6 = _owner_59;
    r7 = _owner_60;
    r8 = _owner_61;
    r9 = _owner_62;
    r10 = _owner_63;
    r11 = _owner_64;
    r12 = _owner_65;
    r13 = _owner_66;
    r14 = _owner_67;
    r15 = _owner_68;
    r16 = _owner_69;
    r17 = _owner_70;
    r18 = _owner_71;
    r19 = _owner_72;
    r20 = _owner_73;
    r21 = _owner_74;
    r22 = _owner_75;
    r23 = _h_2;
    r24 = _owner_76;
    r25 = _owner_77;
    r26 = _h_1;
    WL_RETN(27);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE)
  {
    u32 _t_0 = r0;
    u32 _t_1 = r1;
    Term _t_2 = r2;
    Term _t_3 = r3;
    Term _t_4 = r4;
    Term _t_5 = r5;
    Term _t_6 = r6;
    Term _t_7 = r7;
    u32 _t_8 = r8;
    Term _t_9 = r9;
    u32 _t_10 = r10;
    Term _t_11 = r11;
    u32 _t_12 = r12;
    Term _t_13 = r13;
    u32 _t_14 = r14;
    u32 _t_15 = r15;
    u32 _t_16 = r16;
    u32 _t_17 = r17;
    u32 _t_18 = r18;
    u32 _t_19 = r19;
    u32 _t_20 = r20;
    u32 _t_21 = r21;
    u32 _t_22 = r22;
    Term _t_23 = r23;
    Term _t_24 = r24;
    Term _t_25 = r25;
    Term _t_26 = r26;
    WL_OPEN
    term_sink(e, _t_24);
    term_sink(e, _t_25);
    term_sink(e, _t_26);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE_K104;
      WL_PUSHN(1);
    } else {
      u64 _t_27 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE_K104, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE_K104, _t_27);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_UNWIND_2)) {
      u64 _t_28 = task_node(e, FID_TRANSACTION_UNWIND_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _t_23;
      e.mem[_t_28 + 1] = _t_0;
      e.mem[_t_28 + 2] = _t_1;
      e.mem[_t_28 + 3] = _t_2;
      e.mem[_t_28 + 4] = _t_3;
      e.mem[_t_28 + 5] = _t_4;
      e.mem[_t_28 + 6] = _t_5;
      e.mem[_t_28 + 7] = _t_6;
      e.mem[_t_28 + 8] = _t_7;
      e.mem[_t_28 + 9] = _t_8;
      e.mem[_t_28 + 10] = _t_9;
      e.mem[_t_28 + 11] = _t_10;
      e.mem[_t_28 + 12] = _t_11;
      e.mem[_t_28 + 13] = _t_12;
      e.mem[_t_28 + 14] = _t_13;
      e.mem[_t_28 + 15] = _t_14;
      e.mem[_t_28 + 16] = _t_15;
      e.mem[_t_28 + 17] = _t_16;
      e.mem[_t_28 + 18] = _t_17;
      e.mem[_t_28 + 19] = _t_18;
      e.mem[_t_28 + 20] = _t_19;
      e.mem[_t_28 + 21] = _t_20;
      return term_tsk(FID_TRANSACTION_UNWIND_2, _t_28);
    }
    r0 = _t_23;
    r1 = _t_0;
    r2 = _t_1;
    r3 = _t_2;
    r4 = _t_3;
    r5 = _t_4;
    r6 = _t_5;
    r7 = _t_6;
    r8 = _t_7;
    r9 = _t_8;
    r10 = _t_9;
    r11 = _t_10;
    r12 = _t_11;
    r13 = _t_12;
    r14 = _t_13;
    r15 = _t_14;
    r16 = _t_15;
    r17 = _t_16;
    r18 = _t_17;
    r19 = _t_18;
    r20 = _t_19;
    r21 = _t_20;
    WL_JMP(FID_TRANSACTION_UNWIND_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE_K104)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    WL_OPEN
    r0 = 1;
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _h_5;
    r7 = _h_6;
    r8 = _h_7;
    r9 = _h_8;
    r10 = _h_9;
    r11 = _h_10;
    r12 = _h_11;
    r13 = _h_12;
    r14 = _h_13;
    r15 = _h_14;
    r16 = _h_15;
    r17 = _h_16;
    r18 = _h_17;
    r19 = _h_18;
    r20 = _h_19;
    r21 = _h_20;
    r22 = 0;
    r23 = 0;
    r24 = 0;
    WL_RETN(25);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN)
  {
    u32 _label_0 = r0;
    Term _array_0 = r1;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _fv_0[1];
    _fv_0[0] = 10ull;
    Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_0);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, 11ull);
    Term _at_2 = blk_loc(e.mem, _a_0);
    Term _at_3 = blk_at(_a_0, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, 12ull);
    Term _at_4 = blk_loc(e.mem, _a_0);
    Term _at_5 = blk_at(_a_0, 3ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, 13ull);
    Term _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_0[24];
    if (spin_28(e, _o_0, _array_0, 4ull, 999ull, 200ull, 300ull, 400ull, 77ull, _a_0, 6ull, 900ull, 901ull, 902ull, 903ull, 88ull, 7ull, 3ull, term_pak(CID_TRANSACTION_PROTOTYPEFLATEND, 0), term_pak(CID_TRANSACTION_PROTOTYPEFLATMARKSEND, 0)) == 0) {
      return 0;
    }
    _v_24 = _o_0[0];
    _v_25 = _o_0[1];
    _v_26 = _o_0[2];
    _v_27 = _o_0[3];
    _v_28 = _o_0[4];
    _v_29 = _o_0[5];
    _v_30 = _o_0[6];
    _v_31 = _o_0[7];
    _v_32 = _o_0[8];
    _v_33 = _o_0[9];
    _v_34 = _o_0[10];
    _v_35 = _o_0[11];
    _v_36 = _o_0[12];
    _v_37 = _o_0[13];
    _v_38 = _o_0[14];
    _v_39 = _o_0[15];
    _v_40 = _o_0[16];
    _v_41 = _o_0[17];
    _v_42 = _o_0[18];
    _v_43 = _o_0[19];
    _v_44 = _o_0[20];
    _v_45 = _o_0[21];
    _v_46 = _o_0[22];
    _v_47 = _o_0[23];
    _v_0 = _v_24;
    _v_1 = _v_25;
    _v_2 = _v_26;
    _v_3 = _v_27;
    _v_4 = _v_28;
    _v_5 = _v_29;
    _v_6 = _v_30;
    _v_7 = _v_31;
    _v_8 = _v_32;
    _v_9 = _v_33;
    _v_10 = _v_34;
    _v_11 = _v_35;
    _v_12 = _v_36;
    _v_13 = _v_37;
    _v_14 = _v_38;
    _v_15 = _v_39;
    _v_16 = _v_40;
    _v_17 = _v_41;
    _v_18 = _v_42;
    _v_19 = _v_43;
    _v_20 = _v_44;
    _v_21 = _v_45;
    _v_22 = _v_46;
    _v_23 = _v_47;
    if (_v_18 == 0) {
      Term _v_48 = 0;
      u32 _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      u32 _v_52 = 0;
      u32 _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      Term _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      u32 _v_68 = 0;
      u32 _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      u32 _v_73 = 0;
      Term _v_74 = 0;
      u32 _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      u32 _v_80 = 0;
      u32 _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      u32 _v_85 = 0;
      Term _o_1[19];
      if (spin_31(e, _o_1, _v_0, _v_1, _v_2, _v_3, _v_4, _v_5, _v_6, _v_7, _v_8, _v_9, _v_10, _v_11, _v_12, _v_13, _v_14, _v_15, _v_16, _v_17) == 0) {
        return 0;
      }
      _v_67 = _o_1[0];
      _v_68 = _o_1[1];
      _v_69 = _o_1[2];
      _v_70 = _o_1[3];
      _v_71 = _o_1[4];
      _v_72 = _o_1[5];
      _v_73 = _o_1[6];
      _v_74 = _o_1[7];
      _v_75 = _o_1[8];
      _v_76 = _o_1[9];
      _v_77 = _o_1[10];
      _v_78 = _o_1[11];
      _v_79 = _o_1[12];
      _v_80 = _o_1[13];
      _v_81 = _o_1[14];
      _v_82 = _o_1[15];
      _v_83 = _o_1[16];
      _v_84 = _o_1[17];
      _v_85 = _o_1[18];
      _v_48 = _v_67;
      _v_49 = _v_68;
      _v_50 = _v_69;
      _v_51 = _v_70;
      _v_52 = _v_71;
      _v_53 = _v_72;
      _v_54 = _v_73;
      _v_55 = _v_74;
      _v_56 = _v_75;
      _v_57 = _v_76;
      _v_58 = _v_77;
      _v_59 = _v_78;
      _v_60 = _v_79;
      _v_61 = _v_80;
      _v_62 = _v_81;
      _v_63 = _v_82;
      _v_64 = _v_83;
      _v_65 = _v_84;
      _v_66 = _v_85;
      if (seq) {
        WL_ROOM(25);
        STK(0) = _label_0;
        STK(1) = _v_19;
        STK(2) = _v_20;
        STK(3) = _v_21;
        STK(4) = _v_22;
        STK(5) = _v_23;
        STK(6) = _v_48;
        STK(7) = _v_49;
        STK(8) = _v_50;
        STK(9) = _v_51;
        STK(10) = _v_52;
        STK(11) = _v_53;
        STK(12) = _v_54;
        STK(13) = _v_55;
        STK(14) = _v_56;
        STK(15) = _v_57;
        STK(16) = _v_58;
        STK(17) = _v_59;
        STK(18) = _v_60;
        STK(19) = _v_61;
        STK(20) = _v_62;
        STK(21) = _v_63;
        STK(22) = _v_64;
        STK(23) = _v_65;
        STK(24) = FID_RUN_K288;
        WL_PUSHN(25);
      } else {
        u64 _t_0 = task_node(e, FID_RUN_K288, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _label_0;
        e.mem[_t_0 + 1] = _v_19;
        e.mem[_t_0 + 2] = _v_20;
        e.mem[_t_0 + 3] = _v_21;
        e.mem[_t_0 + 4] = _v_22;
        e.mem[_t_0 + 5] = _v_23;
        e.mem[_t_0 + 6] = _v_48;
        e.mem[_t_0 + 7] = _v_49;
        e.mem[_t_0 + 8] = _v_50;
        e.mem[_t_0 + 9] = _v_51;
        e.mem[_t_0 + 10] = _v_52;
        e.mem[_t_0 + 11] = _v_53;
        e.mem[_t_0 + 12] = _v_54;
        e.mem[_t_0 + 13] = _v_55;
        e.mem[_t_0 + 14] = _v_56;
        e.mem[_t_0 + 15] = _v_57;
        e.mem[_t_0 + 16] = _v_58;
        e.mem[_t_0 + 17] = _v_59;
        e.mem[_t_0 + 18] = _v_60;
        e.mem[_t_0 + 19] = _v_61;
        e.mem[_t_0 + 20] = _v_62;
        e.mem[_t_0 + 21] = _v_63;
        e.mem[_t_0 + 22] = _v_64;
        e.mem[_t_0 + 23] = _v_65;
        WL_CONT = term_tsk(FID_RUN_K288, _t_0);
        WL_IDX = 24;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
        u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = 2ull;
        return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_1);
      }
      r0 = 2ull;
      WL_JMP(FID_STORAGE_SLOTS_EMPTY);
    } else {
      term_sink(e, _v_0);
      term_sink(e, _v_7);
      term_sink(e, _v_16);
      term_sink(e, _v_17);
      u64 _nd_53 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 408);
      r0 = term_clo(FID_IO_PRINT, _nd_53);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K288)
  {
    WL_POPN(24);
    u32 _label_1 = STK(0);
    u32 _v_86 = STK(1);
    u32 _v_87 = STK(2);
    u32 _v_88 = STK(3);
    u32 _v_89 = STK(4);
    u32 _v_90 = STK(5);
    Term _v_91 = STK(6);
    u32 _v_92 = STK(7);
    u32 _v_93 = STK(8);
    u32 _v_94 = STK(9);
    u32 _v_95 = STK(10);
    u32 _v_96 = STK(11);
    u32 _v_97 = STK(12);
    Term _v_98 = STK(13);
    u32 _v_99 = STK(14);
    u32 _v_100 = STK(15);
    u32 _v_101 = STK(16);
    u32 _v_102 = STK(17);
    u32 _v_103 = STK(18);
    u32 _v_104 = STK(19);
    u32 _v_105 = STK(20);
    u32 _v_106 = STK(21);
    Term _v_107 = STK(22);
    Term _v_108 = STK(23);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _label_1;
      STK(1) = _v_86;
      STK(2) = _v_87;
      STK(3) = _v_88;
      STK(4) = _v_89;
      STK(5) = _v_90;
      STK(6) = _v_91;
      STK(7) = _v_92;
      STK(8) = _v_93;
      STK(9) = _v_94;
      STK(10) = _v_95;
      STK(11) = _v_96;
      STK(12) = _v_97;
      STK(13) = _v_98;
      STK(14) = _v_99;
      STK(15) = _v_100;
      STK(16) = _v_101;
      STK(17) = _v_102;
      STK(18) = _v_103;
      STK(19) = _v_104;
      STK(20) = _v_105;
      STK(21) = _v_106;
      STK(22) = _v_107;
      STK(23) = _v_108;
      STK(24) = _h_0;
      STK(25) = FID_RUN_K289;
      WL_PUSHN(26);
    } else {
      u64 _t_2 = task_node(e, FID_RUN_K289, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _label_1;
      e.mem[_t_2 + 1] = _v_86;
      e.mem[_t_2 + 2] = _v_87;
      e.mem[_t_2 + 3] = _v_88;
      e.mem[_t_2 + 4] = _v_89;
      e.mem[_t_2 + 5] = _v_90;
      e.mem[_t_2 + 6] = _v_91;
      e.mem[_t_2 + 7] = _v_92;
      e.mem[_t_2 + 8] = _v_93;
      e.mem[_t_2 + 9] = _v_94;
      e.mem[_t_2 + 10] = _v_95;
      e.mem[_t_2 + 11] = _v_96;
      e.mem[_t_2 + 12] = _v_97;
      e.mem[_t_2 + 13] = _v_98;
      e.mem[_t_2 + 14] = _v_99;
      e.mem[_t_2 + 15] = _v_100;
      e.mem[_t_2 + 16] = _v_101;
      e.mem[_t_2 + 17] = _v_102;
      e.mem[_t_2 + 18] = _v_103;
      e.mem[_t_2 + 19] = _v_104;
      e.mem[_t_2 + 20] = _v_105;
      e.mem[_t_2 + 21] = _v_106;
      e.mem[_t_2 + 22] = _v_107;
      e.mem[_t_2 + 23] = _v_108;
      e.mem[_t_2 + 24] = _h_0;
      WL_CONT = term_tsk(FID_RUN_K289, _t_2);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_3 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = 2ull;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_3);
    }
    r0 = 2ull;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K289)
  {
    WL_POPN(25);
    u32 _label_2 = STK(0);
    u32 _v_109 = STK(1);
    u32 _v_110 = STK(2);
    u32 _v_111 = STK(3);
    u32 _v_112 = STK(4);
    u32 _v_113 = STK(5);
    Term _v_114 = STK(6);
    u32 _v_115 = STK(7);
    u32 _v_116 = STK(8);
    u32 _v_117 = STK(9);
    u32 _v_118 = STK(10);
    u32 _v_119 = STK(11);
    u32 _v_120 = STK(12);
    Term _v_121 = STK(13);
    u32 _v_122 = STK(14);
    u32 _v_123 = STK(15);
    u32 _v_124 = STK(16);
    u32 _v_125 = STK(17);
    u32 _v_126 = STK(18);
    u32 _v_127 = STK(19);
    u32 _v_128 = STK(20);
    u32 _v_129 = STK(21);
    Term _v_130 = STK(22);
    Term _v_131 = STK(23);
    Term _h_2 = STK(24);
    Term _h_1 = r0;
    WL_OPEN
    Term _at_6 = blk_loc(e.mem, _h_2);
    Term _at_7 = blk_at(_h_2, 2ull, 1);
    u32 _c_3 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_4 = e.mem[_at_6 + _at_7 + 1];
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _t_4 = 1;
    if (_t_4 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_0 + 0] = _v_114;
      e.mem[_nd_0 + 1] = _v_115;
      e.mem[_nd_0 + 2] = _v_116;
      e.mem[_nd_0 + 3] = _v_117;
      e.mem[_nd_0 + 4] = _v_118;
      e.mem[_nd_0 + 5] = _v_119;
      e.mem[_nd_0 + 6] = _v_120;
      _o_3 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT, _nd_0);
    }
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _o_2);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _o_3);
    term_sink(e, _c_4);
    Term _fv_1[1];
    _fv_1[0] = 0;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_1);
    Term _at_8 = blk_loc(e.mem, _a_1);
    Term _at_9 = blk_at(_a_1, 2ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, 1);
    u32 _o_4 = 0;
    Term _o_5 = 0;
    Term _t_5 = 0;
    if (_t_5 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_TYPES_SELECTED, 0);
    }
    Term _fv_2[2];
    _fv_2[0] = _o_4;
    _fv_2[1] = _o_5;
    Term _a_2 = blk_new(e, 1, 2ull, 1, 2, _fv_2);
    Term _at_10 = blk_loc(e.mem, _a_2);
    Term _at_11 = blk_at(_a_2, 2ull, 1);
    u32 _c_6 = blk_read(e.mem, 1, _at_10, _at_11 + 0);
    Term _c_7 = e.mem[_at_10 + _at_11 + 1];
    u32 _o_6 = 0;
    Term _o_7 = 0;
    Term _t_6 = 1;
    if (_t_6 == 0) {
      _o_6 = 0;
    } else {
      _o_6 = 1;
      _o_7 = term_pak(CID_TYPES_SELECTED, 55ull);
    }
    blk_write(e.mem, 1, _at_10, _at_11 + 0, _o_6);
    blk_write(e.mem, 1, _at_10, _at_11 + 1, _o_7);
    term_sink(e, _c_7);
    Term _fv_3[1];
    _fv_3[0] = 11ull;
    Term _fv_4[1];
    _fv_4[0] = 22ull;
    if (seq) {
      WL_ROOM(7);
      STK(0) = _label_2;
      STK(1) = _v_109;
      STK(2) = _v_110;
      STK(3) = _v_111;
      STK(4) = _v_112;
      STK(5) = _v_113;
      STK(6) = FID_RUN_K290;
      WL_PUSHN(7);
    } else {
      u64 _t_7 = task_node(e, FID_RUN_K290, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _label_2;
      e.mem[_t_7 + 1] = _v_109;
      e.mem[_t_7 + 2] = _v_110;
      e.mem[_t_7 + 3] = _v_111;
      e.mem[_t_7 + 4] = _v_112;
      e.mem[_t_7 + 5] = _v_113;
      WL_CONT = term_tsk(FID_RUN_K290, _t_7);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0)) {
      u64 _t_8 = task_node(e, FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = 7ull;
      e.mem[_t_8 + 1] = 9ull;
      e.mem[_t_8 + 2] = _h_2;
      e.mem[_t_8 + 3] = _h_1;
      e.mem[_t_8 + 4] = _a_1;
      e.mem[_t_8 + 5] = _a_2;
      e.mem[_t_8 + 6] = blk_new(e, 0, 2ull, 0, 1, _fv_3);
      e.mem[_t_8 + 7] = blk_new(e, 0, 2ull, 0, 1, _fv_4);
      e.mem[_t_8 + 8] = 4ull;
      e.mem[_t_8 + 9] = 2ull;
      e.mem[_t_8 + 10] = 3ull;
      e.mem[_t_8 + 11] = term_ctr(CID_CON, STAT_OFF + 376);
      e.mem[_t_8 + 12] = 1;
      e.mem[_t_8 + 13] = _v_121;
      e.mem[_t_8 + 14] = _v_122;
      e.mem[_t_8 + 15] = _v_123;
      e.mem[_t_8 + 16] = _v_124;
      e.mem[_t_8 + 17] = _v_125;
      e.mem[_t_8 + 18] = _v_126;
      e.mem[_t_8 + 19] = _v_127;
      e.mem[_t_8 + 20] = 0;
      e.mem[_t_8 + 21] = _v_128;
      e.mem[_t_8 + 22] = _v_129;
      e.mem[_t_8 + 23] = _v_130;
      e.mem[_t_8 + 24] = term_ctr(CID_CON, STAT_OFF + 378);
      e.mem[_t_8 + 25] = term_ctr(CID_CON, STAT_OFF + 380);
      e.mem[_t_8 + 26] = _v_131;
      return term_tsk(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0, _t_8);
    }
    r0 = 7ull;
    r1 = 9ull;
    r2 = _h_2;
    r3 = _h_1;
    r4 = _a_1;
    r5 = _a_2;
    r6 = blk_new(e, 0, 2ull, 0, 1, _fv_3);
    r7 = blk_new(e, 0, 2ull, 0, 1, _fv_4);
    r8 = 4ull;
    r9 = 2ull;
    r10 = 3ull;
    r11 = term_ctr(CID_CON, STAT_OFF + 376);
    r12 = 1;
    r13 = _v_121;
    r14 = _v_122;
    r15 = _v_123;
    r16 = _v_124;
    r17 = _v_125;
    r18 = _v_126;
    r19 = _v_127;
    r20 = 0;
    r21 = _v_128;
    r22 = _v_129;
    r23 = _v_130;
    r24 = term_ctr(CID_CON, STAT_OFF + 378);
    r25 = term_ctr(CID_CON, STAT_OFF + 380);
    r26 = _v_131;
    WL_JMP(FID_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K290)
  {
    WL_POPN(6);
    u32 _label_3 = STK(0);
    u32 _v_132 = STK(1);
    u32 _v_133 = STK(2);
    u32 _v_134 = STK(3);
    u32 _v_135 = STK(4);
    u32 _v_136 = STK(5);
    u32 _h_3 = r0;
    u32 _h_4 = r1;
    Term _h_5 = r2;
    Term _h_6 = r3;
    Term _h_7 = r4;
    Term _h_8 = r5;
    Term _h_9 = r6;
    Term _h_10 = r7;
    u32 _h_11 = r8;
    Term _h_12 = r9;
    u32 _h_13 = r10;
    Term _h_14 = r11;
    u32 _h_15 = r12;
    Term _h_16 = r13;
    u32 _h_17 = r14;
    u32 _h_18 = r15;
    u32 _h_19 = r16;
    u32 _h_20 = r17;
    u32 _h_21 = r18;
    u32 _h_22 = r19;
    u32 _h_23 = r20;
    u32 _h_24 = r21;
    u32 _h_25 = r22;
    Term _h_26 = r23;
    Term _h_27 = r24;
    Term _h_28 = r25;
    Term _h_29 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _label_3;
      STK(1) = _v_132;
      STK(2) = _v_133;
      STK(3) = _v_134;
      STK(4) = _v_135;
      STK(5) = _v_136;
      STK(6) = FID_RUN_K291;
      WL_PUSHN(7);
    } else {
      u64 _t_9 = task_node(e, FID_RUN_K291, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _label_3;
      e.mem[_t_9 + 1] = _v_132;
      e.mem[_t_9 + 2] = _v_133;
      e.mem[_t_9 + 3] = _v_134;
      e.mem[_t_9 + 4] = _v_135;
      e.mem[_t_9 + 5] = _v_136;
      WL_CONT = term_tsk(FID_RUN_K291, _t_9);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE)) {
      u64 _t_10 = task_node(e, FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_3;
      e.mem[_t_10 + 1] = _h_4;
      e.mem[_t_10 + 2] = _h_5;
      e.mem[_t_10 + 3] = _h_6;
      e.mem[_t_10 + 4] = _h_7;
      e.mem[_t_10 + 5] = _h_8;
      e.mem[_t_10 + 6] = _h_9;
      e.mem[_t_10 + 7] = _h_10;
      e.mem[_t_10 + 8] = _h_11;
      e.mem[_t_10 + 9] = _h_12;
      e.mem[_t_10 + 10] = _h_13;
      e.mem[_t_10 + 11] = _h_14;
      e.mem[_t_10 + 12] = _h_15;
      e.mem[_t_10 + 13] = _h_16;
      e.mem[_t_10 + 14] = _h_17;
      e.mem[_t_10 + 15] = _h_18;
      e.mem[_t_10 + 16] = _h_19;
      e.mem[_t_10 + 17] = _h_20;
      e.mem[_t_10 + 18] = _h_21;
      e.mem[_t_10 + 19] = _h_22;
      e.mem[_t_10 + 20] = _h_23;
      e.mem[_t_10 + 21] = _h_24;
      e.mem[_t_10 + 22] = _h_25;
      e.mem[_t_10 + 23] = _h_26;
      e.mem[_t_10 + 24] = _h_27;
      e.mem[_t_10 + 25] = _h_28;
      e.mem[_t_10 + 26] = _h_29;
      return term_tsk(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE, _t_10);
    }
    r0 = _h_3;
    r1 = _h_4;
    r2 = _h_5;
    r3 = _h_6;
    r4 = _h_7;
    r5 = _h_8;
    r6 = _h_9;
    r7 = _h_10;
    r8 = _h_11;
    r9 = _h_12;
    r10 = _h_13;
    r11 = _h_14;
    r12 = _h_15;
    r13 = _h_16;
    r14 = _h_17;
    r15 = _h_18;
    r16 = _h_19;
    r17 = _h_20;
    r18 = _h_21;
    r19 = _h_22;
    r20 = _h_23;
    r21 = _h_24;
    r22 = _h_25;
    r23 = _h_26;
    r24 = _h_27;
    r25 = _h_28;
    r26 = _h_29;
    WL_JMP(FID_TRANSACTION_DISPATCH_ADAPTERS_PROTOTYPE_PACKED_MOTION_FINISH_FAILURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K291)
  {
    WL_POPN(6);
    u32 _label_4 = STK(0);
    u32 _v_137 = STK(1);
    u32 _v_138 = STK(2);
    u32 _v_139 = STK(3);
    u32 _v_140 = STK(4);
    u32 _v_141 = STK(5);
    u32 _h_30 = r0;
    u32 _h_31 = r1;
    u32 _h_32 = r2;
    Term _h_33 = r3;
    Term _h_34 = r4;
    Term _h_35 = r5;
    Term _h_36 = r6;
    Term _h_37 = r7;
    Term _h_38 = r8;
    u32 _h_39 = r9;
    Term _h_40 = r10;
    u32 _h_41 = r11;
    Term _h_42 = r12;
    u32 _h_43 = r13;
    Term _h_44 = r14;
    u32 _h_45 = r15;
    u32 _h_46 = r16;
    u32 _h_47 = r17;
    u32 _h_48 = r18;
    u32 _h_49 = r19;
    u32 _h_50 = r20;
    u32 _h_51 = r21;
    Term _h_52 = r22;
    Term _h_53 = r23;
    Term _h_54 = r24;
    WL_OPEN
    if (_h_30 == 1) {
      if (blk_cls(_h_33) != 1) {
        Term _h_55 = blk_half(e, _h_33, 0);
        Term _h_56 = blk_half(e, _h_33, 1);
        if (blk_cls(_h_55) != 1) {
          Term _h_57 = blk_half(e, _h_55, 0);
          Term _h_58 = blk_half(e, _h_55, 1);
          if (blk_cls(_h_57) == 1) {
            u32 _c_8 = blk_read(e.mem, 1, blk_loc(e.mem, _h_57), 0 + 0);
            Term _c_9 = blk_shr(_h_57) ? blk_keep(e, blk_loc(e.mem, _h_57) + 0 + 1) : e.mem[blk_loc(e.mem, _h_57) + 0 + 1];
            blk_free(e, _h_57);
            u32 _o_8 = 0;
            Term _o_9 = 0;
            u32 _o_10 = 0;
            u32 _o_11 = 0;
            u32 _o_12 = 0;
            u32 _o_13 = 0;
            u32 _o_14 = 0;
            u32 _o_15 = 0;
            if (_c_8 == 0) {
              _o_8 = 0;
            } else {
              _o_8 = 1;
              u64 _sp_0 = term_loc(_c_9);
              Term _f_0 = e.mem[_sp_0 + 0];
              u32 _f_1 = e.mem[_sp_0 + 1];
              u32 _f_2 = e.mem[_sp_0 + 2];
              u32 _f_3 = e.mem[_sp_0 + 3];
              u32 _f_4 = e.mem[_sp_0 + 4];
              u32 _f_5 = e.mem[_sp_0 + 5];
              u32 _f_6 = e.mem[_sp_0 + 6];
              heap_free(e, cls_fit(7), _sp_0);
              _o_9 = _f_0;
              _o_10 = _f_1;
              _o_11 = _f_2;
              _o_12 = _f_3;
              _o_13 = _f_4;
              _o_14 = _f_5;
              _o_15 = _f_6;
            }
            if (_o_8 == 0) {
              if (blk_cls(_h_58) == 1) {
                u32 _c_10 = blk_read(e.mem, 1, blk_loc(e.mem, _h_58), 0 + 0);
                Term _c_11 = blk_shr(_h_58) ? blk_keep(e, blk_loc(e.mem, _h_58) + 0 + 1) : e.mem[blk_loc(e.mem, _h_58) + 0 + 1];
                blk_free(e, _h_58);
                u32 _o_16 = 0;
                Term _o_17 = 0;
                u32 _o_18 = 0;
                u32 _o_19 = 0;
                u32 _o_20 = 0;
                u32 _o_21 = 0;
                u32 _o_22 = 0;
                u32 _o_23 = 0;
                if (_c_10 == 0) {
                  _o_16 = 0;
                } else {
                  _o_16 = 1;
                  u64 _sp_1 = term_loc(_c_11);
                  Term _f_7 = e.mem[_sp_1 + 0];
                  u32 _f_8 = e.mem[_sp_1 + 1];
                  u32 _f_9 = e.mem[_sp_1 + 2];
                  u32 _f_10 = e.mem[_sp_1 + 3];
                  u32 _f_11 = e.mem[_sp_1 + 4];
                  u32 _f_12 = e.mem[_sp_1 + 5];
                  u32 _f_13 = e.mem[_sp_1 + 6];
                  heap_free(e, cls_fit(7), _sp_1);
                  _o_17 = _f_7;
                  _o_18 = _f_8;
                  _o_19 = _f_9;
                  _o_20 = _f_10;
                  _o_21 = _f_11;
                  _o_22 = _f_12;
                  _o_23 = _f_13;
                }
                if (_o_16 == 0) {
                  if (blk_cls(_h_56) != 1) {
                    Term _h_59 = blk_half(e, _h_56, 0);
                    Term _h_60 = blk_half(e, _h_56, 1);
                    if (blk_cls(_h_59) == 1) {
                      u32 _c_12 = blk_read(e.mem, 1, blk_loc(e.mem, _h_59), 0 + 0);
                      Term _c_13 = blk_shr(_h_59) ? blk_keep(e, blk_loc(e.mem, _h_59) + 0 + 1) : e.mem[blk_loc(e.mem, _h_59) + 0 + 1];
                      blk_free(e, _h_59);
                      u32 _o_24 = 0;
                      Term _o_25 = 0;
                      u32 _o_26 = 0;
                      u32 _o_27 = 0;
                      u32 _o_28 = 0;
                      u32 _o_29 = 0;
                      u32 _o_30 = 0;
                      u32 _o_31 = 0;
                      if (_c_12 == 0) {
                        _o_24 = 0;
                      } else {
                        _o_24 = 1;
                        u64 _sp_2 = term_loc(_c_13);
                        Term _f_14 = e.mem[_sp_2 + 0];
                        u32 _f_15 = e.mem[_sp_2 + 1];
                        u32 _f_16 = e.mem[_sp_2 + 2];
                        u32 _f_17 = e.mem[_sp_2 + 3];
                        u32 _f_18 = e.mem[_sp_2 + 4];
                        u32 _f_19 = e.mem[_sp_2 + 5];
                        u32 _f_20 = e.mem[_sp_2 + 6];
                        heap_free(e, cls_fit(7), _sp_2);
                        _o_25 = _f_14;
                        _o_26 = _f_15;
                        _o_27 = _f_16;
                        _o_28 = _f_17;
                        _o_29 = _f_18;
                        _o_30 = _f_19;
                        _o_31 = _f_20;
                      }
                      if (_o_24 == 1) {
                        if (blk_cls(_h_60) == 1) {
                          u32 _c_14 = blk_read(e.mem, 1, blk_loc(e.mem, _h_60), 0 + 0);
                          Term _c_15 = blk_shr(_h_60) ? blk_keep(e, blk_loc(e.mem, _h_60) + 0 + 1) : e.mem[blk_loc(e.mem, _h_60) + 0 + 1];
                          blk_free(e, _h_60);
                          u32 _o_32 = 0;
                          Term _o_33 = 0;
                          u32 _o_34 = 0;
                          u32 _o_35 = 0;
                          u32 _o_36 = 0;
                          u32 _o_37 = 0;
                          u32 _o_38 = 0;
                          u32 _o_39 = 0;
                          if (_c_14 == 0) {
                            _o_32 = 0;
                          } else {
                            _o_32 = 1;
                            u64 _sp_3 = term_loc(_c_15);
                            Term _f_21 = e.mem[_sp_3 + 0];
                            u32 _f_22 = e.mem[_sp_3 + 1];
                            u32 _f_23 = e.mem[_sp_3 + 2];
                            u32 _f_24 = e.mem[_sp_3 + 3];
                            u32 _f_25 = e.mem[_sp_3 + 4];
                            u32 _f_26 = e.mem[_sp_3 + 5];
                            u32 _f_27 = e.mem[_sp_3 + 6];
                            heap_free(e, cls_fit(7), _sp_3);
                            _o_33 = _f_21;
                            _o_34 = _f_22;
                            _o_35 = _f_23;
                            _o_36 = _f_24;
                            _o_37 = _f_25;
                            _o_38 = _f_26;
                            _o_39 = _f_27;
                          }
                          if (_o_32 == 0) {
                            if (blk_cls(_h_34) != 1) {
                              Term _h_61 = blk_half(e, _h_34, 0);
                              Term _h_62 = blk_half(e, _h_34, 1);
                              if (blk_cls(_h_61) != 1) {
                                Term _h_63 = blk_half(e, _h_61, 0);
                                Term _h_64 = blk_half(e, _h_61, 1);
                                if (blk_cls(_h_63) == 1) {
                                  u32 _c_16 = blk_read(e.mem, 1, blk_loc(e.mem, _h_63), 0 + 0);
                                  Term _c_17 = blk_shr(_h_63) ? blk_keep(e, blk_loc(e.mem, _h_63) + 0 + 1) : e.mem[blk_loc(e.mem, _h_63) + 0 + 1];
                                  blk_free(e, _h_63);
                                  u32 _o_40 = 0;
                                  Term _o_41 = 0;
                                  u32 _o_42 = 0;
                                  if (_c_16 == 0) {
                                    _o_40 = 0;
                                  } else {
                                    _o_40 = 1;
                                    u64 _sp_4 = term_loc(_c_17);
                                    Term _f_28 = e.mem[_sp_4 + 0];
                                    u32 _f_29 = e.mem[_sp_4 + 1];
                                    heap_free(e, cls_fit(2), _sp_4);
                                    _o_41 = _f_28;
                                    _o_42 = _f_29;
                                  }
                                  if (_o_40 == 0) {
                                    if (blk_cls(_h_64) == 1) {
                                      u32 _c_18 = blk_read(e.mem, 1, blk_loc(e.mem, _h_64), 0 + 0);
                                      Term _c_19 = blk_shr(_h_64) ? blk_keep(e, blk_loc(e.mem, _h_64) + 0 + 1) : e.mem[blk_loc(e.mem, _h_64) + 0 + 1];
                                      blk_free(e, _h_64);
                                      u32 _o_43 = 0;
                                      Term _o_44 = 0;
                                      u32 _o_45 = 0;
                                      if (_c_18 == 0) {
                                        _o_43 = 0;
                                      } else {
                                        _o_43 = 1;
                                        u64 _sp_5 = term_loc(_c_19);
                                        Term _f_30 = e.mem[_sp_5 + 0];
                                        u32 _f_31 = e.mem[_sp_5 + 1];
                                        heap_free(e, cls_fit(2), _sp_5);
                                        _o_44 = _f_30;
                                        _o_45 = _f_31;
                                      }
                                      if (_o_43 == 0) {
                                        if (blk_cls(_h_62) != 1) {
                                          Term _h_65 = blk_half(e, _h_62, 0);
                                          Term _h_66 = blk_half(e, _h_62, 1);
                                          if (blk_cls(_h_65) == 1) {
                                            u32 _c_20 = blk_read(e.mem, 1, blk_loc(e.mem, _h_65), 0 + 0);
                                            Term _c_21 = blk_shr(_h_65) ? blk_keep(e, blk_loc(e.mem, _h_65) + 0 + 1) : e.mem[blk_loc(e.mem, _h_65) + 0 + 1];
                                            blk_free(e, _h_65);
                                            u32 _o_46 = 0;
                                            Term _o_47 = 0;
                                            u32 _o_48 = 0;
                                            if (_c_20 == 0) {
                                              _o_46 = 0;
                                            } else {
                                              _o_46 = 1;
                                              u64 _sp_6 = term_loc(_c_21);
                                              Term _f_32 = e.mem[_sp_6 + 0];
                                              u32 _f_33 = e.mem[_sp_6 + 1];
                                              heap_free(e, cls_fit(2), _sp_6);
                                              _o_47 = _f_32;
                                              _o_48 = _f_33;
                                            }
                                            if (_o_46 == 0) {
                                              if (blk_cls(_h_66) == 1) {
                                                u32 _c_22 = blk_read(e.mem, 1, blk_loc(e.mem, _h_66), 0 + 0);
                                                Term _c_23 = blk_shr(_h_66) ? blk_keep(e, blk_loc(e.mem, _h_66) + 0 + 1) : e.mem[blk_loc(e.mem, _h_66) + 0 + 1];
                                                blk_free(e, _h_66);
                                                u32 _o_49 = 0;
                                                Term _o_50 = 0;
                                                u32 _o_51 = 0;
                                                if (_c_22 == 0) {
                                                  _o_49 = 0;
                                                } else {
                                                  _o_49 = 1;
                                                  u64 _sp_7 = term_loc(_c_23);
                                                  Term _f_34 = e.mem[_sp_7 + 0];
                                                  u32 _f_35 = e.mem[_sp_7 + 1];
                                                  heap_free(e, cls_fit(2), _sp_7);
                                                  _o_50 = _f_34;
                                                  _o_51 = _f_35;
                                                }
                                                if (_o_49 == 0) {
                                                  if (blk_cls(_h_35) != 0) {
                                                    Term _h_67 = blk_half(e, _h_35, 0);
                                                    Term _h_68 = blk_half(e, _h_35, 1);
                                                    if (blk_cls(_h_67) != 0) {
                                                      Term _h_69 = blk_half(e, _h_67, 0);
                                                      Term _h_70 = blk_half(e, _h_67, 1);
                                                      if (blk_cls(_h_69) == 0) {
                                                        u32 _c_24 = blk_read(e.mem, 0, blk_loc(e.mem, _h_69), 0 + 0);
                                                        blk_free(e, _h_69);
                                                        if (_c_24 == 0) {
                                                          if (blk_cls(_h_70) == 0) {
                                                            u32 _c_25 = blk_read(e.mem, 0, blk_loc(e.mem, _h_70), 0 + 0);
                                                            blk_free(e, _h_70);
                                                            if (_c_25 == 0) {
                                                              if (blk_cls(_h_68) != 0) {
                                                                Term _h_71 = blk_half(e, _h_68, 0);
                                                                Term _h_72 = blk_half(e, _h_68, 1);
                                                                if (blk_cls(_h_71) == 0) {
                                                                  u32 _c_26 = blk_read(e.mem, 0, blk_loc(e.mem, _h_71), 0 + 0);
                                                                  blk_free(e, _h_71);
                                                                  if (_c_26 == 1) {
                                                                    if (blk_cls(_h_72) == 0) {
                                                                      u32 _c_27 = blk_read(e.mem, 0, blk_loc(e.mem, _h_72), 0 + 0);
                                                                      blk_free(e, _h_72);
                                                                      if (_c_27 == 0) {
                                                                        if (blk_cls(_h_36) != 1) {
                                                                          Term _h_73 = blk_half(e, _h_36, 0);
                                                                          Term _h_74 = blk_half(e, _h_36, 1);
                                                                          if (blk_cls(_h_73) != 1) {
                                                                            Term _h_75 = blk_half(e, _h_73, 0);
                                                                            Term _h_76 = blk_half(e, _h_73, 1);
                                                                            if (blk_cls(_h_75) == 1) {
                                                                              u32 _c_28 = blk_read(e.mem, 1, blk_loc(e.mem, _h_75), 0 + 0);
                                                                              Term _c_29 = blk_shr(_h_75) ? blk_keep(e, blk_loc(e.mem, _h_75) + 0 + 1) : e.mem[blk_loc(e.mem, _h_75) + 0 + 1];
                                                                              blk_free(e, _h_75);
                                                                              u32 _o_52 = 0;
                                                                              u32 _o_53 = 0;
                                                                              if (_c_28 == 0) {
                                                                                _o_52 = 0;
                                                                              } else {
                                                                                _o_52 = 1;
                                                                                _o_53 = term_loc(_c_29);
                                                                              }
                                                                              if (_o_52 == 0) {
                                                                                if (blk_cls(_h_76) == 1) {
                                                                                  u32 _c_30 = blk_read(e.mem, 1, blk_loc(e.mem, _h_76), 0 + 0);
                                                                                  Term _c_31 = blk_shr(_h_76) ? blk_keep(e, blk_loc(e.mem, _h_76) + 0 + 1) : e.mem[blk_loc(e.mem, _h_76) + 0 + 1];
                                                                                  blk_free(e, _h_76);
                                                                                  u32 _o_54 = 0;
                                                                                  u32 _o_55 = 0;
                                                                                  if (_c_30 == 0) {
                                                                                    _o_54 = 0;
                                                                                  } else {
                                                                                    _o_54 = 1;
                                                                                    _o_55 = term_loc(_c_31);
                                                                                  }
                                                                                  if (_o_54 == 0) {
                                                                                    if (blk_cls(_h_74) != 1) {
                                                                                      Term _h_77 = blk_half(e, _h_74, 0);
                                                                                      Term _h_78 = blk_half(e, _h_74, 1);
                                                                                      if (blk_cls(_h_77) == 1) {
                                                                                        u32 _c_32 = blk_read(e.mem, 1, blk_loc(e.mem, _h_77), 0 + 0);
                                                                                        Term _c_33 = blk_shr(_h_77) ? blk_keep(e, blk_loc(e.mem, _h_77) + 0 + 1) : e.mem[blk_loc(e.mem, _h_77) + 0 + 1];
                                                                                        blk_free(e, _h_77);
                                                                                        u32 _o_56 = 0;
                                                                                        u32 _o_57 = 0;
                                                                                        if (_c_32 == 0) {
                                                                                          _o_56 = 0;
                                                                                        } else {
                                                                                          _o_56 = 1;
                                                                                          _o_57 = term_loc(_c_33);
                                                                                        }
                                                                                        if (_o_56 == 1) {
                                                                                          if (_o_57 == 55) {
                                                                                            if (blk_cls(_h_78) == 1) {
                                                                                              u32 _c_34 = blk_read(e.mem, 1, blk_loc(e.mem, _h_78), 0 + 0);
                                                                                              Term _c_35 = blk_shr(_h_78) ? blk_keep(e, blk_loc(e.mem, _h_78) + 0 + 1) : e.mem[blk_loc(e.mem, _h_78) + 0 + 1];
                                                                                              blk_free(e, _h_78);
                                                                                              u32 _o_58 = 0;
                                                                                              u32 _o_59 = 0;
                                                                                              if (_c_34 == 0) {
                                                                                                _o_58 = 0;
                                                                                              } else {
                                                                                                _o_58 = 1;
                                                                                                _o_59 = term_loc(_c_35);
                                                                                              }
                                                                                              if (_o_58 == 0) {
                                                                                                if (term_aux(_h_42) == CID_CON) {
                                                                                                  Term _fb_0[2];
                                                                                                  u64 _sp_8 = ctr_take(e, _h_42, 2, _fb_0);
                                                                                                  Term _f_36 = _fb_0[0];
                                                                                                  Term _f_37 = _fb_0[1];
                                                                                                  u32 _o_60 = 0;
                                                                                                  u32 _o_61 = 0;
                                                                                                  Term _o_62 = 0;
                                                                                                  Term _o_63 = 0;
                                                                                                  u32 _o_64 = 0;
                                                                                                  u32 _o_65 = 0;
                                                                                                  u32 _o_66 = 0;
                                                                                                  u32 _o_67 = 0;
                                                                                                  u32 _o_68 = 0;
                                                                                                  u32 _o_69 = 0;
                                                                                                  u32 _o_70 = 0;
                                                                                                  Term _o_71 = 0;
                                                                                                  u32 _o_72 = 0;
                                                                                                  u32 _o_73 = 0;
                                                                                                  u32 _o_74 = 0;
                                                                                                  if (term_aux(_f_36) == CID_STORAGE_SPAWN) {
                                                                                                    _o_60 = 0;
                                                                                                    u64 _sp_9 = term_loc(_f_36);
                                                                                                    u32 _f_38 = e.mem[_sp_9 + 0];
                                                                                                    u32 _f_39 = e.mem[_sp_9 + 1];
                                                                                                    Term _f_40 = e.mem[_sp_9 + 2];
                                                                                                    u32 _f_41 = e.mem[_sp_9 + 3];
                                                                                                    Term _f_42 = e.mem[_sp_9 + 4];
                                                                                                    u32 _f_43 = e.mem[_sp_9 + 5];
                                                                                                    Term _f_44 = e.mem[_sp_9 + 6];
                                                                                                    heap_free(e, cls_fit(7), _sp_9);
                                                                                                    u32 _o_75 = 0;
                                                                                                    Term _o_76 = 0;
                                                                                                    u32 _o_77 = 0;
                                                                                                    u32 _o_78 = 0;
                                                                                                    u32 _o_79 = 0;
                                                                                                    u32 _o_80 = 0;
                                                                                                    u32 _o_81 = 0;
                                                                                                    u32 _o_82 = 0;
                                                                                                    if (_f_39 == 0) {
                                                                                                      _o_75 = 0;
                                                                                                    } else {
                                                                                                      _o_75 = 1;
                                                                                                      u64 _sp_10 = term_loc(_f_40);
                                                                                                      Term _f_45 = e.mem[_sp_10 + 0];
                                                                                                      u32 _f_46 = e.mem[_sp_10 + 1];
                                                                                                      u32 _f_47 = e.mem[_sp_10 + 2];
                                                                                                      u32 _f_48 = e.mem[_sp_10 + 3];
                                                                                                      u32 _f_49 = e.mem[_sp_10 + 4];
                                                                                                      u32 _f_50 = e.mem[_sp_10 + 5];
                                                                                                      u32 _f_51 = e.mem[_sp_10 + 6];
                                                                                                      heap_free(e, cls_fit(7), _sp_10);
                                                                                                      _o_76 = _f_45;
                                                                                                      _o_77 = _f_46;
                                                                                                      _o_78 = _f_47;
                                                                                                      _o_79 = _f_48;
                                                                                                      _o_80 = _f_49;
                                                                                                      _o_81 = _f_50;
                                                                                                      _o_82 = _f_51;
                                                                                                    }
                                                                                                    u32 _o_83 = 0;
                                                                                                    Term _o_84 = 0;
                                                                                                    u32 _o_85 = 0;
                                                                                                    if (_f_41 == 0) {
                                                                                                      _o_83 = 0;
                                                                                                    } else {
                                                                                                      _o_83 = 1;
                                                                                                      u64 _sp_11 = term_loc(_f_42);
                                                                                                      Term _f_52 = e.mem[_sp_11 + 0];
                                                                                                      u32 _f_53 = e.mem[_sp_11 + 1];
                                                                                                      heap_free(e, cls_fit(2), _sp_11);
                                                                                                      _o_84 = _f_52;
                                                                                                      _o_85 = _f_53;
                                                                                                    }
                                                                                                    u32 _o_86 = 0;
                                                                                                    u32 _o_87 = 0;
                                                                                                    if (_f_43 == 0) {
                                                                                                      _o_86 = 0;
                                                                                                    } else {
                                                                                                      _o_86 = 1;
                                                                                                      _o_87 = term_loc(_f_44);
                                                                                                    }
                                                                                                    _o_61 = _f_38;
                                                                                                    _o_62 = _o_75;
                                                                                                    _o_63 = _o_76;
                                                                                                    _o_64 = _o_77;
                                                                                                    _o_65 = _o_78;
                                                                                                    _o_66 = _o_79;
                                                                                                    _o_67 = _o_80;
                                                                                                    _o_68 = _o_81;
                                                                                                    _o_69 = _o_82;
                                                                                                    _o_70 = _o_83;
                                                                                                    _o_71 = _o_84;
                                                                                                    _o_72 = _o_85;
                                                                                                    _o_73 = _o_86;
                                                                                                    _o_74 = _o_87;
                                                                                                  } else if (term_aux(_f_36) == CID_STORAGE_INSERTMAIN) {
                                                                                                    _o_60 = 1;
                                                                                                    u64 _sp_12 = term_loc(_f_36);
                                                                                                    u32 _f_54 = e.mem[_sp_12 + 0];
                                                                                                    Term _f_55 = e.mem[_sp_12 + 1];
                                                                                                    heap_free(e, cls_fit(2), _sp_12);
                                                                                                    u64 _sp_13 = term_loc(_f_55);
                                                                                                    Term _f_56 = e.mem[_sp_13 + 0];
                                                                                                    u32 _f_57 = e.mem[_sp_13 + 1];
                                                                                                    u32 _f_58 = e.mem[_sp_13 + 2];
                                                                                                    u32 _f_59 = e.mem[_sp_13 + 3];
                                                                                                    u32 _f_60 = e.mem[_sp_13 + 4];
                                                                                                    u32 _f_61 = e.mem[_sp_13 + 5];
                                                                                                    u32 _f_62 = e.mem[_sp_13 + 6];
                                                                                                    heap_free(e, cls_fit(7), _sp_13);
                                                                                                    _o_61 = _f_54;
                                                                                                    _o_62 = _f_56;
                                                                                                    _o_63 = _f_57;
                                                                                                    _o_64 = _f_58;
                                                                                                    _o_65 = _f_59;
                                                                                                    _o_66 = _f_60;
                                                                                                    _o_67 = _f_61;
                                                                                                    _o_68 = _f_62;
                                                                                                  } else if (term_aux(_f_36) == CID_STORAGE_INSERTFLAG) {
                                                                                                    _o_60 = 2;
                                                                                                    u64 _sp_14 = term_loc(_f_36);
                                                                                                    u32 _f_63 = e.mem[_sp_14 + 0];
                                                                                                    Term _f_64 = e.mem[_sp_14 + 1];
                                                                                                    heap_free(e, cls_fit(2), _sp_14);
                                                                                                    _o_61 = _f_63;
                                                                                                    _o_62 = term_loc(_f_64);
                                                                                                  } else if (term_aux(_f_36) == CID_STORAGE_REMOVEMAIN) {
                                                                                                    _o_60 = 3;
                                                                                                    _o_61 = term_loc(_f_36);
                                                                                                  } else if (term_aux(_f_36) == CID_STORAGE_REMOVEFLAG) {
                                                                                                    _o_60 = 4;
                                                                                                    _o_61 = term_loc(_f_36);
                                                                                                  } else {
                                                                                                    _o_60 = 5;
                                                                                                    _o_61 = term_loc(_f_36);
                                                                                                  }
                                                                                                  if (_o_60 == 5) {
                                                                                                    if (term_aux(_f_37) == CID_NIL) {
                                                                                                      if (_h_43 == 1) {
                                                                                                        if (_h_51 == 0) {
                                                                                                          spare_free(e, cls_fit(2), _sp_8);
                                                                                                          if (seq) {
                                                                                                            WL_ROOM(28);
                                                                                                            STK(0) = _v_137;
                                                                                                            STK(1) = _v_138;
                                                                                                            STK(2) = _v_139;
                                                                                                            STK(3) = _v_140;
                                                                                                            STK(4) = _v_141;
                                                                                                            STK(5) = _h_31;
                                                                                                            STK(6) = _h_32;
                                                                                                            STK(7) = _o_25;
                                                                                                            STK(8) = _o_26;
                                                                                                            STK(9) = _o_27;
                                                                                                            STK(10) = _o_28;
                                                                                                            STK(11) = _o_29;
                                                                                                            STK(12) = _o_30;
                                                                                                            STK(13) = _o_31;
                                                                                                            STK(14) = _h_37;
                                                                                                            STK(15) = _h_38;
                                                                                                            STK(16) = _h_39;
                                                                                                            STK(17) = _h_40;
                                                                                                            STK(18) = _h_41;
                                                                                                            STK(19) = _o_61;
                                                                                                            STK(20) = _h_44;
                                                                                                            STK(21) = _h_45;
                                                                                                            STK(22) = _h_46;
                                                                                                            STK(23) = _h_47;
                                                                                                            STK(24) = _h_48;
                                                                                                            STK(25) = _h_49;
                                                                                                            STK(26) = _h_50;
                                                                                                            STK(27) = FID_RUN_K292;
                                                                                                            WL_PUSHN(28);
                                                                                                          } else {
                                                                                                            u64 _t_11 = task_node(e, FID_RUN_K292, WL_CONT, WL_IDX, 1);
                                                                                                            e.mem[_t_11 + 0] = _v_137;
                                                                                                            e.mem[_t_11 + 1] = _v_138;
                                                                                                            e.mem[_t_11 + 2] = _v_139;
                                                                                                            e.mem[_t_11 + 3] = _v_140;
                                                                                                            e.mem[_t_11 + 4] = _v_141;
                                                                                                            e.mem[_t_11 + 5] = _h_31;
                                                                                                            e.mem[_t_11 + 6] = _h_32;
                                                                                                            e.mem[_t_11 + 7] = _o_25;
                                                                                                            e.mem[_t_11 + 8] = _o_26;
                                                                                                            e.mem[_t_11 + 9] = _o_27;
                                                                                                            e.mem[_t_11 + 10] = _o_28;
                                                                                                            e.mem[_t_11 + 11] = _o_29;
                                                                                                            e.mem[_t_11 + 12] = _o_30;
                                                                                                            e.mem[_t_11 + 13] = _o_31;
                                                                                                            e.mem[_t_11 + 14] = _h_37;
                                                                                                            e.mem[_t_11 + 15] = _h_38;
                                                                                                            e.mem[_t_11 + 16] = _h_39;
                                                                                                            e.mem[_t_11 + 17] = _h_40;
                                                                                                            e.mem[_t_11 + 18] = _h_41;
                                                                                                            e.mem[_t_11 + 19] = _o_61;
                                                                                                            e.mem[_t_11 + 20] = _h_44;
                                                                                                            e.mem[_t_11 + 21] = _h_45;
                                                                                                            e.mem[_t_11 + 22] = _h_46;
                                                                                                            e.mem[_t_11 + 23] = _h_47;
                                                                                                            e.mem[_t_11 + 24] = _h_48;
                                                                                                            e.mem[_t_11 + 25] = _h_49;
                                                                                                            e.mem[_t_11 + 26] = _h_50;
                                                                                                            WL_CONT = term_tsk(FID_RUN_K292, _t_11);
                                                                                                            WL_IDX = 27;
                                                                                                          }
                                                                                                          if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
                                                                                                            u64 _t_12 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
                                                                                                            e.mem[_t_12 + 0] = _label_4;
                                                                                                            return term_tsk(FID_U32_SHOW, _t_12);
                                                                                                          }
                                                                                                          r0 = _label_4;
                                                                                                          WL_JMP(FID_U32_SHOW);
                                                                                                        } else {
                                                                                                          term_sink(e, _o_25);
                                                                                                          term_sink(e, _h_37);
                                                                                                          term_sink(e, _h_38);
                                                                                                          term_sink(e, _h_44);
                                                                                                          u64 _nd_2 = heap_alloc(e, cls_fit(1));
                                                                                                          e.mem[_nd_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                          spare_free(e, cls_fit(2), _sp_8);
                                                                                                          r0 = term_clo(FID_IO_PRINT, _nd_2);
                                                                                                          WL_RETN(1);
                                                                                                        }
                                                                                                      } else {
                                                                                                        term_sink(e, _o_25);
                                                                                                        term_sink(e, _h_37);
                                                                                                        term_sink(e, _h_38);
                                                                                                        term_sink(e, _h_44);
                                                                                                        u64 _nd_3 = heap_alloc(e, cls_fit(1));
                                                                                                        e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                        spare_free(e, cls_fit(2), _sp_8);
                                                                                                        r0 = term_clo(FID_IO_PRINT, _nd_3);
                                                                                                        WL_RETN(1);
                                                                                                      }
                                                                                                    } else {
                                                                                                      term_sink(e, _o_25);
                                                                                                      term_sink(e, _h_37);
                                                                                                      term_sink(e, _h_38);
                                                                                                      term_sink(e, _f_37);
                                                                                                      term_sink(e, _h_44);
                                                                                                      u64 _nd_4 = heap_alloc(e, cls_fit(1));
                                                                                                      e.mem[_nd_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                      spare_free(e, cls_fit(2), _sp_8);
                                                                                                      r0 = term_clo(FID_IO_PRINT, _nd_4);
                                                                                                      WL_RETN(1);
                                                                                                    }
                                                                                                  } else {
                                                                                                    term_sink(e, _o_25);
                                                                                                    term_sink(e, _h_37);
                                                                                                    term_sink(e, _h_38);
                                                                                                    term_sink(e, _o_62);
                                                                                                    term_sink(e, _o_63);
                                                                                                    term_sink(e, _o_71);
                                                                                                    term_sink(e, _f_37);
                                                                                                    term_sink(e, _h_44);
                                                                                                    u64 _nd_5 = heap_alloc(e, cls_fit(1));
                                                                                                    e.mem[_nd_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                    spare_free(e, cls_fit(2), _sp_8);
                                                                                                    r0 = term_clo(FID_IO_PRINT, _nd_5);
                                                                                                    WL_RETN(1);
                                                                                                  }
                                                                                                } else {
                                                                                                  term_sink(e, _o_25);
                                                                                                  term_sink(e, _h_37);
                                                                                                  term_sink(e, _h_38);
                                                                                                  term_sink(e, _h_42);
                                                                                                  term_sink(e, _h_44);
                                                                                                  u64 _nd_6 = heap_alloc(e, cls_fit(1));
                                                                                                  e.mem[_nd_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                  r0 = term_clo(FID_IO_PRINT, _nd_6);
                                                                                                  WL_RETN(1);
                                                                                                }
                                                                                              } else {
                                                                                                term_sink(e, _o_25);
                                                                                                term_sink(e, _h_37);
                                                                                                term_sink(e, _h_38);
                                                                                                term_sink(e, _h_42);
                                                                                                term_sink(e, _h_44);
                                                                                                u64 _nd_7 = heap_alloc(e, cls_fit(1));
                                                                                                e.mem[_nd_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                r0 = term_clo(FID_IO_PRINT, _nd_7);
                                                                                                WL_RETN(1);
                                                                                              }
                                                                                            } else {
                                                                                              term_sink(e, _o_25);
                                                                                              term_sink(e, _h_78);
                                                                                              term_sink(e, _h_37);
                                                                                              term_sink(e, _h_38);
                                                                                              term_sink(e, _h_42);
                                                                                              term_sink(e, _h_44);
                                                                                              u64 _nd_8 = heap_alloc(e, cls_fit(1));
                                                                                              e.mem[_nd_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                              r0 = term_clo(FID_IO_PRINT, _nd_8);
                                                                                              WL_RETN(1);
                                                                                            }
                                                                                          } else {
                                                                                            term_sink(e, _o_25);
                                                                                            u32 _110_0 = ((_o_57 >> 0) & 1);
                                                                                            u32 _111_0 = ((_o_57 >> 1) & 1);
                                                                                            u32 _111_1 = ((_o_57 >> 2) & 1);
                                                                                            u32 _111_2 = ((_o_57 >> 3) & 1);
                                                                                            u32 _111_3 = ((_o_57 >> 4) & 1);
                                                                                            u32 _111_4 = ((_o_57 >> 5) & 1);
                                                                                            u32 _111_5 = ((_o_57 >> 6) & 1);
                                                                                            u32 _111_6 = ((_o_57 >> 7) & 1);
                                                                                            u32 _111_7 = ((_o_57 >> 8) & 1);
                                                                                            u32 _111_8 = ((_o_57 >> 9) & 1);
                                                                                            u32 _111_9 = ((_o_57 >> 10) & 1);
                                                                                            u32 _111_10 = ((_o_57 >> 11) & 1);
                                                                                            u32 _111_11 = ((_o_57 >> 12) & 1);
                                                                                            u32 _111_12 = ((_o_57 >> 13) & 1);
                                                                                            u32 _111_13 = ((_o_57 >> 14) & 1);
                                                                                            u32 _111_14 = ((_o_57 >> 15) & 1);
                                                                                            u32 _111_15 = ((_o_57 >> 16) & 1);
                                                                                            u32 _111_16 = ((_o_57 >> 17) & 1);
                                                                                            u32 _111_17 = ((_o_57 >> 18) & 1);
                                                                                            u32 _111_18 = ((_o_57 >> 19) & 1);
                                                                                            u32 _111_19 = ((_o_57 >> 20) & 1);
                                                                                            u32 _111_20 = ((_o_57 >> 21) & 1);
                                                                                            u32 _111_21 = ((_o_57 >> 22) & 1);
                                                                                            u32 _111_22 = ((_o_57 >> 23) & 1);
                                                                                            u32 _111_23 = ((_o_57 >> 24) & 1);
                                                                                            u32 _111_24 = ((_o_57 >> 25) & 1);
                                                                                            u32 _111_25 = ((_o_57 >> 26) & 1);
                                                                                            u32 _111_26 = ((_o_57 >> 27) & 1);
                                                                                            u32 _111_27 = ((_o_57 >> 28) & 1);
                                                                                            u32 _111_28 = ((_o_57 >> 29) & 1);
                                                                                            u32 _111_29 = ((_o_57 >> 30) & 1);
                                                                                            u32 _111_30 = ((_o_57 >> 31) & 1);
                                                                                            term_sink(e, _h_78);
                                                                                            term_sink(e, _h_37);
                                                                                            term_sink(e, _h_38);
                                                                                            term_sink(e, _h_42);
                                                                                            term_sink(e, _h_44);
                                                                                            u64 _nd_9 = heap_alloc(e, cls_fit(1));
                                                                                            e.mem[_nd_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                            r0 = term_clo(FID_IO_PRINT, _nd_9);
                                                                                            WL_RETN(1);
                                                                                          }
                                                                                        } else {
                                                                                          term_sink(e, _o_25);
                                                                                          term_sink(e, _h_78);
                                                                                          term_sink(e, _h_37);
                                                                                          term_sink(e, _h_38);
                                                                                          term_sink(e, _h_42);
                                                                                          term_sink(e, _h_44);
                                                                                          u64 _nd_10 = heap_alloc(e, cls_fit(1));
                                                                                          e.mem[_nd_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                          r0 = term_clo(FID_IO_PRINT, _nd_10);
                                                                                          WL_RETN(1);
                                                                                        }
                                                                                      } else {
                                                                                        term_sink(e, _o_25);
                                                                                        term_sink(e, _h_77);
                                                                                        term_sink(e, _h_78);
                                                                                        term_sink(e, _h_37);
                                                                                        term_sink(e, _h_38);
                                                                                        term_sink(e, _h_42);
                                                                                        term_sink(e, _h_44);
                                                                                        u64 _nd_11 = heap_alloc(e, cls_fit(1));
                                                                                        e.mem[_nd_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                        r0 = term_clo(FID_IO_PRINT, _nd_11);
                                                                                        WL_RETN(1);
                                                                                      }
                                                                                    } else {
                                                                                      term_sink(e, _o_25);
                                                                                      term_sink(e, _h_74);
                                                                                      term_sink(e, _h_37);
                                                                                      term_sink(e, _h_38);
                                                                                      term_sink(e, _h_42);
                                                                                      term_sink(e, _h_44);
                                                                                      u64 _nd_12 = heap_alloc(e, cls_fit(1));
                                                                                      e.mem[_nd_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                      r0 = term_clo(FID_IO_PRINT, _nd_12);
                                                                                      WL_RETN(1);
                                                                                    }
                                                                                  } else {
                                                                                    term_sink(e, _o_25);
                                                                                    term_sink(e, _h_74);
                                                                                    term_sink(e, _h_37);
                                                                                    term_sink(e, _h_38);
                                                                                    term_sink(e, _h_42);
                                                                                    term_sink(e, _h_44);
                                                                                    u64 _nd_13 = heap_alloc(e, cls_fit(1));
                                                                                    e.mem[_nd_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                    r0 = term_clo(FID_IO_PRINT, _nd_13);
                                                                                    WL_RETN(1);
                                                                                  }
                                                                                } else {
                                                                                  term_sink(e, _o_25);
                                                                                  term_sink(e, _h_76);
                                                                                  term_sink(e, _h_74);
                                                                                  term_sink(e, _h_37);
                                                                                  term_sink(e, _h_38);
                                                                                  term_sink(e, _h_42);
                                                                                  term_sink(e, _h_44);
                                                                                  u64 _nd_14 = heap_alloc(e, cls_fit(1));
                                                                                  e.mem[_nd_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                  r0 = term_clo(FID_IO_PRINT, _nd_14);
                                                                                  WL_RETN(1);
                                                                                }
                                                                              } else {
                                                                                term_sink(e, _o_25);
                                                                                term_sink(e, _h_76);
                                                                                term_sink(e, _h_74);
                                                                                term_sink(e, _h_37);
                                                                                term_sink(e, _h_38);
                                                                                term_sink(e, _h_42);
                                                                                term_sink(e, _h_44);
                                                                                u64 _nd_15 = heap_alloc(e, cls_fit(1));
                                                                                e.mem[_nd_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                r0 = term_clo(FID_IO_PRINT, _nd_15);
                                                                                WL_RETN(1);
                                                                              }
                                                                            } else {
                                                                              term_sink(e, _o_25);
                                                                              term_sink(e, _h_75);
                                                                              term_sink(e, _h_76);
                                                                              term_sink(e, _h_74);
                                                                              term_sink(e, _h_37);
                                                                              term_sink(e, _h_38);
                                                                              term_sink(e, _h_42);
                                                                              term_sink(e, _h_44);
                                                                              u64 _nd_16 = heap_alloc(e, cls_fit(1));
                                                                              e.mem[_nd_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                              r0 = term_clo(FID_IO_PRINT, _nd_16);
                                                                              WL_RETN(1);
                                                                            }
                                                                          } else {
                                                                            term_sink(e, _o_25);
                                                                            term_sink(e, _h_73);
                                                                            term_sink(e, _h_74);
                                                                            term_sink(e, _h_37);
                                                                            term_sink(e, _h_38);
                                                                            term_sink(e, _h_42);
                                                                            term_sink(e, _h_44);
                                                                            u64 _nd_17 = heap_alloc(e, cls_fit(1));
                                                                            e.mem[_nd_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                            r0 = term_clo(FID_IO_PRINT, _nd_17);
                                                                            WL_RETN(1);
                                                                          }
                                                                        } else {
                                                                          term_sink(e, _o_25);
                                                                          term_sink(e, _h_36);
                                                                          term_sink(e, _h_37);
                                                                          term_sink(e, _h_38);
                                                                          term_sink(e, _h_42);
                                                                          term_sink(e, _h_44);
                                                                          u64 _nd_18 = heap_alloc(e, cls_fit(1));
                                                                          e.mem[_nd_18 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                          r0 = term_clo(FID_IO_PRINT, _nd_18);
                                                                          WL_RETN(1);
                                                                        }
                                                                      } else {
                                                                        term_sink(e, _o_25);
                                                                        term_sink(e, _h_36);
                                                                        term_sink(e, _h_37);
                                                                        term_sink(e, _h_38);
                                                                        term_sink(e, _h_42);
                                                                        term_sink(e, _h_44);
                                                                        u64 _nd_19 = heap_alloc(e, cls_fit(1));
                                                                        e.mem[_nd_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                        r0 = term_clo(FID_IO_PRINT, _nd_19);
                                                                        WL_RETN(1);
                                                                      }
                                                                    } else {
                                                                      term_sink(e, _o_25);
                                                                      term_sink(e, _h_72);
                                                                      term_sink(e, _h_36);
                                                                      term_sink(e, _h_37);
                                                                      term_sink(e, _h_38);
                                                                      term_sink(e, _h_42);
                                                                      term_sink(e, _h_44);
                                                                      u64 _nd_20 = heap_alloc(e, cls_fit(1));
                                                                      e.mem[_nd_20 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                      r0 = term_clo(FID_IO_PRINT, _nd_20);
                                                                      WL_RETN(1);
                                                                    }
                                                                  } else {
                                                                    term_sink(e, _o_25);
                                                                    term_sink(e, _h_72);
                                                                    term_sink(e, _h_36);
                                                                    term_sink(e, _h_37);
                                                                    term_sink(e, _h_38);
                                                                    term_sink(e, _h_42);
                                                                    term_sink(e, _h_44);
                                                                    u64 _nd_21 = heap_alloc(e, cls_fit(1));
                                                                    e.mem[_nd_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                    r0 = term_clo(FID_IO_PRINT, _nd_21);
                                                                    WL_RETN(1);
                                                                  }
                                                                } else {
                                                                  term_sink(e, _o_25);
                                                                  term_sink(e, _h_71);
                                                                  term_sink(e, _h_72);
                                                                  term_sink(e, _h_36);
                                                                  term_sink(e, _h_37);
                                                                  term_sink(e, _h_38);
                                                                  term_sink(e, _h_42);
                                                                  term_sink(e, _h_44);
                                                                  u64 _nd_22 = heap_alloc(e, cls_fit(1));
                                                                  e.mem[_nd_22 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                  r0 = term_clo(FID_IO_PRINT, _nd_22);
                                                                  WL_RETN(1);
                                                                }
                                                              } else {
                                                                term_sink(e, _o_25);
                                                                term_sink(e, _h_68);
                                                                term_sink(e, _h_36);
                                                                term_sink(e, _h_37);
                                                                term_sink(e, _h_38);
                                                                term_sink(e, _h_42);
                                                                term_sink(e, _h_44);
                                                                u64 _nd_23 = heap_alloc(e, cls_fit(1));
                                                                e.mem[_nd_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                r0 = term_clo(FID_IO_PRINT, _nd_23);
                                                                WL_RETN(1);
                                                              }
                                                            } else {
                                                              term_sink(e, _o_25);
                                                              term_sink(e, _h_68);
                                                              term_sink(e, _h_36);
                                                              term_sink(e, _h_37);
                                                              term_sink(e, _h_38);
                                                              term_sink(e, _h_42);
                                                              term_sink(e, _h_44);
                                                              u64 _nd_24 = heap_alloc(e, cls_fit(1));
                                                              e.mem[_nd_24 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                              r0 = term_clo(FID_IO_PRINT, _nd_24);
                                                              WL_RETN(1);
                                                            }
                                                          } else {
                                                            term_sink(e, _o_25);
                                                            term_sink(e, _h_70);
                                                            term_sink(e, _h_68);
                                                            term_sink(e, _h_36);
                                                            term_sink(e, _h_37);
                                                            term_sink(e, _h_38);
                                                            term_sink(e, _h_42);
                                                            term_sink(e, _h_44);
                                                            u64 _nd_25 = heap_alloc(e, cls_fit(1));
                                                            e.mem[_nd_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                            r0 = term_clo(FID_IO_PRINT, _nd_25);
                                                            WL_RETN(1);
                                                          }
                                                        } else {
                                                          term_sink(e, _o_25);
                                                          term_sink(e, _h_70);
                                                          term_sink(e, _h_68);
                                                          term_sink(e, _h_36);
                                                          term_sink(e, _h_37);
                                                          term_sink(e, _h_38);
                                                          term_sink(e, _h_42);
                                                          term_sink(e, _h_44);
                                                          u64 _nd_26 = heap_alloc(e, cls_fit(1));
                                                          e.mem[_nd_26 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                          r0 = term_clo(FID_IO_PRINT, _nd_26);
                                                          WL_RETN(1);
                                                        }
                                                      } else {
                                                        term_sink(e, _o_25);
                                                        term_sink(e, _h_69);
                                                        term_sink(e, _h_70);
                                                        term_sink(e, _h_68);
                                                        term_sink(e, _h_36);
                                                        term_sink(e, _h_37);
                                                        term_sink(e, _h_38);
                                                        term_sink(e, _h_42);
                                                        term_sink(e, _h_44);
                                                        u64 _nd_27 = heap_alloc(e, cls_fit(1));
                                                        e.mem[_nd_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                        r0 = term_clo(FID_IO_PRINT, _nd_27);
                                                        WL_RETN(1);
                                                      }
                                                    } else {
                                                      term_sink(e, _o_25);
                                                      term_sink(e, _h_67);
                                                      term_sink(e, _h_68);
                                                      term_sink(e, _h_36);
                                                      term_sink(e, _h_37);
                                                      term_sink(e, _h_38);
                                                      term_sink(e, _h_42);
                                                      term_sink(e, _h_44);
                                                      u64 _nd_28 = heap_alloc(e, cls_fit(1));
                                                      e.mem[_nd_28 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                      r0 = term_clo(FID_IO_PRINT, _nd_28);
                                                      WL_RETN(1);
                                                    }
                                                  } else {
                                                    term_sink(e, _o_25);
                                                    term_sink(e, _h_35);
                                                    term_sink(e, _h_36);
                                                    term_sink(e, _h_37);
                                                    term_sink(e, _h_38);
                                                    term_sink(e, _h_42);
                                                    term_sink(e, _h_44);
                                                    u64 _nd_29 = heap_alloc(e, cls_fit(1));
                                                    e.mem[_nd_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                    r0 = term_clo(FID_IO_PRINT, _nd_29);
                                                    WL_RETN(1);
                                                  }
                                                } else {
                                                  term_sink(e, _o_25);
                                                  term_sink(e, _o_50);
                                                  term_sink(e, _h_35);
                                                  term_sink(e, _h_36);
                                                  term_sink(e, _h_37);
                                                  term_sink(e, _h_38);
                                                  term_sink(e, _h_42);
                                                  term_sink(e, _h_44);
                                                  u64 _nd_30 = heap_alloc(e, cls_fit(1));
                                                  e.mem[_nd_30 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                  r0 = term_clo(FID_IO_PRINT, _nd_30);
                                                  WL_RETN(1);
                                                }
                                              } else {
                                                term_sink(e, _o_25);
                                                term_sink(e, _h_66);
                                                term_sink(e, _h_35);
                                                term_sink(e, _h_36);
                                                term_sink(e, _h_37);
                                                term_sink(e, _h_38);
                                                term_sink(e, _h_42);
                                                term_sink(e, _h_44);
                                                u64 _nd_31 = heap_alloc(e, cls_fit(1));
                                                e.mem[_nd_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                r0 = term_clo(FID_IO_PRINT, _nd_31);
                                                WL_RETN(1);
                                              }
                                            } else {
                                              term_sink(e, _o_25);
                                              term_sink(e, _o_47);
                                              term_sink(e, _h_66);
                                              term_sink(e, _h_35);
                                              term_sink(e, _h_36);
                                              term_sink(e, _h_37);
                                              term_sink(e, _h_38);
                                              term_sink(e, _h_42);
                                              term_sink(e, _h_44);
                                              u64 _nd_32 = heap_alloc(e, cls_fit(1));
                                              e.mem[_nd_32 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                              r0 = term_clo(FID_IO_PRINT, _nd_32);
                                              WL_RETN(1);
                                            }
                                          } else {
                                            term_sink(e, _o_25);
                                            term_sink(e, _h_65);
                                            term_sink(e, _h_66);
                                            term_sink(e, _h_35);
                                            term_sink(e, _h_36);
                                            term_sink(e, _h_37);
                                            term_sink(e, _h_38);
                                            term_sink(e, _h_42);
                                            term_sink(e, _h_44);
                                            u64 _nd_33 = heap_alloc(e, cls_fit(1));
                                            e.mem[_nd_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                            r0 = term_clo(FID_IO_PRINT, _nd_33);
                                            WL_RETN(1);
                                          }
                                        } else {
                                          term_sink(e, _o_25);
                                          term_sink(e, _h_62);
                                          term_sink(e, _h_35);
                                          term_sink(e, _h_36);
                                          term_sink(e, _h_37);
                                          term_sink(e, _h_38);
                                          term_sink(e, _h_42);
                                          term_sink(e, _h_44);
                                          u64 _nd_34 = heap_alloc(e, cls_fit(1));
                                          e.mem[_nd_34 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                          r0 = term_clo(FID_IO_PRINT, _nd_34);
                                          WL_RETN(1);
                                        }
                                      } else {
                                        term_sink(e, _o_25);
                                        term_sink(e, _o_44);
                                        term_sink(e, _h_62);
                                        term_sink(e, _h_35);
                                        term_sink(e, _h_36);
                                        term_sink(e, _h_37);
                                        term_sink(e, _h_38);
                                        term_sink(e, _h_42);
                                        term_sink(e, _h_44);
                                        u64 _nd_35 = heap_alloc(e, cls_fit(1));
                                        e.mem[_nd_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                        r0 = term_clo(FID_IO_PRINT, _nd_35);
                                        WL_RETN(1);
                                      }
                                    } else {
                                      term_sink(e, _o_25);
                                      term_sink(e, _h_64);
                                      term_sink(e, _h_62);
                                      term_sink(e, _h_35);
                                      term_sink(e, _h_36);
                                      term_sink(e, _h_37);
                                      term_sink(e, _h_38);
                                      term_sink(e, _h_42);
                                      term_sink(e, _h_44);
                                      u64 _nd_36 = heap_alloc(e, cls_fit(1));
                                      e.mem[_nd_36 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                      r0 = term_clo(FID_IO_PRINT, _nd_36);
                                      WL_RETN(1);
                                    }
                                  } else {
                                    term_sink(e, _o_25);
                                    term_sink(e, _o_41);
                                    term_sink(e, _h_64);
                                    term_sink(e, _h_62);
                                    term_sink(e, _h_35);
                                    term_sink(e, _h_36);
                                    term_sink(e, _h_37);
                                    term_sink(e, _h_38);
                                    term_sink(e, _h_42);
                                    term_sink(e, _h_44);
                                    u64 _nd_37 = heap_alloc(e, cls_fit(1));
                                    e.mem[_nd_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                    r0 = term_clo(FID_IO_PRINT, _nd_37);
                                    WL_RETN(1);
                                  }
                                } else {
                                  term_sink(e, _o_25);
                                  term_sink(e, _h_63);
                                  term_sink(e, _h_64);
                                  term_sink(e, _h_62);
                                  term_sink(e, _h_35);
                                  term_sink(e, _h_36);
                                  term_sink(e, _h_37);
                                  term_sink(e, _h_38);
                                  term_sink(e, _h_42);
                                  term_sink(e, _h_44);
                                  u64 _nd_38 = heap_alloc(e, cls_fit(1));
                                  e.mem[_nd_38 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                  r0 = term_clo(FID_IO_PRINT, _nd_38);
                                  WL_RETN(1);
                                }
                              } else {
                                term_sink(e, _o_25);
                                term_sink(e, _h_61);
                                term_sink(e, _h_62);
                                term_sink(e, _h_35);
                                term_sink(e, _h_36);
                                term_sink(e, _h_37);
                                term_sink(e, _h_38);
                                term_sink(e, _h_42);
                                term_sink(e, _h_44);
                                u64 _nd_39 = heap_alloc(e, cls_fit(1));
                                e.mem[_nd_39 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                r0 = term_clo(FID_IO_PRINT, _nd_39);
                                WL_RETN(1);
                              }
                            } else {
                              term_sink(e, _o_25);
                              term_sink(e, _h_34);
                              term_sink(e, _h_35);
                              term_sink(e, _h_36);
                              term_sink(e, _h_37);
                              term_sink(e, _h_38);
                              term_sink(e, _h_42);
                              term_sink(e, _h_44);
                              u64 _nd_40 = heap_alloc(e, cls_fit(1));
                              e.mem[_nd_40 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                              r0 = term_clo(FID_IO_PRINT, _nd_40);
                              WL_RETN(1);
                            }
                          } else {
                            term_sink(e, _o_25);
                            term_sink(e, _o_33);
                            term_sink(e, _h_34);
                            term_sink(e, _h_35);
                            term_sink(e, _h_36);
                            term_sink(e, _h_37);
                            term_sink(e, _h_38);
                            term_sink(e, _h_42);
                            term_sink(e, _h_44);
                            u64 _nd_41 = heap_alloc(e, cls_fit(1));
                            e.mem[_nd_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                            r0 = term_clo(FID_IO_PRINT, _nd_41);
                            WL_RETN(1);
                          }
                        } else {
                          term_sink(e, _o_25);
                          term_sink(e, _h_60);
                          term_sink(e, _h_34);
                          term_sink(e, _h_35);
                          term_sink(e, _h_36);
                          term_sink(e, _h_37);
                          term_sink(e, _h_38);
                          term_sink(e, _h_42);
                          term_sink(e, _h_44);
                          u64 _nd_42 = heap_alloc(e, cls_fit(1));
                          e.mem[_nd_42 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                          r0 = term_clo(FID_IO_PRINT, _nd_42);
                          WL_RETN(1);
                        }
                      } else {
                        term_sink(e, _o_25);
                        term_sink(e, _h_60);
                        term_sink(e, _h_34);
                        term_sink(e, _h_35);
                        term_sink(e, _h_36);
                        term_sink(e, _h_37);
                        term_sink(e, _h_38);
                        term_sink(e, _h_42);
                        term_sink(e, _h_44);
                        u64 _nd_43 = heap_alloc(e, cls_fit(1));
                        e.mem[_nd_43 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                        r0 = term_clo(FID_IO_PRINT, _nd_43);
                        WL_RETN(1);
                      }
                    } else {
                      term_sink(e, _h_59);
                      term_sink(e, _h_60);
                      term_sink(e, _h_34);
                      term_sink(e, _h_35);
                      term_sink(e, _h_36);
                      term_sink(e, _h_37);
                      term_sink(e, _h_38);
                      term_sink(e, _h_42);
                      term_sink(e, _h_44);
                      u64 _nd_44 = heap_alloc(e, cls_fit(1));
                      e.mem[_nd_44 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                      r0 = term_clo(FID_IO_PRINT, _nd_44);
                      WL_RETN(1);
                    }
                  } else {
                    term_sink(e, _h_56);
                    term_sink(e, _h_34);
                    term_sink(e, _h_35);
                    term_sink(e, _h_36);
                    term_sink(e, _h_37);
                    term_sink(e, _h_38);
                    term_sink(e, _h_42);
                    term_sink(e, _h_44);
                    u64 _nd_45 = heap_alloc(e, cls_fit(1));
                    e.mem[_nd_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                    r0 = term_clo(FID_IO_PRINT, _nd_45);
                    WL_RETN(1);
                  }
                } else {
                  term_sink(e, _o_17);
                  term_sink(e, _h_56);
                  term_sink(e, _h_34);
                  term_sink(e, _h_35);
                  term_sink(e, _h_36);
                  term_sink(e, _h_37);
                  term_sink(e, _h_38);
                  term_sink(e, _h_42);
                  term_sink(e, _h_44);
                  u64 _nd_46 = heap_alloc(e, cls_fit(1));
                  e.mem[_nd_46 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                  r0 = term_clo(FID_IO_PRINT, _nd_46);
                  WL_RETN(1);
                }
              } else {
                term_sink(e, _h_58);
                term_sink(e, _h_56);
                term_sink(e, _h_34);
                term_sink(e, _h_35);
                term_sink(e, _h_36);
                term_sink(e, _h_37);
                term_sink(e, _h_38);
                term_sink(e, _h_42);
                term_sink(e, _h_44);
                u64 _nd_47 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                r0 = term_clo(FID_IO_PRINT, _nd_47);
                WL_RETN(1);
              }
            } else {
              term_sink(e, _o_9);
              term_sink(e, _h_58);
              term_sink(e, _h_56);
              term_sink(e, _h_34);
              term_sink(e, _h_35);
              term_sink(e, _h_36);
              term_sink(e, _h_37);
              term_sink(e, _h_38);
              term_sink(e, _h_42);
              term_sink(e, _h_44);
              u64 _nd_48 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_48 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
              r0 = term_clo(FID_IO_PRINT, _nd_48);
              WL_RETN(1);
            }
          } else {
            term_sink(e, _h_57);
            term_sink(e, _h_58);
            term_sink(e, _h_56);
            term_sink(e, _h_34);
            term_sink(e, _h_35);
            term_sink(e, _h_36);
            term_sink(e, _h_37);
            term_sink(e, _h_38);
            term_sink(e, _h_42);
            term_sink(e, _h_44);
            u64 _nd_49 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
            r0 = term_clo(FID_IO_PRINT, _nd_49);
            WL_RETN(1);
          }
        } else {
          term_sink(e, _h_55);
          term_sink(e, _h_56);
          term_sink(e, _h_34);
          term_sink(e, _h_35);
          term_sink(e, _h_36);
          term_sink(e, _h_37);
          term_sink(e, _h_38);
          term_sink(e, _h_42);
          term_sink(e, _h_44);
          u64 _nd_50 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_50 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
          r0 = term_clo(FID_IO_PRINT, _nd_50);
          WL_RETN(1);
        }
      } else {
        term_sink(e, _h_33);
        term_sink(e, _h_34);
        term_sink(e, _h_35);
        term_sink(e, _h_36);
        term_sink(e, _h_37);
        term_sink(e, _h_38);
        term_sink(e, _h_42);
        term_sink(e, _h_44);
        u64 _nd_51 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
        r0 = term_clo(FID_IO_PRINT, _nd_51);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _h_33);
      term_sink(e, _h_34);
      term_sink(e, _h_35);
      term_sink(e, _h_36);
      term_sink(e, _h_37);
      term_sink(e, _h_38);
      term_sink(e, _h_42);
      term_sink(e, _h_44);
      term_sink(e, _h_52);
      term_sink(e, _h_53);
      term_sink(e, _h_54);
      u64 _nd_52 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_52 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
      r0 = term_clo(FID_IO_PRINT, _nd_52);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K292)
  {
    WL_POPN(27);
    u32 _v_142 = STK(0);
    u32 _v_143 = STK(1);
    u32 _v_144 = STK(2);
    u32 _v_145 = STK(3);
    u32 _v_146 = STK(4);
    u32 _h_80 = STK(5);
    u32 _h_81 = STK(6);
    Term _o_88 = STK(7);
    u32 _o_89 = STK(8);
    u32 _o_90 = STK(9);
    u32 _o_91 = STK(10);
    u32 _o_92 = STK(11);
    u32 _o_93 = STK(12);
    u32 _o_94 = STK(13);
    Term _h_82 = STK(14);
    Term _h_83 = STK(15);
    u32 _h_84 = STK(16);
    Term _h_85 = STK(17);
    u32 _h_86 = STK(18);
    u32 _o_95 = STK(19);
    Term _h_87 = STK(20);
    u32 _h_88 = STK(21);
    u32 _h_89 = STK(22);
    u32 _h_90 = STK(23);
    u32 _h_91 = STK(24);
    u32 _h_92 = STK(25);
    u32 _h_93 = STK(26);
    Term _h_79 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _v_142;
      STK(1) = _v_143;
      STK(2) = _v_144;
      STK(3) = _v_145;
      STK(4) = _v_146;
      STK(5) = _h_80;
      STK(6) = _h_81;
      STK(7) = _o_89;
      STK(8) = _o_90;
      STK(9) = _o_91;
      STK(10) = _o_92;
      STK(11) = _o_93;
      STK(12) = _o_94;
      STK(13) = _h_82;
      STK(14) = _h_83;
      STK(15) = _h_84;
      STK(16) = _h_85;
      STK(17) = _h_86;
      STK(18) = _o_95;
      STK(19) = _h_87;
      STK(20) = _h_88;
      STK(21) = _h_89;
      STK(22) = _h_90;
      STK(23) = _h_91;
      STK(24) = _h_92;
      STK(25) = _h_93;
      STK(26) = _h_79;
      STK(27) = FID_RUN_K293;
      WL_PUSHN(28);
    } else {
      u64 _t_13 = task_node(e, FID_RUN_K293, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _v_142;
      e.mem[_t_13 + 1] = _v_143;
      e.mem[_t_13 + 2] = _v_144;
      e.mem[_t_13 + 3] = _v_145;
      e.mem[_t_13 + 4] = _v_146;
      e.mem[_t_13 + 5] = _h_80;
      e.mem[_t_13 + 6] = _h_81;
      e.mem[_t_13 + 7] = _o_89;
      e.mem[_t_13 + 8] = _o_90;
      e.mem[_t_13 + 9] = _o_91;
      e.mem[_t_13 + 10] = _o_92;
      e.mem[_t_13 + 11] = _o_93;
      e.mem[_t_13 + 12] = _o_94;
      e.mem[_t_13 + 13] = _h_82;
      e.mem[_t_13 + 14] = _h_83;
      e.mem[_t_13 + 15] = _h_84;
      e.mem[_t_13 + 16] = _h_85;
      e.mem[_t_13 + 17] = _h_86;
      e.mem[_t_13 + 18] = _o_95;
      e.mem[_t_13 + 19] = _h_87;
      e.mem[_t_13 + 20] = _h_88;
      e.mem[_t_13 + 21] = _h_89;
      e.mem[_t_13 + 22] = _h_90;
      e.mem[_t_13 + 23] = _h_91;
      e.mem[_t_13 + 24] = _h_92;
      e.mem[_t_13 + 25] = _h_93;
      e.mem[_t_13 + 26] = _h_79;
      WL_CONT = term_tsk(FID_RUN_K293, _t_13);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_14 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _o_88;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_14);
    }
    r0 = _o_88;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K293)
  {
    WL_POPN(27);
    u32 _v_147 = STK(0);
    u32 _v_148 = STK(1);
    u32 _v_149 = STK(2);
    u32 _v_150 = STK(3);
    u32 _v_151 = STK(4);
    u32 _h_95 = STK(5);
    u32 _h_96 = STK(6);
    u32 _o_96 = STK(7);
    u32 _o_97 = STK(8);
    u32 _o_98 = STK(9);
    u32 _o_99 = STK(10);
    u32 _o_100 = STK(11);
    u32 _o_101 = STK(12);
    Term _h_97 = STK(13);
    Term _h_98 = STK(14);
    u32 _h_99 = STK(15);
    Term _h_100 = STK(16);
    u32 _h_101 = STK(17);
    u32 _o_102 = STK(18);
    Term _h_102 = STK(19);
    u32 _h_103 = STK(20);
    u32 _h_104 = STK(21);
    u32 _h_105 = STK(22);
    u32 _h_106 = STK(23);
    u32 _h_107 = STK(24);
    u32 _h_108 = STK(25);
    Term _h_109 = STK(26);
    Term _h_94 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _v_147;
      STK(1) = _v_148;
      STK(2) = _v_149;
      STK(3) = _v_150;
      STK(4) = _v_151;
      STK(5) = _h_95;
      STK(6) = _h_96;
      STK(7) = _o_96;
      STK(8) = _o_97;
      STK(9) = _o_98;
      STK(10) = _o_99;
      STK(11) = _o_100;
      STK(12) = _o_101;
      STK(13) = _h_97;
      STK(14) = _h_98;
      STK(15) = _h_99;
      STK(16) = _h_100;
      STK(17) = _h_101;
      STK(18) = _o_102;
      STK(19) = _h_102;
      STK(20) = _h_103;
      STK(21) = _h_104;
      STK(22) = _h_105;
      STK(23) = _h_106;
      STK(24) = _h_107;
      STK(25) = _h_108;
      STK(26) = _h_109;
      STK(27) = FID_RUN_K294;
      WL_PUSHN(28);
    } else {
      u64 _t_15 = task_node(e, FID_RUN_K294, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _v_147;
      e.mem[_t_15 + 1] = _v_148;
      e.mem[_t_15 + 2] = _v_149;
      e.mem[_t_15 + 3] = _v_150;
      e.mem[_t_15 + 4] = _v_151;
      e.mem[_t_15 + 5] = _h_95;
      e.mem[_t_15 + 6] = _h_96;
      e.mem[_t_15 + 7] = _o_96;
      e.mem[_t_15 + 8] = _o_97;
      e.mem[_t_15 + 9] = _o_98;
      e.mem[_t_15 + 10] = _o_99;
      e.mem[_t_15 + 11] = _o_100;
      e.mem[_t_15 + 12] = _o_101;
      e.mem[_t_15 + 13] = _h_97;
      e.mem[_t_15 + 14] = _h_98;
      e.mem[_t_15 + 15] = _h_99;
      e.mem[_t_15 + 16] = _h_100;
      e.mem[_t_15 + 17] = _h_101;
      e.mem[_t_15 + 18] = _o_102;
      e.mem[_t_15 + 19] = _h_102;
      e.mem[_t_15 + 20] = _h_103;
      e.mem[_t_15 + 21] = _h_104;
      e.mem[_t_15 + 22] = _h_105;
      e.mem[_t_15 + 23] = _h_106;
      e.mem[_t_15 + 24] = _h_107;
      e.mem[_t_15 + 25] = _h_108;
      e.mem[_t_15 + 26] = _h_109;
      WL_CONT = term_tsk(FID_RUN_K294, _t_15);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_16 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = _h_94;
      return term_tsk(FID_DATA, _t_16);
    }
    r0 = _h_94;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K294)
  {
    WL_POPN(27);
    u32 _v_152 = STK(0);
    u32 _v_153 = STK(1);
    u32 _v_154 = STK(2);
    u32 _v_155 = STK(3);
    u32 _v_156 = STK(4);
    u32 _h_111 = STK(5);
    u32 _h_112 = STK(6);
    u32 _o_103 = STK(7);
    u32 _o_104 = STK(8);
    u32 _o_105 = STK(9);
    u32 _o_106 = STK(10);
    u32 _o_107 = STK(11);
    u32 _o_108 = STK(12);
    Term _h_113 = STK(13);
    Term _h_114 = STK(14);
    u32 _h_115 = STK(15);
    Term _h_116 = STK(16);
    u32 _h_117 = STK(17);
    u32 _o_109 = STK(18);
    Term _h_118 = STK(19);
    u32 _h_119 = STK(20);
    u32 _h_120 = STK(21);
    u32 _h_121 = STK(22);
    u32 _h_122 = STK(23);
    u32 _h_123 = STK(24);
    u32 _h_124 = STK(25);
    Term _h_125 = STK(26);
    Term _h_110 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _v_152;
      STK(1) = _v_153;
      STK(2) = _v_154;
      STK(3) = _v_155;
      STK(4) = _v_156;
      STK(5) = _h_111;
      STK(6) = _h_112;
      STK(7) = _o_103;
      STK(8) = _o_104;
      STK(9) = _o_105;
      STK(10) = _o_106;
      STK(11) = _o_107;
      STK(12) = _o_108;
      STK(13) = _h_113;
      STK(14) = _h_114;
      STK(15) = _h_115;
      STK(16) = _h_116;
      STK(17) = _h_117;
      STK(18) = _o_109;
      STK(19) = _h_118;
      STK(20) = _h_119;
      STK(21) = _h_120;
      STK(22) = _h_121;
      STK(23) = _h_122;
      STK(24) = _h_123;
      STK(25) = _h_124;
      STK(26) = _h_125;
      STK(27) = FID_RUN_K295;
      WL_PUSHN(28);
    } else {
      u64 _t_17 = task_node(e, FID_RUN_K295, WL_CONT, WL_IDX, 1);
      e.mem[_t_17 + 0] = _v_152;
      e.mem[_t_17 + 1] = _v_153;
      e.mem[_t_17 + 2] = _v_154;
      e.mem[_t_17 + 3] = _v_155;
      e.mem[_t_17 + 4] = _v_156;
      e.mem[_t_17 + 5] = _h_111;
      e.mem[_t_17 + 6] = _h_112;
      e.mem[_t_17 + 7] = _o_103;
      e.mem[_t_17 + 8] = _o_104;
      e.mem[_t_17 + 9] = _o_105;
      e.mem[_t_17 + 10] = _o_106;
      e.mem[_t_17 + 11] = _o_107;
      e.mem[_t_17 + 12] = _o_108;
      e.mem[_t_17 + 13] = _h_113;
      e.mem[_t_17 + 14] = _h_114;
      e.mem[_t_17 + 15] = _h_115;
      e.mem[_t_17 + 16] = _h_116;
      e.mem[_t_17 + 17] = _h_117;
      e.mem[_t_17 + 18] = _o_109;
      e.mem[_t_17 + 19] = _h_118;
      e.mem[_t_17 + 20] = _h_119;
      e.mem[_t_17 + 21] = _h_120;
      e.mem[_t_17 + 22] = _h_121;
      e.mem[_t_17 + 23] = _h_122;
      e.mem[_t_17 + 24] = _h_123;
      e.mem[_t_17 + 25] = _h_124;
      e.mem[_t_17 + 26] = _h_125;
      WL_CONT = term_tsk(FID_RUN_K295, _t_17);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_18 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _h_110;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_18);
    }
    r0 = _h_110;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K295)
  {
    WL_POPN(27);
    u32 _v_157 = STK(0);
    u32 _v_158 = STK(1);
    u32 _v_159 = STK(2);
    u32 _v_160 = STK(3);
    u32 _v_161 = STK(4);
    u32 _h_127 = STK(5);
    u32 _h_128 = STK(6);
    u32 _o_110 = STK(7);
    u32 _o_111 = STK(8);
    u32 _o_112 = STK(9);
    u32 _o_113 = STK(10);
    u32 _o_114 = STK(11);
    u32 _o_115 = STK(12);
    Term _h_129 = STK(13);
    Term _h_130 = STK(14);
    u32 _h_131 = STK(15);
    Term _h_132 = STK(16);
    u32 _h_133 = STK(17);
    u32 _o_116 = STK(18);
    Term _h_134 = STK(19);
    u32 _h_135 = STK(20);
    u32 _h_136 = STK(21);
    u32 _h_137 = STK(22);
    u32 _h_138 = STK(23);
    u32 _h_139 = STK(24);
    u32 _h_140 = STK(25);
    Term _h_141 = STK(26);
    Term _h_126 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _v_157;
      STK(1) = _v_158;
      STK(2) = _v_159;
      STK(3) = _v_160;
      STK(4) = _v_161;
      STK(5) = _h_127;
      STK(6) = _h_128;
      STK(7) = _o_111;
      STK(8) = _o_112;
      STK(9) = _o_113;
      STK(10) = _o_114;
      STK(11) = _o_115;
      STK(12) = _h_129;
      STK(13) = _h_130;
      STK(14) = _h_131;
      STK(15) = _h_132;
      STK(16) = _h_133;
      STK(17) = _o_116;
      STK(18) = _h_134;
      STK(19) = _h_135;
      STK(20) = _h_136;
      STK(21) = _h_137;
      STK(22) = _h_138;
      STK(23) = _h_139;
      STK(24) = _h_140;
      STK(25) = _h_141;
      STK(26) = _h_126;
      STK(27) = FID_RUN_K296;
      WL_PUSHN(28);
    } else {
      u64 _t_19 = task_node(e, FID_RUN_K296, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _v_157;
      e.mem[_t_19 + 1] = _v_158;
      e.mem[_t_19 + 2] = _v_159;
      e.mem[_t_19 + 3] = _v_160;
      e.mem[_t_19 + 4] = _v_161;
      e.mem[_t_19 + 5] = _h_127;
      e.mem[_t_19 + 6] = _h_128;
      e.mem[_t_19 + 7] = _o_111;
      e.mem[_t_19 + 8] = _o_112;
      e.mem[_t_19 + 9] = _o_113;
      e.mem[_t_19 + 10] = _o_114;
      e.mem[_t_19 + 11] = _o_115;
      e.mem[_t_19 + 12] = _h_129;
      e.mem[_t_19 + 13] = _h_130;
      e.mem[_t_19 + 14] = _h_131;
      e.mem[_t_19 + 15] = _h_132;
      e.mem[_t_19 + 16] = _h_133;
      e.mem[_t_19 + 17] = _o_116;
      e.mem[_t_19 + 18] = _h_134;
      e.mem[_t_19 + 19] = _h_135;
      e.mem[_t_19 + 20] = _h_136;
      e.mem[_t_19 + 21] = _h_137;
      e.mem[_t_19 + 22] = _h_138;
      e.mem[_t_19 + 23] = _h_139;
      e.mem[_t_19 + 24] = _h_140;
      e.mem[_t_19 + 25] = _h_141;
      e.mem[_t_19 + 26] = _h_126;
      WL_CONT = term_tsk(FID_RUN_K296, _t_19);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_20 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = _o_110;
      return term_tsk(FID_U32_SHOW, _t_20);
    }
    r0 = _o_110;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K296)
  {
    WL_POPN(27);
    u32 _v_162 = STK(0);
    u32 _v_163 = STK(1);
    u32 _v_164 = STK(2);
    u32 _v_165 = STK(3);
    u32 _v_166 = STK(4);
    u32 _h_143 = STK(5);
    u32 _h_144 = STK(6);
    u32 _o_117 = STK(7);
    u32 _o_118 = STK(8);
    u32 _o_119 = STK(9);
    u32 _o_120 = STK(10);
    u32 _o_121 = STK(11);
    Term _h_145 = STK(12);
    Term _h_146 = STK(13);
    u32 _h_147 = STK(14);
    Term _h_148 = STK(15);
    u32 _h_149 = STK(16);
    u32 _o_122 = STK(17);
    Term _h_150 = STK(18);
    u32 _h_151 = STK(19);
    u32 _h_152 = STK(20);
    u32 _h_153 = STK(21);
    u32 _h_154 = STK(22);
    u32 _h_155 = STK(23);
    u32 _h_156 = STK(24);
    Term _h_157 = STK(25);
    Term _h_158 = STK(26);
    Term _h_142 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _v_162;
      STK(1) = _v_163;
      STK(2) = _v_164;
      STK(3) = _v_165;
      STK(4) = _v_166;
      STK(5) = _h_143;
      STK(6) = _h_144;
      STK(7) = _h_145;
      STK(8) = _h_146;
      STK(9) = _h_147;
      STK(10) = _h_148;
      STK(11) = _h_149;
      STK(12) = _o_122;
      STK(13) = _h_150;
      STK(14) = _h_151;
      STK(15) = _h_152;
      STK(16) = _h_153;
      STK(17) = _h_154;
      STK(18) = _h_155;
      STK(19) = _h_156;
      STK(20) = _h_157;
      STK(21) = _h_158;
      STK(22) = _h_142;
      STK(23) = FID_RUN_K297;
      WL_PUSHN(24);
    } else {
      u64 _t_21 = task_node(e, FID_RUN_K297, WL_CONT, WL_IDX, 1);
      e.mem[_t_21 + 0] = _v_162;
      e.mem[_t_21 + 1] = _v_163;
      e.mem[_t_21 + 2] = _v_164;
      e.mem[_t_21 + 3] = _v_165;
      e.mem[_t_21 + 4] = _v_166;
      e.mem[_t_21 + 5] = _h_143;
      e.mem[_t_21 + 6] = _h_144;
      e.mem[_t_21 + 7] = _h_145;
      e.mem[_t_21 + 8] = _h_146;
      e.mem[_t_21 + 9] = _h_147;
      e.mem[_t_21 + 10] = _h_148;
      e.mem[_t_21 + 11] = _h_149;
      e.mem[_t_21 + 12] = _o_122;
      e.mem[_t_21 + 13] = _h_150;
      e.mem[_t_21 + 14] = _h_151;
      e.mem[_t_21 + 15] = _h_152;
      e.mem[_t_21 + 16] = _h_153;
      e.mem[_t_21 + 17] = _h_154;
      e.mem[_t_21 + 18] = _h_155;
      e.mem[_t_21 + 19] = _h_156;
      e.mem[_t_21 + 20] = _h_157;
      e.mem[_t_21 + 21] = _h_158;
      e.mem[_t_21 + 22] = _h_142;
      WL_CONT = term_tsk(FID_RUN_K297, _t_21);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_POSITION)) {
      u64 _t_22 = task_node(e, FID_HOST_RENDER_RENDER_POSITION, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _o_117;
      e.mem[_t_22 + 1] = _o_118;
      e.mem[_t_22 + 2] = _o_119;
      e.mem[_t_22 + 3] = _o_120;
      e.mem[_t_22 + 4] = _o_121;
      return term_tsk(FID_HOST_RENDER_RENDER_POSITION, _t_22);
    }
    r0 = _o_117;
    r1 = _o_118;
    r2 = _o_119;
    r3 = _o_120;
    r4 = _o_121;
    WL_JMP(FID_HOST_RENDER_RENDER_POSITION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K297)
  {
    WL_POPN(23);
    u32 _v_167 = STK(0);
    u32 _v_168 = STK(1);
    u32 _v_169 = STK(2);
    u32 _v_170 = STK(3);
    u32 _v_171 = STK(4);
    u32 _h_160 = STK(5);
    u32 _h_161 = STK(6);
    Term _h_162 = STK(7);
    Term _h_163 = STK(8);
    u32 _h_164 = STK(9);
    Term _h_165 = STK(10);
    u32 _h_166 = STK(11);
    u32 _o_123 = STK(12);
    Term _h_167 = STK(13);
    u32 _h_168 = STK(14);
    u32 _h_169 = STK(15);
    u32 _h_170 = STK(16);
    u32 _h_171 = STK(17);
    u32 _h_172 = STK(18);
    u32 _h_173 = STK(19);
    Term _h_174 = STK(20);
    Term _h_175 = STK(21);
    Term _h_176 = STK(22);
    Term _h_159 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_160;
      STK(1) = _h_161;
      STK(2) = _h_162;
      STK(3) = _h_163;
      STK(4) = _h_164;
      STK(5) = _h_165;
      STK(6) = _h_166;
      STK(7) = _o_123;
      STK(8) = _h_167;
      STK(9) = _h_168;
      STK(10) = _h_169;
      STK(11) = _h_170;
      STK(12) = _h_171;
      STK(13) = _h_172;
      STK(14) = _h_173;
      STK(15) = _h_174;
      STK(16) = _h_175;
      STK(17) = _h_176;
      STK(18) = _h_159;
      STK(19) = FID_RUN_K298;
      WL_PUSHN(20);
    } else {
      u64 _t_23 = task_node(e, FID_RUN_K298, WL_CONT, WL_IDX, 1);
      e.mem[_t_23 + 0] = _h_160;
      e.mem[_t_23 + 1] = _h_161;
      e.mem[_t_23 + 2] = _h_162;
      e.mem[_t_23 + 3] = _h_163;
      e.mem[_t_23 + 4] = _h_164;
      e.mem[_t_23 + 5] = _h_165;
      e.mem[_t_23 + 6] = _h_166;
      e.mem[_t_23 + 7] = _o_123;
      e.mem[_t_23 + 8] = _h_167;
      e.mem[_t_23 + 9] = _h_168;
      e.mem[_t_23 + 10] = _h_169;
      e.mem[_t_23 + 11] = _h_170;
      e.mem[_t_23 + 12] = _h_171;
      e.mem[_t_23 + 13] = _h_172;
      e.mem[_t_23 + 14] = _h_173;
      e.mem[_t_23 + 15] = _h_174;
      e.mem[_t_23 + 16] = _h_175;
      e.mem[_t_23 + 17] = _h_176;
      e.mem[_t_23 + 18] = _h_159;
      WL_CONT = term_tsk(FID_RUN_K298, _t_23);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_POSITION)) {
      u64 _t_24 = task_node(e, FID_HOST_RENDER_RENDER_POSITION, WL_CONT, WL_IDX, 0);
      e.mem[_t_24 + 0] = _v_167;
      e.mem[_t_24 + 1] = _v_168;
      e.mem[_t_24 + 2] = _v_169;
      e.mem[_t_24 + 3] = _v_170;
      e.mem[_t_24 + 4] = _v_171;
      return term_tsk(FID_HOST_RENDER_RENDER_POSITION, _t_24);
    }
    r0 = _v_167;
    r1 = _v_168;
    r2 = _v_169;
    r3 = _v_170;
    r4 = _v_171;
    WL_JMP(FID_HOST_RENDER_RENDER_POSITION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K298)
  {
    WL_POPN(19);
    u32 _h_178 = STK(0);
    u32 _h_179 = STK(1);
    Term _h_180 = STK(2);
    Term _h_181 = STK(3);
    u32 _h_182 = STK(4);
    Term _h_183 = STK(5);
    u32 _h_184 = STK(6);
    u32 _o_124 = STK(7);
    Term _h_185 = STK(8);
    u32 _h_186 = STK(9);
    u32 _h_187 = STK(10);
    u32 _h_188 = STK(11);
    u32 _h_189 = STK(12);
    u32 _h_190 = STK(13);
    u32 _h_191 = STK(14);
    Term _h_192 = STK(15);
    Term _h_193 = STK(16);
    Term _h_194 = STK(17);
    Term _h_195 = STK(18);
    Term _h_177 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_179;
      STK(1) = _h_180;
      STK(2) = _h_181;
      STK(3) = _h_182;
      STK(4) = _h_183;
      STK(5) = _h_184;
      STK(6) = _o_124;
      STK(7) = _h_185;
      STK(8) = _h_186;
      STK(9) = _h_187;
      STK(10) = _h_188;
      STK(11) = _h_189;
      STK(12) = _h_190;
      STK(13) = _h_191;
      STK(14) = _h_192;
      STK(15) = _h_193;
      STK(16) = _h_194;
      STK(17) = _h_195;
      STK(18) = _h_177;
      STK(19) = FID_RUN_K299;
      WL_PUSHN(20);
    } else {
      u64 _t_25 = task_node(e, FID_RUN_K299, WL_CONT, WL_IDX, 1);
      e.mem[_t_25 + 0] = _h_179;
      e.mem[_t_25 + 1] = _h_180;
      e.mem[_t_25 + 2] = _h_181;
      e.mem[_t_25 + 3] = _h_182;
      e.mem[_t_25 + 4] = _h_183;
      e.mem[_t_25 + 5] = _h_184;
      e.mem[_t_25 + 6] = _o_124;
      e.mem[_t_25 + 7] = _h_185;
      e.mem[_t_25 + 8] = _h_186;
      e.mem[_t_25 + 9] = _h_187;
      e.mem[_t_25 + 10] = _h_188;
      e.mem[_t_25 + 11] = _h_189;
      e.mem[_t_25 + 12] = _h_190;
      e.mem[_t_25 + 13] = _h_191;
      e.mem[_t_25 + 14] = _h_192;
      e.mem[_t_25 + 15] = _h_193;
      e.mem[_t_25 + 16] = _h_194;
      e.mem[_t_25 + 17] = _h_195;
      e.mem[_t_25 + 18] = _h_177;
      WL_CONT = term_tsk(FID_RUN_K299, _t_25);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_26 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_26 + 0] = _h_178;
      return term_tsk(FID_U32_SHOW, _t_26);
    }
    r0 = _h_178;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K299)
  {
    WL_POPN(19);
    u32 _h_197 = STK(0);
    Term _h_198 = STK(1);
    Term _h_199 = STK(2);
    u32 _h_200 = STK(3);
    Term _h_201 = STK(4);
    u32 _h_202 = STK(5);
    u32 _o_125 = STK(6);
    Term _h_203 = STK(7);
    u32 _h_204 = STK(8);
    u32 _h_205 = STK(9);
    u32 _h_206 = STK(10);
    u32 _h_207 = STK(11);
    u32 _h_208 = STK(12);
    u32 _h_209 = STK(13);
    Term _h_210 = STK(14);
    Term _h_211 = STK(15);
    Term _h_212 = STK(16);
    Term _h_213 = STK(17);
    Term _h_214 = STK(18);
    Term _h_196 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_198;
      STK(1) = _h_199;
      STK(2) = _h_200;
      STK(3) = _h_201;
      STK(4) = _h_202;
      STK(5) = _o_125;
      STK(6) = _h_203;
      STK(7) = _h_204;
      STK(8) = _h_205;
      STK(9) = _h_206;
      STK(10) = _h_207;
      STK(11) = _h_208;
      STK(12) = _h_209;
      STK(13) = _h_210;
      STK(14) = _h_211;
      STK(15) = _h_212;
      STK(16) = _h_213;
      STK(17) = _h_214;
      STK(18) = _h_196;
      STK(19) = FID_RUN_K300;
      WL_PUSHN(20);
    } else {
      u64 _t_27 = task_node(e, FID_RUN_K300, WL_CONT, WL_IDX, 1);
      e.mem[_t_27 + 0] = _h_198;
      e.mem[_t_27 + 1] = _h_199;
      e.mem[_t_27 + 2] = _h_200;
      e.mem[_t_27 + 3] = _h_201;
      e.mem[_t_27 + 4] = _h_202;
      e.mem[_t_27 + 5] = _o_125;
      e.mem[_t_27 + 6] = _h_203;
      e.mem[_t_27 + 7] = _h_204;
      e.mem[_t_27 + 8] = _h_205;
      e.mem[_t_27 + 9] = _h_206;
      e.mem[_t_27 + 10] = _h_207;
      e.mem[_t_27 + 11] = _h_208;
      e.mem[_t_27 + 12] = _h_209;
      e.mem[_t_27 + 13] = _h_210;
      e.mem[_t_27 + 14] = _h_211;
      e.mem[_t_27 + 15] = _h_212;
      e.mem[_t_27 + 16] = _h_213;
      e.mem[_t_27 + 17] = _h_214;
      e.mem[_t_27 + 18] = _h_196;
      WL_CONT = term_tsk(FID_RUN_K300, _t_27);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_28 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _h_197;
      return term_tsk(FID_U32_SHOW, _t_28);
    }
    r0 = _h_197;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K300)
  {
    WL_POPN(19);
    Term _h_216 = STK(0);
    Term _h_217 = STK(1);
    u32 _h_218 = STK(2);
    Term _h_219 = STK(3);
    u32 _h_220 = STK(4);
    u32 _o_126 = STK(5);
    Term _h_221 = STK(6);
    u32 _h_222 = STK(7);
    u32 _h_223 = STK(8);
    u32 _h_224 = STK(9);
    u32 _h_225 = STK(10);
    u32 _h_226 = STK(11);
    u32 _h_227 = STK(12);
    Term _h_228 = STK(13);
    Term _h_229 = STK(14);
    Term _h_230 = STK(15);
    Term _h_231 = STK(16);
    Term _h_232 = STK(17);
    Term _h_233 = STK(18);
    Term _h_215 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_216;
      STK(1) = _h_217;
      STK(2) = _h_219;
      STK(3) = _h_220;
      STK(4) = _o_126;
      STK(5) = _h_221;
      STK(6) = _h_222;
      STK(7) = _h_223;
      STK(8) = _h_224;
      STK(9) = _h_225;
      STK(10) = _h_226;
      STK(11) = _h_227;
      STK(12) = _h_228;
      STK(13) = _h_229;
      STK(14) = _h_230;
      STK(15) = _h_231;
      STK(16) = _h_232;
      STK(17) = _h_233;
      STK(18) = _h_215;
      STK(19) = FID_RUN_K301;
      WL_PUSHN(20);
    } else {
      u64 _t_29 = task_node(e, FID_RUN_K301, WL_CONT, WL_IDX, 1);
      e.mem[_t_29 + 0] = _h_216;
      e.mem[_t_29 + 1] = _h_217;
      e.mem[_t_29 + 2] = _h_219;
      e.mem[_t_29 + 3] = _h_220;
      e.mem[_t_29 + 4] = _o_126;
      e.mem[_t_29 + 5] = _h_221;
      e.mem[_t_29 + 6] = _h_222;
      e.mem[_t_29 + 7] = _h_223;
      e.mem[_t_29 + 8] = _h_224;
      e.mem[_t_29 + 9] = _h_225;
      e.mem[_t_29 + 10] = _h_226;
      e.mem[_t_29 + 11] = _h_227;
      e.mem[_t_29 + 12] = _h_228;
      e.mem[_t_29 + 13] = _h_229;
      e.mem[_t_29 + 14] = _h_230;
      e.mem[_t_29 + 15] = _h_231;
      e.mem[_t_29 + 16] = _h_232;
      e.mem[_t_29 + 17] = _h_233;
      e.mem[_t_29 + 18] = _h_215;
      WL_CONT = term_tsk(FID_RUN_K301, _t_29);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_30 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_30 + 0] = _h_218;
      return term_tsk(FID_U32_SHOW, _t_30);
    }
    r0 = _h_218;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K301)
  {
    WL_POPN(19);
    Term _h_235 = STK(0);
    Term _h_236 = STK(1);
    Term _h_237 = STK(2);
    u32 _h_238 = STK(3);
    u32 _o_127 = STK(4);
    Term _h_239 = STK(5);
    u32 _h_240 = STK(6);
    u32 _h_241 = STK(7);
    u32 _h_242 = STK(8);
    u32 _h_243 = STK(9);
    u32 _h_244 = STK(10);
    u32 _h_245 = STK(11);
    Term _h_246 = STK(12);
    Term _h_247 = STK(13);
    Term _h_248 = STK(14);
    Term _h_249 = STK(15);
    Term _h_250 = STK(16);
    Term _h_251 = STK(17);
    Term _h_252 = STK(18);
    Term _h_234 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_235;
      STK(1) = _h_236;
      STK(2) = _h_238;
      STK(3) = _o_127;
      STK(4) = _h_239;
      STK(5) = _h_240;
      STK(6) = _h_241;
      STK(7) = _h_242;
      STK(8) = _h_243;
      STK(9) = _h_244;
      STK(10) = _h_245;
      STK(11) = _h_246;
      STK(12) = _h_247;
      STK(13) = _h_248;
      STK(14) = _h_249;
      STK(15) = _h_250;
      STK(16) = _h_251;
      STK(17) = _h_252;
      STK(18) = _h_234;
      STK(19) = FID_RUN_K302;
      WL_PUSHN(20);
    } else {
      u64 _t_31 = task_node(e, FID_RUN_K302, WL_CONT, WL_IDX, 1);
      e.mem[_t_31 + 0] = _h_235;
      e.mem[_t_31 + 1] = _h_236;
      e.mem[_t_31 + 2] = _h_238;
      e.mem[_t_31 + 3] = _o_127;
      e.mem[_t_31 + 4] = _h_239;
      e.mem[_t_31 + 5] = _h_240;
      e.mem[_t_31 + 6] = _h_241;
      e.mem[_t_31 + 7] = _h_242;
      e.mem[_t_31 + 8] = _h_243;
      e.mem[_t_31 + 9] = _h_244;
      e.mem[_t_31 + 10] = _h_245;
      e.mem[_t_31 + 11] = _h_246;
      e.mem[_t_31 + 12] = _h_247;
      e.mem[_t_31 + 13] = _h_248;
      e.mem[_t_31 + 14] = _h_249;
      e.mem[_t_31 + 15] = _h_250;
      e.mem[_t_31 + 16] = _h_251;
      e.mem[_t_31 + 17] = _h_252;
      e.mem[_t_31 + 18] = _h_234;
      WL_CONT = term_tsk(FID_RUN_K302, _t_31);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_32 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_32 + 0] = _h_237;
      return term_tsk(FID_NAT_SHOW, _t_32);
    }
    r0 = _h_237;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K302)
  {
    WL_POPN(19);
    Term _h_254 = STK(0);
    Term _h_255 = STK(1);
    u32 _h_256 = STK(2);
    u32 _o_128 = STK(3);
    Term _h_257 = STK(4);
    u32 _h_258 = STK(5);
    u32 _h_259 = STK(6);
    u32 _h_260 = STK(7);
    u32 _h_261 = STK(8);
    u32 _h_262 = STK(9);
    u32 _h_263 = STK(10);
    Term _h_264 = STK(11);
    Term _h_265 = STK(12);
    Term _h_266 = STK(13);
    Term _h_267 = STK(14);
    Term _h_268 = STK(15);
    Term _h_269 = STK(16);
    Term _h_270 = STK(17);
    Term _h_271 = STK(18);
    Term _h_253 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_254;
      STK(1) = _h_255;
      STK(2) = _o_128;
      STK(3) = _h_257;
      STK(4) = _h_258;
      STK(5) = _h_259;
      STK(6) = _h_260;
      STK(7) = _h_261;
      STK(8) = _h_262;
      STK(9) = _h_263;
      STK(10) = _h_264;
      STK(11) = _h_265;
      STK(12) = _h_266;
      STK(13) = _h_267;
      STK(14) = _h_268;
      STK(15) = _h_269;
      STK(16) = _h_270;
      STK(17) = _h_271;
      STK(18) = _h_253;
      STK(19) = FID_RUN_K303;
      WL_PUSHN(20);
    } else {
      u64 _t_33 = task_node(e, FID_RUN_K303, WL_CONT, WL_IDX, 1);
      e.mem[_t_33 + 0] = _h_254;
      e.mem[_t_33 + 1] = _h_255;
      e.mem[_t_33 + 2] = _o_128;
      e.mem[_t_33 + 3] = _h_257;
      e.mem[_t_33 + 4] = _h_258;
      e.mem[_t_33 + 5] = _h_259;
      e.mem[_t_33 + 6] = _h_260;
      e.mem[_t_33 + 7] = _h_261;
      e.mem[_t_33 + 8] = _h_262;
      e.mem[_t_33 + 9] = _h_263;
      e.mem[_t_33 + 10] = _h_264;
      e.mem[_t_33 + 11] = _h_265;
      e.mem[_t_33 + 12] = _h_266;
      e.mem[_t_33 + 13] = _h_267;
      e.mem[_t_33 + 14] = _h_268;
      e.mem[_t_33 + 15] = _h_269;
      e.mem[_t_33 + 16] = _h_270;
      e.mem[_t_33 + 17] = _h_271;
      e.mem[_t_33 + 18] = _h_253;
      WL_CONT = term_tsk(FID_RUN_K303, _t_33);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_34 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_34 + 0] = _h_256;
      return term_tsk(FID_U32_SHOW, _t_34);
    }
    r0 = _h_256;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K303)
  {
    WL_POPN(19);
    Term _h_273 = STK(0);
    Term _h_274 = STK(1);
    u32 _o_129 = STK(2);
    Term _h_275 = STK(3);
    u32 _h_276 = STK(4);
    u32 _h_277 = STK(5);
    u32 _h_278 = STK(6);
    u32 _h_279 = STK(7);
    u32 _h_280 = STK(8);
    u32 _h_281 = STK(9);
    Term _h_282 = STK(10);
    Term _h_283 = STK(11);
    Term _h_284 = STK(12);
    Term _h_285 = STK(13);
    Term _h_286 = STK(14);
    Term _h_287 = STK(15);
    Term _h_288 = STK(16);
    Term _h_289 = STK(17);
    Term _h_290 = STK(18);
    Term _h_272 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_273;
      STK(1) = _h_274;
      STK(2) = _h_275;
      STK(3) = _h_276;
      STK(4) = _h_277;
      STK(5) = _h_278;
      STK(6) = _h_279;
      STK(7) = _h_280;
      STK(8) = _h_281;
      STK(9) = _h_282;
      STK(10) = _h_283;
      STK(11) = _h_284;
      STK(12) = _h_285;
      STK(13) = _h_286;
      STK(14) = _h_287;
      STK(15) = _h_288;
      STK(16) = _h_289;
      STK(17) = _h_290;
      STK(18) = _h_272;
      STK(19) = FID_RUN_K304;
      WL_PUSHN(20);
    } else {
      u64 _t_35 = task_node(e, FID_RUN_K304, WL_CONT, WL_IDX, 1);
      e.mem[_t_35 + 0] = _h_273;
      e.mem[_t_35 + 1] = _h_274;
      e.mem[_t_35 + 2] = _h_275;
      e.mem[_t_35 + 3] = _h_276;
      e.mem[_t_35 + 4] = _h_277;
      e.mem[_t_35 + 5] = _h_278;
      e.mem[_t_35 + 6] = _h_279;
      e.mem[_t_35 + 7] = _h_280;
      e.mem[_t_35 + 8] = _h_281;
      e.mem[_t_35 + 9] = _h_282;
      e.mem[_t_35 + 10] = _h_283;
      e.mem[_t_35 + 11] = _h_284;
      e.mem[_t_35 + 12] = _h_285;
      e.mem[_t_35 + 13] = _h_286;
      e.mem[_t_35 + 14] = _h_287;
      e.mem[_t_35 + 15] = _h_288;
      e.mem[_t_35 + 16] = _h_289;
      e.mem[_t_35 + 17] = _h_290;
      e.mem[_t_35 + 18] = _h_272;
      WL_CONT = term_tsk(FID_RUN_K304, _t_35);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_36 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_36 + 0] = _o_129;
      return term_tsk(FID_U32_SHOW, _t_36);
    }
    r0 = _o_129;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K304)
  {
    WL_POPN(19);
    Term _h_292 = STK(0);
    Term _h_293 = STK(1);
    Term _h_294 = STK(2);
    u32 _h_295 = STK(3);
    u32 _h_296 = STK(4);
    u32 _h_297 = STK(5);
    u32 _h_298 = STK(6);
    u32 _h_299 = STK(7);
    u32 _h_300 = STK(8);
    Term _h_301 = STK(9);
    Term _h_302 = STK(10);
    Term _h_303 = STK(11);
    Term _h_304 = STK(12);
    Term _h_305 = STK(13);
    Term _h_306 = STK(14);
    Term _h_307 = STK(15);
    Term _h_308 = STK(16);
    Term _h_309 = STK(17);
    Term _h_310 = STK(18);
    Term _h_291 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_293;
      STK(1) = _h_294;
      STK(2) = _h_295;
      STK(3) = _h_296;
      STK(4) = _h_297;
      STK(5) = _h_298;
      STK(6) = _h_299;
      STK(7) = _h_300;
      STK(8) = _h_301;
      STK(9) = _h_302;
      STK(10) = _h_303;
      STK(11) = _h_304;
      STK(12) = _h_305;
      STK(13) = _h_306;
      STK(14) = _h_307;
      STK(15) = _h_308;
      STK(16) = _h_309;
      STK(17) = _h_310;
      STK(18) = _h_291;
      STK(19) = FID_RUN_K305;
      WL_PUSHN(20);
    } else {
      u64 _t_37 = task_node(e, FID_RUN_K305, WL_CONT, WL_IDX, 1);
      e.mem[_t_37 + 0] = _h_293;
      e.mem[_t_37 + 1] = _h_294;
      e.mem[_t_37 + 2] = _h_295;
      e.mem[_t_37 + 3] = _h_296;
      e.mem[_t_37 + 4] = _h_297;
      e.mem[_t_37 + 5] = _h_298;
      e.mem[_t_37 + 6] = _h_299;
      e.mem[_t_37 + 7] = _h_300;
      e.mem[_t_37 + 8] = _h_301;
      e.mem[_t_37 + 9] = _h_302;
      e.mem[_t_37 + 10] = _h_303;
      e.mem[_t_37 + 11] = _h_304;
      e.mem[_t_37 + 12] = _h_305;
      e.mem[_t_37 + 13] = _h_306;
      e.mem[_t_37 + 14] = _h_307;
      e.mem[_t_37 + 15] = _h_308;
      e.mem[_t_37 + 16] = _h_309;
      e.mem[_t_37 + 17] = _h_310;
      e.mem[_t_37 + 18] = _h_291;
      WL_CONT = term_tsk(FID_RUN_K305, _t_37);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_38 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_38 + 0] = _h_292;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_38);
    }
    r0 = _h_292;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K305)
  {
    WL_POPN(19);
    Term _h_312 = STK(0);
    Term _h_313 = STK(1);
    u32 _h_314 = STK(2);
    u32 _h_315 = STK(3);
    u32 _h_316 = STK(4);
    u32 _h_317 = STK(5);
    u32 _h_318 = STK(6);
    u32 _h_319 = STK(7);
    Term _h_320 = STK(8);
    Term _h_321 = STK(9);
    Term _h_322 = STK(10);
    Term _h_323 = STK(11);
    Term _h_324 = STK(12);
    Term _h_325 = STK(13);
    Term _h_326 = STK(14);
    Term _h_327 = STK(15);
    Term _h_328 = STK(16);
    Term _h_329 = STK(17);
    Term _h_330 = STK(18);
    Term _h_311 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_312;
      STK(1) = _h_313;
      STK(2) = _h_314;
      STK(3) = _h_315;
      STK(4) = _h_316;
      STK(5) = _h_317;
      STK(6) = _h_318;
      STK(7) = _h_319;
      STK(8) = _h_320;
      STK(9) = _h_321;
      STK(10) = _h_322;
      STK(11) = _h_323;
      STK(12) = _h_324;
      STK(13) = _h_325;
      STK(14) = _h_326;
      STK(15) = _h_327;
      STK(16) = _h_328;
      STK(17) = _h_329;
      STK(18) = _h_330;
      STK(19) = FID_RUN_K306;
      WL_PUSHN(20);
    } else {
      u64 _t_39 = task_node(e, FID_RUN_K306, WL_CONT, WL_IDX, 1);
      e.mem[_t_39 + 0] = _h_312;
      e.mem[_t_39 + 1] = _h_313;
      e.mem[_t_39 + 2] = _h_314;
      e.mem[_t_39 + 3] = _h_315;
      e.mem[_t_39 + 4] = _h_316;
      e.mem[_t_39 + 5] = _h_317;
      e.mem[_t_39 + 6] = _h_318;
      e.mem[_t_39 + 7] = _h_319;
      e.mem[_t_39 + 8] = _h_320;
      e.mem[_t_39 + 9] = _h_321;
      e.mem[_t_39 + 10] = _h_322;
      e.mem[_t_39 + 11] = _h_323;
      e.mem[_t_39 + 12] = _h_324;
      e.mem[_t_39 + 13] = _h_325;
      e.mem[_t_39 + 14] = _h_326;
      e.mem[_t_39 + 15] = _h_327;
      e.mem[_t_39 + 16] = _h_328;
      e.mem[_t_39 + 17] = _h_329;
      e.mem[_t_39 + 18] = _h_330;
      WL_CONT = term_tsk(FID_RUN_K306, _t_39);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_40 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_40 + 0] = _h_311;
      return term_tsk(FID_DATA, _t_40);
    }
    r0 = _h_311;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K306)
  {
    WL_POPN(19);
    Term _h_332 = STK(0);
    Term _h_333 = STK(1);
    u32 _h_334 = STK(2);
    u32 _h_335 = STK(3);
    u32 _h_336 = STK(4);
    u32 _h_337 = STK(5);
    u32 _h_338 = STK(6);
    u32 _h_339 = STK(7);
    Term _h_340 = STK(8);
    Term _h_341 = STK(9);
    Term _h_342 = STK(10);
    Term _h_343 = STK(11);
    Term _h_344 = STK(12);
    Term _h_345 = STK(13);
    Term _h_346 = STK(14);
    Term _h_347 = STK(15);
    Term _h_348 = STK(16);
    Term _h_349 = STK(17);
    Term _h_350 = STK(18);
    Term _h_331 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_332;
      STK(1) = _h_333;
      STK(2) = _h_334;
      STK(3) = _h_335;
      STK(4) = _h_336;
      STK(5) = _h_337;
      STK(6) = _h_338;
      STK(7) = _h_339;
      STK(8) = _h_340;
      STK(9) = _h_341;
      STK(10) = _h_342;
      STK(11) = _h_343;
      STK(12) = _h_344;
      STK(13) = _h_345;
      STK(14) = _h_346;
      STK(15) = _h_347;
      STK(16) = _h_348;
      STK(17) = _h_349;
      STK(18) = _h_350;
      STK(19) = FID_RUN_K307;
      WL_PUSHN(20);
    } else {
      u64 _t_41 = task_node(e, FID_RUN_K307, WL_CONT, WL_IDX, 1);
      e.mem[_t_41 + 0] = _h_332;
      e.mem[_t_41 + 1] = _h_333;
      e.mem[_t_41 + 2] = _h_334;
      e.mem[_t_41 + 3] = _h_335;
      e.mem[_t_41 + 4] = _h_336;
      e.mem[_t_41 + 5] = _h_337;
      e.mem[_t_41 + 6] = _h_338;
      e.mem[_t_41 + 7] = _h_339;
      e.mem[_t_41 + 8] = _h_340;
      e.mem[_t_41 + 9] = _h_341;
      e.mem[_t_41 + 10] = _h_342;
      e.mem[_t_41 + 11] = _h_343;
      e.mem[_t_41 + 12] = _h_344;
      e.mem[_t_41 + 13] = _h_345;
      e.mem[_t_41 + 14] = _h_346;
      e.mem[_t_41 + 15] = _h_347;
      e.mem[_t_41 + 16] = _h_348;
      e.mem[_t_41 + 17] = _h_349;
      e.mem[_t_41 + 18] = _h_350;
      WL_CONT = term_tsk(FID_RUN_K307, _t_41);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_42 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_42 + 0] = _h_331;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_42);
    }
    r0 = _h_331;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K307)
  {
    WL_POPN(19);
    Term _h_352 = STK(0);
    Term _h_353 = STK(1);
    u32 _h_354 = STK(2);
    u32 _h_355 = STK(3);
    u32 _h_356 = STK(4);
    u32 _h_357 = STK(5);
    u32 _h_358 = STK(6);
    u32 _h_359 = STK(7);
    Term _h_360 = STK(8);
    Term _h_361 = STK(9);
    Term _h_362 = STK(10);
    Term _h_363 = STK(11);
    Term _h_364 = STK(12);
    Term _h_365 = STK(13);
    Term _h_366 = STK(14);
    Term _h_367 = STK(15);
    Term _h_368 = STK(16);
    Term _h_369 = STK(17);
    Term _h_370 = STK(18);
    Term _h_351 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_353;
      STK(1) = _h_354;
      STK(2) = _h_355;
      STK(3) = _h_356;
      STK(4) = _h_357;
      STK(5) = _h_358;
      STK(6) = _h_359;
      STK(7) = _h_360;
      STK(8) = _h_361;
      STK(9) = _h_362;
      STK(10) = _h_363;
      STK(11) = _h_364;
      STK(12) = _h_365;
      STK(13) = _h_366;
      STK(14) = _h_367;
      STK(15) = _h_368;
      STK(16) = _h_369;
      STK(17) = _h_370;
      STK(18) = _h_351;
      STK(19) = FID_RUN_K308;
      WL_PUSHN(20);
    } else {
      u64 _t_43 = task_node(e, FID_RUN_K308, WL_CONT, WL_IDX, 1);
      e.mem[_t_43 + 0] = _h_353;
      e.mem[_t_43 + 1] = _h_354;
      e.mem[_t_43 + 2] = _h_355;
      e.mem[_t_43 + 3] = _h_356;
      e.mem[_t_43 + 4] = _h_357;
      e.mem[_t_43 + 5] = _h_358;
      e.mem[_t_43 + 6] = _h_359;
      e.mem[_t_43 + 7] = _h_360;
      e.mem[_t_43 + 8] = _h_361;
      e.mem[_t_43 + 9] = _h_362;
      e.mem[_t_43 + 10] = _h_363;
      e.mem[_t_43 + 11] = _h_364;
      e.mem[_t_43 + 12] = _h_365;
      e.mem[_t_43 + 13] = _h_366;
      e.mem[_t_43 + 14] = _h_367;
      e.mem[_t_43 + 15] = _h_368;
      e.mem[_t_43 + 16] = _h_369;
      e.mem[_t_43 + 17] = _h_370;
      e.mem[_t_43 + 18] = _h_351;
      WL_CONT = term_tsk(FID_RUN_K308, _t_43);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_44 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_44 + 0] = _h_352;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_44);
    }
    r0 = _h_352;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K308)
  {
    WL_POPN(19);
    Term _h_372 = STK(0);
    u32 _h_373 = STK(1);
    u32 _h_374 = STK(2);
    u32 _h_375 = STK(3);
    u32 _h_376 = STK(4);
    u32 _h_377 = STK(5);
    u32 _h_378 = STK(6);
    Term _h_379 = STK(7);
    Term _h_380 = STK(8);
    Term _h_381 = STK(9);
    Term _h_382 = STK(10);
    Term _h_383 = STK(11);
    Term _h_384 = STK(12);
    Term _h_385 = STK(13);
    Term _h_386 = STK(14);
    Term _h_387 = STK(15);
    Term _h_388 = STK(16);
    Term _h_389 = STK(17);
    Term _h_390 = STK(18);
    Term _h_371 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_372;
      STK(1) = _h_373;
      STK(2) = _h_374;
      STK(3) = _h_375;
      STK(4) = _h_376;
      STK(5) = _h_377;
      STK(6) = _h_378;
      STK(7) = _h_379;
      STK(8) = _h_380;
      STK(9) = _h_381;
      STK(10) = _h_382;
      STK(11) = _h_383;
      STK(12) = _h_384;
      STK(13) = _h_385;
      STK(14) = _h_386;
      STK(15) = _h_387;
      STK(16) = _h_388;
      STK(17) = _h_389;
      STK(18) = _h_390;
      STK(19) = FID_RUN_K309;
      WL_PUSHN(20);
    } else {
      u64 _t_45 = task_node(e, FID_RUN_K309, WL_CONT, WL_IDX, 1);
      e.mem[_t_45 + 0] = _h_372;
      e.mem[_t_45 + 1] = _h_373;
      e.mem[_t_45 + 2] = _h_374;
      e.mem[_t_45 + 3] = _h_375;
      e.mem[_t_45 + 4] = _h_376;
      e.mem[_t_45 + 5] = _h_377;
      e.mem[_t_45 + 6] = _h_378;
      e.mem[_t_45 + 7] = _h_379;
      e.mem[_t_45 + 8] = _h_380;
      e.mem[_t_45 + 9] = _h_381;
      e.mem[_t_45 + 10] = _h_382;
      e.mem[_t_45 + 11] = _h_383;
      e.mem[_t_45 + 12] = _h_384;
      e.mem[_t_45 + 13] = _h_385;
      e.mem[_t_45 + 14] = _h_386;
      e.mem[_t_45 + 15] = _h_387;
      e.mem[_t_45 + 16] = _h_388;
      e.mem[_t_45 + 17] = _h_389;
      e.mem[_t_45 + 18] = _h_390;
      WL_CONT = term_tsk(FID_RUN_K309, _t_45);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_46 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_46 + 0] = _h_371;
      return term_tsk(FID_DATA, _t_46);
    }
    r0 = _h_371;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K309)
  {
    WL_POPN(19);
    Term _h_392 = STK(0);
    u32 _h_393 = STK(1);
    u32 _h_394 = STK(2);
    u32 _h_395 = STK(3);
    u32 _h_396 = STK(4);
    u32 _h_397 = STK(5);
    u32 _h_398 = STK(6);
    Term _h_399 = STK(7);
    Term _h_400 = STK(8);
    Term _h_401 = STK(9);
    Term _h_402 = STK(10);
    Term _h_403 = STK(11);
    Term _h_404 = STK(12);
    Term _h_405 = STK(13);
    Term _h_406 = STK(14);
    Term _h_407 = STK(15);
    Term _h_408 = STK(16);
    Term _h_409 = STK(17);
    Term _h_410 = STK(18);
    Term _h_391 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_392;
      STK(1) = _h_393;
      STK(2) = _h_394;
      STK(3) = _h_395;
      STK(4) = _h_396;
      STK(5) = _h_397;
      STK(6) = _h_398;
      STK(7) = _h_399;
      STK(8) = _h_400;
      STK(9) = _h_401;
      STK(10) = _h_402;
      STK(11) = _h_403;
      STK(12) = _h_404;
      STK(13) = _h_405;
      STK(14) = _h_406;
      STK(15) = _h_407;
      STK(16) = _h_408;
      STK(17) = _h_409;
      STK(18) = _h_410;
      STK(19) = FID_RUN_K310;
      WL_PUSHN(20);
    } else {
      u64 _t_47 = task_node(e, FID_RUN_K310, WL_CONT, WL_IDX, 1);
      e.mem[_t_47 + 0] = _h_392;
      e.mem[_t_47 + 1] = _h_393;
      e.mem[_t_47 + 2] = _h_394;
      e.mem[_t_47 + 3] = _h_395;
      e.mem[_t_47 + 4] = _h_396;
      e.mem[_t_47 + 5] = _h_397;
      e.mem[_t_47 + 6] = _h_398;
      e.mem[_t_47 + 7] = _h_399;
      e.mem[_t_47 + 8] = _h_400;
      e.mem[_t_47 + 9] = _h_401;
      e.mem[_t_47 + 10] = _h_402;
      e.mem[_t_47 + 11] = _h_403;
      e.mem[_t_47 + 12] = _h_404;
      e.mem[_t_47 + 13] = _h_405;
      e.mem[_t_47 + 14] = _h_406;
      e.mem[_t_47 + 15] = _h_407;
      e.mem[_t_47 + 16] = _h_408;
      e.mem[_t_47 + 17] = _h_409;
      e.mem[_t_47 + 18] = _h_410;
      WL_CONT = term_tsk(FID_RUN_K310, _t_47);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_48 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_48 + 0] = _h_391;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_48);
    }
    r0 = _h_391;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K310)
  {
    WL_POPN(19);
    Term _h_412 = STK(0);
    u32 _h_413 = STK(1);
    u32 _h_414 = STK(2);
    u32 _h_415 = STK(3);
    u32 _h_416 = STK(4);
    u32 _h_417 = STK(5);
    u32 _h_418 = STK(6);
    Term _h_419 = STK(7);
    Term _h_420 = STK(8);
    Term _h_421 = STK(9);
    Term _h_422 = STK(10);
    Term _h_423 = STK(11);
    Term _h_424 = STK(12);
    Term _h_425 = STK(13);
    Term _h_426 = STK(14);
    Term _h_427 = STK(15);
    Term _h_428 = STK(16);
    Term _h_429 = STK(17);
    Term _h_430 = STK(18);
    Term _h_411 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_413;
      STK(1) = _h_414;
      STK(2) = _h_415;
      STK(3) = _h_416;
      STK(4) = _h_417;
      STK(5) = _h_418;
      STK(6) = _h_419;
      STK(7) = _h_420;
      STK(8) = _h_421;
      STK(9) = _h_422;
      STK(10) = _h_423;
      STK(11) = _h_424;
      STK(12) = _h_425;
      STK(13) = _h_426;
      STK(14) = _h_427;
      STK(15) = _h_428;
      STK(16) = _h_429;
      STK(17) = _h_430;
      STK(18) = _h_411;
      STK(19) = FID_RUN_K311;
      WL_PUSHN(20);
    } else {
      u64 _t_49 = task_node(e, FID_RUN_K311, WL_CONT, WL_IDX, 1);
      e.mem[_t_49 + 0] = _h_413;
      e.mem[_t_49 + 1] = _h_414;
      e.mem[_t_49 + 2] = _h_415;
      e.mem[_t_49 + 3] = _h_416;
      e.mem[_t_49 + 4] = _h_417;
      e.mem[_t_49 + 5] = _h_418;
      e.mem[_t_49 + 6] = _h_419;
      e.mem[_t_49 + 7] = _h_420;
      e.mem[_t_49 + 8] = _h_421;
      e.mem[_t_49 + 9] = _h_422;
      e.mem[_t_49 + 10] = _h_423;
      e.mem[_t_49 + 11] = _h_424;
      e.mem[_t_49 + 12] = _h_425;
      e.mem[_t_49 + 13] = _h_426;
      e.mem[_t_49 + 14] = _h_427;
      e.mem[_t_49 + 15] = _h_428;
      e.mem[_t_49 + 16] = _h_429;
      e.mem[_t_49 + 17] = _h_430;
      e.mem[_t_49 + 18] = _h_411;
      WL_CONT = term_tsk(FID_RUN_K311, _t_49);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_50 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_50 + 0] = _h_412;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_50);
    }
    r0 = _h_412;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K311)
  {
    WL_POPN(19);
    u32 _h_432 = STK(0);
    u32 _h_433 = STK(1);
    u32 _h_434 = STK(2);
    u32 _h_435 = STK(3);
    u32 _h_436 = STK(4);
    u32 _h_437 = STK(5);
    Term _h_438 = STK(6);
    Term _h_439 = STK(7);
    Term _h_440 = STK(8);
    Term _h_441 = STK(9);
    Term _h_442 = STK(10);
    Term _h_443 = STK(11);
    Term _h_444 = STK(12);
    Term _h_445 = STK(13);
    Term _h_446 = STK(14);
    Term _h_447 = STK(15);
    Term _h_448 = STK(16);
    Term _h_449 = STK(17);
    Term _h_450 = STK(18);
    Term _h_431 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_432;
      STK(1) = _h_433;
      STK(2) = _h_434;
      STK(3) = _h_435;
      STK(4) = _h_436;
      STK(5) = _h_437;
      STK(6) = _h_438;
      STK(7) = _h_439;
      STK(8) = _h_440;
      STK(9) = _h_441;
      STK(10) = _h_442;
      STK(11) = _h_443;
      STK(12) = _h_444;
      STK(13) = _h_445;
      STK(14) = _h_446;
      STK(15) = _h_447;
      STK(16) = _h_448;
      STK(17) = _h_449;
      STK(18) = _h_450;
      STK(19) = FID_RUN_K312;
      WL_PUSHN(20);
    } else {
      u64 _t_51 = task_node(e, FID_RUN_K312, WL_CONT, WL_IDX, 1);
      e.mem[_t_51 + 0] = _h_432;
      e.mem[_t_51 + 1] = _h_433;
      e.mem[_t_51 + 2] = _h_434;
      e.mem[_t_51 + 3] = _h_435;
      e.mem[_t_51 + 4] = _h_436;
      e.mem[_t_51 + 5] = _h_437;
      e.mem[_t_51 + 6] = _h_438;
      e.mem[_t_51 + 7] = _h_439;
      e.mem[_t_51 + 8] = _h_440;
      e.mem[_t_51 + 9] = _h_441;
      e.mem[_t_51 + 10] = _h_442;
      e.mem[_t_51 + 11] = _h_443;
      e.mem[_t_51 + 12] = _h_444;
      e.mem[_t_51 + 13] = _h_445;
      e.mem[_t_51 + 14] = _h_446;
      e.mem[_t_51 + 15] = _h_447;
      e.mem[_t_51 + 16] = _h_448;
      e.mem[_t_51 + 17] = _h_449;
      e.mem[_t_51 + 18] = _h_450;
      WL_CONT = term_tsk(FID_RUN_K312, _t_51);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_52 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_52 + 0] = _h_431;
      return term_tsk(FID_DATA, _t_52);
    }
    r0 = _h_431;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K312)
  {
    WL_POPN(19);
    u32 _h_452 = STK(0);
    u32 _h_453 = STK(1);
    u32 _h_454 = STK(2);
    u32 _h_455 = STK(3);
    u32 _h_456 = STK(4);
    u32 _h_457 = STK(5);
    Term _h_458 = STK(6);
    Term _h_459 = STK(7);
    Term _h_460 = STK(8);
    Term _h_461 = STK(9);
    Term _h_462 = STK(10);
    Term _h_463 = STK(11);
    Term _h_464 = STK(12);
    Term _h_465 = STK(13);
    Term _h_466 = STK(14);
    Term _h_467 = STK(15);
    Term _h_468 = STK(16);
    Term _h_469 = STK(17);
    Term _h_470 = STK(18);
    Term _h_451 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_452;
      STK(1) = _h_453;
      STK(2) = _h_454;
      STK(3) = _h_455;
      STK(4) = _h_456;
      STK(5) = _h_457;
      STK(6) = _h_458;
      STK(7) = _h_459;
      STK(8) = _h_460;
      STK(9) = _h_461;
      STK(10) = _h_462;
      STK(11) = _h_463;
      STK(12) = _h_464;
      STK(13) = _h_465;
      STK(14) = _h_466;
      STK(15) = _h_467;
      STK(16) = _h_468;
      STK(17) = _h_469;
      STK(18) = _h_470;
      STK(19) = FID_RUN_K313;
      WL_PUSHN(20);
    } else {
      u64 _t_53 = task_node(e, FID_RUN_K313, WL_CONT, WL_IDX, 1);
      e.mem[_t_53 + 0] = _h_452;
      e.mem[_t_53 + 1] = _h_453;
      e.mem[_t_53 + 2] = _h_454;
      e.mem[_t_53 + 3] = _h_455;
      e.mem[_t_53 + 4] = _h_456;
      e.mem[_t_53 + 5] = _h_457;
      e.mem[_t_53 + 6] = _h_458;
      e.mem[_t_53 + 7] = _h_459;
      e.mem[_t_53 + 8] = _h_460;
      e.mem[_t_53 + 9] = _h_461;
      e.mem[_t_53 + 10] = _h_462;
      e.mem[_t_53 + 11] = _h_463;
      e.mem[_t_53 + 12] = _h_464;
      e.mem[_t_53 + 13] = _h_465;
      e.mem[_t_53 + 14] = _h_466;
      e.mem[_t_53 + 15] = _h_467;
      e.mem[_t_53 + 16] = _h_468;
      e.mem[_t_53 + 17] = _h_469;
      e.mem[_t_53 + 18] = _h_470;
      WL_CONT = term_tsk(FID_RUN_K313, _t_53);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_54 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_54 + 0] = _h_451;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_54);
    }
    r0 = _h_451;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K313)
  {
    WL_POPN(19);
    u32 _h_472 = STK(0);
    u32 _h_473 = STK(1);
    u32 _h_474 = STK(2);
    u32 _h_475 = STK(3);
    u32 _h_476 = STK(4);
    u32 _h_477 = STK(5);
    Term _h_478 = STK(6);
    Term _h_479 = STK(7);
    Term _h_480 = STK(8);
    Term _h_481 = STK(9);
    Term _h_482 = STK(10);
    Term _h_483 = STK(11);
    Term _h_484 = STK(12);
    Term _h_485 = STK(13);
    Term _h_486 = STK(14);
    Term _h_487 = STK(15);
    Term _h_488 = STK(16);
    Term _h_489 = STK(17);
    Term _h_490 = STK(18);
    Term _h_471 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_473;
      STK(1) = _h_474;
      STK(2) = _h_475;
      STK(3) = _h_476;
      STK(4) = _h_477;
      STK(5) = _h_478;
      STK(6) = _h_479;
      STK(7) = _h_480;
      STK(8) = _h_481;
      STK(9) = _h_482;
      STK(10) = _h_483;
      STK(11) = _h_484;
      STK(12) = _h_485;
      STK(13) = _h_486;
      STK(14) = _h_487;
      STK(15) = _h_488;
      STK(16) = _h_489;
      STK(17) = _h_490;
      STK(18) = _h_471;
      STK(19) = FID_RUN_K314;
      WL_PUSHN(20);
    } else {
      u64 _t_55 = task_node(e, FID_RUN_K314, WL_CONT, WL_IDX, 1);
      e.mem[_t_55 + 0] = _h_473;
      e.mem[_t_55 + 1] = _h_474;
      e.mem[_t_55 + 2] = _h_475;
      e.mem[_t_55 + 3] = _h_476;
      e.mem[_t_55 + 4] = _h_477;
      e.mem[_t_55 + 5] = _h_478;
      e.mem[_t_55 + 6] = _h_479;
      e.mem[_t_55 + 7] = _h_480;
      e.mem[_t_55 + 8] = _h_481;
      e.mem[_t_55 + 9] = _h_482;
      e.mem[_t_55 + 10] = _h_483;
      e.mem[_t_55 + 11] = _h_484;
      e.mem[_t_55 + 12] = _h_485;
      e.mem[_t_55 + 13] = _h_486;
      e.mem[_t_55 + 14] = _h_487;
      e.mem[_t_55 + 15] = _h_488;
      e.mem[_t_55 + 16] = _h_489;
      e.mem[_t_55 + 17] = _h_490;
      e.mem[_t_55 + 18] = _h_471;
      WL_CONT = term_tsk(FID_RUN_K314, _t_55);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_56 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_56 + 0] = _h_472;
      return term_tsk(FID_U32_SHOW, _t_56);
    }
    r0 = _h_472;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K314)
  {
    WL_POPN(19);
    u32 _h_492 = STK(0);
    u32 _h_493 = STK(1);
    u32 _h_494 = STK(2);
    u32 _h_495 = STK(3);
    u32 _h_496 = STK(4);
    Term _h_497 = STK(5);
    Term _h_498 = STK(6);
    Term _h_499 = STK(7);
    Term _h_500 = STK(8);
    Term _h_501 = STK(9);
    Term _h_502 = STK(10);
    Term _h_503 = STK(11);
    Term _h_504 = STK(12);
    Term _h_505 = STK(13);
    Term _h_506 = STK(14);
    Term _h_507 = STK(15);
    Term _h_508 = STK(16);
    Term _h_509 = STK(17);
    Term _h_510 = STK(18);
    Term _h_491 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_497;
      STK(1) = _h_498;
      STK(2) = _h_499;
      STK(3) = _h_500;
      STK(4) = _h_501;
      STK(5) = _h_502;
      STK(6) = _h_503;
      STK(7) = _h_504;
      STK(8) = _h_505;
      STK(9) = _h_506;
      STK(10) = _h_507;
      STK(11) = _h_508;
      STK(12) = _h_509;
      STK(13) = _h_510;
      STK(14) = _h_491;
      STK(15) = FID_RUN_K315;
      WL_PUSHN(16);
    } else {
      u64 _t_57 = task_node(e, FID_RUN_K315, WL_CONT, WL_IDX, 1);
      e.mem[_t_57 + 0] = _h_497;
      e.mem[_t_57 + 1] = _h_498;
      e.mem[_t_57 + 2] = _h_499;
      e.mem[_t_57 + 3] = _h_500;
      e.mem[_t_57 + 4] = _h_501;
      e.mem[_t_57 + 5] = _h_502;
      e.mem[_t_57 + 6] = _h_503;
      e.mem[_t_57 + 7] = _h_504;
      e.mem[_t_57 + 8] = _h_505;
      e.mem[_t_57 + 9] = _h_506;
      e.mem[_t_57 + 10] = _h_507;
      e.mem[_t_57 + 11] = _h_508;
      e.mem[_t_57 + 12] = _h_509;
      e.mem[_t_57 + 13] = _h_510;
      e.mem[_t_57 + 14] = _h_491;
      WL_CONT = term_tsk(FID_RUN_K315, _t_57);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LEDGER)) {
      u64 _t_58 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER, WL_CONT, WL_IDX, 0);
      e.mem[_t_58 + 0] = _h_492;
      e.mem[_t_58 + 1] = _h_493;
      e.mem[_t_58 + 2] = _h_494;
      e.mem[_t_58 + 3] = _h_495;
      e.mem[_t_58 + 4] = _h_496;
      return term_tsk(FID_HOST_RENDER_RENDER_LEDGER, _t_58);
    }
    r0 = _h_492;
    r1 = _h_493;
    r2 = _h_494;
    r3 = _h_495;
    r4 = _h_496;
    WL_JMP(FID_HOST_RENDER_RENDER_LEDGER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K315)
  {
    WL_POPN(15);
    Term _h_512 = STK(0);
    Term _h_513 = STK(1);
    Term _h_514 = STK(2);
    Term _h_515 = STK(3);
    Term _h_516 = STK(4);
    Term _h_517 = STK(5);
    Term _h_518 = STK(6);
    Term _h_519 = STK(7);
    Term _h_520 = STK(8);
    Term _h_521 = STK(9);
    Term _h_522 = STK(10);
    Term _h_523 = STK(11);
    Term _h_524 = STK(12);
    Term _h_525 = STK(13);
    Term _h_526 = STK(14);
    Term _h_511 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_512;
      STK(1) = _h_513;
      STK(2) = _h_514;
      STK(3) = _h_515;
      STK(4) = _h_516;
      STK(5) = _h_517;
      STK(6) = _h_518;
      STK(7) = _h_519;
      STK(8) = _h_520;
      STK(9) = _h_521;
      STK(10) = _h_522;
      STK(11) = _h_523;
      STK(12) = _h_524;
      STK(13) = _h_525;
      STK(14) = _h_526;
      STK(15) = FID_RUN_K316;
      WL_PUSHN(16);
    } else {
      u64 _t_59 = task_node(e, FID_RUN_K316, WL_CONT, WL_IDX, 1);
      e.mem[_t_59 + 0] = _h_512;
      e.mem[_t_59 + 1] = _h_513;
      e.mem[_t_59 + 2] = _h_514;
      e.mem[_t_59 + 3] = _h_515;
      e.mem[_t_59 + 4] = _h_516;
      e.mem[_t_59 + 5] = _h_517;
      e.mem[_t_59 + 6] = _h_518;
      e.mem[_t_59 + 7] = _h_519;
      e.mem[_t_59 + 8] = _h_520;
      e.mem[_t_59 + 9] = _h_521;
      e.mem[_t_59 + 10] = _h_522;
      e.mem[_t_59 + 11] = _h_523;
      e.mem[_t_59 + 12] = _h_524;
      e.mem[_t_59 + 13] = _h_525;
      e.mem[_t_59 + 14] = _h_526;
      WL_CONT = term_tsk(FID_RUN_K316, _t_59);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_60 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_60 + 0] = _h_511;
      e.mem[_t_60 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_60);
    }
    r0 = _h_511;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K316)
  {
    WL_POPN(15);
    Term _h_528 = STK(0);
    Term _h_529 = STK(1);
    Term _h_530 = STK(2);
    Term _h_531 = STK(3);
    Term _h_532 = STK(4);
    Term _h_533 = STK(5);
    Term _h_534 = STK(6);
    Term _h_535 = STK(7);
    Term _h_536 = STK(8);
    Term _h_537 = STK(9);
    Term _h_538 = STK(10);
    Term _h_539 = STK(11);
    Term _h_540 = STK(12);
    Term _h_541 = STK(13);
    Term _h_542 = STK(14);
    Term _h_527 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_528;
      STK(1) = _h_529;
      STK(2) = _h_530;
      STK(3) = _h_531;
      STK(4) = _h_532;
      STK(5) = _h_533;
      STK(6) = _h_534;
      STK(7) = _h_535;
      STK(8) = _h_536;
      STK(9) = _h_537;
      STK(10) = _h_538;
      STK(11) = _h_539;
      STK(12) = _h_540;
      STK(13) = _h_541;
      STK(14) = _h_542;
      STK(15) = FID_RUN_K317;
      WL_PUSHN(16);
    } else {
      u64 _t_61 = task_node(e, FID_RUN_K317, WL_CONT, WL_IDX, 1);
      e.mem[_t_61 + 0] = _h_528;
      e.mem[_t_61 + 1] = _h_529;
      e.mem[_t_61 + 2] = _h_530;
      e.mem[_t_61 + 3] = _h_531;
      e.mem[_t_61 + 4] = _h_532;
      e.mem[_t_61 + 5] = _h_533;
      e.mem[_t_61 + 6] = _h_534;
      e.mem[_t_61 + 7] = _h_535;
      e.mem[_t_61 + 8] = _h_536;
      e.mem[_t_61 + 9] = _h_537;
      e.mem[_t_61 + 10] = _h_538;
      e.mem[_t_61 + 11] = _h_539;
      e.mem[_t_61 + 12] = _h_540;
      e.mem[_t_61 + 13] = _h_541;
      e.mem[_t_61 + 14] = _h_542;
      WL_CONT = term_tsk(FID_RUN_K317, _t_61);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_62 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_62 + 0] = term_ctr(CID_SCON, STAT_OFF + 134);
      e.mem[_t_62 + 1] = _h_527;
      return term_tsk(FID_STRING_APPEND, _t_62);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 134);
    r1 = _h_527;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K317)
  {
    WL_POPN(15);
    Term _h_544 = STK(0);
    Term _h_545 = STK(1);
    Term _h_546 = STK(2);
    Term _h_547 = STK(3);
    Term _h_548 = STK(4);
    Term _h_549 = STK(5);
    Term _h_550 = STK(6);
    Term _h_551 = STK(7);
    Term _h_552 = STK(8);
    Term _h_553 = STK(9);
    Term _h_554 = STK(10);
    Term _h_555 = STK(11);
    Term _h_556 = STK(12);
    Term _h_557 = STK(13);
    Term _h_558 = STK(14);
    Term _h_543 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_544;
      STK(1) = _h_545;
      STK(2) = _h_546;
      STK(3) = _h_547;
      STK(4) = _h_548;
      STK(5) = _h_549;
      STK(6) = _h_550;
      STK(7) = _h_551;
      STK(8) = _h_552;
      STK(9) = _h_553;
      STK(10) = _h_554;
      STK(11) = _h_555;
      STK(12) = _h_556;
      STK(13) = _h_557;
      STK(14) = FID_RUN_K318;
      WL_PUSHN(15);
    } else {
      u64 _t_63 = task_node(e, FID_RUN_K318, WL_CONT, WL_IDX, 1);
      e.mem[_t_63 + 0] = _h_544;
      e.mem[_t_63 + 1] = _h_545;
      e.mem[_t_63 + 2] = _h_546;
      e.mem[_t_63 + 3] = _h_547;
      e.mem[_t_63 + 4] = _h_548;
      e.mem[_t_63 + 5] = _h_549;
      e.mem[_t_63 + 6] = _h_550;
      e.mem[_t_63 + 7] = _h_551;
      e.mem[_t_63 + 8] = _h_552;
      e.mem[_t_63 + 9] = _h_553;
      e.mem[_t_63 + 10] = _h_554;
      e.mem[_t_63 + 11] = _h_555;
      e.mem[_t_63 + 12] = _h_556;
      e.mem[_t_63 + 13] = _h_557;
      WL_CONT = term_tsk(FID_RUN_K318, _t_63);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_64 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_64 + 0] = _h_558;
      e.mem[_t_64 + 1] = _h_543;
      return term_tsk(FID_STRING_APPEND, _t_64);
    }
    r0 = _h_558;
    r1 = _h_543;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K318)
  {
    WL_POPN(14);
    Term _h_560 = STK(0);
    Term _h_561 = STK(1);
    Term _h_562 = STK(2);
    Term _h_563 = STK(3);
    Term _h_564 = STK(4);
    Term _h_565 = STK(5);
    Term _h_566 = STK(6);
    Term _h_567 = STK(7);
    Term _h_568 = STK(8);
    Term _h_569 = STK(9);
    Term _h_570 = STK(10);
    Term _h_571 = STK(11);
    Term _h_572 = STK(12);
    Term _h_573 = STK(13);
    Term _h_559 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_560;
      STK(1) = _h_561;
      STK(2) = _h_562;
      STK(3) = _h_563;
      STK(4) = _h_564;
      STK(5) = _h_565;
      STK(6) = _h_566;
      STK(7) = _h_567;
      STK(8) = _h_568;
      STK(9) = _h_569;
      STK(10) = _h_570;
      STK(11) = _h_571;
      STK(12) = _h_572;
      STK(13) = _h_573;
      STK(14) = FID_RUN_K319;
      WL_PUSHN(15);
    } else {
      u64 _t_65 = task_node(e, FID_RUN_K319, WL_CONT, WL_IDX, 1);
      e.mem[_t_65 + 0] = _h_560;
      e.mem[_t_65 + 1] = _h_561;
      e.mem[_t_65 + 2] = _h_562;
      e.mem[_t_65 + 3] = _h_563;
      e.mem[_t_65 + 4] = _h_564;
      e.mem[_t_65 + 5] = _h_565;
      e.mem[_t_65 + 6] = _h_566;
      e.mem[_t_65 + 7] = _h_567;
      e.mem[_t_65 + 8] = _h_568;
      e.mem[_t_65 + 9] = _h_569;
      e.mem[_t_65 + 10] = _h_570;
      e.mem[_t_65 + 11] = _h_571;
      e.mem[_t_65 + 12] = _h_572;
      e.mem[_t_65 + 13] = _h_573;
      WL_CONT = term_tsk(FID_RUN_K319, _t_65);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_66 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_66 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
      e.mem[_t_66 + 1] = _h_559;
      return term_tsk(FID_STRING_APPEND, _t_66);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 64);
    r1 = _h_559;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K319)
  {
    WL_POPN(14);
    Term _h_575 = STK(0);
    Term _h_576 = STK(1);
    Term _h_577 = STK(2);
    Term _h_578 = STK(3);
    Term _h_579 = STK(4);
    Term _h_580 = STK(5);
    Term _h_581 = STK(6);
    Term _h_582 = STK(7);
    Term _h_583 = STK(8);
    Term _h_584 = STK(9);
    Term _h_585 = STK(10);
    Term _h_586 = STK(11);
    Term _h_587 = STK(12);
    Term _h_588 = STK(13);
    Term _h_574 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_575;
      STK(1) = _h_576;
      STK(2) = _h_577;
      STK(3) = _h_578;
      STK(4) = _h_579;
      STK(5) = _h_580;
      STK(6) = _h_581;
      STK(7) = _h_582;
      STK(8) = _h_583;
      STK(9) = _h_584;
      STK(10) = _h_585;
      STK(11) = _h_586;
      STK(12) = _h_587;
      STK(13) = FID_RUN_K320;
      WL_PUSHN(14);
    } else {
      u64 _t_67 = task_node(e, FID_RUN_K320, WL_CONT, WL_IDX, 1);
      e.mem[_t_67 + 0] = _h_575;
      e.mem[_t_67 + 1] = _h_576;
      e.mem[_t_67 + 2] = _h_577;
      e.mem[_t_67 + 3] = _h_578;
      e.mem[_t_67 + 4] = _h_579;
      e.mem[_t_67 + 5] = _h_580;
      e.mem[_t_67 + 6] = _h_581;
      e.mem[_t_67 + 7] = _h_582;
      e.mem[_t_67 + 8] = _h_583;
      e.mem[_t_67 + 9] = _h_584;
      e.mem[_t_67 + 10] = _h_585;
      e.mem[_t_67 + 11] = _h_586;
      e.mem[_t_67 + 12] = _h_587;
      WL_CONT = term_tsk(FID_RUN_K320, _t_67);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_68 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_68 + 0] = _h_588;
      e.mem[_t_68 + 1] = _h_574;
      return term_tsk(FID_STRING_APPEND, _t_68);
    }
    r0 = _h_588;
    r1 = _h_574;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K320)
  {
    WL_POPN(13);
    Term _h_590 = STK(0);
    Term _h_591 = STK(1);
    Term _h_592 = STK(2);
    Term _h_593 = STK(3);
    Term _h_594 = STK(4);
    Term _h_595 = STK(5);
    Term _h_596 = STK(6);
    Term _h_597 = STK(7);
    Term _h_598 = STK(8);
    Term _h_599 = STK(9);
    Term _h_600 = STK(10);
    Term _h_601 = STK(11);
    Term _h_602 = STK(12);
    Term _h_589 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_590;
      STK(1) = _h_591;
      STK(2) = _h_592;
      STK(3) = _h_593;
      STK(4) = _h_594;
      STK(5) = _h_595;
      STK(6) = _h_596;
      STK(7) = _h_597;
      STK(8) = _h_598;
      STK(9) = _h_599;
      STK(10) = _h_600;
      STK(11) = _h_601;
      STK(12) = _h_602;
      STK(13) = FID_RUN_K321;
      WL_PUSHN(14);
    } else {
      u64 _t_69 = task_node(e, FID_RUN_K321, WL_CONT, WL_IDX, 1);
      e.mem[_t_69 + 0] = _h_590;
      e.mem[_t_69 + 1] = _h_591;
      e.mem[_t_69 + 2] = _h_592;
      e.mem[_t_69 + 3] = _h_593;
      e.mem[_t_69 + 4] = _h_594;
      e.mem[_t_69 + 5] = _h_595;
      e.mem[_t_69 + 6] = _h_596;
      e.mem[_t_69 + 7] = _h_597;
      e.mem[_t_69 + 8] = _h_598;
      e.mem[_t_69 + 9] = _h_599;
      e.mem[_t_69 + 10] = _h_600;
      e.mem[_t_69 + 11] = _h_601;
      e.mem[_t_69 + 12] = _h_602;
      WL_CONT = term_tsk(FID_RUN_K321, _t_69);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_70 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_70 + 0] = term_ctr(CID_SCON, STAT_OFF + 150);
      e.mem[_t_70 + 1] = _h_589;
      return term_tsk(FID_STRING_APPEND, _t_70);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 150);
    r1 = _h_589;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K321)
  {
    WL_POPN(13);
    Term _h_604 = STK(0);
    Term _h_605 = STK(1);
    Term _h_606 = STK(2);
    Term _h_607 = STK(3);
    Term _h_608 = STK(4);
    Term _h_609 = STK(5);
    Term _h_610 = STK(6);
    Term _h_611 = STK(7);
    Term _h_612 = STK(8);
    Term _h_613 = STK(9);
    Term _h_614 = STK(10);
    Term _h_615 = STK(11);
    Term _h_616 = STK(12);
    Term _h_603 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_604;
      STK(1) = _h_605;
      STK(2) = _h_606;
      STK(3) = _h_607;
      STK(4) = _h_608;
      STK(5) = _h_609;
      STK(6) = _h_610;
      STK(7) = _h_611;
      STK(8) = _h_612;
      STK(9) = _h_613;
      STK(10) = _h_614;
      STK(11) = _h_615;
      STK(12) = FID_RUN_K322;
      WL_PUSHN(13);
    } else {
      u64 _t_71 = task_node(e, FID_RUN_K322, WL_CONT, WL_IDX, 1);
      e.mem[_t_71 + 0] = _h_604;
      e.mem[_t_71 + 1] = _h_605;
      e.mem[_t_71 + 2] = _h_606;
      e.mem[_t_71 + 3] = _h_607;
      e.mem[_t_71 + 4] = _h_608;
      e.mem[_t_71 + 5] = _h_609;
      e.mem[_t_71 + 6] = _h_610;
      e.mem[_t_71 + 7] = _h_611;
      e.mem[_t_71 + 8] = _h_612;
      e.mem[_t_71 + 9] = _h_613;
      e.mem[_t_71 + 10] = _h_614;
      e.mem[_t_71 + 11] = _h_615;
      WL_CONT = term_tsk(FID_RUN_K322, _t_71);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_72 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_72 + 0] = _h_616;
      e.mem[_t_72 + 1] = _h_603;
      return term_tsk(FID_STRING_APPEND, _t_72);
    }
    r0 = _h_616;
    r1 = _h_603;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K322)
  {
    WL_POPN(12);
    Term _h_618 = STK(0);
    Term _h_619 = STK(1);
    Term _h_620 = STK(2);
    Term _h_621 = STK(3);
    Term _h_622 = STK(4);
    Term _h_623 = STK(5);
    Term _h_624 = STK(6);
    Term _h_625 = STK(7);
    Term _h_626 = STK(8);
    Term _h_627 = STK(9);
    Term _h_628 = STK(10);
    Term _h_629 = STK(11);
    Term _h_617 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_618;
      STK(1) = _h_619;
      STK(2) = _h_620;
      STK(3) = _h_621;
      STK(4) = _h_622;
      STK(5) = _h_623;
      STK(6) = _h_624;
      STK(7) = _h_625;
      STK(8) = _h_626;
      STK(9) = _h_627;
      STK(10) = _h_628;
      STK(11) = _h_629;
      STK(12) = FID_RUN_K323;
      WL_PUSHN(13);
    } else {
      u64 _t_73 = task_node(e, FID_RUN_K323, WL_CONT, WL_IDX, 1);
      e.mem[_t_73 + 0] = _h_618;
      e.mem[_t_73 + 1] = _h_619;
      e.mem[_t_73 + 2] = _h_620;
      e.mem[_t_73 + 3] = _h_621;
      e.mem[_t_73 + 4] = _h_622;
      e.mem[_t_73 + 5] = _h_623;
      e.mem[_t_73 + 6] = _h_624;
      e.mem[_t_73 + 7] = _h_625;
      e.mem[_t_73 + 8] = _h_626;
      e.mem[_t_73 + 9] = _h_627;
      e.mem[_t_73 + 10] = _h_628;
      e.mem[_t_73 + 11] = _h_629;
      WL_CONT = term_tsk(FID_RUN_K323, _t_73);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_74 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_74 + 0] = term_ctr(CID_SCON, STAT_OFF + 164);
      e.mem[_t_74 + 1] = _h_617;
      return term_tsk(FID_STRING_APPEND, _t_74);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 164);
    r1 = _h_617;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K323)
  {
    WL_POPN(12);
    Term _h_631 = STK(0);
    Term _h_632 = STK(1);
    Term _h_633 = STK(2);
    Term _h_634 = STK(3);
    Term _h_635 = STK(4);
    Term _h_636 = STK(5);
    Term _h_637 = STK(6);
    Term _h_638 = STK(7);
    Term _h_639 = STK(8);
    Term _h_640 = STK(9);
    Term _h_641 = STK(10);
    Term _h_642 = STK(11);
    Term _h_630 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_631;
      STK(1) = _h_632;
      STK(2) = _h_633;
      STK(3) = _h_634;
      STK(4) = _h_635;
      STK(5) = _h_636;
      STK(6) = _h_637;
      STK(7) = _h_638;
      STK(8) = _h_639;
      STK(9) = _h_640;
      STK(10) = _h_641;
      STK(11) = FID_RUN_K324;
      WL_PUSHN(12);
    } else {
      u64 _t_75 = task_node(e, FID_RUN_K324, WL_CONT, WL_IDX, 1);
      e.mem[_t_75 + 0] = _h_631;
      e.mem[_t_75 + 1] = _h_632;
      e.mem[_t_75 + 2] = _h_633;
      e.mem[_t_75 + 3] = _h_634;
      e.mem[_t_75 + 4] = _h_635;
      e.mem[_t_75 + 5] = _h_636;
      e.mem[_t_75 + 6] = _h_637;
      e.mem[_t_75 + 7] = _h_638;
      e.mem[_t_75 + 8] = _h_639;
      e.mem[_t_75 + 9] = _h_640;
      e.mem[_t_75 + 10] = _h_641;
      WL_CONT = term_tsk(FID_RUN_K324, _t_75);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_76 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_76 + 0] = _h_642;
      e.mem[_t_76 + 1] = _h_630;
      return term_tsk(FID_STRING_APPEND, _t_76);
    }
    r0 = _h_642;
    r1 = _h_630;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K324)
  {
    WL_POPN(11);
    Term _h_644 = STK(0);
    Term _h_645 = STK(1);
    Term _h_646 = STK(2);
    Term _h_647 = STK(3);
    Term _h_648 = STK(4);
    Term _h_649 = STK(5);
    Term _h_650 = STK(6);
    Term _h_651 = STK(7);
    Term _h_652 = STK(8);
    Term _h_653 = STK(9);
    Term _h_654 = STK(10);
    Term _h_643 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_644;
      STK(1) = _h_645;
      STK(2) = _h_646;
      STK(3) = _h_647;
      STK(4) = _h_648;
      STK(5) = _h_649;
      STK(6) = _h_650;
      STK(7) = _h_651;
      STK(8) = _h_652;
      STK(9) = _h_653;
      STK(10) = _h_654;
      STK(11) = FID_RUN_K325;
      WL_PUSHN(12);
    } else {
      u64 _t_77 = task_node(e, FID_RUN_K325, WL_CONT, WL_IDX, 1);
      e.mem[_t_77 + 0] = _h_644;
      e.mem[_t_77 + 1] = _h_645;
      e.mem[_t_77 + 2] = _h_646;
      e.mem[_t_77 + 3] = _h_647;
      e.mem[_t_77 + 4] = _h_648;
      e.mem[_t_77 + 5] = _h_649;
      e.mem[_t_77 + 6] = _h_650;
      e.mem[_t_77 + 7] = _h_651;
      e.mem[_t_77 + 8] = _h_652;
      e.mem[_t_77 + 9] = _h_653;
      e.mem[_t_77 + 10] = _h_654;
      WL_CONT = term_tsk(FID_RUN_K325, _t_77);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_78 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_78 + 0] = term_ctr(CID_SCON, STAT_OFF + 174);
      e.mem[_t_78 + 1] = _h_643;
      return term_tsk(FID_STRING_APPEND, _t_78);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 174);
    r1 = _h_643;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K325)
  {
    WL_POPN(11);
    Term _h_656 = STK(0);
    Term _h_657 = STK(1);
    Term _h_658 = STK(2);
    Term _h_659 = STK(3);
    Term _h_660 = STK(4);
    Term _h_661 = STK(5);
    Term _h_662 = STK(6);
    Term _h_663 = STK(7);
    Term _h_664 = STK(8);
    Term _h_665 = STK(9);
    Term _h_666 = STK(10);
    Term _h_655 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_656;
      STK(1) = _h_657;
      STK(2) = _h_658;
      STK(3) = _h_659;
      STK(4) = _h_660;
      STK(5) = _h_661;
      STK(6) = _h_662;
      STK(7) = _h_663;
      STK(8) = _h_664;
      STK(9) = _h_665;
      STK(10) = FID_RUN_K326;
      WL_PUSHN(11);
    } else {
      u64 _t_79 = task_node(e, FID_RUN_K326, WL_CONT, WL_IDX, 1);
      e.mem[_t_79 + 0] = _h_656;
      e.mem[_t_79 + 1] = _h_657;
      e.mem[_t_79 + 2] = _h_658;
      e.mem[_t_79 + 3] = _h_659;
      e.mem[_t_79 + 4] = _h_660;
      e.mem[_t_79 + 5] = _h_661;
      e.mem[_t_79 + 6] = _h_662;
      e.mem[_t_79 + 7] = _h_663;
      e.mem[_t_79 + 8] = _h_664;
      e.mem[_t_79 + 9] = _h_665;
      WL_CONT = term_tsk(FID_RUN_K326, _t_79);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_80 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_80 + 0] = _h_666;
      e.mem[_t_80 + 1] = _h_655;
      return term_tsk(FID_STRING_APPEND, _t_80);
    }
    r0 = _h_666;
    r1 = _h_655;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K326)
  {
    WL_POPN(10);
    Term _h_668 = STK(0);
    Term _h_669 = STK(1);
    Term _h_670 = STK(2);
    Term _h_671 = STK(3);
    Term _h_672 = STK(4);
    Term _h_673 = STK(5);
    Term _h_674 = STK(6);
    Term _h_675 = STK(7);
    Term _h_676 = STK(8);
    Term _h_677 = STK(9);
    Term _h_667 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_668;
      STK(1) = _h_669;
      STK(2) = _h_670;
      STK(3) = _h_671;
      STK(4) = _h_672;
      STK(5) = _h_673;
      STK(6) = _h_674;
      STK(7) = _h_675;
      STK(8) = _h_676;
      STK(9) = _h_677;
      STK(10) = FID_RUN_K327;
      WL_PUSHN(11);
    } else {
      u64 _t_81 = task_node(e, FID_RUN_K327, WL_CONT, WL_IDX, 1);
      e.mem[_t_81 + 0] = _h_668;
      e.mem[_t_81 + 1] = _h_669;
      e.mem[_t_81 + 2] = _h_670;
      e.mem[_t_81 + 3] = _h_671;
      e.mem[_t_81 + 4] = _h_672;
      e.mem[_t_81 + 5] = _h_673;
      e.mem[_t_81 + 6] = _h_674;
      e.mem[_t_81 + 7] = _h_675;
      e.mem[_t_81 + 8] = _h_676;
      e.mem[_t_81 + 9] = _h_677;
      WL_CONT = term_tsk(FID_RUN_K327, _t_81);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_82 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_82 + 0] = term_ctr(CID_SCON, STAT_OFF + 192);
      e.mem[_t_82 + 1] = _h_667;
      return term_tsk(FID_STRING_APPEND, _t_82);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 192);
    r1 = _h_667;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K327)
  {
    WL_POPN(10);
    Term _h_679 = STK(0);
    Term _h_680 = STK(1);
    Term _h_681 = STK(2);
    Term _h_682 = STK(3);
    Term _h_683 = STK(4);
    Term _h_684 = STK(5);
    Term _h_685 = STK(6);
    Term _h_686 = STK(7);
    Term _h_687 = STK(8);
    Term _h_688 = STK(9);
    Term _h_678 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_679;
      STK(1) = _h_680;
      STK(2) = _h_681;
      STK(3) = _h_682;
      STK(4) = _h_683;
      STK(5) = _h_684;
      STK(6) = _h_685;
      STK(7) = _h_686;
      STK(8) = _h_687;
      STK(9) = FID_RUN_K328;
      WL_PUSHN(10);
    } else {
      u64 _t_83 = task_node(e, FID_RUN_K328, WL_CONT, WL_IDX, 1);
      e.mem[_t_83 + 0] = _h_679;
      e.mem[_t_83 + 1] = _h_680;
      e.mem[_t_83 + 2] = _h_681;
      e.mem[_t_83 + 3] = _h_682;
      e.mem[_t_83 + 4] = _h_683;
      e.mem[_t_83 + 5] = _h_684;
      e.mem[_t_83 + 6] = _h_685;
      e.mem[_t_83 + 7] = _h_686;
      e.mem[_t_83 + 8] = _h_687;
      WL_CONT = term_tsk(FID_RUN_K328, _t_83);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_84 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_84 + 0] = _h_688;
      e.mem[_t_84 + 1] = _h_678;
      return term_tsk(FID_STRING_APPEND, _t_84);
    }
    r0 = _h_688;
    r1 = _h_678;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K328)
  {
    WL_POPN(9);
    Term _h_690 = STK(0);
    Term _h_691 = STK(1);
    Term _h_692 = STK(2);
    Term _h_693 = STK(3);
    Term _h_694 = STK(4);
    Term _h_695 = STK(5);
    Term _h_696 = STK(6);
    Term _h_697 = STK(7);
    Term _h_698 = STK(8);
    Term _h_689 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_690;
      STK(1) = _h_691;
      STK(2) = _h_692;
      STK(3) = _h_693;
      STK(4) = _h_694;
      STK(5) = _h_695;
      STK(6) = _h_696;
      STK(7) = _h_697;
      STK(8) = _h_698;
      STK(9) = FID_RUN_K329;
      WL_PUSHN(10);
    } else {
      u64 _t_85 = task_node(e, FID_RUN_K329, WL_CONT, WL_IDX, 1);
      e.mem[_t_85 + 0] = _h_690;
      e.mem[_t_85 + 1] = _h_691;
      e.mem[_t_85 + 2] = _h_692;
      e.mem[_t_85 + 3] = _h_693;
      e.mem[_t_85 + 4] = _h_694;
      e.mem[_t_85 + 5] = _h_695;
      e.mem[_t_85 + 6] = _h_696;
      e.mem[_t_85 + 7] = _h_697;
      e.mem[_t_85 + 8] = _h_698;
      WL_CONT = term_tsk(FID_RUN_K329, _t_85);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_86 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_86 + 0] = term_ctr(CID_SCON, STAT_OFF + 202);
      e.mem[_t_86 + 1] = _h_689;
      return term_tsk(FID_STRING_APPEND, _t_86);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 202);
    r1 = _h_689;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K329)
  {
    WL_POPN(9);
    Term _h_700 = STK(0);
    Term _h_701 = STK(1);
    Term _h_702 = STK(2);
    Term _h_703 = STK(3);
    Term _h_704 = STK(4);
    Term _h_705 = STK(5);
    Term _h_706 = STK(6);
    Term _h_707 = STK(7);
    Term _h_708 = STK(8);
    Term _h_699 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_700;
      STK(1) = _h_701;
      STK(2) = _h_702;
      STK(3) = _h_703;
      STK(4) = _h_704;
      STK(5) = _h_705;
      STK(6) = _h_706;
      STK(7) = _h_707;
      STK(8) = FID_RUN_K330;
      WL_PUSHN(9);
    } else {
      u64 _t_87 = task_node(e, FID_RUN_K330, WL_CONT, WL_IDX, 1);
      e.mem[_t_87 + 0] = _h_700;
      e.mem[_t_87 + 1] = _h_701;
      e.mem[_t_87 + 2] = _h_702;
      e.mem[_t_87 + 3] = _h_703;
      e.mem[_t_87 + 4] = _h_704;
      e.mem[_t_87 + 5] = _h_705;
      e.mem[_t_87 + 6] = _h_706;
      e.mem[_t_87 + 7] = _h_707;
      WL_CONT = term_tsk(FID_RUN_K330, _t_87);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_88 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_88 + 0] = _h_708;
      e.mem[_t_88 + 1] = _h_699;
      return term_tsk(FID_STRING_APPEND, _t_88);
    }
    r0 = _h_708;
    r1 = _h_699;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K330)
  {
    WL_POPN(8);
    Term _h_710 = STK(0);
    Term _h_711 = STK(1);
    Term _h_712 = STK(2);
    Term _h_713 = STK(3);
    Term _h_714 = STK(4);
    Term _h_715 = STK(5);
    Term _h_716 = STK(6);
    Term _h_717 = STK(7);
    Term _h_709 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_710;
      STK(1) = _h_711;
      STK(2) = _h_712;
      STK(3) = _h_713;
      STK(4) = _h_714;
      STK(5) = _h_715;
      STK(6) = _h_716;
      STK(7) = _h_717;
      STK(8) = FID_RUN_K331;
      WL_PUSHN(9);
    } else {
      u64 _t_89 = task_node(e, FID_RUN_K331, WL_CONT, WL_IDX, 1);
      e.mem[_t_89 + 0] = _h_710;
      e.mem[_t_89 + 1] = _h_711;
      e.mem[_t_89 + 2] = _h_712;
      e.mem[_t_89 + 3] = _h_713;
      e.mem[_t_89 + 4] = _h_714;
      e.mem[_t_89 + 5] = _h_715;
      e.mem[_t_89 + 6] = _h_716;
      e.mem[_t_89 + 7] = _h_717;
      WL_CONT = term_tsk(FID_RUN_K331, _t_89);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_90 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_90 + 0] = term_ctr(CID_SCON, STAT_OFF + 214);
      e.mem[_t_90 + 1] = _h_709;
      return term_tsk(FID_STRING_APPEND, _t_90);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 214);
    r1 = _h_709;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K331)
  {
    WL_POPN(8);
    Term _h_719 = STK(0);
    Term _h_720 = STK(1);
    Term _h_721 = STK(2);
    Term _h_722 = STK(3);
    Term _h_723 = STK(4);
    Term _h_724 = STK(5);
    Term _h_725 = STK(6);
    Term _h_726 = STK(7);
    Term _h_718 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_719;
      STK(1) = _h_720;
      STK(2) = _h_721;
      STK(3) = _h_722;
      STK(4) = _h_723;
      STK(5) = _h_724;
      STK(6) = _h_725;
      STK(7) = FID_RUN_K332;
      WL_PUSHN(8);
    } else {
      u64 _t_91 = task_node(e, FID_RUN_K332, WL_CONT, WL_IDX, 1);
      e.mem[_t_91 + 0] = _h_719;
      e.mem[_t_91 + 1] = _h_720;
      e.mem[_t_91 + 2] = _h_721;
      e.mem[_t_91 + 3] = _h_722;
      e.mem[_t_91 + 4] = _h_723;
      e.mem[_t_91 + 5] = _h_724;
      e.mem[_t_91 + 6] = _h_725;
      WL_CONT = term_tsk(FID_RUN_K332, _t_91);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_92 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_92 + 0] = _h_726;
      e.mem[_t_92 + 1] = _h_718;
      return term_tsk(FID_STRING_APPEND, _t_92);
    }
    r0 = _h_726;
    r1 = _h_718;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K332)
  {
    WL_POPN(7);
    Term _h_728 = STK(0);
    Term _h_729 = STK(1);
    Term _h_730 = STK(2);
    Term _h_731 = STK(3);
    Term _h_732 = STK(4);
    Term _h_733 = STK(5);
    Term _h_734 = STK(6);
    Term _h_727 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_728;
      STK(1) = _h_729;
      STK(2) = _h_730;
      STK(3) = _h_731;
      STK(4) = _h_732;
      STK(5) = _h_733;
      STK(6) = _h_734;
      STK(7) = FID_RUN_K333;
      WL_PUSHN(8);
    } else {
      u64 _t_93 = task_node(e, FID_RUN_K333, WL_CONT, WL_IDX, 1);
      e.mem[_t_93 + 0] = _h_728;
      e.mem[_t_93 + 1] = _h_729;
      e.mem[_t_93 + 2] = _h_730;
      e.mem[_t_93 + 3] = _h_731;
      e.mem[_t_93 + 4] = _h_732;
      e.mem[_t_93 + 5] = _h_733;
      e.mem[_t_93 + 6] = _h_734;
      WL_CONT = term_tsk(FID_RUN_K333, _t_93);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_94 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_94 + 0] = term_ctr(CID_SCON, STAT_OFF + 234);
      e.mem[_t_94 + 1] = _h_727;
      return term_tsk(FID_STRING_APPEND, _t_94);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 234);
    r1 = _h_727;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K333)
  {
    WL_POPN(7);
    Term _h_736 = STK(0);
    Term _h_737 = STK(1);
    Term _h_738 = STK(2);
    Term _h_739 = STK(3);
    Term _h_740 = STK(4);
    Term _h_741 = STK(5);
    Term _h_742 = STK(6);
    Term _h_735 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_736;
      STK(1) = _h_737;
      STK(2) = _h_738;
      STK(3) = _h_739;
      STK(4) = _h_740;
      STK(5) = _h_741;
      STK(6) = FID_RUN_K334;
      WL_PUSHN(7);
    } else {
      u64 _t_95 = task_node(e, FID_RUN_K334, WL_CONT, WL_IDX, 1);
      e.mem[_t_95 + 0] = _h_736;
      e.mem[_t_95 + 1] = _h_737;
      e.mem[_t_95 + 2] = _h_738;
      e.mem[_t_95 + 3] = _h_739;
      e.mem[_t_95 + 4] = _h_740;
      e.mem[_t_95 + 5] = _h_741;
      WL_CONT = term_tsk(FID_RUN_K334, _t_95);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_96 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_96 + 0] = _h_742;
      e.mem[_t_96 + 1] = _h_735;
      return term_tsk(FID_STRING_APPEND, _t_96);
    }
    r0 = _h_742;
    r1 = _h_735;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K334)
  {
    WL_POPN(6);
    Term _h_744 = STK(0);
    Term _h_745 = STK(1);
    Term _h_746 = STK(2);
    Term _h_747 = STK(3);
    Term _h_748 = STK(4);
    Term _h_749 = STK(5);
    Term _h_743 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_744;
      STK(1) = _h_745;
      STK(2) = _h_746;
      STK(3) = _h_747;
      STK(4) = _h_748;
      STK(5) = _h_749;
      STK(6) = FID_RUN_K335;
      WL_PUSHN(7);
    } else {
      u64 _t_97 = task_node(e, FID_RUN_K335, WL_CONT, WL_IDX, 1);
      e.mem[_t_97 + 0] = _h_744;
      e.mem[_t_97 + 1] = _h_745;
      e.mem[_t_97 + 2] = _h_746;
      e.mem[_t_97 + 3] = _h_747;
      e.mem[_t_97 + 4] = _h_748;
      e.mem[_t_97 + 5] = _h_749;
      WL_CONT = term_tsk(FID_RUN_K335, _t_97);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_98 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_98 + 0] = term_ctr(CID_SCON, STAT_OFF + 246);
      e.mem[_t_98 + 1] = _h_743;
      return term_tsk(FID_STRING_APPEND, _t_98);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 246);
    r1 = _h_743;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K335)
  {
    WL_POPN(6);
    Term _h_751 = STK(0);
    Term _h_752 = STK(1);
    Term _h_753 = STK(2);
    Term _h_754 = STK(3);
    Term _h_755 = STK(4);
    Term _h_756 = STK(5);
    Term _h_750 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_751;
      STK(1) = _h_752;
      STK(2) = _h_753;
      STK(3) = _h_754;
      STK(4) = _h_755;
      STK(5) = FID_RUN_K336;
      WL_PUSHN(6);
    } else {
      u64 _t_99 = task_node(e, FID_RUN_K336, WL_CONT, WL_IDX, 1);
      e.mem[_t_99 + 0] = _h_751;
      e.mem[_t_99 + 1] = _h_752;
      e.mem[_t_99 + 2] = _h_753;
      e.mem[_t_99 + 3] = _h_754;
      e.mem[_t_99 + 4] = _h_755;
      WL_CONT = term_tsk(FID_RUN_K336, _t_99);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_100 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_100 + 0] = _h_756;
      e.mem[_t_100 + 1] = _h_750;
      return term_tsk(FID_STRING_APPEND, _t_100);
    }
    r0 = _h_756;
    r1 = _h_750;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K336)
  {
    WL_POPN(5);
    Term _h_758 = STK(0);
    Term _h_759 = STK(1);
    Term _h_760 = STK(2);
    Term _h_761 = STK(3);
    Term _h_762 = STK(4);
    Term _h_757 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_758;
      STK(1) = _h_759;
      STK(2) = _h_760;
      STK(3) = _h_761;
      STK(4) = _h_762;
      STK(5) = FID_RUN_K337;
      WL_PUSHN(6);
    } else {
      u64 _t_101 = task_node(e, FID_RUN_K337, WL_CONT, WL_IDX, 1);
      e.mem[_t_101 + 0] = _h_758;
      e.mem[_t_101 + 1] = _h_759;
      e.mem[_t_101 + 2] = _h_760;
      e.mem[_t_101 + 3] = _h_761;
      e.mem[_t_101 + 4] = _h_762;
      WL_CONT = term_tsk(FID_RUN_K337, _t_101);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_102 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_102 + 0] = term_ctr(CID_SCON, STAT_OFF + 266);
      e.mem[_t_102 + 1] = _h_757;
      return term_tsk(FID_STRING_APPEND, _t_102);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 266);
    r1 = _h_757;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K337)
  {
    WL_POPN(5);
    Term _h_764 = STK(0);
    Term _h_765 = STK(1);
    Term _h_766 = STK(2);
    Term _h_767 = STK(3);
    Term _h_768 = STK(4);
    Term _h_763 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_764;
      STK(1) = _h_765;
      STK(2) = _h_766;
      STK(3) = _h_767;
      STK(4) = FID_RUN_K338;
      WL_PUSHN(5);
    } else {
      u64 _t_103 = task_node(e, FID_RUN_K338, WL_CONT, WL_IDX, 1);
      e.mem[_t_103 + 0] = _h_764;
      e.mem[_t_103 + 1] = _h_765;
      e.mem[_t_103 + 2] = _h_766;
      e.mem[_t_103 + 3] = _h_767;
      WL_CONT = term_tsk(FID_RUN_K338, _t_103);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_104 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_104 + 0] = _h_768;
      e.mem[_t_104 + 1] = _h_763;
      return term_tsk(FID_STRING_APPEND, _t_104);
    }
    r0 = _h_768;
    r1 = _h_763;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K338)
  {
    WL_POPN(4);
    Term _h_770 = STK(0);
    Term _h_771 = STK(1);
    Term _h_772 = STK(2);
    Term _h_773 = STK(3);
    Term _h_769 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_770;
      STK(1) = _h_771;
      STK(2) = _h_772;
      STK(3) = _h_773;
      STK(4) = FID_RUN_K339;
      WL_PUSHN(5);
    } else {
      u64 _t_105 = task_node(e, FID_RUN_K339, WL_CONT, WL_IDX, 1);
      e.mem[_t_105 + 0] = _h_770;
      e.mem[_t_105 + 1] = _h_771;
      e.mem[_t_105 + 2] = _h_772;
      e.mem[_t_105 + 3] = _h_773;
      WL_CONT = term_tsk(FID_RUN_K339, _t_105);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_106 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_106 + 0] = term_ctr(CID_SCON, STAT_OFF + 282);
      e.mem[_t_106 + 1] = _h_769;
      return term_tsk(FID_STRING_APPEND, _t_106);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 282);
    r1 = _h_769;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K339)
  {
    WL_POPN(4);
    Term _h_775 = STK(0);
    Term _h_776 = STK(1);
    Term _h_777 = STK(2);
    Term _h_778 = STK(3);
    Term _h_774 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_775;
      STK(1) = _h_776;
      STK(2) = _h_777;
      STK(3) = FID_RUN_K340;
      WL_PUSHN(4);
    } else {
      u64 _t_107 = task_node(e, FID_RUN_K340, WL_CONT, WL_IDX, 1);
      e.mem[_t_107 + 0] = _h_775;
      e.mem[_t_107 + 1] = _h_776;
      e.mem[_t_107 + 2] = _h_777;
      WL_CONT = term_tsk(FID_RUN_K340, _t_107);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_108 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_108 + 0] = _h_778;
      e.mem[_t_108 + 1] = _h_774;
      return term_tsk(FID_STRING_APPEND, _t_108);
    }
    r0 = _h_778;
    r1 = _h_774;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K340)
  {
    WL_POPN(3);
    Term _h_780 = STK(0);
    Term _h_781 = STK(1);
    Term _h_782 = STK(2);
    Term _h_779 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_780;
      STK(1) = _h_781;
      STK(2) = _h_782;
      STK(3) = FID_RUN_K341;
      WL_PUSHN(4);
    } else {
      u64 _t_109 = task_node(e, FID_RUN_K341, WL_CONT, WL_IDX, 1);
      e.mem[_t_109 + 0] = _h_780;
      e.mem[_t_109 + 1] = _h_781;
      e.mem[_t_109 + 2] = _h_782;
      WL_CONT = term_tsk(FID_RUN_K341, _t_109);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_110 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_110 + 0] = term_ctr(CID_SCON, STAT_OFF + 288);
      e.mem[_t_110 + 1] = _h_779;
      return term_tsk(FID_STRING_APPEND, _t_110);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 288);
    r1 = _h_779;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K341)
  {
    WL_POPN(3);
    Term _h_784 = STK(0);
    Term _h_785 = STK(1);
    Term _h_786 = STK(2);
    Term _h_783 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_784;
      STK(1) = _h_785;
      STK(2) = FID_RUN_K342;
      WL_PUSHN(3);
    } else {
      u64 _t_111 = task_node(e, FID_RUN_K342, WL_CONT, WL_IDX, 1);
      e.mem[_t_111 + 0] = _h_784;
      e.mem[_t_111 + 1] = _h_785;
      WL_CONT = term_tsk(FID_RUN_K342, _t_111);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_112 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_112 + 0] = _h_786;
      e.mem[_t_112 + 1] = _h_783;
      return term_tsk(FID_STRING_APPEND, _t_112);
    }
    r0 = _h_786;
    r1 = _h_783;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K342)
  {
    WL_POPN(2);
    Term _h_788 = STK(0);
    Term _h_789 = STK(1);
    Term _h_787 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_788;
      STK(1) = _h_789;
      STK(2) = FID_RUN_K343;
      WL_PUSHN(3);
    } else {
      u64 _t_113 = task_node(e, FID_RUN_K343, WL_CONT, WL_IDX, 1);
      e.mem[_t_113 + 0] = _h_788;
      e.mem[_t_113 + 1] = _h_789;
      WL_CONT = term_tsk(FID_RUN_K343, _t_113);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_114 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_114 + 0] = term_ctr(CID_SCON, STAT_OFF + 300);
      e.mem[_t_114 + 1] = _h_787;
      return term_tsk(FID_STRING_APPEND, _t_114);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 300);
    r1 = _h_787;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K343)
  {
    WL_POPN(2);
    Term _h_791 = STK(0);
    Term _h_792 = STK(1);
    Term _h_790 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_791;
      STK(1) = FID_RUN_K344;
      WL_PUSHN(2);
    } else {
      u64 _t_115 = task_node(e, FID_RUN_K344, WL_CONT, WL_IDX, 1);
      e.mem[_t_115 + 0] = _h_791;
      WL_CONT = term_tsk(FID_RUN_K344, _t_115);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_116 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_116 + 0] = _h_792;
      e.mem[_t_116 + 1] = _h_790;
      return term_tsk(FID_STRING_APPEND, _t_116);
    }
    r0 = _h_792;
    r1 = _h_790;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K344)
  {
    WL_POPN(1);
    Term _h_794 = STK(0);
    Term _h_793 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_794;
      STK(1) = FID_RUN_K345;
      WL_PUSHN(2);
    } else {
      u64 _t_117 = task_node(e, FID_RUN_K345, WL_CONT, WL_IDX, 1);
      e.mem[_t_117 + 0] = _h_794;
      WL_CONT = term_tsk(FID_RUN_K345, _t_117);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_118 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_118 + 0] = term_ctr(CID_SCON, STAT_OFF + 312);
      e.mem[_t_118 + 1] = _h_793;
      return term_tsk(FID_STRING_APPEND, _t_118);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 312);
    r1 = _h_793;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K345)
  {
    WL_POPN(1);
    Term _h_796 = STK(0);
    Term _h_795 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_RUN_K346;
      WL_PUSHN(1);
    } else {
      u64 _t_119 = task_node(e, FID_RUN_K346, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_RUN_K346, _t_119);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_120 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_120 + 0] = _h_796;
      e.mem[_t_120 + 1] = _h_795;
      return term_tsk(FID_STRING_APPEND, _t_120);
    }
    r0 = _h_796;
    r1 = _h_795;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K346)
  {
    Term _h_797 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_RUN_K347;
      WL_PUSHN(1);
    } else {
      u64 _t_121 = task_node(e, FID_RUN_K347, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_RUN_K347, _t_121);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_122 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_122 + 0] = term_ctr(CID_SCON, STAT_OFF + 324);
      e.mem[_t_122 + 1] = _h_797;
      return term_tsk(FID_STRING_APPEND, _t_122);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 324);
    r1 = _h_797;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K347)
  {
    Term _h_798 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_798;
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C349, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C349, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C349)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K350;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K350, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K350, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K350)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 100ull;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K352;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K352, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K352, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_1 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 1ull;
      e.mem[_t_1 + 1] = blk_new(e, 0, 0, 0, 1, _fv_0);
      return term_tsk(FID_RUN, _t_1);
    }
    r0 = 1ull;
    r1 = blk_new(e, 0, 0, 0, 1, _fv_0);
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K352)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_0;
    r0 = term_clo(FID_MAIN_C353, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C353)
  {
    Term _h_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_12 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_1;
      e.mem[_t_12 + 1] = term_clo(FID_MAIN_C354, 0);
      e.mem[_t_12 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_12);
    }
    r0 = _h_1;
    r1 = term_clo(FID_MAIN_C354, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C354)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fv_1[1];
    _fv_1[0] = 100ull;
    Term _a_0 = blk_new(e, 0, 1ull, 0, 1, _fv_1);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, 101ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K355;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K355, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K355, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_3 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = 2ull;
      e.mem[_t_3 + 1] = _a_0;
      return term_tsk(FID_RUN, _t_3);
    }
    r0 = 2ull;
    r1 = _a_0;
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K355)
  {
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_2;
    r0 = term_clo(FID_MAIN_C356, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C356)
  {
    Term _h_3 = r0;
    Term _x_2 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_11 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_3;
      e.mem[_t_11 + 1] = term_clo(FID_MAIN_C357, 0);
      e.mem[_t_11 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_11);
    }
    r0 = _h_3;
    r1 = term_clo(FID_MAIN_C357, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C357)
  {
    Term _x_3 = r0;
    WL_OPEN
    Term _fv_2[1];
    _fv_2[0] = 100ull;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_2);
    Term _at_2 = blk_loc(e.mem, _a_1);
    Term _at_3 = blk_at(_a_1, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, 101ull);
    Term _at_4 = blk_loc(e.mem, _a_1);
    Term _at_5 = blk_at(_a_1, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, 102ull);
    Term _at_6 = blk_loc(e.mem, _a_1);
    Term _at_7 = blk_at(_a_1, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, 103ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K358;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K358, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K358, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_5 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = 4ull;
      e.mem[_t_5 + 1] = _a_1;
      return term_tsk(FID_RUN, _t_5);
    }
    r0 = 4ull;
    r1 = _a_1;
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K358)
  {
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _h_4;
    r0 = term_clo(FID_MAIN_C359, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C359)
  {
    Term _h_5 = r0;
    Term _x_4 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_10 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_5;
      e.mem[_t_10 + 1] = term_clo(FID_MAIN_C360, 0);
      e.mem[_t_10 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_10);
    }
    r0 = _h_5;
    r1 = term_clo(FID_MAIN_C360, 0);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C360)
  {
    Term _x_5 = r0;
    WL_OPEN
    Term _fv_3[1];
    _fv_3[0] = 100ull;
    Term _a_2 = blk_new(e, 0, 3ull, 0, 1, _fv_3);
    Term _at_8 = blk_loc(e.mem, _a_2);
    Term _at_9 = blk_at(_a_2, 1ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, 101ull);
    Term _at_10 = blk_loc(e.mem, _a_2);
    Term _at_11 = blk_at(_a_2, 2ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, 102ull);
    Term _at_12 = blk_loc(e.mem, _a_2);
    Term _at_13 = blk_at(_a_2, 3ull, 0);
    u32 _c_6 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, 103ull);
    Term _at_14 = blk_loc(e.mem, _a_2);
    Term _at_15 = blk_at(_a_2, 4ull, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, 104ull);
    Term _at_16 = blk_loc(e.mem, _a_2);
    Term _at_17 = blk_at(_a_2, 5ull, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_16, _at_17 + 0);
    blk_write(e.mem, 0, _at_16, _at_17 + 0, 105ull);
    Term _at_18 = blk_loc(e.mem, _a_2);
    Term _at_19 = blk_at(_a_2, 6ull, 0);
    u32 _c_9 = blk_read(e.mem, 0, _at_18, _at_19 + 0);
    blk_write(e.mem, 0, _at_18, _at_19 + 0, 106ull);
    Term _at_20 = blk_loc(e.mem, _a_2);
    Term _at_21 = blk_at(_a_2, 7ull, 0);
    u32 _c_10 = blk_read(e.mem, 0, _at_20, _at_21 + 0);
    blk_write(e.mem, 0, _at_20, _at_21 + 0, 107ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K361;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K361, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K361, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_7 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = 8ull;
      e.mem[_t_7 + 1] = _a_2;
      return term_tsk(FID_RUN, _t_7);
    }
    r0 = 8ull;
    r1 = _a_2;
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K361)
  {
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = _h_6;
    r0 = term_clo(FID_MAIN_C362, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C362)
  {
    Term _h_7 = r0;
    Term _x_6 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_7;
      e.mem[_t_9 + 1] = term_clo(FID_MAIN_C363, 0);
      e.mem[_t_9 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = _h_7;
    r1 = term_clo(FID_MAIN_C363, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C363)
  {
    Term _x_7 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C364, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C364)
  {
    Term _x_8 = r0;
    WL_OPEN
    Term _x_9 = term_pak(CID_UNIT, 0);
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_8 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _x_8;
      e.mem[_t_8 + 1] = _x_9;
      return term_tsk(FID_CLO_APPLY, _t_8);
    }
    r0 = _x_8;
    r1 = _x_9;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_1 = r0;
    Term _k_1 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _text_1;
    e.mem[_nd_1 + 1] = _k_1;
    r0 = term_ctr(CID_IO_PRINT, _nd_1);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
