
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_CHR 13
#define CID_HELD_ADAPTER_PROTOTYPEPACKEDMOTIONROWOWNER 14
#define CID_TYPES_FOUND 15
#define CID_TYPES_MISMATCH 16
#define CID_TYPES_MISSING 17
#define CID_TYPES_POSITIONVIEW 18
#define CID_TYPES_POSITIONTOKEN 19
#define CID_TYPES_MOTIONLEDGER 20
#define CID_TYPES_LEDGERVIEW 21
#define CID_STORAGE_HANDLE 22
#define CID_TYPES_MOTIONSCHEMA 23
#define CID_TRANSACTION_PROTOTYPEFLATMAIN 24
#define CID_TRANSACTION_PROTOTYPEFLATLEDGER 25
#define CID_TRANSACTION_PROTOTYPEFLATEND 26
#define CID_TRANSACTION_PROTOTYPEFLATMARK 27
#define CID_TRANSACTION_PROTOTYPEFLATMARKSEND 28
#define CID_TYPES_FOUR 29
#define CID_NIL 30
#define CID_CON 31
#define CID_IO_PRINT 32
#define FID_U32_SHOW_GO 0
#define FID_HOST_RENDER_RENDER_FOUR 1
#define FID_HOST_RENDER_RENDER_FOUR_K15 2
#define FID_HOST_RENDER_RENDER_FOUR_K16 3
#define FID_HOST_RENDER_RENDER_FOUR_K17 4
#define FID_HOST_RENDER_RENDER_FOUR_K18 5
#define FID_ARRAY_TO_LIST_GO_0 6
#define FID_ARRAY_TO_LIST_GO_0_K20 7
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16 8
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16_K22 9
#define FID_HOST_RENDER_RENDER_LEDGER 10
#define FID_HOST_RENDER_RENDER_LEDGER_K27 11
#define FID_HOST_RENDER_RENDER_LEDGER_K28 12
#define FID_HOST_RENDER_RENDER_POSITION 13
#define FID_HOST_RENDER_RENDER_POSITION_K30 14
#define FID_HOST_RENDER_RENDER_POSITION_K31 15
#define FID_ARRAY_TO_LIST_0 16
#define FID_DATA 17
#define FID_DATA_K34 18
#define FID_HOST_RENDER_RENDER_LIST_16 19
#define FID_HOST_RENDER_RENDER_LIST_16_K36 20
#define FID_U32_SHOW 21
#define FID_STRING_APPEND 22
#define FID_STRING_APPEND_K39 23
#define FID_RUN 24
#define FID_RUN_K180 25
#define FID_RUN_K181 26
#define FID_RUN_K182 27
#define FID_RUN_K183 28
#define FID_RUN_K184 29
#define FID_RUN_K185 30
#define FID_RUN_K186 31
#define FID_RUN_K187 32
#define FID_RUN_K188 33
#define FID_RUN_K189 34
#define FID_RUN_K190 35
#define FID_RUN_K191 36
#define FID_RUN_K192 37
#define FID_RUN_K193 38
#define FID_RUN_K194 39
#define FID_RUN_K195 40
#define FID_RUN_K196 41
#define FID_RUN_K197 42
#define FID_RUN_K198 43
#define FID_RUN_K199 44
#define FID_RUN_K200 45
#define FID_RUN_K201 46
#define FID_RUN_K202 47
#define FID_RUN_K203 48
#define FID_RUN_K204 49
#define FID_RUN_K205 50
#define FID_RUN_K206 51
#define FID_RUN_K207 52
#define FID_RUN_K208 53
#define FID_RUN_K209 54
#define FID_RUN_K210 55
#define FID_RUN_K211 56
#define FID_RUN_K212 57
#define FID_RUN_K213 58
#define FID_RUN_K214 59
#define FID_RUN_K215 60
#define FID_RUN_K216 61
#define FID_RUN_K217 62
#define FID_RUN_K218 63
#define FID_RUN_K219 64
#define FID_RUN_K220 65
#define FID_RUN_K221 66
#define FID_RUN_K222 67
#define FID_RUN_K223 68
#define FID_RUN_K224 69
#define FID_RUN_K225 70
#define FID_RUN_K226 71
#define FID_RUN_K227 72
#define FID_RUN_K228 73
#define FID_RUN_K229 74
#define FID_RUN_K230 75
#define FID_RUN_K231 76
#define FID_RUN_K232 77
#define FID_RUN_K233 78
#define FID_RUN_K234 79
#define FID_RUN_K235 80
#define FID_RUN_K236 81
#define FID_RUN_K237 82
#define FID_RUN_K238 83
#define FID_RUN_K239 84
#define FID_RUN_K240 85
#define FID_RUN_K241 86
#define FID_RUN_K242 87
#define FID_RUN_K243 88
#define FID_RUN_K244 89
#define FID_RUN_K245 90
#define FID_RUN_K246 91
#define FID_IO_BIND 92
#define FID_IO_BIND_C248 93
#define FID_IO_BIND_K249 94
#define FID_MAIN 95
#define FID_MAIN_K251 96
#define FID_MAIN_C252 97
#define FID_MAIN_C253 98
#define FID_MAIN_K254 99
#define FID_MAIN_C255 100
#define FID_MAIN_C256 101
#define FID_MAIN_K257 102
#define FID_MAIN_C258 103
#define FID_MAIN_C259 104
#define FID_MAIN_K260 105
#define FID_MAIN_C261 106
#define FID_MAIN_C262 107
#define FID_MAIN_C263 108
#define FID_IO_PRINT 109
#define FID_IO_EMIT 110
#define FID_CLO_APPLY 111
#define FID_EXIT 112
#define FID_ENTER 113
CONSTV u8 FID_T[][3] = { { 3, 0, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 29, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 17, 1, 2 }, { 17, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 0 }, { 2, 0 }, { 2, 0 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 1, 0 }, { 18, 0 }, { 1, 0 }, { 0, 0 }, { 0, 0 }, { 5, 0 }, { 0, 0 }, { 2, 0 }, { 5, 0 }, { 2, 0 }, { 0, 0 }, { 4, 0 }, { 2, 0 }, { 0, 0 }, { 3, 0 }, { 0, 0 }, { 4, 0 }, { 0, 0 }, { 2, 0 }, { 2, 0 } };
#define STAT_LEN 368

#define WL_RESW 1
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0;

#define WL_TAKE(V) r0 = (V)[0];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4

#define WL_TABLE WL_X(FID_U32_SHOW_GO) WL_X(FID_HOST_RENDER_RENDER_FOUR) WL_X(FID_HOST_RENDER_RENDER_FOUR_K15) WL_X(FID_HOST_RENDER_RENDER_FOUR_K16) WL_X(FID_HOST_RENDER_RENDER_FOUR_K17) WL_X(FID_HOST_RENDER_RENDER_FOUR_K18) WL_X(FID_ARRAY_TO_LIST_GO_0) WL_X(FID_ARRAY_TO_LIST_GO_0_K20) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K22) WL_X(FID_HOST_RENDER_RENDER_LEDGER) WL_X(FID_HOST_RENDER_RENDER_LEDGER_K27) WL_X(FID_HOST_RENDER_RENDER_LEDGER_K28) WL_X(FID_HOST_RENDER_RENDER_POSITION) WL_X(FID_HOST_RENDER_RENDER_POSITION_K30) WL_X(FID_HOST_RENDER_RENDER_POSITION_K31) WL_X(FID_ARRAY_TO_LIST_0) WL_X(FID_DATA) WL_X(FID_DATA_K34) WL_X(FID_HOST_RENDER_RENDER_LIST_16) WL_X(FID_HOST_RENDER_RENDER_LIST_16_K36) WL_X(FID_U32_SHOW) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K39) WL_X(FID_RUN) WL_X(FID_RUN_K180) WL_X(FID_RUN_K181) WL_X(FID_RUN_K182) WL_X(FID_RUN_K183) WL_X(FID_RUN_K184) WL_X(FID_RUN_K185) WL_X(FID_RUN_K186) WL_X(FID_RUN_K187) WL_X(FID_RUN_K188) WL_X(FID_RUN_K189) WL_X(FID_RUN_K190) WL_X(FID_RUN_K191) WL_X(FID_RUN_K192) WL_X(FID_RUN_K193) WL_X(FID_RUN_K194) WL_X(FID_RUN_K195) WL_X(FID_RUN_K196) WL_X(FID_RUN_K197) WL_X(FID_RUN_K198) WL_X(FID_RUN_K199) WL_X(FID_RUN_K200) WL_X(FID_RUN_K201) WL_X(FID_RUN_K202) WL_X(FID_RUN_K203) WL_X(FID_RUN_K204) WL_X(FID_RUN_K205) WL_X(FID_RUN_K206) WL_X(FID_RUN_K207) WL_X(FID_RUN_K208) WL_X(FID_RUN_K209) WL_X(FID_RUN_K210) WL_X(FID_RUN_K211) WL_X(FID_RUN_K212) WL_X(FID_RUN_K213) WL_X(FID_RUN_K214) WL_X(FID_RUN_K215) WL_X(FID_RUN_K216) WL_X(FID_RUN_K217) WL_X(FID_RUN_K218) WL_X(FID_RUN_K219) WL_X(FID_RUN_K220) WL_X(FID_RUN_K221) WL_X(FID_RUN_K222) WL_X(FID_RUN_K223) WL_X(FID_RUN_K224) WL_X(FID_RUN_K225) WL_X(FID_RUN_K226) WL_X(FID_RUN_K227) WL_X(FID_RUN_K228) WL_X(FID_RUN_K229) WL_X(FID_RUN_K230) WL_X(FID_RUN_K231) WL_X(FID_RUN_K232) WL_X(FID_RUN_K233) WL_X(FID_RUN_K234) WL_X(FID_RUN_K235) WL_X(FID_RUN_K236) WL_X(FID_RUN_K237) WL_X(FID_RUN_K238) WL_X(FID_RUN_K239) WL_X(FID_RUN_K240) WL_X(FID_RUN_K241) WL_X(FID_RUN_K242) WL_X(FID_RUN_K243) WL_X(FID_RUN_K244) WL_X(FID_RUN_K245) WL_X(FID_RUN_K246) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C248) WL_X(FID_IO_BIND_K249) WL_X(FID_MAIN) WL_X(FID_MAIN_K251) WL_X(FID_MAIN_C252) WL_X(FID_MAIN_C253) WL_X(FID_MAIN_K254) WL_X(FID_MAIN_C255) WL_X(FID_MAIN_C256) WL_X(FID_MAIN_K257) WL_X(FID_MAIN_C258) WL_X(FID_MAIN_C259) WL_X(FID_MAIN_K260) WL_X(FID_MAIN_C261) WL_X(FID_MAIN_C262) WL_X(FID_MAIN_C263) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 0

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 44ull, term_pak(CID_SNIL, 0), 58ull, term_pak(CID_SNIL, 0), 34ull, term_ctr(CID_SCON, STAT_OFF + 2), 97ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 6), 123ull, term_ctr(CID_SCON, STAT_OFF + 8), 98ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 12), 44ull, term_ctr(CID_SCON, STAT_OFF + 14), 99ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 18), 44ull, term_ctr(CID_SCON, STAT_OFF + 20), 100ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 24), 44ull, term_ctr(CID_SCON, STAT_OFF + 26), 125ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 30), term_pak(CID_NIL, 0), 48ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 4), 108ull, term_ctr(CID_SCON, STAT_OFF + 36), 97ull, term_ctr(CID_SCON, STAT_OFF + 38), 116ull, term_ctr(CID_SCON, STAT_OFF + 40), 111ull, term_ctr(CID_SCON, STAT_OFF + 42), 116ull, term_ctr(CID_SCON, STAT_OFF + 44), 34ull, term_ctr(CID_SCON, STAT_OFF + 46), 123ull, term_ctr(CID_SCON, STAT_OFF + 48), 104ull, term_ctr(CID_SCON, STAT_OFF + 4), 99ull, term_ctr(CID_SCON, STAT_OFF + 52), 111ull, term_ctr(CID_SCON, STAT_OFF + 54), 112ull, term_ctr(CID_SCON, STAT_OFF + 56), 101ull, term_ctr(CID_SCON, STAT_OFF + 58), 34ull, term_ctr(CID_SCON, STAT_OFF + 60), 44ull, term_ctr(CID_SCON, STAT_OFF + 62), 101ull, term_ctr(CID_SCON, STAT_OFF + 36), 116ull, term_ctr(CID_SCON, STAT_OFF + 66), 97ull, term_ctr(CID_SCON, STAT_OFF + 68), 110ull, term_ctr(CID_SCON, STAT_OFF + 70), 105ull, term_ctr(CID_SCON, STAT_OFF + 72), 100ull, term_ctr(CID_SCON, STAT_OFF + 74), 114ull, term_ctr(CID_SCON, STAT_OFF + 76), 111ull, term_ctr(CID_SCON, STAT_OFF + 78), 111ull, term_ctr(CID_SCON, STAT_OFF + 80), 99ull, term_ctr(CID_SCON, STAT_OFF + 82), 34ull, term_ctr(CID_SCON, STAT_OFF + 84), 123ull, term_ctr(CID_SCON, STAT_OFF + 86), 101ull, term_ctr(CID_SCON, STAT_OFF + 4), 109ull, term_ctr(CID_SCON, STAT_OFF + 90), 97ull, term_ctr(CID_SCON, STAT_OFF + 92), 114ull, term_ctr(CID_SCON, STAT_OFF + 94), 102ull, term_ctr(CID_SCON, STAT_OFF + 96), 34ull, term_ctr(CID_SCON, STAT_OFF + 98), 44ull, term_ctr(CID_SCON, STAT_OFF + 100), 91ull, term_pak(CID_SNIL, 0), 93ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 106), term_pak(CID_NIL, 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 90), 108ull, term_ctr(CID_SCON, STAT_OFF + 110), 97ull, term_ctr(CID_SCON, STAT_OFF + 112), 86ull, term_ctr(CID_SCON, STAT_OFF + 114), 116ull, term_ctr(CID_SCON, STAT_OFF + 116), 110ull, term_ctr(CID_SCON, STAT_OFF + 118), 101ull, term_ctr(CID_SCON, STAT_OFF + 120), 105ull, term_ctr(CID_SCON, STAT_OFF + 122), 108ull, term_ctr(CID_SCON, STAT_OFF + 124), 99ull, term_ctr(CID_SCON, STAT_OFF + 126), 34ull, term_ctr(CID_SCON, STAT_OFF + 128), 44ull, term_ctr(CID_SCON, STAT_OFF + 130), 93ull, term_ctr(CID_SCON, STAT_OFF + 132), 93ull, term_ctr(CID_SCON, STAT_OFF + 134), 44ull, term_ctr(CID_SCON, STAT_OFF + 104), 93ull, term_ctr(CID_SCON, STAT_OFF + 138), 91ull, term_ctr(CID_SCON, STAT_OFF + 104), 58ull, term_ctr(CID_SCON, STAT_OFF + 142), 34ull, term_ctr(CID_SCON, STAT_OFF + 144), 115ull, term_ctr(CID_SCON, STAT_OFF + 146), 107ull, term_ctr(CID_SCON, STAT_OFF + 148), 114ull, term_ctr(CID_SCON, STAT_OFF + 150), 97ull, term_ctr(CID_SCON, STAT_OFF + 152), 109ull, term_ctr(CID_SCON, STAT_OFF + 154), 34ull, term_ctr(CID_SCON, STAT_OFF + 156), 44ull, term_ctr(CID_SCON, STAT_OFF + 158), 93ull, term_ctr(CID_SCON, STAT_OFF + 160), 93ull, term_ctr(CID_SCON, STAT_OFF + 162), 101ull, term_ctr(CID_SCON, STAT_OFF + 146), 115ull, term_ctr(CID_SCON, STAT_OFF + 166), 114ull, term_ctr(CID_SCON, STAT_OFF + 168), 101ull, term_ctr(CID_SCON, STAT_OFF + 170), 118ull, term_ctr(CID_SCON, STAT_OFF + 172), 110ull, term_ctr(CID_SCON, STAT_OFF + 174), 105ull, term_ctr(CID_SCON, STAT_OFF + 176), 34ull, term_ctr(CID_SCON, STAT_OFF + 178), 44ull, term_ctr(CID_SCON, STAT_OFF + 180), 93ull, term_ctr(CID_SCON, STAT_OFF + 182), 58ull, term_ctr(CID_SCON, STAT_OFF + 104), 34ull, term_ctr(CID_SCON, STAT_OFF + 186), 101ull, term_ctr(CID_SCON, STAT_OFF + 188), 108ull, term_ctr(CID_SCON, STAT_OFF + 190), 100ull, term_ctr(CID_SCON, STAT_OFF + 192), 110ull, term_ctr(CID_SCON, STAT_OFF + 194), 97ull, term_ctr(CID_SCON, STAT_OFF + 196), 104ull, term_ctr(CID_SCON, STAT_OFF + 198), 34ull, term_ctr(CID_SCON, STAT_OFF + 200), 44ull, term_ctr(CID_SCON, STAT_OFF + 202), 101ull, term_ctr(CID_SCON, STAT_OFF + 24), 104ull, term_ctr(CID_SCON, STAT_OFF + 206), 99ull, term_ctr(CID_SCON, STAT_OFF + 208), 97ull, term_ctr(CID_SCON, STAT_OFF + 210), 67ull, term_ctr(CID_SCON, STAT_OFF + 212), 114ull, term_ctr(CID_SCON, STAT_OFF + 214), 101ull, term_ctr(CID_SCON, STAT_OFF + 216), 103ull, term_ctr(CID_SCON, STAT_OFF + 218), 100ull, term_ctr(CID_SCON, STAT_OFF + 220), 101ull, term_ctr(CID_SCON, STAT_OFF + 222), 108ull, term_ctr(CID_SCON, STAT_OFF + 224), 34ull, term_ctr(CID_SCON, STAT_OFF + 226), 44ull, term_ctr(CID_SCON, STAT_OFF + 228), 114ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 232), 103ull, term_ctr(CID_SCON, STAT_OFF + 234), 100ull, term_ctr(CID_SCON, STAT_OFF + 236), 101ull, term_ctr(CID_SCON, STAT_OFF + 238), 108ull, term_ctr(CID_SCON, STAT_OFF + 240), 34ull, term_ctr(CID_SCON, STAT_OFF + 242), 44ull, term_ctr(CID_SCON, STAT_OFF + 244), 110ull, term_ctr(CID_SCON, STAT_OFF + 206), 105ull, term_ctr(CID_SCON, STAT_OFF + 248), 97ull, term_ctr(CID_SCON, STAT_OFF + 250), 116ull, term_ctr(CID_SCON, STAT_OFF + 252), 101ull, term_ctr(CID_SCON, STAT_OFF + 254), 114ull, term_ctr(CID_SCON, STAT_OFF + 256), 34ull, term_ctr(CID_SCON, STAT_OFF + 258), 44ull, term_ctr(CID_SCON, STAT_OFF + 260), 99ull, term_ctr(CID_SCON, STAT_OFF + 212), 34ull, term_ctr(CID_SCON, STAT_OFF + 264), 44ull, term_ctr(CID_SCON, STAT_OFF + 266), 70ull, term_ctr(CID_SCON, STAT_OFF + 96), 119ull, term_ctr(CID_SCON, STAT_OFF + 270), 97ull, term_ctr(CID_SCON, STAT_OFF + 272), 114ull, term_ctr(CID_SCON, STAT_OFF + 274), 34ull, term_ctr(CID_SCON, STAT_OFF + 276), 44ull, term_ctr(CID_SCON, STAT_OFF + 278), 121ull, term_ctr(CID_SCON, STAT_OFF + 4), 97ull, term_ctr(CID_SCON, STAT_OFF + 282), 114ull, term_ctr(CID_SCON, STAT_OFF + 284), 114ull, term_ctr(CID_SCON, STAT_OFF + 286), 97ull, term_ctr(CID_SCON, STAT_OFF + 288), 34ull, term_ctr(CID_SCON, STAT_OFF + 290), 44ull, term_ctr(CID_SCON, STAT_OFF + 292), 116ull, term_ctr(CID_SCON, STAT_OFF + 52), 103ull, term_ctr(CID_SCON, STAT_OFF + 296), 110ull, term_ctr(CID_SCON, STAT_OFF + 298), 101ull, term_ctr(CID_SCON, STAT_OFF + 300), 108ull, term_ctr(CID_SCON, STAT_OFF + 302), 34ull, term_ctr(CID_SCON, STAT_OFF + 304), 123ull, term_ctr(CID_SCON, STAT_OFF + 306), 119ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 310), 114ull, term_ctr(CID_SCON, STAT_OFF + 312), 45ull, term_ctr(CID_SCON, STAT_OFF + 314), 100ull, term_ctr(CID_SCON, STAT_OFF + 316), 101ull, term_ctr(CID_SCON, STAT_OFF + 318), 116ull, term_ctr(CID_SCON, STAT_OFF + 320), 99ull, term_ctr(CID_SCON, STAT_OFF + 322), 101ull, term_ctr(CID_SCON, STAT_OFF + 324), 112ull, term_ctr(CID_SCON, STAT_OFF + 326), 120ull, term_ctr(CID_SCON, STAT_OFF + 328), 101ull, term_ctr(CID_SCON, STAT_OFF + 330), 110ull, term_ctr(CID_SCON, STAT_OFF + 332), 117ull, term_ctr(CID_SCON, STAT_OFF + 334), 100ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 338), 101ull, term_ctr(CID_SCON, STAT_OFF + 340), 114ull, term_ctr(CID_SCON, STAT_OFF + 342), 45ull, term_ctr(CID_SCON, STAT_OFF + 344), 100ull, term_ctr(CID_SCON, STAT_OFF + 346), 101ull, term_ctr(CID_SCON, STAT_OFF + 348), 116ull, term_ctr(CID_SCON, STAT_OFF + 350), 99ull, term_ctr(CID_SCON, STAT_OFF + 352), 101ull, term_ctr(CID_SCON, STAT_OFF + 354), 112ull, term_ctr(CID_SCON, STAT_OFF + 356), 120ull, term_ctr(CID_SCON, STAT_OFF + 358), 101ull, term_ctr(CID_SCON, STAT_OFF + 360), 110ull, term_ctr(CID_SCON, STAT_OFF + 362), 117ull, term_ctr(CID_SCON, STAT_OFF + 364) };

INLINE Term spin_0(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _s_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_s_1) == CID_SNIL) {
      _v_1 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _s_1, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = _f_1;
      r1 = term_ctr(CID_SCON, _nd_0);
      _s_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_0);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _view_0 = r0;
  u32 _view_1 = r1;
  u32 _view_2 = r2;
  u32 _view_3 = r3;
  u32 _view_4 = r4;
  WL_SPIN
    _v_2 = U32_BIN(U32_BIN(_view_0, +, _view_1), +, U32_BIN(U32_BIN(_view_2, +, _view_3), +, _view_4));
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_1 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_2);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _s_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    if (spin_0(e, _o_0, _s_0, term_pak(CID_SNIL, 0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_5 = 0;
  Term _value_0 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_value_0) == CID_SNIL) {
      _v_5 = _acc_1;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _value_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_0 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_2;
      e.mem[_nd_0 + 1] = _acc_1;
      r0 = _f_3;
      r1 = term_ctr(CID_SCON, _nd_0);
      _value_0 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_4);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, Term r15, u32 r16, Term r17, u32 r18) {
  u32 wpoll = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _rawframe_0 = r0;
  u32 _b_0 = r1;
  u32 _c_1 = r2;
  u32 _d_0 = r3;
  u32 _cachedframe_0 = r4;
  Term _ledger_raw_0 = r5;
  u32 _ledger_raw_1 = r6;
  u32 _ledger_cached_0 = r7;
  u32 _ledger_cached_1 = r8;
  u32 _ledger_cached_2 = r9;
  u32 _ledger_cached_3 = r10;
  u32 _ledger_cached_4 = r11;
  u32 _handle_0 = r12;
  u32 _handle_1 = r13;
  Term _undo_0 = r14;
  Term _marks_0 = r15;
  u32 _value_1 = r16;
  Term _result_0 = r17;
  u32 _result_1 = r18;
  WL_SPIN
    Term _at_2 = blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 0ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _value_1);
    Term _at_4 = blk_loc(e.mem, _result_0);
    Term _at_5 = blk_at(_result_0, 1ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, 9999ull);
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = _handle_0;
    e.mem[_nd_0 + 1] = _handle_1;
    e.mem[_nd_0 + 2] = _result_1;
    e.mem[_nd_0 + 3] = _undo_0;
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = _handle_0;
    e.mem[_nd_1 + 1] = _handle_1;
    e.mem[_nd_1 + 2] = _marks_0;
    _v_18 = _result_0;
    _v_19 = _rawframe_0;
    _v_20 = _value_1;
    _v_21 = _b_0;
    _v_22 = _c_1;
    _v_23 = _d_0;
    _v_24 = _cachedframe_0;
    _v_25 = _ledger_raw_0;
    _v_26 = _ledger_raw_1;
    _v_27 = _ledger_cached_0;
    _v_28 = _ledger_cached_1;
    _v_29 = _ledger_cached_2;
    _v_30 = _ledger_cached_3;
    _v_31 = _ledger_cached_4;
    _v_32 = _handle_0;
    _v_33 = _handle_1;
    _v_34 = term_ctr(CID_TRANSACTION_PROTOTYPEFLATMAIN, _nd_0);
    _v_35 = term_ctr(CID_TRANSACTION_PROTOTYPEFLATMARK, _nd_1);
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  o[9] = _v_27;
  o[10] = _v_28;
  o[11] = _v_29;
  o[12] = _v_30;
  o[13] = _v_31;
  o[14] = _v_32;
  o[15] = _v_33;
  o[16] = _v_34;
  o[17] = _v_35;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  Term _owner_7 = r7;
  u32 _owner_8 = r8;
  u32 _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  Term _owner_16 = r16;
  Term _owner_17 = r17;
  u32 _result_24 = r18;
  u32 _result_25 = r19;
  u32 _result_26 = r20;
  u32 _result_27 = r21;
  u32 _result_28 = r22;
  u32 _result_29 = r23;
  WL_SPIN
    if (_result_24 == 0) {
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      Term _o_0[1];
      if (spin_1(e, _o_0, _result_25, _result_26, _result_27, _result_28, _result_29) == 0) {
        return 0;
      }
      _v_39 = _o_0[0];
      _v_38 = _v_39;
      _v_19 = _owner_0;
      _v_20 = _owner_1;
      _v_21 = _owner_2;
      _v_22 = _owner_3;
      _v_23 = _owner_4;
      _v_24 = _owner_5;
      _v_25 = _owner_6;
      _v_26 = _owner_7;
      _v_27 = _owner_8;
      _v_28 = _owner_9;
      _v_29 = _owner_10;
      _v_30 = _owner_11;
      _v_31 = _owner_12;
      _v_32 = _owner_13;
      _v_33 = _owner_14;
      _v_34 = _owner_15;
      _v_35 = _owner_16;
      _v_36 = _owner_17;
      _v_37 = _v_38;
    } else {
      _v_19 = _owner_0;
      _v_20 = _owner_1;
      _v_21 = _owner_2;
      _v_22 = _owner_3;
      _v_23 = _owner_4;
      _v_24 = _owner_5;
      _v_25 = _owner_6;
      _v_26 = _owner_7;
      _v_27 = _owner_8;
      _v_28 = _owner_9;
      _v_29 = _owner_10;
      _v_30 = _owner_11;
      _v_31 = _owner_12;
      _v_32 = _owner_13;
      _v_33 = _owner_14;
      _v_34 = _owner_15;
      _v_35 = _owner_16;
      _v_36 = _owner_17;
      _v_37 = 0ull;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_3 = 0;
  Term _values_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_values_1) == CID_NIL) {
      Term _v_4 = 0;
      Term _o_0[1];
      if (spin_3(e, _o_0, _acc_0) == 0) {
        return 0;
      }
      _v_4 = _o_0[0];
      _v_3 = _v_4;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _o_1[1];
      if (spin_4(e, _o_1, _f_0, _acc_0) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_5 = _v_6;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_5;
      _values_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_8);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _values_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_2[1];
    if (spin_8(e, _o_2, _values_0, term_pak(CID_SNIL, 0)) == 0) {
      return 0;
    }
    _v_2 = _o_2[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    if (spin_2(e, _o_0, _xs_0, term_pak(CID_NIL, 0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, Term r1, u32 r2) {
  u32 wpoll = 0;
  Term _v_5 = 0;
  Term _value_0 = r0;
  Term _acc_2 = r1;
  u32 _first_2 = r2;
  WL_SPIN
    if (_first_2 == 1) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _value_0;
      e.mem[_nd_0 + 1] = _acc_2;
      _v_5 = term_ctr(CID_CON, _nd_0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_nd_1 + 1] = _acc_2;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = _value_0;
      e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
      _v_5 = term_ctr(CID_CON, _nd_2);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17, u32 r18) {
  u32 wpoll = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  u32 _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  Term _v_94 = 0;
  Term _v_95 = 0;
  Term _owner_18 = r0;
  u32 _owner_19 = r1;
  u32 _owner_20 = r2;
  u32 _owner_21 = r3;
  u32 _owner_22 = r4;
  u32 _owner_23 = r5;
  u32 _owner_24 = r6;
  Term _owner_25 = r7;
  u32 _owner_26 = r8;
  u32 _owner_27 = r9;
  u32 _owner_28 = r10;
  u32 _owner_29 = r11;
  u32 _owner_30 = r12;
  u32 _owner_31 = r13;
  u32 _owner_32 = r14;
  u32 _owner_33 = r15;
  Term _owner_34 = r16;
  Term _owner_35 = r17;
  u32 _value_0 = r18;
  WL_SPIN
    Term _at_0 = blk_loc(e.mem, _owner_18);
    Term _at_1 = blk_at(_owner_18, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    Term _o_0[18];
    if (spin_5(e, _o_0, _owner_19, _owner_21, _owner_22, _owner_23, _owner_24, _owner_25, _owner_26, _owner_27, _owner_28, _owner_29, _owner_30, _owner_31, _owner_32, _owner_33, _owner_34, _owner_35, _value_0, _owner_18, _c_0) == 0) {
      return 0;
    }
    _v_96 = _o_0[0];
    _v_97 = _o_0[1];
    _v_98 = _o_0[2];
    _v_99 = _o_0[3];
    _v_100 = _o_0[4];
    _v_101 = _o_0[5];
    _v_102 = _o_0[6];
    _v_103 = _o_0[7];
    _v_104 = _o_0[8];
    _v_105 = _o_0[9];
    _v_106 = _o_0[10];
    _v_107 = _o_0[11];
    _v_108 = _o_0[12];
    _v_109 = _o_0[13];
    _v_110 = _o_0[14];
    _v_111 = _o_0[15];
    _v_112 = _o_0[16];
    _v_113 = _o_0[17];
    _v_78 = _v_96;
    _v_79 = _v_97;
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    _v_89 = _v_107;
    _v_90 = _v_108;
    _v_91 = _v_109;
    _v_92 = _v_110;
    _v_93 = _v_111;
    _v_94 = _v_112;
    _v_95 = _v_113;
  break;
  }
  o[0] = _v_78;
  o[1] = _v_79;
  o[2] = _v_80;
  o[3] = _v_81;
  o[4] = _v_82;
  o[5] = _v_83;
  o[6] = _v_84;
  o[7] = _v_85;
  o[8] = _v_86;
  o[9] = _v_87;
  o[10] = _v_88;
  o[11] = _v_89;
  o[12] = _v_90;
  o[13] = _v_91;
  o[14] = _v_92;
  o[15] = _v_93;
  o[16] = _v_94;
  o[17] = _v_95;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  u32 _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  u32 _v_162 = 0;
  Term _v_163 = 0;
  u32 _v_164 = 0;
  u32 _v_165 = 0;
  u32 _v_166 = 0;
  u32 _v_167 = 0;
  u32 _v_168 = 0;
  u32 _v_169 = 0;
  u32 _v_170 = 0;
  u32 _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  u32 _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  u32 _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  Term _owner_36 = r0;
  u32 _owner_37 = r1;
  u32 _owner_38 = r2;
  u32 _owner_39 = r3;
  u32 _owner_40 = r4;
  u32 _owner_41 = r5;
  u32 _owner_42 = r6;
  Term _owner_43 = r7;
  u32 _owner_44 = r8;
  u32 _owner_45 = r9;
  u32 _owner_46 = r10;
  u32 _owner_47 = r11;
  u32 _owner_48 = r12;
  u32 _owner_49 = r13;
  u32 _owner_50 = r14;
  u32 _owner_51 = r15;
  Term _owner_52 = r16;
  Term _owner_53 = r17;
  WL_SPIN
    _v_156 = _owner_36;
    _v_157 = _owner_37;
    _v_158 = _owner_38;
    _v_159 = _owner_39;
    _v_160 = _owner_40;
    _v_161 = _owner_41;
    _v_162 = _owner_42;
    _v_163 = _owner_43;
    _v_164 = _owner_44;
    _v_165 = _owner_45;
    _v_166 = _owner_46;
    _v_167 = _owner_47;
    _v_168 = _owner_48;
    _v_169 = _owner_49;
    _v_170 = _owner_50;
    _v_171 = _owner_51;
    _v_172 = _owner_52;
    _v_173 = _owner_53;
    _v_174 = 0;
    _v_175 = _owner_38;
    _v_176 = _owner_39;
    _v_177 = _owner_40;
    _v_178 = _owner_41;
    _v_179 = _owner_42;
  break;
  }
  o[0] = _v_156;
  o[1] = _v_157;
  o[2] = _v_158;
  o[3] = _v_159;
  o[4] = _v_160;
  o[5] = _v_161;
  o[6] = _v_162;
  o[7] = _v_163;
  o[8] = _v_164;
  o[9] = _v_165;
  o[10] = _v_166;
  o[11] = _v_167;
  o[12] = _v_168;
  o[13] = _v_169;
  o[14] = _v_170;
  o[15] = _v_171;
  o[16] = _v_172;
  o[17] = _v_173;
  o[18] = _v_174;
  o[19] = _v_175;
  o[20] = _v_176;
  o[21] = _v_177;
  o[22] = _v_178;
  o[23] = _v_179;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term _v_199 = 0;
  u32 _v_200 = 0;
  u32 _v_201 = 0;
  u32 _v_202 = 0;
  u32 _v_203 = 0;
  u32 _v_204 = 0;
  u32 _v_205 = 0;
  Term _v_206 = 0;
  u32 _v_207 = 0;
  u32 _v_208 = 0;
  u32 _v_209 = 0;
  u32 _v_210 = 0;
  u32 _v_211 = 0;
  u32 _v_212 = 0;
  u32 _v_213 = 0;
  u32 _v_214 = 0;
  Term _v_215 = 0;
  Term _v_216 = 0;
  u32 _v_217 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  u32 _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  u32 _result_14 = r14;
  u32 _result_15 = r15;
  Term _result_16 = r16;
  Term _result_17 = r17;
  u32 _result_18 = r18;
  u32 _result_19 = r19;
  u32 _result_20 = r20;
  u32 _result_21 = r21;
  u32 _result_22 = r22;
  u32 _result_23 = r23;
  WL_SPIN
    Term _v_218 = 0;
    u32 _v_219 = 0;
    u32 _v_220 = 0;
    u32 _v_221 = 0;
    u32 _v_222 = 0;
    u32 _v_223 = 0;
    u32 _v_224 = 0;
    Term _v_225 = 0;
    u32 _v_226 = 0;
    u32 _v_227 = 0;
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    u32 _v_230 = 0;
    u32 _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    Term _v_234 = 0;
    Term _v_235 = 0;
    u32 _v_236 = 0;
    Term _o_4[19];
    if (spin_6(e, _o_4, _result_0, _result_1, _result_2, _result_3, _result_4, _result_5, _result_6, _result_7, _result_8, _result_9, _result_10, _result_11, _result_12, _result_13, _result_14, _result_15, _result_16, _result_17, _result_18, _result_19, _result_20, _result_21, _result_22, _result_23) == 0) {
      return 0;
    }
    _v_218 = _o_4[0];
    _v_219 = _o_4[1];
    _v_220 = _o_4[2];
    _v_221 = _o_4[3];
    _v_222 = _o_4[4];
    _v_223 = _o_4[5];
    _v_224 = _o_4[6];
    _v_225 = _o_4[7];
    _v_226 = _o_4[8];
    _v_227 = _o_4[9];
    _v_228 = _o_4[10];
    _v_229 = _o_4[11];
    _v_230 = _o_4[12];
    _v_231 = _o_4[13];
    _v_232 = _o_4[14];
    _v_233 = _o_4[15];
    _v_234 = _o_4[16];
    _v_235 = _o_4[17];
    _v_236 = _o_4[18];
    _v_199 = _v_218;
    _v_200 = _v_219;
    _v_201 = _v_220;
    _v_202 = _v_221;
    _v_203 = _v_222;
    _v_204 = _v_223;
    _v_205 = _v_224;
    _v_206 = _v_225;
    _v_207 = _v_226;
    _v_208 = _v_227;
    _v_209 = _v_228;
    _v_210 = _v_229;
    _v_211 = _v_230;
    _v_212 = _v_231;
    _v_213 = _v_232;
    _v_214 = _v_233;
    _v_215 = _v_234;
    _v_216 = _v_235;
    _v_217 = _v_236;
  break;
  }
  o[0] = _v_199;
  o[1] = _v_200;
  o[2] = _v_201;
  o[3] = _v_202;
  o[4] = _v_203;
  o[5] = _v_204;
  o[6] = _v_205;
  o[7] = _v_206;
  o[8] = _v_207;
  o[9] = _v_208;
  o[10] = _v_209;
  o[11] = _v_210;
  o[12] = _v_211;
  o[13] = _v_212;
  o[14] = _v_213;
  o[15] = _v_214;
  o[16] = _v_215;
  o[17] = _v_216;
  o[18] = _v_217;
  return 1;
}

FAR Term spin_14(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _owner_18 = r0;
  u32 _owner_19 = r1;
  u32 _owner_20 = r2;
  u32 _owner_21 = r3;
  u32 _owner_22 = r4;
  u32 _owner_23 = r5;
  u32 _owner_24 = r6;
  Term _owner_25 = r7;
  u32 _owner_26 = r8;
  u32 _owner_27 = r9;
  u32 _owner_28 = r10;
  u32 _owner_29 = r11;
  u32 _owner_30 = r12;
  u32 _owner_31 = r13;
  u32 _owner_32 = r14;
  u32 _owner_33 = r15;
  Term _owner_34 = r16;
  Term _owner_35 = r17;
  WL_SPIN
    Term _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    Term _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    Term _o_0[18];
    if (spin_11(e, _o_0, _owner_18, _owner_19, _owner_20, _owner_21, _owner_22, _owner_23, _owner_24, _owner_25, _owner_26, _owner_27, _owner_28, _owner_29, _owner_30, _owner_31, _owner_32, _owner_33, _owner_34, _owner_35, 500ull) == 0) {
      return 0;
    }
    _v_98 = _o_0[0];
    _v_99 = _o_0[1];
    _v_100 = _o_0[2];
    _v_101 = _o_0[3];
    _v_102 = _o_0[4];
    _v_103 = _o_0[5];
    _v_104 = _o_0[6];
    _v_105 = _o_0[7];
    _v_106 = _o_0[8];
    _v_107 = _o_0[9];
    _v_108 = _o_0[10];
    _v_109 = _o_0[11];
    _v_110 = _o_0[12];
    _v_111 = _o_0[13];
    _v_112 = _o_0[14];
    _v_113 = _o_0[15];
    _v_114 = _o_0[16];
    _v_115 = _o_0[17];
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    _v_89 = _v_107;
    _v_90 = _v_108;
    _v_91 = _v_109;
    _v_92 = _v_110;
    _v_93 = _v_111;
    _v_94 = _v_112;
    _v_95 = _v_113;
    _v_96 = _v_114;
    _v_97 = _v_115;
    Term _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    Term _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _o_1[18];
    if (spin_11(e, _o_1, _v_80, _v_81, _v_82, _v_83, _v_84, _v_85, _v_86, _v_87, _v_88, _v_89, _v_90, _v_91, _v_92, _v_93, _v_94, _v_95, _v_96, _v_97, 700ull) == 0) {
      return 0;
    }
    _v_116 = _o_1[0];
    _v_117 = _o_1[1];
    _v_118 = _o_1[2];
    _v_119 = _o_1[3];
    _v_120 = _o_1[4];
    _v_121 = _o_1[5];
    _v_122 = _o_1[6];
    _v_123 = _o_1[7];
    _v_124 = _o_1[8];
    _v_125 = _o_1[9];
    _v_126 = _o_1[10];
    _v_127 = _o_1[11];
    _v_128 = _o_1[12];
    _v_129 = _o_1[13];
    _v_130 = _o_1[14];
    _v_131 = _o_1[15];
    _v_132 = _o_1[16];
    _v_133 = _o_1[17];
    _v_62 = _v_116;
    _v_63 = _v_117;
    _v_64 = _v_118;
    _v_65 = _v_119;
    _v_66 = _v_120;
    _v_67 = _v_121;
    _v_68 = _v_122;
    _v_69 = _v_123;
    _v_70 = _v_124;
    _v_71 = _v_125;
    _v_72 = _v_126;
    _v_73 = _v_127;
    _v_74 = _v_128;
    _v_75 = _v_129;
    _v_76 = _v_130;
    _v_77 = _v_131;
    _v_78 = _v_132;
    _v_79 = _v_133;
    Term _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    Term _v_141 = 0;
    u32 _v_142 = 0;
    u32 _v_143 = 0;
    u32 _v_144 = 0;
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    Term _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    u32 _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    Term _o_2[24];
    if (spin_12(e, _o_2, _v_62, _v_63, _v_64, _v_65, _v_66, _v_67, _v_68, _v_69, _v_70, _v_71, _v_72, _v_73, _v_74, _v_75, _v_76, _v_77, _v_78, _v_79) == 0) {
      return 0;
    }
    _v_134 = _o_2[0];
    _v_135 = _o_2[1];
    _v_136 = _o_2[2];
    _v_137 = _o_2[3];
    _v_138 = _o_2[4];
    _v_139 = _o_2[5];
    _v_140 = _o_2[6];
    _v_141 = _o_2[7];
    _v_142 = _o_2[8];
    _v_143 = _o_2[9];
    _v_144 = _o_2[10];
    _v_145 = _o_2[11];
    _v_146 = _o_2[12];
    _v_147 = _o_2[13];
    _v_148 = _o_2[14];
    _v_149 = _o_2[15];
    _v_150 = _o_2[16];
    _v_151 = _o_2[17];
    _v_152 = _o_2[18];
    _v_153 = _o_2[19];
    _v_154 = _o_2[20];
    _v_155 = _o_2[21];
    _v_156 = _o_2[22];
    _v_157 = _o_2[23];
    _v_38 = _v_134;
    _v_39 = _v_135;
    _v_40 = _v_136;
    _v_41 = _v_137;
    _v_42 = _v_138;
    _v_43 = _v_139;
    _v_44 = _v_140;
    _v_45 = _v_141;
    _v_46 = _v_142;
    _v_47 = _v_143;
    _v_48 = _v_144;
    _v_49 = _v_145;
    _v_50 = _v_146;
    _v_51 = _v_147;
    _v_52 = _v_148;
    _v_53 = _v_149;
    _v_54 = _v_150;
    _v_55 = _v_151;
    _v_56 = _v_152;
    _v_57 = _v_153;
    _v_58 = _v_154;
    _v_59 = _v_155;
    _v_60 = _v_156;
    _v_61 = _v_157;
    Term _v_158 = 0;
    u32 _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    u32 _v_172 = 0;
    u32 _v_173 = 0;
    Term _v_174 = 0;
    Term _v_175 = 0;
    u32 _v_176 = 0;
    Term _o_3[19];
    if (spin_13(e, _o_3, _v_38, _v_39, _v_40, _v_41, _v_42, _v_43, _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_50, _v_51, _v_52, _v_53, _v_54, _v_55, _v_56, _v_57, _v_58, _v_59, _v_60, _v_61) == 0) {
      return 0;
    }
    _v_158 = _o_3[0];
    _v_159 = _o_3[1];
    _v_160 = _o_3[2];
    _v_161 = _o_3[3];
    _v_162 = _o_3[4];
    _v_163 = _o_3[5];
    _v_164 = _o_3[6];
    _v_165 = _o_3[7];
    _v_166 = _o_3[8];
    _v_167 = _o_3[9];
    _v_168 = _o_3[10];
    _v_169 = _o_3[11];
    _v_170 = _o_3[12];
    _v_171 = _o_3[13];
    _v_172 = _o_3[14];
    _v_173 = _o_3[15];
    _v_174 = _o_3[16];
    _v_175 = _o_3[17];
    _v_176 = _o_3[18];
    _v_19 = _v_158;
    _v_20 = _v_159;
    _v_21 = _v_160;
    _v_22 = _v_161;
    _v_23 = _v_162;
    _v_24 = _v_163;
    _v_25 = _v_164;
    _v_26 = _v_165;
    _v_27 = _v_166;
    _v_28 = _v_167;
    _v_29 = _v_168;
    _v_30 = _v_169;
    _v_31 = _v_170;
    _v_32 = _v_171;
    _v_33 = _v_172;
    _v_34 = _v_173;
    _v_35 = _v_174;
    _v_36 = _v_175;
    _v_37 = _v_176;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, Term r16, Term r17) {
  u32 wpoll = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  Term _owner_7 = r7;
  u32 _owner_8 = r8;
  u32 _owner_9 = r9;
  u32 _owner_10 = r10;
  u32 _owner_11 = r11;
  u32 _owner_12 = r12;
  u32 _owner_13 = r13;
  u32 _owner_14 = r14;
  u32 _owner_15 = r15;
  Term _owner_16 = r16;
  Term _owner_17 = r17;
  WL_SPIN
    Term _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _o_0[19];
    if (spin_14(e, _o_0, _owner_0, _owner_1, _owner_2, _owner_3, _owner_4, _owner_5, _owner_6, _owner_7, _owner_8, _owner_9, _owner_10, _owner_11, _owner_12, _owner_13, _owner_14, _owner_15, _owner_16, _owner_17) == 0) {
      return 0;
    }
    _v_57 = _o_0[0];
    _v_58 = _o_0[1];
    _v_59 = _o_0[2];
    _v_60 = _o_0[3];
    _v_61 = _o_0[4];
    _v_62 = _o_0[5];
    _v_63 = _o_0[6];
    _v_64 = _o_0[7];
    _v_65 = _o_0[8];
    _v_66 = _o_0[9];
    _v_67 = _o_0[10];
    _v_68 = _o_0[11];
    _v_69 = _o_0[12];
    _v_70 = _o_0[13];
    _v_71 = _o_0[14];
    _v_72 = _o_0[15];
    _v_73 = _o_0[16];
    _v_74 = _o_0[17];
    _v_75 = _o_0[18];
    _v_38 = _v_57;
    _v_39 = _v_58;
    _v_40 = _v_59;
    _v_41 = _v_60;
    _v_42 = _v_61;
    _v_43 = _v_62;
    _v_44 = _v_63;
    _v_45 = _v_64;
    _v_46 = _v_65;
    _v_47 = _v_66;
    _v_48 = _v_67;
    _v_49 = _v_68;
    _v_50 = _v_69;
    _v_51 = _v_70;
    _v_52 = _v_71;
    _v_53 = _v_72;
    _v_54 = _v_73;
    _v_55 = _v_74;
    _v_56 = _v_75;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1)));
        e.mem[_nd_0 + 1] = _acc_0;
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = _value_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K15;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K15, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      e.mem[_t_0 + 2] = _value_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K15, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K15)
  {
    WL_POPN(3);
    u32 _value_4 = STK(0);
    u32 _value_5 = STK(1);
    u32 _value_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_5;
      STK(1) = _value_6;
      STK(2) = _h_0;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K16;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K16, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_5;
      e.mem[_t_2 + 1] = _value_6;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K16, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K16)
  {
    WL_POPN(3);
    u32 _value_7 = STK(0);
    u32 _value_8 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_8;
      STK(1) = _h_2;
      STK(2) = _h_1;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K17;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K17, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_8;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K17, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_7;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _value_7;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K17)
  {
    WL_POPN(3);
    u32 _value_9 = STK(0);
    Term _h_4 = STK(1);
    Term _h_5 = STK(2);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K18;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K18, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K18, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_9;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _value_9;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K18)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_6;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 32);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _h_9;
    e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 22);
    e.mem[_nd_3 + 1] = term_ctr(CID_CON, _nd_2);
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = _h_8;
    e.mem[_nd_4 + 1] = term_ctr(CID_CON, _nd_3);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 16);
    e.mem[_nd_5 + 1] = term_ctr(CID_CON, _nd_4);
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = _h_7;
    e.mem[_nd_6 + 1] = term_ctr(CID_CON, _nd_5);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 10);
    e.mem[_nd_7 + 1] = term_ctr(CID_CON, _nd_6);
    Term _v_0 = 0;
    Term _o_3[1];
    if (spin_7(e, _o_3, term_ctr(CID_CON, _nd_7)) == 0) {
      return 0;
    }
    _v_0 = _o_3[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_GO_0)
  {
    Term _a_0 = r0;
    Term _acc_0 = r1;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_a_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _a_0), 0 + 0);
      blk_free(e, _a_0);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _c_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = term_ctr(CID_CON, _nd_0);
      WL_RETN(1);
    } else {
      Term _h_0 = blk_half(e, _a_0, 0);
      Term _h_1 = blk_half(e, _a_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_0;
        STK(1) = FID_ARRAY_TO_LIST_GO_0_K20;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_ARRAY_TO_LIST_GO_0_K20, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _h_0;
        WL_CONT = term_tsk(FID_ARRAY_TO_LIST_GO_0_K20, _t_0);
        WL_IDX = 1;
      }
      r0 = _h_1;
      r1 = _acc_0;
      _a_0 = r0;
      _acc_0 = r1;
      WL_AGAIN(FID_ARRAY_TO_LIST_GO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_GO_0_K20)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_GO_0)) {
      u64 _t_1 = task_node(e, FID_ARRAY_TO_LIST_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _h_3;
      e.mem[_t_1 + 1] = _h_2;
      return term_tsk(FID_ARRAY_TO_LIST_GO_0, _t_1);
    }
    r0 = _h_3;
    r1 = _h_2;
    WL_JMP(FID_ARRAY_TO_LIST_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_1[1];
      if (spin_9(e, _o_1, _acc_0) == 0) {
        return 0;
      }
      _v_0 = _o_1[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_16_K22;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16_K22, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K22, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K22)
  {
    WL_POPN(3);
    Term _f_2 = STK(0);
    Term _acc_1 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_2[1];
    if (spin_10(e, _o_2, _h_0, _acc_1, _first_1) == 0) {
      return 0;
    }
    _v_4 = _o_2[0];
    _v_3 = _v_4;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _v_3;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_2);
    }
    r0 = _f_2;
    r1 = _v_3;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_4;
      STK(1) = FID_HOST_RENDER_RENDER_LEDGER_K27;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER_K27, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LEDGER_K27, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER_K27)
  {
    WL_POPN(1);
    u32 _value_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_LEDGER_K28;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER_K28, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LEDGER_K28, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_5;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_5;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER_K28)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_1;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 32);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _h_2;
    e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 50);
    e.mem[_nd_3 + 1] = term_ctr(CID_CON, _nd_2);
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, term_ctr(CID_CON, _nd_3)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_4;
      STK(1) = FID_HOST_RENDER_RENDER_POSITION_K30;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_POSITION_K30, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_POSITION_K30, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION_K30)
  {
    WL_POPN(1);
    u32 _value_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_POSITION_K31;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_POSITION_K31, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_POSITION_K31, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_5;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_5;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION_K31)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_1;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 32);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 102);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _h_2;
    e.mem[_nd_2 + 1] = term_ctr(CID_CON, _nd_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 88);
    e.mem[_nd_3 + 1] = term_ctr(CID_CON, _nd_2);
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, term_ctr(CID_CON, _nd_3)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_0)
  {
    Term _a_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_GO_0)) {
      u64 _t_0 = task_node(e, FID_ARRAY_TO_LIST_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _a_0;
      e.mem[_t_0 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_ARRAY_TO_LIST_GO_0, _t_0);
    }
    r0 = _a_0;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_ARRAY_TO_LIST_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DATA)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_DATA_K34;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_DATA_K34, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_DATA_K34, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _values_0 = r0;
      WL_AGAIN(FID_DATA);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DATA_K34)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _h_0;
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_16_K36;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16_K36, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_16_K36, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16_K36)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, _h_0) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _v_0;
    e.mem[_nd_0 + 1] = term_ctr(CID_CON, STAT_OFF + 108);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 104);
    e.mem[_nd_1 + 1] = term_ctr(CID_CON, _nd_0);
    Term _v_2 = 0;
    Term _o_1[1];
    if (spin_7(e, _o_1, term_ctr(CID_CON, _nd_1)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 34);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K39;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K39, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K39, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K39)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _h_0;
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN)
  {
    u32 _label_0 = r0;
    Term _array_0 = r1;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _fv_0[1];
    _fv_0[0] = 10ull;
    Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_0);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, 11ull);
    Term _at_2 = blk_loc(e.mem, _a_0);
    Term _at_3 = blk_at(_a_0, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, 12ull);
    Term _at_4 = blk_loc(e.mem, _a_0);
    Term _at_5 = blk_at(_a_0, 3ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, 13ull);
    Term _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_0[24];
    if (spin_12(e, _o_0, _array_0, 4ull, 999ull, 200ull, 300ull, 400ull, 77ull, _a_0, 6ull, 900ull, 901ull, 902ull, 903ull, 88ull, 7ull, 3ull, term_pak(CID_TRANSACTION_PROTOTYPEFLATEND, 0), term_pak(CID_TRANSACTION_PROTOTYPEFLATMARKSEND, 0)) == 0) {
      return 0;
    }
    _v_24 = _o_0[0];
    _v_25 = _o_0[1];
    _v_26 = _o_0[2];
    _v_27 = _o_0[3];
    _v_28 = _o_0[4];
    _v_29 = _o_0[5];
    _v_30 = _o_0[6];
    _v_31 = _o_0[7];
    _v_32 = _o_0[8];
    _v_33 = _o_0[9];
    _v_34 = _o_0[10];
    _v_35 = _o_0[11];
    _v_36 = _o_0[12];
    _v_37 = _o_0[13];
    _v_38 = _o_0[14];
    _v_39 = _o_0[15];
    _v_40 = _o_0[16];
    _v_41 = _o_0[17];
    _v_42 = _o_0[18];
    _v_43 = _o_0[19];
    _v_44 = _o_0[20];
    _v_45 = _o_0[21];
    _v_46 = _o_0[22];
    _v_47 = _o_0[23];
    _v_0 = _v_24;
    _v_1 = _v_25;
    _v_2 = _v_26;
    _v_3 = _v_27;
    _v_4 = _v_28;
    _v_5 = _v_29;
    _v_6 = _v_30;
    _v_7 = _v_31;
    _v_8 = _v_32;
    _v_9 = _v_33;
    _v_10 = _v_34;
    _v_11 = _v_35;
    _v_12 = _v_36;
    _v_13 = _v_37;
    _v_14 = _v_38;
    _v_15 = _v_39;
    _v_16 = _v_40;
    _v_17 = _v_41;
    _v_18 = _v_42;
    _v_19 = _v_43;
    _v_20 = _v_44;
    _v_21 = _v_45;
    _v_22 = _v_46;
    _v_23 = _v_47;
    if (_v_18 == 0) {
      Term _v_48 = 0;
      u32 _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      u32 _v_52 = 0;
      u32 _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      Term _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      u32 _v_68 = 0;
      u32 _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      u32 _v_73 = 0;
      Term _v_74 = 0;
      u32 _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      u32 _v_80 = 0;
      u32 _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      u32 _v_85 = 0;
      Term _o_1[19];
      if (spin_15(e, _o_1, _v_0, _v_1, _v_2, _v_3, _v_4, _v_5, _v_6, _v_7, _v_8, _v_9, _v_10, _v_11, _v_12, _v_13, _v_14, _v_15, _v_16, _v_17) == 0) {
        return 0;
      }
      _v_67 = _o_1[0];
      _v_68 = _o_1[1];
      _v_69 = _o_1[2];
      _v_70 = _o_1[3];
      _v_71 = _o_1[4];
      _v_72 = _o_1[5];
      _v_73 = _o_1[6];
      _v_74 = _o_1[7];
      _v_75 = _o_1[8];
      _v_76 = _o_1[9];
      _v_77 = _o_1[10];
      _v_78 = _o_1[11];
      _v_79 = _o_1[12];
      _v_80 = _o_1[13];
      _v_81 = _o_1[14];
      _v_82 = _o_1[15];
      _v_83 = _o_1[16];
      _v_84 = _o_1[17];
      _v_85 = _o_1[18];
      _v_48 = _v_67;
      _v_49 = _v_68;
      _v_50 = _v_69;
      _v_51 = _v_70;
      _v_52 = _v_71;
      _v_53 = _v_72;
      _v_54 = _v_73;
      _v_55 = _v_74;
      _v_56 = _v_75;
      _v_57 = _v_76;
      _v_58 = _v_77;
      _v_59 = _v_78;
      _v_60 = _v_79;
      _v_61 = _v_80;
      _v_62 = _v_81;
      _v_63 = _v_82;
      _v_64 = _v_83;
      _v_65 = _v_84;
      _v_66 = _v_85;
      if (term_aux(_v_64) == CID_TRANSACTION_PROTOTYPEFLATMAIN) {
        u64 _sp_0 = term_loc(_v_64);
        u32 _f_0 = e.mem[_sp_0 + 0];
        u32 _f_1 = e.mem[_sp_0 + 1];
        u32 _f_2 = e.mem[_sp_0 + 2];
        Term _f_3 = e.mem[_sp_0 + 3];
        if (term_aux(_f_3) == CID_TRANSACTION_PROTOTYPEFLATMAIN) {
          u64 _sp_1 = term_loc(_f_3);
          u32 _f_4 = e.mem[_sp_1 + 0];
          u32 _f_5 = e.mem[_sp_1 + 1];
          u32 _f_6 = e.mem[_sp_1 + 2];
          Term _f_7 = e.mem[_sp_1 + 3];
          if (term_aux(_f_7) == CID_TRANSACTION_PROTOTYPEFLATEND) {
            if (term_aux(_v_65) == CID_TRANSACTION_PROTOTYPEFLATMARK) {
              u64 _sp_2 = term_loc(_v_65);
              u32 _f_8 = e.mem[_sp_2 + 0];
              u32 _f_9 = e.mem[_sp_2 + 1];
              Term _f_10 = e.mem[_sp_2 + 2];
              if (term_aux(_f_10) == CID_TRANSACTION_PROTOTYPEFLATMARK) {
                u64 _sp_3 = term_loc(_f_10);
                u32 _f_11 = e.mem[_sp_3 + 0];
                u32 _f_12 = e.mem[_sp_3 + 1];
                Term _f_13 = e.mem[_sp_3 + 2];
                if (term_aux(_f_13) == CID_TRANSACTION_PROTOTYPEFLATMARKSEND) {
                  heap_free(e, cls_fit(3), _sp_3);
                  heap_free(e, cls_fit(3), _sp_2);
                  heap_free(e, cls_fit(4), _sp_1);
                  heap_free(e, cls_fit(4), _sp_0);
                  if (seq) {
                    WL_ROOM(33);
                    STK(0) = _v_19;
                    STK(1) = _v_20;
                    STK(2) = _v_21;
                    STK(3) = _v_22;
                    STK(4) = _v_23;
                    STK(5) = _v_48;
                    STK(6) = _v_49;
                    STK(7) = _v_50;
                    STK(8) = _v_51;
                    STK(9) = _v_52;
                    STK(10) = _v_53;
                    STK(11) = _v_54;
                    STK(12) = _v_55;
                    STK(13) = _v_56;
                    STK(14) = _v_57;
                    STK(15) = _v_58;
                    STK(16) = _v_59;
                    STK(17) = _v_60;
                    STK(18) = _v_61;
                    STK(19) = _v_62;
                    STK(20) = _v_63;
                    STK(21) = _f_0;
                    STK(22) = _f_1;
                    STK(23) = _f_2;
                    STK(24) = _f_4;
                    STK(25) = _f_5;
                    STK(26) = _f_6;
                    STK(27) = _f_8;
                    STK(28) = _f_9;
                    STK(29) = _f_11;
                    STK(30) = _f_12;
                    STK(31) = _v_66;
                    STK(32) = FID_RUN_K180;
                    WL_PUSHN(33);
                  } else {
                    u64 _t_0 = task_node(e, FID_RUN_K180, WL_CONT, WL_IDX, 1);
                    e.mem[_t_0 + 0] = _v_19;
                    e.mem[_t_0 + 1] = _v_20;
                    e.mem[_t_0 + 2] = _v_21;
                    e.mem[_t_0 + 3] = _v_22;
                    e.mem[_t_0 + 4] = _v_23;
                    e.mem[_t_0 + 5] = _v_48;
                    e.mem[_t_0 + 6] = _v_49;
                    e.mem[_t_0 + 7] = _v_50;
                    e.mem[_t_0 + 8] = _v_51;
                    e.mem[_t_0 + 9] = _v_52;
                    e.mem[_t_0 + 10] = _v_53;
                    e.mem[_t_0 + 11] = _v_54;
                    e.mem[_t_0 + 12] = _v_55;
                    e.mem[_t_0 + 13] = _v_56;
                    e.mem[_t_0 + 14] = _v_57;
                    e.mem[_t_0 + 15] = _v_58;
                    e.mem[_t_0 + 16] = _v_59;
                    e.mem[_t_0 + 17] = _v_60;
                    e.mem[_t_0 + 18] = _v_61;
                    e.mem[_t_0 + 19] = _v_62;
                    e.mem[_t_0 + 20] = _v_63;
                    e.mem[_t_0 + 21] = _f_0;
                    e.mem[_t_0 + 22] = _f_1;
                    e.mem[_t_0 + 23] = _f_2;
                    e.mem[_t_0 + 24] = _f_4;
                    e.mem[_t_0 + 25] = _f_5;
                    e.mem[_t_0 + 26] = _f_6;
                    e.mem[_t_0 + 27] = _f_8;
                    e.mem[_t_0 + 28] = _f_9;
                    e.mem[_t_0 + 29] = _f_11;
                    e.mem[_t_0 + 30] = _f_12;
                    e.mem[_t_0 + 31] = _v_66;
                    WL_CONT = term_tsk(FID_RUN_K180, _t_0);
                    WL_IDX = 32;
                  }
                  if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
                    u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
                    e.mem[_t_1 + 0] = _label_0;
                    return term_tsk(FID_U32_SHOW, _t_1);
                  }
                  r0 = _label_0;
                  WL_JMP(FID_U32_SHOW);
                } else {
                  term_sink(e, _v_48);
                  term_sink(e, _v_55);
                  term_sink(e, _f_13);
                  u64 _nd_1 = heap_alloc(e, cls_fit(1));
                  e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
                  heap_free(e, cls_fit(3), _sp_3);
                  heap_free(e, cls_fit(3), _sp_2);
                  heap_free(e, cls_fit(4), _sp_1);
                  heap_free(e, cls_fit(4), _sp_0);
                  r0 = term_clo(FID_IO_PRINT, _nd_1);
                  WL_RETN(1);
                }
              } else {
                term_sink(e, _v_48);
                term_sink(e, _v_55);
                term_sink(e, _f_10);
                u64 _nd_2 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
                heap_free(e, cls_fit(3), _sp_2);
                heap_free(e, cls_fit(4), _sp_1);
                heap_free(e, cls_fit(4), _sp_0);
                r0 = term_clo(FID_IO_PRINT, _nd_2);
                WL_RETN(1);
              }
            } else {
              term_sink(e, _v_48);
              term_sink(e, _v_55);
              term_sink(e, _v_65);
              u64 _nd_3 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
              heap_free(e, cls_fit(4), _sp_1);
              heap_free(e, cls_fit(4), _sp_0);
              r0 = term_clo(FID_IO_PRINT, _nd_3);
              WL_RETN(1);
            }
          } else {
            term_sink(e, _v_48);
            term_sink(e, _v_55);
            term_sink(e, _f_7);
            term_sink(e, _v_65);
            u64 _nd_4 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
            heap_free(e, cls_fit(4), _sp_1);
            heap_free(e, cls_fit(4), _sp_0);
            r0 = term_clo(FID_IO_PRINT, _nd_4);
            WL_RETN(1);
          }
        } else {
          term_sink(e, _v_48);
          term_sink(e, _v_55);
          term_sink(e, _f_3);
          term_sink(e, _v_65);
          u64 _nd_5 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
          heap_free(e, cls_fit(4), _sp_0);
          r0 = term_clo(FID_IO_PRINT, _nd_5);
          WL_RETN(1);
        }
      } else {
        term_sink(e, _v_48);
        term_sink(e, _v_55);
        term_sink(e, _v_64);
        term_sink(e, _v_65);
        u64 _nd_6 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
        r0 = term_clo(FID_IO_PRINT, _nd_6);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _v_0);
      term_sink(e, _v_7);
      term_sink(e, _v_16);
      term_sink(e, _v_17);
      u64 _nd_7 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 366);
      r0 = term_clo(FID_IO_PRINT, _nd_7);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K180)
  {
    WL_POPN(32);
    u32 _v_86 = STK(0);
    u32 _v_87 = STK(1);
    u32 _v_88 = STK(2);
    u32 _v_89 = STK(3);
    u32 _v_90 = STK(4);
    Term _v_91 = STK(5);
    u32 _v_92 = STK(6);
    u32 _v_93 = STK(7);
    u32 _v_94 = STK(8);
    u32 _v_95 = STK(9);
    u32 _v_96 = STK(10);
    u32 _v_97 = STK(11);
    Term _v_98 = STK(12);
    u32 _v_99 = STK(13);
    u32 _v_100 = STK(14);
    u32 _v_101 = STK(15);
    u32 _v_102 = STK(16);
    u32 _v_103 = STK(17);
    u32 _v_104 = STK(18);
    u32 _v_105 = STK(19);
    u32 _v_106 = STK(20);
    u32 _f_14 = STK(21);
    u32 _f_15 = STK(22);
    u32 _f_16 = STK(23);
    u32 _f_17 = STK(24);
    u32 _f_18 = STK(25);
    u32 _f_19 = STK(26);
    u32 _f_20 = STK(27);
    u32 _f_21 = STK(28);
    u32 _f_22 = STK(29);
    u32 _f_23 = STK(30);
    u32 _v_107 = STK(31);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _v_86;
      STK(1) = _v_87;
      STK(2) = _v_88;
      STK(3) = _v_89;
      STK(4) = _v_90;
      STK(5) = _v_92;
      STK(6) = _v_93;
      STK(7) = _v_94;
      STK(8) = _v_95;
      STK(9) = _v_96;
      STK(10) = _v_97;
      STK(11) = _v_98;
      STK(12) = _v_99;
      STK(13) = _v_100;
      STK(14) = _v_101;
      STK(15) = _v_102;
      STK(16) = _v_103;
      STK(17) = _v_104;
      STK(18) = _v_105;
      STK(19) = _v_106;
      STK(20) = _f_14;
      STK(21) = _f_15;
      STK(22) = _f_16;
      STK(23) = _f_17;
      STK(24) = _f_18;
      STK(25) = _f_19;
      STK(26) = _f_20;
      STK(27) = _f_21;
      STK(28) = _f_22;
      STK(29) = _f_23;
      STK(30) = _v_107;
      STK(31) = _h_0;
      STK(32) = FID_RUN_K181;
      WL_PUSHN(33);
    } else {
      u64 _t_2 = task_node(e, FID_RUN_K181, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_86;
      e.mem[_t_2 + 1] = _v_87;
      e.mem[_t_2 + 2] = _v_88;
      e.mem[_t_2 + 3] = _v_89;
      e.mem[_t_2 + 4] = _v_90;
      e.mem[_t_2 + 5] = _v_92;
      e.mem[_t_2 + 6] = _v_93;
      e.mem[_t_2 + 7] = _v_94;
      e.mem[_t_2 + 8] = _v_95;
      e.mem[_t_2 + 9] = _v_96;
      e.mem[_t_2 + 10] = _v_97;
      e.mem[_t_2 + 11] = _v_98;
      e.mem[_t_2 + 12] = _v_99;
      e.mem[_t_2 + 13] = _v_100;
      e.mem[_t_2 + 14] = _v_101;
      e.mem[_t_2 + 15] = _v_102;
      e.mem[_t_2 + 16] = _v_103;
      e.mem[_t_2 + 17] = _v_104;
      e.mem[_t_2 + 18] = _v_105;
      e.mem[_t_2 + 19] = _v_106;
      e.mem[_t_2 + 20] = _f_14;
      e.mem[_t_2 + 21] = _f_15;
      e.mem[_t_2 + 22] = _f_16;
      e.mem[_t_2 + 23] = _f_17;
      e.mem[_t_2 + 24] = _f_18;
      e.mem[_t_2 + 25] = _f_19;
      e.mem[_t_2 + 26] = _f_20;
      e.mem[_t_2 + 27] = _f_21;
      e.mem[_t_2 + 28] = _f_22;
      e.mem[_t_2 + 29] = _f_23;
      e.mem[_t_2 + 30] = _v_107;
      e.mem[_t_2 + 31] = _h_0;
      WL_CONT = term_tsk(FID_RUN_K181, _t_2);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_3 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_91;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_3);
    }
    r0 = _v_91;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K181)
  {
    WL_POPN(32);
    u32 _v_108 = STK(0);
    u32 _v_109 = STK(1);
    u32 _v_110 = STK(2);
    u32 _v_111 = STK(3);
    u32 _v_112 = STK(4);
    u32 _v_113 = STK(5);
    u32 _v_114 = STK(6);
    u32 _v_115 = STK(7);
    u32 _v_116 = STK(8);
    u32 _v_117 = STK(9);
    u32 _v_118 = STK(10);
    Term _v_119 = STK(11);
    u32 _v_120 = STK(12);
    u32 _v_121 = STK(13);
    u32 _v_122 = STK(14);
    u32 _v_123 = STK(15);
    u32 _v_124 = STK(16);
    u32 _v_125 = STK(17);
    u32 _v_126 = STK(18);
    u32 _v_127 = STK(19);
    u32 _f_24 = STK(20);
    u32 _f_25 = STK(21);
    u32 _f_26 = STK(22);
    u32 _f_27 = STK(23);
    u32 _f_28 = STK(24);
    u32 _f_29 = STK(25);
    u32 _f_30 = STK(26);
    u32 _f_31 = STK(27);
    u32 _f_32 = STK(28);
    u32 _f_33 = STK(29);
    u32 _v_128 = STK(30);
    Term _h_2 = STK(31);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _v_108;
      STK(1) = _v_109;
      STK(2) = _v_110;
      STK(3) = _v_111;
      STK(4) = _v_112;
      STK(5) = _v_113;
      STK(6) = _v_114;
      STK(7) = _v_115;
      STK(8) = _v_116;
      STK(9) = _v_117;
      STK(10) = _v_118;
      STK(11) = _v_119;
      STK(12) = _v_120;
      STK(13) = _v_121;
      STK(14) = _v_122;
      STK(15) = _v_123;
      STK(16) = _v_124;
      STK(17) = _v_125;
      STK(18) = _v_126;
      STK(19) = _v_127;
      STK(20) = _f_24;
      STK(21) = _f_25;
      STK(22) = _f_26;
      STK(23) = _f_27;
      STK(24) = _f_28;
      STK(25) = _f_29;
      STK(26) = _f_30;
      STK(27) = _f_31;
      STK(28) = _f_32;
      STK(29) = _f_33;
      STK(30) = _v_128;
      STK(31) = _h_2;
      STK(32) = FID_RUN_K182;
      WL_PUSHN(33);
    } else {
      u64 _t_4 = task_node(e, FID_RUN_K182, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _v_108;
      e.mem[_t_4 + 1] = _v_109;
      e.mem[_t_4 + 2] = _v_110;
      e.mem[_t_4 + 3] = _v_111;
      e.mem[_t_4 + 4] = _v_112;
      e.mem[_t_4 + 5] = _v_113;
      e.mem[_t_4 + 6] = _v_114;
      e.mem[_t_4 + 7] = _v_115;
      e.mem[_t_4 + 8] = _v_116;
      e.mem[_t_4 + 9] = _v_117;
      e.mem[_t_4 + 10] = _v_118;
      e.mem[_t_4 + 11] = _v_119;
      e.mem[_t_4 + 12] = _v_120;
      e.mem[_t_4 + 13] = _v_121;
      e.mem[_t_4 + 14] = _v_122;
      e.mem[_t_4 + 15] = _v_123;
      e.mem[_t_4 + 16] = _v_124;
      e.mem[_t_4 + 17] = _v_125;
      e.mem[_t_4 + 18] = _v_126;
      e.mem[_t_4 + 19] = _v_127;
      e.mem[_t_4 + 20] = _f_24;
      e.mem[_t_4 + 21] = _f_25;
      e.mem[_t_4 + 22] = _f_26;
      e.mem[_t_4 + 23] = _f_27;
      e.mem[_t_4 + 24] = _f_28;
      e.mem[_t_4 + 25] = _f_29;
      e.mem[_t_4 + 26] = _f_30;
      e.mem[_t_4 + 27] = _f_31;
      e.mem[_t_4 + 28] = _f_32;
      e.mem[_t_4 + 29] = _f_33;
      e.mem[_t_4 + 30] = _v_128;
      e.mem[_t_4 + 31] = _h_2;
      WL_CONT = term_tsk(FID_RUN_K182, _t_4);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_5 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_1;
      return term_tsk(FID_DATA, _t_5);
    }
    r0 = _h_1;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K182)
  {
    WL_POPN(32);
    u32 _v_129 = STK(0);
    u32 _v_130 = STK(1);
    u32 _v_131 = STK(2);
    u32 _v_132 = STK(3);
    u32 _v_133 = STK(4);
    u32 _v_134 = STK(5);
    u32 _v_135 = STK(6);
    u32 _v_136 = STK(7);
    u32 _v_137 = STK(8);
    u32 _v_138 = STK(9);
    u32 _v_139 = STK(10);
    Term _v_140 = STK(11);
    u32 _v_141 = STK(12);
    u32 _v_142 = STK(13);
    u32 _v_143 = STK(14);
    u32 _v_144 = STK(15);
    u32 _v_145 = STK(16);
    u32 _v_146 = STK(17);
    u32 _v_147 = STK(18);
    u32 _v_148 = STK(19);
    u32 _f_34 = STK(20);
    u32 _f_35 = STK(21);
    u32 _f_36 = STK(22);
    u32 _f_37 = STK(23);
    u32 _f_38 = STK(24);
    u32 _f_39 = STK(25);
    u32 _f_40 = STK(26);
    u32 _f_41 = STK(27);
    u32 _f_42 = STK(28);
    u32 _f_43 = STK(29);
    u32 _v_149 = STK(30);
    Term _h_4 = STK(31);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _v_129;
      STK(1) = _v_130;
      STK(2) = _v_131;
      STK(3) = _v_132;
      STK(4) = _v_133;
      STK(5) = _v_134;
      STK(6) = _v_135;
      STK(7) = _v_136;
      STK(8) = _v_137;
      STK(9) = _v_138;
      STK(10) = _v_139;
      STK(11) = _v_140;
      STK(12) = _v_141;
      STK(13) = _v_142;
      STK(14) = _v_143;
      STK(15) = _v_144;
      STK(16) = _v_145;
      STK(17) = _v_146;
      STK(18) = _v_147;
      STK(19) = _v_148;
      STK(20) = _f_34;
      STK(21) = _f_35;
      STK(22) = _f_36;
      STK(23) = _f_37;
      STK(24) = _f_38;
      STK(25) = _f_39;
      STK(26) = _f_40;
      STK(27) = _f_41;
      STK(28) = _f_42;
      STK(29) = _f_43;
      STK(30) = _v_149;
      STK(31) = _h_4;
      STK(32) = FID_RUN_K183;
      WL_PUSHN(33);
    } else {
      u64 _t_6 = task_node(e, FID_RUN_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _v_129;
      e.mem[_t_6 + 1] = _v_130;
      e.mem[_t_6 + 2] = _v_131;
      e.mem[_t_6 + 3] = _v_132;
      e.mem[_t_6 + 4] = _v_133;
      e.mem[_t_6 + 5] = _v_134;
      e.mem[_t_6 + 6] = _v_135;
      e.mem[_t_6 + 7] = _v_136;
      e.mem[_t_6 + 8] = _v_137;
      e.mem[_t_6 + 9] = _v_138;
      e.mem[_t_6 + 10] = _v_139;
      e.mem[_t_6 + 11] = _v_140;
      e.mem[_t_6 + 12] = _v_141;
      e.mem[_t_6 + 13] = _v_142;
      e.mem[_t_6 + 14] = _v_143;
      e.mem[_t_6 + 15] = _v_144;
      e.mem[_t_6 + 16] = _v_145;
      e.mem[_t_6 + 17] = _v_146;
      e.mem[_t_6 + 18] = _v_147;
      e.mem[_t_6 + 19] = _v_148;
      e.mem[_t_6 + 20] = _f_34;
      e.mem[_t_6 + 21] = _f_35;
      e.mem[_t_6 + 22] = _f_36;
      e.mem[_t_6 + 23] = _f_37;
      e.mem[_t_6 + 24] = _f_38;
      e.mem[_t_6 + 25] = _f_39;
      e.mem[_t_6 + 26] = _f_40;
      e.mem[_t_6 + 27] = _f_41;
      e.mem[_t_6 + 28] = _f_42;
      e.mem[_t_6 + 29] = _f_43;
      e.mem[_t_6 + 30] = _v_149;
      e.mem[_t_6 + 31] = _h_4;
      WL_CONT = term_tsk(FID_RUN_K183, _t_6);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_7 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_3;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_7);
    }
    r0 = _h_3;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K183)
  {
    WL_POPN(32);
    u32 _v_150 = STK(0);
    u32 _v_151 = STK(1);
    u32 _v_152 = STK(2);
    u32 _v_153 = STK(3);
    u32 _v_154 = STK(4);
    u32 _v_155 = STK(5);
    u32 _v_156 = STK(6);
    u32 _v_157 = STK(7);
    u32 _v_158 = STK(8);
    u32 _v_159 = STK(9);
    u32 _v_160 = STK(10);
    Term _v_161 = STK(11);
    u32 _v_162 = STK(12);
    u32 _v_163 = STK(13);
    u32 _v_164 = STK(14);
    u32 _v_165 = STK(15);
    u32 _v_166 = STK(16);
    u32 _v_167 = STK(17);
    u32 _v_168 = STK(18);
    u32 _v_169 = STK(19);
    u32 _f_44 = STK(20);
    u32 _f_45 = STK(21);
    u32 _f_46 = STK(22);
    u32 _f_47 = STK(23);
    u32 _f_48 = STK(24);
    u32 _f_49 = STK(25);
    u32 _f_50 = STK(26);
    u32 _f_51 = STK(27);
    u32 _f_52 = STK(28);
    u32 _f_53 = STK(29);
    u32 _v_170 = STK(30);
    Term _h_6 = STK(31);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _v_150;
      STK(1) = _v_151;
      STK(2) = _v_152;
      STK(3) = _v_153;
      STK(4) = _v_154;
      STK(5) = _v_156;
      STK(6) = _v_157;
      STK(7) = _v_158;
      STK(8) = _v_159;
      STK(9) = _v_160;
      STK(10) = _v_161;
      STK(11) = _v_162;
      STK(12) = _v_163;
      STK(13) = _v_164;
      STK(14) = _v_165;
      STK(15) = _v_166;
      STK(16) = _v_167;
      STK(17) = _v_168;
      STK(18) = _v_169;
      STK(19) = _f_44;
      STK(20) = _f_45;
      STK(21) = _f_46;
      STK(22) = _f_47;
      STK(23) = _f_48;
      STK(24) = _f_49;
      STK(25) = _f_50;
      STK(26) = _f_51;
      STK(27) = _f_52;
      STK(28) = _f_53;
      STK(29) = _v_170;
      STK(30) = _h_6;
      STK(31) = _h_5;
      STK(32) = FID_RUN_K184;
      WL_PUSHN(33);
    } else {
      u64 _t_8 = task_node(e, FID_RUN_K184, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _v_150;
      e.mem[_t_8 + 1] = _v_151;
      e.mem[_t_8 + 2] = _v_152;
      e.mem[_t_8 + 3] = _v_153;
      e.mem[_t_8 + 4] = _v_154;
      e.mem[_t_8 + 5] = _v_156;
      e.mem[_t_8 + 6] = _v_157;
      e.mem[_t_8 + 7] = _v_158;
      e.mem[_t_8 + 8] = _v_159;
      e.mem[_t_8 + 9] = _v_160;
      e.mem[_t_8 + 10] = _v_161;
      e.mem[_t_8 + 11] = _v_162;
      e.mem[_t_8 + 12] = _v_163;
      e.mem[_t_8 + 13] = _v_164;
      e.mem[_t_8 + 14] = _v_165;
      e.mem[_t_8 + 15] = _v_166;
      e.mem[_t_8 + 16] = _v_167;
      e.mem[_t_8 + 17] = _v_168;
      e.mem[_t_8 + 18] = _v_169;
      e.mem[_t_8 + 19] = _f_44;
      e.mem[_t_8 + 20] = _f_45;
      e.mem[_t_8 + 21] = _f_46;
      e.mem[_t_8 + 22] = _f_47;
      e.mem[_t_8 + 23] = _f_48;
      e.mem[_t_8 + 24] = _f_49;
      e.mem[_t_8 + 25] = _f_50;
      e.mem[_t_8 + 26] = _f_51;
      e.mem[_t_8 + 27] = _f_52;
      e.mem[_t_8 + 28] = _f_53;
      e.mem[_t_8 + 29] = _v_170;
      e.mem[_t_8 + 30] = _h_6;
      e.mem[_t_8 + 31] = _h_5;
      WL_CONT = term_tsk(FID_RUN_K184, _t_8);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _v_155;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _v_155;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K184)
  {
    WL_POPN(32);
    u32 _v_171 = STK(0);
    u32 _v_172 = STK(1);
    u32 _v_173 = STK(2);
    u32 _v_174 = STK(3);
    u32 _v_175 = STK(4);
    u32 _v_176 = STK(5);
    u32 _v_177 = STK(6);
    u32 _v_178 = STK(7);
    u32 _v_179 = STK(8);
    u32 _v_180 = STK(9);
    Term _v_181 = STK(10);
    u32 _v_182 = STK(11);
    u32 _v_183 = STK(12);
    u32 _v_184 = STK(13);
    u32 _v_185 = STK(14);
    u32 _v_186 = STK(15);
    u32 _v_187 = STK(16);
    u32 _v_188 = STK(17);
    u32 _v_189 = STK(18);
    u32 _f_54 = STK(19);
    u32 _f_55 = STK(20);
    u32 _f_56 = STK(21);
    u32 _f_57 = STK(22);
    u32 _f_58 = STK(23);
    u32 _f_59 = STK(24);
    u32 _f_60 = STK(25);
    u32 _f_61 = STK(26);
    u32 _f_62 = STK(27);
    u32 _f_63 = STK(28);
    u32 _v_190 = STK(29);
    Term _h_8 = STK(30);
    Term _h_9 = STK(31);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _v_171;
      STK(1) = _v_172;
      STK(2) = _v_173;
      STK(3) = _v_174;
      STK(4) = _v_175;
      STK(5) = _v_181;
      STK(6) = _v_182;
      STK(7) = _v_183;
      STK(8) = _v_184;
      STK(9) = _v_185;
      STK(10) = _v_186;
      STK(11) = _v_187;
      STK(12) = _v_188;
      STK(13) = _v_189;
      STK(14) = _f_54;
      STK(15) = _f_55;
      STK(16) = _f_56;
      STK(17) = _f_57;
      STK(18) = _f_58;
      STK(19) = _f_59;
      STK(20) = _f_60;
      STK(21) = _f_61;
      STK(22) = _f_62;
      STK(23) = _f_63;
      STK(24) = _v_190;
      STK(25) = _h_8;
      STK(26) = _h_9;
      STK(27) = _h_7;
      STK(28) = FID_RUN_K185;
      WL_PUSHN(29);
    } else {
      u64 _t_10 = task_node(e, FID_RUN_K185, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _v_171;
      e.mem[_t_10 + 1] = _v_172;
      e.mem[_t_10 + 2] = _v_173;
      e.mem[_t_10 + 3] = _v_174;
      e.mem[_t_10 + 4] = _v_175;
      e.mem[_t_10 + 5] = _v_181;
      e.mem[_t_10 + 6] = _v_182;
      e.mem[_t_10 + 7] = _v_183;
      e.mem[_t_10 + 8] = _v_184;
      e.mem[_t_10 + 9] = _v_185;
      e.mem[_t_10 + 10] = _v_186;
      e.mem[_t_10 + 11] = _v_187;
      e.mem[_t_10 + 12] = _v_188;
      e.mem[_t_10 + 13] = _v_189;
      e.mem[_t_10 + 14] = _f_54;
      e.mem[_t_10 + 15] = _f_55;
      e.mem[_t_10 + 16] = _f_56;
      e.mem[_t_10 + 17] = _f_57;
      e.mem[_t_10 + 18] = _f_58;
      e.mem[_t_10 + 19] = _f_59;
      e.mem[_t_10 + 20] = _f_60;
      e.mem[_t_10 + 21] = _f_61;
      e.mem[_t_10 + 22] = _f_62;
      e.mem[_t_10 + 23] = _f_63;
      e.mem[_t_10 + 24] = _v_190;
      e.mem[_t_10 + 25] = _h_8;
      e.mem[_t_10 + 26] = _h_9;
      e.mem[_t_10 + 27] = _h_7;
      WL_CONT = term_tsk(FID_RUN_K185, _t_10);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_POSITION)) {
      u64 _t_11 = task_node(e, FID_HOST_RENDER_RENDER_POSITION, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _v_176;
      e.mem[_t_11 + 1] = _v_177;
      e.mem[_t_11 + 2] = _v_178;
      e.mem[_t_11 + 3] = _v_179;
      e.mem[_t_11 + 4] = _v_180;
      return term_tsk(FID_HOST_RENDER_RENDER_POSITION, _t_11);
    }
    r0 = _v_176;
    r1 = _v_177;
    r2 = _v_178;
    r3 = _v_179;
    r4 = _v_180;
    WL_JMP(FID_HOST_RENDER_RENDER_POSITION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K185)
  {
    WL_POPN(28);
    u32 _v_191 = STK(0);
    u32 _v_192 = STK(1);
    u32 _v_193 = STK(2);
    u32 _v_194 = STK(3);
    u32 _v_195 = STK(4);
    Term _v_196 = STK(5);
    u32 _v_197 = STK(6);
    u32 _v_198 = STK(7);
    u32 _v_199 = STK(8);
    u32 _v_200 = STK(9);
    u32 _v_201 = STK(10);
    u32 _v_202 = STK(11);
    u32 _v_203 = STK(12);
    u32 _v_204 = STK(13);
    u32 _f_64 = STK(14);
    u32 _f_65 = STK(15);
    u32 _f_66 = STK(16);
    u32 _f_67 = STK(17);
    u32 _f_68 = STK(18);
    u32 _f_69 = STK(19);
    u32 _f_70 = STK(20);
    u32 _f_71 = STK(21);
    u32 _f_72 = STK(22);
    u32 _f_73 = STK(23);
    u32 _v_205 = STK(24);
    Term _h_11 = STK(25);
    Term _h_12 = STK(26);
    Term _h_13 = STK(27);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _v_196;
      STK(1) = _v_197;
      STK(2) = _v_198;
      STK(3) = _v_199;
      STK(4) = _v_200;
      STK(5) = _v_201;
      STK(6) = _v_202;
      STK(7) = _v_203;
      STK(8) = _v_204;
      STK(9) = _f_64;
      STK(10) = _f_65;
      STK(11) = _f_66;
      STK(12) = _f_67;
      STK(13) = _f_68;
      STK(14) = _f_69;
      STK(15) = _f_70;
      STK(16) = _f_71;
      STK(17) = _f_72;
      STK(18) = _f_73;
      STK(19) = _v_205;
      STK(20) = _h_11;
      STK(21) = _h_12;
      STK(22) = _h_13;
      STK(23) = _h_10;
      STK(24) = FID_RUN_K186;
      WL_PUSHN(25);
    } else {
      u64 _t_12 = task_node(e, FID_RUN_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _v_196;
      e.mem[_t_12 + 1] = _v_197;
      e.mem[_t_12 + 2] = _v_198;
      e.mem[_t_12 + 3] = _v_199;
      e.mem[_t_12 + 4] = _v_200;
      e.mem[_t_12 + 5] = _v_201;
      e.mem[_t_12 + 6] = _v_202;
      e.mem[_t_12 + 7] = _v_203;
      e.mem[_t_12 + 8] = _v_204;
      e.mem[_t_12 + 9] = _f_64;
      e.mem[_t_12 + 10] = _f_65;
      e.mem[_t_12 + 11] = _f_66;
      e.mem[_t_12 + 12] = _f_67;
      e.mem[_t_12 + 13] = _f_68;
      e.mem[_t_12 + 14] = _f_69;
      e.mem[_t_12 + 15] = _f_70;
      e.mem[_t_12 + 16] = _f_71;
      e.mem[_t_12 + 17] = _f_72;
      e.mem[_t_12 + 18] = _f_73;
      e.mem[_t_12 + 19] = _v_205;
      e.mem[_t_12 + 20] = _h_11;
      e.mem[_t_12 + 21] = _h_12;
      e.mem[_t_12 + 22] = _h_13;
      e.mem[_t_12 + 23] = _h_10;
      WL_CONT = term_tsk(FID_RUN_K186, _t_12);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_POSITION)) {
      u64 _t_13 = task_node(e, FID_HOST_RENDER_RENDER_POSITION, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _v_191;
      e.mem[_t_13 + 1] = _v_192;
      e.mem[_t_13 + 2] = _v_193;
      e.mem[_t_13 + 3] = _v_194;
      e.mem[_t_13 + 4] = _v_195;
      return term_tsk(FID_HOST_RENDER_RENDER_POSITION, _t_13);
    }
    r0 = _v_191;
    r1 = _v_192;
    r2 = _v_193;
    r3 = _v_194;
    r4 = _v_195;
    WL_JMP(FID_HOST_RENDER_RENDER_POSITION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K186)
  {
    WL_POPN(24);
    Term _v_206 = STK(0);
    u32 _v_207 = STK(1);
    u32 _v_208 = STK(2);
    u32 _v_209 = STK(3);
    u32 _v_210 = STK(4);
    u32 _v_211 = STK(5);
    u32 _v_212 = STK(6);
    u32 _v_213 = STK(7);
    u32 _v_214 = STK(8);
    u32 _f_74 = STK(9);
    u32 _f_75 = STK(10);
    u32 _f_76 = STK(11);
    u32 _f_77 = STK(12);
    u32 _f_78 = STK(13);
    u32 _f_79 = STK(14);
    u32 _f_80 = STK(15);
    u32 _f_81 = STK(16);
    u32 _f_82 = STK(17);
    u32 _f_83 = STK(18);
    u32 _v_215 = STK(19);
    Term _h_15 = STK(20);
    Term _h_16 = STK(21);
    Term _h_17 = STK(22);
    Term _h_18 = STK(23);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _v_207;
      STK(1) = _v_208;
      STK(2) = _v_209;
      STK(3) = _v_210;
      STK(4) = _v_211;
      STK(5) = _v_212;
      STK(6) = _v_213;
      STK(7) = _v_214;
      STK(8) = _f_74;
      STK(9) = _f_75;
      STK(10) = _f_76;
      STK(11) = _f_77;
      STK(12) = _f_78;
      STK(13) = _f_79;
      STK(14) = _f_80;
      STK(15) = _f_81;
      STK(16) = _f_82;
      STK(17) = _f_83;
      STK(18) = _v_215;
      STK(19) = _h_15;
      STK(20) = _h_16;
      STK(21) = _h_17;
      STK(22) = _h_18;
      STK(23) = _h_14;
      STK(24) = FID_RUN_K187;
      WL_PUSHN(25);
    } else {
      u64 _t_14 = task_node(e, FID_RUN_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _v_207;
      e.mem[_t_14 + 1] = _v_208;
      e.mem[_t_14 + 2] = _v_209;
      e.mem[_t_14 + 3] = _v_210;
      e.mem[_t_14 + 4] = _v_211;
      e.mem[_t_14 + 5] = _v_212;
      e.mem[_t_14 + 6] = _v_213;
      e.mem[_t_14 + 7] = _v_214;
      e.mem[_t_14 + 8] = _f_74;
      e.mem[_t_14 + 9] = _f_75;
      e.mem[_t_14 + 10] = _f_76;
      e.mem[_t_14 + 11] = _f_77;
      e.mem[_t_14 + 12] = _f_78;
      e.mem[_t_14 + 13] = _f_79;
      e.mem[_t_14 + 14] = _f_80;
      e.mem[_t_14 + 15] = _f_81;
      e.mem[_t_14 + 16] = _f_82;
      e.mem[_t_14 + 17] = _f_83;
      e.mem[_t_14 + 18] = _v_215;
      e.mem[_t_14 + 19] = _h_15;
      e.mem[_t_14 + 20] = _h_16;
      e.mem[_t_14 + 21] = _h_17;
      e.mem[_t_14 + 22] = _h_18;
      e.mem[_t_14 + 23] = _h_14;
      WL_CONT = term_tsk(FID_RUN_K187, _t_14);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_15 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _v_206;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_15);
    }
    r0 = _v_206;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K187)
  {
    WL_POPN(24);
    u32 _v_216 = STK(0);
    u32 _v_217 = STK(1);
    u32 _v_218 = STK(2);
    u32 _v_219 = STK(3);
    u32 _v_220 = STK(4);
    u32 _v_221 = STK(5);
    u32 _v_222 = STK(6);
    u32 _v_223 = STK(7);
    u32 _f_84 = STK(8);
    u32 _f_85 = STK(9);
    u32 _f_86 = STK(10);
    u32 _f_87 = STK(11);
    u32 _f_88 = STK(12);
    u32 _f_89 = STK(13);
    u32 _f_90 = STK(14);
    u32 _f_91 = STK(15);
    u32 _f_92 = STK(16);
    u32 _f_93 = STK(17);
    u32 _v_224 = STK(18);
    Term _h_20 = STK(19);
    Term _h_21 = STK(20);
    Term _h_22 = STK(21);
    Term _h_23 = STK(22);
    Term _h_24 = STK(23);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _v_216;
      STK(1) = _v_217;
      STK(2) = _v_218;
      STK(3) = _v_219;
      STK(4) = _v_220;
      STK(5) = _v_221;
      STK(6) = _v_222;
      STK(7) = _v_223;
      STK(8) = _f_84;
      STK(9) = _f_85;
      STK(10) = _f_86;
      STK(11) = _f_87;
      STK(12) = _f_88;
      STK(13) = _f_89;
      STK(14) = _f_90;
      STK(15) = _f_91;
      STK(16) = _f_92;
      STK(17) = _f_93;
      STK(18) = _v_224;
      STK(19) = _h_20;
      STK(20) = _h_21;
      STK(21) = _h_22;
      STK(22) = _h_23;
      STK(23) = _h_24;
      STK(24) = FID_RUN_K188;
      WL_PUSHN(25);
    } else {
      u64 _t_16 = task_node(e, FID_RUN_K188, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _v_216;
      e.mem[_t_16 + 1] = _v_217;
      e.mem[_t_16 + 2] = _v_218;
      e.mem[_t_16 + 3] = _v_219;
      e.mem[_t_16 + 4] = _v_220;
      e.mem[_t_16 + 5] = _v_221;
      e.mem[_t_16 + 6] = _v_222;
      e.mem[_t_16 + 7] = _v_223;
      e.mem[_t_16 + 8] = _f_84;
      e.mem[_t_16 + 9] = _f_85;
      e.mem[_t_16 + 10] = _f_86;
      e.mem[_t_16 + 11] = _f_87;
      e.mem[_t_16 + 12] = _f_88;
      e.mem[_t_16 + 13] = _f_89;
      e.mem[_t_16 + 14] = _f_90;
      e.mem[_t_16 + 15] = _f_91;
      e.mem[_t_16 + 16] = _f_92;
      e.mem[_t_16 + 17] = _f_93;
      e.mem[_t_16 + 18] = _v_224;
      e.mem[_t_16 + 19] = _h_20;
      e.mem[_t_16 + 20] = _h_21;
      e.mem[_t_16 + 21] = _h_22;
      e.mem[_t_16 + 22] = _h_23;
      e.mem[_t_16 + 23] = _h_24;
      WL_CONT = term_tsk(FID_RUN_K188, _t_16);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_17 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_19;
      return term_tsk(FID_DATA, _t_17);
    }
    r0 = _h_19;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K188)
  {
    WL_POPN(24);
    u32 _v_225 = STK(0);
    u32 _v_226 = STK(1);
    u32 _v_227 = STK(2);
    u32 _v_228 = STK(3);
    u32 _v_229 = STK(4);
    u32 _v_230 = STK(5);
    u32 _v_231 = STK(6);
    u32 _v_232 = STK(7);
    u32 _f_94 = STK(8);
    u32 _f_95 = STK(9);
    u32 _f_96 = STK(10);
    u32 _f_97 = STK(11);
    u32 _f_98 = STK(12);
    u32 _f_99 = STK(13);
    u32 _f_100 = STK(14);
    u32 _f_101 = STK(15);
    u32 _f_102 = STK(16);
    u32 _f_103 = STK(17);
    u32 _v_233 = STK(18);
    Term _h_26 = STK(19);
    Term _h_27 = STK(20);
    Term _h_28 = STK(21);
    Term _h_29 = STK(22);
    Term _h_30 = STK(23);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _v_225;
      STK(1) = _v_226;
      STK(2) = _v_227;
      STK(3) = _v_228;
      STK(4) = _v_229;
      STK(5) = _v_230;
      STK(6) = _v_231;
      STK(7) = _v_232;
      STK(8) = _f_94;
      STK(9) = _f_95;
      STK(10) = _f_96;
      STK(11) = _f_97;
      STK(12) = _f_98;
      STK(13) = _f_99;
      STK(14) = _f_100;
      STK(15) = _f_101;
      STK(16) = _f_102;
      STK(17) = _f_103;
      STK(18) = _v_233;
      STK(19) = _h_26;
      STK(20) = _h_27;
      STK(21) = _h_28;
      STK(22) = _h_29;
      STK(23) = _h_30;
      STK(24) = FID_RUN_K189;
      WL_PUSHN(25);
    } else {
      u64 _t_18 = task_node(e, FID_RUN_K189, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _v_225;
      e.mem[_t_18 + 1] = _v_226;
      e.mem[_t_18 + 2] = _v_227;
      e.mem[_t_18 + 3] = _v_228;
      e.mem[_t_18 + 4] = _v_229;
      e.mem[_t_18 + 5] = _v_230;
      e.mem[_t_18 + 6] = _v_231;
      e.mem[_t_18 + 7] = _v_232;
      e.mem[_t_18 + 8] = _f_94;
      e.mem[_t_18 + 9] = _f_95;
      e.mem[_t_18 + 10] = _f_96;
      e.mem[_t_18 + 11] = _f_97;
      e.mem[_t_18 + 12] = _f_98;
      e.mem[_t_18 + 13] = _f_99;
      e.mem[_t_18 + 14] = _f_100;
      e.mem[_t_18 + 15] = _f_101;
      e.mem[_t_18 + 16] = _f_102;
      e.mem[_t_18 + 17] = _f_103;
      e.mem[_t_18 + 18] = _v_233;
      e.mem[_t_18 + 19] = _h_26;
      e.mem[_t_18 + 20] = _h_27;
      e.mem[_t_18 + 21] = _h_28;
      e.mem[_t_18 + 22] = _h_29;
      e.mem[_t_18 + 23] = _h_30;
      WL_CONT = term_tsk(FID_RUN_K189, _t_18);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_19 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_25;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_19);
    }
    r0 = _h_25;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K189)
  {
    WL_POPN(24);
    u32 _v_234 = STK(0);
    u32 _v_235 = STK(1);
    u32 _v_236 = STK(2);
    u32 _v_237 = STK(3);
    u32 _v_238 = STK(4);
    u32 _v_239 = STK(5);
    u32 _v_240 = STK(6);
    u32 _v_241 = STK(7);
    u32 _f_104 = STK(8);
    u32 _f_105 = STK(9);
    u32 _f_106 = STK(10);
    u32 _f_107 = STK(11);
    u32 _f_108 = STK(12);
    u32 _f_109 = STK(13);
    u32 _f_110 = STK(14);
    u32 _f_111 = STK(15);
    u32 _f_112 = STK(16);
    u32 _f_113 = STK(17);
    u32 _v_242 = STK(18);
    Term _h_32 = STK(19);
    Term _h_33 = STK(20);
    Term _h_34 = STK(21);
    Term _h_35 = STK(22);
    Term _h_36 = STK(23);
    Term _h_31 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _v_235;
      STK(1) = _v_236;
      STK(2) = _v_237;
      STK(3) = _v_238;
      STK(4) = _v_239;
      STK(5) = _v_240;
      STK(6) = _v_241;
      STK(7) = _f_104;
      STK(8) = _f_105;
      STK(9) = _f_106;
      STK(10) = _f_107;
      STK(11) = _f_108;
      STK(12) = _f_109;
      STK(13) = _f_110;
      STK(14) = _f_111;
      STK(15) = _f_112;
      STK(16) = _f_113;
      STK(17) = _v_242;
      STK(18) = _h_32;
      STK(19) = _h_33;
      STK(20) = _h_34;
      STK(21) = _h_35;
      STK(22) = _h_36;
      STK(23) = _h_31;
      STK(24) = FID_RUN_K190;
      WL_PUSHN(25);
    } else {
      u64 _t_20 = task_node(e, FID_RUN_K190, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _v_235;
      e.mem[_t_20 + 1] = _v_236;
      e.mem[_t_20 + 2] = _v_237;
      e.mem[_t_20 + 3] = _v_238;
      e.mem[_t_20 + 4] = _v_239;
      e.mem[_t_20 + 5] = _v_240;
      e.mem[_t_20 + 6] = _v_241;
      e.mem[_t_20 + 7] = _f_104;
      e.mem[_t_20 + 8] = _f_105;
      e.mem[_t_20 + 9] = _f_106;
      e.mem[_t_20 + 10] = _f_107;
      e.mem[_t_20 + 11] = _f_108;
      e.mem[_t_20 + 12] = _f_109;
      e.mem[_t_20 + 13] = _f_110;
      e.mem[_t_20 + 14] = _f_111;
      e.mem[_t_20 + 15] = _f_112;
      e.mem[_t_20 + 16] = _f_113;
      e.mem[_t_20 + 17] = _v_242;
      e.mem[_t_20 + 18] = _h_32;
      e.mem[_t_20 + 19] = _h_33;
      e.mem[_t_20 + 20] = _h_34;
      e.mem[_t_20 + 21] = _h_35;
      e.mem[_t_20 + 22] = _h_36;
      e.mem[_t_20 + 23] = _h_31;
      WL_CONT = term_tsk(FID_RUN_K190, _t_20);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_21 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _v_234;
      return term_tsk(FID_U32_SHOW, _t_21);
    }
    r0 = _v_234;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K190)
  {
    WL_POPN(24);
    u32 _v_243 = STK(0);
    u32 _v_244 = STK(1);
    u32 _v_245 = STK(2);
    u32 _v_246 = STK(3);
    u32 _v_247 = STK(4);
    u32 _v_248 = STK(5);
    u32 _v_249 = STK(6);
    u32 _f_114 = STK(7);
    u32 _f_115 = STK(8);
    u32 _f_116 = STK(9);
    u32 _f_117 = STK(10);
    u32 _f_118 = STK(11);
    u32 _f_119 = STK(12);
    u32 _f_120 = STK(13);
    u32 _f_121 = STK(14);
    u32 _f_122 = STK(15);
    u32 _f_123 = STK(16);
    u32 _v_250 = STK(17);
    Term _h_38 = STK(18);
    Term _h_39 = STK(19);
    Term _h_40 = STK(20);
    Term _h_41 = STK(21);
    Term _h_42 = STK(22);
    Term _h_43 = STK(23);
    Term _h_37 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _v_248;
      STK(1) = _v_249;
      STK(2) = _f_114;
      STK(3) = _f_115;
      STK(4) = _f_116;
      STK(5) = _f_117;
      STK(6) = _f_118;
      STK(7) = _f_119;
      STK(8) = _f_120;
      STK(9) = _f_121;
      STK(10) = _f_122;
      STK(11) = _f_123;
      STK(12) = _v_250;
      STK(13) = _h_38;
      STK(14) = _h_39;
      STK(15) = _h_40;
      STK(16) = _h_41;
      STK(17) = _h_42;
      STK(18) = _h_43;
      STK(19) = _h_37;
      STK(20) = FID_RUN_K191;
      WL_PUSHN(21);
    } else {
      u64 _t_22 = task_node(e, FID_RUN_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _v_248;
      e.mem[_t_22 + 1] = _v_249;
      e.mem[_t_22 + 2] = _f_114;
      e.mem[_t_22 + 3] = _f_115;
      e.mem[_t_22 + 4] = _f_116;
      e.mem[_t_22 + 5] = _f_117;
      e.mem[_t_22 + 6] = _f_118;
      e.mem[_t_22 + 7] = _f_119;
      e.mem[_t_22 + 8] = _f_120;
      e.mem[_t_22 + 9] = _f_121;
      e.mem[_t_22 + 10] = _f_122;
      e.mem[_t_22 + 11] = _f_123;
      e.mem[_t_22 + 12] = _v_250;
      e.mem[_t_22 + 13] = _h_38;
      e.mem[_t_22 + 14] = _h_39;
      e.mem[_t_22 + 15] = _h_40;
      e.mem[_t_22 + 16] = _h_41;
      e.mem[_t_22 + 17] = _h_42;
      e.mem[_t_22 + 18] = _h_43;
      e.mem[_t_22 + 19] = _h_37;
      WL_CONT = term_tsk(FID_RUN_K191, _t_22);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LEDGER)) {
      u64 _t_23 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _v_243;
      e.mem[_t_23 + 1] = _v_244;
      e.mem[_t_23 + 2] = _v_245;
      e.mem[_t_23 + 3] = _v_246;
      e.mem[_t_23 + 4] = _v_247;
      return term_tsk(FID_HOST_RENDER_RENDER_LEDGER, _t_23);
    }
    r0 = _v_243;
    r1 = _v_244;
    r2 = _v_245;
    r3 = _v_246;
    r4 = _v_247;
    WL_JMP(FID_HOST_RENDER_RENDER_LEDGER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K191)
  {
    WL_POPN(20);
    u32 _v_251 = STK(0);
    u32 _v_252 = STK(1);
    u32 _f_124 = STK(2);
    u32 _f_125 = STK(3);
    u32 _f_126 = STK(4);
    u32 _f_127 = STK(5);
    u32 _f_128 = STK(6);
    u32 _f_129 = STK(7);
    u32 _f_130 = STK(8);
    u32 _f_131 = STK(9);
    u32 _f_132 = STK(10);
    u32 _f_133 = STK(11);
    u32 _v_253 = STK(12);
    Term _h_45 = STK(13);
    Term _h_46 = STK(14);
    Term _h_47 = STK(15);
    Term _h_48 = STK(16);
    Term _h_49 = STK(17);
    Term _h_50 = STK(18);
    Term _h_51 = STK(19);
    Term _h_44 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _v_252;
      STK(1) = _f_124;
      STK(2) = _f_125;
      STK(3) = _f_126;
      STK(4) = _f_127;
      STK(5) = _f_128;
      STK(6) = _f_129;
      STK(7) = _f_130;
      STK(8) = _f_131;
      STK(9) = _f_132;
      STK(10) = _f_133;
      STK(11) = _v_253;
      STK(12) = _h_45;
      STK(13) = _h_46;
      STK(14) = _h_47;
      STK(15) = _h_48;
      STK(16) = _h_49;
      STK(17) = _h_50;
      STK(18) = _h_51;
      STK(19) = _h_44;
      STK(20) = FID_RUN_K192;
      WL_PUSHN(21);
    } else {
      u64 _t_24 = task_node(e, FID_RUN_K192, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _v_252;
      e.mem[_t_24 + 1] = _f_124;
      e.mem[_t_24 + 2] = _f_125;
      e.mem[_t_24 + 3] = _f_126;
      e.mem[_t_24 + 4] = _f_127;
      e.mem[_t_24 + 5] = _f_128;
      e.mem[_t_24 + 6] = _f_129;
      e.mem[_t_24 + 7] = _f_130;
      e.mem[_t_24 + 8] = _f_131;
      e.mem[_t_24 + 9] = _f_132;
      e.mem[_t_24 + 10] = _f_133;
      e.mem[_t_24 + 11] = _v_253;
      e.mem[_t_24 + 12] = _h_45;
      e.mem[_t_24 + 13] = _h_46;
      e.mem[_t_24 + 14] = _h_47;
      e.mem[_t_24 + 15] = _h_48;
      e.mem[_t_24 + 16] = _h_49;
      e.mem[_t_24 + 17] = _h_50;
      e.mem[_t_24 + 18] = _h_51;
      e.mem[_t_24 + 19] = _h_44;
      WL_CONT = term_tsk(FID_RUN_K192, _t_24);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_25 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _v_251;
      return term_tsk(FID_U32_SHOW, _t_25);
    }
    r0 = _v_251;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K192)
  {
    WL_POPN(20);
    u32 _v_254 = STK(0);
    u32 _f_134 = STK(1);
    u32 _f_135 = STK(2);
    u32 _f_136 = STK(3);
    u32 _f_137 = STK(4);
    u32 _f_138 = STK(5);
    u32 _f_139 = STK(6);
    u32 _f_140 = STK(7);
    u32 _f_141 = STK(8);
    u32 _f_142 = STK(9);
    u32 _f_143 = STK(10);
    u32 _v_255 = STK(11);
    Term _h_53 = STK(12);
    Term _h_54 = STK(13);
    Term _h_55 = STK(14);
    Term _h_56 = STK(15);
    Term _h_57 = STK(16);
    Term _h_58 = STK(17);
    Term _h_59 = STK(18);
    Term _h_60 = STK(19);
    Term _h_52 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_134;
      STK(1) = _f_135;
      STK(2) = _f_136;
      STK(3) = _f_137;
      STK(4) = _f_138;
      STK(5) = _f_139;
      STK(6) = _f_140;
      STK(7) = _f_141;
      STK(8) = _f_142;
      STK(9) = _f_143;
      STK(10) = _v_255;
      STK(11) = _h_53;
      STK(12) = _h_54;
      STK(13) = _h_55;
      STK(14) = _h_56;
      STK(15) = _h_57;
      STK(16) = _h_58;
      STK(17) = _h_59;
      STK(18) = _h_60;
      STK(19) = _h_52;
      STK(20) = FID_RUN_K193;
      WL_PUSHN(21);
    } else {
      u64 _t_26 = task_node(e, FID_RUN_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _f_134;
      e.mem[_t_26 + 1] = _f_135;
      e.mem[_t_26 + 2] = _f_136;
      e.mem[_t_26 + 3] = _f_137;
      e.mem[_t_26 + 4] = _f_138;
      e.mem[_t_26 + 5] = _f_139;
      e.mem[_t_26 + 6] = _f_140;
      e.mem[_t_26 + 7] = _f_141;
      e.mem[_t_26 + 8] = _f_142;
      e.mem[_t_26 + 9] = _f_143;
      e.mem[_t_26 + 10] = _v_255;
      e.mem[_t_26 + 11] = _h_53;
      e.mem[_t_26 + 12] = _h_54;
      e.mem[_t_26 + 13] = _h_55;
      e.mem[_t_26 + 14] = _h_56;
      e.mem[_t_26 + 15] = _h_57;
      e.mem[_t_26 + 16] = _h_58;
      e.mem[_t_26 + 17] = _h_59;
      e.mem[_t_26 + 18] = _h_60;
      e.mem[_t_26 + 19] = _h_52;
      WL_CONT = term_tsk(FID_RUN_K193, _t_26);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_27 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _v_254;
      return term_tsk(FID_U32_SHOW, _t_27);
    }
    r0 = _v_254;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K193)
  {
    WL_POPN(20);
    u32 _f_144 = STK(0);
    u32 _f_145 = STK(1);
    u32 _f_146 = STK(2);
    u32 _f_147 = STK(3);
    u32 _f_148 = STK(4);
    u32 _f_149 = STK(5);
    u32 _f_150 = STK(6);
    u32 _f_151 = STK(7);
    u32 _f_152 = STK(8);
    u32 _f_153 = STK(9);
    u32 _v_256 = STK(10);
    Term _h_62 = STK(11);
    Term _h_63 = STK(12);
    Term _h_64 = STK(13);
    Term _h_65 = STK(14);
    Term _h_66 = STK(15);
    Term _h_67 = STK(16);
    Term _h_68 = STK(17);
    Term _h_69 = STK(18);
    Term _h_70 = STK(19);
    Term _h_61 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_145;
      STK(1) = _f_146;
      STK(2) = _f_147;
      STK(3) = _f_148;
      STK(4) = _f_149;
      STK(5) = _f_150;
      STK(6) = _f_151;
      STK(7) = _f_152;
      STK(8) = _f_153;
      STK(9) = _v_256;
      STK(10) = _h_62;
      STK(11) = _h_63;
      STK(12) = _h_64;
      STK(13) = _h_65;
      STK(14) = _h_66;
      STK(15) = _h_67;
      STK(16) = _h_68;
      STK(17) = _h_69;
      STK(18) = _h_70;
      STK(19) = _h_61;
      STK(20) = FID_RUN_K194;
      WL_PUSHN(21);
    } else {
      u64 _t_28 = task_node(e, FID_RUN_K194, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _f_145;
      e.mem[_t_28 + 1] = _f_146;
      e.mem[_t_28 + 2] = _f_147;
      e.mem[_t_28 + 3] = _f_148;
      e.mem[_t_28 + 4] = _f_149;
      e.mem[_t_28 + 5] = _f_150;
      e.mem[_t_28 + 6] = _f_151;
      e.mem[_t_28 + 7] = _f_152;
      e.mem[_t_28 + 8] = _f_153;
      e.mem[_t_28 + 9] = _v_256;
      e.mem[_t_28 + 10] = _h_62;
      e.mem[_t_28 + 11] = _h_63;
      e.mem[_t_28 + 12] = _h_64;
      e.mem[_t_28 + 13] = _h_65;
      e.mem[_t_28 + 14] = _h_66;
      e.mem[_t_28 + 15] = _h_67;
      e.mem[_t_28 + 16] = _h_68;
      e.mem[_t_28 + 17] = _h_69;
      e.mem[_t_28 + 18] = _h_70;
      e.mem[_t_28 + 19] = _h_61;
      WL_CONT = term_tsk(FID_RUN_K194, _t_28);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_29 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _f_144;
      return term_tsk(FID_U32_SHOW, _t_29);
    }
    r0 = _f_144;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K194)
  {
    WL_POPN(20);
    u32 _f_154 = STK(0);
    u32 _f_155 = STK(1);
    u32 _f_156 = STK(2);
    u32 _f_157 = STK(3);
    u32 _f_158 = STK(4);
    u32 _f_159 = STK(5);
    u32 _f_160 = STK(6);
    u32 _f_161 = STK(7);
    u32 _f_162 = STK(8);
    u32 _v_257 = STK(9);
    Term _h_72 = STK(10);
    Term _h_73 = STK(11);
    Term _h_74 = STK(12);
    Term _h_75 = STK(13);
    Term _h_76 = STK(14);
    Term _h_77 = STK(15);
    Term _h_78 = STK(16);
    Term _h_79 = STK(17);
    Term _h_80 = STK(18);
    Term _h_81 = STK(19);
    Term _h_71 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_155;
      STK(1) = _f_156;
      STK(2) = _f_157;
      STK(3) = _f_158;
      STK(4) = _f_159;
      STK(5) = _f_160;
      STK(6) = _f_161;
      STK(7) = _f_162;
      STK(8) = _v_257;
      STK(9) = _h_72;
      STK(10) = _h_73;
      STK(11) = _h_74;
      STK(12) = _h_75;
      STK(13) = _h_76;
      STK(14) = _h_77;
      STK(15) = _h_78;
      STK(16) = _h_79;
      STK(17) = _h_80;
      STK(18) = _h_81;
      STK(19) = _h_71;
      STK(20) = FID_RUN_K195;
      WL_PUSHN(21);
    } else {
      u64 _t_30 = task_node(e, FID_RUN_K195, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _f_155;
      e.mem[_t_30 + 1] = _f_156;
      e.mem[_t_30 + 2] = _f_157;
      e.mem[_t_30 + 3] = _f_158;
      e.mem[_t_30 + 4] = _f_159;
      e.mem[_t_30 + 5] = _f_160;
      e.mem[_t_30 + 6] = _f_161;
      e.mem[_t_30 + 7] = _f_162;
      e.mem[_t_30 + 8] = _v_257;
      e.mem[_t_30 + 9] = _h_72;
      e.mem[_t_30 + 10] = _h_73;
      e.mem[_t_30 + 11] = _h_74;
      e.mem[_t_30 + 12] = _h_75;
      e.mem[_t_30 + 13] = _h_76;
      e.mem[_t_30 + 14] = _h_77;
      e.mem[_t_30 + 15] = _h_78;
      e.mem[_t_30 + 16] = _h_79;
      e.mem[_t_30 + 17] = _h_80;
      e.mem[_t_30 + 18] = _h_81;
      e.mem[_t_30 + 19] = _h_71;
      WL_CONT = term_tsk(FID_RUN_K195, _t_30);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_31 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _f_154;
      return term_tsk(FID_U32_SHOW, _t_31);
    }
    r0 = _f_154;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K195)
  {
    WL_POPN(20);
    u32 _f_163 = STK(0);
    u32 _f_164 = STK(1);
    u32 _f_165 = STK(2);
    u32 _f_166 = STK(3);
    u32 _f_167 = STK(4);
    u32 _f_168 = STK(5);
    u32 _f_169 = STK(6);
    u32 _f_170 = STK(7);
    u32 _v_258 = STK(8);
    Term _h_83 = STK(9);
    Term _h_84 = STK(10);
    Term _h_85 = STK(11);
    Term _h_86 = STK(12);
    Term _h_87 = STK(13);
    Term _h_88 = STK(14);
    Term _h_89 = STK(15);
    Term _h_90 = STK(16);
    Term _h_91 = STK(17);
    Term _h_92 = STK(18);
    Term _h_93 = STK(19);
    Term _h_82 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_164;
      STK(1) = _f_165;
      STK(2) = _f_166;
      STK(3) = _f_167;
      STK(4) = _f_168;
      STK(5) = _f_169;
      STK(6) = _f_170;
      STK(7) = _v_258;
      STK(8) = _h_83;
      STK(9) = _h_84;
      STK(10) = _h_85;
      STK(11) = _h_86;
      STK(12) = _h_87;
      STK(13) = _h_88;
      STK(14) = _h_89;
      STK(15) = _h_90;
      STK(16) = _h_91;
      STK(17) = _h_92;
      STK(18) = _h_93;
      STK(19) = _h_82;
      STK(20) = FID_RUN_K196;
      WL_PUSHN(21);
    } else {
      u64 _t_32 = task_node(e, FID_RUN_K196, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _f_164;
      e.mem[_t_32 + 1] = _f_165;
      e.mem[_t_32 + 2] = _f_166;
      e.mem[_t_32 + 3] = _f_167;
      e.mem[_t_32 + 4] = _f_168;
      e.mem[_t_32 + 5] = _f_169;
      e.mem[_t_32 + 6] = _f_170;
      e.mem[_t_32 + 7] = _v_258;
      e.mem[_t_32 + 8] = _h_83;
      e.mem[_t_32 + 9] = _h_84;
      e.mem[_t_32 + 10] = _h_85;
      e.mem[_t_32 + 11] = _h_86;
      e.mem[_t_32 + 12] = _h_87;
      e.mem[_t_32 + 13] = _h_88;
      e.mem[_t_32 + 14] = _h_89;
      e.mem[_t_32 + 15] = _h_90;
      e.mem[_t_32 + 16] = _h_91;
      e.mem[_t_32 + 17] = _h_92;
      e.mem[_t_32 + 18] = _h_93;
      e.mem[_t_32 + 19] = _h_82;
      WL_CONT = term_tsk(FID_RUN_K196, _t_32);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_33 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _f_163;
      return term_tsk(FID_U32_SHOW, _t_33);
    }
    r0 = _f_163;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K196)
  {
    WL_POPN(20);
    u32 _f_171 = STK(0);
    u32 _f_172 = STK(1);
    u32 _f_173 = STK(2);
    u32 _f_174 = STK(3);
    u32 _f_175 = STK(4);
    u32 _f_176 = STK(5);
    u32 _f_177 = STK(6);
    u32 _v_259 = STK(7);
    Term _h_95 = STK(8);
    Term _h_96 = STK(9);
    Term _h_97 = STK(10);
    Term _h_98 = STK(11);
    Term _h_99 = STK(12);
    Term _h_100 = STK(13);
    Term _h_101 = STK(14);
    Term _h_102 = STK(15);
    Term _h_103 = STK(16);
    Term _h_104 = STK(17);
    Term _h_105 = STK(18);
    Term _h_106 = STK(19);
    Term _h_94 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_172;
      STK(1) = _f_173;
      STK(2) = _f_174;
      STK(3) = _f_175;
      STK(4) = _f_176;
      STK(5) = _f_177;
      STK(6) = _v_259;
      STK(7) = _h_95;
      STK(8) = _h_96;
      STK(9) = _h_97;
      STK(10) = _h_98;
      STK(11) = _h_99;
      STK(12) = _h_100;
      STK(13) = _h_101;
      STK(14) = _h_102;
      STK(15) = _h_103;
      STK(16) = _h_104;
      STK(17) = _h_105;
      STK(18) = _h_106;
      STK(19) = _h_94;
      STK(20) = FID_RUN_K197;
      WL_PUSHN(21);
    } else {
      u64 _t_34 = task_node(e, FID_RUN_K197, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _f_172;
      e.mem[_t_34 + 1] = _f_173;
      e.mem[_t_34 + 2] = _f_174;
      e.mem[_t_34 + 3] = _f_175;
      e.mem[_t_34 + 4] = _f_176;
      e.mem[_t_34 + 5] = _f_177;
      e.mem[_t_34 + 6] = _v_259;
      e.mem[_t_34 + 7] = _h_95;
      e.mem[_t_34 + 8] = _h_96;
      e.mem[_t_34 + 9] = _h_97;
      e.mem[_t_34 + 10] = _h_98;
      e.mem[_t_34 + 11] = _h_99;
      e.mem[_t_34 + 12] = _h_100;
      e.mem[_t_34 + 13] = _h_101;
      e.mem[_t_34 + 14] = _h_102;
      e.mem[_t_34 + 15] = _h_103;
      e.mem[_t_34 + 16] = _h_104;
      e.mem[_t_34 + 17] = _h_105;
      e.mem[_t_34 + 18] = _h_106;
      e.mem[_t_34 + 19] = _h_94;
      WL_CONT = term_tsk(FID_RUN_K197, _t_34);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_35 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _f_171;
      return term_tsk(FID_U32_SHOW, _t_35);
    }
    r0 = _f_171;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K197)
  {
    WL_POPN(20);
    u32 _f_178 = STK(0);
    u32 _f_179 = STK(1);
    u32 _f_180 = STK(2);
    u32 _f_181 = STK(3);
    u32 _f_182 = STK(4);
    u32 _f_183 = STK(5);
    u32 _v_260 = STK(6);
    Term _h_108 = STK(7);
    Term _h_109 = STK(8);
    Term _h_110 = STK(9);
    Term _h_111 = STK(10);
    Term _h_112 = STK(11);
    Term _h_113 = STK(12);
    Term _h_114 = STK(13);
    Term _h_115 = STK(14);
    Term _h_116 = STK(15);
    Term _h_117 = STK(16);
    Term _h_118 = STK(17);
    Term _h_119 = STK(18);
    Term _h_120 = STK(19);
    Term _h_107 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_179;
      STK(1) = _f_180;
      STK(2) = _f_181;
      STK(3) = _f_182;
      STK(4) = _f_183;
      STK(5) = _v_260;
      STK(6) = _h_108;
      STK(7) = _h_109;
      STK(8) = _h_110;
      STK(9) = _h_111;
      STK(10) = _h_112;
      STK(11) = _h_113;
      STK(12) = _h_114;
      STK(13) = _h_115;
      STK(14) = _h_116;
      STK(15) = _h_117;
      STK(16) = _h_118;
      STK(17) = _h_119;
      STK(18) = _h_120;
      STK(19) = _h_107;
      STK(20) = FID_RUN_K198;
      WL_PUSHN(21);
    } else {
      u64 _t_36 = task_node(e, FID_RUN_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _f_179;
      e.mem[_t_36 + 1] = _f_180;
      e.mem[_t_36 + 2] = _f_181;
      e.mem[_t_36 + 3] = _f_182;
      e.mem[_t_36 + 4] = _f_183;
      e.mem[_t_36 + 5] = _v_260;
      e.mem[_t_36 + 6] = _h_108;
      e.mem[_t_36 + 7] = _h_109;
      e.mem[_t_36 + 8] = _h_110;
      e.mem[_t_36 + 9] = _h_111;
      e.mem[_t_36 + 10] = _h_112;
      e.mem[_t_36 + 11] = _h_113;
      e.mem[_t_36 + 12] = _h_114;
      e.mem[_t_36 + 13] = _h_115;
      e.mem[_t_36 + 14] = _h_116;
      e.mem[_t_36 + 15] = _h_117;
      e.mem[_t_36 + 16] = _h_118;
      e.mem[_t_36 + 17] = _h_119;
      e.mem[_t_36 + 18] = _h_120;
      e.mem[_t_36 + 19] = _h_107;
      WL_CONT = term_tsk(FID_RUN_K198, _t_36);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_37 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _f_178;
      return term_tsk(FID_U32_SHOW, _t_37);
    }
    r0 = _f_178;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K198)
  {
    WL_POPN(20);
    u32 _f_184 = STK(0);
    u32 _f_185 = STK(1);
    u32 _f_186 = STK(2);
    u32 _f_187 = STK(3);
    u32 _f_188 = STK(4);
    u32 _v_261 = STK(5);
    Term _h_122 = STK(6);
    Term _h_123 = STK(7);
    Term _h_124 = STK(8);
    Term _h_125 = STK(9);
    Term _h_126 = STK(10);
    Term _h_127 = STK(11);
    Term _h_128 = STK(12);
    Term _h_129 = STK(13);
    Term _h_130 = STK(14);
    Term _h_131 = STK(15);
    Term _h_132 = STK(16);
    Term _h_133 = STK(17);
    Term _h_134 = STK(18);
    Term _h_135 = STK(19);
    Term _h_121 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_185;
      STK(1) = _f_186;
      STK(2) = _f_187;
      STK(3) = _f_188;
      STK(4) = _v_261;
      STK(5) = _h_122;
      STK(6) = _h_123;
      STK(7) = _h_124;
      STK(8) = _h_125;
      STK(9) = _h_126;
      STK(10) = _h_127;
      STK(11) = _h_128;
      STK(12) = _h_129;
      STK(13) = _h_130;
      STK(14) = _h_131;
      STK(15) = _h_132;
      STK(16) = _h_133;
      STK(17) = _h_134;
      STK(18) = _h_135;
      STK(19) = _h_121;
      STK(20) = FID_RUN_K199;
      WL_PUSHN(21);
    } else {
      u64 _t_38 = task_node(e, FID_RUN_K199, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _f_185;
      e.mem[_t_38 + 1] = _f_186;
      e.mem[_t_38 + 2] = _f_187;
      e.mem[_t_38 + 3] = _f_188;
      e.mem[_t_38 + 4] = _v_261;
      e.mem[_t_38 + 5] = _h_122;
      e.mem[_t_38 + 6] = _h_123;
      e.mem[_t_38 + 7] = _h_124;
      e.mem[_t_38 + 8] = _h_125;
      e.mem[_t_38 + 9] = _h_126;
      e.mem[_t_38 + 10] = _h_127;
      e.mem[_t_38 + 11] = _h_128;
      e.mem[_t_38 + 12] = _h_129;
      e.mem[_t_38 + 13] = _h_130;
      e.mem[_t_38 + 14] = _h_131;
      e.mem[_t_38 + 15] = _h_132;
      e.mem[_t_38 + 16] = _h_133;
      e.mem[_t_38 + 17] = _h_134;
      e.mem[_t_38 + 18] = _h_135;
      e.mem[_t_38 + 19] = _h_121;
      WL_CONT = term_tsk(FID_RUN_K199, _t_38);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_39 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _f_184;
      return term_tsk(FID_U32_SHOW, _t_39);
    }
    r0 = _f_184;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K199)
  {
    WL_POPN(20);
    u32 _f_189 = STK(0);
    u32 _f_190 = STK(1);
    u32 _f_191 = STK(2);
    u32 _f_192 = STK(3);
    u32 _v_262 = STK(4);
    Term _h_137 = STK(5);
    Term _h_138 = STK(6);
    Term _h_139 = STK(7);
    Term _h_140 = STK(8);
    Term _h_141 = STK(9);
    Term _h_142 = STK(10);
    Term _h_143 = STK(11);
    Term _h_144 = STK(12);
    Term _h_145 = STK(13);
    Term _h_146 = STK(14);
    Term _h_147 = STK(15);
    Term _h_148 = STK(16);
    Term _h_149 = STK(17);
    Term _h_150 = STK(18);
    Term _h_151 = STK(19);
    Term _h_136 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_190;
      STK(1) = _f_191;
      STK(2) = _f_192;
      STK(3) = _v_262;
      STK(4) = _h_137;
      STK(5) = _h_138;
      STK(6) = _h_139;
      STK(7) = _h_140;
      STK(8) = _h_141;
      STK(9) = _h_142;
      STK(10) = _h_143;
      STK(11) = _h_144;
      STK(12) = _h_145;
      STK(13) = _h_146;
      STK(14) = _h_147;
      STK(15) = _h_148;
      STK(16) = _h_149;
      STK(17) = _h_150;
      STK(18) = _h_151;
      STK(19) = _h_136;
      STK(20) = FID_RUN_K200;
      WL_PUSHN(21);
    } else {
      u64 _t_40 = task_node(e, FID_RUN_K200, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _f_190;
      e.mem[_t_40 + 1] = _f_191;
      e.mem[_t_40 + 2] = _f_192;
      e.mem[_t_40 + 3] = _v_262;
      e.mem[_t_40 + 4] = _h_137;
      e.mem[_t_40 + 5] = _h_138;
      e.mem[_t_40 + 6] = _h_139;
      e.mem[_t_40 + 7] = _h_140;
      e.mem[_t_40 + 8] = _h_141;
      e.mem[_t_40 + 9] = _h_142;
      e.mem[_t_40 + 10] = _h_143;
      e.mem[_t_40 + 11] = _h_144;
      e.mem[_t_40 + 12] = _h_145;
      e.mem[_t_40 + 13] = _h_146;
      e.mem[_t_40 + 14] = _h_147;
      e.mem[_t_40 + 15] = _h_148;
      e.mem[_t_40 + 16] = _h_149;
      e.mem[_t_40 + 17] = _h_150;
      e.mem[_t_40 + 18] = _h_151;
      e.mem[_t_40 + 19] = _h_136;
      WL_CONT = term_tsk(FID_RUN_K200, _t_40);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_41 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = _f_189;
      return term_tsk(FID_U32_SHOW, _t_41);
    }
    r0 = _f_189;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K200)
  {
    WL_POPN(20);
    u32 _f_193 = STK(0);
    u32 _f_194 = STK(1);
    u32 _f_195 = STK(2);
    u32 _v_263 = STK(3);
    Term _h_153 = STK(4);
    Term _h_154 = STK(5);
    Term _h_155 = STK(6);
    Term _h_156 = STK(7);
    Term _h_157 = STK(8);
    Term _h_158 = STK(9);
    Term _h_159 = STK(10);
    Term _h_160 = STK(11);
    Term _h_161 = STK(12);
    Term _h_162 = STK(13);
    Term _h_163 = STK(14);
    Term _h_164 = STK(15);
    Term _h_165 = STK(16);
    Term _h_166 = STK(17);
    Term _h_167 = STK(18);
    Term _h_168 = STK(19);
    Term _h_152 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_194;
      STK(1) = _f_195;
      STK(2) = _v_263;
      STK(3) = _h_153;
      STK(4) = _h_154;
      STK(5) = _h_155;
      STK(6) = _h_156;
      STK(7) = _h_157;
      STK(8) = _h_158;
      STK(9) = _h_159;
      STK(10) = _h_160;
      STK(11) = _h_161;
      STK(12) = _h_162;
      STK(13) = _h_163;
      STK(14) = _h_164;
      STK(15) = _h_165;
      STK(16) = _h_166;
      STK(17) = _h_167;
      STK(18) = _h_168;
      STK(19) = _h_152;
      STK(20) = FID_RUN_K201;
      WL_PUSHN(21);
    } else {
      u64 _t_42 = task_node(e, FID_RUN_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _f_194;
      e.mem[_t_42 + 1] = _f_195;
      e.mem[_t_42 + 2] = _v_263;
      e.mem[_t_42 + 3] = _h_153;
      e.mem[_t_42 + 4] = _h_154;
      e.mem[_t_42 + 5] = _h_155;
      e.mem[_t_42 + 6] = _h_156;
      e.mem[_t_42 + 7] = _h_157;
      e.mem[_t_42 + 8] = _h_158;
      e.mem[_t_42 + 9] = _h_159;
      e.mem[_t_42 + 10] = _h_160;
      e.mem[_t_42 + 11] = _h_161;
      e.mem[_t_42 + 12] = _h_162;
      e.mem[_t_42 + 13] = _h_163;
      e.mem[_t_42 + 14] = _h_164;
      e.mem[_t_42 + 15] = _h_165;
      e.mem[_t_42 + 16] = _h_166;
      e.mem[_t_42 + 17] = _h_167;
      e.mem[_t_42 + 18] = _h_168;
      e.mem[_t_42 + 19] = _h_152;
      WL_CONT = term_tsk(FID_RUN_K201, _t_42);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_43 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _f_193;
      return term_tsk(FID_U32_SHOW, _t_43);
    }
    r0 = _f_193;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K201)
  {
    WL_POPN(20);
    u32 _f_196 = STK(0);
    u32 _f_197 = STK(1);
    u32 _v_264 = STK(2);
    Term _h_170 = STK(3);
    Term _h_171 = STK(4);
    Term _h_172 = STK(5);
    Term _h_173 = STK(6);
    Term _h_174 = STK(7);
    Term _h_175 = STK(8);
    Term _h_176 = STK(9);
    Term _h_177 = STK(10);
    Term _h_178 = STK(11);
    Term _h_179 = STK(12);
    Term _h_180 = STK(13);
    Term _h_181 = STK(14);
    Term _h_182 = STK(15);
    Term _h_183 = STK(16);
    Term _h_184 = STK(17);
    Term _h_185 = STK(18);
    Term _h_186 = STK(19);
    Term _h_169 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _f_197;
      STK(1) = _v_264;
      STK(2) = _h_170;
      STK(3) = _h_171;
      STK(4) = _h_172;
      STK(5) = _h_173;
      STK(6) = _h_174;
      STK(7) = _h_175;
      STK(8) = _h_176;
      STK(9) = _h_177;
      STK(10) = _h_178;
      STK(11) = _h_179;
      STK(12) = _h_180;
      STK(13) = _h_181;
      STK(14) = _h_182;
      STK(15) = _h_183;
      STK(16) = _h_184;
      STK(17) = _h_185;
      STK(18) = _h_186;
      STK(19) = _h_169;
      STK(20) = FID_RUN_K202;
      WL_PUSHN(21);
    } else {
      u64 _t_44 = task_node(e, FID_RUN_K202, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _f_197;
      e.mem[_t_44 + 1] = _v_264;
      e.mem[_t_44 + 2] = _h_170;
      e.mem[_t_44 + 3] = _h_171;
      e.mem[_t_44 + 4] = _h_172;
      e.mem[_t_44 + 5] = _h_173;
      e.mem[_t_44 + 6] = _h_174;
      e.mem[_t_44 + 7] = _h_175;
      e.mem[_t_44 + 8] = _h_176;
      e.mem[_t_44 + 9] = _h_177;
      e.mem[_t_44 + 10] = _h_178;
      e.mem[_t_44 + 11] = _h_179;
      e.mem[_t_44 + 12] = _h_180;
      e.mem[_t_44 + 13] = _h_181;
      e.mem[_t_44 + 14] = _h_182;
      e.mem[_t_44 + 15] = _h_183;
      e.mem[_t_44 + 16] = _h_184;
      e.mem[_t_44 + 17] = _h_185;
      e.mem[_t_44 + 18] = _h_186;
      e.mem[_t_44 + 19] = _h_169;
      WL_CONT = term_tsk(FID_RUN_K202, _t_44);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_45 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _f_196;
      return term_tsk(FID_U32_SHOW, _t_45);
    }
    r0 = _f_196;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K202)
  {
    WL_POPN(20);
    u32 _f_198 = STK(0);
    u32 _v_265 = STK(1);
    Term _h_188 = STK(2);
    Term _h_189 = STK(3);
    Term _h_190 = STK(4);
    Term _h_191 = STK(5);
    Term _h_192 = STK(6);
    Term _h_193 = STK(7);
    Term _h_194 = STK(8);
    Term _h_195 = STK(9);
    Term _h_196 = STK(10);
    Term _h_197 = STK(11);
    Term _h_198 = STK(12);
    Term _h_199 = STK(13);
    Term _h_200 = STK(14);
    Term _h_201 = STK(15);
    Term _h_202 = STK(16);
    Term _h_203 = STK(17);
    Term _h_204 = STK(18);
    Term _h_205 = STK(19);
    Term _h_187 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _v_265;
      STK(1) = _h_188;
      STK(2) = _h_189;
      STK(3) = _h_190;
      STK(4) = _h_191;
      STK(5) = _h_192;
      STK(6) = _h_193;
      STK(7) = _h_194;
      STK(8) = _h_195;
      STK(9) = _h_196;
      STK(10) = _h_197;
      STK(11) = _h_198;
      STK(12) = _h_199;
      STK(13) = _h_200;
      STK(14) = _h_201;
      STK(15) = _h_202;
      STK(16) = _h_203;
      STK(17) = _h_204;
      STK(18) = _h_205;
      STK(19) = _h_187;
      STK(20) = FID_RUN_K203;
      WL_PUSHN(21);
    } else {
      u64 _t_46 = task_node(e, FID_RUN_K203, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _v_265;
      e.mem[_t_46 + 1] = _h_188;
      e.mem[_t_46 + 2] = _h_189;
      e.mem[_t_46 + 3] = _h_190;
      e.mem[_t_46 + 4] = _h_191;
      e.mem[_t_46 + 5] = _h_192;
      e.mem[_t_46 + 6] = _h_193;
      e.mem[_t_46 + 7] = _h_194;
      e.mem[_t_46 + 8] = _h_195;
      e.mem[_t_46 + 9] = _h_196;
      e.mem[_t_46 + 10] = _h_197;
      e.mem[_t_46 + 11] = _h_198;
      e.mem[_t_46 + 12] = _h_199;
      e.mem[_t_46 + 13] = _h_200;
      e.mem[_t_46 + 14] = _h_201;
      e.mem[_t_46 + 15] = _h_202;
      e.mem[_t_46 + 16] = _h_203;
      e.mem[_t_46 + 17] = _h_204;
      e.mem[_t_46 + 18] = _h_205;
      e.mem[_t_46 + 19] = _h_187;
      WL_CONT = term_tsk(FID_RUN_K203, _t_46);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_47 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _f_198;
      return term_tsk(FID_U32_SHOW, _t_47);
    }
    r0 = _f_198;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K203)
  {
    WL_POPN(20);
    u32 _v_266 = STK(0);
    Term _h_207 = STK(1);
    Term _h_208 = STK(2);
    Term _h_209 = STK(3);
    Term _h_210 = STK(4);
    Term _h_211 = STK(5);
    Term _h_212 = STK(6);
    Term _h_213 = STK(7);
    Term _h_214 = STK(8);
    Term _h_215 = STK(9);
    Term _h_216 = STK(10);
    Term _h_217 = STK(11);
    Term _h_218 = STK(12);
    Term _h_219 = STK(13);
    Term _h_220 = STK(14);
    Term _h_221 = STK(15);
    Term _h_222 = STK(16);
    Term _h_223 = STK(17);
    Term _h_224 = STK(18);
    Term _h_225 = STK(19);
    Term _h_206 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_207;
      STK(1) = _h_208;
      STK(2) = _h_209;
      STK(3) = _h_210;
      STK(4) = _h_211;
      STK(5) = _h_212;
      STK(6) = _h_213;
      STK(7) = _h_214;
      STK(8) = _h_215;
      STK(9) = _h_216;
      STK(10) = _h_217;
      STK(11) = _h_218;
      STK(12) = _h_219;
      STK(13) = _h_220;
      STK(14) = _h_221;
      STK(15) = _h_222;
      STK(16) = _h_223;
      STK(17) = _h_224;
      STK(18) = _h_225;
      STK(19) = _h_206;
      STK(20) = FID_RUN_K204;
      WL_PUSHN(21);
    } else {
      u64 _t_48 = task_node(e, FID_RUN_K204, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_207;
      e.mem[_t_48 + 1] = _h_208;
      e.mem[_t_48 + 2] = _h_209;
      e.mem[_t_48 + 3] = _h_210;
      e.mem[_t_48 + 4] = _h_211;
      e.mem[_t_48 + 5] = _h_212;
      e.mem[_t_48 + 6] = _h_213;
      e.mem[_t_48 + 7] = _h_214;
      e.mem[_t_48 + 8] = _h_215;
      e.mem[_t_48 + 9] = _h_216;
      e.mem[_t_48 + 10] = _h_217;
      e.mem[_t_48 + 11] = _h_218;
      e.mem[_t_48 + 12] = _h_219;
      e.mem[_t_48 + 13] = _h_220;
      e.mem[_t_48 + 14] = _h_221;
      e.mem[_t_48 + 15] = _h_222;
      e.mem[_t_48 + 16] = _h_223;
      e.mem[_t_48 + 17] = _h_224;
      e.mem[_t_48 + 18] = _h_225;
      e.mem[_t_48 + 19] = _h_206;
      WL_CONT = term_tsk(FID_RUN_K204, _t_48);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_49 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = _v_266;
      return term_tsk(FID_U32_SHOW, _t_49);
    }
    r0 = _v_266;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K204)
  {
    WL_POPN(20);
    Term _h_227 = STK(0);
    Term _h_228 = STK(1);
    Term _h_229 = STK(2);
    Term _h_230 = STK(3);
    Term _h_231 = STK(4);
    Term _h_232 = STK(5);
    Term _h_233 = STK(6);
    Term _h_234 = STK(7);
    Term _h_235 = STK(8);
    Term _h_236 = STK(9);
    Term _h_237 = STK(10);
    Term _h_238 = STK(11);
    Term _h_239 = STK(12);
    Term _h_240 = STK(13);
    Term _h_241 = STK(14);
    Term _h_242 = STK(15);
    Term _h_243 = STK(16);
    Term _h_244 = STK(17);
    Term _h_245 = STK(18);
    Term _h_246 = STK(19);
    Term _h_226 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_227;
      STK(1) = _h_228;
      STK(2) = _h_229;
      STK(3) = _h_230;
      STK(4) = _h_231;
      STK(5) = _h_232;
      STK(6) = _h_233;
      STK(7) = _h_234;
      STK(8) = _h_235;
      STK(9) = _h_236;
      STK(10) = _h_237;
      STK(11) = _h_238;
      STK(12) = _h_239;
      STK(13) = _h_240;
      STK(14) = _h_241;
      STK(15) = _h_242;
      STK(16) = _h_243;
      STK(17) = _h_244;
      STK(18) = _h_245;
      STK(19) = _h_246;
      STK(20) = FID_RUN_K205;
      WL_PUSHN(21);
    } else {
      u64 _t_50 = task_node(e, FID_RUN_K205, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_227;
      e.mem[_t_50 + 1] = _h_228;
      e.mem[_t_50 + 2] = _h_229;
      e.mem[_t_50 + 3] = _h_230;
      e.mem[_t_50 + 4] = _h_231;
      e.mem[_t_50 + 5] = _h_232;
      e.mem[_t_50 + 6] = _h_233;
      e.mem[_t_50 + 7] = _h_234;
      e.mem[_t_50 + 8] = _h_235;
      e.mem[_t_50 + 9] = _h_236;
      e.mem[_t_50 + 10] = _h_237;
      e.mem[_t_50 + 11] = _h_238;
      e.mem[_t_50 + 12] = _h_239;
      e.mem[_t_50 + 13] = _h_240;
      e.mem[_t_50 + 14] = _h_241;
      e.mem[_t_50 + 15] = _h_242;
      e.mem[_t_50 + 16] = _h_243;
      e.mem[_t_50 + 17] = _h_244;
      e.mem[_t_50 + 18] = _h_245;
      e.mem[_t_50 + 19] = _h_246;
      WL_CONT = term_tsk(FID_RUN_K205, _t_50);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _h_226;
      e.mem[_t_51 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = _h_226;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K205)
  {
    WL_POPN(20);
    Term _h_248 = STK(0);
    Term _h_249 = STK(1);
    Term _h_250 = STK(2);
    Term _h_251 = STK(3);
    Term _h_252 = STK(4);
    Term _h_253 = STK(5);
    Term _h_254 = STK(6);
    Term _h_255 = STK(7);
    Term _h_256 = STK(8);
    Term _h_257 = STK(9);
    Term _h_258 = STK(10);
    Term _h_259 = STK(11);
    Term _h_260 = STK(12);
    Term _h_261 = STK(13);
    Term _h_262 = STK(14);
    Term _h_263 = STK(15);
    Term _h_264 = STK(16);
    Term _h_265 = STK(17);
    Term _h_266 = STK(18);
    Term _h_267 = STK(19);
    Term _h_247 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_248;
      STK(1) = _h_249;
      STK(2) = _h_250;
      STK(3) = _h_251;
      STK(4) = _h_252;
      STK(5) = _h_253;
      STK(6) = _h_254;
      STK(7) = _h_255;
      STK(8) = _h_256;
      STK(9) = _h_257;
      STK(10) = _h_258;
      STK(11) = _h_259;
      STK(12) = _h_260;
      STK(13) = _h_261;
      STK(14) = _h_262;
      STK(15) = _h_263;
      STK(16) = _h_264;
      STK(17) = _h_265;
      STK(18) = _h_266;
      STK(19) = _h_267;
      STK(20) = FID_RUN_K206;
      WL_PUSHN(21);
    } else {
      u64 _t_52 = task_node(e, FID_RUN_K206, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_248;
      e.mem[_t_52 + 1] = _h_249;
      e.mem[_t_52 + 2] = _h_250;
      e.mem[_t_52 + 3] = _h_251;
      e.mem[_t_52 + 4] = _h_252;
      e.mem[_t_52 + 5] = _h_253;
      e.mem[_t_52 + 6] = _h_254;
      e.mem[_t_52 + 7] = _h_255;
      e.mem[_t_52 + 8] = _h_256;
      e.mem[_t_52 + 9] = _h_257;
      e.mem[_t_52 + 10] = _h_258;
      e.mem[_t_52 + 11] = _h_259;
      e.mem[_t_52 + 12] = _h_260;
      e.mem[_t_52 + 13] = _h_261;
      e.mem[_t_52 + 14] = _h_262;
      e.mem[_t_52 + 15] = _h_263;
      e.mem[_t_52 + 16] = _h_264;
      e.mem[_t_52 + 17] = _h_265;
      e.mem[_t_52 + 18] = _h_266;
      e.mem[_t_52 + 19] = _h_267;
      WL_CONT = term_tsk(FID_RUN_K206, _t_52);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 136);
      e.mem[_t_53 + 1] = _h_247;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 136);
    r1 = _h_247;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K206)
  {
    WL_POPN(20);
    Term _h_269 = STK(0);
    Term _h_270 = STK(1);
    Term _h_271 = STK(2);
    Term _h_272 = STK(3);
    Term _h_273 = STK(4);
    Term _h_274 = STK(5);
    Term _h_275 = STK(6);
    Term _h_276 = STK(7);
    Term _h_277 = STK(8);
    Term _h_278 = STK(9);
    Term _h_279 = STK(10);
    Term _h_280 = STK(11);
    Term _h_281 = STK(12);
    Term _h_282 = STK(13);
    Term _h_283 = STK(14);
    Term _h_284 = STK(15);
    Term _h_285 = STK(16);
    Term _h_286 = STK(17);
    Term _h_287 = STK(18);
    Term _h_288 = STK(19);
    Term _h_268 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_269;
      STK(1) = _h_270;
      STK(2) = _h_271;
      STK(3) = _h_272;
      STK(4) = _h_273;
      STK(5) = _h_274;
      STK(6) = _h_275;
      STK(7) = _h_276;
      STK(8) = _h_277;
      STK(9) = _h_278;
      STK(10) = _h_279;
      STK(11) = _h_280;
      STK(12) = _h_281;
      STK(13) = _h_282;
      STK(14) = _h_283;
      STK(15) = _h_284;
      STK(16) = _h_285;
      STK(17) = _h_286;
      STK(18) = _h_287;
      STK(19) = FID_RUN_K207;
      WL_PUSHN(20);
    } else {
      u64 _t_54 = task_node(e, FID_RUN_K207, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_269;
      e.mem[_t_54 + 1] = _h_270;
      e.mem[_t_54 + 2] = _h_271;
      e.mem[_t_54 + 3] = _h_272;
      e.mem[_t_54 + 4] = _h_273;
      e.mem[_t_54 + 5] = _h_274;
      e.mem[_t_54 + 6] = _h_275;
      e.mem[_t_54 + 7] = _h_276;
      e.mem[_t_54 + 8] = _h_277;
      e.mem[_t_54 + 9] = _h_278;
      e.mem[_t_54 + 10] = _h_279;
      e.mem[_t_54 + 11] = _h_280;
      e.mem[_t_54 + 12] = _h_281;
      e.mem[_t_54 + 13] = _h_282;
      e.mem[_t_54 + 14] = _h_283;
      e.mem[_t_54 + 15] = _h_284;
      e.mem[_t_54 + 16] = _h_285;
      e.mem[_t_54 + 17] = _h_286;
      e.mem[_t_54 + 18] = _h_287;
      WL_CONT = term_tsk(FID_RUN_K207, _t_54);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = _h_288;
      e.mem[_t_55 + 1] = _h_268;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = _h_288;
    r1 = _h_268;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K207)
  {
    WL_POPN(19);
    Term _h_290 = STK(0);
    Term _h_291 = STK(1);
    Term _h_292 = STK(2);
    Term _h_293 = STK(3);
    Term _h_294 = STK(4);
    Term _h_295 = STK(5);
    Term _h_296 = STK(6);
    Term _h_297 = STK(7);
    Term _h_298 = STK(8);
    Term _h_299 = STK(9);
    Term _h_300 = STK(10);
    Term _h_301 = STK(11);
    Term _h_302 = STK(12);
    Term _h_303 = STK(13);
    Term _h_304 = STK(14);
    Term _h_305 = STK(15);
    Term _h_306 = STK(16);
    Term _h_307 = STK(17);
    Term _h_308 = STK(18);
    Term _h_289 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_290;
      STK(1) = _h_291;
      STK(2) = _h_292;
      STK(3) = _h_293;
      STK(4) = _h_294;
      STK(5) = _h_295;
      STK(6) = _h_296;
      STK(7) = _h_297;
      STK(8) = _h_298;
      STK(9) = _h_299;
      STK(10) = _h_300;
      STK(11) = _h_301;
      STK(12) = _h_302;
      STK(13) = _h_303;
      STK(14) = _h_304;
      STK(15) = _h_305;
      STK(16) = _h_306;
      STK(17) = _h_307;
      STK(18) = _h_308;
      STK(19) = FID_RUN_K208;
      WL_PUSHN(20);
    } else {
      u64 _t_56 = task_node(e, FID_RUN_K208, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_290;
      e.mem[_t_56 + 1] = _h_291;
      e.mem[_t_56 + 2] = _h_292;
      e.mem[_t_56 + 3] = _h_293;
      e.mem[_t_56 + 4] = _h_294;
      e.mem[_t_56 + 5] = _h_295;
      e.mem[_t_56 + 6] = _h_296;
      e.mem[_t_56 + 7] = _h_297;
      e.mem[_t_56 + 8] = _h_298;
      e.mem[_t_56 + 9] = _h_299;
      e.mem[_t_56 + 10] = _h_300;
      e.mem[_t_56 + 11] = _h_301;
      e.mem[_t_56 + 12] = _h_302;
      e.mem[_t_56 + 13] = _h_303;
      e.mem[_t_56 + 14] = _h_304;
      e.mem[_t_56 + 15] = _h_305;
      e.mem[_t_56 + 16] = _h_306;
      e.mem[_t_56 + 17] = _h_307;
      e.mem[_t_56 + 18] = _h_308;
      WL_CONT = term_tsk(FID_RUN_K208, _t_56);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_57 + 1] = _h_289;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_289;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K208)
  {
    WL_POPN(19);
    Term _h_310 = STK(0);
    Term _h_311 = STK(1);
    Term _h_312 = STK(2);
    Term _h_313 = STK(3);
    Term _h_314 = STK(4);
    Term _h_315 = STK(5);
    Term _h_316 = STK(6);
    Term _h_317 = STK(7);
    Term _h_318 = STK(8);
    Term _h_319 = STK(9);
    Term _h_320 = STK(10);
    Term _h_321 = STK(11);
    Term _h_322 = STK(12);
    Term _h_323 = STK(13);
    Term _h_324 = STK(14);
    Term _h_325 = STK(15);
    Term _h_326 = STK(16);
    Term _h_327 = STK(17);
    Term _h_328 = STK(18);
    Term _h_309 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_310;
      STK(1) = _h_311;
      STK(2) = _h_312;
      STK(3) = _h_313;
      STK(4) = _h_314;
      STK(5) = _h_315;
      STK(6) = _h_316;
      STK(7) = _h_317;
      STK(8) = _h_318;
      STK(9) = _h_319;
      STK(10) = _h_320;
      STK(11) = _h_321;
      STK(12) = _h_322;
      STK(13) = _h_323;
      STK(14) = _h_324;
      STK(15) = _h_325;
      STK(16) = _h_326;
      STK(17) = _h_327;
      STK(18) = FID_RUN_K209;
      WL_PUSHN(19);
    } else {
      u64 _t_58 = task_node(e, FID_RUN_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_310;
      e.mem[_t_58 + 1] = _h_311;
      e.mem[_t_58 + 2] = _h_312;
      e.mem[_t_58 + 3] = _h_313;
      e.mem[_t_58 + 4] = _h_314;
      e.mem[_t_58 + 5] = _h_315;
      e.mem[_t_58 + 6] = _h_316;
      e.mem[_t_58 + 7] = _h_317;
      e.mem[_t_58 + 8] = _h_318;
      e.mem[_t_58 + 9] = _h_319;
      e.mem[_t_58 + 10] = _h_320;
      e.mem[_t_58 + 11] = _h_321;
      e.mem[_t_58 + 12] = _h_322;
      e.mem[_t_58 + 13] = _h_323;
      e.mem[_t_58 + 14] = _h_324;
      e.mem[_t_58 + 15] = _h_325;
      e.mem[_t_58 + 16] = _h_326;
      e.mem[_t_58 + 17] = _h_327;
      WL_CONT = term_tsk(FID_RUN_K209, _t_58);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = _h_328;
      e.mem[_t_59 + 1] = _h_309;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = _h_328;
    r1 = _h_309;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K209)
  {
    WL_POPN(18);
    Term _h_330 = STK(0);
    Term _h_331 = STK(1);
    Term _h_332 = STK(2);
    Term _h_333 = STK(3);
    Term _h_334 = STK(4);
    Term _h_335 = STK(5);
    Term _h_336 = STK(6);
    Term _h_337 = STK(7);
    Term _h_338 = STK(8);
    Term _h_339 = STK(9);
    Term _h_340 = STK(10);
    Term _h_341 = STK(11);
    Term _h_342 = STK(12);
    Term _h_343 = STK(13);
    Term _h_344 = STK(14);
    Term _h_345 = STK(15);
    Term _h_346 = STK(16);
    Term _h_347 = STK(17);
    Term _h_329 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_330;
      STK(1) = _h_331;
      STK(2) = _h_332;
      STK(3) = _h_333;
      STK(4) = _h_334;
      STK(5) = _h_335;
      STK(6) = _h_336;
      STK(7) = _h_337;
      STK(8) = _h_338;
      STK(9) = _h_339;
      STK(10) = _h_340;
      STK(11) = _h_341;
      STK(12) = _h_342;
      STK(13) = _h_343;
      STK(14) = _h_344;
      STK(15) = _h_345;
      STK(16) = _h_346;
      STK(17) = _h_347;
      STK(18) = FID_RUN_K210;
      WL_PUSHN(19);
    } else {
      u64 _t_60 = task_node(e, FID_RUN_K210, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_330;
      e.mem[_t_60 + 1] = _h_331;
      e.mem[_t_60 + 2] = _h_332;
      e.mem[_t_60 + 3] = _h_333;
      e.mem[_t_60 + 4] = _h_334;
      e.mem[_t_60 + 5] = _h_335;
      e.mem[_t_60 + 6] = _h_336;
      e.mem[_t_60 + 7] = _h_337;
      e.mem[_t_60 + 8] = _h_338;
      e.mem[_t_60 + 9] = _h_339;
      e.mem[_t_60 + 10] = _h_340;
      e.mem[_t_60 + 11] = _h_341;
      e.mem[_t_60 + 12] = _h_342;
      e.mem[_t_60 + 13] = _h_343;
      e.mem[_t_60 + 14] = _h_344;
      e.mem[_t_60 + 15] = _h_345;
      e.mem[_t_60 + 16] = _h_346;
      e.mem[_t_60 + 17] = _h_347;
      WL_CONT = term_tsk(FID_RUN_K210, _t_60);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_61 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = term_ctr(CID_SCON, STAT_OFF + 140);
      e.mem[_t_61 + 1] = _h_329;
      return term_tsk(FID_STRING_APPEND, _t_61);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 140);
    r1 = _h_329;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K210)
  {
    WL_POPN(18);
    Term _h_349 = STK(0);
    Term _h_350 = STK(1);
    Term _h_351 = STK(2);
    Term _h_352 = STK(3);
    Term _h_353 = STK(4);
    Term _h_354 = STK(5);
    Term _h_355 = STK(6);
    Term _h_356 = STK(7);
    Term _h_357 = STK(8);
    Term _h_358 = STK(9);
    Term _h_359 = STK(10);
    Term _h_360 = STK(11);
    Term _h_361 = STK(12);
    Term _h_362 = STK(13);
    Term _h_363 = STK(14);
    Term _h_364 = STK(15);
    Term _h_365 = STK(16);
    Term _h_366 = STK(17);
    Term _h_348 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_349;
      STK(1) = _h_350;
      STK(2) = _h_351;
      STK(3) = _h_352;
      STK(4) = _h_353;
      STK(5) = _h_354;
      STK(6) = _h_355;
      STK(7) = _h_356;
      STK(8) = _h_357;
      STK(9) = _h_358;
      STK(10) = _h_359;
      STK(11) = _h_360;
      STK(12) = _h_361;
      STK(13) = _h_362;
      STK(14) = _h_363;
      STK(15) = _h_364;
      STK(16) = _h_365;
      STK(17) = FID_RUN_K211;
      WL_PUSHN(18);
    } else {
      u64 _t_62 = task_node(e, FID_RUN_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_349;
      e.mem[_t_62 + 1] = _h_350;
      e.mem[_t_62 + 2] = _h_351;
      e.mem[_t_62 + 3] = _h_352;
      e.mem[_t_62 + 4] = _h_353;
      e.mem[_t_62 + 5] = _h_354;
      e.mem[_t_62 + 6] = _h_355;
      e.mem[_t_62 + 7] = _h_356;
      e.mem[_t_62 + 8] = _h_357;
      e.mem[_t_62 + 9] = _h_358;
      e.mem[_t_62 + 10] = _h_359;
      e.mem[_t_62 + 11] = _h_360;
      e.mem[_t_62 + 12] = _h_361;
      e.mem[_t_62 + 13] = _h_362;
      e.mem[_t_62 + 14] = _h_363;
      e.mem[_t_62 + 15] = _h_364;
      e.mem[_t_62 + 16] = _h_365;
      WL_CONT = term_tsk(FID_RUN_K211, _t_62);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _h_366;
      e.mem[_t_63 + 1] = _h_348;
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = _h_366;
    r1 = _h_348;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K211)
  {
    WL_POPN(17);
    Term _h_368 = STK(0);
    Term _h_369 = STK(1);
    Term _h_370 = STK(2);
    Term _h_371 = STK(3);
    Term _h_372 = STK(4);
    Term _h_373 = STK(5);
    Term _h_374 = STK(6);
    Term _h_375 = STK(7);
    Term _h_376 = STK(8);
    Term _h_377 = STK(9);
    Term _h_378 = STK(10);
    Term _h_379 = STK(11);
    Term _h_380 = STK(12);
    Term _h_381 = STK(13);
    Term _h_382 = STK(14);
    Term _h_383 = STK(15);
    Term _h_384 = STK(16);
    Term _h_367 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_368;
      STK(1) = _h_369;
      STK(2) = _h_370;
      STK(3) = _h_371;
      STK(4) = _h_372;
      STK(5) = _h_373;
      STK(6) = _h_374;
      STK(7) = _h_375;
      STK(8) = _h_376;
      STK(9) = _h_377;
      STK(10) = _h_378;
      STK(11) = _h_379;
      STK(12) = _h_380;
      STK(13) = _h_381;
      STK(14) = _h_382;
      STK(15) = _h_383;
      STK(16) = _h_384;
      STK(17) = FID_RUN_K212;
      WL_PUSHN(18);
    } else {
      u64 _t_64 = task_node(e, FID_RUN_K212, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_368;
      e.mem[_t_64 + 1] = _h_369;
      e.mem[_t_64 + 2] = _h_370;
      e.mem[_t_64 + 3] = _h_371;
      e.mem[_t_64 + 4] = _h_372;
      e.mem[_t_64 + 5] = _h_373;
      e.mem[_t_64 + 6] = _h_374;
      e.mem[_t_64 + 7] = _h_375;
      e.mem[_t_64 + 8] = _h_376;
      e.mem[_t_64 + 9] = _h_377;
      e.mem[_t_64 + 10] = _h_378;
      e.mem[_t_64 + 11] = _h_379;
      e.mem[_t_64 + 12] = _h_380;
      e.mem[_t_64 + 13] = _h_381;
      e.mem[_t_64 + 14] = _h_382;
      e.mem[_t_64 + 15] = _h_383;
      e.mem[_t_64 + 16] = _h_384;
      WL_CONT = term_tsk(FID_RUN_K212, _t_64);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_65 + 1] = _h_367;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_367;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K212)
  {
    WL_POPN(17);
    Term _h_386 = STK(0);
    Term _h_387 = STK(1);
    Term _h_388 = STK(2);
    Term _h_389 = STK(3);
    Term _h_390 = STK(4);
    Term _h_391 = STK(5);
    Term _h_392 = STK(6);
    Term _h_393 = STK(7);
    Term _h_394 = STK(8);
    Term _h_395 = STK(9);
    Term _h_396 = STK(10);
    Term _h_397 = STK(11);
    Term _h_398 = STK(12);
    Term _h_399 = STK(13);
    Term _h_400 = STK(14);
    Term _h_401 = STK(15);
    Term _h_402 = STK(16);
    Term _h_385 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_386;
      STK(1) = _h_387;
      STK(2) = _h_388;
      STK(3) = _h_389;
      STK(4) = _h_390;
      STK(5) = _h_391;
      STK(6) = _h_392;
      STK(7) = _h_393;
      STK(8) = _h_394;
      STK(9) = _h_395;
      STK(10) = _h_396;
      STK(11) = _h_397;
      STK(12) = _h_398;
      STK(13) = _h_399;
      STK(14) = _h_400;
      STK(15) = _h_401;
      STK(16) = FID_RUN_K213;
      WL_PUSHN(17);
    } else {
      u64 _t_66 = task_node(e, FID_RUN_K213, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_386;
      e.mem[_t_66 + 1] = _h_387;
      e.mem[_t_66 + 2] = _h_388;
      e.mem[_t_66 + 3] = _h_389;
      e.mem[_t_66 + 4] = _h_390;
      e.mem[_t_66 + 5] = _h_391;
      e.mem[_t_66 + 6] = _h_392;
      e.mem[_t_66 + 7] = _h_393;
      e.mem[_t_66 + 8] = _h_394;
      e.mem[_t_66 + 9] = _h_395;
      e.mem[_t_66 + 10] = _h_396;
      e.mem[_t_66 + 11] = _h_397;
      e.mem[_t_66 + 12] = _h_398;
      e.mem[_t_66 + 13] = _h_399;
      e.mem[_t_66 + 14] = _h_400;
      e.mem[_t_66 + 15] = _h_401;
      WL_CONT = term_tsk(FID_RUN_K213, _t_66);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = _h_402;
      e.mem[_t_67 + 1] = _h_385;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = _h_402;
    r1 = _h_385;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K213)
  {
    WL_POPN(16);
    Term _h_404 = STK(0);
    Term _h_405 = STK(1);
    Term _h_406 = STK(2);
    Term _h_407 = STK(3);
    Term _h_408 = STK(4);
    Term _h_409 = STK(5);
    Term _h_410 = STK(6);
    Term _h_411 = STK(7);
    Term _h_412 = STK(8);
    Term _h_413 = STK(9);
    Term _h_414 = STK(10);
    Term _h_415 = STK(11);
    Term _h_416 = STK(12);
    Term _h_417 = STK(13);
    Term _h_418 = STK(14);
    Term _h_419 = STK(15);
    Term _h_403 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_404;
      STK(1) = _h_405;
      STK(2) = _h_406;
      STK(3) = _h_407;
      STK(4) = _h_408;
      STK(5) = _h_409;
      STK(6) = _h_410;
      STK(7) = _h_411;
      STK(8) = _h_412;
      STK(9) = _h_413;
      STK(10) = _h_414;
      STK(11) = _h_415;
      STK(12) = _h_416;
      STK(13) = _h_417;
      STK(14) = _h_418;
      STK(15) = _h_419;
      STK(16) = FID_RUN_K214;
      WL_PUSHN(17);
    } else {
      u64 _t_68 = task_node(e, FID_RUN_K214, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_404;
      e.mem[_t_68 + 1] = _h_405;
      e.mem[_t_68 + 2] = _h_406;
      e.mem[_t_68 + 3] = _h_407;
      e.mem[_t_68 + 4] = _h_408;
      e.mem[_t_68 + 5] = _h_409;
      e.mem[_t_68 + 6] = _h_410;
      e.mem[_t_68 + 7] = _h_411;
      e.mem[_t_68 + 8] = _h_412;
      e.mem[_t_68 + 9] = _h_413;
      e.mem[_t_68 + 10] = _h_414;
      e.mem[_t_68 + 11] = _h_415;
      e.mem[_t_68 + 12] = _h_416;
      e.mem[_t_68 + 13] = _h_417;
      e.mem[_t_68 + 14] = _h_418;
      e.mem[_t_68 + 15] = _h_419;
      WL_CONT = term_tsk(FID_RUN_K214, _t_68);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = term_ctr(CID_SCON, STAT_OFF + 164);
      e.mem[_t_69 + 1] = _h_403;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 164);
    r1 = _h_403;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K214)
  {
    WL_POPN(16);
    Term _h_421 = STK(0);
    Term _h_422 = STK(1);
    Term _h_423 = STK(2);
    Term _h_424 = STK(3);
    Term _h_425 = STK(4);
    Term _h_426 = STK(5);
    Term _h_427 = STK(6);
    Term _h_428 = STK(7);
    Term _h_429 = STK(8);
    Term _h_430 = STK(9);
    Term _h_431 = STK(10);
    Term _h_432 = STK(11);
    Term _h_433 = STK(12);
    Term _h_434 = STK(13);
    Term _h_435 = STK(14);
    Term _h_436 = STK(15);
    Term _h_420 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_421;
      STK(1) = _h_422;
      STK(2) = _h_423;
      STK(3) = _h_424;
      STK(4) = _h_425;
      STK(5) = _h_426;
      STK(6) = _h_427;
      STK(7) = _h_428;
      STK(8) = _h_429;
      STK(9) = _h_430;
      STK(10) = _h_431;
      STK(11) = _h_432;
      STK(12) = _h_433;
      STK(13) = _h_434;
      STK(14) = _h_435;
      STK(15) = FID_RUN_K215;
      WL_PUSHN(16);
    } else {
      u64 _t_70 = task_node(e, FID_RUN_K215, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _h_421;
      e.mem[_t_70 + 1] = _h_422;
      e.mem[_t_70 + 2] = _h_423;
      e.mem[_t_70 + 3] = _h_424;
      e.mem[_t_70 + 4] = _h_425;
      e.mem[_t_70 + 5] = _h_426;
      e.mem[_t_70 + 6] = _h_427;
      e.mem[_t_70 + 7] = _h_428;
      e.mem[_t_70 + 8] = _h_429;
      e.mem[_t_70 + 9] = _h_430;
      e.mem[_t_70 + 10] = _h_431;
      e.mem[_t_70 + 11] = _h_432;
      e.mem[_t_70 + 12] = _h_433;
      e.mem[_t_70 + 13] = _h_434;
      e.mem[_t_70 + 14] = _h_435;
      WL_CONT = term_tsk(FID_RUN_K215, _t_70);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = _h_436;
      e.mem[_t_71 + 1] = _h_420;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = _h_436;
    r1 = _h_420;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K215)
  {
    WL_POPN(15);
    Term _h_438 = STK(0);
    Term _h_439 = STK(1);
    Term _h_440 = STK(2);
    Term _h_441 = STK(3);
    Term _h_442 = STK(4);
    Term _h_443 = STK(5);
    Term _h_444 = STK(6);
    Term _h_445 = STK(7);
    Term _h_446 = STK(8);
    Term _h_447 = STK(9);
    Term _h_448 = STK(10);
    Term _h_449 = STK(11);
    Term _h_450 = STK(12);
    Term _h_451 = STK(13);
    Term _h_452 = STK(14);
    Term _h_437 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_438;
      STK(1) = _h_439;
      STK(2) = _h_440;
      STK(3) = _h_441;
      STK(4) = _h_442;
      STK(5) = _h_443;
      STK(6) = _h_444;
      STK(7) = _h_445;
      STK(8) = _h_446;
      STK(9) = _h_447;
      STK(10) = _h_448;
      STK(11) = _h_449;
      STK(12) = _h_450;
      STK(13) = _h_451;
      STK(14) = _h_452;
      STK(15) = FID_RUN_K216;
      WL_PUSHN(16);
    } else {
      u64 _t_72 = task_node(e, FID_RUN_K216, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _h_438;
      e.mem[_t_72 + 1] = _h_439;
      e.mem[_t_72 + 2] = _h_440;
      e.mem[_t_72 + 3] = _h_441;
      e.mem[_t_72 + 4] = _h_442;
      e.mem[_t_72 + 5] = _h_443;
      e.mem[_t_72 + 6] = _h_444;
      e.mem[_t_72 + 7] = _h_445;
      e.mem[_t_72 + 8] = _h_446;
      e.mem[_t_72 + 9] = _h_447;
      e.mem[_t_72 + 10] = _h_448;
      e.mem[_t_72 + 11] = _h_449;
      e.mem[_t_72 + 12] = _h_450;
      e.mem[_t_72 + 13] = _h_451;
      e.mem[_t_72 + 14] = _h_452;
      WL_CONT = term_tsk(FID_RUN_K216, _t_72);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_73 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_73 + 1] = _h_437;
      return term_tsk(FID_STRING_APPEND, _t_73);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_437;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K216)
  {
    WL_POPN(15);
    Term _h_454 = STK(0);
    Term _h_455 = STK(1);
    Term _h_456 = STK(2);
    Term _h_457 = STK(3);
    Term _h_458 = STK(4);
    Term _h_459 = STK(5);
    Term _h_460 = STK(6);
    Term _h_461 = STK(7);
    Term _h_462 = STK(8);
    Term _h_463 = STK(9);
    Term _h_464 = STK(10);
    Term _h_465 = STK(11);
    Term _h_466 = STK(12);
    Term _h_467 = STK(13);
    Term _h_468 = STK(14);
    Term _h_453 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_454;
      STK(1) = _h_455;
      STK(2) = _h_456;
      STK(3) = _h_457;
      STK(4) = _h_458;
      STK(5) = _h_459;
      STK(6) = _h_460;
      STK(7) = _h_461;
      STK(8) = _h_462;
      STK(9) = _h_463;
      STK(10) = _h_464;
      STK(11) = _h_465;
      STK(12) = _h_466;
      STK(13) = _h_467;
      STK(14) = FID_RUN_K217;
      WL_PUSHN(15);
    } else {
      u64 _t_74 = task_node(e, FID_RUN_K217, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _h_454;
      e.mem[_t_74 + 1] = _h_455;
      e.mem[_t_74 + 2] = _h_456;
      e.mem[_t_74 + 3] = _h_457;
      e.mem[_t_74 + 4] = _h_458;
      e.mem[_t_74 + 5] = _h_459;
      e.mem[_t_74 + 6] = _h_460;
      e.mem[_t_74 + 7] = _h_461;
      e.mem[_t_74 + 8] = _h_462;
      e.mem[_t_74 + 9] = _h_463;
      e.mem[_t_74 + 10] = _h_464;
      e.mem[_t_74 + 11] = _h_465;
      e.mem[_t_74 + 12] = _h_466;
      e.mem[_t_74 + 13] = _h_467;
      WL_CONT = term_tsk(FID_RUN_K217, _t_74);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_75 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = _h_468;
      e.mem[_t_75 + 1] = _h_453;
      return term_tsk(FID_STRING_APPEND, _t_75);
    }
    r0 = _h_468;
    r1 = _h_453;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K217)
  {
    WL_POPN(14);
    Term _h_470 = STK(0);
    Term _h_471 = STK(1);
    Term _h_472 = STK(2);
    Term _h_473 = STK(3);
    Term _h_474 = STK(4);
    Term _h_475 = STK(5);
    Term _h_476 = STK(6);
    Term _h_477 = STK(7);
    Term _h_478 = STK(8);
    Term _h_479 = STK(9);
    Term _h_480 = STK(10);
    Term _h_481 = STK(11);
    Term _h_482 = STK(12);
    Term _h_483 = STK(13);
    Term _h_469 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_470;
      STK(1) = _h_471;
      STK(2) = _h_472;
      STK(3) = _h_473;
      STK(4) = _h_474;
      STK(5) = _h_475;
      STK(6) = _h_476;
      STK(7) = _h_477;
      STK(8) = _h_478;
      STK(9) = _h_479;
      STK(10) = _h_480;
      STK(11) = _h_481;
      STK(12) = _h_482;
      STK(13) = _h_483;
      STK(14) = FID_RUN_K218;
      WL_PUSHN(15);
    } else {
      u64 _t_76 = task_node(e, FID_RUN_K218, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _h_470;
      e.mem[_t_76 + 1] = _h_471;
      e.mem[_t_76 + 2] = _h_472;
      e.mem[_t_76 + 3] = _h_473;
      e.mem[_t_76 + 4] = _h_474;
      e.mem[_t_76 + 5] = _h_475;
      e.mem[_t_76 + 6] = _h_476;
      e.mem[_t_76 + 7] = _h_477;
      e.mem[_t_76 + 8] = _h_478;
      e.mem[_t_76 + 9] = _h_479;
      e.mem[_t_76 + 10] = _h_480;
      e.mem[_t_76 + 11] = _h_481;
      e.mem[_t_76 + 12] = _h_482;
      e.mem[_t_76 + 13] = _h_483;
      WL_CONT = term_tsk(FID_RUN_K218, _t_76);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_77 + 1] = _h_469;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_469;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K218)
  {
    WL_POPN(14);
    Term _h_485 = STK(0);
    Term _h_486 = STK(1);
    Term _h_487 = STK(2);
    Term _h_488 = STK(3);
    Term _h_489 = STK(4);
    Term _h_490 = STK(5);
    Term _h_491 = STK(6);
    Term _h_492 = STK(7);
    Term _h_493 = STK(8);
    Term _h_494 = STK(9);
    Term _h_495 = STK(10);
    Term _h_496 = STK(11);
    Term _h_497 = STK(12);
    Term _h_498 = STK(13);
    Term _h_484 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_485;
      STK(1) = _h_486;
      STK(2) = _h_487;
      STK(3) = _h_488;
      STK(4) = _h_489;
      STK(5) = _h_490;
      STK(6) = _h_491;
      STK(7) = _h_492;
      STK(8) = _h_493;
      STK(9) = _h_494;
      STK(10) = _h_495;
      STK(11) = _h_496;
      STK(12) = _h_497;
      STK(13) = FID_RUN_K219;
      WL_PUSHN(14);
    } else {
      u64 _t_78 = task_node(e, FID_RUN_K219, WL_CONT, WL_IDX, 1);
      e.mem[_t_78 + 0] = _h_485;
      e.mem[_t_78 + 1] = _h_486;
      e.mem[_t_78 + 2] = _h_487;
      e.mem[_t_78 + 3] = _h_488;
      e.mem[_t_78 + 4] = _h_489;
      e.mem[_t_78 + 5] = _h_490;
      e.mem[_t_78 + 6] = _h_491;
      e.mem[_t_78 + 7] = _h_492;
      e.mem[_t_78 + 8] = _h_493;
      e.mem[_t_78 + 9] = _h_494;
      e.mem[_t_78 + 10] = _h_495;
      e.mem[_t_78 + 11] = _h_496;
      e.mem[_t_78 + 12] = _h_497;
      WL_CONT = term_tsk(FID_RUN_K219, _t_78);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_79 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = _h_498;
      e.mem[_t_79 + 1] = _h_484;
      return term_tsk(FID_STRING_APPEND, _t_79);
    }
    r0 = _h_498;
    r1 = _h_484;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K219)
  {
    WL_POPN(13);
    Term _h_500 = STK(0);
    Term _h_501 = STK(1);
    Term _h_502 = STK(2);
    Term _h_503 = STK(3);
    Term _h_504 = STK(4);
    Term _h_505 = STK(5);
    Term _h_506 = STK(6);
    Term _h_507 = STK(7);
    Term _h_508 = STK(8);
    Term _h_509 = STK(9);
    Term _h_510 = STK(10);
    Term _h_511 = STK(11);
    Term _h_512 = STK(12);
    Term _h_499 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_500;
      STK(1) = _h_501;
      STK(2) = _h_502;
      STK(3) = _h_503;
      STK(4) = _h_504;
      STK(5) = _h_505;
      STK(6) = _h_506;
      STK(7) = _h_507;
      STK(8) = _h_508;
      STK(9) = _h_509;
      STK(10) = _h_510;
      STK(11) = _h_511;
      STK(12) = _h_512;
      STK(13) = FID_RUN_K220;
      WL_PUSHN(14);
    } else {
      u64 _t_80 = task_node(e, FID_RUN_K220, WL_CONT, WL_IDX, 1);
      e.mem[_t_80 + 0] = _h_500;
      e.mem[_t_80 + 1] = _h_501;
      e.mem[_t_80 + 2] = _h_502;
      e.mem[_t_80 + 3] = _h_503;
      e.mem[_t_80 + 4] = _h_504;
      e.mem[_t_80 + 5] = _h_505;
      e.mem[_t_80 + 6] = _h_506;
      e.mem[_t_80 + 7] = _h_507;
      e.mem[_t_80 + 8] = _h_508;
      e.mem[_t_80 + 9] = _h_509;
      e.mem[_t_80 + 10] = _h_510;
      e.mem[_t_80 + 11] = _h_511;
      e.mem[_t_80 + 12] = _h_512;
      WL_CONT = term_tsk(FID_RUN_K220, _t_80);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_81 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = term_ctr(CID_SCON, STAT_OFF + 140);
      e.mem[_t_81 + 1] = _h_499;
      return term_tsk(FID_STRING_APPEND, _t_81);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 140);
    r1 = _h_499;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K220)
  {
    WL_POPN(13);
    Term _h_514 = STK(0);
    Term _h_515 = STK(1);
    Term _h_516 = STK(2);
    Term _h_517 = STK(3);
    Term _h_518 = STK(4);
    Term _h_519 = STK(5);
    Term _h_520 = STK(6);
    Term _h_521 = STK(7);
    Term _h_522 = STK(8);
    Term _h_523 = STK(9);
    Term _h_524 = STK(10);
    Term _h_525 = STK(11);
    Term _h_526 = STK(12);
    Term _h_513 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_514;
      STK(1) = _h_515;
      STK(2) = _h_516;
      STK(3) = _h_517;
      STK(4) = _h_518;
      STK(5) = _h_519;
      STK(6) = _h_520;
      STK(7) = _h_521;
      STK(8) = _h_522;
      STK(9) = _h_523;
      STK(10) = _h_524;
      STK(11) = _h_525;
      STK(12) = FID_RUN_K221;
      WL_PUSHN(13);
    } else {
      u64 _t_82 = task_node(e, FID_RUN_K221, WL_CONT, WL_IDX, 1);
      e.mem[_t_82 + 0] = _h_514;
      e.mem[_t_82 + 1] = _h_515;
      e.mem[_t_82 + 2] = _h_516;
      e.mem[_t_82 + 3] = _h_517;
      e.mem[_t_82 + 4] = _h_518;
      e.mem[_t_82 + 5] = _h_519;
      e.mem[_t_82 + 6] = _h_520;
      e.mem[_t_82 + 7] = _h_521;
      e.mem[_t_82 + 8] = _h_522;
      e.mem[_t_82 + 9] = _h_523;
      e.mem[_t_82 + 10] = _h_524;
      e.mem[_t_82 + 11] = _h_525;
      WL_CONT = term_tsk(FID_RUN_K221, _t_82);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = _h_526;
      e.mem[_t_83 + 1] = _h_513;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = _h_526;
    r1 = _h_513;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K221)
  {
    WL_POPN(12);
    Term _h_528 = STK(0);
    Term _h_529 = STK(1);
    Term _h_530 = STK(2);
    Term _h_531 = STK(3);
    Term _h_532 = STK(4);
    Term _h_533 = STK(5);
    Term _h_534 = STK(6);
    Term _h_535 = STK(7);
    Term _h_536 = STK(8);
    Term _h_537 = STK(9);
    Term _h_538 = STK(10);
    Term _h_539 = STK(11);
    Term _h_527 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_528;
      STK(1) = _h_529;
      STK(2) = _h_530;
      STK(3) = _h_531;
      STK(4) = _h_532;
      STK(5) = _h_533;
      STK(6) = _h_534;
      STK(7) = _h_535;
      STK(8) = _h_536;
      STK(9) = _h_537;
      STK(10) = _h_538;
      STK(11) = _h_539;
      STK(12) = FID_RUN_K222;
      WL_PUSHN(13);
    } else {
      u64 _t_84 = task_node(e, FID_RUN_K222, WL_CONT, WL_IDX, 1);
      e.mem[_t_84 + 0] = _h_528;
      e.mem[_t_84 + 1] = _h_529;
      e.mem[_t_84 + 2] = _h_530;
      e.mem[_t_84 + 3] = _h_531;
      e.mem[_t_84 + 4] = _h_532;
      e.mem[_t_84 + 5] = _h_533;
      e.mem[_t_84 + 6] = _h_534;
      e.mem[_t_84 + 7] = _h_535;
      e.mem[_t_84 + 8] = _h_536;
      e.mem[_t_84 + 9] = _h_537;
      e.mem[_t_84 + 10] = _h_538;
      e.mem[_t_84 + 11] = _h_539;
      WL_CONT = term_tsk(FID_RUN_K222, _t_84);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_85 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_85 + 1] = _h_527;
      return term_tsk(FID_STRING_APPEND, _t_85);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_527;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K222)
  {
    WL_POPN(12);
    Term _h_541 = STK(0);
    Term _h_542 = STK(1);
    Term _h_543 = STK(2);
    Term _h_544 = STK(3);
    Term _h_545 = STK(4);
    Term _h_546 = STK(5);
    Term _h_547 = STK(6);
    Term _h_548 = STK(7);
    Term _h_549 = STK(8);
    Term _h_550 = STK(9);
    Term _h_551 = STK(10);
    Term _h_552 = STK(11);
    Term _h_540 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_541;
      STK(1) = _h_542;
      STK(2) = _h_543;
      STK(3) = _h_544;
      STK(4) = _h_545;
      STK(5) = _h_546;
      STK(6) = _h_547;
      STK(7) = _h_548;
      STK(8) = _h_549;
      STK(9) = _h_550;
      STK(10) = _h_551;
      STK(11) = FID_RUN_K223;
      WL_PUSHN(12);
    } else {
      u64 _t_86 = task_node(e, FID_RUN_K223, WL_CONT, WL_IDX, 1);
      e.mem[_t_86 + 0] = _h_541;
      e.mem[_t_86 + 1] = _h_542;
      e.mem[_t_86 + 2] = _h_543;
      e.mem[_t_86 + 3] = _h_544;
      e.mem[_t_86 + 4] = _h_545;
      e.mem[_t_86 + 5] = _h_546;
      e.mem[_t_86 + 6] = _h_547;
      e.mem[_t_86 + 7] = _h_548;
      e.mem[_t_86 + 8] = _h_549;
      e.mem[_t_86 + 9] = _h_550;
      e.mem[_t_86 + 10] = _h_551;
      WL_CONT = term_tsk(FID_RUN_K223, _t_86);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_87 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_87 + 0] = _h_552;
      e.mem[_t_87 + 1] = _h_540;
      return term_tsk(FID_STRING_APPEND, _t_87);
    }
    r0 = _h_552;
    r1 = _h_540;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K223)
  {
    WL_POPN(11);
    Term _h_554 = STK(0);
    Term _h_555 = STK(1);
    Term _h_556 = STK(2);
    Term _h_557 = STK(3);
    Term _h_558 = STK(4);
    Term _h_559 = STK(5);
    Term _h_560 = STK(6);
    Term _h_561 = STK(7);
    Term _h_562 = STK(8);
    Term _h_563 = STK(9);
    Term _h_564 = STK(10);
    Term _h_553 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_554;
      STK(1) = _h_555;
      STK(2) = _h_556;
      STK(3) = _h_557;
      STK(4) = _h_558;
      STK(5) = _h_559;
      STK(6) = _h_560;
      STK(7) = _h_561;
      STK(8) = _h_562;
      STK(9) = _h_563;
      STK(10) = _h_564;
      STK(11) = FID_RUN_K224;
      WL_PUSHN(12);
    } else {
      u64 _t_88 = task_node(e, FID_RUN_K224, WL_CONT, WL_IDX, 1);
      e.mem[_t_88 + 0] = _h_554;
      e.mem[_t_88 + 1] = _h_555;
      e.mem[_t_88 + 2] = _h_556;
      e.mem[_t_88 + 3] = _h_557;
      e.mem[_t_88 + 4] = _h_558;
      e.mem[_t_88 + 5] = _h_559;
      e.mem[_t_88 + 6] = _h_560;
      e.mem[_t_88 + 7] = _h_561;
      e.mem[_t_88 + 8] = _h_562;
      e.mem[_t_88 + 9] = _h_563;
      e.mem[_t_88 + 10] = _h_564;
      WL_CONT = term_tsk(FID_RUN_K224, _t_88);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_89 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_89 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_89 + 1] = _h_553;
      return term_tsk(FID_STRING_APPEND, _t_89);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_553;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K224)
  {
    WL_POPN(11);
    Term _h_566 = STK(0);
    Term _h_567 = STK(1);
    Term _h_568 = STK(2);
    Term _h_569 = STK(3);
    Term _h_570 = STK(4);
    Term _h_571 = STK(5);
    Term _h_572 = STK(6);
    Term _h_573 = STK(7);
    Term _h_574 = STK(8);
    Term _h_575 = STK(9);
    Term _h_576 = STK(10);
    Term _h_565 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_566;
      STK(1) = _h_567;
      STK(2) = _h_568;
      STK(3) = _h_569;
      STK(4) = _h_570;
      STK(5) = _h_571;
      STK(6) = _h_572;
      STK(7) = _h_573;
      STK(8) = _h_574;
      STK(9) = _h_575;
      STK(10) = FID_RUN_K225;
      WL_PUSHN(11);
    } else {
      u64 _t_90 = task_node(e, FID_RUN_K225, WL_CONT, WL_IDX, 1);
      e.mem[_t_90 + 0] = _h_566;
      e.mem[_t_90 + 1] = _h_567;
      e.mem[_t_90 + 2] = _h_568;
      e.mem[_t_90 + 3] = _h_569;
      e.mem[_t_90 + 4] = _h_570;
      e.mem[_t_90 + 5] = _h_571;
      e.mem[_t_90 + 6] = _h_572;
      e.mem[_t_90 + 7] = _h_573;
      e.mem[_t_90 + 8] = _h_574;
      e.mem[_t_90 + 9] = _h_575;
      WL_CONT = term_tsk(FID_RUN_K225, _t_90);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_91 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_91 + 0] = _h_576;
      e.mem[_t_91 + 1] = _h_565;
      return term_tsk(FID_STRING_APPEND, _t_91);
    }
    r0 = _h_576;
    r1 = _h_565;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K225)
  {
    WL_POPN(10);
    Term _h_578 = STK(0);
    Term _h_579 = STK(1);
    Term _h_580 = STK(2);
    Term _h_581 = STK(3);
    Term _h_582 = STK(4);
    Term _h_583 = STK(5);
    Term _h_584 = STK(6);
    Term _h_585 = STK(7);
    Term _h_586 = STK(8);
    Term _h_587 = STK(9);
    Term _h_577 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_578;
      STK(1) = _h_579;
      STK(2) = _h_580;
      STK(3) = _h_581;
      STK(4) = _h_582;
      STK(5) = _h_583;
      STK(6) = _h_584;
      STK(7) = _h_585;
      STK(8) = _h_586;
      STK(9) = _h_587;
      STK(10) = FID_RUN_K226;
      WL_PUSHN(11);
    } else {
      u64 _t_92 = task_node(e, FID_RUN_K226, WL_CONT, WL_IDX, 1);
      e.mem[_t_92 + 0] = _h_578;
      e.mem[_t_92 + 1] = _h_579;
      e.mem[_t_92 + 2] = _h_580;
      e.mem[_t_92 + 3] = _h_581;
      e.mem[_t_92 + 4] = _h_582;
      e.mem[_t_92 + 5] = _h_583;
      e.mem[_t_92 + 6] = _h_584;
      e.mem[_t_92 + 7] = _h_585;
      e.mem[_t_92 + 8] = _h_586;
      e.mem[_t_92 + 9] = _h_587;
      WL_CONT = term_tsk(FID_RUN_K226, _t_92);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_93 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_93 + 0] = term_ctr(CID_SCON, STAT_OFF + 184);
      e.mem[_t_93 + 1] = _h_577;
      return term_tsk(FID_STRING_APPEND, _t_93);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 184);
    r1 = _h_577;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K226)
  {
    WL_POPN(10);
    Term _h_589 = STK(0);
    Term _h_590 = STK(1);
    Term _h_591 = STK(2);
    Term _h_592 = STK(3);
    Term _h_593 = STK(4);
    Term _h_594 = STK(5);
    Term _h_595 = STK(6);
    Term _h_596 = STK(7);
    Term _h_597 = STK(8);
    Term _h_598 = STK(9);
    Term _h_588 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_589;
      STK(1) = _h_590;
      STK(2) = _h_591;
      STK(3) = _h_592;
      STK(4) = _h_593;
      STK(5) = _h_594;
      STK(6) = _h_595;
      STK(7) = _h_596;
      STK(8) = _h_597;
      STK(9) = FID_RUN_K227;
      WL_PUSHN(10);
    } else {
      u64 _t_94 = task_node(e, FID_RUN_K227, WL_CONT, WL_IDX, 1);
      e.mem[_t_94 + 0] = _h_589;
      e.mem[_t_94 + 1] = _h_590;
      e.mem[_t_94 + 2] = _h_591;
      e.mem[_t_94 + 3] = _h_592;
      e.mem[_t_94 + 4] = _h_593;
      e.mem[_t_94 + 5] = _h_594;
      e.mem[_t_94 + 6] = _h_595;
      e.mem[_t_94 + 7] = _h_596;
      e.mem[_t_94 + 8] = _h_597;
      WL_CONT = term_tsk(FID_RUN_K227, _t_94);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_95 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_95 + 0] = _h_598;
      e.mem[_t_95 + 1] = _h_588;
      return term_tsk(FID_STRING_APPEND, _t_95);
    }
    r0 = _h_598;
    r1 = _h_588;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K227)
  {
    WL_POPN(9);
    Term _h_600 = STK(0);
    Term _h_601 = STK(1);
    Term _h_602 = STK(2);
    Term _h_603 = STK(3);
    Term _h_604 = STK(4);
    Term _h_605 = STK(5);
    Term _h_606 = STK(6);
    Term _h_607 = STK(7);
    Term _h_608 = STK(8);
    Term _h_599 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_600;
      STK(1) = _h_601;
      STK(2) = _h_602;
      STK(3) = _h_603;
      STK(4) = _h_604;
      STK(5) = _h_605;
      STK(6) = _h_606;
      STK(7) = _h_607;
      STK(8) = _h_608;
      STK(9) = FID_RUN_K228;
      WL_PUSHN(10);
    } else {
      u64 _t_96 = task_node(e, FID_RUN_K228, WL_CONT, WL_IDX, 1);
      e.mem[_t_96 + 0] = _h_600;
      e.mem[_t_96 + 1] = _h_601;
      e.mem[_t_96 + 2] = _h_602;
      e.mem[_t_96 + 3] = _h_603;
      e.mem[_t_96 + 4] = _h_604;
      e.mem[_t_96 + 5] = _h_605;
      e.mem[_t_96 + 6] = _h_606;
      e.mem[_t_96 + 7] = _h_607;
      e.mem[_t_96 + 8] = _h_608;
      WL_CONT = term_tsk(FID_RUN_K228, _t_96);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_97 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_97 + 1] = _h_599;
      return term_tsk(FID_STRING_APPEND, _t_97);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_599;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K228)
  {
    WL_POPN(9);
    Term _h_610 = STK(0);
    Term _h_611 = STK(1);
    Term _h_612 = STK(2);
    Term _h_613 = STK(3);
    Term _h_614 = STK(4);
    Term _h_615 = STK(5);
    Term _h_616 = STK(6);
    Term _h_617 = STK(7);
    Term _h_618 = STK(8);
    Term _h_609 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_610;
      STK(1) = _h_611;
      STK(2) = _h_612;
      STK(3) = _h_613;
      STK(4) = _h_614;
      STK(5) = _h_615;
      STK(6) = _h_616;
      STK(7) = _h_617;
      STK(8) = FID_RUN_K229;
      WL_PUSHN(9);
    } else {
      u64 _t_98 = task_node(e, FID_RUN_K229, WL_CONT, WL_IDX, 1);
      e.mem[_t_98 + 0] = _h_610;
      e.mem[_t_98 + 1] = _h_611;
      e.mem[_t_98 + 2] = _h_612;
      e.mem[_t_98 + 3] = _h_613;
      e.mem[_t_98 + 4] = _h_614;
      e.mem[_t_98 + 5] = _h_615;
      e.mem[_t_98 + 6] = _h_616;
      e.mem[_t_98 + 7] = _h_617;
      WL_CONT = term_tsk(FID_RUN_K229, _t_98);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_99 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = _h_618;
      e.mem[_t_99 + 1] = _h_609;
      return term_tsk(FID_STRING_APPEND, _t_99);
    }
    r0 = _h_618;
    r1 = _h_609;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K229)
  {
    WL_POPN(8);
    Term _h_620 = STK(0);
    Term _h_621 = STK(1);
    Term _h_622 = STK(2);
    Term _h_623 = STK(3);
    Term _h_624 = STK(4);
    Term _h_625 = STK(5);
    Term _h_626 = STK(6);
    Term _h_627 = STK(7);
    Term _h_619 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_620;
      STK(1) = _h_621;
      STK(2) = _h_622;
      STK(3) = _h_623;
      STK(4) = _h_624;
      STK(5) = _h_625;
      STK(6) = _h_626;
      STK(7) = _h_627;
      STK(8) = FID_RUN_K230;
      WL_PUSHN(9);
    } else {
      u64 _t_100 = task_node(e, FID_RUN_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_100 + 0] = _h_620;
      e.mem[_t_100 + 1] = _h_621;
      e.mem[_t_100 + 2] = _h_622;
      e.mem[_t_100 + 3] = _h_623;
      e.mem[_t_100 + 4] = _h_624;
      e.mem[_t_100 + 5] = _h_625;
      e.mem[_t_100 + 6] = _h_626;
      e.mem[_t_100 + 7] = _h_627;
      WL_CONT = term_tsk(FID_RUN_K230, _t_100);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_101 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_101 + 0] = term_ctr(CID_SCON, STAT_OFF + 204);
      e.mem[_t_101 + 1] = _h_619;
      return term_tsk(FID_STRING_APPEND, _t_101);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 204);
    r1 = _h_619;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K230)
  {
    WL_POPN(8);
    Term _h_629 = STK(0);
    Term _h_630 = STK(1);
    Term _h_631 = STK(2);
    Term _h_632 = STK(3);
    Term _h_633 = STK(4);
    Term _h_634 = STK(5);
    Term _h_635 = STK(6);
    Term _h_636 = STK(7);
    Term _h_628 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_629;
      STK(1) = _h_630;
      STK(2) = _h_631;
      STK(3) = _h_632;
      STK(4) = _h_633;
      STK(5) = _h_634;
      STK(6) = _h_635;
      STK(7) = FID_RUN_K231;
      WL_PUSHN(8);
    } else {
      u64 _t_102 = task_node(e, FID_RUN_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_102 + 0] = _h_629;
      e.mem[_t_102 + 1] = _h_630;
      e.mem[_t_102 + 2] = _h_631;
      e.mem[_t_102 + 3] = _h_632;
      e.mem[_t_102 + 4] = _h_633;
      e.mem[_t_102 + 5] = _h_634;
      e.mem[_t_102 + 6] = _h_635;
      WL_CONT = term_tsk(FID_RUN_K231, _t_102);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_103 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_103 + 0] = _h_636;
      e.mem[_t_103 + 1] = _h_628;
      return term_tsk(FID_STRING_APPEND, _t_103);
    }
    r0 = _h_636;
    r1 = _h_628;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K231)
  {
    WL_POPN(7);
    Term _h_638 = STK(0);
    Term _h_639 = STK(1);
    Term _h_640 = STK(2);
    Term _h_641 = STK(3);
    Term _h_642 = STK(4);
    Term _h_643 = STK(5);
    Term _h_644 = STK(6);
    Term _h_637 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_638;
      STK(1) = _h_639;
      STK(2) = _h_640;
      STK(3) = _h_641;
      STK(4) = _h_642;
      STK(5) = _h_643;
      STK(6) = _h_644;
      STK(7) = FID_RUN_K232;
      WL_PUSHN(8);
    } else {
      u64 _t_104 = task_node(e, FID_RUN_K232, WL_CONT, WL_IDX, 1);
      e.mem[_t_104 + 0] = _h_638;
      e.mem[_t_104 + 1] = _h_639;
      e.mem[_t_104 + 2] = _h_640;
      e.mem[_t_104 + 3] = _h_641;
      e.mem[_t_104 + 4] = _h_642;
      e.mem[_t_104 + 5] = _h_643;
      e.mem[_t_104 + 6] = _h_644;
      WL_CONT = term_tsk(FID_RUN_K232, _t_104);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_105 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_105 + 0] = term_ctr(CID_SCON, STAT_OFF + 230);
      e.mem[_t_105 + 1] = _h_637;
      return term_tsk(FID_STRING_APPEND, _t_105);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 230);
    r1 = _h_637;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K232)
  {
    WL_POPN(7);
    Term _h_646 = STK(0);
    Term _h_647 = STK(1);
    Term _h_648 = STK(2);
    Term _h_649 = STK(3);
    Term _h_650 = STK(4);
    Term _h_651 = STK(5);
    Term _h_652 = STK(6);
    Term _h_645 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_646;
      STK(1) = _h_647;
      STK(2) = _h_648;
      STK(3) = _h_649;
      STK(4) = _h_650;
      STK(5) = _h_651;
      STK(6) = FID_RUN_K233;
      WL_PUSHN(7);
    } else {
      u64 _t_106 = task_node(e, FID_RUN_K233, WL_CONT, WL_IDX, 1);
      e.mem[_t_106 + 0] = _h_646;
      e.mem[_t_106 + 1] = _h_647;
      e.mem[_t_106 + 2] = _h_648;
      e.mem[_t_106 + 3] = _h_649;
      e.mem[_t_106 + 4] = _h_650;
      e.mem[_t_106 + 5] = _h_651;
      WL_CONT = term_tsk(FID_RUN_K233, _t_106);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_107 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_107 + 0] = _h_652;
      e.mem[_t_107 + 1] = _h_645;
      return term_tsk(FID_STRING_APPEND, _t_107);
    }
    r0 = _h_652;
    r1 = _h_645;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K233)
  {
    WL_POPN(6);
    Term _h_654 = STK(0);
    Term _h_655 = STK(1);
    Term _h_656 = STK(2);
    Term _h_657 = STK(3);
    Term _h_658 = STK(4);
    Term _h_659 = STK(5);
    Term _h_653 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_654;
      STK(1) = _h_655;
      STK(2) = _h_656;
      STK(3) = _h_657;
      STK(4) = _h_658;
      STK(5) = _h_659;
      STK(6) = FID_RUN_K234;
      WL_PUSHN(7);
    } else {
      u64 _t_108 = task_node(e, FID_RUN_K234, WL_CONT, WL_IDX, 1);
      e.mem[_t_108 + 0] = _h_654;
      e.mem[_t_108 + 1] = _h_655;
      e.mem[_t_108 + 2] = _h_656;
      e.mem[_t_108 + 3] = _h_657;
      e.mem[_t_108 + 4] = _h_658;
      e.mem[_t_108 + 5] = _h_659;
      WL_CONT = term_tsk(FID_RUN_K234, _t_108);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_109 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_109 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
      e.mem[_t_109 + 1] = _h_653;
      return term_tsk(FID_STRING_APPEND, _t_109);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 64);
    r1 = _h_653;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K234)
  {
    WL_POPN(6);
    Term _h_661 = STK(0);
    Term _h_662 = STK(1);
    Term _h_663 = STK(2);
    Term _h_664 = STK(3);
    Term _h_665 = STK(4);
    Term _h_666 = STK(5);
    Term _h_660 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_661;
      STK(1) = _h_662;
      STK(2) = _h_663;
      STK(3) = _h_664;
      STK(4) = _h_665;
      STK(5) = FID_RUN_K235;
      WL_PUSHN(6);
    } else {
      u64 _t_110 = task_node(e, FID_RUN_K235, WL_CONT, WL_IDX, 1);
      e.mem[_t_110 + 0] = _h_661;
      e.mem[_t_110 + 1] = _h_662;
      e.mem[_t_110 + 2] = _h_663;
      e.mem[_t_110 + 3] = _h_664;
      e.mem[_t_110 + 4] = _h_665;
      WL_CONT = term_tsk(FID_RUN_K235, _t_110);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_111 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_111 + 0] = _h_666;
      e.mem[_t_111 + 1] = _h_660;
      return term_tsk(FID_STRING_APPEND, _t_111);
    }
    r0 = _h_666;
    r1 = _h_660;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K235)
  {
    WL_POPN(5);
    Term _h_668 = STK(0);
    Term _h_669 = STK(1);
    Term _h_670 = STK(2);
    Term _h_671 = STK(3);
    Term _h_672 = STK(4);
    Term _h_667 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_668;
      STK(1) = _h_669;
      STK(2) = _h_670;
      STK(3) = _h_671;
      STK(4) = _h_672;
      STK(5) = FID_RUN_K236;
      WL_PUSHN(6);
    } else {
      u64 _t_112 = task_node(e, FID_RUN_K236, WL_CONT, WL_IDX, 1);
      e.mem[_t_112 + 0] = _h_668;
      e.mem[_t_112 + 1] = _h_669;
      e.mem[_t_112 + 2] = _h_670;
      e.mem[_t_112 + 3] = _h_671;
      e.mem[_t_112 + 4] = _h_672;
      WL_CONT = term_tsk(FID_RUN_K236, _t_112);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_113 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_113 + 0] = term_ctr(CID_SCON, STAT_OFF + 246);
      e.mem[_t_113 + 1] = _h_667;
      return term_tsk(FID_STRING_APPEND, _t_113);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 246);
    r1 = _h_667;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K236)
  {
    WL_POPN(5);
    Term _h_674 = STK(0);
    Term _h_675 = STK(1);
    Term _h_676 = STK(2);
    Term _h_677 = STK(3);
    Term _h_678 = STK(4);
    Term _h_673 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_674;
      STK(1) = _h_675;
      STK(2) = _h_676;
      STK(3) = _h_677;
      STK(4) = FID_RUN_K237;
      WL_PUSHN(5);
    } else {
      u64 _t_114 = task_node(e, FID_RUN_K237, WL_CONT, WL_IDX, 1);
      e.mem[_t_114 + 0] = _h_674;
      e.mem[_t_114 + 1] = _h_675;
      e.mem[_t_114 + 2] = _h_676;
      e.mem[_t_114 + 3] = _h_677;
      WL_CONT = term_tsk(FID_RUN_K237, _t_114);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_115 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_115 + 0] = _h_678;
      e.mem[_t_115 + 1] = _h_673;
      return term_tsk(FID_STRING_APPEND, _t_115);
    }
    r0 = _h_678;
    r1 = _h_673;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K237)
  {
    WL_POPN(4);
    Term _h_680 = STK(0);
    Term _h_681 = STK(1);
    Term _h_682 = STK(2);
    Term _h_683 = STK(3);
    Term _h_679 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_680;
      STK(1) = _h_681;
      STK(2) = _h_682;
      STK(3) = _h_683;
      STK(4) = FID_RUN_K238;
      WL_PUSHN(5);
    } else {
      u64 _t_116 = task_node(e, FID_RUN_K238, WL_CONT, WL_IDX, 1);
      e.mem[_t_116 + 0] = _h_680;
      e.mem[_t_116 + 1] = _h_681;
      e.mem[_t_116 + 2] = _h_682;
      e.mem[_t_116 + 3] = _h_683;
      WL_CONT = term_tsk(FID_RUN_K238, _t_116);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_117 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_117 + 0] = term_ctr(CID_SCON, STAT_OFF + 262);
      e.mem[_t_117 + 1] = _h_679;
      return term_tsk(FID_STRING_APPEND, _t_117);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 262);
    r1 = _h_679;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K238)
  {
    WL_POPN(4);
    Term _h_685 = STK(0);
    Term _h_686 = STK(1);
    Term _h_687 = STK(2);
    Term _h_688 = STK(3);
    Term _h_684 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_685;
      STK(1) = _h_686;
      STK(2) = _h_687;
      STK(3) = FID_RUN_K239;
      WL_PUSHN(4);
    } else {
      u64 _t_118 = task_node(e, FID_RUN_K239, WL_CONT, WL_IDX, 1);
      e.mem[_t_118 + 0] = _h_685;
      e.mem[_t_118 + 1] = _h_686;
      e.mem[_t_118 + 2] = _h_687;
      WL_CONT = term_tsk(FID_RUN_K239, _t_118);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_119 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_119 + 0] = _h_688;
      e.mem[_t_119 + 1] = _h_684;
      return term_tsk(FID_STRING_APPEND, _t_119);
    }
    r0 = _h_688;
    r1 = _h_684;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K239)
  {
    WL_POPN(3);
    Term _h_690 = STK(0);
    Term _h_691 = STK(1);
    Term _h_692 = STK(2);
    Term _h_689 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_690;
      STK(1) = _h_691;
      STK(2) = _h_692;
      STK(3) = FID_RUN_K240;
      WL_PUSHN(4);
    } else {
      u64 _t_120 = task_node(e, FID_RUN_K240, WL_CONT, WL_IDX, 1);
      e.mem[_t_120 + 0] = _h_690;
      e.mem[_t_120 + 1] = _h_691;
      e.mem[_t_120 + 2] = _h_692;
      WL_CONT = term_tsk(FID_RUN_K240, _t_120);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_121 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_121 + 0] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_121 + 1] = _h_689;
      return term_tsk(FID_STRING_APPEND, _t_121);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 268);
    r1 = _h_689;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K240)
  {
    WL_POPN(3);
    Term _h_694 = STK(0);
    Term _h_695 = STK(1);
    Term _h_696 = STK(2);
    Term _h_693 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_694;
      STK(1) = _h_695;
      STK(2) = FID_RUN_K241;
      WL_PUSHN(3);
    } else {
      u64 _t_122 = task_node(e, FID_RUN_K241, WL_CONT, WL_IDX, 1);
      e.mem[_t_122 + 0] = _h_694;
      e.mem[_t_122 + 1] = _h_695;
      WL_CONT = term_tsk(FID_RUN_K241, _t_122);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_123 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_123 + 0] = _h_696;
      e.mem[_t_123 + 1] = _h_693;
      return term_tsk(FID_STRING_APPEND, _t_123);
    }
    r0 = _h_696;
    r1 = _h_693;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K241)
  {
    WL_POPN(2);
    Term _h_698 = STK(0);
    Term _h_699 = STK(1);
    Term _h_697 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_698;
      STK(1) = _h_699;
      STK(2) = FID_RUN_K242;
      WL_PUSHN(3);
    } else {
      u64 _t_124 = task_node(e, FID_RUN_K242, WL_CONT, WL_IDX, 1);
      e.mem[_t_124 + 0] = _h_698;
      e.mem[_t_124 + 1] = _h_699;
      WL_CONT = term_tsk(FID_RUN_K242, _t_124);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_125 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_125 + 0] = term_ctr(CID_SCON, STAT_OFF + 280);
      e.mem[_t_125 + 1] = _h_697;
      return term_tsk(FID_STRING_APPEND, _t_125);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 280);
    r1 = _h_697;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K242)
  {
    WL_POPN(2);
    Term _h_701 = STK(0);
    Term _h_702 = STK(1);
    Term _h_700 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_701;
      STK(1) = FID_RUN_K243;
      WL_PUSHN(2);
    } else {
      u64 _t_126 = task_node(e, FID_RUN_K243, WL_CONT, WL_IDX, 1);
      e.mem[_t_126 + 0] = _h_701;
      WL_CONT = term_tsk(FID_RUN_K243, _t_126);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_127 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_127 + 0] = _h_702;
      e.mem[_t_127 + 1] = _h_700;
      return term_tsk(FID_STRING_APPEND, _t_127);
    }
    r0 = _h_702;
    r1 = _h_700;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K243)
  {
    WL_POPN(1);
    Term _h_704 = STK(0);
    Term _h_703 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_704;
      STK(1) = FID_RUN_K244;
      WL_PUSHN(2);
    } else {
      u64 _t_128 = task_node(e, FID_RUN_K244, WL_CONT, WL_IDX, 1);
      e.mem[_t_128 + 0] = _h_704;
      WL_CONT = term_tsk(FID_RUN_K244, _t_128);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_129 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_129 + 0] = term_ctr(CID_SCON, STAT_OFF + 294);
      e.mem[_t_129 + 1] = _h_703;
      return term_tsk(FID_STRING_APPEND, _t_129);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 294);
    r1 = _h_703;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K244)
  {
    WL_POPN(1);
    Term _h_706 = STK(0);
    Term _h_705 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_RUN_K245;
      WL_PUSHN(1);
    } else {
      u64 _t_130 = task_node(e, FID_RUN_K245, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_RUN_K245, _t_130);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_131 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_131 + 0] = _h_706;
      e.mem[_t_131 + 1] = _h_705;
      return term_tsk(FID_STRING_APPEND, _t_131);
    }
    r0 = _h_706;
    r1 = _h_705;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K245)
  {
    Term _h_707 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_RUN_K246;
      WL_PUSHN(1);
    } else {
      u64 _t_132 = task_node(e, FID_RUN_K246, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_RUN_K246, _t_132);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_133 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_133 + 0] = term_ctr(CID_SCON, STAT_OFF + 308);
      e.mem[_t_133 + 1] = _h_707;
      return term_tsk(FID_STRING_APPEND, _t_133);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 308);
    r1 = _h_707;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUN_K246)
  {
    Term _h_708 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_708;
    r0 = term_clo(FID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C248, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C248, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C248)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K249;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K249, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K249, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K249)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 100ull;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K251;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K251, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K251, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_1 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 1ull;
      e.mem[_t_1 + 1] = blk_new(e, 0, 0, 0, 1, _fv_0);
      return term_tsk(FID_RUN, _t_1);
    }
    r0 = 1ull;
    r1 = blk_new(e, 0, 0, 0, 1, _fv_0);
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K251)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_0;
    r0 = term_clo(FID_MAIN_C252, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C252)
  {
    Term _h_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_12 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_1;
      e.mem[_t_12 + 1] = term_clo(FID_MAIN_C253, 0);
      e.mem[_t_12 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_12);
    }
    r0 = _h_1;
    r1 = term_clo(FID_MAIN_C253, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C253)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fv_1[1];
    _fv_1[0] = 100ull;
    Term _a_0 = blk_new(e, 0, 1ull, 0, 1, _fv_1);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, 101ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K254;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K254, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K254, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_3 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = 2ull;
      e.mem[_t_3 + 1] = _a_0;
      return term_tsk(FID_RUN, _t_3);
    }
    r0 = 2ull;
    r1 = _a_0;
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K254)
  {
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_2;
    r0 = term_clo(FID_MAIN_C255, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C255)
  {
    Term _h_3 = r0;
    Term _x_2 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_11 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_3;
      e.mem[_t_11 + 1] = term_clo(FID_MAIN_C256, 0);
      e.mem[_t_11 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_11);
    }
    r0 = _h_3;
    r1 = term_clo(FID_MAIN_C256, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C256)
  {
    Term _x_3 = r0;
    WL_OPEN
    Term _fv_2[1];
    _fv_2[0] = 100ull;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_2);
    Term _at_2 = blk_loc(e.mem, _a_1);
    Term _at_3 = blk_at(_a_1, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, 101ull);
    Term _at_4 = blk_loc(e.mem, _a_1);
    Term _at_5 = blk_at(_a_1, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, 102ull);
    Term _at_6 = blk_loc(e.mem, _a_1);
    Term _at_7 = blk_at(_a_1, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, 103ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K257;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K257, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K257, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_5 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = 4ull;
      e.mem[_t_5 + 1] = _a_1;
      return term_tsk(FID_RUN, _t_5);
    }
    r0 = 4ull;
    r1 = _a_1;
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K257)
  {
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _h_4;
    r0 = term_clo(FID_MAIN_C258, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C258)
  {
    Term _h_5 = r0;
    Term _x_4 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_10 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_5;
      e.mem[_t_10 + 1] = term_clo(FID_MAIN_C259, 0);
      e.mem[_t_10 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_10);
    }
    r0 = _h_5;
    r1 = term_clo(FID_MAIN_C259, 0);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C259)
  {
    Term _x_5 = r0;
    WL_OPEN
    Term _fv_3[1];
    _fv_3[0] = 100ull;
    Term _a_2 = blk_new(e, 0, 3ull, 0, 1, _fv_3);
    Term _at_8 = blk_loc(e.mem, _a_2);
    Term _at_9 = blk_at(_a_2, 1ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, 101ull);
    Term _at_10 = blk_loc(e.mem, _a_2);
    Term _at_11 = blk_at(_a_2, 2ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, 102ull);
    Term _at_12 = blk_loc(e.mem, _a_2);
    Term _at_13 = blk_at(_a_2, 3ull, 0);
    u32 _c_6 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, 103ull);
    Term _at_14 = blk_loc(e.mem, _a_2);
    Term _at_15 = blk_at(_a_2, 4ull, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, 104ull);
    Term _at_16 = blk_loc(e.mem, _a_2);
    Term _at_17 = blk_at(_a_2, 5ull, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_16, _at_17 + 0);
    blk_write(e.mem, 0, _at_16, _at_17 + 0, 105ull);
    Term _at_18 = blk_loc(e.mem, _a_2);
    Term _at_19 = blk_at(_a_2, 6ull, 0);
    u32 _c_9 = blk_read(e.mem, 0, _at_18, _at_19 + 0);
    blk_write(e.mem, 0, _at_18, _at_19 + 0, 106ull);
    Term _at_20 = blk_loc(e.mem, _a_2);
    Term _at_21 = blk_at(_a_2, 7ull, 0);
    u32 _c_10 = blk_read(e.mem, 0, _at_20, _at_21 + 0);
    blk_write(e.mem, 0, _at_20, _at_21 + 0, 107ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K260;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K260, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K260, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RUN)) {
      u64 _t_7 = task_node(e, FID_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = 8ull;
      e.mem[_t_7 + 1] = _a_2;
      return term_tsk(FID_RUN, _t_7);
    }
    r0 = 8ull;
    r1 = _a_2;
    WL_JMP(FID_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K260)
  {
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = _h_6;
    r0 = term_clo(FID_MAIN_C261, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C261)
  {
    Term _h_7 = r0;
    Term _x_6 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_7;
      e.mem[_t_9 + 1] = term_clo(FID_MAIN_C262, 0);
      e.mem[_t_9 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = _h_7;
    r1 = term_clo(FID_MAIN_C262, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C262)
  {
    Term _x_7 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C263, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C263)
  {
    Term _x_8 = r0;
    WL_OPEN
    Term _x_9 = term_pak(CID_UNIT, 0);
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_8 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _x_8;
      e.mem[_t_8 + 1] = _x_9;
      return term_tsk(FID_CLO_APPLY, _t_8);
    }
    r0 = _x_8;
    r1 = _x_9;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_1 = r0;
    Term _k_1 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _text_1;
    e.mem[_nd_1 + 1] = _k_1;
    r0 = term_ctr(CID_IO_PRINT, _nd_1);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
