function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return $queued$(($raw$045boundaries$058prototype_packed_motion_insert$(($world$()), {$: "storage.Handle", "namespace": 7, "id": 2}, {$: "types.Position", "coordinates": array_new(2, 700), "frame": 91})));
}

function $queued$(_result_0) {
  if (_result_0.$ === "types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$("same-world-hole-queued", _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$(($applied$(($commands$058apply_checked$(_world_0, 99)))), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $IO$pure$({$: "Unit"}, _x_5);
});
}), _x_3);
});
}), _x_0);
});
  } else {
    return (_x_6) => $IO$print$("unexpected-rejection", _x_6);
  }
}

function $raw$045boundaries$058prototype_packed_motion_insert$(_world_0, _handle_0, _raw_0) {
  return $raw$045boundaries$058prototype_packed_motion_insert_return$(($commands$058insert_main$(_world_0, _handle_0, ($cached$045payload$058prototype_slot_position_new$(_raw_0)))));
}

function $world$() {
  const _x_0 = array_new(2, 100);
  const _x_1 = (_x_0[1 % _x_0.length] = 101, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = 102, _x_1);
  const _x_3 = ($storage$058slots_empty$(2));
  const _x_4 = {$: "Some", "value": {$: "cached-payload.PrototypeMotionMainSlot", "coordinates": (_x_2[3 % _x_2.length] = 103, _x_2), "rawframe": 4, "a": 999, "b": 200, "c": 300, "d": 400, "cachedframe": 77}};
  const _x_5 = array_new(2, false);
  const _x_6 = {$: "None"};
  const _x_7 = array_new(2, _x_6);
  const _x_8 = {$: "Some", "value": {$: "types.Selected", "group": 55}};
  const _x_9 = array_new(2, 10);
  const _x_10 = (_x_9[1 % _x_9.length] = 11, _x_9);
  const _x_11 = (_x_10[2 % _x_10.length] = 12, _x_10);
  return {$: "storage.World", "namespace": 7, "next": 9, "rows": {$: "storage.Rows", "main": (_x_3[2 % _x_3.length] = _x_4, _x_3), "aux": ($storage$058slots_empty$(2)), "metadata": {$: "storage.MetadataColumns", "live": (_x_5[2 % _x_5.length] = true, _x_5), "flags": (_x_7[2 % _x_7.length] = _x_8, _x_7), "added": array_new(2, 11), "changed": array_new(2, 22)}, "capacity": 4, "depth": 2, "high_water": 3}, "pending": {$: "Con", "head": {$: "storage.Despawn", "id": 2}, "tail": {$: "Nil"}}, "ledger": {$: "Some", "value": {$: "cache.Cache", "raw": {$: "types.MotionLedger", "totals": (_x_11[3 % _x_11.length] = 13, _x_11), "epoch": 6}, "cached": {$: "types.LedgerView", "totals": {$: "types.Four", "a": 900, "b": 901, "c": 902, "d": 903}, "epoch": 88}}}, "mode": {$: "types.MotionOn"}};
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $applied$(_result_0) {
  if (_result_0.$ === "commands.Applied") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["changes"];
    if (_t_0.$ === "Nil") {
      return $finished$(4, {$: "types.PositionView", "coordinates": {$: "types.Four", "a": 999, "b": 200, "c": 300, "d": 400}, "frame": 77}, {$: "transaction.Reverted", "world": _world_0});
    } else {
      return (_x_0) => $IO$print$("unexpected-apply", _x_0);
    }
  } else {
    return (_x_1) => $IO$print$("unexpected-apply", _x_1);
  }
}

function $commands$058apply_checked$(_world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, ($commands$058preflight$(_pending_0, _rows_0)));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $raw$045boundaries$058prototype_packed_motion_insert_return$(_result_0) {
  if (_result_0.$ === "types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return {$: "types.CommandQueued", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["payload"];
    return {$: "types.CommandMissing", "world": _world_1, "payload": ($cached$045payload$058prototype_slot_position_raw$(_owner_0))};
  }
}

function $commands$058insert_main$(_world_0, _handle_0, _main_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, _main_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_main$(_x_0, _x_1);
});
}));
}

function $cached$045payload$058prototype_slot_position_new$(_raw_0) {
  return $cached$045payload$058prototype_slot_position_result$(($uncached$045payload$058position_get$(_raw_0)));
}

function $storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($storage$058slots_empty$(_d_0)), ($storage$058slots_empty$(_d_0)));
  }
}

function $finished$(_label_0, _retained_0, _result_0) {
  if (_result_0.$ === "transaction.Reverted") {
    const _t_0 = _result_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _next_0 = _t_0["next"];
    const _t_1 = _t_0["rows"];
    const _t_2 = _t_1["main"];
    if (_t_2.length !== 1) {
      const _t_3 = _t_2.slice(0, _t_2.length >> 1);
      if (_t_3.length !== 1) {
        const _t_4 = _t_3.slice(0, _t_3.length >> 1);
        if (_t_4.length === 1) {
          const _t_5 = _t_4[0];
          if (_t_5.$ === "None") {
            const _t_6 = _t_3.slice(_t_3.length >> 1);
            if (_t_6.length === 1) {
              const _t_7 = _t_6[0];
              if (_t_7.$ === "None") {
                const _t_8 = _t_2.slice(_t_2.length >> 1);
                if (_t_8.length !== 1) {
                  const _t_9 = _t_8.slice(0, _t_8.length >> 1);
                  if (_t_9.length === 1) {
                    const _t_10 = _t_9[0];
                    if (_t_10.$ === "Some") {
                      const _t_11 = _t_10["value"];
                      const _array_0 = _t_11["coordinates"];
                      const _frame_0 = _t_11["rawframe"];
                      const _a_0 = _t_11["a"];
                      const _b_0 = _t_11["b"];
                      const _c_0 = _t_11["c"];
                      const _d_0 = _t_11["d"];
                      const _cf_0 = _t_11["cachedframe"];
                      const _t_12 = _t_8.slice(_t_8.length >> 1);
                      if (_t_12.length === 1) {
                        const _t_13 = _t_12[0];
                        if (_t_13.$ === "None") {
                          const _t_14 = _t_1["aux"];
                          if (_t_14.length !== 1) {
                            const _t_15 = _t_14.slice(0, _t_14.length >> 1);
                            if (_t_15.length !== 1) {
                              const _t_16 = _t_15.slice(0, _t_15.length >> 1);
                              if (_t_16.length === 1) {
                                const _t_17 = _t_16[0];
                                if (_t_17.$ === "None") {
                                  const _t_18 = _t_15.slice(_t_15.length >> 1);
                                  if (_t_18.length === 1) {
                                    const _t_19 = _t_18[0];
                                    if (_t_19.$ === "None") {
                                      const _t_20 = _t_14.slice(_t_14.length >> 1);
                                      if (_t_20.length !== 1) {
                                        const _t_21 = _t_20.slice(0, _t_20.length >> 1);
                                        if (_t_21.length === 1) {
                                          const _t_22 = _t_21[0];
                                          if (_t_22.$ === "None") {
                                            const _t_23 = _t_20.slice(_t_20.length >> 1);
                                            if (_t_23.length === 1) {
                                              const _t_24 = _t_23[0];
                                              if (_t_24.$ === "None") {
                                                const _t_25 = _t_1["metadata"];
                                                const _t_26 = _t_25["live"];
                                                if (_t_26.length !== 1) {
                                                  const _t_27 = _t_26.slice(0, _t_26.length >> 1);
                                                  if (_t_27.length !== 1) {
                                                    const _t_28 = _t_27.slice(0, _t_27.length >> 1);
                                                    if (_t_28.length === 1) {
                                                      const _t_29 = _t_28[0];
                                                      if (!_t_29) {
                                                        const _t_30 = _t_27.slice(_t_27.length >> 1);
                                                        if (_t_30.length === 1) {
                                                          const _t_31 = _t_30[0];
                                                          if (!_t_31) {
                                                            const _t_32 = _t_26.slice(_t_26.length >> 1);
                                                            if (_t_32.length !== 1) {
                                                              const _t_33 = _t_32.slice(0, _t_32.length >> 1);
                                                              if (_t_33.length === 1) {
                                                                const _t_34 = _t_33[0];
                                                                if (_t_34) {
                                                                  const _t_35 = _t_32.slice(_t_32.length >> 1);
                                                                  if (_t_35.length === 1) {
                                                                    const _t_36 = _t_35[0];
                                                                    if (!_t_36) {
                                                                      const _t_37 = _t_25["flags"];
                                                                      if (_t_37.length !== 1) {
                                                                        const _t_38 = _t_37.slice(0, _t_37.length >> 1);
                                                                        if (_t_38.length !== 1) {
                                                                          const _t_39 = _t_38.slice(0, _t_38.length >> 1);
                                                                          if (_t_39.length === 1) {
                                                                            const _t_40 = _t_39[0];
                                                                            if (_t_40.$ === "None") {
                                                                              const _t_41 = _t_38.slice(_t_38.length >> 1);
                                                                              if (_t_41.length === 1) {
                                                                                const _t_42 = _t_41[0];
                                                                                if (_t_42.$ === "None") {
                                                                                  const _t_43 = _t_37.slice(_t_37.length >> 1);
                                                                                  if (_t_43.length !== 1) {
                                                                                    const _t_44 = _t_43.slice(0, _t_43.length >> 1);
                                                                                    if (_t_44.length === 1) {
                                                                                      const _t_45 = _t_44[0];
                                                                                      if (_t_45.$ === "Some") {
                                                                                        const _t_46 = _t_45["value"];
                                                                                        const _t_47 = _t_46["group"];
                                                                                        if (_t_47 == 55) {
                                                                                          const _t_48 = _t_43.slice(_t_43.length >> 1);
                                                                                          if (_t_48.length === 1) {
                                                                                            const _t_49 = _t_48[0];
                                                                                            if (_t_49.$ === "None") {
                                                                                              const _added_0 = _t_25["added"];
                                                                                              const _changed_0 = _t_25["changed"];
                                                                                              const _capacity_0 = _t_1["capacity"];
                                                                                              const _depth_0 = _t_1["depth"];
                                                                                              const _high_0 = _t_1["high_water"];
                                                                                              const _t_50 = _t_0["pending"];
                                                                                              if (_t_50.$ === "Nil") {
                                                                                                const _t_51 = _t_0["ledger"];
                                                                                                if (_t_51.$ === "Some") {
                                                                                                  const _t_52 = _t_51["value"];
                                                                                                  const _t_53 = _t_52["raw"];
                                                                                                  const _totals_0 = _t_53["totals"];
                                                                                                  const _epoch_0 = _t_53["epoch"];
                                                                                                  const _lc_0 = _t_52["cached"];
                                                                                                  const _t_54 = _t_0["mode"];
                                                                                                  if (_t_54.$ === "types.MotionOn") {
                                                                                                    const _x_0 = ($host$045render$058render_ledger$(_lc_0));
                                                                                                    const _x_1 = (_x_0 + "}");
                                                                                                    const _x_2 = ($U32$show$(_epoch_0));
                                                                                                    const _x_3 = (",\"ledgerCached\":" + _x_1);
                                                                                                    const _x_4 = (_x_2 + _x_3);
                                                                                                    const _x_5 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_totals_0))))));
                                                                                                    const _x_6 = (",\"epoch\":" + _x_4);
                                                                                                    const _x_7 = (_x_5 + _x_6);
                                                                                                    const _x_8 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_changed_0))))));
                                                                                                    const _x_9 = (",\"ledger\":" + _x_7);
                                                                                                    const _x_10 = (_x_8 + _x_9);
                                                                                                    const _x_11 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_added_0))))));
                                                                                                    const _x_12 = (",\"changed\":" + _x_10);
                                                                                                    const _x_13 = (_x_11 + _x_12);
                                                                                                    const _x_14 = ($U32$show$(0));
                                                                                                    const _x_15 = (",\"added\":" + _x_13);
                                                                                                    const _x_16 = (_x_14 + _x_15);
                                                                                                    const _x_17 = ($U32$show$(_high_0));
                                                                                                    const _x_18 = (",\"pending\":" + _x_16);
                                                                                                    const _x_19 = (_x_17 + _x_18);
                                                                                                    const _x_20 = ($Nat$show$(_depth_0));
                                                                                                    const _x_21 = (",\"high\":" + _x_19);
                                                                                                    const _x_22 = (_x_20 + _x_21);
                                                                                                    const _x_23 = ($U32$show$(_capacity_0));
                                                                                                    const _x_24 = (",\"depth\":" + _x_22);
                                                                                                    const _x_25 = (_x_23 + _x_24);
                                                                                                    const _x_26 = ($U32$show$(_next_0));
                                                                                                    const _x_27 = (",\"capacity\":" + _x_25);
                                                                                                    const _x_28 = (_x_26 + _x_27);
                                                                                                    const _x_29 = ($U32$show$(_ns_0));
                                                                                                    const _x_30 = (",\"next\":" + _x_28);
                                                                                                    const _x_31 = (_x_29 + _x_30);
                                                                                                    const _x_32 = ($host$045render$058render_position$(_retained_0));
                                                                                                    const _x_33 = (",\"namespace\":" + _x_31);
                                                                                                    const _x_34 = (_x_32 + _x_33);
                                                                                                    const _x_35 = ($host$045render$058render_position$({$: "types.PositionView", "coordinates": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "frame": _cf_0}));
                                                                                                    const _x_36 = (",\"retained\":" + _x_34);
                                                                                                    const _x_37 = (_x_35 + _x_36);
                                                                                                    const _x_38 = ($U32$show$(_frame_0));
                                                                                                    const _x_39 = (",\"cached\":" + _x_37);
                                                                                                    const _x_40 = (_x_38 + _x_39);
                                                                                                    const _x_41 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_array_0))))));
                                                                                                    const _x_42 = (",\"rawFrame\":" + _x_40);
                                                                                                    const _x_43 = (_x_41 + _x_42);
                                                                                                    const _x_44 = ($U32$show$(_label_0));
                                                                                                    const _x_45 = (",\"array\":" + _x_43);
                                                                                                    const _x_46 = (_x_44 + _x_45);
                                                                                                    return (_x_47) => $IO$print$(("{\"length\":" + _x_46), _x_47);
                                                                                                  } else {
                                                                                                    return (_x_48) => $IO$print$("unexpected-reverted-world", _x_48);
                                                                                                  }
                                                                                                } else {
                                                                                                  return (_x_49) => $IO$print$("unexpected-reverted-world", _x_49);
                                                                                                }
                                                                                              } else {
                                                                                                return (_x_50) => $IO$print$("unexpected-reverted-world", _x_50);
                                                                                              }
                                                                                            } else {
                                                                                              return (_x_51) => $IO$print$("unexpected-reverted-world", _x_51);
                                                                                            }
                                                                                          } else {
                                                                                            return (_x_52) => $IO$print$("unexpected-reverted-world", _x_52);
                                                                                          }
                                                                                        } else {
                                                                                          return (_x_53) => $IO$print$("unexpected-reverted-world", _x_53);
                                                                                        }
                                                                                      } else {
                                                                                        return (_x_54) => $IO$print$("unexpected-reverted-world", _x_54);
                                                                                      }
                                                                                    } else {
                                                                                      return (_x_55) => $IO$print$("unexpected-reverted-world", _x_55);
                                                                                    }
                                                                                  } else {
                                                                                    return (_x_56) => $IO$print$("unexpected-reverted-world", _x_56);
                                                                                  }
                                                                                } else {
                                                                                  return (_x_57) => $IO$print$("unexpected-reverted-world", _x_57);
                                                                                }
                                                                              } else {
                                                                                return (_x_58) => $IO$print$("unexpected-reverted-world", _x_58);
                                                                              }
                                                                            } else {
                                                                              return (_x_59) => $IO$print$("unexpected-reverted-world", _x_59);
                                                                            }
                                                                          } else {
                                                                            return (_x_60) => $IO$print$("unexpected-reverted-world", _x_60);
                                                                          }
                                                                        } else {
                                                                          return (_x_61) => $IO$print$("unexpected-reverted-world", _x_61);
                                                                        }
                                                                      } else {
                                                                        return (_x_62) => $IO$print$("unexpected-reverted-world", _x_62);
                                                                      }
                                                                    } else {
                                                                      return (_x_63) => $IO$print$("unexpected-reverted-world", _x_63);
                                                                    }
                                                                  } else {
                                                                    return (_x_64) => $IO$print$("unexpected-reverted-world", _x_64);
                                                                  }
                                                                } else {
                                                                  return (_x_65) => $IO$print$("unexpected-reverted-world", _x_65);
                                                                }
                                                              } else {
                                                                return (_x_66) => $IO$print$("unexpected-reverted-world", _x_66);
                                                              }
                                                            } else {
                                                              return (_x_67) => $IO$print$("unexpected-reverted-world", _x_67);
                                                            }
                                                          } else {
                                                            return (_x_68) => $IO$print$("unexpected-reverted-world", _x_68);
                                                          }
                                                        } else {
                                                          return (_x_69) => $IO$print$("unexpected-reverted-world", _x_69);
                                                        }
                                                      } else {
                                                        return (_x_70) => $IO$print$("unexpected-reverted-world", _x_70);
                                                      }
                                                    } else {
                                                      return (_x_71) => $IO$print$("unexpected-reverted-world", _x_71);
                                                    }
                                                  } else {
                                                    return (_x_72) => $IO$print$("unexpected-reverted-world", _x_72);
                                                  }
                                                } else {
                                                  return (_x_73) => $IO$print$("unexpected-reverted-world", _x_73);
                                                }
                                              } else {
                                                return (_x_74) => $IO$print$("unexpected-reverted-world", _x_74);
                                              }
                                            } else {
                                              return (_x_75) => $IO$print$("unexpected-reverted-world", _x_75);
                                            }
                                          } else {
                                            return (_x_76) => $IO$print$("unexpected-reverted-world", _x_76);
                                          }
                                        } else {
                                          return (_x_77) => $IO$print$("unexpected-reverted-world", _x_77);
                                        }
                                      } else {
                                        return (_x_78) => $IO$print$("unexpected-reverted-world", _x_78);
                                      }
                                    } else {
                                      return (_x_79) => $IO$print$("unexpected-reverted-world", _x_79);
                                    }
                                  } else {
                                    return (_x_80) => $IO$print$("unexpected-reverted-world", _x_80);
                                  }
                                } else {
                                  return (_x_81) => $IO$print$("unexpected-reverted-world", _x_81);
                                }
                              } else {
                                return (_x_82) => $IO$print$("unexpected-reverted-world", _x_82);
                              }
                            } else {
                              return (_x_83) => $IO$print$("unexpected-reverted-world", _x_83);
                            }
                          } else {
                            return (_x_84) => $IO$print$("unexpected-reverted-world", _x_84);
                          }
                        } else {
                          return (_x_85) => $IO$print$("unexpected-reverted-world", _x_85);
                        }
                      } else {
                        return (_x_86) => $IO$print$("unexpected-reverted-world", _x_86);
                      }
                    } else {
                      return (_x_87) => $IO$print$("unexpected-reverted-world", _x_87);
                    }
                  } else {
                    return (_x_88) => $IO$print$("unexpected-reverted-world", _x_88);
                  }
                } else {
                  return (_x_89) => $IO$print$("unexpected-reverted-world", _x_89);
                }
              } else {
                return (_x_90) => $IO$print$("unexpected-reverted-world", _x_90);
              }
            } else {
              return (_x_91) => $IO$print$("unexpected-reverted-world", _x_91);
            }
          } else {
            return (_x_92) => $IO$print$("unexpected-reverted-world", _x_92);
          }
        } else {
          return (_x_93) => $IO$print$("unexpected-reverted-world", _x_93);
        }
      } else {
        return (_x_94) => $IO$print$("unexpected-reverted-world", _x_94);
      }
    } else {
      return (_x_95) => $IO$print$("unexpected-reverted-world", _x_95);
    }
  } else {
    return (_x_96) => $IO$print$("unexpected-reverted-world", _x_96);
  }
}

function $commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, _result_0) {
  const _rows_0 = _result_0["rows"];
  const _pending_0 = _result_0["commands"];
  const _t_0 = _result_0["valid"];
  if (!_t_0) {
    return {$: "commands.CapacityRejected", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}};
  } else {
    return $commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, ($commands$058batch$(($List$reverse$(_pending_0)), _namespace_0, _tick_0, {$: "commands.Running", "rows": _rows_0, "reverseChanges": {$: "Nil"}})));
  }
}

function $commands$058preflight$(_commands_0, _rows_0) {
  return $commands$058preflight_go$(_commands_0, {$: "commands.Preflight", "rows": _rows_0, "commands": {$: "Nil"}, "valid": true});
}

function $cached$045payload$058prototype_slot_position_raw$(_owner_0) {
  const _coordinates_0 = _owner_0["coordinates"];
  const _rawframe_0 = _owner_0["rawframe"];
  return {$: "types.Position", "coordinates": _coordinates_0, "frame": _rawframe_0};
}

function $commands$058queue_owned$(_world_0, _handle_0, _payload_0, _build_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $commands$058queue_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _payload_0, _build_0);
}

function $commands$058build_main$(_id_0, _main_0) {
  return {$: "storage.InsertMain", "id": _id_0, "main": _main_0};
}

function $cached$045payload$058prototype_slot_position_result$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _coordinates_0 = _t_0["coordinates"];
  const _rawframe_0 = _t_0["frame"];
  const _t_1 = _result_0["snd"];
  const _t_2 = _t_1["coordinates"];
  const _a_0 = _t_2["a"];
  const _b_0 = _t_2["b"];
  const _c_0 = _t_2["c"];
  const _d_0 = _t_2["d"];
  const _cachedframe_0 = _t_1["frame"];
  return {$: "cached-payload.PrototypeMotionMainSlot", "coordinates": _coordinates_0, "rawframe": _rawframe_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0};
}

function $uncached$045payload$058position_get$(_owner_0) {
  const _array_0 = _owner_0["coordinates"];
  const _frame_0 = _owner_0["frame"];
  return $uncached$045payload$058position_observed$(_frame_0, ($uncached$045payload$058four$(_array_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $host$045render$058render_list$12616$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12616$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $data$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": _head_0, "tail": ($data$(_tail_0))};
  }
}

function $Array$to_list$1260$(_a_0) {
  return $Array$to_list$go$1260$(_a_0, {$: "Nil"});
}

function $host$045render$058render_position$(_value_0) {
  const _coordinates_0 = _value_0["coordinates"];
  const _frame_0 = _value_0["frame"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"coordinates\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_coordinates_0)), "tail": {$: "Con", "head": ",\"frame\":", "tail": {$: "Con", "head": ($U32$show$(_frame_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"totals\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_totals_0)), "tail": {$: "Con", "head": ",\"epoch\":", "tail": {$: "Con", "head": ($U32$show$(_epoch_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _result_0) {
  if (_result_0.$ === "commands.Completed") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Applied", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": {$: "Nil"}, "ledger": _ledger_0, "mode": _mode_0}, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    const _remaining_0 = _result_0["remaining"];
    const _changes_1 = _result_0["changes"];
    return {$: "commands.InvariantFault", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_1, "pending": ($List$reverse$(_remaining_0)), "ledger": _ledger_0, "mode": _mode_0}, "row": _row_0, "changes": _changes_1};
  }
}

function $commands$058batch$($0, $1, $2, $3) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _namespace_0 = $1;
      const _tick_0 = $2;
      const _state_0 = $3;
      if (_commands_0.$ === "Nil") {
        return $commands$058state_finish$(_state_0);
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = _namespace_0;
        $2 = _tick_0;
        $3 = ($commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0));
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $commands$058preflight_go$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        const _rows_0 = _state_0["rows"];
        const _reverse_0 = _state_0["commands"];
        const _valid_0 = _state_0["valid"];
        return {$: "commands.Preflight", "rows": _rows_0, "commands": ($List$reverse$(_reverse_0)), "valid": _valid_0};
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        const _rows_1 = _state_0["rows"];
        const _reverse_1 = _state_0["commands"];
        const _valid_1 = _state_0["valid"];
        $0 = _tail_0;
        $1 = ($commands$058preflight_step$(_reverse_1, _valid_1, ($commands$058command_bound$(_rows_1, _command_0))));
        continue;
      }
    }
  }
}

function $commands$058queue_checked$(_valid_0, _world_0, _target_0, _payload_0, _build_0) {
  if (!_valid_0) {
    return {$: "types.CommandMissing", "world": _world_0, "payload": _payload_0};
  } else {
    return {$: "types.CommandQueued", "world": ($storage$058publish$(_world_0, {$: "Con", "head": _build_0(_target_0)(_payload_0), "tail": {$: "Nil"}}))};
  }
}

function $uncached$045payload$058position_observed$(_frame_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.Position", "coordinates": _array_0, "frame": _frame_0}, "snd": {$: "types.PositionView", "coordinates": _values_0, "frame": _frame_0}};
}

function $uncached$045payload$058four$(_array_0) {
  return $uncached$045payload$058original_four$(_array_0);
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $host$045render$058render_concat$(_values_0) {
  return $host$045render$058render_chunks$(_values_0, "");
}

function $host$045render$058render_list_tail$12616$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($U32$show$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $Array$to_list$go$1260$($0, $1) {
  for (;;) {
    {
      const _a_0 = $0;
      const _acc_0 = $1;
      if (_a_0.length === 1) {
        const _x_0 = _a_0[0];
        return {$: "Con", "head": _x_0, "tail": _acc_0};
      } else {
        const _xs_0 = _a_0.slice(0, _a_0.length >> 1);
        const _ys_0 = _a_0.slice(_a_0.length >> 1);
        $0 = _xs_0;
        $1 = ($Array$to_list$go$1260$(_ys_0, _acc_0));
        continue;
      }
    }
  }
}

function $host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"a\":", "tail": {$: "Con", "head": ($U32$show$(_a_0)), "tail": {$: "Con", "head": ",\"b\":", "tail": {$: "Con", "head": ($U32$show$(_b_0)), "tail": {$: "Con", "head": ",\"c\":", "tail": {$: "Con", "head": ($U32$show$(_c_0)), "tail": {$: "Con", "head": ",\"d\":", "tail": {$: "Con", "head": ($U32$show$(_d_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $commands$058state_finish$(_state_0) {
  if (_state_0.$ === "commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return {$: "commands.Completed", "rows": _rows_0, "changes": ($List$reverse$(_changes_0))};
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "commands.BatchFault", "rows": _rows_1, "row": _row_0, "remaining": ($List$reverse$(_remaining_0)), "changes": _changes_1};
  }
}

function $commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0) {
  if (_state_0.$ === "commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return $commands$058state_step$(_changes_0, ($commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0)));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Con", "head": _command_0, "tail": _remaining_0}, "changes": _changes_1};
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $commands$058preflight_step$(_reverse_0, _valid_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _command_0 = _t_0["fst"];
  const _bounded_0 = _t_0["snd"];
  return {$: "commands.Preflight", "rows": _rows_0, "commands": {$: "Con", "head": _command_0, "tail": _reverse_0}, "valid": ($Bool$and$(_valid_0, _bounded_0))};
}

function $commands$058command_bound$(_rows_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $commands$058bounded_spawn$(_id_0, _bundle_0, ($storage$058rows_can_place$(_rows_0, _id_0)));
  } else {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": _command_0, "snd": true}};
  }
}

function $storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0};
}

function $uncached$045payload$058original_four$(_array_0) {
  return $uncached$045payload$058four_a$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return {$: "Con", "head": _value_0, "tail": _acc_0};
  } else {
    return {$: "Con", "head": _value_0, "tail": {$: "Con", "head": ",", "tail": _acc_0}};
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $commands$058state_step$(_reverseChanges_0, _result_0) {
  if (_result_0.$ === "commands.Stepped") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Running", "rows": _rows_0, "reverseChanges": ($List$reverse$go$(_changes_0, _reverseChanges_0))};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Nil"}, "changes": ($List$reverse$(_reverseChanges_0))};
  }
}

function $commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0);
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $commands$058main_effect$(_namespace_0, _id_1, ($storage$058rows_replace_main$(_rows_0, _id_1, {$: "Some", "value": _main_0}, _tick_0)));
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_2 = _command_0["id"];
    return $commands$058main_effect$(_namespace_0, _id_2, ($storage$058rows_replace_main$(_rows_0, _id_2, {$: "None"}, _tick_0)));
  } else {
    return $commands$058edit_target$(_namespace_0, _tick_0, _rows_0, ($commands$058targeted$(_command_0)));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $commands$058bounded_spawn$(_id_0, _bundle_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _valid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _valid_0}};
}

function $storage$058rows_can_place$(_rows_0, _id_0) {
  return {$: "Tuple", "fst": _rows_0, "snd": ($Bool$and$((0 < _id_0), (_id_0 <= 131072)))};
}

function $uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $uncached$045payload$058four_b$(_a_0, {$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]});
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0) {
  const _t_0 = _bundle_0["main"];
  if (_t_0.$ === "None") {
    const _aux_0 = _bundle_0["aux"];
    const _flag_0 = _bundle_0["flag"];
    return $commands$058placed$({$: "Nil"}, ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": 0, "changed": 0})));
  } else {
    const _main_0 = _t_0["value"];
    const _aux_1 = _bundle_0["aux"];
    const _flag_1 = _bundle_0["flag"];
    return $commands$058placed$({$: "Con", "head": {$: "storage.MainAdded", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}, ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": _id_0, "main": {$: "Some", "value": _main_0}, "aux": _aux_1, "flag": _flag_1, "added": _tick_0, "changed": _tick_0})));
  }
}

function $commands$058main_effect$(_namespace_0, _id_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "storage.AddedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainAdded", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}};
  } else if (_t_0.$ === "storage.ChangedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "storage.RemovedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainRemoved", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "storage.MissingMainTarget") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  }
}

function $storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _replacement_0);
}

function $commands$058edit_target$(_namespace_0, _tick_0, _rows_0, _result_0) {
  const _command_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $commands$058targeted$(_command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _id_0};
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return {$: "Tuple", "fst": {$: "storage.InsertMain", "id": _id_1, "main": _main_0}, "snd": _id_1};
  } else if (_command_0.$ === "storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    return {$: "Tuple", "fst": {$: "storage.InsertFlag", "id": _id_2, "flag": _flag_0}, "snd": _id_2};
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveMain", "id": _id_3}, "snd": _id_3};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveFlag", "id": _id_4}, "snd": _id_4};
  } else {
    const _id_5 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.Despawn", "id": _id_5}, "snd": _id_5};
  }
}

function $uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $uncached$045payload$058four_c$(_a_0, _b_0, {$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]});
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

function $commands$058placed$(_changes_0, _result_0) {
  if (_result_0.$ === "storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return {$: "commands.Stepped", "rows": _rows_0, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "commands.PlacementFault", "rows": _rows_1, "row": _row_0};
  }
}

function $storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    const _row_0 = _t_0["value"];
    return $commands$058edited$(_rows_0, _id_0, ($commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0)));
  }
}

function $storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $uncached$045payload$058four_done$(_a_0, _b_0, _c_0, {$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]});
}

function $storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_grown$(run_loop($storage$058grow$(17, _id_0, _rows_0)), {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
  }
}

function $storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $commands$058edited$(_rows_0, _id_0, _result_0) {
  const _t_0 = _result_0["row"];
  if (_t_0.$ === "Some") {
    const _row_0 = _t_0["value"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Stepped", "rows": ($storage$058rows_restore$(_rows_0, _row_0)), "changes": _changes_0};
  } else {
    const _changes_1 = _result_0["changes"];
    return $commands$058removed$(_changes_1, ($storage$058rows_remove$(_rows_0, _id_0)));
  }
}

function $commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0) {
  if (_command_0.$ === "storage.InsertFlag") {
    const _flag_0 = _command_0["flag"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return {$: "commands.RowEdit", "row": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": {$: "Some", "value": _flag_0}, "added": _added_0, "changed": _changed_0}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_1 = _row_0["id"];
    const _main_1 = _row_0["main"];
    const _aux_1 = _row_0["aux"];
    const _added_1 = _row_0["added"];
    const _changed_1 = _row_0["changed"];
    return {$: "commands.RowEdit", "row": {$: "Some", "value": {$: "storage.Row", "id": _id_1, "main": _main_1, "aux": _aux_1, "flag": {$: "None"}, "added": _added_1, "changed": _changed_1}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.InsertMain") {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.RemoveMain") {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.Despawn") {
    const _id_2 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "Some") {
      return {$: "commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "storage.MainRemoved", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Con", "head": {$: "storage.Despawned", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}}};
    } else {
      return {$: "commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "storage.Despawned", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}};
    }
  } else {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  }
}

function $storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, run_clo((_x_0) => {
  return $storage$058grow$(_n_0, _id_0, _x_0);
}));
  }
}

function $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function $storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $commands$058removed$(_changes_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  return {$: "commands.Stepped", "rows": _rows_0, "changes": _changes_0};
}

function $storage$058rows_remove$(_rows_0, _id_0) {
  return $storage$058remove_done$(_id_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, ($storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, {$: "storage.Rows", "main": array_node(_m_0, ($storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($storage$058slots_empty$(_d_0))), "metadata": ($storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0});
  }
}

function $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, () => _x_1));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = {$: "Some", "value": _value_0};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, () => _x_3));
  }
}

function $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, {$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]});
}

function $storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "None"}};
  } else {
    const _row_0 = _t_1["value"];
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": false, "flag": {$: "None"}, "added": 0, "changed": 0})), "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "Some", "value": _row_0}};
  }
}

function $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))};
}

function $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]});
}

function $storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.NoMainChange"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.RemovedMain"}};
    }
  } else {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.AddedMain"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.ChangedMain"}};
    }
  }
}

function $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return {$: "storage.Rejected", "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return {$: "storage.Placed", "rows": {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}};
  }
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);