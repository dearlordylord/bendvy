
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_TYPES_COMMANDQUEUED 13
#define CID_TYPES_COMMANDMISSING 14
#define CID_STORAGE_WORLD 15
#define CID_TYPES_MOTIONSCHEMA 16
#define CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT 17
#define CID_TYPES_VELOCITY 18
#define CID_TYPES_SELECTED 19
#define CID_CACHE_CACHE 20
#define CID_TYPES_MOTIONLEDGER 21
#define CID_TYPES_LEDGERVIEW 22
#define CID_TYPES_MOTIONON 23
#define CID_TYPES_MOTIONOFF 24
#define CID_TYPES_POSITION 25
#define CID_STORAGE_HANDLE 26
#define CID_CHR 27
#define CID_STORAGE_ROWS 28
#define CID_NIL 29
#define CID_CON 30
#define CID_STORAGE_SPAWN 31
#define CID_STORAGE_INSERTMAIN 32
#define CID_STORAGE_INSERTFLAG 33
#define CID_STORAGE_REMOVEMAIN 34
#define CID_STORAGE_REMOVEFLAG 35
#define CID_STORAGE_DESPAWN 36
#define CID_TYPES_FOUR 37
#define CID_COMMANDS_APPLIED 38
#define CID_COMMANDS_CAPACITYREJECTED 39
#define CID_COMMANDS_INVARIANTFAULT 40
#define CID_STORAGE_METADATACOLUMNS 41
#define CID_STORAGE_BUNDLE 42
#define CID_STORAGE_MAINADDED 43
#define CID_STORAGE_MAINCHANGED 44
#define CID_STORAGE_MAINREMOVED 45
#define CID_STORAGE_DESPAWNED 46
#define CID_STORAGE_ROW 47
#define CID_TYPES_POSITIONVIEW 48
#define CID_TRANSACTION_COMMITTED 49
#define CID_TRANSACTION_REVERTED 50
#define CID_COMMANDS_PREFLIGHT 51
#define CID_WNIL 52
#define CID_COMMANDS_COMPLETED 53
#define CID_COMMANDS_BATCHFAULT 54
#define CID_COMMANDS_RUNNING 55
#define CID_COMMANDS_FAULTED 56
#define CID_COMMANDS_STEPPED 57
#define CID_COMMANDS_PLACEMENTFAULT 58
#define CID_STORAGE_MISSINGMAINTARGET 59
#define CID_STORAGE_ADDEDMAIN 60
#define CID_STORAGE_CHANGEDMAIN 61
#define CID_STORAGE_REMOVEDMAIN 62
#define CID_STORAGE_NOMAINCHANGE 63
#define CID_STORAGE_PLACED 64
#define CID_STORAGE_REJECTED 65
#define CID_STORAGE_METADATA 66
#define CID_COMMANDS_ROWEDIT 67
#define CID_IO_PRINT 68
#define FID_STORAGE_GROW 0
#define FID_STORAGE_GROW_C31 1
#define FID_STORAGE_GROW_K32 2
#define FID_STORAGE_GROW_K33 3
#define FID_STORAGE_GROW_K34 4
#define FID_STORAGE_GROW_K35 5
#define FID_STORAGE_ROWS_PLACE 6
#define FID_STORAGE_ROWS_PLACE_K50 7
#define FID_COMMANDS_STEP 8
#define FID_COMMANDS_STEP_K69 9
#define FID_COMMANDS_STEP_K70 10
#define FID_U32_SHOW_GO 11
#define FID_COMMANDS_STATE_COMMAND 12
#define FID_COMMANDS_STATE_COMMAND_K82 13
#define FID_NAT_SHOW_FIN 14
#define FID_HOST_RENDER_RENDER_FOUR 15
#define FID_HOST_RENDER_RENDER_FOUR_K87 16
#define FID_HOST_RENDER_RENDER_FOUR_K88 17
#define FID_HOST_RENDER_RENDER_FOUR_K89 18
#define FID_HOST_RENDER_RENDER_FOUR_K90 19
#define FID_ARRAY_TO_LIST_GO_0 20
#define FID_ARRAY_TO_LIST_GO_0_K92 21
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16 22
#define FID_HOST_RENDER_RENDER_LIST_TAIL_16_K94 23
#define FID_COMMANDS_BATCH 24
#define FID_COMMANDS_BATCH_K105 25
#define FID_HOST_RENDER_RENDER_LEDGER 26
#define FID_HOST_RENDER_RENDER_LEDGER_K108 27
#define FID_HOST_RENDER_RENDER_LEDGER_K109 28
#define FID_NAT_SHOW 29
#define FID_HOST_RENDER_RENDER_POSITION 30
#define FID_HOST_RENDER_RENDER_POSITION_K112 31
#define FID_HOST_RENDER_RENDER_POSITION_K113 32
#define FID_ARRAY_TO_LIST_0 33
#define FID_DATA 34
#define FID_DATA_K116 35
#define FID_HOST_RENDER_RENDER_LIST_16 36
#define FID_HOST_RENDER_RENDER_LIST_16_K118 37
#define FID_U32_SHOW 38
#define FID_STRING_APPEND 39
#define FID_STRING_APPEND_K121 40
#define FID_STORAGE_SLOTS_EMPTY 41
#define FID_STORAGE_SLOTS_EMPTY_K190 42
#define FID_STORAGE_SLOTS_EMPTY_K191 43
#define FID_COMMANDS_INSERT_MAIN 44
#define FID_COMMANDS_INSERT_MAIN_C194 45
#define FID_COMMANDS_INSERT_MAIN_C195 46
#define FID_COMMANDS_INSERT_MAIN_K196 47
#define FID_COMMANDS_INSERT_MAIN_K197 48
#define FID_COMMANDS_APPLY_CHECKED 49
#define FID_COMMANDS_APPLY_CHECKED_K201 50
#define FID_APPLIED 51
#define FID_APPLIED_K203 52
#define FID_APPLIED_K204 53
#define FID_APPLIED_K205 54
#define FID_APPLIED_K206 55
#define FID_APPLIED_K207 56
#define FID_APPLIED_K208 57
#define FID_APPLIED_K209 58
#define FID_APPLIED_K210 59
#define FID_APPLIED_K211 60
#define FID_APPLIED_K212 61
#define FID_APPLIED_K213 62
#define FID_APPLIED_K214 63
#define FID_APPLIED_K215 64
#define FID_APPLIED_K216 65
#define FID_APPLIED_K217 66
#define FID_APPLIED_K218 67
#define FID_APPLIED_K219 68
#define FID_APPLIED_K220 69
#define FID_APPLIED_K221 70
#define FID_APPLIED_K222 71
#define FID_APPLIED_K223 72
#define FID_APPLIED_K224 73
#define FID_APPLIED_K225 74
#define FID_APPLIED_K226 75
#define FID_APPLIED_K227 76
#define FID_APPLIED_K228 77
#define FID_APPLIED_K229 78
#define FID_APPLIED_K230 79
#define FID_APPLIED_K231 80
#define FID_APPLIED_K232 81
#define FID_APPLIED_K233 82
#define FID_APPLIED_K234 83
#define FID_APPLIED_K235 84
#define FID_APPLIED_K236 85
#define FID_APPLIED_K237 86
#define FID_APPLIED_K238 87
#define FID_APPLIED_K239 88
#define FID_APPLIED_K240 89
#define FID_APPLIED_K241 90
#define FID_APPLIED_K242 91
#define FID_APPLIED_K243 92
#define FID_APPLIED_K244 93
#define FID_APPLIED_K245 94
#define FID_APPLIED_K246 95
#define FID_APPLIED_K247 96
#define FID_APPLIED_K248 97
#define FID_APPLIED_K249 98
#define FID_APPLIED_K250 99
#define FID_APPLIED_K251 100
#define FID_APPLIED_K252 101
#define FID_APPLIED_K253 102
#define FID_APPLIED_K254 103
#define FID_APPLIED_K255 104
#define FID_APPLIED_K256 105
#define FID_APPLIED_K257 106
#define FID_APPLIED_K258 107
#define FID_IO_BIND 108
#define FID_IO_BIND_C260 109
#define FID_IO_BIND_K261 110
#define FID_WORLD 111
#define FID_WORLD_K263 112
#define FID_WORLD_K264 113
#define FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT 114
#define FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT_K266 115
#define FID_MAIN 116
#define FID_MAIN_K276 117
#define FID_MAIN_K277 118
#define FID_MAIN_C278 119
#define FID_MAIN_C279 120
#define FID_MAIN_K280 121
#define FID_MAIN_K281 122
#define FID_MAIN_C282 123
#define FID_MAIN_C283 124
#define FID_MAIN_C284 125
#define FID_IO_PRINT 126
#define FID_IO_EMIT 127
#define FID_CLO_APPLY 128
#define FID_EXIT 129
#define FID_ENTER 130
CONSTV u8 FID_T[][3] = { { 11, 0, 2 }, { 3, 0, 2 }, { 9, 9, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 1, 1, 2 }, { 18, 0, 2 }, { 18, 9, 2 }, { 19, 0, 2 }, { 19, 19, 2 }, { 21, 19, 2 }, { 3, 0, 2 }, { 31, 0, 2 }, { 20, 19, 2 }, { 4, 0, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 24, 0, 2 }, { 24, 21, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 18, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 1, 2 }, { 16, 1, 2 }, { 16, 0, 2 }, { 26, 21, 2 }, { 39, 0, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 23, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 25, 0, 2 }, { 17, 17, 2 }, { 0, 0, 2 }, { 21, 21, 2 }, { 24, 24, 2 }, { 22, 0, 2 }, { 22, 0, 2 }, { 26, 26, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1 }, { 15, 1 }, { 0, 1 }, { 7, 1 }, { 2, 1 }, { 1, 1 }, { 2, 1 }, { 2, 1 }, { 5, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 9, 1 }, { 0, 1 }, { 2, 1 }, { 7, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 4, 1 }, { 16, 1 }, { 15, 1 }, { 25, 1 }, { 4, 1 }, { 6, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 9, 1 }, { 5, 1 }, { 4, 1 }, { 1, 1 }, { 11, 0 }, { 0, 0 }, { 10, 1 }, { 20, 1 }, { 10, 1 }, { 20, 1 }, { 10, 1 }, { 18, 1 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 9, 1 }, { 18, 1 }, { 5, 1 }, { 11, 0 }, { 2, 0 } };
#define STAT_LEN 492

#define WL_RESW 26
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
    if ((N) <= 29) break; r29 = e.mem[(A) + 29]; \
    if ((N) <= 30) break; r30 = e.mem[(A) + 30]; \
    if ((N) <= 31) break; r31 = e.mem[(A) + 31]; \
    if ((N) <= 32) break; r32 = e.mem[(A) + 32]; \
    if ((N) <= 33) break; r33 = e.mem[(A) + 33]; \
    if ((N) <= 34) break; r34 = e.mem[(A) + 34]; \
    if ((N) <= 35) break; r35 = e.mem[(A) + 35]; \
    if ((N) <= 36) break; r36 = e.mem[(A) + 36]; \
    if ((N) <= 37) break; r37 = e.mem[(A) + 37]; \
    if ((N) <= 38) break; r38 = e.mem[(A) + 38]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
    case 29: r29 = (X); \
      break; \
    case 30: r30 = (X); \
      break; \
    case 31: r31 = (X); \
      break; \
    case 32: r32 = (X); \
      break; \
    case 33: r33 = (X); \
      break; \
    case 34: r34 = (X); \
      break; \
    case 35: r35 = (X); \
      break; \
    case 36: r36 = (X); \
      break; \
    case 37: r37 = (X); \
      break; \
    case 38: r38 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35, Term r36, Term r37, Term r38

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38

#define WL_TABLE WL_X(FID_STORAGE_GROW) WL_X(FID_STORAGE_GROW_C31) WL_X(FID_STORAGE_GROW_K32) WL_X(FID_STORAGE_GROW_K33) WL_X(FID_STORAGE_GROW_K34) WL_X(FID_STORAGE_GROW_K35) WL_X(FID_STORAGE_ROWS_PLACE) WL_X(FID_STORAGE_ROWS_PLACE_K50) WL_X(FID_COMMANDS_STEP) WL_X(FID_COMMANDS_STEP_K69) WL_X(FID_COMMANDS_STEP_K70) WL_X(FID_U32_SHOW_GO) WL_X(FID_COMMANDS_STATE_COMMAND) WL_X(FID_COMMANDS_STATE_COMMAND_K82) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_HOST_RENDER_RENDER_FOUR) WL_X(FID_HOST_RENDER_RENDER_FOUR_K87) WL_X(FID_HOST_RENDER_RENDER_FOUR_K88) WL_X(FID_HOST_RENDER_RENDER_FOUR_K89) WL_X(FID_HOST_RENDER_RENDER_FOUR_K90) WL_X(FID_ARRAY_TO_LIST_GO_0) WL_X(FID_ARRAY_TO_LIST_GO_0_K92) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16) WL_X(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K94) WL_X(FID_COMMANDS_BATCH) WL_X(FID_COMMANDS_BATCH_K105) WL_X(FID_HOST_RENDER_RENDER_LEDGER) WL_X(FID_HOST_RENDER_RENDER_LEDGER_K108) WL_X(FID_HOST_RENDER_RENDER_LEDGER_K109) WL_X(FID_NAT_SHOW) WL_X(FID_HOST_RENDER_RENDER_POSITION) WL_X(FID_HOST_RENDER_RENDER_POSITION_K112) WL_X(FID_HOST_RENDER_RENDER_POSITION_K113) WL_X(FID_ARRAY_TO_LIST_0) WL_X(FID_DATA) WL_X(FID_DATA_K116) WL_X(FID_HOST_RENDER_RENDER_LIST_16) WL_X(FID_HOST_RENDER_RENDER_LIST_16_K118) WL_X(FID_U32_SHOW) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K121) WL_X(FID_STORAGE_SLOTS_EMPTY) WL_X(FID_STORAGE_SLOTS_EMPTY_K190) WL_X(FID_STORAGE_SLOTS_EMPTY_K191) WL_X(FID_COMMANDS_INSERT_MAIN) WL_X(FID_COMMANDS_INSERT_MAIN_C194) WL_X(FID_COMMANDS_INSERT_MAIN_C195) WL_X(FID_COMMANDS_INSERT_MAIN_K196) WL_X(FID_COMMANDS_INSERT_MAIN_K197) WL_X(FID_COMMANDS_APPLY_CHECKED) WL_X(FID_COMMANDS_APPLY_CHECKED_K201) WL_X(FID_APPLIED) WL_X(FID_APPLIED_K203) WL_X(FID_APPLIED_K204) WL_X(FID_APPLIED_K205) WL_X(FID_APPLIED_K206) WL_X(FID_APPLIED_K207) WL_X(FID_APPLIED_K208) WL_X(FID_APPLIED_K209) WL_X(FID_APPLIED_K210) WL_X(FID_APPLIED_K211) WL_X(FID_APPLIED_K212) WL_X(FID_APPLIED_K213) WL_X(FID_APPLIED_K214) WL_X(FID_APPLIED_K215) WL_X(FID_APPLIED_K216) WL_X(FID_APPLIED_K217) WL_X(FID_APPLIED_K218) WL_X(FID_APPLIED_K219) WL_X(FID_APPLIED_K220) WL_X(FID_APPLIED_K221) WL_X(FID_APPLIED_K222) WL_X(FID_APPLIED_K223) WL_X(FID_APPLIED_K224) WL_X(FID_APPLIED_K225) WL_X(FID_APPLIED_K226) WL_X(FID_APPLIED_K227) WL_X(FID_APPLIED_K228) WL_X(FID_APPLIED_K229) WL_X(FID_APPLIED_K230) WL_X(FID_APPLIED_K231) WL_X(FID_APPLIED_K232) WL_X(FID_APPLIED_K233) WL_X(FID_APPLIED_K234) WL_X(FID_APPLIED_K235) WL_X(FID_APPLIED_K236) WL_X(FID_APPLIED_K237) WL_X(FID_APPLIED_K238) WL_X(FID_APPLIED_K239) WL_X(FID_APPLIED_K240) WL_X(FID_APPLIED_K241) WL_X(FID_APPLIED_K242) WL_X(FID_APPLIED_K243) WL_X(FID_APPLIED_K244) WL_X(FID_APPLIED_K245) WL_X(FID_APPLIED_K246) WL_X(FID_APPLIED_K247) WL_X(FID_APPLIED_K248) WL_X(FID_APPLIED_K249) WL_X(FID_APPLIED_K250) WL_X(FID_APPLIED_K251) WL_X(FID_APPLIED_K252) WL_X(FID_APPLIED_K253) WL_X(FID_APPLIED_K254) WL_X(FID_APPLIED_K255) WL_X(FID_APPLIED_K256) WL_X(FID_APPLIED_K257) WL_X(FID_APPLIED_K258) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C260) WL_X(FID_IO_BIND_K261) WL_X(FID_WORLD) WL_X(FID_WORLD_K263) WL_X(FID_WORLD_K264) WL_X(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT) WL_X(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT_K266) WL_X(FID_MAIN) WL_X(FID_MAIN_K276) WL_X(FID_MAIN_K277) WL_X(FID_MAIN_C278) WL_X(FID_MAIN_C279) WL_X(FID_MAIN_K280) WL_X(FID_MAIN_K281) WL_X(FID_MAIN_C282) WL_X(FID_MAIN_C283) WL_X(FID_MAIN_C284) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 44ull, term_pak(CID_SNIL, 0), 58ull, term_pak(CID_SNIL, 0), 34ull, term_ctr(CID_SCON, STAT_OFF + 2), 97ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 6), 123ull, term_ctr(CID_SCON, STAT_OFF + 8), 98ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 12), 44ull, term_ctr(CID_SCON, STAT_OFF + 14), 99ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 18), 44ull, term_ctr(CID_SCON, STAT_OFF + 20), 100ull, term_ctr(CID_SCON, STAT_OFF + 4), 34ull, term_ctr(CID_SCON, STAT_OFF + 24), 44ull, term_ctr(CID_SCON, STAT_OFF + 26), 125ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 30), term_pak(CID_NIL, 0), 48ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 4), 108ull, term_ctr(CID_SCON, STAT_OFF + 36), 97ull, term_ctr(CID_SCON, STAT_OFF + 38), 116ull, term_ctr(CID_SCON, STAT_OFF + 40), 111ull, term_ctr(CID_SCON, STAT_OFF + 42), 116ull, term_ctr(CID_SCON, STAT_OFF + 44), 34ull, term_ctr(CID_SCON, STAT_OFF + 46), 123ull, term_ctr(CID_SCON, STAT_OFF + 48), 104ull, term_ctr(CID_SCON, STAT_OFF + 4), 99ull, term_ctr(CID_SCON, STAT_OFF + 52), 111ull, term_ctr(CID_SCON, STAT_OFF + 54), 112ull, term_ctr(CID_SCON, STAT_OFF + 56), 101ull, term_ctr(CID_SCON, STAT_OFF + 58), 34ull, term_ctr(CID_SCON, STAT_OFF + 60), 44ull, term_ctr(CID_SCON, STAT_OFF + 62), 101ull, term_ctr(CID_SCON, STAT_OFF + 36), 116ull, term_ctr(CID_SCON, STAT_OFF + 66), 97ull, term_ctr(CID_SCON, STAT_OFF + 68), 110ull, term_ctr(CID_SCON, STAT_OFF + 70), 105ull, term_ctr(CID_SCON, STAT_OFF + 72), 100ull, term_ctr(CID_SCON, STAT_OFF + 74), 114ull, term_ctr(CID_SCON, STAT_OFF + 76), 111ull, term_ctr(CID_SCON, STAT_OFF + 78), 111ull, term_ctr(CID_SCON, STAT_OFF + 80), 99ull, term_ctr(CID_SCON, STAT_OFF + 82), 34ull, term_ctr(CID_SCON, STAT_OFF + 84), 123ull, term_ctr(CID_SCON, STAT_OFF + 86), 101ull, term_ctr(CID_SCON, STAT_OFF + 4), 109ull, term_ctr(CID_SCON, STAT_OFF + 90), 97ull, term_ctr(CID_SCON, STAT_OFF + 92), 114ull, term_ctr(CID_SCON, STAT_OFF + 94), 102ull, term_ctr(CID_SCON, STAT_OFF + 96), 34ull, term_ctr(CID_SCON, STAT_OFF + 98), 44ull, term_ctr(CID_SCON, STAT_OFF + 100), 91ull, term_pak(CID_SNIL, 0), 93ull, term_pak(CID_SNIL, 0), term_ctr(CID_SCON, STAT_OFF + 106), term_pak(CID_NIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 24), 104ull, term_ctr(CID_SCON, STAT_OFF + 110), 99ull, term_ctr(CID_SCON, STAT_OFF + 112), 97ull, term_ctr(CID_SCON, STAT_OFF + 114), 67ull, term_ctr(CID_SCON, STAT_OFF + 116), 114ull, term_ctr(CID_SCON, STAT_OFF + 118), 101ull, term_ctr(CID_SCON, STAT_OFF + 120), 103ull, term_ctr(CID_SCON, STAT_OFF + 122), 100ull, term_ctr(CID_SCON, STAT_OFF + 124), 101ull, term_ctr(CID_SCON, STAT_OFF + 126), 108ull, term_ctr(CID_SCON, STAT_OFF + 128), 34ull, term_ctr(CID_SCON, STAT_OFF + 130), 44ull, term_ctr(CID_SCON, STAT_OFF + 132), 114ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 136), 103ull, term_ctr(CID_SCON, STAT_OFF + 138), 100ull, term_ctr(CID_SCON, STAT_OFF + 140), 101ull, term_ctr(CID_SCON, STAT_OFF + 142), 108ull, term_ctr(CID_SCON, STAT_OFF + 144), 34ull, term_ctr(CID_SCON, STAT_OFF + 146), 44ull, term_ctr(CID_SCON, STAT_OFF + 148), 103ull, term_ctr(CID_SCON, STAT_OFF + 110), 110ull, term_ctr(CID_SCON, STAT_OFF + 152), 97ull, term_ctr(CID_SCON, STAT_OFF + 154), 104ull, term_ctr(CID_SCON, STAT_OFF + 156), 99ull, term_ctr(CID_SCON, STAT_OFF + 158), 34ull, term_ctr(CID_SCON, STAT_OFF + 160), 44ull, term_ctr(CID_SCON, STAT_OFF + 162), 100ull, term_ctr(CID_SCON, STAT_OFF + 110), 100ull, term_ctr(CID_SCON, STAT_OFF + 166), 97ull, term_ctr(CID_SCON, STAT_OFF + 168), 34ull, term_ctr(CID_SCON, STAT_OFF + 170), 44ull, term_ctr(CID_SCON, STAT_OFF + 172), 103ull, term_ctr(CID_SCON, STAT_OFF + 4), 110ull, term_ctr(CID_SCON, STAT_OFF + 176), 105ull, term_ctr(CID_SCON, STAT_OFF + 178), 100ull, term_ctr(CID_SCON, STAT_OFF + 180), 110ull, term_ctr(CID_SCON, STAT_OFF + 182), 101ull, term_ctr(CID_SCON, STAT_OFF + 184), 112ull, term_ctr(CID_SCON, STAT_OFF + 186), 34ull, term_ctr(CID_SCON, STAT_OFF + 188), 44ull, term_ctr(CID_SCON, STAT_OFF + 190), 103ull, term_ctr(CID_SCON, STAT_OFF + 52), 105ull, term_ctr(CID_SCON, STAT_OFF + 194), 104ull, term_ctr(CID_SCON, STAT_OFF + 196), 34ull, term_ctr(CID_SCON, STAT_OFF + 198), 44ull, term_ctr(CID_SCON, STAT_OFF + 200), 116ull, term_ctr(CID_SCON, STAT_OFF + 52), 112ull, term_ctr(CID_SCON, STAT_OFF + 204), 101ull, term_ctr(CID_SCON, STAT_OFF + 206), 100ull, term_ctr(CID_SCON, STAT_OFF + 208), 34ull, term_ctr(CID_SCON, STAT_OFF + 210), 44ull, term_ctr(CID_SCON, STAT_OFF + 212), 121ull, term_ctr(CID_SCON, STAT_OFF + 4), 116ull, term_ctr(CID_SCON, STAT_OFF + 216), 105ull, term_ctr(CID_SCON, STAT_OFF + 218), 99ull, term_ctr(CID_SCON, STAT_OFF + 220), 97ull, term_ctr(CID_SCON, STAT_OFF + 222), 112ull, term_ctr(CID_SCON, STAT_OFF + 224), 97ull, term_ctr(CID_SCON, STAT_OFF + 226), 99ull, term_ctr(CID_SCON, STAT_OFF + 228), 34ull, term_ctr(CID_SCON, STAT_OFF + 230), 44ull, term_ctr(CID_SCON, STAT_OFF + 232), 116ull, term_ctr(CID_SCON, STAT_OFF + 4), 120ull, term_ctr(CID_SCON, STAT_OFF + 236), 101ull, term_ctr(CID_SCON, STAT_OFF + 238), 110ull, term_ctr(CID_SCON, STAT_OFF + 240), 34ull, term_ctr(CID_SCON, STAT_OFF + 242), 44ull, term_ctr(CID_SCON, STAT_OFF + 244), 99ull, term_ctr(CID_SCON, STAT_OFF + 90), 97ull, term_ctr(CID_SCON, STAT_OFF + 248), 112ull, term_ctr(CID_SCON, STAT_OFF + 250), 115ull, term_ctr(CID_SCON, STAT_OFF + 252), 101ull, term_ctr(CID_SCON, STAT_OFF + 254), 109ull, term_ctr(CID_SCON, STAT_OFF + 256), 97ull, term_ctr(CID_SCON, STAT_OFF + 258), 110ull, term_ctr(CID_SCON, STAT_OFF + 260), 34ull, term_ctr(CID_SCON, STAT_OFF + 262), 44ull, term_ctr(CID_SCON, STAT_OFF + 264), 110ull, term_ctr(CID_SCON, STAT_OFF + 110), 105ull, term_ctr(CID_SCON, STAT_OFF + 268), 97ull, term_ctr(CID_SCON, STAT_OFF + 270), 116ull, term_ctr(CID_SCON, STAT_OFF + 272), 101ull, term_ctr(CID_SCON, STAT_OFF + 274), 114ull, term_ctr(CID_SCON, STAT_OFF + 276), 34ull, term_ctr(CID_SCON, STAT_OFF + 278), 44ull, term_ctr(CID_SCON, STAT_OFF + 280), 99ull, term_ctr(CID_SCON, STAT_OFF + 116), 34ull, term_ctr(CID_SCON, STAT_OFF + 284), 44ull, term_ctr(CID_SCON, STAT_OFF + 286), 70ull, term_ctr(CID_SCON, STAT_OFF + 96), 119ull, term_ctr(CID_SCON, STAT_OFF + 290), 97ull, term_ctr(CID_SCON, STAT_OFF + 292), 114ull, term_ctr(CID_SCON, STAT_OFF + 294), 34ull, term_ctr(CID_SCON, STAT_OFF + 296), 44ull, term_ctr(CID_SCON, STAT_OFF + 298), 97ull, term_ctr(CID_SCON, STAT_OFF + 216), 114ull, term_ctr(CID_SCON, STAT_OFF + 302), 114ull, term_ctr(CID_SCON, STAT_OFF + 304), 97ull, term_ctr(CID_SCON, STAT_OFF + 306), 34ull, term_ctr(CID_SCON, STAT_OFF + 308), 44ull, term_ctr(CID_SCON, STAT_OFF + 310), 103ull, term_ctr(CID_SCON, STAT_OFF + 204), 110ull, term_ctr(CID_SCON, STAT_OFF + 314), 101ull, term_ctr(CID_SCON, STAT_OFF + 316), 108ull, term_ctr(CID_SCON, STAT_OFF + 318), 34ull, term_ctr(CID_SCON, STAT_OFF + 320), 123ull, term_ctr(CID_SCON, STAT_OFF + 322), 100ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 326), 114ull, term_ctr(CID_SCON, STAT_OFF + 328), 111ull, term_ctr(CID_SCON, STAT_OFF + 330), 119ull, term_ctr(CID_SCON, STAT_OFF + 332), 45ull, term_ctr(CID_SCON, STAT_OFF + 334), 100ull, term_ctr(CID_SCON, STAT_OFF + 336), 101ull, term_ctr(CID_SCON, STAT_OFF + 338), 116ull, term_ctr(CID_SCON, STAT_OFF + 340), 114ull, term_ctr(CID_SCON, STAT_OFF + 342), 101ull, term_ctr(CID_SCON, STAT_OFF + 344), 118ull, term_ctr(CID_SCON, STAT_OFF + 346), 101ull, term_ctr(CID_SCON, STAT_OFF + 348), 114ull, term_ctr(CID_SCON, STAT_OFF + 350), 45ull, term_ctr(CID_SCON, STAT_OFF + 352), 100ull, term_ctr(CID_SCON, STAT_OFF + 354), 101ull, term_ctr(CID_SCON, STAT_OFF + 356), 116ull, term_ctr(CID_SCON, STAT_OFF + 358), 99ull, term_ctr(CID_SCON, STAT_OFF + 360), 101ull, term_ctr(CID_SCON, STAT_OFF + 362), 112ull, term_ctr(CID_SCON, STAT_OFF + 364), 120ull, term_ctr(CID_SCON, STAT_OFF + 366), 101ull, term_ctr(CID_SCON, STAT_OFF + 368), 110ull, term_ctr(CID_SCON, STAT_OFF + 370), 117ull, term_ctr(CID_SCON, STAT_OFF + 372), 121ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 376), 112ull, term_ctr(CID_SCON, STAT_OFF + 378), 112ull, term_ctr(CID_SCON, STAT_OFF + 380), 97ull, term_ctr(CID_SCON, STAT_OFF + 382), 45ull, term_ctr(CID_SCON, STAT_OFF + 384), 100ull, term_ctr(CID_SCON, STAT_OFF + 386), 101ull, term_ctr(CID_SCON, STAT_OFF + 388), 116ull, term_ctr(CID_SCON, STAT_OFF + 390), 99ull, term_ctr(CID_SCON, STAT_OFF + 392), 101ull, term_ctr(CID_SCON, STAT_OFF + 394), 112ull, term_ctr(CID_SCON, STAT_OFF + 396), 120ull, term_ctr(CID_SCON, STAT_OFF + 398), 101ull, term_ctr(CID_SCON, STAT_OFF + 400), 110ull, term_ctr(CID_SCON, STAT_OFF + 402), 117ull, term_ctr(CID_SCON, STAT_OFF + 404), term_pak(CID_STORAGE_DESPAWN, 2ull), term_pak(CID_NIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 326), 117ull, term_ctr(CID_SCON, STAT_OFF + 410), 101ull, term_ctr(CID_SCON, STAT_OFF + 412), 117ull, term_ctr(CID_SCON, STAT_OFF + 414), 113ull, term_ctr(CID_SCON, STAT_OFF + 416), 45ull, term_ctr(CID_SCON, STAT_OFF + 418), 101ull, term_ctr(CID_SCON, STAT_OFF + 420), 108ull, term_ctr(CID_SCON, STAT_OFF + 422), 111ull, term_ctr(CID_SCON, STAT_OFF + 424), 104ull, term_ctr(CID_SCON, STAT_OFF + 426), 45ull, term_ctr(CID_SCON, STAT_OFF + 428), 100ull, term_ctr(CID_SCON, STAT_OFF + 430), 108ull, term_ctr(CID_SCON, STAT_OFF + 432), 114ull, term_ctr(CID_SCON, STAT_OFF + 434), 111ull, term_ctr(CID_SCON, STAT_OFF + 436), 119ull, term_ctr(CID_SCON, STAT_OFF + 438), 45ull, term_ctr(CID_SCON, STAT_OFF + 440), 101ull, term_ctr(CID_SCON, STAT_OFF + 442), 109ull, term_ctr(CID_SCON, STAT_OFF + 444), 97ull, term_ctr(CID_SCON, STAT_OFF + 446), 115ull, term_ctr(CID_SCON, STAT_OFF + 448), 110ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 452), 105ull, term_ctr(CID_SCON, STAT_OFF + 454), 116ull, term_ctr(CID_SCON, STAT_OFF + 456), 99ull, term_ctr(CID_SCON, STAT_OFF + 458), 101ull, term_ctr(CID_SCON, STAT_OFF + 460), 106ull, term_ctr(CID_SCON, STAT_OFF + 462), 101ull, term_ctr(CID_SCON, STAT_OFF + 464), 114ull, term_ctr(CID_SCON, STAT_OFF + 466), 45ull, term_ctr(CID_SCON, STAT_OFF + 468), 100ull, term_ctr(CID_SCON, STAT_OFF + 470), 101ull, term_ctr(CID_SCON, STAT_OFF + 472), 116ull, term_ctr(CID_SCON, STAT_OFF + 474), 99ull, term_ctr(CID_SCON, STAT_OFF + 476), 101ull, term_ctr(CID_SCON, STAT_OFF + 478), 112ull, term_ctr(CID_SCON, STAT_OFF + 480), 120ull, term_ctr(CID_SCON, STAT_OFF + 482), 101ull, term_ctr(CID_SCON, STAT_OFF + 484), 110ull, term_ctr(CID_SCON, STAT_OFF + 486), 117ull, term_ctr(CID_SCON, STAT_OFF + 488) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _c_0 = r0;
  Term _a_1 = r1;
  Term _b_1 = r2;
  WL_SPIN
    if (_c_0 == 0) {
      term_sink(e, _a_1);
      _v_1 = _b_1;
    } else {
      term_sink(e, _b_1);
      _v_1 = _a_1;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_4 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_5 = blk_at(_columns_0, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_0);
    Term _at_6 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_7 = blk_at(_columns_1, _index_0, 1);
    u32 _c_5 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_6 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _meta_1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _meta_2);
    term_sink(e, _c_6);
    Term _at_8 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_9 = blk_at(_columns_2, _index_0, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _meta_3);
    Term _at_10 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_11 = blk_at(_columns_3, _index_0, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _meta_4);
    _v_8 = _columns_0;
    _v_9 = _columns_1;
    _v_10 = _columns_2;
    _v_11 = _columns_3;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_14 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    u32 _x_0 = ((_a_0 >> 0) & 1);
    u32 _x_1 = ((_a_0 >> 1) & 1);
    u32 _x_2 = ((_a_0 >> 2) & 1);
    u32 _x_3 = ((_a_0 >> 3) & 1);
    u32 _x_4 = ((_a_0 >> 4) & 1);
    u32 _x_5 = ((_a_0 >> 5) & 1);
    u32 _x_6 = ((_a_0 >> 6) & 1);
    u32 _x_7 = ((_a_0 >> 7) & 1);
    u32 _x_8 = ((_a_0 >> 8) & 1);
    u32 _x_9 = ((_a_0 >> 9) & 1);
    u32 _x_10 = ((_a_0 >> 10) & 1);
    u32 _x_11 = ((_a_0 >> 11) & 1);
    u32 _x_12 = ((_a_0 >> 12) & 1);
    u32 _x_13 = ((_a_0 >> 13) & 1);
    u32 _x_14 = ((_a_0 >> 14) & 1);
    u32 _x_15 = ((_a_0 >> 15) & 1);
    u32 _x_16 = ((_a_0 >> 16) & 1);
    u32 _x_17 = ((_a_0 >> 17) & 1);
    u32 _x_18 = ((_a_0 >> 18) & 1);
    u32 _x_19 = ((_a_0 >> 19) & 1);
    u32 _x_20 = ((_a_0 >> 20) & 1);
    u32 _x_21 = ((_a_0 >> 21) & 1);
    u32 _x_22 = ((_a_0 >> 22) & 1);
    u32 _x_23 = ((_a_0 >> 23) & 1);
    u32 _x_24 = ((_a_0 >> 24) & 1);
    u32 _x_25 = ((_a_0 >> 25) & 1);
    u32 _x_26 = ((_a_0 >> 26) & 1);
    u32 _x_27 = ((_a_0 >> 27) & 1);
    u32 _x_28 = ((_a_0 >> 28) & 1);
    u32 _x_29 = ((_a_0 >> 29) & 1);
    u32 _x_30 = ((_a_0 >> 30) & 1);
    u32 _x_31 = ((_a_0 >> 31) & 1);
    u32 _y_0 = ((_b_0 >> 0) & 1);
    u32 _y_1 = ((_b_0 >> 1) & 1);
    u32 _y_2 = ((_b_0 >> 2) & 1);
    u32 _y_3 = ((_b_0 >> 3) & 1);
    u32 _y_4 = ((_b_0 >> 4) & 1);
    u32 _y_5 = ((_b_0 >> 5) & 1);
    u32 _y_6 = ((_b_0 >> 6) & 1);
    u32 _y_7 = ((_b_0 >> 7) & 1);
    u32 _y_8 = ((_b_0 >> 8) & 1);
    u32 _y_9 = ((_b_0 >> 9) & 1);
    u32 _y_10 = ((_b_0 >> 10) & 1);
    u32 _y_11 = ((_b_0 >> 11) & 1);
    u32 _y_12 = ((_b_0 >> 12) & 1);
    u32 _y_13 = ((_b_0 >> 13) & 1);
    u32 _y_14 = ((_b_0 >> 14) & 1);
    u32 _y_15 = ((_b_0 >> 15) & 1);
    u32 _y_16 = ((_b_0 >> 16) & 1);
    u32 _y_17 = ((_b_0 >> 17) & 1);
    u32 _y_18 = ((_b_0 >> 18) & 1);
    u32 _y_19 = ((_b_0 >> 19) & 1);
    u32 _y_20 = ((_b_0 >> 20) & 1);
    u32 _y_21 = ((_b_0 >> 21) & 1);
    u32 _y_22 = ((_b_0 >> 22) & 1);
    u32 _y_23 = ((_b_0 >> 23) & 1);
    u32 _y_24 = ((_b_0 >> 24) & 1);
    u32 _y_25 = ((_b_0 >> 25) & 1);
    u32 _y_26 = ((_b_0 >> 26) & 1);
    u32 _y_27 = ((_b_0 >> 27) & 1);
    u32 _y_28 = ((_b_0 >> 28) & 1);
    u32 _y_29 = ((_b_0 >> 29) & 1);
    u32 _y_30 = ((_b_0 >> 30) & 1);
    u32 _y_31 = ((_b_0 >> 31) & 1);
    Term _v_15 = 0;
    Term _o_1[1];
    Term _a_1 = (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31));
    Term _a_2 = (((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31));
    if (spin_0(e, _o_1, U32_BIN((((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31)), <, (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31))), _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_15 = _o_1[0];
    _v_14 = _v_15;
  break;
  }
  o[0] = _v_14;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_4 = r2;
  Term _metadata_5 = r3;
  Term _metadata_6 = r4;
  Term _metadata_7 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _live_0 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_live_0 == 1) {
      _v_19 = 1;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _metadata_4;
      _v_23 = _metadata_5;
      _v_24 = _metadata_6;
      _v_25 = _metadata_7;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _high_1;
      _v_29 = _row_9;
      _v_30 = _row_10;
      _v_31 = _row_11;
      _v_32 = _row_12;
      _v_33 = _row_13;
      _v_34 = _row_14;
      _v_35 = _row_15;
      _v_36 = _row_16;
      _v_37 = _row_17;
    } else {
      Term _at_0 = _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_10);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_11);
      term_sink(e, _c_1);
      Term _at_2 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
      Term _at_3 = blk_at(_aux_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_12);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_13);
      term_sink(e, _c_3);
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_0[4];
      if (spin_1(e, _o_0, _metadata_4, _metadata_4 == h2 ? q2 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h3 ? q3 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h4 ? q4 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h5 ? q5 : blk_loc(e.mem, _metadata_7), U32_BIN(_row_9, -, 1ull), 1, _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
        return 0;
      }
      _v_42 = _o_0[0];
      _v_43 = _o_0[1];
      _v_44 = _o_0[2];
      _v_45 = _o_0[3];
      _v_38 = _v_42;
      _v_39 = _v_43;
      _v_40 = _v_44;
      _v_41 = _v_45;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_1[1];
      if (spin_2(e, _o_1, _high_1, _row_9) == 0) {
        return 0;
      }
      _v_47 = _o_1[0];
      _v_46 = _v_47;
      _v_19 = 0;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _v_38;
      _v_23 = _v_39;
      _v_24 = _v_40;
      _v_25 = _v_41;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _v_46;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, Term r12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h16 = r16;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  Term _main_1 = r1;
  u32 _value_2 = r2;
  Term _value_3 = r3;
  Term _aux_0 = r4;
  u32 _av_0 = r5;
  Term _av_1 = r6;
  Term _metadata_4 = r7;
  Term _metadata_5 = r8;
  Term _metadata_6 = r9;
  Term _metadata_7 = r10;
  u32 _capacity_1 = r11;
  Term _depth_1 = r12;
  u32 _high_1 = r13;
  u32 _meta_5 = r14;
  u32 _meta_6 = r15;
  Term _meta_7 = r16;
  u32 _meta_8 = r17;
  u32 _meta_9 = r18;
  WL_SPIN
    _v_19 = _main_1;
    _v_20 = _aux_0;
    _v_21 = _metadata_4;
    _v_22 = _metadata_5;
    _v_23 = _metadata_6;
    _v_24 = _metadata_7;
    _v_25 = _capacity_1;
    _v_26 = _depth_1;
    _v_27 = _high_1;
    _v_28 = 1;
    _v_29 = _id_1;
    _v_30 = _value_2;
    _v_31 = _value_3;
    _v_32 = _av_0;
    _v_33 = _av_1;
    _v_34 = _meta_6;
    _v_35 = _meta_7;
    _v_36 = _meta_8;
    _v_37 = _meta_9;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _live_1 = r0;
  Term _flags_1 = r1;
  Term _added_0 = r2;
  u32 _l_1 = r3;
  u32 _f_2 = r4;
  Term _f_3 = r5;
  u32 _a_0 = r6;
  Term _result_2 = r7;
  u32 _result_3 = r8;
  WL_SPIN
    _v_9 = _live_1;
    _v_10 = _flags_1;
    _v_11 = _added_0;
    _v_12 = _result_2;
    _v_13 = _l_1;
    _v_14 = _f_2;
    _v_15 = _f_3;
    _v_16 = _a_0;
    _v_17 = _result_3;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h17 = r17;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_0 = r2;
  Term _aux_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _flag_2 = r11;
  Term _flag_3 = r12;
  u32 _added_1 = r13;
  u32 _changed_1 = r14;
  u32 _insert_1 = r15;
  u32 _old_0 = r16;
  Term _old_1 = r17;
  WL_SPIN
    if (_insert_1 == 0) {
      if (_old_0 == 0) {
        term_sink(e, _flag_3);
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _metadata_4;
        _v_13 = _metadata_5;
        _v_14 = _metadata_6;
        _v_15 = _metadata_7;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 4;
      } else {
        term_sink(e, _old_1);
        Term _v_20 = 0;
        Term _v_21 = 0;
        Term _v_22 = 0;
        Term _v_23 = 0;
        Term _v_24 = 0;
        Term _v_25 = 0;
        Term _v_26 = 0;
        Term _v_27 = 0;
        Term _o_0[4];
        if (spin_1(e, _o_0, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), 0ull, 0ull) == 0) {
          return 0;
        }
        _v_24 = _o_0[0];
        _v_25 = _o_0[1];
        _v_26 = _o_0[2];
        _v_27 = _o_0[3];
        _v_20 = _v_24;
        _v_21 = _v_25;
        _v_22 = _v_26;
        _v_23 = _v_27;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_20;
        _v_13 = _v_21;
        _v_14 = _v_22;
        _v_15 = _v_23;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 3;
      }
    } else {
      if (_old_0 == 0) {
        Term _v_28 = 0;
        Term _v_29 = 0;
        Term _v_30 = 0;
        Term _v_31 = 0;
        Term _v_32 = 0;
        Term _v_33 = 0;
        Term _v_34 = 0;
        Term _v_35 = 0;
        Term _o_1[4];
        if (spin_1(e, _o_1, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), _tick_1, _tick_1) == 0) {
          return 0;
        }
        _v_32 = _o_1[0];
        _v_33 = _o_1[1];
        _v_34 = _o_1[2];
        _v_35 = _o_1[3];
        _v_28 = _v_32;
        _v_29 = _v_33;
        _v_30 = _v_34;
        _v_31 = _v_35;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_28;
        _v_13 = _v_29;
        _v_14 = _v_30;
        _v_15 = _v_31;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 1;
      } else {
        term_sink(e, _old_1);
        Term _v_36 = 0;
        Term _v_37 = 0;
        Term _v_38 = 0;
        Term _v_39 = 0;
        Term _v_40 = 0;
        Term _v_41 = 0;
        Term _v_42 = 0;
        Term _v_43 = 0;
        Term _o_2[4];
        if (spin_1(e, _o_2, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), _added_1, _tick_1) == 0) {
          return 0;
        }
        _v_40 = _o_2[0];
        _v_41 = _o_2[1];
        _v_42 = _o_2[2];
        _v_43 = _o_2[3];
        _v_36 = _v_40;
        _v_37 = _v_41;
        _v_38 = _v_42;
        _v_39 = _v_43;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_36;
        _v_13 = _v_37;
        _v_14 = _v_38;
        _v_15 = _v_39;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 2;
      }
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  Term _result_0 = r3;
  u32 _result_1 = r4;
  WL_SPIN
    _v_5 = _result_0;
    _v_6 = _flags_0;
    _v_7 = _added_0;
    _v_8 = _changed_0;
    _v_9 = _result_1;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _row_9 = r9;
  u32 _row_10 = r10;
  Term _row_11 = r11;
  u32 _row_12 = r12;
  Term _row_13 = r13;
  u32 _row_14 = r14;
  Term _row_15 = r15;
  u32 _row_16 = r16;
  u32 _row_17 = r17;
  u32 _meta_0 = r18;
  WL_SPIN
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_3(e, _o_0, _main_1, _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _row_9, _row_10, _row_11, _row_11 == h11 ? q11 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h13 ? q13 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h15 ? q15 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  Term _main_0 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _meta_5 = r11;
  u32 _meta_6 = r12;
  Term _meta_7 = r13;
  u32 _meta_8 = r14;
  u32 _meta_9 = r15;
  Term _result_3 = r16;
  u32 _result_4 = r17;
  Term _result_5 = r18;
  WL_SPIN
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_4(e, _o_0, _id_1, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _value_0, _value_1, _value_1 == h3 ? q3 : blk_loc(e.mem, _value_1), _result_3, _result_3 == h16 ? q16 : blk_loc(e.mem, _result_3), _result_4, _result_5, _result_5 == h18 ? q18 : blk_loc(e.mem, _result_5), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _meta_5, _meta_6, _meta_7, _meta_7 == h13 ? q13 : blk_loc(e.mem, _meta_7), _meta_8, _meta_9) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _live_1 = r0;
  Term _flags_0 = r1;
  Term _changed_1 = r2;
  u32 _index_1 = r3;
  u32 _l_1 = r4;
  u32 _f_0 = r5;
  Term _f_1 = r6;
  Term _result_3 = r7;
  u32 _result_4 = r8;
  WL_SPIN
    Term _at_2 = _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1);
    Term _at_3 = blk_at(_changed_1, _index_1, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _o_0[9];
    if (spin_5(e, _o_0, _live_1, _live_1 == h0 ? q0 : blk_loc(e.mem, _live_1), _flags_0, _flags_0 == h1 ? q1 : blk_loc(e.mem, _flags_0), _result_3, _result_3 == h7 ? q7 : blk_loc(e.mem, _result_3), _l_1, _f_0, _f_1, _f_1 == h6 ? q6 : blk_loc(e.mem, _f_1), _result_4, _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _c_1) == 0) {
      return 0;
    }
    _v_18 = _o_0[0];
    _v_19 = _o_0[1];
    _v_20 = _o_0[2];
    _v_21 = _o_0[3];
    _v_22 = _o_0[4];
    _v_23 = _o_0[5];
    _v_24 = _o_0[6];
    _v_25 = _o_0[7];
    _v_26 = _o_0[8];
    _v_9 = _v_18;
    _v_10 = _v_19;
    _v_11 = _v_20;
    _v_12 = _v_21;
    _v_13 = _v_22;
    _v_14 = _v_23;
    _v_15 = _v_24;
    _v_16 = _v_25;
    _v_17 = _v_26;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _aux_1 = r2;
  Term _metadata_4 = r3;
  Term _metadata_5 = r4;
  Term _metadata_6 = r5;
  Term _metadata_7 = r6;
  u32 _capacity_1 = r7;
  Term _depth_1 = r8;
  u32 _high_1 = r9;
  u32 _flag_2 = r10;
  Term _flag_3 = r11;
  u32 _added_1 = r12;
  u32 _changed_1 = r13;
  u32 _insert_0 = r14;
  Term _result_0 = r15;
  u32 _result_1 = r16;
  Term _result_2 = r17;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[10];
    if (spin_6(e, _o_0, _id_1, _tick_1, _result_0, _result_0 == h15 ? q15 : blk_loc(e.mem, _result_0), _aux_1, _aux_1 == h2 ? q2 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h3 ? q3 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h4 ? q4 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h5 ? q5 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h6 ? q6 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_2, _flag_3, _flag_3 == h11 ? q11 : blk_loc(e.mem, _flag_3), _added_1, _changed_1, _insert_0, _result_1, _result_2, _result_2 == h17 ? q17 : blk_loc(e.mem, _result_2)) == 0) {
      return 0;
    }
    _v_20 = _o_0[0];
    _v_21 = _o_0[1];
    _v_22 = _o_0[2];
    _v_23 = _o_0[3];
    _v_24 = _o_0[4];
    _v_25 = _o_0[5];
    _v_26 = _o_0[6];
    _v_27 = _o_0[7];
    _v_28 = _o_0[8];
    _v_29 = _o_0[9];
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  Term _depth_0 = r4;
  WL_SPIN
    Term _fv_0[1];
    _fv_0[0] = 0;
    Term _fv_1[2];
    _fv_1[0] = 0;
    _fv_1[1] = 0;
    Term _fv_2[1];
    _fv_2[0] = 0ull;
    Term _fv_3[1];
    _fv_3[0] = 0ull;
    _v_8 = blk_node(e, _columns_0, blk_new(e, 0, _depth_0, 0, 1, _fv_0));
    _v_9 = blk_node(e, _columns_1, blk_new(e, 1, _depth_0, 1, 2, _fv_1));
    _v_10 = blk_node(e, _columns_2, blk_new(e, 0, _depth_0, 0, 1, _fv_2));
    _v_11 = blk_node(e, _columns_3, blk_new(e, 0, _depth_0, 0, 1, _fv_3));
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[5];
    if (spin_7(e, _o_0, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h7 = r7;
  Term h9 = r9;
  Term h11 = r11;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _main_0 = r0;
  Term _aux_0 = r1;
  u32 _capacity_0 = r2;
  Term _depth_0 = r3;
  u32 _high_0 = r4;
  u32 _row_9 = r5;
  u32 _row_10 = r6;
  Term _row_11 = r7;
  u32 _row_12 = r8;
  Term _row_13 = r9;
  u32 _row_14 = r10;
  Term _row_15 = r11;
  u32 _row_16 = r12;
  u32 _row_17 = r13;
  Term _result_0 = r14;
  Term _result_1 = r15;
  Term _result_2 = r16;
  Term _result_3 = r17;
  u32 _result_4 = r18;
  WL_SPIN
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _o_2[19];
    if (spin_8(e, _o_2, _main_0, _main_0 == h0 ? q0 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h1 ? q1 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h14 ? q14 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h15 ? q15 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h16 ? q16 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h17 ? q17 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _row_9, _row_10, _row_11, _row_11 == h7 ? q7 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h9 ? q9 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h11 ? q11 : blk_loc(e.mem, _row_15), _row_16, _row_17, _result_4) == 0) {
      return 0;
    }
    _v_58 = _o_2[0];
    _v_59 = _o_2[1];
    _v_60 = _o_2[2];
    _v_61 = _o_2[3];
    _v_62 = _o_2[4];
    _v_63 = _o_2[5];
    _v_64 = _o_2[6];
    _v_65 = _o_2[7];
    _v_66 = _o_2[8];
    _v_67 = _o_2[9];
    _v_68 = _o_2[10];
    _v_69 = _o_2[11];
    _v_70 = _o_2[12];
    _v_71 = _o_2[13];
    _v_72 = _o_2[14];
    _v_73 = _o_2[15];
    _v_74 = _o_2[16];
    _v_75 = _o_2[17];
    _v_76 = _o_2[18];
    _v_39 = _v_58;
    _v_40 = _v_59;
    _v_41 = _v_60;
    _v_42 = _v_61;
    _v_43 = _v_62;
    _v_44 = _v_63;
    _v_45 = _v_64;
    _v_46 = _v_65;
    _v_47 = _v_66;
    _v_48 = _v_67;
    _v_49 = _v_68;
    _v_50 = _v_69;
    _v_51 = _v_70;
    _v_52 = _v_71;
    _v_53 = _v_72;
    _v_54 = _v_73;
    _v_55 = _v_74;
    _v_56 = _v_75;
    _v_57 = _v_76;
  break;
  }
  o[0] = _v_39;
  o[1] = _v_40;
  o[2] = _v_41;
  o[3] = _v_42;
  o[4] = _v_43;
  o[5] = _v_44;
  o[6] = _v_45;
  o[7] = _v_46;
  o[8] = _v_47;
  o[9] = _v_48;
  o[10] = _v_49;
  o[11] = _v_50;
  o[12] = _v_51;
  o[13] = _v_52;
  o[14] = _v_53;
  o[15] = _v_54;
  o[16] = _v_55;
  o[17] = _v_56;
  o[18] = _v_57;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _meta_0 = r9;
  u32 _meta_1 = r10;
  Term _meta_2 = r11;
  u32 _meta_3 = r12;
  u32 _meta_4 = r13;
  Term _result_9 = r14;
  u32 _result_10 = r15;
  Term _result_11 = r16;
  WL_SPIN
    Term _at_2 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
    Term _at_3 = blk_at(_aux_1, U32_BIN(_id_1, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, 0);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, 0);
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_9(e, _o_0, _id_1, _result_9, _result_9 == h14 ? q14 : blk_loc(e.mem, _result_9), _result_10, _result_11, _result_11 == h16 ? q16 : blk_loc(e.mem, _result_11), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _meta_1, _meta_2, _meta_2 == h11 ? q11 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _c_2, _c_3, _c_3 == h16 ? q16 : _c_3 == h14 ? q14 : _c_3 == h11 ? q11 : _c_3 == h5 ? q5 : _c_3 == h4 ? q4 : _c_3 == h3 ? q3 : _c_3 == h2 ? q2 : _c_3 == h1 ? q1 : blk_loc(e.mem, _c_3)) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_60 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_60 = 0;
    } else {
      _v_60 = _b_0;
    }
  break;
  }
  o[0] = _v_60;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  Term _v_157 = 0;
  u32 _v_158 = 0;
  u32 _v_159 = 0;
  Term _v_160 = 0;
  u32 _v_161 = 0;
  u32 _v_162 = 0;
  Term _live_0 = r0;
  Term _added_1 = r1;
  Term _changed_1 = r2;
  u32 _index_2 = r3;
  u32 _l_0 = r4;
  Term _result_2 = r5;
  u32 _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    Term _at_4 = _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1);
    Term _at_5 = blk_at(_added_1, _index_2, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_163 = 0;
    Term _v_164 = 0;
    Term _v_165 = 0;
    Term _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    Term _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    Term _o_2[9];
    if (spin_10(e, _o_2, _live_0, _live_0 == h0 ? q0 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h5 ? q5 : blk_loc(e.mem, _result_2), _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _index_2, _l_0, _result_3, _result_4, _result_4 == h7 ? q7 : blk_loc(e.mem, _result_4), _added_1, _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1), _c_3) == 0) {
      return 0;
    }
    _v_163 = _o_2[0];
    _v_164 = _o_2[1];
    _v_165 = _o_2[2];
    _v_166 = _o_2[3];
    _v_167 = _o_2[4];
    _v_168 = _o_2[5];
    _v_169 = _o_2[6];
    _v_170 = _o_2[7];
    _v_171 = _o_2[8];
    _v_154 = _v_163;
    _v_155 = _v_164;
    _v_156 = _v_165;
    _v_157 = _v_166;
    _v_158 = _v_167;
    _v_159 = _v_168;
    _v_160 = _v_169;
    _v_161 = _v_170;
    _v_162 = _v_171;
  break;
  }
  o[0] = _v_154;
  o[1] = _v_155;
  o[2] = _v_156;
  o[3] = _v_157;
  o[4] = _v_158;
  o[5] = _v_159;
  o[6] = _v_160;
  o[7] = _v_161;
  o[8] = _v_162;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  Term _v_139 = 0;
  u32 _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  u32 _v_144 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  u32 _index_1 = r3;
  Term _result_0 = r4;
  u32 _result_1 = r5;
  WL_SPIN
    Term _at_2 = _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0);
    Term _at_3 = blk_at(_flags_0, _index_1, 1);
    u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    Term _v_148 = 0;
    u32 _v_149 = 0;
    u32 _v_150 = 0;
    Term _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    Term _o_3[9];
    if (spin_21(e, _o_3, _result_0, _result_0 == h4 ? q4 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h1 ? q1 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), _index_1, _result_1, _flags_0, _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0), _c_1, _c_2, _c_2 == h4 ? q4 : _c_2 == h2 ? q2 : _c_2 == h1 ? q1 : _c_2 == h0 ? q0 : blk_loc(e.mem, _c_2)) == 0) {
      return 0;
    }
    _v_145 = _o_3[0];
    _v_146 = _o_3[1];
    _v_147 = _o_3[2];
    _v_148 = _o_3[3];
    _v_149 = _o_3[4];
    _v_150 = _o_3[5];
    _v_151 = _o_3[6];
    _v_152 = _o_3[7];
    _v_153 = _o_3[8];
    _v_136 = _v_145;
    _v_137 = _v_146;
    _v_138 = _v_147;
    _v_139 = _v_148;
    _v_140 = _v_149;
    _v_141 = _v_150;
    _v_142 = _v_151;
    _v_143 = _v_152;
    _v_144 = _v_153;
  break;
  }
  o[0] = _v_136;
  o[1] = _v_137;
  o[2] = _v_138;
  o[3] = _v_139;
  o[4] = _v_140;
  o[5] = _v_141;
  o[6] = _v_142;
  o[7] = _v_143;
  o[8] = _v_144;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  u32 _v_122 = 0;
  u32 _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  u32 _v_126 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    u32 _v_131 = 0;
    u32 _v_132 = 0;
    Term _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    Term _o_4[9];
    if (spin_20(e, _o_4, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _index_0, _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_127 = _o_4[0];
    _v_128 = _o_4[1];
    _v_129 = _o_4[2];
    _v_130 = _o_4[3];
    _v_131 = _o_4[4];
    _v_132 = _o_4[5];
    _v_133 = _o_4[6];
    _v_134 = _o_4[7];
    _v_135 = _o_4[8];
    _v_118 = _v_127;
    _v_119 = _v_128;
    _v_120 = _v_129;
    _v_121 = _v_130;
    _v_122 = _v_131;
    _v_123 = _v_132;
    _v_124 = _v_133;
    _v_125 = _v_134;
    _v_126 = _v_135;
  break;
  }
  o[0] = _v_118;
  o[1] = _v_119;
  o[2] = _v_120;
  o[3] = _v_121;
  o[4] = _v_122;
  o[5] = _v_123;
  o[6] = _v_124;
  o[7] = _v_125;
  o[8] = _v_126;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  Term _v_194 = 0;
  Term _v_195 = 0;
  Term _v_196 = 0;
  u32 _v_197 = 0;
  Term _v_198 = 0;
  u32 _v_199 = 0;
  u32 _v_200 = 0;
  u32 _v_201 = 0;
  u32 _v_202 = 0;
  Term _v_203 = 0;
  u32 _v_204 = 0;
  Term _v_205 = 0;
  u32 _v_206 = 0;
  Term _v_207 = 0;
  u32 _v_208 = 0;
  u32 _v_209 = 0;
  u32 _id_3 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  u32 _capacity_0 = r3;
  Term _depth_0 = r4;
  u32 _high_0 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  Term _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  u32 _result_10 = r11;
  Term _result_11 = r12;
  u32 _result_12 = r13;
  u32 _result_13 = r14;
  WL_SPIN
    if (_result_9 == 0) {
      term_sink(e, _result_11);
      _v_191 = _main_0;
      _v_192 = _aux_0;
      _v_193 = _result_5;
      _v_194 = _result_6;
      _v_195 = _result_7;
      _v_196 = _result_8;
      _v_197 = _capacity_0;
      _v_198 = _depth_0;
      _v_199 = _high_0;
      _v_200 = 0;
      _v_201 = 0;
      _v_202 = 0;
      _v_203 = 0;
      _v_204 = 0;
      _v_205 = 0;
      _v_206 = 0;
      _v_207 = 0;
      _v_208 = 0;
      _v_209 = 0;
    } else {
      Term _at_6 = _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0);
      Term _at_7 = blk_at(_main_0, U32_BIN(_id_3, -, 1ull), 1);
      u32 _c_4 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
      Term _c_5 = e.mem[_at_6 + _at_7 + 1];
      blk_write(e.mem, 1, _at_6, _at_7 + 0, 0);
      blk_write(e.mem, 1, _at_6, _at_7 + 1, 0);
      Term _v_210 = 0;
      Term _v_211 = 0;
      Term _v_212 = 0;
      Term _v_213 = 0;
      Term _v_214 = 0;
      Term _v_215 = 0;
      u32 _v_216 = 0;
      Term _v_217 = 0;
      u32 _v_218 = 0;
      u32 _v_219 = 0;
      u32 _v_220 = 0;
      u32 _v_221 = 0;
      Term _v_222 = 0;
      u32 _v_223 = 0;
      Term _v_224 = 0;
      u32 _v_225 = 0;
      Term _v_226 = 0;
      u32 _v_227 = 0;
      u32 _v_228 = 0;
      Term _o_6[19];
      if (spin_15(e, _o_6, _id_3, _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _result_5, _result_5 == h6 ? q6 : blk_loc(e.mem, _result_5), _result_6, _result_6 == h7 ? q7 : blk_loc(e.mem, _result_6), _result_7, _result_7 == h8 ? q8 : blk_loc(e.mem, _result_7), _result_8, _result_8 == h9 ? q9 : blk_loc(e.mem, _result_8), _capacity_0, _depth_0, _high_0, 1, _result_10, _result_11, _result_11 == h12 ? q12 : blk_loc(e.mem, _result_11), _result_12, _result_13, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _c_4, _c_5, _c_5 == h12 ? q12 : _c_5 == h9 ? q9 : _c_5 == h8 ? q8 : _c_5 == h7 ? q7 : _c_5 == h6 ? q6 : _c_5 == h2 ? q2 : _c_5 == h1 ? q1 : blk_loc(e.mem, _c_5)) == 0) {
        return 0;
      }
      _v_210 = _o_6[0];
      _v_211 = _o_6[1];
      _v_212 = _o_6[2];
      _v_213 = _o_6[3];
      _v_214 = _o_6[4];
      _v_215 = _o_6[5];
      _v_216 = _o_6[6];
      _v_217 = _o_6[7];
      _v_218 = _o_6[8];
      _v_219 = _o_6[9];
      _v_220 = _o_6[10];
      _v_221 = _o_6[11];
      _v_222 = _o_6[12];
      _v_223 = _o_6[13];
      _v_224 = _o_6[14];
      _v_225 = _o_6[15];
      _v_226 = _o_6[16];
      _v_227 = _o_6[17];
      _v_228 = _o_6[18];
      _v_191 = _v_210;
      _v_192 = _v_211;
      _v_193 = _v_212;
      _v_194 = _v_213;
      _v_195 = _v_214;
      _v_196 = _v_215;
      _v_197 = _v_216;
      _v_198 = _v_217;
      _v_199 = _v_218;
      _v_200 = _v_219;
      _v_201 = _v_220;
      _v_202 = _v_221;
      _v_203 = _v_222;
      _v_204 = _v_223;
      _v_205 = _v_224;
      _v_206 = _v_225;
      _v_207 = _v_226;
      _v_208 = _v_227;
      _v_209 = _v_228;
    }
  break;
  }
  o[0] = _v_191;
  o[1] = _v_192;
  o[2] = _v_193;
  o[3] = _v_194;
  o[4] = _v_195;
  o[5] = _v_196;
  o[6] = _v_197;
  o[7] = _v_198;
  o[8] = _v_199;
  o[9] = _v_200;
  o[10] = _v_201;
  o[11] = _v_202;
  o[12] = _v_203;
  o[13] = _v_204;
  o[14] = _v_205;
  o[15] = _v_206;
  o[16] = _v_207;
  o[17] = _v_208;
  o[18] = _v_209;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  Term _v_93 = 0;
  u32 _v_94 = 0;
  Term _v_95 = 0;
  u32 _v_96 = 0;
  Term _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  u32 _valid_0 = r0;
  u32 _id_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_81 = _rows_18;
      _v_82 = _rows_19;
      _v_83 = _rows_20;
      _v_84 = _rows_21;
      _v_85 = _rows_22;
      _v_86 = _rows_23;
      _v_87 = _rows_24;
      _v_88 = _rows_25;
      _v_89 = _rows_26;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
      _v_99 = 0;
    } else {
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      Term _v_103 = 0;
      u32 _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      u32 _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      Term _v_112 = 0;
      u32 _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      Term _o_5[9];
      if (spin_19(e, _o_5, _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), U32_BIN(_id_2, -, 1ull)) == 0) {
        return 0;
      }
      _v_109 = _o_5[0];
      _v_110 = _o_5[1];
      _v_111 = _o_5[2];
      _v_112 = _o_5[3];
      _v_113 = _o_5[4];
      _v_114 = _o_5[5];
      _v_115 = _o_5[6];
      _v_116 = _o_5[7];
      _v_117 = _o_5[8];
      _v_100 = _v_109;
      _v_101 = _v_110;
      _v_102 = _v_111;
      _v_103 = _v_112;
      _v_104 = _v_113;
      _v_105 = _v_114;
      _v_106 = _v_115;
      _v_107 = _v_116;
      _v_108 = _v_117;
      Term _v_172 = 0;
      Term _v_173 = 0;
      Term _v_174 = 0;
      Term _v_175 = 0;
      Term _v_176 = 0;
      Term _v_177 = 0;
      u32 _v_178 = 0;
      Term _v_179 = 0;
      u32 _v_180 = 0;
      u32 _v_181 = 0;
      u32 _v_182 = 0;
      u32 _v_183 = 0;
      Term _v_184 = 0;
      u32 _v_185 = 0;
      Term _v_186 = 0;
      u32 _v_187 = 0;
      Term _v_188 = 0;
      u32 _v_189 = 0;
      u32 _v_190 = 0;
      Term _o_7[19];
      if (spin_22(e, _o_7, _id_2, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_24, _rows_25, _rows_26, _v_100, _v_100 == h7 ? q7 : _v_100 == h6 ? q6 : _v_100 == h5 ? q5 : _v_100 == h4 ? q4 : _v_100 == h3 ? q3 : _v_100 == h2 ? q2 : blk_loc(e.mem, _v_100), _v_101, _v_101 == h7 ? q7 : _v_101 == h6 ? q6 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : blk_loc(e.mem, _v_101), _v_102, _v_102 == h7 ? q7 : _v_102 == h6 ? q6 : _v_102 == h5 ? q5 : _v_102 == h4 ? q4 : _v_102 == h3 ? q3 : _v_102 == h2 ? q2 : blk_loc(e.mem, _v_102), _v_103, _v_103 == h7 ? q7 : _v_103 == h6 ? q6 : _v_103 == h5 ? q5 : _v_103 == h4 ? q4 : _v_103 == h3 ? q3 : _v_103 == h2 ? q2 : blk_loc(e.mem, _v_103), _v_104, _v_105, _v_106, _v_106 == h7 ? q7 : _v_106 == h6 ? q6 : _v_106 == h5 ? q5 : _v_106 == h4 ? q4 : _v_106 == h3 ? q3 : _v_106 == h2 ? q2 : blk_loc(e.mem, _v_106), _v_107, _v_108) == 0) {
        return 0;
      }
      _v_172 = _o_7[0];
      _v_173 = _o_7[1];
      _v_174 = _o_7[2];
      _v_175 = _o_7[3];
      _v_176 = _o_7[4];
      _v_177 = _o_7[5];
      _v_178 = _o_7[6];
      _v_179 = _o_7[7];
      _v_180 = _o_7[8];
      _v_181 = _o_7[9];
      _v_182 = _o_7[10];
      _v_183 = _o_7[11];
      _v_184 = _o_7[12];
      _v_185 = _o_7[13];
      _v_186 = _o_7[14];
      _v_187 = _o_7[15];
      _v_188 = _o_7[16];
      _v_189 = _o_7[17];
      _v_190 = _o_7[18];
      _v_81 = _v_172;
      _v_82 = _v_173;
      _v_83 = _v_174;
      _v_84 = _v_175;
      _v_85 = _v_176;
      _v_86 = _v_177;
      _v_87 = _v_178;
      _v_88 = _v_179;
      _v_89 = _v_180;
      _v_90 = _v_181;
      _v_91 = _v_182;
      _v_92 = _v_183;
      _v_93 = _v_184;
      _v_94 = _v_185;
      _v_95 = _v_186;
      _v_96 = _v_187;
      _v_97 = _v_188;
      _v_98 = _v_189;
      _v_99 = _v_190;
    }
  break;
  }
  o[0] = _v_81;
  o[1] = _v_82;
  o[2] = _v_83;
  o[3] = _v_84;
  o[4] = _v_85;
  o[5] = _v_86;
  o[6] = _v_87;
  o[7] = _v_88;
  o[8] = _v_89;
  o[9] = _v_90;
  o[10] = _v_91;
  o[11] = _v_92;
  o[12] = _v_93;
  o[13] = _v_94;
  o[14] = _v_95;
  o[15] = _v_96;
  o[16] = _v_97;
  o[17] = _v_98;
  o[18] = _v_99;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_0[1];
    if (spin_17(e, _o_0, U32_BIN(_id_1, <=, _rows_15), U32_BIN(_id_1, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_59 = _o_0[0];
    _v_58 = _v_59;
    u32 _v_61 = 0;
    Term _o_1[1];
    if (spin_17(e, _o_1, U32_BIN(0ull, <, _id_1), _v_58) == 0) {
      return 0;
    }
    _v_61 = _o_1[0];
    _v_57 = _v_61;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    Term _o_8[19];
    if (spin_18(e, _o_8, _v_57, _id_1, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17) == 0) {
      return 0;
    }
    _v_62 = _o_8[0];
    _v_63 = _o_8[1];
    _v_64 = _o_8[2];
    _v_65 = _o_8[3];
    _v_66 = _o_8[4];
    _v_67 = _o_8[5];
    _v_68 = _o_8[6];
    _v_69 = _o_8[7];
    _v_70 = _o_8[8];
    _v_71 = _o_8[9];
    _v_72 = _o_8[10];
    _v_73 = _o_8[11];
    _v_74 = _o_8[12];
    _v_75 = _o_8[13];
    _v_76 = _o_8[14];
    _v_77 = _o_8[15];
    _v_78 = _o_8[16];
    _v_79 = _o_8[17];
    _v_80 = _o_8[18];
    _v_38 = _v_62;
    _v_39 = _v_63;
    _v_40 = _v_64;
    _v_41 = _v_65;
    _v_42 = _v_66;
    _v_43 = _v_67;
    _v_44 = _v_68;
    _v_45 = _v_69;
    _v_46 = _v_70;
    _v_47 = _v_71;
    _v_48 = _v_72;
    _v_49 = _v_73;
    _v_50 = _v_74;
    _v_51 = _v_75;
    _v_52 = _v_76;
    _v_53 = _v_77;
    _v_54 = _v_78;
    _v_55 = _v_79;
    _v_56 = _v_80;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_248 = 0;
  Term _v_249 = 0;
  Term _v_250 = 0;
  Term _v_251 = 0;
  Term _v_252 = 0;
  Term _v_253 = 0;
  u32 _v_254 = 0;
  Term _v_255 = 0;
  u32 _v_256 = 0;
  u32 _v_257 = 0;
  u32 _v_258 = 0;
  u32 _v_259 = 0;
  Term _v_260 = 0;
  u32 _v_261 = 0;
  Term _v_262 = 0;
  u32 _v_263 = 0;
  Term _v_264 = 0;
  u32 _v_265 = 0;
  u32 _v_266 = 0;
  u32 _id_4 = r0;
  Term _result_14 = r1;
  Term _result_15 = r2;
  Term _result_16 = r3;
  Term _result_17 = r4;
  Term _result_18 = r5;
  Term _result_19 = r6;
  u32 _result_20 = r7;
  Term _result_21 = r8;
  u32 _result_22 = r9;
  u32 _result_23 = r10;
  u32 _result_24 = r11;
  u32 _result_25 = r12;
  Term _result_26 = r13;
  u32 _result_27 = r14;
  Term _result_28 = r15;
  u32 _result_29 = r16;
  Term _result_30 = r17;
  u32 _result_31 = r18;
  u32 _result_32 = r19;
  WL_SPIN
    if (_result_23 == 0) {
      _v_248 = _result_14;
      _v_249 = _result_15;
      _v_250 = _result_16;
      _v_251 = _result_17;
      _v_252 = _result_18;
      _v_253 = _result_19;
      _v_254 = _result_20;
      _v_255 = _result_21;
      _v_256 = _result_22;
      _v_257 = 0;
      _v_258 = 0;
      _v_259 = 0;
      _v_260 = 0;
      _v_261 = 0;
      _v_262 = 0;
      _v_263 = 0;
      _v_264 = 0;
      _v_265 = 0;
      _v_266 = 0;
    } else {
      Term _v_267 = 0;
      Term _v_268 = 0;
      Term _v_269 = 0;
      Term _v_270 = 0;
      Term _v_271 = 0;
      Term _v_272 = 0;
      Term _v_273 = 0;
      Term _v_274 = 0;
      Term _o_10[4];
      Term _a_1 = 0;
      if (spin_1(e, _o_10, _result_16, _result_16 == h3 ? q3 : blk_loc(e.mem, _result_16), _result_17, _result_17 == h4 ? q4 : blk_loc(e.mem, _result_17), _result_18, _result_18 == h5 ? q5 : blk_loc(e.mem, _result_18), _result_19, _result_19 == h6 ? q6 : blk_loc(e.mem, _result_19), U32_BIN(_id_4, -, 1ull), 0, 0, _a_1, _a_1 == h17 ? q17 : _a_1 == h15 ? q15 : _a_1 == h13 ? q13 : _a_1 == h6 ? q6 : _a_1 == h5 ? q5 : _a_1 == h4 ? q4 : _a_1 == h3 ? q3 : _a_1 == h2 ? q2 : _a_1 == h1 ? q1 : blk_loc(e.mem, _a_1), 0ull, 0ull) == 0) {
        return 0;
      }
      _v_271 = _o_10[0];
      _v_272 = _o_10[1];
      _v_273 = _o_10[2];
      _v_274 = _o_10[3];
      _v_267 = _v_271;
      _v_268 = _v_272;
      _v_269 = _v_273;
      _v_270 = _v_274;
      _v_248 = _result_14;
      _v_249 = _result_15;
      _v_250 = _v_267;
      _v_251 = _v_268;
      _v_252 = _v_269;
      _v_253 = _v_270;
      _v_254 = _result_20;
      _v_255 = _result_21;
      _v_256 = _result_22;
      _v_257 = 1;
      _v_258 = _result_24;
      _v_259 = _result_25;
      _v_260 = _result_26;
      _v_261 = _result_27;
      _v_262 = _result_28;
      _v_263 = _result_29;
      _v_264 = _result_30;
      _v_265 = _result_31;
      _v_266 = _result_32;
    }
  break;
  }
  o[0] = _v_248;
  o[1] = _v_249;
  o[2] = _v_250;
  o[3] = _v_251;
  o[4] = _v_252;
  o[5] = _v_253;
  o[6] = _v_254;
  o[7] = _v_255;
  o[8] = _v_256;
  o[9] = _v_257;
  o[10] = _v_258;
  o[11] = _v_259;
  o[12] = _v_260;
  o[13] = _v_261;
  o[14] = _v_262;
  o[15] = _v_263;
  o[16] = _v_264;
  o[17] = _v_265;
  o[18] = _v_266;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h16 = r16;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _flag_0 = r11;
  Term _flag_1 = r12;
  u32 _added_0 = r13;
  u32 _changed_0 = r14;
  u32 _replacement_2 = r15;
  Term _replacement_3 = r16;
  WL_SPIN
    if (_replacement_2 == 0) {
      Term _at_0 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, 0);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, 0);
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _o_0[10];
      if (spin_11(e, _o_0, _id_1, _tick_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_0, _changed_0, 0, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_0, _c_1, _c_1 == h16 ? q16 : _c_1 == h12 ? q12 : _c_1 == h7 ? q7 : _c_1 == h6 ? q6 : _c_1 == h5 ? q5 : _c_1 == h4 ? q4 : _c_1 == h3 ? q3 : _c_1 == h2 ? q2 : blk_loc(e.mem, _c_1)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    } else {
      Term _at_2 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
      Term _at_3 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, 1);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _replacement_3);
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      u32 _v_36 = 0;
      Term _v_37 = 0;
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      Term _o_1[10];
      if (spin_11(e, _o_1, _id_1, _tick_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_0, _changed_0, 1, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_2, _c_3, _c_3 == h16 ? q16 : _c_3 == h12 ? q12 : _c_3 == h7 ? q7 : _c_3 == h6 ? q6 : _c_3 == h5 ? q5 : _c_3 == h4 ? q4 : _c_3 == h3 ? q3 : _c_3 == h2 ? q2 : blk_loc(e.mem, _c_3)) == 0) {
        return 0;
      }
      _v_30 = _o_1[0];
      _v_31 = _o_1[1];
      _v_32 = _o_1[2];
      _v_33 = _o_1[3];
      _v_34 = _o_1[4];
      _v_35 = _o_1[5];
      _v_36 = _o_1[6];
      _v_37 = _o_1[7];
      _v_38 = _o_1[8];
      _v_39 = _o_1[9];
      _v_10 = _v_30;
      _v_11 = _v_31;
      _v_12 = _v_32;
      _v_13 = _v_33;
      _v_14 = _v_34;
      _v_15 = _v_35;
      _v_16 = _v_36;
      _v_17 = _v_37;
      _v_18 = _v_38;
      _v_19 = _v_39;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _valid_0 = r0;
  Term _rows_9 = r1;
  Term _rows_10 = r2;
  Term _rows_11 = r3;
  Term _rows_12 = r4;
  Term _rows_13 = r5;
  Term _rows_14 = r6;
  u32 _rows_15 = r7;
  Term _rows_16 = r8;
  u32 _rows_17 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_21 = 1;
      _v_22 = _rows_9;
      _v_23 = _rows_10;
      _v_24 = _rows_11;
      _v_25 = _rows_12;
      _v_26 = _rows_13;
      _v_27 = _rows_14;
      _v_28 = _rows_15;
      _v_29 = _rows_16;
      _v_30 = _rows_17;
      _v_31 = _row_9;
      _v_32 = _row_10;
      _v_33 = _row_11;
      _v_34 = _row_12;
      _v_35 = _row_13;
      _v_36 = _row_14;
      _v_37 = _row_15;
      _v_38 = _row_16;
      _v_39 = _row_17;
    } else {
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      u32 _v_49 = 0;
      Term _o_1[5];
      if (spin_13(e, _o_1, _rows_11, _rows_11 == h3 ? q3 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h4 ? q4 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h5 ? q5 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h6 ? q6 : blk_loc(e.mem, _rows_14), U32_BIN(_row_9, -, 1ull)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_46 = _o_1[1];
      _v_47 = _o_1[2];
      _v_48 = _o_1[3];
      _v_49 = _o_1[4];
      _v_40 = _v_45;
      _v_41 = _v_46;
      _v_42 = _v_47;
      _v_43 = _v_48;
      _v_44 = _v_49;
      u32 _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      Term _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      u32 _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      Term _o_2[19];
      if (spin_14(e, _o_2, _rows_9, _rows_9 == h1 ? q1 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h2 ? q2 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _row_9, _row_10, _row_11, _row_11 == h12 ? q12 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h14 ? q14 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17, _v_40, _v_40 == h16 ? q16 : _v_40 == h14 ? q14 : _v_40 == h12 ? q12 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h16 ? q16 : _v_41 == h14 ? q14 : _v_41 == h12 ? q12 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h16 ? q16 : _v_42 == h14 ? q14 : _v_42 == h12 ? q12 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h16 ? q16 : _v_43 == h14 ? q14 : _v_43 == h12 ? q12 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : blk_loc(e.mem, _v_43), _v_44) == 0) {
        return 0;
      }
      _v_50 = _o_2[0];
      _v_51 = _o_2[1];
      _v_52 = _o_2[2];
      _v_53 = _o_2[3];
      _v_54 = _o_2[4];
      _v_55 = _o_2[5];
      _v_56 = _o_2[6];
      _v_57 = _o_2[7];
      _v_58 = _o_2[8];
      _v_59 = _o_2[9];
      _v_60 = _o_2[10];
      _v_61 = _o_2[11];
      _v_62 = _o_2[12];
      _v_63 = _o_2[13];
      _v_64 = _o_2[14];
      _v_65 = _o_2[15];
      _v_66 = _o_2[16];
      _v_67 = _o_2[17];
      _v_68 = _o_2[18];
      _v_21 = _v_50;
      _v_22 = _v_51;
      _v_23 = _v_52;
      _v_24 = _v_53;
      _v_25 = _v_54;
      _v_26 = _v_55;
      _v_27 = _v_56;
      _v_28 = _v_57;
      _v_29 = _v_58;
      _v_30 = _v_59;
      _v_31 = _v_60;
      _v_32 = _v_61;
      _v_33 = _v_62;
      _v_34 = _v_63;
      _v_35 = _v_64;
      _v_36 = _v_65;
      _v_37 = _v_66;
      _v_38 = _v_67;
      _v_39 = _v_68;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_0 = r9;
  u32 _row_1 = r10;
  Term _row_2 = r11;
  u32 _row_3 = r12;
  Term _row_4 = r13;
  u32 _row_5 = r14;
  Term _row_6 = r15;
  u32 _row_7 = r16;
  u32 _row_8 = r17;
  WL_SPIN
    Term _at_0 = _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9);
    Term _at_1 = blk_at(_rows_9, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_2);
    term_sink(e, _c_1);
    Term _at_2 = _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10);
    Term _at_3 = blk_at(_rows_10, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_3);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_4);
    term_sink(e, _c_3);
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _o_0[4];
    if (spin_1(e, _o_0, _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), U32_BIN(_row_0, -, 1ull), 1, _row_5, _row_6, _row_6 == h15 ? q15 : blk_loc(e.mem, _row_6), _row_7, _row_8) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_32 = _o_0[1];
    _v_33 = _o_0[2];
    _v_34 = _o_0[3];
    _v_27 = _v_31;
    _v_28 = _v_32;
    _v_29 = _v_33;
    _v_30 = _v_34;
    _v_18 = _rows_9;
    _v_19 = _rows_10;
    _v_20 = _v_27;
    _v_21 = _v_28;
    _v_22 = _v_29;
    _v_23 = _v_30;
    _v_24 = _rows_15;
    _v_25 = _rows_16;
    _v_26 = _rows_17;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_73 = 0;
  Term _v_74 = 0;
  Term _v_75 = 0;
  Term _v_76 = 0;
  Term _v_77 = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _rows_18 = r0;
  Term _rows_19 = r1;
  Term _rows_20 = r2;
  Term _rows_21 = r3;
  Term _rows_22 = r4;
  Term _rows_23 = r5;
  u32 _rows_24 = r6;
  Term _rows_25 = r7;
  u32 _rows_26 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    Term _v_104 = 0;
    u32 _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    Term _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    Term _v_116 = 0;
    u32 _v_117 = 0;
    Term _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    Term _v_123 = 0;
    u32 _v_124 = 0;
    Term _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    Term _o_2[19];
    if (spin_16(e, _o_2, _rows_18, _rows_18 == h0 ? q0 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h1 ? q1 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h2 ? q2 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h3 ? q3 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h4 ? q4 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h5 ? q5 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26, _id_1) == 0) {
      return 0;
    }
    _v_111 = _o_2[0];
    _v_112 = _o_2[1];
    _v_113 = _o_2[2];
    _v_114 = _o_2[3];
    _v_115 = _o_2[4];
    _v_116 = _o_2[5];
    _v_117 = _o_2[6];
    _v_118 = _o_2[7];
    _v_119 = _o_2[8];
    _v_120 = _o_2[9];
    _v_121 = _o_2[10];
    _v_122 = _o_2[11];
    _v_123 = _o_2[12];
    _v_124 = _o_2[13];
    _v_125 = _o_2[14];
    _v_126 = _o_2[15];
    _v_127 = _o_2[16];
    _v_128 = _o_2[17];
    _v_129 = _o_2[18];
    _v_92 = _v_111;
    _v_93 = _v_112;
    _v_94 = _v_113;
    _v_95 = _v_114;
    _v_96 = _v_115;
    _v_97 = _v_116;
    _v_98 = _v_117;
    _v_99 = _v_118;
    _v_100 = _v_119;
    _v_101 = _v_120;
    _v_102 = _v_121;
    _v_103 = _v_122;
    _v_104 = _v_123;
    _v_105 = _v_124;
    _v_106 = _v_125;
    _v_107 = _v_126;
    _v_108 = _v_127;
    _v_109 = _v_128;
    _v_110 = _v_129;
    Term _v_130 = 0;
    Term _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    Term _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    Term _v_142 = 0;
    u32 _v_143 = 0;
    Term _v_144 = 0;
    u32 _v_145 = 0;
    Term _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    Term _o_3[19];
    if (spin_23(e, _o_3, _id_1, _v_92, _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : _v_92 == h2 ? q2 : _v_92 == h1 ? q1 : _v_92 == h0 ? q0 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h5 ? q5 : _v_93 == h4 ? q4 : _v_93 == h3 ? q3 : _v_93 == h2 ? q2 : _v_93 == h1 ? q1 : _v_93 == h0 ? q0 : blk_loc(e.mem, _v_93), _v_94, _v_94 == h5 ? q5 : _v_94 == h4 ? q4 : _v_94 == h3 ? q3 : _v_94 == h2 ? q2 : _v_94 == h1 ? q1 : _v_94 == h0 ? q0 : blk_loc(e.mem, _v_94), _v_95, _v_95 == h5 ? q5 : _v_95 == h4 ? q4 : _v_95 == h3 ? q3 : _v_95 == h2 ? q2 : _v_95 == h1 ? q1 : _v_95 == h0 ? q0 : blk_loc(e.mem, _v_95), _v_96, _v_96 == h5 ? q5 : _v_96 == h4 ? q4 : _v_96 == h3 ? q3 : _v_96 == h2 ? q2 : _v_96 == h1 ? q1 : _v_96 == h0 ? q0 : blk_loc(e.mem, _v_96), _v_97, _v_97 == h5 ? q5 : _v_97 == h4 ? q4 : _v_97 == h3 ? q3 : _v_97 == h2 ? q2 : _v_97 == h1 ? q1 : _v_97 == h0 ? q0 : blk_loc(e.mem, _v_97), _v_98, _v_99, _v_100, _v_101, _v_102, _v_103, _v_104, _v_104 == h5 ? q5 : _v_104 == h4 ? q4 : _v_104 == h3 ? q3 : _v_104 == h2 ? q2 : _v_104 == h1 ? q1 : _v_104 == h0 ? q0 : blk_loc(e.mem, _v_104), _v_105, _v_106, _v_106 == h5 ? q5 : _v_106 == h4 ? q4 : _v_106 == h3 ? q3 : _v_106 == h2 ? q2 : _v_106 == h1 ? q1 : _v_106 == h0 ? q0 : blk_loc(e.mem, _v_106), _v_107, _v_108, _v_108 == h5 ? q5 : _v_108 == h4 ? q4 : _v_108 == h3 ? q3 : _v_108 == h2 ? q2 : _v_108 == h1 ? q1 : _v_108 == h0 ? q0 : blk_loc(e.mem, _v_108), _v_109, _v_110) == 0) {
      return 0;
    }
    _v_130 = _o_3[0];
    _v_131 = _o_3[1];
    _v_132 = _o_3[2];
    _v_133 = _o_3[3];
    _v_134 = _o_3[4];
    _v_135 = _o_3[5];
    _v_136 = _o_3[6];
    _v_137 = _o_3[7];
    _v_138 = _o_3[8];
    _v_139 = _o_3[9];
    _v_140 = _o_3[10];
    _v_141 = _o_3[11];
    _v_142 = _o_3[12];
    _v_143 = _o_3[13];
    _v_144 = _o_3[14];
    _v_145 = _o_3[15];
    _v_146 = _o_3[16];
    _v_147 = _o_3[17];
    _v_148 = _o_3[18];
    _v_73 = _v_130;
    _v_74 = _v_131;
    _v_75 = _v_132;
    _v_76 = _v_133;
    _v_77 = _v_134;
    _v_78 = _v_135;
    _v_79 = _v_136;
    _v_80 = _v_137;
    _v_81 = _v_138;
    _v_82 = _v_139;
    _v_83 = _v_140;
    _v_84 = _v_141;
    _v_85 = _v_142;
    _v_86 = _v_143;
    _v_87 = _v_144;
    _v_88 = _v_145;
    _v_89 = _v_146;
    _v_90 = _v_147;
    _v_91 = _v_148;
  break;
  }
  o[0] = _v_73;
  o[1] = _v_74;
  o[2] = _v_75;
  o[3] = _v_76;
  o[4] = _v_77;
  o[5] = _v_78;
  o[6] = _v_79;
  o[7] = _v_80;
  o[8] = _v_81;
  o[9] = _v_82;
  o[10] = _v_83;
  o[11] = _v_84;
  o[12] = _v_85;
  o[13] = _v_86;
  o[14] = _v_87;
  o[15] = _v_88;
  o[16] = _v_89;
  o[17] = _v_90;
  o[18] = _v_91;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_168 = 0;
  Term _v_169 = 0;
  Term _v_170 = 0;
  Term _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  Term _v_176 = 0;
  u32 _v_177 = 0;
  Term _v_178 = 0;
  u32 _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  Term _v_184 = 0;
  u32 _v_185 = 0;
  u32 _v_186 = 0;
  Term _changes_0 = r0;
  Term _result_11 = r1;
  Term _result_12 = r2;
  Term _result_13 = r3;
  Term _result_14 = r4;
  Term _result_15 = r5;
  Term _result_16 = r6;
  u32 _result_17 = r7;
  Term _result_18 = r8;
  u32 _result_19 = r9;
  u32 _result_20 = r10;
  u32 _result_21 = r11;
  u32 _result_22 = r12;
  Term _result_23 = r13;
  u32 _result_24 = r14;
  Term _result_25 = r15;
  u32 _result_26 = r16;
  Term _result_27 = r17;
  u32 _result_28 = r18;
  u32 _result_29 = r19;
  WL_SPIN
    term_sink(e, _result_23);
    term_sink(e, _result_25);
    term_sink(e, _result_27);
    _v_168 = 0;
    _v_169 = _result_11;
    _v_170 = _result_12;
    _v_171 = _result_13;
    _v_172 = _result_14;
    _v_173 = _result_15;
    _v_174 = _result_16;
    _v_175 = _result_17;
    _v_176 = _result_18;
    _v_177 = _result_19;
    _v_178 = _changes_0;
    _v_179 = 0;
    _v_180 = 0;
    _v_181 = 0;
    _v_182 = 0;
    _v_183 = 0;
    _v_184 = 0;
    _v_185 = 0;
    _v_186 = 0;
  break;
  }
  o[0] = _v_168;
  o[1] = _v_169;
  o[2] = _v_170;
  o[3] = _v_171;
  o[4] = _v_172;
  o[5] = _v_173;
  o[6] = _v_174;
  o[7] = _v_175;
  o[8] = _v_176;
  o[9] = _v_177;
  o[10] = _v_178;
  o[11] = _v_179;
  o[12] = _v_180;
  o[13] = _v_181;
  o[14] = _v_182;
  o[15] = _v_183;
  o[16] = _v_184;
  o[17] = _v_185;
  o[18] = _v_186;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _metadata_0 = r4;
  Term _metadata_1 = r5;
  Term _metadata_2 = r6;
  Term _metadata_3 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _replacement_2 = r11;
  Term _replacement_3 = r12;
  u32 _meta_0 = r13;
  u32 _meta_1 = r14;
  Term _meta_2 = r15;
  u32 _meta_3 = r16;
  u32 _meta_4 = r17;
  WL_SPIN
    if (_meta_0 == 0) {
      term_sink(e, _replacement_3);
      term_sink(e, _meta_2);
      _v_10 = _main_1;
      _v_11 = _aux_1;
      _v_12 = _metadata_0;
      _v_13 = _metadata_1;
      _v_14 = _metadata_2;
      _v_15 = _metadata_3;
      _v_16 = _capacity_1;
      _v_17 = _depth_1;
      _v_18 = _high_1;
      _v_19 = 0;
    } else {
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _o_0[10];
      if (spin_24(e, _o_0, _id_1, _tick_1, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h4 ? q4 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h5 ? q5 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h6 ? q6 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h7 ? q7 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_1, _meta_2, _meta_2 == h15 ? q15 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _replacement_2, _replacement_3, _replacement_3 == h12 ? q12 : blk_loc(e.mem, _replacement_3)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_18 = r9;
  u32 _row_19 = r10;
  Term _row_20 = r11;
  u32 _row_21 = r12;
  Term _row_22 = r13;
  u32 _row_23 = r14;
  Term _row_24 = r15;
  u32 _row_25 = r16;
  u32 _row_26 = r17;
  WL_SPIN
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_0[1];
    if (spin_17(e, _o_0, U32_BIN(0ull, <, _row_18), U32_BIN(_row_18, <=, _rows_15)) == 0) {
      return 0;
    }
    _v_39 = _o_0[0];
    _v_38 = _v_39;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    Term _o_1[19];
    if (spin_25(e, _o_1, _v_38, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _row_18, _row_19, _row_20, _row_20 == h11 ? q11 : blk_loc(e.mem, _row_20), _row_21, _row_22, _row_22 == h13 ? q13 : blk_loc(e.mem, _row_22), _row_23, _row_24, _row_24 == h15 ? q15 : blk_loc(e.mem, _row_24), _row_25, _row_26) == 0) {
      return 0;
    }
    _v_40 = _o_1[0];
    _v_41 = _o_1[1];
    _v_42 = _o_1[2];
    _v_43 = _o_1[3];
    _v_44 = _o_1[4];
    _v_45 = _o_1[5];
    _v_46 = _o_1[6];
    _v_47 = _o_1[7];
    _v_48 = _o_1[8];
    _v_49 = _o_1[9];
    _v_50 = _o_1[10];
    _v_51 = _o_1[11];
    _v_52 = _o_1[12];
    _v_53 = _o_1[13];
    _v_54 = _o_1[14];
    _v_55 = _o_1[15];
    _v_56 = _o_1[16];
    _v_57 = _o_1[17];
    _v_58 = _o_1[18];
    _v_19 = _v_40;
    _v_20 = _v_41;
    _v_21 = _v_42;
    _v_22 = _v_43;
    _v_23 = _v_44;
    _v_24 = _v_45;
    _v_25 = _v_46;
    _v_26 = _v_47;
    _v_27 = _v_48;
    _v_28 = _v_49;
    _v_29 = _v_50;
    _v_30 = _v_51;
    _v_31 = _v_52;
    _v_32 = _v_53;
    _v_33 = _v_54;
    _v_34 = _v_55;
    _v_35 = _v_56;
    _v_36 = _v_57;
    _v_37 = _v_58;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  u32 _c_1 = r2;
  Term _result_2 = r3;
  u32 _result_3 = r4;
  WL_SPIN
    _v_5 = _result_2;
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = _c_1;
    _v_9 = _result_3;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term h9 = r9;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  u32 _namespace_1 = r0;
  u32 _tick_1 = r1;
  u32 _command_8 = r2;
  u32 _command_9 = r3;
  Term _command_10 = r4;
  Term _command_11 = r5;
  u32 _command_12 = r6;
  Term _command_13 = r7;
  u32 _command_14 = r8;
  Term _command_15 = r9;
  u32 _row_0 = r10;
  u32 _row_1 = r11;
  Term _row_2 = r12;
  u32 _row_3 = r13;
  Term _row_4 = r14;
  u32 _row_5 = r15;
  Term _row_6 = r16;
  u32 _row_7 = r17;
  u32 _row_8 = r18;
  WL_SPIN
    if (_command_8 == 2) {
      term_sink(e, _row_6);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = 1;
      _v_29 = _command_10;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 4) {
      term_sink(e, _row_6);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = 0;
      _v_29 = 0;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 1) {
      term_sink(e, _command_10);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 3) {
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 5) {
      if (_row_1 == 1) {
        term_sink(e, _row_2);
        term_sink(e, _row_4);
        term_sink(e, _row_6);
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_0 + 1] = rfc_seal(e, _row_0);
        u64 _nd_1 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _row_0);
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_DESPAWNED, _nd_1));
        e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINREMOVED, _nd_0));
        e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
        _v_22 = 0;
        _v_23 = 0;
        _v_24 = 0;
        _v_25 = 0;
        _v_26 = 0;
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0;
        _v_30 = 0;
        _v_31 = 0;
        _v_32 = term_ctr(CID_CON, _nd_3);
      } else {
        term_sink(e, _row_4);
        term_sink(e, _row_6);
        u64 _nd_4 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_4 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_4 + 1] = rfc_seal(e, _row_0);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_DESPAWNED, _nd_4));
        e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        _v_22 = 0;
        _v_23 = 0;
        _v_24 = 0;
        _v_25 = 0;
        _v_26 = 0;
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0;
        _v_30 = 0;
        _v_31 = 0;
        _v_32 = term_ctr(CID_CON, _nd_5);
      }
    } else {
      term_sink(e, _command_11);
      term_sink(e, _command_13);
      term_sink(e, _command_15);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    }
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term h20 = r20;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  u32 _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _id_1 = r9;
  u32 _result_19 = r10;
  u32 _result_20 = r11;
  u32 _result_21 = r12;
  Term _result_22 = r13;
  u32 _result_23 = r14;
  Term _result_24 = r15;
  u32 _result_25 = r16;
  Term _result_26 = r17;
  u32 _result_27 = r18;
  u32 _result_28 = r19;
  Term _result_29 = r20;
  WL_SPIN
    if (_result_19 == 1) {
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      u32 _v_77 = 0;
      Term _v_78 = 0;
      u32 _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      u32 _v_88 = 0;
      Term _o_1[9];
      if (spin_26(e, _o_1, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _result_20, _result_21, _result_22, _result_22 == h13 ? q13 : blk_loc(e.mem, _result_22), _result_23, _result_24, _result_24 == h15 ? q15 : blk_loc(e.mem, _result_24), _result_25, _result_26, _result_26 == h17 ? q17 : blk_loc(e.mem, _result_26), _result_27, _result_28) == 0) {
        return 0;
      }
      _v_80 = _o_1[0];
      _v_81 = _o_1[1];
      _v_82 = _o_1[2];
      _v_83 = _o_1[3];
      _v_84 = _o_1[4];
      _v_85 = _o_1[5];
      _v_86 = _o_1[6];
      _v_87 = _o_1[7];
      _v_88 = _o_1[8];
      _v_71 = _v_80;
      _v_72 = _v_81;
      _v_73 = _v_82;
      _v_74 = _v_83;
      _v_75 = _v_84;
      _v_76 = _v_85;
      _v_77 = _v_86;
      _v_78 = _v_87;
      _v_79 = _v_88;
      _v_52 = 0;
      _v_53 = _v_71;
      _v_54 = _v_72;
      _v_55 = _v_73;
      _v_56 = _v_74;
      _v_57 = _v_75;
      _v_58 = _v_76;
      _v_59 = _v_77;
      _v_60 = _v_78;
      _v_61 = _v_79;
      _v_62 = _result_29;
      _v_63 = 0;
      _v_64 = 0;
      _v_65 = 0;
      _v_66 = 0;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
    } else {
      Term _v_89 = 0;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      u32 _v_102 = 0;
      Term _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      Term _v_112 = 0;
      Term _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      u32 _v_118 = 0;
      u32 _v_119 = 0;
      Term _v_120 = 0;
      u32 _v_121 = 0;
      Term _v_122 = 0;
      u32 _v_123 = 0;
      Term _v_124 = 0;
      u32 _v_125 = 0;
      u32 _v_126 = 0;
      Term _o_2[19];
      if (spin_27(e, _o_2, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _id_1) == 0) {
        return 0;
      }
      _v_108 = _o_2[0];
      _v_109 = _o_2[1];
      _v_110 = _o_2[2];
      _v_111 = _o_2[3];
      _v_112 = _o_2[4];
      _v_113 = _o_2[5];
      _v_114 = _o_2[6];
      _v_115 = _o_2[7];
      _v_116 = _o_2[8];
      _v_117 = _o_2[9];
      _v_118 = _o_2[10];
      _v_119 = _o_2[11];
      _v_120 = _o_2[12];
      _v_121 = _o_2[13];
      _v_122 = _o_2[14];
      _v_123 = _o_2[15];
      _v_124 = _o_2[16];
      _v_125 = _o_2[17];
      _v_126 = _o_2[18];
      _v_89 = _v_108;
      _v_90 = _v_109;
      _v_91 = _v_110;
      _v_92 = _v_111;
      _v_93 = _v_112;
      _v_94 = _v_113;
      _v_95 = _v_114;
      _v_96 = _v_115;
      _v_97 = _v_116;
      _v_98 = _v_117;
      _v_99 = _v_118;
      _v_100 = _v_119;
      _v_101 = _v_120;
      _v_102 = _v_121;
      _v_103 = _v_122;
      _v_104 = _v_123;
      _v_105 = _v_124;
      _v_106 = _v_125;
      _v_107 = _v_126;
      u32 _v_127 = 0;
      Term _v_128 = 0;
      Term _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      u32 _v_134 = 0;
      Term _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      Term _v_139 = 0;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      u32 _v_142 = 0;
      Term _v_143 = 0;
      u32 _v_144 = 0;
      u32 _v_145 = 0;
      Term _o_3[19];
      if (spin_28(e, _o_3, _result_29, _result_29 == h20 ? q20 : blk_loc(e.mem, _result_29), _v_89, _v_89 == h20 ? q20 : _v_89 == h17 ? q17 : _v_89 == h15 ? q15 : _v_89 == h13 ? q13 : _v_89 == h5 ? q5 : _v_89 == h4 ? q4 : _v_89 == h3 ? q3 : _v_89 == h2 ? q2 : _v_89 == h1 ? q1 : _v_89 == h0 ? q0 : blk_loc(e.mem, _v_89), _v_90, _v_90 == h20 ? q20 : _v_90 == h17 ? q17 : _v_90 == h15 ? q15 : _v_90 == h13 ? q13 : _v_90 == h5 ? q5 : _v_90 == h4 ? q4 : _v_90 == h3 ? q3 : _v_90 == h2 ? q2 : _v_90 == h1 ? q1 : _v_90 == h0 ? q0 : blk_loc(e.mem, _v_90), _v_91, _v_91 == h20 ? q20 : _v_91 == h17 ? q17 : _v_91 == h15 ? q15 : _v_91 == h13 ? q13 : _v_91 == h5 ? q5 : _v_91 == h4 ? q4 : _v_91 == h3 ? q3 : _v_91 == h2 ? q2 : _v_91 == h1 ? q1 : _v_91 == h0 ? q0 : blk_loc(e.mem, _v_91), _v_92, _v_92 == h20 ? q20 : _v_92 == h17 ? q17 : _v_92 == h15 ? q15 : _v_92 == h13 ? q13 : _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : _v_92 == h2 ? q2 : _v_92 == h1 ? q1 : _v_92 == h0 ? q0 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h20 ? q20 : _v_93 == h17 ? q17 : _v_93 == h15 ? q15 : _v_93 == h13 ? q13 : _v_93 == h5 ? q5 : _v_93 == h4 ? q4 : _v_93 == h3 ? q3 : _v_93 == h2 ? q2 : _v_93 == h1 ? q1 : _v_93 == h0 ? q0 : blk_loc(e.mem, _v_93), _v_94, _v_94 == h20 ? q20 : _v_94 == h17 ? q17 : _v_94 == h15 ? q15 : _v_94 == h13 ? q13 : _v_94 == h5 ? q5 : _v_94 == h4 ? q4 : _v_94 == h3 ? q3 : _v_94 == h2 ? q2 : _v_94 == h1 ? q1 : _v_94 == h0 ? q0 : blk_loc(e.mem, _v_94), _v_95, _v_96, _v_97, _v_98, _v_99, _v_100, _v_101, _v_101 == h20 ? q20 : _v_101 == h17 ? q17 : _v_101 == h15 ? q15 : _v_101 == h13 ? q13 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : _v_101 == h1 ? q1 : _v_101 == h0 ? q0 : blk_loc(e.mem, _v_101), _v_102, _v_103, _v_103 == h20 ? q20 : _v_103 == h17 ? q17 : _v_103 == h15 ? q15 : _v_103 == h13 ? q13 : _v_103 == h5 ? q5 : _v_103 == h4 ? q4 : _v_103 == h3 ? q3 : _v_103 == h2 ? q2 : _v_103 == h1 ? q1 : _v_103 == h0 ? q0 : blk_loc(e.mem, _v_103), _v_104, _v_105, _v_105 == h20 ? q20 : _v_105 == h17 ? q17 : _v_105 == h15 ? q15 : _v_105 == h13 ? q13 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : _v_105 == h1 ? q1 : _v_105 == h0 ? q0 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_127 = _o_3[0];
      _v_128 = _o_3[1];
      _v_129 = _o_3[2];
      _v_130 = _o_3[3];
      _v_131 = _o_3[4];
      _v_132 = _o_3[5];
      _v_133 = _o_3[6];
      _v_134 = _o_3[7];
      _v_135 = _o_3[8];
      _v_136 = _o_3[9];
      _v_137 = _o_3[10];
      _v_138 = _o_3[11];
      _v_139 = _o_3[12];
      _v_140 = _o_3[13];
      _v_141 = _o_3[14];
      _v_142 = _o_3[15];
      _v_143 = _o_3[16];
      _v_144 = _o_3[17];
      _v_145 = _o_3[18];
      _v_52 = _v_127;
      _v_53 = _v_128;
      _v_54 = _v_129;
      _v_55 = _v_130;
      _v_56 = _v_131;
      _v_57 = _v_132;
      _v_58 = _v_133;
      _v_59 = _v_134;
      _v_60 = _v_135;
      _v_61 = _v_136;
      _v_62 = _v_137;
      _v_63 = _v_138;
      _v_64 = _v_139;
      _v_65 = _v_140;
      _v_66 = _v_141;
      _v_67 = _v_142;
      _v_68 = _v_143;
      _v_69 = _v_144;
      _v_70 = _v_145;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  o[18] = _v_70;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_0 = r2;
  Term _aux_0 = r3;
  u32 _capacity_0 = r4;
  Term _depth_0 = r5;
  u32 _high_0 = r6;
  u32 _replacement_2 = r7;
  Term _replacement_3 = r8;
  Term _result_0 = r9;
  Term _result_1 = r10;
  Term _result_2 = r11;
  Term _result_3 = r12;
  u32 _result_4 = r13;
  u32 _result_5 = r14;
  Term _result_6 = r15;
  u32 _result_7 = r16;
  u32 _result_8 = r17;
  WL_SPIN
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_1[10];
    if (spin_29(e, _o_1, _id_1, _tick_1, _main_0, _main_0 == h2 ? q2 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h3 ? q3 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h9 ? q9 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h10 ? q10 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h11 ? q11 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h12 ? q12 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _replacement_2, _replacement_3, _replacement_3 == h8 ? q8 : blk_loc(e.mem, _replacement_3), _result_4, _result_5, _result_6, _result_6 == h15 ? q15 : blk_loc(e.mem, _result_6), _result_7, _result_8) == 0) {
      return 0;
    }
    _v_38 = _o_1[0];
    _v_39 = _o_1[1];
    _v_40 = _o_1[2];
    _v_41 = _o_1[3];
    _v_42 = _o_1[4];
    _v_43 = _o_1[5];
    _v_44 = _o_1[6];
    _v_45 = _o_1[7];
    _v_46 = _o_1[8];
    _v_47 = _o_1[9];
    _v_28 = _v_38;
    _v_29 = _v_39;
    _v_30 = _v_40;
    _v_31 = _v_41;
    _v_32 = _v_42;
    _v_33 = _v_43;
    _v_34 = _v_44;
    _v_35 = _v_45;
    _v_36 = _v_46;
    _v_37 = _v_47;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_1 = r0;
  u32 _b_0 = r1;
  Term _result_2 = r2;
  u32 _result_3 = r3;
  WL_SPIN
    Term _at_2 = _result_2 == h2 ? q2 : blk_loc(e.mem, _result_2);
    Term _at_3 = blk_at(_result_2, 3ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_31(e, _o_0, _a_1, _b_0, _result_3, _result_2, _result_2 == h2 ? q2 : blk_loc(e.mem, _result_2), _c_1) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, Term r18, u32 r19, u32 r20, u32 r21, u32 r22, Term r23, u64 q23, u32 r24, Term r25, u64 q25, u32 r26, Term r27, u64 q27, u32 r28, u32 r29) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h23 = r23;
  Term h25 = r25;
  Term h27 = r27;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _namespace_1 = r0;
  u32 _tick_1 = r1;
  u32 _id_0 = r2;
  u32 _command_0 = r3;
  u32 _command_1 = r4;
  Term _command_2 = r5;
  Term _command_3 = r6;
  u32 _command_4 = r7;
  Term _command_5 = r8;
  u32 _command_6 = r9;
  Term _command_7 = r10;
  Term _result_9 = r11;
  Term _result_10 = r12;
  Term _result_11 = r13;
  Term _result_12 = r14;
  Term _result_13 = r15;
  Term _result_14 = r16;
  u32 _result_15 = r17;
  Term _result_16 = r18;
  u32 _result_17 = r19;
  u32 _result_18 = r20;
  u32 _result_19 = r21;
  u32 _result_20 = r22;
  Term _result_21 = r23;
  u32 _result_22 = r24;
  Term _result_23 = r25;
  u32 _result_24 = r26;
  Term _result_25 = r27;
  u32 _result_26 = r28;
  u32 _result_27 = r29;
  WL_SPIN
    if (_result_18 == 0) {
      term_sink(e, _command_2);
      term_sink(e, _command_3);
      term_sink(e, _command_5);
      term_sink(e, _command_7);
      _v_57 = 0;
      _v_58 = _result_9;
      _v_59 = _result_10;
      _v_60 = _result_11;
      _v_61 = _result_12;
      _v_62 = _result_13;
      _v_63 = _result_14;
      _v_64 = _result_15;
      _v_65 = _result_16;
      _v_66 = _result_17;
      _v_67 = term_pak(CID_NIL, 0);
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
      _v_71 = 0;
      _v_72 = 0;
      _v_73 = 0;
      _v_74 = 0;
      _v_75 = 0;
    } else {
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      u32 _v_85 = 0;
      Term _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      u32 _v_96 = 0;
      Term _v_97 = 0;
      Term _o_1[11];
      if (spin_32(e, _o_1, _namespace_1, _tick_1, _command_0, _command_1, _command_2, _command_2 == h5 ? q5 : blk_loc(e.mem, _command_2), _command_3, _command_3 == h6 ? q6 : blk_loc(e.mem, _command_3), _command_4, _command_5, _command_5 == h8 ? q8 : blk_loc(e.mem, _command_5), _command_6, _command_7, _command_7 == h10 ? q10 : blk_loc(e.mem, _command_7), _result_19, _result_20, _result_21, _result_21 == h23 ? q23 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h25 ? q25 : blk_loc(e.mem, _result_23), _result_24, _result_25, _result_25 == h27 ? q27 : blk_loc(e.mem, _result_25), _result_26, _result_27) == 0) {
        return 0;
      }
      _v_87 = _o_1[0];
      _v_88 = _o_1[1];
      _v_89 = _o_1[2];
      _v_90 = _o_1[3];
      _v_91 = _o_1[4];
      _v_92 = _o_1[5];
      _v_93 = _o_1[6];
      _v_94 = _o_1[7];
      _v_95 = _o_1[8];
      _v_96 = _o_1[9];
      _v_97 = _o_1[10];
      _v_76 = _v_87;
      _v_77 = _v_88;
      _v_78 = _v_89;
      _v_79 = _v_90;
      _v_80 = _v_91;
      _v_81 = _v_92;
      _v_82 = _v_93;
      _v_83 = _v_94;
      _v_84 = _v_95;
      _v_85 = _v_96;
      _v_86 = _v_97;
      u32 _v_98 = 0;
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      Term _v_103 = 0;
      Term _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      u32 _v_109 = 0;
      Term _v_110 = 0;
      u32 _v_111 = 0;
      Term _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_2[19];
      if (spin_33(e, _o_2, _result_9, _result_9 == h11 ? q11 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h12 ? q12 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h13 ? q13 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h14 ? q14 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h15 ? q15 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h16 ? q16 : blk_loc(e.mem, _result_14), _result_15, _result_16, _result_17, _id_0, _v_76, _v_77, _v_78, _v_79, _v_79 == h27 ? q27 : _v_79 == h25 ? q25 : _v_79 == h23 ? q23 : _v_79 == h16 ? q16 : _v_79 == h15 ? q15 : _v_79 == h14 ? q14 : _v_79 == h13 ? q13 : _v_79 == h12 ? q12 : _v_79 == h11 ? q11 : _v_79 == h10 ? q10 : _v_79 == h8 ? q8 : _v_79 == h6 ? q6 : _v_79 == h5 ? q5 : blk_loc(e.mem, _v_79), _v_80, _v_81, _v_81 == h27 ? q27 : _v_81 == h25 ? q25 : _v_81 == h23 ? q23 : _v_81 == h16 ? q16 : _v_81 == h15 ? q15 : _v_81 == h14 ? q14 : _v_81 == h13 ? q13 : _v_81 == h12 ? q12 : _v_81 == h11 ? q11 : _v_81 == h10 ? q10 : _v_81 == h8 ? q8 : _v_81 == h6 ? q6 : _v_81 == h5 ? q5 : blk_loc(e.mem, _v_81), _v_82, _v_83, _v_83 == h27 ? q27 : _v_83 == h25 ? q25 : _v_83 == h23 ? q23 : _v_83 == h16 ? q16 : _v_83 == h15 ? q15 : _v_83 == h14 ? q14 : _v_83 == h13 ? q13 : _v_83 == h12 ? q12 : _v_83 == h11 ? q11 : _v_83 == h10 ? q10 : _v_83 == h8 ? q8 : _v_83 == h6 ? q6 : _v_83 == h5 ? q5 : blk_loc(e.mem, _v_83), _v_84, _v_85, _v_86, _v_86 == h27 ? q27 : _v_86 == h25 ? q25 : _v_86 == h23 ? q23 : _v_86 == h16 ? q16 : _v_86 == h15 ? q15 : _v_86 == h14 ? q14 : _v_86 == h13 ? q13 : _v_86 == h12 ? q12 : _v_86 == h11 ? q11 : _v_86 == h10 ? q10 : _v_86 == h8 ? q8 : _v_86 == h6 ? q6 : _v_86 == h5 ? q5 : blk_loc(e.mem, _v_86)) == 0) {
        return 0;
      }
      _v_98 = _o_2[0];
      _v_99 = _o_2[1];
      _v_100 = _o_2[2];
      _v_101 = _o_2[3];
      _v_102 = _o_2[4];
      _v_103 = _o_2[5];
      _v_104 = _o_2[6];
      _v_105 = _o_2[7];
      _v_106 = _o_2[8];
      _v_107 = _o_2[9];
      _v_108 = _o_2[10];
      _v_109 = _o_2[11];
      _v_110 = _o_2[12];
      _v_111 = _o_2[13];
      _v_112 = _o_2[14];
      _v_113 = _o_2[15];
      _v_114 = _o_2[16];
      _v_115 = _o_2[17];
      _v_116 = _o_2[18];
      _v_57 = _v_98;
      _v_58 = _v_99;
      _v_59 = _v_100;
      _v_60 = _v_101;
      _v_61 = _v_102;
      _v_62 = _v_103;
      _v_63 = _v_104;
      _v_64 = _v_105;
      _v_65 = _v_106;
      _v_66 = _v_107;
      _v_67 = _v_108;
      _v_68 = _v_109;
      _v_69 = _v_110;
      _v_70 = _v_111;
      _v_71 = _v_112;
      _v_72 = _v_113;
      _v_73 = _v_114;
      _v_74 = _v_115;
      _v_75 = _v_116;
    }
  break;
  }
  o[0] = _v_57;
  o[1] = _v_58;
  o[2] = _v_59;
  o[3] = _v_60;
  o[4] = _v_61;
  o[5] = _v_62;
  o[6] = _v_63;
  o[7] = _v_64;
  o[8] = _v_65;
  o[9] = _v_66;
  o[10] = _v_67;
  o[11] = _v_68;
  o[12] = _v_69;
  o[13] = _v_70;
  o[14] = _v_71;
  o[15] = _v_72;
  o[16] = _v_73;
  o[17] = _v_74;
  o[18] = _v_75;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h13 = r13;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  u32 _tick_1 = r2;
  Term _rows_9 = r3;
  Term _rows_10 = r4;
  Term _rows_11 = r5;
  Term _rows_12 = r6;
  Term _rows_13 = r7;
  Term _rows_14 = r8;
  u32 _rows_15 = r9;
  Term _rows_16 = r10;
  u32 _rows_17 = r11;
  u32 _replacement_2 = r12;
  Term _replacement_3 = r13;
  WL_SPIN
    if (_valid_0 == 0) {
      term_sink(e, _replacement_3);
      _v_14 = _rows_9;
      _v_15 = _rows_10;
      _v_16 = _rows_11;
      _v_17 = _rows_12;
      _v_18 = _rows_13;
      _v_19 = _rows_14;
      _v_20 = _rows_15;
      _v_21 = _rows_16;
      _v_22 = _rows_17;
      _v_23 = 0;
    } else {
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      Term _o_2[9];
      if (spin_19(e, _o_2, _rows_11, _rows_11 == h5 ? q5 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h6 ? q6 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h7 ? q7 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h8 ? q8 : blk_loc(e.mem, _rows_14), U32_BIN(_id_1, -, 1ull)) == 0) {
        return 0;
      }
      _v_33 = _o_2[0];
      _v_34 = _o_2[1];
      _v_35 = _o_2[2];
      _v_36 = _o_2[3];
      _v_37 = _o_2[4];
      _v_38 = _o_2[5];
      _v_39 = _o_2[6];
      _v_40 = _o_2[7];
      _v_41 = _o_2[8];
      _v_24 = _v_33;
      _v_25 = _v_34;
      _v_26 = _v_35;
      _v_27 = _v_36;
      _v_28 = _v_37;
      _v_29 = _v_38;
      _v_30 = _v_39;
      _v_31 = _v_40;
      _v_32 = _v_41;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      Term _o_3[10];
      if (spin_34(e, _o_3, _id_1, _tick_1, _rows_9, _rows_9 == h3 ? q3 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h4 ? q4 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _replacement_2, _replacement_3, _replacement_3 == h13 ? q13 : blk_loc(e.mem, _replacement_3), _v_24, _v_24 == h13 ? q13 : _v_24 == h8 ? q8 : _v_24 == h7 ? q7 : _v_24 == h6 ? q6 : _v_24 == h5 ? q5 : _v_24 == h4 ? q4 : _v_24 == h3 ? q3 : blk_loc(e.mem, _v_24), _v_25, _v_25 == h13 ? q13 : _v_25 == h8 ? q8 : _v_25 == h7 ? q7 : _v_25 == h6 ? q6 : _v_25 == h5 ? q5 : _v_25 == h4 ? q4 : _v_25 == h3 ? q3 : blk_loc(e.mem, _v_25), _v_26, _v_26 == h13 ? q13 : _v_26 == h8 ? q8 : _v_26 == h7 ? q7 : _v_26 == h6 ? q6 : _v_26 == h5 ? q5 : _v_26 == h4 ? q4 : _v_26 == h3 ? q3 : blk_loc(e.mem, _v_26), _v_27, _v_27 == h13 ? q13 : _v_27 == h8 ? q8 : _v_27 == h7 ? q7 : _v_27 == h6 ? q6 : _v_27 == h5 ? q5 : _v_27 == h4 ? q4 : _v_27 == h3 ? q3 : blk_loc(e.mem, _v_27), _v_28, _v_29, _v_30, _v_30 == h13 ? q13 : _v_30 == h8 ? q8 : _v_30 == h7 ? q7 : _v_30 == h6 ? q6 : _v_30 == h5 ? q5 : _v_30 == h4 ? q4 : _v_30 == h3 ? q3 : blk_loc(e.mem, _v_30), _v_31, _v_32) == 0) {
        return 0;
      }
      _v_42 = _o_3[0];
      _v_43 = _o_3[1];
      _v_44 = _o_3[2];
      _v_45 = _o_3[3];
      _v_46 = _o_3[4];
      _v_47 = _o_3[5];
      _v_48 = _o_3[6];
      _v_49 = _o_3[7];
      _v_50 = _o_3[8];
      _v_51 = _o_3[9];
      _v_14 = _v_42;
      _v_15 = _v_43;
      _v_16 = _v_44;
      _v_17 = _v_45;
      _v_18 = _v_46;
      _v_19 = _v_47;
      _v_20 = _v_48;
      _v_21 = _v_49;
      _v_22 = _v_50;
      _v_23 = _v_51;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _changes_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  Term _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  u32 _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  u32 _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  u32 _result_13 = r14;
  Term _result_14 = r15;
  u32 _result_15 = r16;
  Term _result_16 = r17;
  u32 _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      _v_19 = 0;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _changes_0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    } else {
      term_sink(e, _changes_0);
      _v_19 = 1;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _result_10;
      _v_30 = _result_11;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _s_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_s_1) == CID_SNIL) {
      _v_1 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _s_1, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_SCON, _nd_0);
      _s_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_39);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_0 = r0;
  Term _result_2 = r1;
  u32 _result_3 = r2;
  WL_SPIN
    Term _at_2 = _result_2 == h1 ? q1 : blk_loc(e.mem, _result_2);
    Term _at_3 = blk_at(_result_2, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_35(e, _o_0, _a_0, _result_3, _result_2, _result_2 == h1 ? q1 : blk_loc(e.mem, _result_2), _c_1) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  u32 _replacement_0 = r10;
  Term _replacement_1 = r11;
  u32 _tick_1 = r12;
  WL_SPIN
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _o_2[1];
    if (spin_17(e, _o_2, U32_BIN(_id_0, <=, _rows_15), U32_BIN(_id_0, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_70 = _o_2[0];
    _v_69 = _v_70;
    u32 _v_71 = 0;
    Term _o_3[1];
    if (spin_17(e, _o_3, U32_BIN(0ull, <, _id_0), _v_69) == 0) {
      return 0;
    }
    _v_71 = _o_3[0];
    _v_68 = _v_71;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _o_4[10];
    if (spin_37(e, _o_4, _v_68, _id_0, _tick_1, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _replacement_0, _replacement_1, _replacement_1 == h11 ? q11 : blk_loc(e.mem, _replacement_1)) == 0) {
      return 0;
    }
    _v_72 = _o_4[0];
    _v_73 = _o_4[1];
    _v_74 = _o_4[2];
    _v_75 = _o_4[3];
    _v_76 = _o_4[4];
    _v_77 = _o_4[5];
    _v_78 = _o_4[6];
    _v_79 = _o_4[7];
    _v_80 = _o_4[8];
    _v_81 = _o_4[9];
    _v_58 = _v_72;
    _v_59 = _v_73;
    _v_60 = _v_74;
    _v_61 = _v_75;
    _v_62 = _v_76;
    _v_63 = _v_77;
    _v_64 = _v_78;
    _v_65 = _v_79;
    _v_66 = _v_80;
    _v_67 = _v_81;
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  o[5] = _v_63;
  o[6] = _v_64;
  o[7] = _v_65;
  o[8] = _v_66;
  o[9] = _v_67;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  Term _v_103 = 0;
  Term _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  u32 _v_108 = 0;
  Term _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  u32 _v_114 = 0;
  Term _v_115 = 0;
  u32 _v_116 = 0;
  Term _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _namespace_2 = r0;
  u32 _id_1 = r1;
  Term _result_0 = r2;
  Term _result_1 = r3;
  Term _result_2 = r4;
  Term _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  Term _result_7 = r9;
  u32 _result_8 = r10;
  u32 _result_9 = r11;
  WL_SPIN
    if (_result_9 == 1) {
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_4 + 1] = rfc_seal(e, _id_1);
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_5 + 1] = rfc_seal(e, _id_1);
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_5));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINADDED, _nd_4));
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_7);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 2) {
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_8 + 1] = rfc_seal(e, _id_1);
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_8));
      e.mem[_nd_9 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_9);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 3) {
      u64 _nd_10 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_10 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_10 + 1] = rfc_seal(e, _id_1);
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINREMOVED, _nd_10));
      e.mem[_nd_11 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_11);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 0) {
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_pak(CID_NIL, 0);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else {
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_pak(CID_NIL, 0);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    }
  break;
  }
  o[0] = _v_101;
  o[1] = _v_102;
  o[2] = _v_103;
  o[3] = _v_104;
  o[4] = _v_105;
  o[5] = _v_106;
  o[6] = _v_107;
  o[7] = _v_108;
  o[8] = _v_109;
  o[9] = _v_110;
  o[10] = _v_111;
  o[11] = _v_112;
  o[12] = _v_113;
  o[13] = _v_114;
  o[14] = _v_115;
  o[15] = _v_116;
  o[16] = _v_117;
  o[17] = _v_118;
  o[18] = _v_119;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h7 = r7;
  u32 _v_177 = 0;
  u32 _v_178 = 0;
  Term _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  Term _v_184 = 0;
  u32 _v_185 = 0;
  u32 _command_9 = r0;
  u32 _command_10 = r1;
  Term _command_11 = r2;
  Term _command_12 = r3;
  u32 _command_13 = r4;
  Term _command_14 = r5;
  u32 _command_15 = r6;
  Term _command_16 = r7;
  WL_SPIN
    if (_command_9 == 0) {
      _v_177 = 0;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = _command_12;
      _v_181 = _command_13;
      _v_182 = _command_14;
      _v_183 = _command_15;
      _v_184 = _command_16;
      _v_185 = _command_10;
    } else if (_command_9 == 1) {
      _v_177 = 1;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 2) {
      _v_177 = 2;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 3) {
      _v_177 = 3;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 4) {
      _v_177 = 4;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else {
      _v_177 = 5;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    }
  break;
  }
  o[0] = _v_177;
  o[1] = _v_178;
  o[2] = _v_179;
  o[3] = _v_180;
  o[4] = _v_181;
  o[5] = _v_182;
  o[6] = _v_183;
  o[7] = _v_184;
  o[8] = _v_185;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  u32 _v_205 = 0;
  Term _v_206 = 0;
  Term _v_207 = 0;
  Term _v_208 = 0;
  Term _v_209 = 0;
  Term _v_210 = 0;
  Term _v_211 = 0;
  u32 _v_212 = 0;
  Term _v_213 = 0;
  u32 _v_214 = 0;
  Term _v_215 = 0;
  u32 _v_216 = 0;
  Term _v_217 = 0;
  u32 _v_218 = 0;
  Term _v_219 = 0;
  u32 _v_220 = 0;
  Term _v_221 = 0;
  u32 _v_222 = 0;
  u32 _v_223 = 0;
  u32 _namespace_3 = r0;
  u32 _tick_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  u32 _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  Term _result_13 = r14;
  u32 _result_14 = r15;
  Term _result_15 = r16;
  u32 _result_16 = r17;
  Term _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    Term _v_224 = 0;
    Term _v_225 = 0;
    Term _v_226 = 0;
    Term _v_227 = 0;
    Term _v_228 = 0;
    Term _v_229 = 0;
    u32 _v_230 = 0;
    Term _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    u32 _v_235 = 0;
    Term _v_236 = 0;
    u32 _v_237 = 0;
    Term _v_238 = 0;
    u32 _v_239 = 0;
    Term _v_240 = 0;
    u32 _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    Term _v_244 = 0;
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    Term _v_248 = 0;
    u32 _v_249 = 0;
    Term _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    Term _v_255 = 0;
    u32 _v_256 = 0;
    Term _v_257 = 0;
    u32 _v_258 = 0;
    Term _v_259 = 0;
    u32 _v_260 = 0;
    u32 _v_261 = 0;
    Term _o_10[19];
    if (spin_16(e, _o_10, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26, _result_18) == 0) {
      return 0;
    }
    _v_243 = _o_10[0];
    _v_244 = _o_10[1];
    _v_245 = _o_10[2];
    _v_246 = _o_10[3];
    _v_247 = _o_10[4];
    _v_248 = _o_10[5];
    _v_249 = _o_10[6];
    _v_250 = _o_10[7];
    _v_251 = _o_10[8];
    _v_252 = _o_10[9];
    _v_253 = _o_10[10];
    _v_254 = _o_10[11];
    _v_255 = _o_10[12];
    _v_256 = _o_10[13];
    _v_257 = _o_10[14];
    _v_258 = _o_10[15];
    _v_259 = _o_10[16];
    _v_260 = _o_10[17];
    _v_261 = _o_10[18];
    _v_224 = _v_243;
    _v_225 = _v_244;
    _v_226 = _v_245;
    _v_227 = _v_246;
    _v_228 = _v_247;
    _v_229 = _v_248;
    _v_230 = _v_249;
    _v_231 = _v_250;
    _v_232 = _v_251;
    _v_233 = _v_252;
    _v_234 = _v_253;
    _v_235 = _v_254;
    _v_236 = _v_255;
    _v_237 = _v_256;
    _v_238 = _v_257;
    _v_239 = _v_258;
    _v_240 = _v_259;
    _v_241 = _v_260;
    _v_242 = _v_261;
    u32 _v_262 = 0;
    Term _v_263 = 0;
    Term _v_264 = 0;
    Term _v_265 = 0;
    Term _v_266 = 0;
    Term _v_267 = 0;
    Term _v_268 = 0;
    u32 _v_269 = 0;
    Term _v_270 = 0;
    u32 _v_271 = 0;
    Term _v_272 = 0;
    u32 _v_273 = 0;
    Term _v_274 = 0;
    u32 _v_275 = 0;
    Term _v_276 = 0;
    u32 _v_277 = 0;
    Term _v_278 = 0;
    u32 _v_279 = 0;
    u32 _v_280 = 0;
    Term _o_11[19];
    if (spin_36(e, _o_11, _namespace_3, _tick_2, _result_18, _result_10, _result_11, _result_12, _result_12 == h13 ? q13 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h14 ? q14 : blk_loc(e.mem, _result_13), _result_14, _result_15, _result_15 == h16 ? q16 : blk_loc(e.mem, _result_15), _result_16, _result_17, _result_17 == h18 ? q18 : blk_loc(e.mem, _result_17), _v_224, _v_224 == h18 ? q18 : _v_224 == h16 ? q16 : _v_224 == h14 ? q14 : _v_224 == h13 ? q13 : _v_224 == h7 ? q7 : _v_224 == h6 ? q6 : _v_224 == h5 ? q5 : _v_224 == h4 ? q4 : _v_224 == h3 ? q3 : _v_224 == h2 ? q2 : blk_loc(e.mem, _v_224), _v_225, _v_225 == h18 ? q18 : _v_225 == h16 ? q16 : _v_225 == h14 ? q14 : _v_225 == h13 ? q13 : _v_225 == h7 ? q7 : _v_225 == h6 ? q6 : _v_225 == h5 ? q5 : _v_225 == h4 ? q4 : _v_225 == h3 ? q3 : _v_225 == h2 ? q2 : blk_loc(e.mem, _v_225), _v_226, _v_226 == h18 ? q18 : _v_226 == h16 ? q16 : _v_226 == h14 ? q14 : _v_226 == h13 ? q13 : _v_226 == h7 ? q7 : _v_226 == h6 ? q6 : _v_226 == h5 ? q5 : _v_226 == h4 ? q4 : _v_226 == h3 ? q3 : _v_226 == h2 ? q2 : blk_loc(e.mem, _v_226), _v_227, _v_227 == h18 ? q18 : _v_227 == h16 ? q16 : _v_227 == h14 ? q14 : _v_227 == h13 ? q13 : _v_227 == h7 ? q7 : _v_227 == h6 ? q6 : _v_227 == h5 ? q5 : _v_227 == h4 ? q4 : _v_227 == h3 ? q3 : _v_227 == h2 ? q2 : blk_loc(e.mem, _v_227), _v_228, _v_228 == h18 ? q18 : _v_228 == h16 ? q16 : _v_228 == h14 ? q14 : _v_228 == h13 ? q13 : _v_228 == h7 ? q7 : _v_228 == h6 ? q6 : _v_228 == h5 ? q5 : _v_228 == h4 ? q4 : _v_228 == h3 ? q3 : _v_228 == h2 ? q2 : blk_loc(e.mem, _v_228), _v_229, _v_229 == h18 ? q18 : _v_229 == h16 ? q16 : _v_229 == h14 ? q14 : _v_229 == h13 ? q13 : _v_229 == h7 ? q7 : _v_229 == h6 ? q6 : _v_229 == h5 ? q5 : _v_229 == h4 ? q4 : _v_229 == h3 ? q3 : _v_229 == h2 ? q2 : blk_loc(e.mem, _v_229), _v_230, _v_231, _v_232, _v_233, _v_234, _v_235, _v_236, _v_236 == h18 ? q18 : _v_236 == h16 ? q16 : _v_236 == h14 ? q14 : _v_236 == h13 ? q13 : _v_236 == h7 ? q7 : _v_236 == h6 ? q6 : _v_236 == h5 ? q5 : _v_236 == h4 ? q4 : _v_236 == h3 ? q3 : _v_236 == h2 ? q2 : blk_loc(e.mem, _v_236), _v_237, _v_238, _v_238 == h18 ? q18 : _v_238 == h16 ? q16 : _v_238 == h14 ? q14 : _v_238 == h13 ? q13 : _v_238 == h7 ? q7 : _v_238 == h6 ? q6 : _v_238 == h5 ? q5 : _v_238 == h4 ? q4 : _v_238 == h3 ? q3 : _v_238 == h2 ? q2 : blk_loc(e.mem, _v_238), _v_239, _v_240, _v_240 == h18 ? q18 : _v_240 == h16 ? q16 : _v_240 == h14 ? q14 : _v_240 == h13 ? q13 : _v_240 == h7 ? q7 : _v_240 == h6 ? q6 : _v_240 == h5 ? q5 : _v_240 == h4 ? q4 : _v_240 == h3 ? q3 : _v_240 == h2 ? q2 : blk_loc(e.mem, _v_240), _v_241, _v_242) == 0) {
      return 0;
    }
    _v_262 = _o_11[0];
    _v_263 = _o_11[1];
    _v_264 = _o_11[2];
    _v_265 = _o_11[3];
    _v_266 = _o_11[4];
    _v_267 = _o_11[5];
    _v_268 = _o_11[6];
    _v_269 = _o_11[7];
    _v_270 = _o_11[8];
    _v_271 = _o_11[9];
    _v_272 = _o_11[10];
    _v_273 = _o_11[11];
    _v_274 = _o_11[12];
    _v_275 = _o_11[13];
    _v_276 = _o_11[14];
    _v_277 = _o_11[15];
    _v_278 = _o_11[16];
    _v_279 = _o_11[17];
    _v_280 = _o_11[18];
    _v_205 = _v_262;
    _v_206 = _v_263;
    _v_207 = _v_264;
    _v_208 = _v_265;
    _v_209 = _v_266;
    _v_210 = _v_267;
    _v_211 = _v_268;
    _v_212 = _v_269;
    _v_213 = _v_270;
    _v_214 = _v_271;
    _v_215 = _v_272;
    _v_216 = _v_273;
    _v_217 = _v_274;
    _v_218 = _v_275;
    _v_219 = _v_276;
    _v_220 = _v_277;
    _v_221 = _v_278;
    _v_222 = _v_279;
    _v_223 = _v_280;
  break;
  }
  o[0] = _v_205;
  o[1] = _v_206;
  o[2] = _v_207;
  o[3] = _v_208;
  o[4] = _v_209;
  o[5] = _v_210;
  o[6] = _v_211;
  o[7] = _v_212;
  o[8] = _v_213;
  o[9] = _v_214;
  o[10] = _v_215;
  o[11] = _v_216;
  o[12] = _v_217;
  o[13] = _v_218;
  o[14] = _v_219;
  o[15] = _v_220;
  o[16] = _v_221;
  o[17] = _v_222;
  o[18] = _v_223;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _s_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_SNIL, 0);
    if (spin_39(e, _o_0, _s_0, _s_0 == h0 ? q0 : blk_loc(e.mem, _s_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_5 = 0;
  Term _value_0 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_value_0) == CID_SNIL) {
      _v_5 = _acc_1;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _value_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_0 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_3;
      r1 = term_ctr(CID_SCON, _nd_0);
      _value_0 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_49);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  WL_SPIN
    Term _at_2 = _result_0 == h0 ? q0 : blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_40(e, _o_0, _result_1, _result_0, _result_0 == h0 ? q0 : blk_loc(e.mem, _result_0), _c_1) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  WL_SPIN
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_0[1];
    if (spin_17(e, _o_0, U32_BIN(0ull, <, _id_0), U32_BIN(_id_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_30 = _v_31;
    _v_20 = _rows_9;
    _v_21 = _rows_10;
    _v_22 = _rows_11;
    _v_23 = _rows_12;
    _v_24 = _rows_13;
    _v_25 = _rows_14;
    _v_26 = _rows_15;
    _v_27 = _rows_16;
    _v_28 = _rows_17;
    _v_29 = _v_30;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _id_1 = r0;
  u32 _bundle_0 = r1;
  Term _bundle_1 = r2;
  u32 _bundle_2 = r3;
  Term _bundle_3 = r4;
  u32 _bundle_4 = r5;
  Term _bundle_5 = r6;
  Term _result_0 = r7;
  Term _result_1 = r8;
  Term _result_2 = r9;
  Term _result_3 = r10;
  Term _result_4 = r11;
  Term _result_5 = r12;
  u32 _result_6 = r13;
  Term _result_7 = r14;
  u32 _result_8 = r15;
  u32 _result_9 = r16;
  WL_SPIN
    _v_50 = _result_0;
    _v_51 = _result_1;
    _v_52 = _result_2;
    _v_53 = _result_3;
    _v_54 = _result_4;
    _v_55 = _result_5;
    _v_56 = _result_6;
    _v_57 = _result_7;
    _v_58 = _result_8;
    _v_59 = 0;
    _v_60 = _id_1;
    _v_61 = _bundle_0;
    _v_62 = _bundle_1;
    _v_63 = _bundle_2;
    _v_64 = _bundle_3;
    _v_65 = _bundle_4;
    _v_66 = _bundle_5;
    _v_67 = _result_9;
  break;
  }
  o[0] = _v_50;
  o[1] = _v_51;
  o[2] = _v_52;
  o[3] = _v_53;
  o[4] = _v_54;
  o[5] = _v_55;
  o[6] = _v_56;
  o[7] = _v_57;
  o[8] = _v_58;
  o[9] = _v_59;
  o[10] = _v_60;
  o[11] = _v_61;
  o[12] = _v_62;
  o[13] = _v_63;
  o[14] = _v_64;
  o[15] = _v_65;
  o[16] = _v_66;
  o[17] = _v_67;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_44 = 0;
  Term _xs_0 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      _v_44 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_0 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_56);
    }
  break;
  }
  o[0] = _v_44;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_47 = 0;
  Term _xs_1 = r0;
  WL_SPIN
    Term _v_48 = 0;
    Term _o_1[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_56(e, _o_1, _xs_1, _xs_1 == h0 ? q0 : blk_loc(e.mem, _xs_1), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_48 = _o_1[0];
    _v_47 = _v_48;
  break;
  }
  o[0] = _v_47;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _reverseChanges_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  Term _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  u32 _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  Term _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  u32 _result_13 = r14;
  Term _result_14 = r15;
  u32 _result_15 = r16;
  Term _result_16 = r17;
  u32 _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _o_0[1];
      if (spin_56(e, _o_0, _result_10, _result_10 == h11 ? q11 : blk_loc(e.mem, _result_10), _reverseChanges_0, _reverseChanges_0 == h0 ? q0 : blk_loc(e.mem, _reverseChanges_0)) == 0) {
        return 0;
      }
      _v_43 = _o_0[0];
      _v_42 = _v_43;
      _v_21 = 0;
      _v_22 = _result_1;
      _v_23 = _result_2;
      _v_24 = _result_3;
      _v_25 = _result_4;
      _v_26 = _result_5;
      _v_27 = _result_6;
      _v_28 = _result_7;
      _v_29 = _result_8;
      _v_30 = _result_9;
      _v_31 = _v_42;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
    } else {
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _o_2[1];
      if (spin_57(e, _o_2, _reverseChanges_0, _reverseChanges_0 == h0 ? q0 : blk_loc(e.mem, _reverseChanges_0)) == 0) {
        return 0;
      }
      _v_46 = _o_2[0];
      _v_45 = _v_46;
      _v_21 = 1;
      _v_22 = _result_1;
      _v_23 = _result_2;
      _v_24 = _result_3;
      _v_25 = _result_4;
      _v_26 = _result_5;
      _v_27 = _result_6;
      _v_28 = _result_7;
      _v_29 = _result_8;
      _v_30 = _result_9;
      _v_31 = _result_10;
      _v_32 = _result_11;
      _v_33 = _result_12;
      _v_34 = _result_13;
      _v_35 = _result_14;
      _v_36 = _result_15;
      _v_37 = _result_16;
      _v_38 = _result_17;
      _v_39 = _result_18;
      _v_40 = term_pak(CID_NIL, 0);
      _v_41 = _v_45;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_3 = 0;
  Term _values_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_values_1) == CID_NIL) {
      Term _v_4 = 0;
      Term _o_0[1];
      if (spin_48(e, _o_0, _acc_0, _acc_0 == h1 ? q1 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_4 = _o_0[0];
      _v_3 = _v_4;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _o_1[1];
      if (spin_49(e, _o_1, _f_0, _f_0 == h1 ? q1 : _f_0 == h0 ? q0 : blk_loc(e.mem, _f_0), _acc_0, _acc_0 == h1 ? q1 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_5 = _v_6;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_5;
      _values_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_59);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _values_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_2[1];
    Term _a_0 = term_pak(CID_SNIL, 0);
    if (spin_59(e, _o_2, _values_0, _values_0 == h0 ? q0 : blk_loc(e.mem, _values_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_2[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_3 = 0;
  Term _xs_1 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_3 = _acc_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_61);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_61(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _value_0 = r0;
  Term _acc_3 = r1;
  u32 _first_2 = r2;
  WL_SPIN
    if (_first_2 == 1) {
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _value_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_3);
      _v_6 = term_ctr(CID_CON, _nd_1);
    } else {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 0));
      e.mem[_nd_2 + 1] = rfc_seal(e, _acc_3);
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _value_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
      _v_6 = term_ctr(CID_CON, _nd_3);
    }
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _array_1 = r0;
  WL_SPIN
    Term _at_0 = _array_1 == h0 ? q0 : blk_loc(e.mem, _array_1);
    Term _at_1 = blk_at(_array_1, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_50(e, _o_0, _array_1, _array_1 == h0 ? q0 : blk_loc(e.mem, _array_1), _c_0) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_50 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_50 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_1 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_1);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_66);
    }
  break;
  }
  o[0] = _v_50;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_48 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_49 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_66(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_49 = _o_0[0];
    _v_48 = _v_49;
  break;
  }
  o[0] = _v_48;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _world_45 = r0;
  u32 _world_46 = r1;
  Term _world_47 = r2;
  Term _world_48 = r3;
  Term _world_49 = r4;
  Term _world_50 = r5;
  Term _world_51 = r6;
  Term _world_52 = r7;
  u32 _world_53 = r8;
  Term _world_54 = r9;
  u32 _world_55 = r10;
  Term _world_56 = r11;
  u32 _world_57 = r12;
  Term _world_58 = r13;
  Term _world_59 = r14;
  Term _staged_0 = r15;
  WL_SPIN
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _o_1[1];
    if (spin_65(e, _o_1, _staged_0, _staged_0 == h15 ? q15 : blk_loc(e.mem, _staged_0)) == 0) {
      return 0;
    }
    _v_47 = _o_1[0];
    _v_46 = _v_47;
    Term _v_51 = 0;
    Term _o_2[1];
    if (spin_66(e, _o_2, _v_46, _v_46 == h15 ? q15 : _v_46 == h14 ? q14 : _v_46 == h13 ? q13 : _v_46 == h11 ? q11 : _v_46 == h7 ? q7 : _v_46 == h6 ? q6 : _v_46 == h5 ? q5 : _v_46 == h4 ? q4 : _v_46 == h3 ? q3 : _v_46 == h2 ? q2 : blk_loc(e.mem, _v_46), _world_56, _world_56 == h11 ? q11 : blk_loc(e.mem, _world_56)) == 0) {
      return 0;
    }
    _v_51 = _o_2[0];
    _v_45 = _v_51;
    _v_30 = _world_45;
    _v_31 = _world_46;
    _v_32 = _world_47;
    _v_33 = _world_48;
    _v_34 = _world_49;
    _v_35 = _world_50;
    _v_36 = _world_51;
    _v_37 = _world_52;
    _v_38 = _world_53;
    _v_39 = _world_54;
    _v_40 = _world_55;
    _v_41 = _v_45;
    _v_42 = _world_57;
    _v_43 = _world_58;
    _v_44 = _world_59;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  return 1;
}

INLINE Term spin_69(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _command_0 = r9;
  u32 _command_1 = r10;
  Term _command_2 = r11;
  Term _command_3 = r12;
  u32 _command_4 = r13;
  Term _command_5 = r14;
  u32 _command_6 = r15;
  Term _command_7 = r16;
  WL_SPIN
    if (_command_0 == 0) {
      Term _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      Term _o_10[10];
      if (spin_53(e, _o_10, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1) == 0) {
        return 0;
      }
      _v_80 = _o_10[0];
      _v_81 = _o_10[1];
      _v_82 = _o_10[2];
      _v_83 = _o_10[3];
      _v_84 = _o_10[4];
      _v_85 = _o_10[5];
      _v_86 = _o_10[6];
      _v_87 = _o_10[7];
      _v_88 = _o_10[8];
      _v_89 = _o_10[9];
      _v_70 = _v_80;
      _v_71 = _v_81;
      _v_72 = _v_82;
      _v_73 = _v_83;
      _v_74 = _v_84;
      _v_75 = _v_85;
      _v_76 = _v_86;
      _v_77 = _v_87;
      _v_78 = _v_88;
      _v_79 = _v_89;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      Term _v_95 = 0;
      u32 _v_96 = 0;
      Term _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      Term _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      Term _o_11[18];
      if (spin_54(e, _o_11, _command_1, _command_2, _command_3, _command_3 == h12 ? q12 : blk_loc(e.mem, _command_3), _command_4, _command_5, _command_5 == h14 ? q14 : blk_loc(e.mem, _command_5), _command_6, _command_7, _command_7 == h16 ? q16 : blk_loc(e.mem, _command_7), _v_70, _v_70 == h16 ? q16 : _v_70 == h14 ? q14 : _v_70 == h12 ? q12 : _v_70 == h11 ? q11 : _v_70 == h5 ? q5 : _v_70 == h4 ? q4 : _v_70 == h3 ? q3 : _v_70 == h2 ? q2 : _v_70 == h1 ? q1 : _v_70 == h0 ? q0 : blk_loc(e.mem, _v_70), _v_71, _v_71 == h16 ? q16 : _v_71 == h14 ? q14 : _v_71 == h12 ? q12 : _v_71 == h11 ? q11 : _v_71 == h5 ? q5 : _v_71 == h4 ? q4 : _v_71 == h3 ? q3 : _v_71 == h2 ? q2 : _v_71 == h1 ? q1 : _v_71 == h0 ? q0 : blk_loc(e.mem, _v_71), _v_72, _v_72 == h16 ? q16 : _v_72 == h14 ? q14 : _v_72 == h12 ? q12 : _v_72 == h11 ? q11 : _v_72 == h5 ? q5 : _v_72 == h4 ? q4 : _v_72 == h3 ? q3 : _v_72 == h2 ? q2 : _v_72 == h1 ? q1 : _v_72 == h0 ? q0 : blk_loc(e.mem, _v_72), _v_73, _v_73 == h16 ? q16 : _v_73 == h14 ? q14 : _v_73 == h12 ? q12 : _v_73 == h11 ? q11 : _v_73 == h5 ? q5 : _v_73 == h4 ? q4 : _v_73 == h3 ? q3 : _v_73 == h2 ? q2 : _v_73 == h1 ? q1 : _v_73 == h0 ? q0 : blk_loc(e.mem, _v_73), _v_74, _v_74 == h16 ? q16 : _v_74 == h14 ? q14 : _v_74 == h12 ? q12 : _v_74 == h11 ? q11 : _v_74 == h5 ? q5 : _v_74 == h4 ? q4 : _v_74 == h3 ? q3 : _v_74 == h2 ? q2 : _v_74 == h1 ? q1 : _v_74 == h0 ? q0 : blk_loc(e.mem, _v_74), _v_75, _v_75 == h16 ? q16 : _v_75 == h14 ? q14 : _v_75 == h12 ? q12 : _v_75 == h11 ? q11 : _v_75 == h5 ? q5 : _v_75 == h4 ? q4 : _v_75 == h3 ? q3 : _v_75 == h2 ? q2 : _v_75 == h1 ? q1 : _v_75 == h0 ? q0 : blk_loc(e.mem, _v_75), _v_76, _v_77, _v_78, _v_79) == 0) {
        return 0;
      }
      _v_90 = _o_11[0];
      _v_91 = _o_11[1];
      _v_92 = _o_11[2];
      _v_93 = _o_11[3];
      _v_94 = _o_11[4];
      _v_95 = _o_11[5];
      _v_96 = _o_11[6];
      _v_97 = _o_11[7];
      _v_98 = _o_11[8];
      _v_99 = _o_11[9];
      _v_100 = _o_11[10];
      _v_101 = _o_11[11];
      _v_102 = _o_11[12];
      _v_103 = _o_11[13];
      _v_104 = _o_11[14];
      _v_105 = _o_11[15];
      _v_106 = _o_11[16];
      _v_107 = _o_11[17];
      _v_52 = _v_90;
      _v_53 = _v_91;
      _v_54 = _v_92;
      _v_55 = _v_93;
      _v_56 = _v_94;
      _v_57 = _v_95;
      _v_58 = _v_96;
      _v_59 = _v_97;
      _v_60 = _v_98;
      _v_61 = _v_99;
      _v_62 = _v_100;
      _v_63 = _v_101;
      _v_64 = _v_102;
      _v_65 = _v_103;
      _v_66 = _v_104;
      _v_67 = _v_105;
      _v_68 = _v_106;
      _v_69 = _v_107;
    } else {
      _v_52 = _rows_0;
      _v_53 = _rows_1;
      _v_54 = _rows_2;
      _v_55 = _rows_3;
      _v_56 = _rows_4;
      _v_57 = _rows_5;
      _v_58 = _rows_6;
      _v_59 = _rows_7;
      _v_60 = _rows_8;
      _v_61 = _command_0;
      _v_62 = _command_1;
      _v_63 = _command_2;
      _v_64 = _command_3;
      _v_65 = _command_4;
      _v_66 = _command_5;
      _v_67 = _command_6;
      _v_68 = _command_7;
      _v_69 = 1;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  return 1;
}

INLINE Term spin_70(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  Term _v_122 = 0;
  Term _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  Term _v_126 = 0;
  u32 _v_127 = 0;
  Term _v_128 = 0;
  u32 _v_129 = 0;
  Term _reverse_0 = r0;
  u32 _valid_0 = r1;
  Term _result_0 = r2;
  Term _result_1 = r3;
  Term _result_2 = r4;
  Term _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  Term _result_7 = r9;
  u32 _result_8 = r10;
  u32 _result_9 = r11;
  u32 _result_10 = r12;
  Term _result_11 = r13;
  Term _result_12 = r14;
  u32 _result_13 = r15;
  Term _result_14 = r16;
  u32 _result_15 = r17;
  Term _result_16 = r18;
  u32 _result_17 = r19;
  WL_SPIN
    Term _b_0 = 0;
    if (_result_9 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_11);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_12);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_13);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_14);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_15);
      e.mem[_nd_1 + 6] = rfc_seal(e, _result_16);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_result_9 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_2 + 1] = rfc_seal(e, _result_11);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_result_9 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_3 + 1] = rfc_seal(e, _result_11);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_result_9 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _result_10);
    } else if (_result_9 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _result_10);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _result_10);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _reverse_0);
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _o_13[1];
    if (spin_17(e, _o_13, _valid_0, _result_17) == 0) {
      return 0;
    }
    _v_131 = _o_13[0];
    _v_130 = _v_131;
    _v_119 = _result_0;
    _v_120 = _result_1;
    _v_121 = _result_2;
    _v_122 = _result_3;
    _v_123 = _result_4;
    _v_124 = _result_5;
    _v_125 = _result_6;
    _v_126 = _result_7;
    _v_127 = _result_8;
    _v_128 = term_ctr(CID_CON, _nd_4);
    _v_129 = _v_130;
  break;
  }
  o[0] = _v_119;
  o[1] = _v_120;
  o[2] = _v_121;
  o[3] = _v_122;
  o[4] = _v_123;
  o[5] = _v_124;
  o[6] = _v_125;
  o[7] = _v_126;
  o[8] = _v_127;
  o[9] = _v_128;
  o[10] = _v_129;
  return 1;
}

INLINE Term spin_71(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  u32 _state_21 = r0;
  Term _state_22 = r1;
  Term _state_23 = r2;
  Term _state_24 = r3;
  Term _state_25 = r4;
  Term _state_26 = r5;
  Term _state_27 = r6;
  u32 _state_28 = r7;
  Term _state_29 = r8;
  u32 _state_30 = r9;
  Term _state_31 = r10;
  u32 _state_32 = r11;
  Term _state_33 = r12;
  u32 _state_34 = r13;
  Term _state_35 = r14;
  u32 _state_36 = r15;
  Term _state_37 = r16;
  u32 _state_38 = r17;
  u32 _state_39 = r18;
  Term _state_40 = r19;
  Term _state_41 = r20;
  WL_SPIN
    if (_state_21 == 0) {
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _o_0[1];
      if (spin_57(e, _o_0, _state_31, _state_31 == h10 ? q10 : blk_loc(e.mem, _state_31)) == 0) {
        return 0;
      }
      _v_43 = _o_0[0];
      _v_42 = _v_43;
      _v_21 = 0;
      _v_22 = _state_22;
      _v_23 = _state_23;
      _v_24 = _state_24;
      _v_25 = _state_25;
      _v_26 = _state_26;
      _v_27 = _state_27;
      _v_28 = _state_28;
      _v_29 = _state_29;
      _v_30 = _state_30;
      _v_31 = _v_42;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
    } else {
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_1[1];
      if (spin_65(e, _o_1, _state_40, _state_40 == h19 ? q19 : blk_loc(e.mem, _state_40)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_44 = _v_45;
      _v_21 = 1;
      _v_22 = _state_22;
      _v_23 = _state_23;
      _v_24 = _state_24;
      _v_25 = _state_25;
      _v_26 = _state_26;
      _v_27 = _state_27;
      _v_28 = _state_28;
      _v_29 = _state_29;
      _v_30 = _state_30;
      _v_31 = _state_31;
      _v_32 = _state_32;
      _v_33 = _state_33;
      _v_34 = _state_34;
      _v_35 = _state_35;
      _v_36 = _state_36;
      _v_37 = _state_37;
      _v_38 = _state_38;
      _v_39 = _state_39;
      _v_40 = _v_44;
      _v_41 = _state_41;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_72(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _array_0 = r0;
  WL_SPIN
    Term _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[5];
    if (spin_63(e, _o_0, _array_0, _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0)) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_73(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _frame_0 = r0;
  Term _result_0 = r1;
  u32 _result_1 = r2;
  u32 _result_2 = r3;
  u32 _result_3 = r4;
  u32 _result_4 = r5;
  WL_SPIN
    _v_27 = _result_0;
    _v_28 = _frame_0;
    _v_29 = _result_1;
    _v_30 = _result_2;
    _v_31 = _result_3;
    _v_32 = _result_4;
    _v_33 = _frame_0;
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  o[5] = _v_32;
  o[6] = _v_33;
  return 1;
}

INLINE Term spin_76(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_26 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_26 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_76);
    }
  break;
  }
  o[0] = _v_26;
  return 1;
}

INLINE Term spin_75(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_24 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_25 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_76(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_25 = _o_0[0];
    _v_24 = _v_25;
  break;
  }
  o[0] = _v_24;
  return 1;
}

INLINE Term spin_74(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _commands_1 = r0;
  Term _state_0 = r1;
  Term _state_1 = r2;
  Term _state_2 = r3;
  Term _state_3 = r4;
  Term _state_4 = r5;
  Term _state_5 = r6;
  u32 _state_6 = r7;
  Term _state_7 = r8;
  u32 _state_8 = r9;
  Term _state_9 = r10;
  u32 _state_10 = r11;
  WL_SPIN
    if (term_aux(_commands_1) == CID_NIL) {
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _o_1[1];
      if (spin_75(e, _o_1, _state_9, _state_9 == h10 ? q10 : blk_loc(e.mem, _state_9)) == 0) {
        return 0;
      }
      _v_23 = _o_1[0];
      _v_22 = _v_23;
      _v_11 = _state_0;
      _v_12 = _state_1;
      _v_13 = _state_2;
      _v_14 = _state_3;
      _v_15 = _state_4;
      _v_16 = _state_5;
      _v_17 = _state_6;
      _v_18 = _state_7;
      _v_19 = _state_8;
      _v_20 = _v_22;
      _v_21 = _state_10;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _commands_1, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      u32 _o_6 = 0;
      Term _o_7 = 0;
      u32 _o_8 = 0;
      Term _o_9 = 0;
      if (term_aux(_f_2) == CID_STORAGE_SPAWN) {
        _o_2 = 0;
        Term _fb_2[7];
        u64 _sp_2 = ctr_take(e, _f_2, 7, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        Term _f_8 = _fb_2[4];
        u32 _f_9 = _fb_2[5];
        Term _f_10 = _fb_2[6];
        spare_free(e, cls_fit(7), _sp_2);
        _o_3 = _f_4;
        _o_4 = _f_5;
        _o_5 = _f_6;
        _o_6 = _f_7;
        _o_7 = _f_8;
        _o_8 = _f_9;
        _o_9 = _f_10;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTMAIN) {
        _o_2 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_2, 2, _fb_3);
        u32 _f_11 = _fb_3[0];
        Term _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_3 = _f_11;
        _o_4 = _f_12;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTFLAG) {
        _o_2 = 2;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_2, 2, _fb_4);
        u32 _f_13 = _fb_4[0];
        Term _f_14 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        _o_3 = _f_13;
        _o_4 = _f_14;
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEMAIN) {
        _o_2 = 3;
        _o_3 = term_loc(_f_2);
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEFLAG) {
        _o_2 = 4;
        _o_3 = term_loc(_f_2);
      } else {
        _o_2 = 5;
        _o_3 = term_loc(_f_2);
      }
      Term _v_27 = 0;
      Term _v_28 = 0;
      Term _v_29 = 0;
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      u32 _v_33 = 0;
      Term _v_34 = 0;
      u32 _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      u32 _v_51 = 0;
      Term _v_52 = 0;
      u32 _v_53 = 0;
      Term _v_54 = 0;
      u32 _v_55 = 0;
      Term _v_56 = 0;
      Term _v_57 = 0;
      Term _v_58 = 0;
      Term _v_59 = 0;
      Term _v_60 = 0;
      Term _v_61 = 0;
      u32 _v_62 = 0;
      Term _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      u32 _v_69 = 0;
      Term _v_70 = 0;
      u32 _v_71 = 0;
      Term _v_72 = 0;
      u32 _v_73 = 0;
      Term _o_10[18];
      if (spin_69(e, _o_10, _state_0, _state_0 == h1 ? q1 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h2 ? q2 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h3 ? q3 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h4 ? q4 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h5 ? q5 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h6 ? q6 : blk_loc(e.mem, _state_5), _state_6, _state_7, _state_8, _o_2, _o_3, _o_4, _o_4 == h10 ? q10 : _o_4 == h6 ? q6 : _o_4 == h5 ? q5 : _o_4 == h4 ? q4 : _o_4 == h3 ? q3 : _o_4 == h2 ? q2 : _o_4 == h1 ? q1 : _o_4 == h0 ? q0 : blk_loc(e.mem, _o_4), _o_5, _o_5 == h10 ? q10 : _o_5 == h6 ? q6 : _o_5 == h5 ? q5 : _o_5 == h4 ? q4 : _o_5 == h3 ? q3 : _o_5 == h2 ? q2 : _o_5 == h1 ? q1 : _o_5 == h0 ? q0 : blk_loc(e.mem, _o_5), _o_6, _o_7, _o_7 == h10 ? q10 : _o_7 == h6 ? q6 : _o_7 == h5 ? q5 : _o_7 == h4 ? q4 : _o_7 == h3 ? q3 : _o_7 == h2 ? q2 : _o_7 == h1 ? q1 : _o_7 == h0 ? q0 : blk_loc(e.mem, _o_7), _o_8, _o_9, _o_9 == h10 ? q10 : _o_9 == h6 ? q6 : _o_9 == h5 ? q5 : _o_9 == h4 ? q4 : _o_9 == h3 ? q3 : _o_9 == h2 ? q2 : _o_9 == h1 ? q1 : _o_9 == h0 ? q0 : blk_loc(e.mem, _o_9)) == 0) {
        return 0;
      }
      _v_56 = _o_10[0];
      _v_57 = _o_10[1];
      _v_58 = _o_10[2];
      _v_59 = _o_10[3];
      _v_60 = _o_10[4];
      _v_61 = _o_10[5];
      _v_62 = _o_10[6];
      _v_63 = _o_10[7];
      _v_64 = _o_10[8];
      _v_65 = _o_10[9];
      _v_66 = _o_10[10];
      _v_67 = _o_10[11];
      _v_68 = _o_10[12];
      _v_69 = _o_10[13];
      _v_70 = _o_10[14];
      _v_71 = _o_10[15];
      _v_72 = _o_10[16];
      _v_73 = _o_10[17];
      _v_38 = _v_56;
      _v_39 = _v_57;
      _v_40 = _v_58;
      _v_41 = _v_59;
      _v_42 = _v_60;
      _v_43 = _v_61;
      _v_44 = _v_62;
      _v_45 = _v_63;
      _v_46 = _v_64;
      _v_47 = _v_65;
      _v_48 = _v_66;
      _v_49 = _v_67;
      _v_50 = _v_68;
      _v_51 = _v_69;
      _v_52 = _v_70;
      _v_53 = _v_71;
      _v_54 = _v_72;
      _v_55 = _v_73;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      Term _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      Term _o_11[11];
      if (spin_70(e, _o_11, _state_9, _state_9 == h10 ? q10 : blk_loc(e.mem, _state_9), _state_10, _v_38, _v_38 == h10 ? q10 : _v_38 == h6 ? q6 : _v_38 == h5 ? q5 : _v_38 == h4 ? q4 : _v_38 == h3 ? q3 : _v_38 == h2 ? q2 : _v_38 == h1 ? q1 : _v_38 == h0 ? q0 : blk_loc(e.mem, _v_38), _v_39, _v_39 == h10 ? q10 : _v_39 == h6 ? q6 : _v_39 == h5 ? q5 : _v_39 == h4 ? q4 : _v_39 == h3 ? q3 : _v_39 == h2 ? q2 : _v_39 == h1 ? q1 : _v_39 == h0 ? q0 : blk_loc(e.mem, _v_39), _v_40, _v_40 == h10 ? q10 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : _v_40 == h0 ? q0 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h10 ? q10 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : _v_41 == h0 ? q0 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h10 ? q10 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : _v_42 == h0 ? q0 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h10 ? q10 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : _v_43 == h0 ? q0 : blk_loc(e.mem, _v_43), _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_49 == h10 ? q10 : _v_49 == h6 ? q6 : _v_49 == h5 ? q5 : _v_49 == h4 ? q4 : _v_49 == h3 ? q3 : _v_49 == h2 ? q2 : _v_49 == h1 ? q1 : _v_49 == h0 ? q0 : blk_loc(e.mem, _v_49), _v_50, _v_50 == h10 ? q10 : _v_50 == h6 ? q6 : _v_50 == h5 ? q5 : _v_50 == h4 ? q4 : _v_50 == h3 ? q3 : _v_50 == h2 ? q2 : _v_50 == h1 ? q1 : _v_50 == h0 ? q0 : blk_loc(e.mem, _v_50), _v_51, _v_52, _v_52 == h10 ? q10 : _v_52 == h6 ? q6 : _v_52 == h5 ? q5 : _v_52 == h4 ? q4 : _v_52 == h3 ? q3 : _v_52 == h2 ? q2 : _v_52 == h1 ? q1 : _v_52 == h0 ? q0 : blk_loc(e.mem, _v_52), _v_53, _v_54, _v_54 == h10 ? q10 : _v_54 == h6 ? q6 : _v_54 == h5 ? q5 : _v_54 == h4 ? q4 : _v_54 == h3 ? q3 : _v_54 == h2 ? q2 : _v_54 == h1 ? q1 : _v_54 == h0 ? q0 : blk_loc(e.mem, _v_54), _v_55) == 0) {
        return 0;
      }
      _v_74 = _o_11[0];
      _v_75 = _o_11[1];
      _v_76 = _o_11[2];
      _v_77 = _o_11[3];
      _v_78 = _o_11[4];
      _v_79 = _o_11[5];
      _v_80 = _o_11[6];
      _v_81 = _o_11[7];
      _v_82 = _o_11[8];
      _v_83 = _o_11[9];
      _v_84 = _o_11[10];
      _v_27 = _v_74;
      _v_28 = _v_75;
      _v_29 = _v_76;
      _v_30 = _v_77;
      _v_31 = _v_78;
      _v_32 = _v_79;
      _v_33 = _v_80;
      _v_34 = _v_81;
      _v_35 = _v_82;
      _v_36 = _v_83;
      _v_37 = _v_84;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _v_27;
      r2 = _v_28;
      r3 = _v_29;
      r4 = _v_30;
      r5 = _v_31;
      r6 = _v_32;
      r7 = _v_33;
      r8 = _v_34;
      r9 = _v_35;
      r10 = _v_36;
      r11 = _v_37;
      _commands_1 = r0;
      _state_0 = r1;
      _state_1 = r2;
      _state_2 = r3;
      _state_3 = r4;
      _state_4 = r5;
      _state_5 = r6;
      _state_6 = r7;
      _state_7 = r8;
      _state_8 = r9;
      _state_9 = r10;
      _state_10 = r11;
      WL_AGAIN(spin_74);
    }
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_77(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, Term r19, u64 q19, u32 r20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term h19 = r19;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _v_45 = 0;
  Term _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  u32 _ledger_4 = r2;
  Term _ledger_5 = r3;
  Term _mode_2 = r4;
  u32 _result_11 = r5;
  Term _result_12 = r6;
  Term _result_13 = r7;
  Term _result_14 = r8;
  Term _result_15 = r9;
  Term _result_16 = r10;
  Term _result_17 = r11;
  u32 _result_18 = r12;
  Term _result_19 = r13;
  u32 _result_20 = r14;
  Term _result_21 = r15;
  u32 _result_22 = r16;
  Term _result_23 = r17;
  u32 _result_24 = r18;
  Term _result_25 = r19;
  u32 _result_26 = r20;
  Term _result_27 = r21;
  u32 _result_28 = r22;
  u32 _result_29 = r23;
  Term _result_30 = r24;
  Term _result_31 = r25;
  WL_SPIN
    if (_result_11 == 0) {
      _v_28 = 0;
      _v_29 = _namespace_2;
      _v_30 = _next_2;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
      _v_38 = _result_19;
      _v_39 = _result_20;
      _v_40 = term_pak(CID_NIL, 0);
      _v_41 = _ledger_4;
      _v_42 = _ledger_5;
      _v_43 = _mode_2;
      _v_44 = _result_21;
      _v_45 = 0;
      _v_46 = 0;
      _v_47 = 0;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
      _v_52 = 0;
      _v_53 = 0;
    } else {
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _o_1[1];
      if (spin_65(e, _o_1, _result_30, _result_30 == h24 ? q24 : blk_loc(e.mem, _result_30)) == 0) {
        return 0;
      }
      _v_55 = _o_1[0];
      _v_54 = _v_55;
      _v_28 = 2;
      _v_29 = _namespace_2;
      _v_30 = _next_2;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
      _v_38 = _result_19;
      _v_39 = _result_20;
      _v_40 = _v_54;
      _v_41 = _ledger_4;
      _v_42 = _ledger_5;
      _v_43 = _mode_2;
      _v_44 = _result_21;
      _v_45 = _result_22;
      _v_46 = _result_23;
      _v_47 = _result_24;
      _v_48 = _result_25;
      _v_49 = _result_26;
      _v_50 = _result_27;
      _v_51 = _result_28;
      _v_52 = _result_29;
      _v_53 = _result_31;
    }
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  o[14] = _v_42;
  o[15] = _v_43;
  o[16] = _v_44;
  o[17] = _v_45;
  o[18] = _v_46;
  o[19] = _v_47;
  o[20] = _v_48;
  o[21] = _v_49;
  o[22] = _v_50;
  o[23] = _v_51;
  o[24] = _v_52;
  o[25] = _v_53;
  return 1;
}

INLINE Term spin_78(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  WL_SPIN
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _o_0[5];
    if (spin_72(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0)) == 0) {
      return 0;
    }
    _v_26 = _o_0[0];
    _v_27 = _o_0[1];
    _v_28 = _o_0[2];
    _v_29 = _o_0[3];
    _v_30 = _o_0[4];
    _v_21 = _v_26;
    _v_22 = _v_27;
    _v_23 = _v_28;
    _v_24 = _v_29;
    _v_25 = _v_30;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_1[7];
    if (spin_73(e, _o_1, _owner_1, _v_21, _v_21 == h0 ? q0 : blk_loc(e.mem, _v_21), _v_22, _v_23, _v_24, _v_25) == 0) {
      return 0;
    }
    _v_31 = _o_1[0];
    _v_32 = _o_1[1];
    _v_33 = _o_1[2];
    _v_34 = _o_1[3];
    _v_35 = _o_1[4];
    _v_36 = _o_1[5];
    _v_37 = _o_1[6];
    _v_14 = _v_31;
    _v_15 = _v_32;
    _v_16 = _v_33;
    _v_17 = _v_34;
    _v_18 = _v_35;
    _v_19 = _v_36;
    _v_20 = _v_37;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  return 1;
}

INLINE Term spin_79(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  WL_SPIN
    _v_45 = _result_0;
    _v_46 = _result_1;
    _v_47 = _result_2;
    _v_48 = _result_3;
    _v_49 = _result_4;
    _v_50 = _result_5;
    _v_51 = _result_6;
  break;
  }
  o[0] = _v_45;
  o[1] = _v_46;
  o[2] = _v_47;
  o[3] = _v_48;
  o[4] = _v_49;
  o[5] = _v_50;
  o[6] = _v_51;
  return 1;
}

INLINE Term spin_80(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  Term _main_1 = r1;
  WL_SPIN
    _v_8 = 1;
    _v_9 = _id_0;
    _v_10 = _main_1;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_81(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  u32 _owner_3 = r3;
  u32 _owner_4 = r4;
  u32 _owner_5 = r5;
  u32 _owner_6 = r6;
  WL_SPIN
    _v_4 = _owner_0;
    _v_5 = _owner_1;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_82(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _commands_0 = r0;
  Term _rows_0 = r1;
  Term _rows_1 = r2;
  Term _rows_2 = r3;
  Term _rows_3 = r4;
  Term _rows_4 = r5;
  Term _rows_5 = r6;
  u32 _rows_6 = r7;
  Term _rows_7 = r8;
  u32 _rows_8 = r9;
  WL_SPIN
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _o_0[11];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_74(e, _o_0, _commands_0, _commands_0 == h0 ? q0 : blk_loc(e.mem, _commands_0), _rows_0, _rows_0 == h1 ? q1 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h2 ? q2 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h3 ? q3 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h4 ? q4 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h5 ? q5 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h6 ? q6 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _a_0, _a_0 == h6 ? q6 : _a_0 == h5 ? q5 : _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), 1) == 0) {
      return 0;
    }
    _v_33 = _o_0[0];
    _v_34 = _o_0[1];
    _v_35 = _o_0[2];
    _v_36 = _o_0[3];
    _v_37 = _o_0[4];
    _v_38 = _o_0[5];
    _v_39 = _o_0[6];
    _v_40 = _o_0[7];
    _v_41 = _o_0[8];
    _v_42 = _o_0[9];
    _v_43 = _o_0[10];
    _v_22 = _v_33;
    _v_23 = _v_34;
    _v_24 = _v_35;
    _v_25 = _v_36;
    _v_26 = _v_37;
    _v_27 = _v_38;
    _v_28 = _v_39;
    _v_29 = _v_40;
    _v_30 = _v_41;
    _v_31 = _v_42;
    _v_32 = _v_43;
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_83(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _raw_2 = r0;
  u32 _raw_3 = r1;
  WL_SPIN
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    Term _o_0[7];
    if (spin_78(e, _o_0, _raw_2, _raw_2 == h0 ? q0 : blk_loc(e.mem, _raw_2), _raw_3) == 0) {
      return 0;
    }
    _v_28 = _o_0[0];
    _v_29 = _o_0[1];
    _v_30 = _o_0[2];
    _v_31 = _o_0[3];
    _v_32 = _o_0[4];
    _v_33 = _o_0[5];
    _v_34 = _o_0[6];
    _v_21 = _v_28;
    _v_22 = _v_29;
    _v_23 = _v_30;
    _v_24 = _v_31;
    _v_25 = _v_32;
    _v_26 = _v_33;
    _v_27 = _v_34;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    Term _o_1[7];
    if (spin_79(e, _o_1, _v_21, _v_21 == h0 ? q0 : blk_loc(e.mem, _v_21), _v_22, _v_23, _v_24, _v_25, _v_26, _v_27) == 0) {
      return 0;
    }
    _v_35 = _o_1[0];
    _v_36 = _o_1[1];
    _v_37 = _o_1[2];
    _v_38 = _o_1[3];
    _v_39 = _o_1[4];
    _v_40 = _o_1[5];
    _v_41 = _o_1[6];
    _v_14 = _v_35;
    _v_15 = _v_36;
    _v_16 = _v_37;
    _v_17 = _v_38;
    _v_18 = _v_39;
    _v_19 = _v_40;
    _v_20 = _v_41;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  return 1;
}

INLINE Term spin_84(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, Term r22, u64 q22, u32 r23, u32 r24, u32 r25, u32 r26, u32 r27, u32 r28) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h22 = r22;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  u32 _v_75 = 0;
  Term _v_76 = 0;
  u32 _v_77 = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  u32 _result_9 = r9;
  Term _result_10 = r10;
  u32 _result_11 = r11;
  Term _result_12 = r12;
  u32 _result_13 = r13;
  Term _result_14 = r14;
  u32 _result_15 = r15;
  u32 _result_16 = r16;
  u32 _result_17 = r17;
  u32 _result_18 = r18;
  u32 _result_19 = r19;
  u32 _result_20 = r20;
  u32 _result_21 = r21;
  Term _result_22 = r22;
  u32 _result_23 = r23;
  u32 _result_24 = r24;
  u32 _result_25 = r25;
  u32 _result_26 = r26;
  u32 _result_27 = r27;
  u32 _result_28 = r28;
  WL_SPIN
    if (_result_0 == 0) {
      _v_66 = 0;
      _v_67 = _result_1;
      _v_68 = _result_2;
      _v_69 = _result_3;
      _v_70 = _result_4;
      _v_71 = _result_5;
      _v_72 = _result_6;
      _v_73 = _result_7;
      _v_74 = _result_8;
      _v_75 = _result_9;
      _v_76 = _result_10;
      _v_77 = _result_11;
      _v_78 = _result_12;
      _v_79 = _result_13;
      _v_80 = _result_14;
      _v_81 = _result_15;
      _v_82 = _result_16;
      _v_83 = _result_17;
      _v_84 = _result_18;
      _v_85 = _result_19;
      _v_86 = _result_20;
      _v_87 = _result_21;
      _v_88 = 0;
      _v_89 = 0;
    } else {
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _o_52[2];
      if (spin_81(e, _o_52, _result_22, _result_22 == h22 ? q22 : blk_loc(e.mem, _result_22), _result_23, _result_24, _result_25, _result_26, _result_27, _result_28) == 0) {
        return 0;
      }
      _v_92 = _o_52[0];
      _v_93 = _o_52[1];
      _v_90 = _v_92;
      _v_91 = _v_93;
      _v_66 = 1;
      _v_67 = _result_1;
      _v_68 = _result_2;
      _v_69 = _result_3;
      _v_70 = _result_4;
      _v_71 = _result_5;
      _v_72 = _result_6;
      _v_73 = _result_7;
      _v_74 = _result_8;
      _v_75 = _result_9;
      _v_76 = _result_10;
      _v_77 = _result_11;
      _v_78 = _result_12;
      _v_79 = _result_13;
      _v_80 = _result_14;
      _v_81 = _result_15;
      _v_82 = _result_16;
      _v_83 = _result_17;
      _v_84 = _result_18;
      _v_85 = _result_19;
      _v_86 = _result_20;
      _v_87 = _result_21;
      _v_88 = _v_90;
      _v_89 = _v_91;
    }
  break;
  }
  o[0] = _v_66;
  o[1] = _v_67;
  o[2] = _v_68;
  o[3] = _v_69;
  o[4] = _v_70;
  o[5] = _v_71;
  o[6] = _v_72;
  o[7] = _v_73;
  o[8] = _v_74;
  o[9] = _v_75;
  o[10] = _v_76;
  o[11] = _v_77;
  o[12] = _v_78;
  o[13] = _v_79;
  o[14] = _v_80;
  o[15] = _v_81;
  o[16] = _v_82;
  o[17] = _v_83;
  o[18] = _v_84;
  o[19] = _v_85;
  o[20] = _v_86;
  o[21] = _v_87;
  o[22] = _v_88;
  o[23] = _v_89;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW)
  {
    Term _fuel_0 = r0;
    u32 _id_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    WL_OPEN
    if (_fuel_0 == 0) {
      r0 = _rows_0;
      r1 = _rows_1;
      r2 = _rows_2;
      r3 = _rows_3;
      r4 = _rows_4;
      r5 = _rows_5;
      r6 = _rows_6;
      r7 = _rows_7;
      r8 = _rows_8;
      WL_RETN(9);
    } else {
      Term _n_0 = (_fuel_0 - 1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_17(e, _o_0, U32_BIN(_rows_6, <, _id_0), U32_BIN(_rows_6, <=, 65536ull)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _n_0;
      e.mem[_nd_0 + 1] = _id_0;
      if (_v_0 == 0) {
        Term _recurse_0 = term_clo(FID_STORAGE_GROW_C31, _nd_0);
        term_sink(e, _recurse_0);
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        WL_RETN(9);
      } else {
        Term _recurse_1 = term_clo(FID_STORAGE_GROW_C31, _nd_0);
        if (seq) {
          WL_ROOM(11);
          STK(0) = _rows_0;
          STK(1) = _rows_1;
          STK(2) = _rows_2;
          STK(3) = _rows_3;
          STK(4) = _rows_4;
          STK(5) = _rows_5;
          STK(6) = _rows_6;
          STK(7) = _rows_7;
          STK(8) = _rows_8;
          STK(9) = _recurse_1;
          STK(10) = FID_STORAGE_GROW_K33;
          WL_PUSHN(11);
        } else {
          u64 _t_2 = task_node(e, FID_STORAGE_GROW_K33, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _rows_0;
          e.mem[_t_2 + 1] = _rows_1;
          e.mem[_t_2 + 2] = _rows_2;
          e.mem[_t_2 + 3] = _rows_3;
          e.mem[_t_2 + 4] = _rows_4;
          e.mem[_t_2 + 5] = _rows_5;
          e.mem[_t_2 + 6] = _rows_6;
          e.mem[_t_2 + 7] = _rows_7;
          e.mem[_t_2 + 8] = _rows_8;
          e.mem[_t_2 + 9] = _recurse_1;
          WL_CONT = term_tsk(FID_STORAGE_GROW_K33, _t_2);
          WL_IDX = 10;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
          u64 _t_3 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_7;
          return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_3);
        }
        r0 = _rows_7;
        WL_JMP(FID_STORAGE_SLOTS_EMPTY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_C31)
  {
    Term _n_1 = r0;
    u32 _id_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    u32 _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K32;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STORAGE_GROW_K32, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K32, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
      u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _n_1;
      e.mem[_t_1 + 1] = _id_1;
      e.mem[_t_1 + 2] = _f_0;
      e.mem[_t_1 + 3] = _f_1;
      e.mem[_t_1 + 4] = _f_2;
      e.mem[_t_1 + 5] = _f_3;
      e.mem[_t_1 + 6] = _f_4;
      e.mem[_t_1 + 7] = _f_5;
      e.mem[_t_1 + 8] = _f_6;
      e.mem[_t_1 + 9] = _f_7;
      e.mem[_t_1 + 10] = _f_8;
      return term_tsk(FID_STORAGE_GROW, _t_1);
    }
    r0 = _n_1;
    r1 = _id_1;
    r2 = _f_0;
    r3 = _f_1;
    r4 = _f_2;
    r5 = _f_3;
    r6 = _f_4;
    r7 = _f_5;
    r8 = _f_6;
    r9 = _f_7;
    r10 = _f_8;
    WL_JMP(FID_STORAGE_GROW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K32)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    u32 _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_1 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_1 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_1 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_1 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_1 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_1 + 8] = rfc_seal(e, _r_8);
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K33)
  {
    WL_POPN(10);
    Term _rows_9 = STK(0);
    Term _rows_10 = STK(1);
    Term _rows_11 = STK(2);
    Term _rows_12 = STK(3);
    Term _rows_13 = STK(4);
    Term _rows_14 = STK(5);
    u32 _rows_15 = STK(6);
    Term _rows_16 = STK(7);
    u32 _rows_17 = STK(8);
    Term _recurse_2 = STK(9);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_9;
      STK(1) = _rows_10;
      STK(2) = _rows_11;
      STK(3) = _rows_12;
      STK(4) = _rows_13;
      STK(5) = _rows_14;
      STK(6) = _rows_15;
      STK(7) = _rows_16;
      STK(8) = _rows_17;
      STK(9) = _recurse_2;
      STK(10) = _h_0;
      STK(11) = FID_STORAGE_GROW_K34;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_STORAGE_GROW_K34, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _rows_9;
      e.mem[_t_4 + 1] = _rows_10;
      e.mem[_t_4 + 2] = _rows_11;
      e.mem[_t_4 + 3] = _rows_12;
      e.mem[_t_4 + 4] = _rows_13;
      e.mem[_t_4 + 5] = _rows_14;
      e.mem[_t_4 + 6] = _rows_15;
      e.mem[_t_4 + 7] = _rows_16;
      e.mem[_t_4 + 8] = _rows_17;
      e.mem[_t_4 + 9] = _recurse_2;
      e.mem[_t_4 + 10] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_GROW_K34, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_5 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rows_16;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_5);
    }
    r0 = _rows_16;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K34)
  {
    WL_POPN(11);
    Term _rows_18 = STK(0);
    Term _rows_19 = STK(1);
    Term _rows_20 = STK(2);
    Term _rows_21 = STK(3);
    Term _rows_22 = STK(4);
    Term _rows_23 = STK(5);
    u32 _rows_24 = STK(6);
    Term _rows_25 = STK(7);
    u32 _rows_26 = STK(8);
    Term _recurse_3 = STK(9);
    Term _h_2 = STK(10);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _o_1[4];
    if (spin_12(e, _o_1, _rows_20, blk_loc(e.mem, _rows_20), _rows_21, blk_loc(e.mem, _rows_21), _rows_22, blk_loc(e.mem, _rows_22), _rows_23, blk_loc(e.mem, _rows_23), _rows_25) == 0) {
      return 0;
    }
    _v_6 = _o_1[0];
    _v_7 = _o_1[1];
    _v_8 = _o_1[2];
    _v_9 = _o_1[3];
    _v_2 = _v_6;
    _v_3 = _v_7;
    _v_4 = _v_8;
    _v_5 = _v_9;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = rfc_seal(e, blk_node(e, _rows_18, _h_2));
    e.mem[_nd_2 + 1] = rfc_seal(e, blk_node(e, _rows_19, _h_1));
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 6] = rfc_seal(e, U32_BIN(_rows_24, +, _rows_24));
    e.mem[_nd_2 + 7] = rfc_seal(e, nat_chk(e, _rows_25 + 1));
    e.mem[_nd_2 + 8] = rfc_seal(e, _rows_26);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K35;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_STORAGE_GROW_K35, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K35, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _recurse_3;
      e.mem[_t_7 + 1] = term_ctr(CID_STORAGE_ROWS, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _recurse_3;
    r1 = term_ctr(CID_STORAGE_ROWS, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K35)
  {
    Term _r_9 = r0;
    WL_OPEN
    Term _fb_1[9];
    u64 _sp_1 = ctr_take(e, _r_9, 9, _fb_1);
    Term _f_9 = _fb_1[0];
    Term _f_10 = _fb_1[1];
    Term _f_11 = _fb_1[2];
    Term _f_12 = _fb_1[3];
    Term _f_13 = _fb_1[4];
    Term _f_14 = _fb_1[5];
    u32 _f_15 = _fb_1[6];
    Term _f_16 = _fb_1[7];
    u32 _f_17 = _fb_1[8];
    spare_free(e, cls_fit(9), _sp_1);
    r0 = _f_9;
    r1 = _f_10;
    r2 = _f_11;
    r3 = _f_12;
    r4 = _f_13;
    r5 = _f_14;
    r6 = _f_15;
    r7 = _f_16;
    r8 = _f_17;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    u32 _row_0 = r9;
    u32 _row_1 = r10;
    Term _row_2 = r11;
    u32 _row_3 = r12;
    Term _row_4 = r13;
    u32 _row_5 = r14;
    Term _row_6 = r15;
    u32 _row_7 = r16;
    u32 _row_8 = r17;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_17(e, _o_0, U32_BIN(0ull, <, _row_0), U32_BIN(_row_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (_v_0 == 0) {
      r0 = 1;
      r1 = _rows_0;
      r2 = _rows_1;
      r3 = _rows_2;
      r4 = _rows_3;
      r5 = _rows_4;
      r6 = _rows_5;
      r7 = _rows_6;
      r8 = _rows_7;
      r9 = _rows_8;
      r10 = _row_0;
      r11 = _row_1;
      r12 = _row_2;
      r13 = _row_3;
      r14 = _row_4;
      r15 = _row_5;
      r16 = _row_6;
      r17 = _row_7;
      r18 = _row_8;
      WL_RETN(19);
    } else {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _row_0;
        STK(1) = _row_1;
        STK(2) = _row_2;
        STK(3) = _row_3;
        STK(4) = _row_4;
        STK(5) = _row_5;
        STK(6) = _row_6;
        STK(7) = _row_7;
        STK(8) = _row_8;
        STK(9) = FID_STORAGE_ROWS_PLACE_K50;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_ROWS_PLACE_K50, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _row_0;
        e.mem[_t_0 + 1] = _row_1;
        e.mem[_t_0 + 2] = _row_2;
        e.mem[_t_0 + 3] = _row_3;
        e.mem[_t_0 + 4] = _row_4;
        e.mem[_t_0 + 5] = _row_5;
        e.mem[_t_0 + 6] = _row_6;
        e.mem[_t_0 + 7] = _row_7;
        e.mem[_t_0 + 8] = _row_8;
        WL_CONT = term_tsk(FID_STORAGE_ROWS_PLACE_K50, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
        u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = 17ull;
        e.mem[_t_1 + 1] = _row_0;
        e.mem[_t_1 + 2] = _rows_0;
        e.mem[_t_1 + 3] = _rows_1;
        e.mem[_t_1 + 4] = _rows_2;
        e.mem[_t_1 + 5] = _rows_3;
        e.mem[_t_1 + 6] = _rows_4;
        e.mem[_t_1 + 7] = _rows_5;
        e.mem[_t_1 + 8] = _rows_6;
        e.mem[_t_1 + 9] = _rows_7;
        e.mem[_t_1 + 10] = _rows_8;
        return term_tsk(FID_STORAGE_GROW, _t_1);
      }
      r0 = 17ull;
      r1 = _row_0;
      r2 = _rows_0;
      r3 = _rows_1;
      r4 = _rows_2;
      r5 = _rows_3;
      r6 = _rows_4;
      r7 = _rows_5;
      r8 = _rows_6;
      r9 = _rows_7;
      r10 = _rows_8;
      WL_JMP(FID_STORAGE_GROW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE_K50)
  {
    WL_POPN(9);
    u32 _row_9 = STK(0);
    u32 _row_10 = STK(1);
    Term _row_11 = STK(2);
    u32 _row_12 = STK(3);
    Term _row_13 = STK(4);
    u32 _row_14 = STK(5);
    Term _row_15 = STK(6);
    u32 _row_16 = STK(7);
    u32 _row_17 = STK(8);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _o_1[19];
    if (spin_30(e, _o_1, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, _row_9, _row_10, _row_11, blk_loc(e.mem, _row_11), _row_12, _row_13, blk_loc(e.mem, _row_13), _row_14, _row_15, blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    _v_3 = _o_1[1];
    _v_4 = _o_1[2];
    _v_5 = _o_1[3];
    _v_6 = _o_1[4];
    _v_7 = _o_1[5];
    _v_8 = _o_1[6];
    _v_9 = _o_1[7];
    _v_10 = _o_1[8];
    _v_11 = _o_1[9];
    _v_12 = _o_1[10];
    _v_13 = _o_1[11];
    _v_14 = _o_1[12];
    _v_15 = _o_1[13];
    _v_16 = _o_1[14];
    _v_17 = _o_1[15];
    _v_18 = _o_1[16];
    _v_19 = _o_1[17];
    _v_20 = _o_1[18];
    r0 = _v_2;
    r1 = _v_3;
    r2 = _v_4;
    r3 = _v_5;
    r4 = _v_6;
    r5 = _v_7;
    r6 = _v_8;
    r7 = _v_9;
    r8 = _v_10;
    r9 = _v_11;
    r10 = _v_12;
    r11 = _v_13;
    r12 = _v_14;
    r13 = _v_15;
    r14 = _v_16;
    r15 = _v_17;
    r16 = _v_18;
    r17 = _v_19;
    r18 = _v_20;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP)
  {
    u32 _namespace_0 = r0;
    u32 _tick_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    u32 _command_0 = r11;
    u32 _command_1 = r12;
    Term _command_2 = r13;
    Term _command_3 = r14;
    u32 _command_4 = r15;
    Term _command_5 = r16;
    u32 _command_6 = r17;
    Term _command_7 = r18;
    WL_OPEN
    if (_command_0 == 0) {
      if (_command_2 == 0) {
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_COMMANDS_STEP_K69;
          WL_PUSHN(1);
        } else {
          u64 _t_0 = task_node(e, FID_COMMANDS_STEP_K69, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_COMMANDS_STEP_K69, _t_0);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
          u64 _t_1 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _rows_0;
          e.mem[_t_1 + 1] = _rows_1;
          e.mem[_t_1 + 2] = _rows_2;
          e.mem[_t_1 + 3] = _rows_3;
          e.mem[_t_1 + 4] = _rows_4;
          e.mem[_t_1 + 5] = _rows_5;
          e.mem[_t_1 + 6] = _rows_6;
          e.mem[_t_1 + 7] = _rows_7;
          e.mem[_t_1 + 8] = _rows_8;
          e.mem[_t_1 + 9] = _command_1;
          e.mem[_t_1 + 10] = 0;
          e.mem[_t_1 + 11] = 0;
          e.mem[_t_1 + 12] = _command_4;
          e.mem[_t_1 + 13] = _command_5;
          e.mem[_t_1 + 14] = _command_6;
          e.mem[_t_1 + 15] = _command_7;
          e.mem[_t_1 + 16] = 0ull;
          e.mem[_t_1 + 17] = 0ull;
          return term_tsk(FID_STORAGE_ROWS_PLACE, _t_1);
        }
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        r9 = _command_1;
        r10 = 0;
        r11 = 0;
        r12 = _command_4;
        r13 = _command_5;
        r14 = _command_6;
        r15 = _command_7;
        r16 = 0ull;
        r17 = 0ull;
        WL_JMP(FID_STORAGE_ROWS_PLACE);
      } else {
        if (seq) {
          WL_ROOM(3);
          STK(0) = _namespace_0;
          STK(1) = _command_1;
          STK(2) = FID_COMMANDS_STEP_K70;
          WL_PUSHN(3);
        } else {
          u64 _t_2 = task_node(e, FID_COMMANDS_STEP_K70, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _namespace_0;
          e.mem[_t_2 + 1] = _command_1;
          WL_CONT = term_tsk(FID_COMMANDS_STEP_K70, _t_2);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
          u64 _t_3 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_0;
          e.mem[_t_3 + 1] = _rows_1;
          e.mem[_t_3 + 2] = _rows_2;
          e.mem[_t_3 + 3] = _rows_3;
          e.mem[_t_3 + 4] = _rows_4;
          e.mem[_t_3 + 5] = _rows_5;
          e.mem[_t_3 + 6] = _rows_6;
          e.mem[_t_3 + 7] = _rows_7;
          e.mem[_t_3 + 8] = _rows_8;
          e.mem[_t_3 + 9] = _command_1;
          e.mem[_t_3 + 10] = 1;
          e.mem[_t_3 + 11] = _command_3;
          e.mem[_t_3 + 12] = _command_4;
          e.mem[_t_3 + 13] = _command_5;
          e.mem[_t_3 + 14] = _command_6;
          e.mem[_t_3 + 15] = _command_7;
          e.mem[_t_3 + 16] = _tick_0;
          e.mem[_t_3 + 17] = _tick_0;
          return term_tsk(FID_STORAGE_ROWS_PLACE, _t_3);
        }
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        r9 = _command_1;
        r10 = 1;
        r11 = _command_3;
        r12 = _command_4;
        r13 = _command_5;
        r14 = _command_6;
        r15 = _command_7;
        r16 = _tick_0;
        r17 = _tick_0;
        WL_JMP(FID_STORAGE_ROWS_PLACE);
      }
    } else if (_command_0 == 1) {
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      Term _o_5[10];
      if (spin_41(e, _o_5, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1, 1, _command_2, blk_loc(e.mem, _command_2), _tick_0) == 0) {
        return 0;
      }
      _v_48 = _o_5[0];
      _v_49 = _o_5[1];
      _v_50 = _o_5[2];
      _v_51 = _o_5[3];
      _v_52 = _o_5[4];
      _v_53 = _o_5[5];
      _v_54 = _o_5[6];
      _v_55 = _o_5[7];
      _v_56 = _o_5[8];
      _v_57 = _o_5[9];
      _v_38 = _v_48;
      _v_39 = _v_49;
      _v_40 = _v_50;
      _v_41 = _v_51;
      _v_42 = _v_52;
      _v_43 = _v_53;
      _v_44 = _v_54;
      _v_45 = _v_55;
      _v_46 = _v_56;
      _v_47 = _v_57;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      Term _v_86 = 0;
      Term _v_87 = 0;
      Term _v_88 = 0;
      u32 _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      Term _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _o_6[19];
      if (spin_42(e, _o_6, _namespace_0, _command_1, _v_38, blk_loc(e.mem, _v_38), _v_39, blk_loc(e.mem, _v_39), _v_40, blk_loc(e.mem, _v_40), _v_41, blk_loc(e.mem, _v_41), _v_42, blk_loc(e.mem, _v_42), _v_43, blk_loc(e.mem, _v_43), _v_44, _v_45, _v_46, _v_47) == 0) {
        return 0;
      }
      _v_82 = _o_6[0];
      _v_83 = _o_6[1];
      _v_84 = _o_6[2];
      _v_85 = _o_6[3];
      _v_86 = _o_6[4];
      _v_87 = _o_6[5];
      _v_88 = _o_6[6];
      _v_89 = _o_6[7];
      _v_90 = _o_6[8];
      _v_91 = _o_6[9];
      _v_92 = _o_6[10];
      _v_93 = _o_6[11];
      _v_94 = _o_6[12];
      _v_95 = _o_6[13];
      _v_96 = _o_6[14];
      _v_97 = _o_6[15];
      _v_98 = _o_6[16];
      _v_99 = _o_6[17];
      _v_100 = _o_6[18];
      r0 = _v_82;
      r1 = _v_83;
      r2 = _v_84;
      r3 = _v_85;
      r4 = _v_86;
      r5 = _v_87;
      r6 = _v_88;
      r7 = _v_89;
      r8 = _v_90;
      r9 = _v_91;
      r10 = _v_92;
      r11 = _v_93;
      r12 = _v_94;
      r13 = _v_95;
      r14 = _v_96;
      r15 = _v_97;
      r16 = _v_98;
      r17 = _v_99;
      r18 = _v_100;
      WL_RETN(19);
    } else if (_command_0 == 3) {
      Term _v_120 = 0;
      Term _v_121 = 0;
      Term _v_122 = 0;
      Term _v_123 = 0;
      Term _v_124 = 0;
      Term _v_125 = 0;
      u32 _v_126 = 0;
      Term _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      Term _v_134 = 0;
      Term _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      u32 _v_139 = 0;
      Term _o_7[10];
      Term _a_2 = 0;
      if (spin_41(e, _o_7, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1, 0, _a_2, blk_loc(e.mem, _a_2), _tick_0) == 0) {
        return 0;
      }
      _v_130 = _o_7[0];
      _v_131 = _o_7[1];
      _v_132 = _o_7[2];
      _v_133 = _o_7[3];
      _v_134 = _o_7[4];
      _v_135 = _o_7[5];
      _v_136 = _o_7[6];
      _v_137 = _o_7[7];
      _v_138 = _o_7[8];
      _v_139 = _o_7[9];
      _v_120 = _v_130;
      _v_121 = _v_131;
      _v_122 = _v_132;
      _v_123 = _v_133;
      _v_124 = _v_134;
      _v_125 = _v_135;
      _v_126 = _v_136;
      _v_127 = _v_137;
      _v_128 = _v_138;
      _v_129 = _v_139;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      Term _v_142 = 0;
      Term _v_143 = 0;
      Term _v_144 = 0;
      Term _v_145 = 0;
      Term _v_146 = 0;
      u32 _v_147 = 0;
      Term _v_148 = 0;
      u32 _v_149 = 0;
      Term _v_150 = 0;
      u32 _v_151 = 0;
      Term _v_152 = 0;
      u32 _v_153 = 0;
      Term _v_154 = 0;
      u32 _v_155 = 0;
      Term _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      Term _o_8[19];
      if (spin_42(e, _o_8, _namespace_0, _command_1, _v_120, blk_loc(e.mem, _v_120), _v_121, blk_loc(e.mem, _v_121), _v_122, blk_loc(e.mem, _v_122), _v_123, blk_loc(e.mem, _v_123), _v_124, blk_loc(e.mem, _v_124), _v_125, blk_loc(e.mem, _v_125), _v_126, _v_127, _v_128, _v_129) == 0) {
        return 0;
      }
      _v_140 = _o_8[0];
      _v_141 = _o_8[1];
      _v_142 = _o_8[2];
      _v_143 = _o_8[3];
      _v_144 = _o_8[4];
      _v_145 = _o_8[5];
      _v_146 = _o_8[6];
      _v_147 = _o_8[7];
      _v_148 = _o_8[8];
      _v_149 = _o_8[9];
      _v_150 = _o_8[10];
      _v_151 = _o_8[11];
      _v_152 = _o_8[12];
      _v_153 = _o_8[13];
      _v_154 = _o_8[14];
      _v_155 = _o_8[15];
      _v_156 = _o_8[16];
      _v_157 = _o_8[17];
      _v_158 = _o_8[18];
      r0 = _v_140;
      r1 = _v_141;
      r2 = _v_142;
      r3 = _v_143;
      r4 = _v_144;
      r5 = _v_145;
      r6 = _v_146;
      r7 = _v_147;
      r8 = _v_148;
      r9 = _v_149;
      r10 = _v_150;
      r11 = _v_151;
      r12 = _v_152;
      r13 = _v_153;
      r14 = _v_154;
      r15 = _v_155;
      r16 = _v_156;
      r17 = _v_157;
      r18 = _v_158;
      WL_RETN(19);
    } else {
      u32 _v_159 = 0;
      u32 _v_160 = 0;
      Term _v_161 = 0;
      Term _v_162 = 0;
      u32 _v_163 = 0;
      Term _v_164 = 0;
      u32 _v_165 = 0;
      Term _v_166 = 0;
      u32 _v_167 = 0;
      u32 _v_168 = 0;
      u32 _v_169 = 0;
      Term _v_170 = 0;
      Term _v_171 = 0;
      u32 _v_172 = 0;
      Term _v_173 = 0;
      u32 _v_174 = 0;
      Term _v_175 = 0;
      u32 _v_176 = 0;
      Term _o_9[9];
      if (spin_43(e, _o_9, _command_0, _command_1, _command_2, blk_loc(e.mem, _command_2), _command_3, blk_loc(e.mem, _command_3), _command_4, _command_5, blk_loc(e.mem, _command_5), _command_6, _command_7, blk_loc(e.mem, _command_7)) == 0) {
        return 0;
      }
      _v_168 = _o_9[0];
      _v_169 = _o_9[1];
      _v_170 = _o_9[2];
      _v_171 = _o_9[3];
      _v_172 = _o_9[4];
      _v_173 = _o_9[5];
      _v_174 = _o_9[6];
      _v_175 = _o_9[7];
      _v_176 = _o_9[8];
      _v_159 = _v_168;
      _v_160 = _v_169;
      _v_161 = _v_170;
      _v_162 = _v_171;
      _v_163 = _v_172;
      _v_164 = _v_173;
      _v_165 = _v_174;
      _v_166 = _v_175;
      _v_167 = _v_176;
      u32 _v_186 = 0;
      Term _v_187 = 0;
      Term _v_188 = 0;
      Term _v_189 = 0;
      Term _v_190 = 0;
      Term _v_191 = 0;
      Term _v_192 = 0;
      u32 _v_193 = 0;
      Term _v_194 = 0;
      u32 _v_195 = 0;
      Term _v_196 = 0;
      u32 _v_197 = 0;
      Term _v_198 = 0;
      u32 _v_199 = 0;
      Term _v_200 = 0;
      u32 _v_201 = 0;
      Term _v_202 = 0;
      u32 _v_203 = 0;
      u32 _v_204 = 0;
      Term _o_12[19];
      if (spin_44(e, _o_12, _namespace_0, _tick_0, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _v_159, _v_160, _v_161, blk_loc(e.mem, _v_161), _v_162, blk_loc(e.mem, _v_162), _v_163, _v_164, blk_loc(e.mem, _v_164), _v_165, _v_166, blk_loc(e.mem, _v_166), _v_167) == 0) {
        return 0;
      }
      _v_186 = _o_12[0];
      _v_187 = _o_12[1];
      _v_188 = _o_12[2];
      _v_189 = _o_12[3];
      _v_190 = _o_12[4];
      _v_191 = _o_12[5];
      _v_192 = _o_12[6];
      _v_193 = _o_12[7];
      _v_194 = _o_12[8];
      _v_195 = _o_12[9];
      _v_196 = _o_12[10];
      _v_197 = _o_12[11];
      _v_198 = _o_12[12];
      _v_199 = _o_12[13];
      _v_200 = _o_12[14];
      _v_201 = _o_12[15];
      _v_202 = _o_12[16];
      _v_203 = _o_12[17];
      _v_204 = _o_12[18];
      r0 = _v_186;
      r1 = _v_187;
      r2 = _v_188;
      r3 = _v_189;
      r4 = _v_190;
      r5 = _v_191;
      r6 = _v_192;
      r7 = _v_193;
      r8 = _v_194;
      r9 = _v_195;
      r10 = _v_196;
      r11 = _v_197;
      r12 = _v_198;
      r13 = _v_199;
      r14 = _v_200;
      r15 = _v_201;
      r16 = _v_202;
      r17 = _v_203;
      r18 = _v_204;
      WL_RETN(19);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP_K69)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _o_0[19];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_38(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP_K70)
  {
    WL_POPN(2);
    u32 _namespace_1 = STK(0);
    u32 _command_8 = STK(1);
    u32 _h_19 = r0;
    Term _h_20 = r1;
    Term _h_21 = r2;
    Term _h_22 = r3;
    Term _h_23 = r4;
    Term _h_24 = r5;
    Term _h_25 = r6;
    u32 _h_26 = r7;
    Term _h_27 = r8;
    u32 _h_28 = r9;
    u32 _h_29 = r10;
    u32 _h_30 = r11;
    Term _h_31 = r12;
    u32 _h_32 = r13;
    Term _h_33 = r14;
    u32 _h_34 = r15;
    Term _h_35 = r16;
    u32 _h_36 = r17;
    u32 _h_37 = r18;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _command_8);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, _command_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINADDED, _nd_0));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_1[19];
    Term _a_1 = term_ctr(CID_CON, _nd_3);
    if (spin_38(e, _o_1, _a_1, blk_loc(e.mem, _a_1), _h_19, _h_20, blk_loc(e.mem, _h_20), _h_21, blk_loc(e.mem, _h_21), _h_22, blk_loc(e.mem, _h_22), _h_23, blk_loc(e.mem, _h_23), _h_24, blk_loc(e.mem, _h_24), _h_25, blk_loc(e.mem, _h_25), _h_26, _h_27, _h_28, _h_29, _h_30, _h_31, blk_loc(e.mem, _h_31), _h_32, _h_33, blk_loc(e.mem, _h_33), _h_34, _h_35, blk_loc(e.mem, _h_35), _h_36, _h_37) == 0) {
      return 0;
    }
    _v_19 = _o_1[0];
    _v_20 = _o_1[1];
    _v_21 = _o_1[2];
    _v_22 = _o_1[3];
    _v_23 = _o_1[4];
    _v_24 = _o_1[5];
    _v_25 = _o_1[6];
    _v_26 = _o_1[7];
    _v_27 = _o_1[8];
    _v_28 = _o_1[9];
    _v_29 = _o_1[10];
    _v_30 = _o_1[11];
    _v_31 = _o_1[12];
    _v_32 = _o_1[13];
    _v_33 = _o_1[14];
    _v_34 = _o_1[15];
    _v_35 = _o_1[16];
    _v_36 = _o_1[17];
    _v_37 = _o_1[18];
    r0 = _v_19;
    r1 = _v_20;
    r2 = _v_21;
    r3 = _v_22;
    r4 = _v_23;
    r5 = _v_24;
    r6 = _v_25;
    r7 = _v_26;
    r8 = _v_27;
    r9 = _v_28;
    r10 = _v_29;
    r11 = _v_30;
    r12 = _v_31;
    r13 = _v_32;
    r14 = _v_33;
    r15 = _v_34;
    r16 = _v_35;
    r17 = _v_36;
    r18 = _v_37;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STATE_COMMAND)
  {
    u32 _namespace_0 = r0;
    u32 _tick_0 = r1;
    u32 _command_0 = r2;
    u32 _command_1 = r3;
    Term _command_2 = r4;
    Term _command_3 = r5;
    u32 _command_4 = r6;
    Term _command_5 = r7;
    u32 _command_6 = r8;
    Term _command_7 = r9;
    u32 _state_0 = r10;
    Term _state_1 = r11;
    Term _state_2 = r12;
    Term _state_3 = r13;
    Term _state_4 = r14;
    Term _state_5 = r15;
    Term _state_6 = r16;
    u32 _state_7 = r17;
    Term _state_8 = r18;
    u32 _state_9 = r19;
    Term _state_10 = r20;
    u32 _state_11 = r21;
    Term _state_12 = r22;
    u32 _state_13 = r23;
    Term _state_14 = r24;
    u32 _state_15 = r25;
    Term _state_16 = r26;
    u32 _state_17 = r27;
    u32 _state_18 = r28;
    Term _state_19 = r29;
    Term _state_20 = r30;
    WL_OPEN
    if (_state_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _state_10;
        STK(1) = FID_COMMANDS_STATE_COMMAND_K82;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_STATE_COMMAND_K82, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _state_10;
        WL_CONT = term_tsk(FID_COMMANDS_STATE_COMMAND_K82, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_STEP)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_STEP, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _namespace_0;
        e.mem[_t_1 + 1] = _tick_0;
        e.mem[_t_1 + 2] = _state_1;
        e.mem[_t_1 + 3] = _state_2;
        e.mem[_t_1 + 4] = _state_3;
        e.mem[_t_1 + 5] = _state_4;
        e.mem[_t_1 + 6] = _state_5;
        e.mem[_t_1 + 7] = _state_6;
        e.mem[_t_1 + 8] = _state_7;
        e.mem[_t_1 + 9] = _state_8;
        e.mem[_t_1 + 10] = _state_9;
        e.mem[_t_1 + 11] = _command_0;
        e.mem[_t_1 + 12] = _command_1;
        e.mem[_t_1 + 13] = _command_2;
        e.mem[_t_1 + 14] = _command_3;
        e.mem[_t_1 + 15] = _command_4;
        e.mem[_t_1 + 16] = _command_5;
        e.mem[_t_1 + 17] = _command_6;
        e.mem[_t_1 + 18] = _command_7;
        return term_tsk(FID_COMMANDS_STEP, _t_1);
      }
      r0 = _namespace_0;
      r1 = _tick_0;
      r2 = _state_1;
      r3 = _state_2;
      r4 = _state_3;
      r5 = _state_4;
      r6 = _state_5;
      r7 = _state_6;
      r8 = _state_7;
      r9 = _state_8;
      r10 = _state_9;
      r11 = _command_0;
      r12 = _command_1;
      r13 = _command_2;
      r14 = _command_3;
      r15 = _command_4;
      r16 = _command_5;
      r17 = _command_6;
      r18 = _command_7;
      WL_JMP(FID_COMMANDS_STEP);
    } else {
      Term _b_0 = 0;
      if (_command_0 == 0) {
        u64 _nd_1 = heap_alloc(e, cls_fit(7));
        e.mem[_nd_1 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _command_2);
        e.mem[_nd_1 + 2] = rfc_seal(e, _command_3);
        e.mem[_nd_1 + 3] = rfc_seal(e, _command_4);
        e.mem[_nd_1 + 4] = rfc_seal(e, _command_5);
        e.mem[_nd_1 + 5] = rfc_seal(e, _command_6);
        e.mem[_nd_1 + 6] = rfc_seal(e, _command_7);
        _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
      } else if (_command_0 == 1) {
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_2 + 1] = rfc_seal(e, _command_2);
        _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
      } else if (_command_0 == 2) {
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_3 + 1] = rfc_seal(e, _command_2);
        _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
      } else if (_command_0 == 3) {
        _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _command_1);
      } else if (_command_0 == 4) {
        _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _command_1);
      } else {
        _b_0 = term_pak(CID_STORAGE_DESPAWN, _command_1);
      }
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_4 + 1] = rfc_seal(e, _state_19);
      r0 = 1;
      r1 = _state_1;
      r2 = _state_2;
      r3 = _state_3;
      r4 = _state_4;
      r5 = _state_5;
      r6 = _state_6;
      r7 = _state_7;
      r8 = _state_8;
      r9 = _state_9;
      r10 = _state_10;
      r11 = _state_11;
      r12 = _state_12;
      r13 = _state_13;
      r14 = _state_14;
      r15 = _state_15;
      r16 = _state_16;
      r17 = _state_17;
      r18 = _state_18;
      r19 = term_ctr(CID_CON, _nd_4);
      r20 = _state_20;
      WL_RETN(21);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STATE_COMMAND_K82)
  {
    WL_POPN(1);
    Term _state_21 = STK(0);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_3[21];
    if (spin_55(e, _o_3, _state_21, blk_loc(e.mem, _state_21), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18) == 0) {
      return 0;
    }
    _v_0 = _o_3[0];
    _v_1 = _o_3[1];
    _v_2 = _o_3[2];
    _v_3 = _o_3[3];
    _v_4 = _o_3[4];
    _v_5 = _o_3[5];
    _v_6 = _o_3[6];
    _v_7 = _o_3[7];
    _v_8 = _o_3[8];
    _v_9 = _o_3[9];
    _v_10 = _o_3[10];
    _v_11 = _o_3[11];
    _v_12 = _o_3[12];
    _v_13 = _o_3[13];
    _v_14 = _o_3[14];
    _v_15 = _o_3[15];
    _v_16 = _o_3[16];
    _v_17 = _o_3[17];
    _v_18 = _o_3[18];
    _v_19 = _o_3[19];
    _v_20 = _o_3[20];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_47(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = _value_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K87;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K87, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      e.mem[_t_0 + 2] = _value_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K87, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K87)
  {
    WL_POPN(3);
    u32 _value_4 = STK(0);
    u32 _value_5 = STK(1);
    u32 _value_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_5;
      STK(1) = _value_6;
      STK(2) = _h_0;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K88;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K88, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_5;
      e.mem[_t_2 + 1] = _value_6;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K88, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K88)
  {
    WL_POPN(3);
    u32 _value_7 = STK(0);
    u32 _value_8 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_8;
      STK(1) = _h_2;
      STK(2) = _h_1;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K89;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K89, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_8;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_1;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K89, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_7;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _value_7;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K89)
  {
    WL_POPN(3);
    u32 _value_9 = STK(0);
    Term _h_4 = STK(1);
    Term _h_5 = STK(2);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_HOST_RENDER_RENDER_FOUR_K90;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_HOST_RENDER_RENDER_FOUR_K90, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_FOUR_K90, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_9;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _value_9;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_FOUR_K90)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 32));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 28));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_9);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 22));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_8);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 16));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_7);
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_5));
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 10));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
    Term _v_0 = 0;
    Term _o_3[1];
    Term _a_1 = term_ctr(CID_CON, _nd_7);
    if (spin_58(e, _o_3, _a_1, blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_0 = _o_3[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_GO_0)
  {
    Term _a_0 = r0;
    Term _acc_0 = r1;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_a_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _a_0), 0 + 0);
      blk_free(e, _a_0);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _c_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_CON, _nd_0);
      WL_RETN(1);
    } else {
      Term _h_0 = blk_half(e, _a_0, 0);
      Term _h_1 = blk_half(e, _a_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_0;
        STK(1) = FID_ARRAY_TO_LIST_GO_0_K92;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_ARRAY_TO_LIST_GO_0_K92, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _h_0;
        WL_CONT = term_tsk(FID_ARRAY_TO_LIST_GO_0_K92, _t_0);
        WL_IDX = 1;
      }
      r0 = _h_1;
      r1 = _acc_0;
      _a_0 = r0;
      _acc_0 = r1;
      WL_AGAIN(FID_ARRAY_TO_LIST_GO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_GO_0_K92)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_GO_0)) {
      u64 _t_1 = task_node(e, FID_ARRAY_TO_LIST_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _h_3;
      e.mem[_t_1 + 1] = _h_2;
      return term_tsk(FID_ARRAY_TO_LIST_GO_0, _t_1);
    }
    r0 = _h_3;
    r1 = _h_2;
    WL_JMP(FID_ARRAY_TO_LIST_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16)
  {
    Term _values_0 = r0;
    Term _acc_0 = r1;
    u32 _first_0 = r2;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_1[1];
      if (spin_60(e, _o_1, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_0 = _o_1[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _values_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_3;
        STK(1) = _acc_0;
        STK(2) = _first_0;
        STK(3) = FID_HOST_RENDER_RENDER_LIST_TAIL_16_K94;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16_K94, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        e.mem[_t_0 + 1] = _acc_0;
        e.mem[_t_0 + 2] = _first_0;
        WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K94, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_2;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_TAIL_16_K94)
  {
    WL_POPN(3);
    Term _f_4 = STK(0);
    Term _acc_2 = STK(1);
    u32 _first_1 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_2[1];
    if (spin_62(e, _o_2, _h_0, blk_loc(e.mem, _h_0), _acc_2, blk_loc(e.mem, _acc_2), _first_1) == 0) {
      return 0;
    }
    _v_5 = _o_2[0];
    _v_4 = _v_5;
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_4;
      e.mem[_t_2 + 1] = _v_4;
      e.mem[_t_2 + 2] = 0;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_2);
    }
    r0 = _f_4;
    r1 = _v_4;
    r2 = 0;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_BATCH)
  {
    Term _commands_0 = r0;
    u32 _namespace_0 = r1;
    u32 _tick_0 = r2;
    u32 _state_0 = r3;
    Term _state_1 = r4;
    Term _state_2 = r5;
    Term _state_3 = r6;
    Term _state_4 = r7;
    Term _state_5 = r8;
    Term _state_6 = r9;
    u32 _state_7 = r10;
    Term _state_8 = r11;
    u32 _state_9 = r12;
    Term _state_10 = r13;
    u32 _state_11 = r14;
    Term _state_12 = r15;
    u32 _state_13 = r16;
    Term _state_14 = r17;
    u32 _state_15 = r18;
    Term _state_16 = r19;
    u32 _state_17 = r20;
    u32 _state_18 = r21;
    Term _state_19 = r22;
    Term _state_20 = r23;
    WL_OPEN
    if (term_aux(_commands_0) == CID_NIL) {
      u32 _v_0 = 0;
      Term _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      u32 _v_7 = 0;
      Term _v_8 = 0;
      u32 _v_9 = 0;
      Term _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      u32 _v_13 = 0;
      Term _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _o_2[21];
      if (spin_71(e, _o_2, _state_0, _state_1, blk_loc(e.mem, _state_1), _state_2, blk_loc(e.mem, _state_2), _state_3, blk_loc(e.mem, _state_3), _state_4, blk_loc(e.mem, _state_4), _state_5, blk_loc(e.mem, _state_5), _state_6, blk_loc(e.mem, _state_6), _state_7, _state_8, _state_9, _state_10, blk_loc(e.mem, _state_10), _state_11, _state_12, blk_loc(e.mem, _state_12), _state_13, _state_14, blk_loc(e.mem, _state_14), _state_15, _state_16, blk_loc(e.mem, _state_16), _state_17, _state_18, _state_19, blk_loc(e.mem, _state_19), _state_20, blk_loc(e.mem, _state_20)) == 0) {
        return 0;
      }
      _v_0 = _o_2[0];
      _v_1 = _o_2[1];
      _v_2 = _o_2[2];
      _v_3 = _o_2[3];
      _v_4 = _o_2[4];
      _v_5 = _o_2[5];
      _v_6 = _o_2[6];
      _v_7 = _o_2[7];
      _v_8 = _o_2[8];
      _v_9 = _o_2[9];
      _v_10 = _o_2[10];
      _v_11 = _o_2[11];
      _v_12 = _o_2[12];
      _v_13 = _o_2[13];
      _v_14 = _o_2[14];
      _v_15 = _o_2[15];
      _v_16 = _o_2[16];
      _v_17 = _o_2[17];
      _v_18 = _o_2[18];
      _v_19 = _o_2[19];
      _v_20 = _o_2[20];
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      WL_RETN(21);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_3 = 0;
      u32 _o_4 = 0;
      Term _o_5 = 0;
      Term _o_6 = 0;
      u32 _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      if (term_aux(_f_0) == CID_STORAGE_SPAWN) {
        _o_3 = 0;
        Term _fb_1[7];
        u64 _sp_1 = ctr_take(e, _f_0, 7, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        u32 _f_7 = _fb_1[5];
        Term _f_8 = _fb_1[6];
        spare_free(e, cls_fit(7), _sp_1);
        _o_4 = _f_2;
        _o_5 = _f_3;
        _o_6 = _f_4;
        _o_7 = _f_5;
        _o_8 = _f_6;
        _o_9 = _f_7;
        _o_10 = _f_8;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTMAIN) {
        _o_3 = 1;
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _f_0, 2, _fb_2);
        u32 _f_9 = _fb_2[0];
        Term _f_10 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        _o_4 = _f_9;
        _o_5 = _f_10;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTFLAG) {
        _o_3 = 2;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_0, 2, _fb_3);
        u32 _f_11 = _fb_3[0];
        Term _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_4 = _f_11;
        _o_5 = _f_12;
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEMAIN) {
        _o_3 = 3;
        _o_4 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEFLAG) {
        _o_3 = 4;
        _o_4 = term_loc(_f_0);
      } else {
        _o_3 = 5;
        _o_4 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _namespace_0;
        STK(2) = _tick_0;
        STK(3) = FID_COMMANDS_BATCH_K105;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_BATCH_K105, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _namespace_0;
        e.mem[_t_0 + 2] = _tick_0;
        WL_CONT = term_tsk(FID_COMMANDS_BATCH_K105, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_STATE_COMMAND)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_STATE_COMMAND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _namespace_0;
        e.mem[_t_1 + 1] = _tick_0;
        e.mem[_t_1 + 2] = _o_3;
        e.mem[_t_1 + 3] = _o_4;
        e.mem[_t_1 + 4] = _o_5;
        e.mem[_t_1 + 5] = _o_6;
        e.mem[_t_1 + 6] = _o_7;
        e.mem[_t_1 + 7] = _o_8;
        e.mem[_t_1 + 8] = _o_9;
        e.mem[_t_1 + 9] = _o_10;
        e.mem[_t_1 + 10] = _state_0;
        e.mem[_t_1 + 11] = _state_1;
        e.mem[_t_1 + 12] = _state_2;
        e.mem[_t_1 + 13] = _state_3;
        e.mem[_t_1 + 14] = _state_4;
        e.mem[_t_1 + 15] = _state_5;
        e.mem[_t_1 + 16] = _state_6;
        e.mem[_t_1 + 17] = _state_7;
        e.mem[_t_1 + 18] = _state_8;
        e.mem[_t_1 + 19] = _state_9;
        e.mem[_t_1 + 20] = _state_10;
        e.mem[_t_1 + 21] = _state_11;
        e.mem[_t_1 + 22] = _state_12;
        e.mem[_t_1 + 23] = _state_13;
        e.mem[_t_1 + 24] = _state_14;
        e.mem[_t_1 + 25] = _state_15;
        e.mem[_t_1 + 26] = _state_16;
        e.mem[_t_1 + 27] = _state_17;
        e.mem[_t_1 + 28] = _state_18;
        e.mem[_t_1 + 29] = _state_19;
        e.mem[_t_1 + 30] = _state_20;
        return term_tsk(FID_COMMANDS_STATE_COMMAND, _t_1);
      }
      r0 = _namespace_0;
      r1 = _tick_0;
      r2 = _o_3;
      r3 = _o_4;
      r4 = _o_5;
      r5 = _o_6;
      r6 = _o_7;
      r7 = _o_8;
      r8 = _o_9;
      r9 = _o_10;
      r10 = _state_0;
      r11 = _state_1;
      r12 = _state_2;
      r13 = _state_3;
      r14 = _state_4;
      r15 = _state_5;
      r16 = _state_6;
      r17 = _state_7;
      r18 = _state_8;
      r19 = _state_9;
      r20 = _state_10;
      r21 = _state_11;
      r22 = _state_12;
      r23 = _state_13;
      r24 = _state_14;
      r25 = _state_15;
      r26 = _state_16;
      r27 = _state_17;
      r28 = _state_18;
      r29 = _state_19;
      r30 = _state_20;
      WL_JMP(FID_COMMANDS_STATE_COMMAND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_BATCH_K105)
  {
    WL_POPN(3);
    Term _f_13 = STK(0);
    u32 _namespace_1 = STK(1);
    u32 _tick_1 = STK(2);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_BATCH)) {
      u64 _t_2 = task_node(e, FID_COMMANDS_BATCH, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_13;
      e.mem[_t_2 + 1] = _namespace_1;
      e.mem[_t_2 + 2] = _tick_1;
      e.mem[_t_2 + 3] = _h_0;
      e.mem[_t_2 + 4] = _h_1;
      e.mem[_t_2 + 5] = _h_2;
      e.mem[_t_2 + 6] = _h_3;
      e.mem[_t_2 + 7] = _h_4;
      e.mem[_t_2 + 8] = _h_5;
      e.mem[_t_2 + 9] = _h_6;
      e.mem[_t_2 + 10] = _h_7;
      e.mem[_t_2 + 11] = _h_8;
      e.mem[_t_2 + 12] = _h_9;
      e.mem[_t_2 + 13] = _h_10;
      e.mem[_t_2 + 14] = _h_11;
      e.mem[_t_2 + 15] = _h_12;
      e.mem[_t_2 + 16] = _h_13;
      e.mem[_t_2 + 17] = _h_14;
      e.mem[_t_2 + 18] = _h_15;
      e.mem[_t_2 + 19] = _h_16;
      e.mem[_t_2 + 20] = _h_17;
      e.mem[_t_2 + 21] = _h_18;
      e.mem[_t_2 + 22] = _h_19;
      e.mem[_t_2 + 23] = _h_20;
      return term_tsk(FID_COMMANDS_BATCH, _t_2);
    }
    r0 = _f_13;
    r1 = _namespace_1;
    r2 = _tick_1;
    r3 = _h_0;
    r4 = _h_1;
    r5 = _h_2;
    r6 = _h_3;
    r7 = _h_4;
    r8 = _h_5;
    r9 = _h_6;
    r10 = _h_7;
    r11 = _h_8;
    r12 = _h_9;
    r13 = _h_10;
    r14 = _h_11;
    r15 = _h_12;
    r16 = _h_13;
    r17 = _h_14;
    r18 = _h_15;
    r19 = _h_16;
    r20 = _h_17;
    r21 = _h_18;
    r22 = _h_19;
    r23 = _h_20;
    WL_JMP(FID_COMMANDS_BATCH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_4;
      STK(1) = FID_HOST_RENDER_RENDER_LEDGER_K108;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER_K108, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LEDGER_K108, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER_K108)
  {
    WL_POPN(1);
    u32 _value_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_LEDGER_K109;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER_K109, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LEDGER_K109, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_5;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_5;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LEDGER_K109)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 32));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 64));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 50));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_3);
    if (spin_58(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_47(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_4;
      STK(1) = FID_HOST_RENDER_RENDER_POSITION_K112;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_POSITION_K112, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_4;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_POSITION_K112, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_FOUR)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_FOUR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID_HOST_RENDER_RENDER_FOUR, _t_1);
    }
    r0 = _value_0;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID_HOST_RENDER_RENDER_FOUR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION_K112)
  {
    WL_POPN(1);
    u32 _value_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_HOST_RENDER_RENDER_POSITION_K113;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_HOST_RENDER_RENDER_POSITION_K113, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_POSITION_K113, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_5;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _value_5;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_POSITION_K113)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 32));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 102));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 88));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = term_ctr(CID_CON, _nd_3);
    if (spin_58(e, _o_0, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARRAY_TO_LIST_0)
  {
    Term _a_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_GO_0)) {
      u64 _t_0 = task_node(e, FID_ARRAY_TO_LIST_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _a_0;
      e.mem[_t_0 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_ARRAY_TO_LIST_GO_0, _t_0);
    }
    r0 = _a_0;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_ARRAY_TO_LIST_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DATA)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_DATA_K116;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_DATA_K116, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_DATA_K116, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _values_0 = r0;
      WL_AGAIN(FID_DATA);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DATA_K116)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_HOST_RENDER_RENDER_LIST_16_K118;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16_K118, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_HOST_RENDER_RENDER_LIST_16_K118, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_TAIL_16)) {
      u64 _t_1 = task_node(e, FID_HOST_RENDER_RENDER_LIST_TAIL_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _values_0;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = 1;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_TAIL_16, _t_1);
    }
    r0 = _values_0;
    r1 = term_pak(CID_NIL, 0);
    r2 = 1;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_TAIL_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HOST_RENDER_RENDER_LIST_16_K118)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_58(e, _o_0, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_ctr(CID_CON, STAT_OFF + 108));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 104));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    Term _v_2 = 0;
    Term _o_1[1];
    Term _a_0 = term_ctr(CID_CON, _nd_1);
    if (spin_58(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 34);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K121;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K121, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K121, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K121)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY)
  {
    Term _depth_0 = r0;
    WL_OPEN
    WL_SPIN
    if (_depth_0 == 0) {
      Term _fv_0[2];
      _fv_0[0] = 0;
      _fv_0[1] = 0;
      r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
      WL_RETN(1);
    } else {
      Term _d_0 = (_depth_0 - 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _d_0;
        STK(1) = FID_STORAGE_SLOTS_EMPTY_K190;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K190, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _d_0;
        WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K190, _t_0);
        WL_IDX = 1;
      }
      r0 = _d_0;
      _depth_0 = r0;
      WL_AGAIN(FID_STORAGE_SLOTS_EMPTY);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K190)
  {
    WL_POPN(1);
    Term _d_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_STORAGE_SLOTS_EMPTY_K191;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K191, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_2 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _d_1;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_2);
    }
    r0 = _d_1;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K191)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_2, _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _main_0 = r17;
    WL_OPEN
    Term _build_0 = term_clo(FID_COMMANDS_INSERT_MAIN_C194, 0);
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _build_0);
      r0 = 1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _world_2;
      r4 = _world_3;
      r5 = _world_4;
      r6 = _world_5;
      r7 = _world_6;
      r8 = _world_7;
      r9 = _world_8;
      r10 = _world_9;
      r11 = _world_10;
      r12 = _world_11;
      r13 = _world_12;
      r14 = _world_13;
      r15 = _world_14;
      r16 = _main_0;
      WL_RETN(17);
    } else {
      if (seq) {
        WL_ROOM(17);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_2;
        STK(3) = _world_3;
        STK(4) = _world_4;
        STK(5) = _world_5;
        STK(6) = _world_6;
        STK(7) = _world_7;
        STK(8) = _world_8;
        STK(9) = _world_9;
        STK(10) = _world_10;
        STK(11) = _world_11;
        STK(12) = _world_12;
        STK(13) = _world_13;
        STK(14) = _world_14;
        STK(15) = _main_0;
        STK(16) = FID_COMMANDS_INSERT_MAIN_K196;
        WL_PUSHN(17);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_INSERT_MAIN_K196, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_2;
        e.mem[_t_0 + 3] = _world_3;
        e.mem[_t_0 + 4] = _world_4;
        e.mem[_t_0 + 5] = _world_5;
        e.mem[_t_0 + 6] = _world_6;
        e.mem[_t_0 + 7] = _world_7;
        e.mem[_t_0 + 8] = _world_8;
        e.mem[_t_0 + 9] = _world_9;
        e.mem[_t_0 + 10] = _world_10;
        e.mem[_t_0 + 11] = _world_11;
        e.mem[_t_0 + 12] = _world_12;
        e.mem[_t_0 + 13] = _world_13;
        e.mem[_t_0 + 14] = _world_14;
        e.mem[_t_0 + 15] = _main_0;
        WL_CONT = term_tsk(FID_COMMANDS_INSERT_MAIN_K196, _t_0);
        WL_IDX = 16;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _build_0;
        e.mem[_t_1 + 1] = _handle_1;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _build_0;
      r1 = _handle_1;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_C194)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_INSERT_MAIN_C195, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_C195)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_80(e, _o_0, _x_2, _x_1, blk_loc(e.mem, _x_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_K196)
  {
    WL_POPN(16);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    Term _world_22 = STK(7);
    u32 _world_23 = STK(8);
    Term _world_24 = STK(9);
    u32 _world_25 = STK(10);
    Term _world_26 = STK(11);
    u32 _world_27 = STK(12);
    Term _world_28 = STK(13);
    Term _world_29 = STK(14);
    Term _main_2 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _world_15;
      STK(1) = _world_16;
      STK(2) = _world_17;
      STK(3) = _world_18;
      STK(4) = _world_19;
      STK(5) = _world_20;
      STK(6) = _world_21;
      STK(7) = _world_22;
      STK(8) = _world_23;
      STK(9) = _world_24;
      STK(10) = _world_25;
      STK(11) = _world_26;
      STK(12) = _world_27;
      STK(13) = _world_28;
      STK(14) = _world_29;
      STK(15) = FID_COMMANDS_INSERT_MAIN_K197;
      WL_PUSHN(16);
    } else {
      u64 _t_2 = task_node(e, FID_COMMANDS_INSERT_MAIN_K197, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _world_15;
      e.mem[_t_2 + 1] = _world_16;
      e.mem[_t_2 + 2] = _world_17;
      e.mem[_t_2 + 3] = _world_18;
      e.mem[_t_2 + 4] = _world_19;
      e.mem[_t_2 + 5] = _world_20;
      e.mem[_t_2 + 6] = _world_21;
      e.mem[_t_2 + 7] = _world_22;
      e.mem[_t_2 + 8] = _world_23;
      e.mem[_t_2 + 9] = _world_24;
      e.mem[_t_2 + 10] = _world_25;
      e.mem[_t_2 + 11] = _world_26;
      e.mem[_t_2 + 12] = _world_27;
      e.mem[_t_2 + 13] = _world_28;
      e.mem[_t_2 + 14] = _world_29;
      WL_CONT = term_tsk(FID_COMMANDS_INSERT_MAIN_K197, _t_2);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _main_2;
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _h_0;
    r1 = _main_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_K197)
  {
    WL_POPN(15);
    u32 _world_30 = STK(0);
    u32 _world_31 = STK(1);
    Term _world_32 = STK(2);
    Term _world_33 = STK(3);
    Term _world_34 = STK(4);
    Term _world_35 = STK(5);
    Term _world_36 = STK(6);
    Term _world_37 = STK(7);
    u32 _world_38 = STK(8);
    Term _world_39 = STK(9);
    u32 _world_40 = STK(10);
    Term _world_41 = STK(11);
    u32 _world_42 = STK(12);
    Term _world_43 = STK(13);
    Term _world_44 = STK(14);
    Term _h_1 = r0;
    WL_OPEN
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _o_1[15];
    Term _a_0 = term_ctr(CID_CON, _nd_4);
    if (spin_64(e, _o_1, _world_30, _world_31, _world_32, blk_loc(e.mem, _world_32), _world_33, blk_loc(e.mem, _world_33), _world_34, blk_loc(e.mem, _world_34), _world_35, blk_loc(e.mem, _world_35), _world_36, blk_loc(e.mem, _world_36), _world_37, blk_loc(e.mem, _world_37), _world_38, _world_39, _world_40, _world_41, blk_loc(e.mem, _world_41), _world_42, _world_43, blk_loc(e.mem, _world_43), _world_44, blk_loc(e.mem, _world_44), _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_31 = _o_1[0];
    _v_32 = _o_1[1];
    _v_33 = _o_1[2];
    _v_34 = _o_1[3];
    _v_35 = _o_1[4];
    _v_36 = _o_1[5];
    _v_37 = _o_1[6];
    _v_38 = _o_1[7];
    _v_39 = _o_1[8];
    _v_40 = _o_1[9];
    _v_41 = _o_1[10];
    _v_42 = _o_1[11];
    _v_43 = _o_1[12];
    _v_44 = _o_1[13];
    _v_45 = _o_1[14];
    _v_16 = _v_31;
    _v_17 = _v_32;
    _v_18 = _v_33;
    _v_19 = _v_34;
    _v_20 = _v_35;
    _v_21 = _v_36;
    _v_22 = _v_37;
    _v_23 = _v_38;
    _v_24 = _v_39;
    _v_25 = _v_40;
    _v_26 = _v_41;
    _v_27 = _v_42;
    _v_28 = _v_43;
    _v_29 = _v_44;
    _v_30 = _v_45;
    r0 = 0;
    r1 = _v_16;
    r2 = _v_17;
    r3 = _v_18;
    r4 = _v_19;
    r5 = _v_20;
    r6 = _v_21;
    r7 = _v_22;
    r8 = _v_23;
    r9 = _v_24;
    r10 = _v_25;
    r11 = _v_26;
    r12 = _v_27;
    r13 = _v_28;
    r14 = _v_29;
    r15 = _v_30;
    r16 = 0;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_APPLY_CHECKED)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _tick_0 = r15;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_1[11];
    if (spin_82(e, _o_1, _world_11, blk_loc(e.mem, _world_11), _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    _v_14 = _o_1[3];
    _v_15 = _o_1[4];
    _v_16 = _o_1[5];
    _v_17 = _o_1[6];
    _v_18 = _o_1[7];
    _v_19 = _o_1[8];
    _v_20 = _o_1[9];
    _v_21 = _o_1[10];
    _v_0 = _v_11;
    _v_1 = _v_12;
    _v_2 = _v_13;
    _v_3 = _v_14;
    _v_4 = _v_15;
    _v_5 = _v_16;
    _v_6 = _v_17;
    _v_7 = _v_18;
    _v_8 = _v_19;
    _v_9 = _v_20;
    _v_10 = _v_21;
    if (_v_10 == 0) {
      r0 = 1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _v_0;
      r4 = _v_1;
      r5 = _v_2;
      r6 = _v_3;
      r7 = _v_4;
      r8 = _v_5;
      r9 = _v_6;
      r10 = _v_7;
      r11 = _v_8;
      r12 = _v_9;
      r13 = _world_12;
      r14 = _world_13;
      r15 = _world_14;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      WL_RETN(26);
    } else {
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_2[1];
      if (spin_65(e, _o_2, _v_9, blk_loc(e.mem, _v_9)) == 0) {
        return 0;
      }
      _v_45 = _o_2[0];
      _v_44 = _v_45;
      if (seq) {
        WL_ROOM(6);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_12;
        STK(3) = _world_13;
        STK(4) = _world_14;
        STK(5) = FID_COMMANDS_APPLY_CHECKED_K201;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_APPLY_CHECKED_K201, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_12;
        e.mem[_t_0 + 3] = _world_13;
        e.mem[_t_0 + 4] = _world_14;
        WL_CONT = term_tsk(FID_COMMANDS_APPLY_CHECKED_K201, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_BATCH)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_BATCH, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_44;
        e.mem[_t_1 + 1] = _world_0;
        e.mem[_t_1 + 2] = _tick_0;
        e.mem[_t_1 + 3] = 0;
        e.mem[_t_1 + 4] = _v_0;
        e.mem[_t_1 + 5] = _v_1;
        e.mem[_t_1 + 6] = _v_2;
        e.mem[_t_1 + 7] = _v_3;
        e.mem[_t_1 + 8] = _v_4;
        e.mem[_t_1 + 9] = _v_5;
        e.mem[_t_1 + 10] = _v_6;
        e.mem[_t_1 + 11] = _v_7;
        e.mem[_t_1 + 12] = _v_8;
        e.mem[_t_1 + 13] = term_pak(CID_NIL, 0);
        e.mem[_t_1 + 14] = 0;
        e.mem[_t_1 + 15] = 0;
        e.mem[_t_1 + 16] = 0;
        e.mem[_t_1 + 17] = 0;
        e.mem[_t_1 + 18] = 0;
        e.mem[_t_1 + 19] = 0;
        e.mem[_t_1 + 20] = 0;
        e.mem[_t_1 + 21] = 0;
        e.mem[_t_1 + 22] = 0;
        e.mem[_t_1 + 23] = 0;
        return term_tsk(FID_COMMANDS_BATCH, _t_1);
      }
      r0 = _v_44;
      r1 = _world_0;
      r2 = _tick_0;
      r3 = 0;
      r4 = _v_0;
      r5 = _v_1;
      r6 = _v_2;
      r7 = _v_3;
      r8 = _v_4;
      r9 = _v_5;
      r10 = _v_6;
      r11 = _v_7;
      r12 = _v_8;
      r13 = term_pak(CID_NIL, 0);
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      WL_JMP(FID_COMMANDS_BATCH);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_APPLY_CHECKED_K201)
  {
    WL_POPN(5);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    u32 _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    WL_OPEN
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _o_3[26];
    if (spin_77(e, _o_3, _world_15, _world_16, _world_17, _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_46 = _o_3[0];
    _v_47 = _o_3[1];
    _v_48 = _o_3[2];
    _v_49 = _o_3[3];
    _v_50 = _o_3[4];
    _v_51 = _o_3[5];
    _v_52 = _o_3[6];
    _v_53 = _o_3[7];
    _v_54 = _o_3[8];
    _v_55 = _o_3[9];
    _v_56 = _o_3[10];
    _v_57 = _o_3[11];
    _v_58 = _o_3[12];
    _v_59 = _o_3[13];
    _v_60 = _o_3[14];
    _v_61 = _o_3[15];
    _v_62 = _o_3[16];
    _v_63 = _o_3[17];
    _v_64 = _o_3[18];
    _v_65 = _o_3[19];
    _v_66 = _o_3[20];
    _v_67 = _o_3[21];
    _v_68 = _o_3[22];
    _v_69 = _o_3[23];
    _v_70 = _o_3[24];
    _v_71 = _o_3[25];
    r0 = _v_46;
    r1 = _v_47;
    r2 = _v_48;
    r3 = _v_49;
    r4 = _v_50;
    r5 = _v_51;
    r6 = _v_52;
    r7 = _v_53;
    r8 = _v_54;
    r9 = _v_55;
    r10 = _v_56;
    r11 = _v_57;
    r12 = _v_58;
    r13 = _v_59;
    r14 = _v_60;
    r15 = _v_61;
    r16 = _v_62;
    r17 = _v_63;
    r18 = _v_64;
    r19 = _v_65;
    r20 = _v_66;
    r21 = _v_67;
    r22 = _v_68;
    r23 = _v_69;
    r24 = _v_70;
    r25 = _v_71;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    u32 _result_2 = r2;
    Term _result_3 = r3;
    Term _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    Term _result_8 = r8;
    u32 _result_9 = r9;
    Term _result_10 = r10;
    u32 _result_11 = r11;
    Term _result_12 = r12;
    u32 _result_13 = r13;
    Term _result_14 = r14;
    u32 _result_15 = r15;
    u32 _result_16 = r16;
    u32 _result_17 = r17;
    u32 _result_18 = r18;
    u32 _result_19 = r19;
    u32 _result_20 = r20;
    u32 _result_21 = r21;
    Term _result_22 = r22;
    u32 _result_23 = r23;
    Term _result_24 = r24;
    u32 _result_25 = r25;
    u32 _result_26 = r26;
    u32 _result_27 = r27;
    u32 _result_28 = r28;
    u32 _result_29 = r29;
    u32 _result_30 = r30;
    u32 _result_31 = r31;
    Term _result_32 = r32;
    u32 _result_33 = r33;
    u32 _result_34 = r34;
    u32 _result_35 = r35;
    u32 _result_36 = r36;
    u32 _result_37 = r37;
    Term _result_38 = r38;
    WL_OPEN
    if (_result_0 == 0) {
      if (term_aux(_result_22) == CID_NIL) {
        u32 _label_0 = 4ull;
        u32 _retained_0 = 999ull;
        u32 _retained_1 = 200ull;
        u32 _retained_2 = 300ull;
        u32 _retained_3 = 400ull;
        u32 _retained_4 = 77ull;
        u32 _s_0 = 1;
        Term _s_1 = 0;
        Term _s_2 = 0;
        Term _s_3 = 0;
        if (_s_0 == 1) {
          if (blk_cls(_result_3) != 1) {
            Term _h_0 = blk_half(e, _result_3, 0);
            Term _h_1 = blk_half(e, _result_3, 1);
            if (blk_cls(_h_0) != 1) {
              Term _h_2 = blk_half(e, _h_0, 0);
              Term _h_3 = blk_half(e, _h_0, 1);
              if (blk_cls(_h_2) == 1) {
                u32 _c_0 = blk_read(e.mem, 1, blk_loc(e.mem, _h_2), 0 + 0);
                Term _c_1 = blk_shr(_h_2) ? blk_keep(e, blk_loc(e.mem, _h_2) + 0 + 1) : e.mem[blk_loc(e.mem, _h_2) + 0 + 1];
                blk_free(e, _h_2);
                u32 _o_0 = 0;
                Term _o_1 = 0;
                u32 _o_2 = 0;
                u32 _o_3 = 0;
                u32 _o_4 = 0;
                u32 _o_5 = 0;
                u32 _o_6 = 0;
                u32 _o_7 = 0;
                if (_c_0 == 0) {
                  _o_0 = 0;
                } else {
                  _o_0 = 1;
                  Term _fb_0[7];
                  u64 _sp_0 = ctr_take(e, _c_1, 7, _fb_0);
                  Term _f_0 = _fb_0[0];
                  u32 _f_1 = _fb_0[1];
                  u32 _f_2 = _fb_0[2];
                  u32 _f_3 = _fb_0[3];
                  u32 _f_4 = _fb_0[4];
                  u32 _f_5 = _fb_0[5];
                  u32 _f_6 = _fb_0[6];
                  spare_free(e, cls_fit(7), _sp_0);
                  _o_1 = _f_0;
                  _o_2 = _f_1;
                  _o_3 = _f_2;
                  _o_4 = _f_3;
                  _o_5 = _f_4;
                  _o_6 = _f_5;
                  _o_7 = _f_6;
                }
                if (_o_0 == 0) {
                  if (blk_cls(_h_3) == 1) {
                    u32 _c_2 = blk_read(e.mem, 1, blk_loc(e.mem, _h_3), 0 + 0);
                    Term _c_3 = blk_shr(_h_3) ? blk_keep(e, blk_loc(e.mem, _h_3) + 0 + 1) : e.mem[blk_loc(e.mem, _h_3) + 0 + 1];
                    blk_free(e, _h_3);
                    u32 _o_8 = 0;
                    Term _o_9 = 0;
                    u32 _o_10 = 0;
                    u32 _o_11 = 0;
                    u32 _o_12 = 0;
                    u32 _o_13 = 0;
                    u32 _o_14 = 0;
                    u32 _o_15 = 0;
                    if (_c_2 == 0) {
                      _o_8 = 0;
                    } else {
                      _o_8 = 1;
                      Term _fb_1[7];
                      u64 _sp_1 = ctr_take(e, _c_3, 7, _fb_1);
                      Term _f_7 = _fb_1[0];
                      u32 _f_8 = _fb_1[1];
                      u32 _f_9 = _fb_1[2];
                      u32 _f_10 = _fb_1[3];
                      u32 _f_11 = _fb_1[4];
                      u32 _f_12 = _fb_1[5];
                      u32 _f_13 = _fb_1[6];
                      spare_free(e, cls_fit(7), _sp_1);
                      _o_9 = _f_7;
                      _o_10 = _f_8;
                      _o_11 = _f_9;
                      _o_12 = _f_10;
                      _o_13 = _f_11;
                      _o_14 = _f_12;
                      _o_15 = _f_13;
                    }
                    if (_o_8 == 0) {
                      if (blk_cls(_h_1) != 1) {
                        Term _h_4 = blk_half(e, _h_1, 0);
                        Term _h_5 = blk_half(e, _h_1, 1);
                        if (blk_cls(_h_4) == 1) {
                          u32 _c_4 = blk_read(e.mem, 1, blk_loc(e.mem, _h_4), 0 + 0);
                          Term _c_5 = blk_shr(_h_4) ? blk_keep(e, blk_loc(e.mem, _h_4) + 0 + 1) : e.mem[blk_loc(e.mem, _h_4) + 0 + 1];
                          blk_free(e, _h_4);
                          u32 _o_16 = 0;
                          Term _o_17 = 0;
                          u32 _o_18 = 0;
                          u32 _o_19 = 0;
                          u32 _o_20 = 0;
                          u32 _o_21 = 0;
                          u32 _o_22 = 0;
                          u32 _o_23 = 0;
                          if (_c_4 == 0) {
                            _o_16 = 0;
                          } else {
                            _o_16 = 1;
                            Term _fb_2[7];
                            u64 _sp_2 = ctr_take(e, _c_5, 7, _fb_2);
                            Term _f_14 = _fb_2[0];
                            u32 _f_15 = _fb_2[1];
                            u32 _f_16 = _fb_2[2];
                            u32 _f_17 = _fb_2[3];
                            u32 _f_18 = _fb_2[4];
                            u32 _f_19 = _fb_2[5];
                            u32 _f_20 = _fb_2[6];
                            spare_free(e, cls_fit(7), _sp_2);
                            _o_17 = _f_14;
                            _o_18 = _f_15;
                            _o_19 = _f_16;
                            _o_20 = _f_17;
                            _o_21 = _f_18;
                            _o_22 = _f_19;
                            _o_23 = _f_20;
                          }
                          if (_o_16 == 1) {
                            if (blk_cls(_h_5) == 1) {
                              u32 _c_6 = blk_read(e.mem, 1, blk_loc(e.mem, _h_5), 0 + 0);
                              Term _c_7 = blk_shr(_h_5) ? blk_keep(e, blk_loc(e.mem, _h_5) + 0 + 1) : e.mem[blk_loc(e.mem, _h_5) + 0 + 1];
                              blk_free(e, _h_5);
                              u32 _o_24 = 0;
                              Term _o_25 = 0;
                              u32 _o_26 = 0;
                              u32 _o_27 = 0;
                              u32 _o_28 = 0;
                              u32 _o_29 = 0;
                              u32 _o_30 = 0;
                              u32 _o_31 = 0;
                              if (_c_6 == 0) {
                                _o_24 = 0;
                              } else {
                                _o_24 = 1;
                                Term _fb_3[7];
                                u64 _sp_3 = ctr_take(e, _c_7, 7, _fb_3);
                                Term _f_21 = _fb_3[0];
                                u32 _f_22 = _fb_3[1];
                                u32 _f_23 = _fb_3[2];
                                u32 _f_24 = _fb_3[3];
                                u32 _f_25 = _fb_3[4];
                                u32 _f_26 = _fb_3[5];
                                u32 _f_27 = _fb_3[6];
                                spare_free(e, cls_fit(7), _sp_3);
                                _o_25 = _f_21;
                                _o_26 = _f_22;
                                _o_27 = _f_23;
                                _o_28 = _f_24;
                                _o_29 = _f_25;
                                _o_30 = _f_26;
                                _o_31 = _f_27;
                              }
                              if (_o_24 == 0) {
                                if (blk_cls(_result_4) != 1) {
                                  Term _h_6 = blk_half(e, _result_4, 0);
                                  Term _h_7 = blk_half(e, _result_4, 1);
                                  if (blk_cls(_h_6) != 1) {
                                    Term _h_8 = blk_half(e, _h_6, 0);
                                    Term _h_9 = blk_half(e, _h_6, 1);
                                    if (blk_cls(_h_8) == 1) {
                                      u32 _c_8 = blk_read(e.mem, 1, blk_loc(e.mem, _h_8), 0 + 0);
                                      Term _c_9 = blk_shr(_h_8) ? blk_keep(e, blk_loc(e.mem, _h_8) + 0 + 1) : e.mem[blk_loc(e.mem, _h_8) + 0 + 1];
                                      blk_free(e, _h_8);
                                      u32 _o_32 = 0;
                                      Term _o_33 = 0;
                                      u32 _o_34 = 0;
                                      if (_c_8 == 0) {
                                        _o_32 = 0;
                                      } else {
                                        _o_32 = 1;
                                        Term _fb_4[2];
                                        u64 _sp_4 = ctr_take(e, _c_9, 2, _fb_4);
                                        Term _f_28 = _fb_4[0];
                                        u32 _f_29 = _fb_4[1];
                                        spare_free(e, cls_fit(2), _sp_4);
                                        _o_33 = _f_28;
                                        _o_34 = _f_29;
                                      }
                                      if (_o_32 == 0) {
                                        if (blk_cls(_h_9) == 1) {
                                          u32 _c_10 = blk_read(e.mem, 1, blk_loc(e.mem, _h_9), 0 + 0);
                                          Term _c_11 = blk_shr(_h_9) ? blk_keep(e, blk_loc(e.mem, _h_9) + 0 + 1) : e.mem[blk_loc(e.mem, _h_9) + 0 + 1];
                                          blk_free(e, _h_9);
                                          u32 _o_35 = 0;
                                          Term _o_36 = 0;
                                          u32 _o_37 = 0;
                                          if (_c_10 == 0) {
                                            _o_35 = 0;
                                          } else {
                                            _o_35 = 1;
                                            Term _fb_5[2];
                                            u64 _sp_5 = ctr_take(e, _c_11, 2, _fb_5);
                                            Term _f_30 = _fb_5[0];
                                            u32 _f_31 = _fb_5[1];
                                            spare_free(e, cls_fit(2), _sp_5);
                                            _o_36 = _f_30;
                                            _o_37 = _f_31;
                                          }
                                          if (_o_35 == 0) {
                                            if (blk_cls(_h_7) != 1) {
                                              Term _h_10 = blk_half(e, _h_7, 0);
                                              Term _h_11 = blk_half(e, _h_7, 1);
                                              if (blk_cls(_h_10) == 1) {
                                                u32 _c_12 = blk_read(e.mem, 1, blk_loc(e.mem, _h_10), 0 + 0);
                                                Term _c_13 = blk_shr(_h_10) ? blk_keep(e, blk_loc(e.mem, _h_10) + 0 + 1) : e.mem[blk_loc(e.mem, _h_10) + 0 + 1];
                                                blk_free(e, _h_10);
                                                u32 _o_38 = 0;
                                                Term _o_39 = 0;
                                                u32 _o_40 = 0;
                                                if (_c_12 == 0) {
                                                  _o_38 = 0;
                                                } else {
                                                  _o_38 = 1;
                                                  Term _fb_6[2];
                                                  u64 _sp_6 = ctr_take(e, _c_13, 2, _fb_6);
                                                  Term _f_32 = _fb_6[0];
                                                  u32 _f_33 = _fb_6[1];
                                                  spare_free(e, cls_fit(2), _sp_6);
                                                  _o_39 = _f_32;
                                                  _o_40 = _f_33;
                                                }
                                                if (_o_38 == 0) {
                                                  if (blk_cls(_h_11) == 1) {
                                                    u32 _c_14 = blk_read(e.mem, 1, blk_loc(e.mem, _h_11), 0 + 0);
                                                    Term _c_15 = blk_shr(_h_11) ? blk_keep(e, blk_loc(e.mem, _h_11) + 0 + 1) : e.mem[blk_loc(e.mem, _h_11) + 0 + 1];
                                                    blk_free(e, _h_11);
                                                    u32 _o_41 = 0;
                                                    Term _o_42 = 0;
                                                    u32 _o_43 = 0;
                                                    if (_c_14 == 0) {
                                                      _o_41 = 0;
                                                    } else {
                                                      _o_41 = 1;
                                                      Term _fb_7[2];
                                                      u64 _sp_7 = ctr_take(e, _c_15, 2, _fb_7);
                                                      Term _f_34 = _fb_7[0];
                                                      u32 _f_35 = _fb_7[1];
                                                      spare_free(e, cls_fit(2), _sp_7);
                                                      _o_42 = _f_34;
                                                      _o_43 = _f_35;
                                                    }
                                                    if (_o_41 == 0) {
                                                      if (blk_cls(_result_5) != 0) {
                                                        Term _h_12 = blk_half(e, _result_5, 0);
                                                        Term _h_13 = blk_half(e, _result_5, 1);
                                                        if (blk_cls(_h_12) != 0) {
                                                          Term _h_14 = blk_half(e, _h_12, 0);
                                                          Term _h_15 = blk_half(e, _h_12, 1);
                                                          if (blk_cls(_h_14) == 0) {
                                                            u32 _c_16 = blk_read(e.mem, 0, blk_loc(e.mem, _h_14), 0 + 0);
                                                            blk_free(e, _h_14);
                                                            if (_c_16 == 0) {
                                                              if (blk_cls(_h_15) == 0) {
                                                                u32 _c_17 = blk_read(e.mem, 0, blk_loc(e.mem, _h_15), 0 + 0);
                                                                blk_free(e, _h_15);
                                                                if (_c_17 == 0) {
                                                                  if (blk_cls(_h_13) != 0) {
                                                                    Term _h_16 = blk_half(e, _h_13, 0);
                                                                    Term _h_17 = blk_half(e, _h_13, 1);
                                                                    if (blk_cls(_h_16) == 0) {
                                                                      u32 _c_18 = blk_read(e.mem, 0, blk_loc(e.mem, _h_16), 0 + 0);
                                                                      blk_free(e, _h_16);
                                                                      if (_c_18 == 1) {
                                                                        if (blk_cls(_h_17) == 0) {
                                                                          u32 _c_19 = blk_read(e.mem, 0, blk_loc(e.mem, _h_17), 0 + 0);
                                                                          blk_free(e, _h_17);
                                                                          if (_c_19 == 0) {
                                                                            if (blk_cls(_result_6) != 1) {
                                                                              Term _h_18 = blk_half(e, _result_6, 0);
                                                                              Term _h_19 = blk_half(e, _result_6, 1);
                                                                              if (blk_cls(_h_18) != 1) {
                                                                                Term _h_20 = blk_half(e, _h_18, 0);
                                                                                Term _h_21 = blk_half(e, _h_18, 1);
                                                                                if (blk_cls(_h_20) == 1) {
                                                                                  u32 _c_20 = blk_read(e.mem, 1, blk_loc(e.mem, _h_20), 0 + 0);
                                                                                  Term _c_21 = blk_shr(_h_20) ? blk_keep(e, blk_loc(e.mem, _h_20) + 0 + 1) : e.mem[blk_loc(e.mem, _h_20) + 0 + 1];
                                                                                  blk_free(e, _h_20);
                                                                                  u32 _o_44 = 0;
                                                                                  u32 _o_45 = 0;
                                                                                  if (_c_20 == 0) {
                                                                                    _o_44 = 0;
                                                                                  } else {
                                                                                    _o_44 = 1;
                                                                                    _o_45 = term_loc(_c_21);
                                                                                  }
                                                                                  if (_o_44 == 0) {
                                                                                    if (blk_cls(_h_21) == 1) {
                                                                                      u32 _c_22 = blk_read(e.mem, 1, blk_loc(e.mem, _h_21), 0 + 0);
                                                                                      Term _c_23 = blk_shr(_h_21) ? blk_keep(e, blk_loc(e.mem, _h_21) + 0 + 1) : e.mem[blk_loc(e.mem, _h_21) + 0 + 1];
                                                                                      blk_free(e, _h_21);
                                                                                      u32 _o_46 = 0;
                                                                                      u32 _o_47 = 0;
                                                                                      if (_c_22 == 0) {
                                                                                        _o_46 = 0;
                                                                                      } else {
                                                                                        _o_46 = 1;
                                                                                        _o_47 = term_loc(_c_23);
                                                                                      }
                                                                                      if (_o_46 == 0) {
                                                                                        if (blk_cls(_h_19) != 1) {
                                                                                          Term _h_22 = blk_half(e, _h_19, 0);
                                                                                          Term _h_23 = blk_half(e, _h_19, 1);
                                                                                          if (blk_cls(_h_22) == 1) {
                                                                                            u32 _c_24 = blk_read(e.mem, 1, blk_loc(e.mem, _h_22), 0 + 0);
                                                                                            Term _c_25 = blk_shr(_h_22) ? blk_keep(e, blk_loc(e.mem, _h_22) + 0 + 1) : e.mem[blk_loc(e.mem, _h_22) + 0 + 1];
                                                                                            blk_free(e, _h_22);
                                                                                            u32 _o_48 = 0;
                                                                                            u32 _o_49 = 0;
                                                                                            if (_c_24 == 0) {
                                                                                              _o_48 = 0;
                                                                                            } else {
                                                                                              _o_48 = 1;
                                                                                              _o_49 = term_loc(_c_25);
                                                                                            }
                                                                                            if (_o_48 == 1) {
                                                                                              if (_o_49 == 55) {
                                                                                                if (blk_cls(_h_23) == 1) {
                                                                                                  u32 _c_26 = blk_read(e.mem, 1, blk_loc(e.mem, _h_23), 0 + 0);
                                                                                                  Term _c_27 = blk_shr(_h_23) ? blk_keep(e, blk_loc(e.mem, _h_23) + 0 + 1) : e.mem[blk_loc(e.mem, _h_23) + 0 + 1];
                                                                                                  blk_free(e, _h_23);
                                                                                                  u32 _o_50 = 0;
                                                                                                  u32 _o_51 = 0;
                                                                                                  if (_c_26 == 0) {
                                                                                                    _o_50 = 0;
                                                                                                  } else {
                                                                                                    _o_50 = 1;
                                                                                                    _o_51 = term_loc(_c_27);
                                                                                                  }
                                                                                                  if (_o_50 == 0) {
                                                                                                    if (term_aux(_result_12) == CID_NIL) {
                                                                                                      if (_result_13 == 1) {
                                                                                                        if (_result_21 == 0) {
                                                                                                          if (seq) {
                                                                                                            WL_ROOM(27);
                                                                                                            STK(0) = _retained_0;
                                                                                                            STK(1) = _retained_1;
                                                                                                            STK(2) = _retained_2;
                                                                                                            STK(3) = _retained_3;
                                                                                                            STK(4) = _retained_4;
                                                                                                            STK(5) = _result_1;
                                                                                                            STK(6) = _result_2;
                                                                                                            STK(7) = _o_17;
                                                                                                            STK(8) = _o_18;
                                                                                                            STK(9) = _o_19;
                                                                                                            STK(10) = _o_20;
                                                                                                            STK(11) = _o_21;
                                                                                                            STK(12) = _o_22;
                                                                                                            STK(13) = _o_23;
                                                                                                            STK(14) = _result_7;
                                                                                                            STK(15) = _result_8;
                                                                                                            STK(16) = _result_9;
                                                                                                            STK(17) = _result_10;
                                                                                                            STK(18) = _result_11;
                                                                                                            STK(19) = _result_14;
                                                                                                            STK(20) = _result_15;
                                                                                                            STK(21) = _result_16;
                                                                                                            STK(22) = _result_17;
                                                                                                            STK(23) = _result_18;
                                                                                                            STK(24) = _result_19;
                                                                                                            STK(25) = _result_20;
                                                                                                            STK(26) = FID_APPLIED_K203;
                                                                                                            WL_PUSHN(27);
                                                                                                          } else {
                                                                                                            u64 _t_0 = task_node(e, FID_APPLIED_K203, WL_CONT, WL_IDX, 1);
                                                                                                            e.mem[_t_0 + 0] = _retained_0;
                                                                                                            e.mem[_t_0 + 1] = _retained_1;
                                                                                                            e.mem[_t_0 + 2] = _retained_2;
                                                                                                            e.mem[_t_0 + 3] = _retained_3;
                                                                                                            e.mem[_t_0 + 4] = _retained_4;
                                                                                                            e.mem[_t_0 + 5] = _result_1;
                                                                                                            e.mem[_t_0 + 6] = _result_2;
                                                                                                            e.mem[_t_0 + 7] = _o_17;
                                                                                                            e.mem[_t_0 + 8] = _o_18;
                                                                                                            e.mem[_t_0 + 9] = _o_19;
                                                                                                            e.mem[_t_0 + 10] = _o_20;
                                                                                                            e.mem[_t_0 + 11] = _o_21;
                                                                                                            e.mem[_t_0 + 12] = _o_22;
                                                                                                            e.mem[_t_0 + 13] = _o_23;
                                                                                                            e.mem[_t_0 + 14] = _result_7;
                                                                                                            e.mem[_t_0 + 15] = _result_8;
                                                                                                            e.mem[_t_0 + 16] = _result_9;
                                                                                                            e.mem[_t_0 + 17] = _result_10;
                                                                                                            e.mem[_t_0 + 18] = _result_11;
                                                                                                            e.mem[_t_0 + 19] = _result_14;
                                                                                                            e.mem[_t_0 + 20] = _result_15;
                                                                                                            e.mem[_t_0 + 21] = _result_16;
                                                                                                            e.mem[_t_0 + 22] = _result_17;
                                                                                                            e.mem[_t_0 + 23] = _result_18;
                                                                                                            e.mem[_t_0 + 24] = _result_19;
                                                                                                            e.mem[_t_0 + 25] = _result_20;
                                                                                                            WL_CONT = term_tsk(FID_APPLIED_K203, _t_0);
                                                                                                            WL_IDX = 26;
                                                                                                          }
                                                                                                          if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
                                                                                                            u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
                                                                                                            e.mem[_t_1 + 0] = _label_0;
                                                                                                            return term_tsk(FID_U32_SHOW, _t_1);
                                                                                                          }
                                                                                                          r0 = _label_0;
                                                                                                          WL_JMP(FID_U32_SHOW);
                                                                                                        } else {
                                                                                                          term_sink(e, _o_17);
                                                                                                          term_sink(e, _result_7);
                                                                                                          term_sink(e, _result_8);
                                                                                                          term_sink(e, _result_14);
                                                                                                          u64 _nd_1 = heap_alloc(e, cls_fit(1));
                                                                                                          e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                          r0 = term_clo(FID_IO_PRINT, _nd_1);
                                                                                                          WL_RETN(1);
                                                                                                        }
                                                                                                      } else {
                                                                                                        term_sink(e, _o_17);
                                                                                                        term_sink(e, _result_7);
                                                                                                        term_sink(e, _result_8);
                                                                                                        term_sink(e, _result_14);
                                                                                                        u64 _nd_2 = heap_alloc(e, cls_fit(1));
                                                                                                        e.mem[_nd_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                        r0 = term_clo(FID_IO_PRINT, _nd_2);
                                                                                                        WL_RETN(1);
                                                                                                      }
                                                                                                    } else {
                                                                                                      term_sink(e, _o_17);
                                                                                                      term_sink(e, _result_7);
                                                                                                      term_sink(e, _result_8);
                                                                                                      term_sink(e, _result_12);
                                                                                                      term_sink(e, _result_14);
                                                                                                      u64 _nd_3 = heap_alloc(e, cls_fit(1));
                                                                                                      e.mem[_nd_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                      r0 = term_clo(FID_IO_PRINT, _nd_3);
                                                                                                      WL_RETN(1);
                                                                                                    }
                                                                                                  } else {
                                                                                                    term_sink(e, _o_17);
                                                                                                    term_sink(e, _result_7);
                                                                                                    term_sink(e, _result_8);
                                                                                                    term_sink(e, _result_12);
                                                                                                    term_sink(e, _result_14);
                                                                                                    u64 _nd_4 = heap_alloc(e, cls_fit(1));
                                                                                                    e.mem[_nd_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                    r0 = term_clo(FID_IO_PRINT, _nd_4);
                                                                                                    WL_RETN(1);
                                                                                                  }
                                                                                                } else {
                                                                                                  term_sink(e, _o_17);
                                                                                                  term_sink(e, _h_23);
                                                                                                  term_sink(e, _result_7);
                                                                                                  term_sink(e, _result_8);
                                                                                                  term_sink(e, _result_12);
                                                                                                  term_sink(e, _result_14);
                                                                                                  u64 _nd_5 = heap_alloc(e, cls_fit(1));
                                                                                                  e.mem[_nd_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                  r0 = term_clo(FID_IO_PRINT, _nd_5);
                                                                                                  WL_RETN(1);
                                                                                                }
                                                                                              } else {
                                                                                                term_sink(e, _o_17);
                                                                                                u32 _108_0 = ((_o_49 >> 0) & 1);
                                                                                                u32 _109_0 = ((_o_49 >> 1) & 1);
                                                                                                u32 _109_1 = ((_o_49 >> 2) & 1);
                                                                                                u32 _109_2 = ((_o_49 >> 3) & 1);
                                                                                                u32 _109_3 = ((_o_49 >> 4) & 1);
                                                                                                u32 _109_4 = ((_o_49 >> 5) & 1);
                                                                                                u32 _109_5 = ((_o_49 >> 6) & 1);
                                                                                                u32 _109_6 = ((_o_49 >> 7) & 1);
                                                                                                u32 _109_7 = ((_o_49 >> 8) & 1);
                                                                                                u32 _109_8 = ((_o_49 >> 9) & 1);
                                                                                                u32 _109_9 = ((_o_49 >> 10) & 1);
                                                                                                u32 _109_10 = ((_o_49 >> 11) & 1);
                                                                                                u32 _109_11 = ((_o_49 >> 12) & 1);
                                                                                                u32 _109_12 = ((_o_49 >> 13) & 1);
                                                                                                u32 _109_13 = ((_o_49 >> 14) & 1);
                                                                                                u32 _109_14 = ((_o_49 >> 15) & 1);
                                                                                                u32 _109_15 = ((_o_49 >> 16) & 1);
                                                                                                u32 _109_16 = ((_o_49 >> 17) & 1);
                                                                                                u32 _109_17 = ((_o_49 >> 18) & 1);
                                                                                                u32 _109_18 = ((_o_49 >> 19) & 1);
                                                                                                u32 _109_19 = ((_o_49 >> 20) & 1);
                                                                                                u32 _109_20 = ((_o_49 >> 21) & 1);
                                                                                                u32 _109_21 = ((_o_49 >> 22) & 1);
                                                                                                u32 _109_22 = ((_o_49 >> 23) & 1);
                                                                                                u32 _109_23 = ((_o_49 >> 24) & 1);
                                                                                                u32 _109_24 = ((_o_49 >> 25) & 1);
                                                                                                u32 _109_25 = ((_o_49 >> 26) & 1);
                                                                                                u32 _109_26 = ((_o_49 >> 27) & 1);
                                                                                                u32 _109_27 = ((_o_49 >> 28) & 1);
                                                                                                u32 _109_28 = ((_o_49 >> 29) & 1);
                                                                                                u32 _109_29 = ((_o_49 >> 30) & 1);
                                                                                                u32 _109_30 = ((_o_49 >> 31) & 1);
                                                                                                term_sink(e, _h_23);
                                                                                                term_sink(e, _result_7);
                                                                                                term_sink(e, _result_8);
                                                                                                term_sink(e, _result_12);
                                                                                                term_sink(e, _result_14);
                                                                                                u64 _nd_6 = heap_alloc(e, cls_fit(1));
                                                                                                e.mem[_nd_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                                r0 = term_clo(FID_IO_PRINT, _nd_6);
                                                                                                WL_RETN(1);
                                                                                              }
                                                                                            } else {
                                                                                              term_sink(e, _o_17);
                                                                                              term_sink(e, _h_23);
                                                                                              term_sink(e, _result_7);
                                                                                              term_sink(e, _result_8);
                                                                                              term_sink(e, _result_12);
                                                                                              term_sink(e, _result_14);
                                                                                              u64 _nd_7 = heap_alloc(e, cls_fit(1));
                                                                                              e.mem[_nd_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                              r0 = term_clo(FID_IO_PRINT, _nd_7);
                                                                                              WL_RETN(1);
                                                                                            }
                                                                                          } else {
                                                                                            term_sink(e, _o_17);
                                                                                            term_sink(e, _h_22);
                                                                                            term_sink(e, _h_23);
                                                                                            term_sink(e, _result_7);
                                                                                            term_sink(e, _result_8);
                                                                                            term_sink(e, _result_12);
                                                                                            term_sink(e, _result_14);
                                                                                            u64 _nd_8 = heap_alloc(e, cls_fit(1));
                                                                                            e.mem[_nd_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                            r0 = term_clo(FID_IO_PRINT, _nd_8);
                                                                                            WL_RETN(1);
                                                                                          }
                                                                                        } else {
                                                                                          term_sink(e, _o_17);
                                                                                          term_sink(e, _h_19);
                                                                                          term_sink(e, _result_7);
                                                                                          term_sink(e, _result_8);
                                                                                          term_sink(e, _result_12);
                                                                                          term_sink(e, _result_14);
                                                                                          u64 _nd_9 = heap_alloc(e, cls_fit(1));
                                                                                          e.mem[_nd_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                          r0 = term_clo(FID_IO_PRINT, _nd_9);
                                                                                          WL_RETN(1);
                                                                                        }
                                                                                      } else {
                                                                                        term_sink(e, _o_17);
                                                                                        term_sink(e, _h_19);
                                                                                        term_sink(e, _result_7);
                                                                                        term_sink(e, _result_8);
                                                                                        term_sink(e, _result_12);
                                                                                        term_sink(e, _result_14);
                                                                                        u64 _nd_10 = heap_alloc(e, cls_fit(1));
                                                                                        e.mem[_nd_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                        r0 = term_clo(FID_IO_PRINT, _nd_10);
                                                                                        WL_RETN(1);
                                                                                      }
                                                                                    } else {
                                                                                      term_sink(e, _o_17);
                                                                                      term_sink(e, _h_21);
                                                                                      term_sink(e, _h_19);
                                                                                      term_sink(e, _result_7);
                                                                                      term_sink(e, _result_8);
                                                                                      term_sink(e, _result_12);
                                                                                      term_sink(e, _result_14);
                                                                                      u64 _nd_11 = heap_alloc(e, cls_fit(1));
                                                                                      e.mem[_nd_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                      r0 = term_clo(FID_IO_PRINT, _nd_11);
                                                                                      WL_RETN(1);
                                                                                    }
                                                                                  } else {
                                                                                    term_sink(e, _o_17);
                                                                                    term_sink(e, _h_21);
                                                                                    term_sink(e, _h_19);
                                                                                    term_sink(e, _result_7);
                                                                                    term_sink(e, _result_8);
                                                                                    term_sink(e, _result_12);
                                                                                    term_sink(e, _result_14);
                                                                                    u64 _nd_12 = heap_alloc(e, cls_fit(1));
                                                                                    e.mem[_nd_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                    r0 = term_clo(FID_IO_PRINT, _nd_12);
                                                                                    WL_RETN(1);
                                                                                  }
                                                                                } else {
                                                                                  term_sink(e, _o_17);
                                                                                  term_sink(e, _h_20);
                                                                                  term_sink(e, _h_21);
                                                                                  term_sink(e, _h_19);
                                                                                  term_sink(e, _result_7);
                                                                                  term_sink(e, _result_8);
                                                                                  term_sink(e, _result_12);
                                                                                  term_sink(e, _result_14);
                                                                                  u64 _nd_13 = heap_alloc(e, cls_fit(1));
                                                                                  e.mem[_nd_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                  r0 = term_clo(FID_IO_PRINT, _nd_13);
                                                                                  WL_RETN(1);
                                                                                }
                                                                              } else {
                                                                                term_sink(e, _o_17);
                                                                                term_sink(e, _h_18);
                                                                                term_sink(e, _h_19);
                                                                                term_sink(e, _result_7);
                                                                                term_sink(e, _result_8);
                                                                                term_sink(e, _result_12);
                                                                                term_sink(e, _result_14);
                                                                                u64 _nd_14 = heap_alloc(e, cls_fit(1));
                                                                                e.mem[_nd_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                                r0 = term_clo(FID_IO_PRINT, _nd_14);
                                                                                WL_RETN(1);
                                                                              }
                                                                            } else {
                                                                              term_sink(e, _o_17);
                                                                              term_sink(e, _result_6);
                                                                              term_sink(e, _result_7);
                                                                              term_sink(e, _result_8);
                                                                              term_sink(e, _result_12);
                                                                              term_sink(e, _result_14);
                                                                              u64 _nd_15 = heap_alloc(e, cls_fit(1));
                                                                              e.mem[_nd_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                              r0 = term_clo(FID_IO_PRINT, _nd_15);
                                                                              WL_RETN(1);
                                                                            }
                                                                          } else {
                                                                            term_sink(e, _o_17);
                                                                            term_sink(e, _result_6);
                                                                            term_sink(e, _result_7);
                                                                            term_sink(e, _result_8);
                                                                            term_sink(e, _result_12);
                                                                            term_sink(e, _result_14);
                                                                            u64 _nd_16 = heap_alloc(e, cls_fit(1));
                                                                            e.mem[_nd_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                            r0 = term_clo(FID_IO_PRINT, _nd_16);
                                                                            WL_RETN(1);
                                                                          }
                                                                        } else {
                                                                          term_sink(e, _o_17);
                                                                          term_sink(e, _h_17);
                                                                          term_sink(e, _result_6);
                                                                          term_sink(e, _result_7);
                                                                          term_sink(e, _result_8);
                                                                          term_sink(e, _result_12);
                                                                          term_sink(e, _result_14);
                                                                          u64 _nd_17 = heap_alloc(e, cls_fit(1));
                                                                          e.mem[_nd_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                          r0 = term_clo(FID_IO_PRINT, _nd_17);
                                                                          WL_RETN(1);
                                                                        }
                                                                      } else {
                                                                        term_sink(e, _o_17);
                                                                        term_sink(e, _h_17);
                                                                        term_sink(e, _result_6);
                                                                        term_sink(e, _result_7);
                                                                        term_sink(e, _result_8);
                                                                        term_sink(e, _result_12);
                                                                        term_sink(e, _result_14);
                                                                        u64 _nd_18 = heap_alloc(e, cls_fit(1));
                                                                        e.mem[_nd_18 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                        r0 = term_clo(FID_IO_PRINT, _nd_18);
                                                                        WL_RETN(1);
                                                                      }
                                                                    } else {
                                                                      term_sink(e, _o_17);
                                                                      term_sink(e, _h_16);
                                                                      term_sink(e, _h_17);
                                                                      term_sink(e, _result_6);
                                                                      term_sink(e, _result_7);
                                                                      term_sink(e, _result_8);
                                                                      term_sink(e, _result_12);
                                                                      term_sink(e, _result_14);
                                                                      u64 _nd_19 = heap_alloc(e, cls_fit(1));
                                                                      e.mem[_nd_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                      r0 = term_clo(FID_IO_PRINT, _nd_19);
                                                                      WL_RETN(1);
                                                                    }
                                                                  } else {
                                                                    term_sink(e, _o_17);
                                                                    term_sink(e, _h_13);
                                                                    term_sink(e, _result_6);
                                                                    term_sink(e, _result_7);
                                                                    term_sink(e, _result_8);
                                                                    term_sink(e, _result_12);
                                                                    term_sink(e, _result_14);
                                                                    u64 _nd_20 = heap_alloc(e, cls_fit(1));
                                                                    e.mem[_nd_20 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                    r0 = term_clo(FID_IO_PRINT, _nd_20);
                                                                    WL_RETN(1);
                                                                  }
                                                                } else {
                                                                  term_sink(e, _o_17);
                                                                  term_sink(e, _h_13);
                                                                  term_sink(e, _result_6);
                                                                  term_sink(e, _result_7);
                                                                  term_sink(e, _result_8);
                                                                  term_sink(e, _result_12);
                                                                  term_sink(e, _result_14);
                                                                  u64 _nd_21 = heap_alloc(e, cls_fit(1));
                                                                  e.mem[_nd_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                  r0 = term_clo(FID_IO_PRINT, _nd_21);
                                                                  WL_RETN(1);
                                                                }
                                                              } else {
                                                                term_sink(e, _o_17);
                                                                term_sink(e, _h_15);
                                                                term_sink(e, _h_13);
                                                                term_sink(e, _result_6);
                                                                term_sink(e, _result_7);
                                                                term_sink(e, _result_8);
                                                                term_sink(e, _result_12);
                                                                term_sink(e, _result_14);
                                                                u64 _nd_22 = heap_alloc(e, cls_fit(1));
                                                                e.mem[_nd_22 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                                r0 = term_clo(FID_IO_PRINT, _nd_22);
                                                                WL_RETN(1);
                                                              }
                                                            } else {
                                                              term_sink(e, _o_17);
                                                              term_sink(e, _h_15);
                                                              term_sink(e, _h_13);
                                                              term_sink(e, _result_6);
                                                              term_sink(e, _result_7);
                                                              term_sink(e, _result_8);
                                                              term_sink(e, _result_12);
                                                              term_sink(e, _result_14);
                                                              u64 _nd_23 = heap_alloc(e, cls_fit(1));
                                                              e.mem[_nd_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                              r0 = term_clo(FID_IO_PRINT, _nd_23);
                                                              WL_RETN(1);
                                                            }
                                                          } else {
                                                            term_sink(e, _o_17);
                                                            term_sink(e, _h_14);
                                                            term_sink(e, _h_15);
                                                            term_sink(e, _h_13);
                                                            term_sink(e, _result_6);
                                                            term_sink(e, _result_7);
                                                            term_sink(e, _result_8);
                                                            term_sink(e, _result_12);
                                                            term_sink(e, _result_14);
                                                            u64 _nd_24 = heap_alloc(e, cls_fit(1));
                                                            e.mem[_nd_24 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                            r0 = term_clo(FID_IO_PRINT, _nd_24);
                                                            WL_RETN(1);
                                                          }
                                                        } else {
                                                          term_sink(e, _o_17);
                                                          term_sink(e, _h_12);
                                                          term_sink(e, _h_13);
                                                          term_sink(e, _result_6);
                                                          term_sink(e, _result_7);
                                                          term_sink(e, _result_8);
                                                          term_sink(e, _result_12);
                                                          term_sink(e, _result_14);
                                                          u64 _nd_25 = heap_alloc(e, cls_fit(1));
                                                          e.mem[_nd_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                          r0 = term_clo(FID_IO_PRINT, _nd_25);
                                                          WL_RETN(1);
                                                        }
                                                      } else {
                                                        term_sink(e, _o_17);
                                                        term_sink(e, _result_5);
                                                        term_sink(e, _result_6);
                                                        term_sink(e, _result_7);
                                                        term_sink(e, _result_8);
                                                        term_sink(e, _result_12);
                                                        term_sink(e, _result_14);
                                                        u64 _nd_26 = heap_alloc(e, cls_fit(1));
                                                        e.mem[_nd_26 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                        r0 = term_clo(FID_IO_PRINT, _nd_26);
                                                        WL_RETN(1);
                                                      }
                                                    } else {
                                                      term_sink(e, _o_17);
                                                      term_sink(e, _o_42);
                                                      term_sink(e, _result_5);
                                                      term_sink(e, _result_6);
                                                      term_sink(e, _result_7);
                                                      term_sink(e, _result_8);
                                                      term_sink(e, _result_12);
                                                      term_sink(e, _result_14);
                                                      u64 _nd_27 = heap_alloc(e, cls_fit(1));
                                                      e.mem[_nd_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                      r0 = term_clo(FID_IO_PRINT, _nd_27);
                                                      WL_RETN(1);
                                                    }
                                                  } else {
                                                    term_sink(e, _o_17);
                                                    term_sink(e, _h_11);
                                                    term_sink(e, _result_5);
                                                    term_sink(e, _result_6);
                                                    term_sink(e, _result_7);
                                                    term_sink(e, _result_8);
                                                    term_sink(e, _result_12);
                                                    term_sink(e, _result_14);
                                                    u64 _nd_28 = heap_alloc(e, cls_fit(1));
                                                    e.mem[_nd_28 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                    r0 = term_clo(FID_IO_PRINT, _nd_28);
                                                    WL_RETN(1);
                                                  }
                                                } else {
                                                  term_sink(e, _o_17);
                                                  term_sink(e, _o_39);
                                                  term_sink(e, _h_11);
                                                  term_sink(e, _result_5);
                                                  term_sink(e, _result_6);
                                                  term_sink(e, _result_7);
                                                  term_sink(e, _result_8);
                                                  term_sink(e, _result_12);
                                                  term_sink(e, _result_14);
                                                  u64 _nd_29 = heap_alloc(e, cls_fit(1));
                                                  e.mem[_nd_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                  r0 = term_clo(FID_IO_PRINT, _nd_29);
                                                  WL_RETN(1);
                                                }
                                              } else {
                                                term_sink(e, _o_17);
                                                term_sink(e, _h_10);
                                                term_sink(e, _h_11);
                                                term_sink(e, _result_5);
                                                term_sink(e, _result_6);
                                                term_sink(e, _result_7);
                                                term_sink(e, _result_8);
                                                term_sink(e, _result_12);
                                                term_sink(e, _result_14);
                                                u64 _nd_30 = heap_alloc(e, cls_fit(1));
                                                e.mem[_nd_30 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                                r0 = term_clo(FID_IO_PRINT, _nd_30);
                                                WL_RETN(1);
                                              }
                                            } else {
                                              term_sink(e, _o_17);
                                              term_sink(e, _h_7);
                                              term_sink(e, _result_5);
                                              term_sink(e, _result_6);
                                              term_sink(e, _result_7);
                                              term_sink(e, _result_8);
                                              term_sink(e, _result_12);
                                              term_sink(e, _result_14);
                                              u64 _nd_31 = heap_alloc(e, cls_fit(1));
                                              e.mem[_nd_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                              r0 = term_clo(FID_IO_PRINT, _nd_31);
                                              WL_RETN(1);
                                            }
                                          } else {
                                            term_sink(e, _o_17);
                                            term_sink(e, _o_36);
                                            term_sink(e, _h_7);
                                            term_sink(e, _result_5);
                                            term_sink(e, _result_6);
                                            term_sink(e, _result_7);
                                            term_sink(e, _result_8);
                                            term_sink(e, _result_12);
                                            term_sink(e, _result_14);
                                            u64 _nd_32 = heap_alloc(e, cls_fit(1));
                                            e.mem[_nd_32 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                            r0 = term_clo(FID_IO_PRINT, _nd_32);
                                            WL_RETN(1);
                                          }
                                        } else {
                                          term_sink(e, _o_17);
                                          term_sink(e, _h_9);
                                          term_sink(e, _h_7);
                                          term_sink(e, _result_5);
                                          term_sink(e, _result_6);
                                          term_sink(e, _result_7);
                                          term_sink(e, _result_8);
                                          term_sink(e, _result_12);
                                          term_sink(e, _result_14);
                                          u64 _nd_33 = heap_alloc(e, cls_fit(1));
                                          e.mem[_nd_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                          r0 = term_clo(FID_IO_PRINT, _nd_33);
                                          WL_RETN(1);
                                        }
                                      } else {
                                        term_sink(e, _o_17);
                                        term_sink(e, _o_33);
                                        term_sink(e, _h_9);
                                        term_sink(e, _h_7);
                                        term_sink(e, _result_5);
                                        term_sink(e, _result_6);
                                        term_sink(e, _result_7);
                                        term_sink(e, _result_8);
                                        term_sink(e, _result_12);
                                        term_sink(e, _result_14);
                                        u64 _nd_34 = heap_alloc(e, cls_fit(1));
                                        e.mem[_nd_34 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                        r0 = term_clo(FID_IO_PRINT, _nd_34);
                                        WL_RETN(1);
                                      }
                                    } else {
                                      term_sink(e, _o_17);
                                      term_sink(e, _h_8);
                                      term_sink(e, _h_9);
                                      term_sink(e, _h_7);
                                      term_sink(e, _result_5);
                                      term_sink(e, _result_6);
                                      term_sink(e, _result_7);
                                      term_sink(e, _result_8);
                                      term_sink(e, _result_12);
                                      term_sink(e, _result_14);
                                      u64 _nd_35 = heap_alloc(e, cls_fit(1));
                                      e.mem[_nd_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                      r0 = term_clo(FID_IO_PRINT, _nd_35);
                                      WL_RETN(1);
                                    }
                                  } else {
                                    term_sink(e, _o_17);
                                    term_sink(e, _h_6);
                                    term_sink(e, _h_7);
                                    term_sink(e, _result_5);
                                    term_sink(e, _result_6);
                                    term_sink(e, _result_7);
                                    term_sink(e, _result_8);
                                    term_sink(e, _result_12);
                                    term_sink(e, _result_14);
                                    u64 _nd_36 = heap_alloc(e, cls_fit(1));
                                    e.mem[_nd_36 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                    r0 = term_clo(FID_IO_PRINT, _nd_36);
                                    WL_RETN(1);
                                  }
                                } else {
                                  term_sink(e, _o_17);
                                  term_sink(e, _result_4);
                                  term_sink(e, _result_5);
                                  term_sink(e, _result_6);
                                  term_sink(e, _result_7);
                                  term_sink(e, _result_8);
                                  term_sink(e, _result_12);
                                  term_sink(e, _result_14);
                                  u64 _nd_37 = heap_alloc(e, cls_fit(1));
                                  e.mem[_nd_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                  r0 = term_clo(FID_IO_PRINT, _nd_37);
                                  WL_RETN(1);
                                }
                              } else {
                                term_sink(e, _o_17);
                                term_sink(e, _o_25);
                                term_sink(e, _result_4);
                                term_sink(e, _result_5);
                                term_sink(e, _result_6);
                                term_sink(e, _result_7);
                                term_sink(e, _result_8);
                                term_sink(e, _result_12);
                                term_sink(e, _result_14);
                                u64 _nd_38 = heap_alloc(e, cls_fit(1));
                                e.mem[_nd_38 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                                r0 = term_clo(FID_IO_PRINT, _nd_38);
                                WL_RETN(1);
                              }
                            } else {
                              term_sink(e, _o_17);
                              term_sink(e, _h_5);
                              term_sink(e, _result_4);
                              term_sink(e, _result_5);
                              term_sink(e, _result_6);
                              term_sink(e, _result_7);
                              term_sink(e, _result_8);
                              term_sink(e, _result_12);
                              term_sink(e, _result_14);
                              u64 _nd_39 = heap_alloc(e, cls_fit(1));
                              e.mem[_nd_39 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                              r0 = term_clo(FID_IO_PRINT, _nd_39);
                              WL_RETN(1);
                            }
                          } else {
                            term_sink(e, _o_17);
                            term_sink(e, _h_5);
                            term_sink(e, _result_4);
                            term_sink(e, _result_5);
                            term_sink(e, _result_6);
                            term_sink(e, _result_7);
                            term_sink(e, _result_8);
                            term_sink(e, _result_12);
                            term_sink(e, _result_14);
                            u64 _nd_40 = heap_alloc(e, cls_fit(1));
                            e.mem[_nd_40 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                            r0 = term_clo(FID_IO_PRINT, _nd_40);
                            WL_RETN(1);
                          }
                        } else {
                          term_sink(e, _h_4);
                          term_sink(e, _h_5);
                          term_sink(e, _result_4);
                          term_sink(e, _result_5);
                          term_sink(e, _result_6);
                          term_sink(e, _result_7);
                          term_sink(e, _result_8);
                          term_sink(e, _result_12);
                          term_sink(e, _result_14);
                          u64 _nd_41 = heap_alloc(e, cls_fit(1));
                          e.mem[_nd_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                          r0 = term_clo(FID_IO_PRINT, _nd_41);
                          WL_RETN(1);
                        }
                      } else {
                        term_sink(e, _h_1);
                        term_sink(e, _result_4);
                        term_sink(e, _result_5);
                        term_sink(e, _result_6);
                        term_sink(e, _result_7);
                        term_sink(e, _result_8);
                        term_sink(e, _result_12);
                        term_sink(e, _result_14);
                        u64 _nd_42 = heap_alloc(e, cls_fit(1));
                        e.mem[_nd_42 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                        r0 = term_clo(FID_IO_PRINT, _nd_42);
                        WL_RETN(1);
                      }
                    } else {
                      term_sink(e, _o_9);
                      term_sink(e, _h_1);
                      term_sink(e, _result_4);
                      term_sink(e, _result_5);
                      term_sink(e, _result_6);
                      term_sink(e, _result_7);
                      term_sink(e, _result_8);
                      term_sink(e, _result_12);
                      term_sink(e, _result_14);
                      u64 _nd_43 = heap_alloc(e, cls_fit(1));
                      e.mem[_nd_43 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                      r0 = term_clo(FID_IO_PRINT, _nd_43);
                      WL_RETN(1);
                    }
                  } else {
                    term_sink(e, _h_3);
                    term_sink(e, _h_1);
                    term_sink(e, _result_4);
                    term_sink(e, _result_5);
                    term_sink(e, _result_6);
                    term_sink(e, _result_7);
                    term_sink(e, _result_8);
                    term_sink(e, _result_12);
                    term_sink(e, _result_14);
                    u64 _nd_44 = heap_alloc(e, cls_fit(1));
                    e.mem[_nd_44 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                    r0 = term_clo(FID_IO_PRINT, _nd_44);
                    WL_RETN(1);
                  }
                } else {
                  term_sink(e, _o_1);
                  term_sink(e, _h_3);
                  term_sink(e, _h_1);
                  term_sink(e, _result_4);
                  term_sink(e, _result_5);
                  term_sink(e, _result_6);
                  term_sink(e, _result_7);
                  term_sink(e, _result_8);
                  term_sink(e, _result_12);
                  term_sink(e, _result_14);
                  u64 _nd_45 = heap_alloc(e, cls_fit(1));
                  e.mem[_nd_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                  r0 = term_clo(FID_IO_PRINT, _nd_45);
                  WL_RETN(1);
                }
              } else {
                term_sink(e, _h_2);
                term_sink(e, _h_3);
                term_sink(e, _h_1);
                term_sink(e, _result_4);
                term_sink(e, _result_5);
                term_sink(e, _result_6);
                term_sink(e, _result_7);
                term_sink(e, _result_8);
                term_sink(e, _result_12);
                term_sink(e, _result_14);
                u64 _nd_46 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_46 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
                r0 = term_clo(FID_IO_PRINT, _nd_46);
                WL_RETN(1);
              }
            } else {
              term_sink(e, _h_0);
              term_sink(e, _h_1);
              term_sink(e, _result_4);
              term_sink(e, _result_5);
              term_sink(e, _result_6);
              term_sink(e, _result_7);
              term_sink(e, _result_8);
              term_sink(e, _result_12);
              term_sink(e, _result_14);
              u64 _nd_47 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
              r0 = term_clo(FID_IO_PRINT, _nd_47);
              WL_RETN(1);
            }
          } else {
            term_sink(e, _result_3);
            term_sink(e, _result_4);
            term_sink(e, _result_5);
            term_sink(e, _result_6);
            term_sink(e, _result_7);
            term_sink(e, _result_8);
            term_sink(e, _result_12);
            term_sink(e, _result_14);
            u64 _nd_48 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_48 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
            r0 = term_clo(FID_IO_PRINT, _nd_48);
            WL_RETN(1);
          }
        } else {
          term_sink(e, _result_3);
          term_sink(e, _result_4);
          term_sink(e, _result_5);
          term_sink(e, _result_6);
          term_sink(e, _result_7);
          term_sink(e, _result_8);
          term_sink(e, _result_12);
          term_sink(e, _result_14);
          term_sink(e, _s_1);
          term_sink(e, _s_2);
          term_sink(e, _s_3);
          u64 _nd_49 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 374);
          r0 = term_clo(FID_IO_PRINT, _nd_49);
          WL_RETN(1);
        }
      } else {
        term_sink(e, _result_3);
        term_sink(e, _result_4);
        term_sink(e, _result_5);
        term_sink(e, _result_6);
        term_sink(e, _result_7);
        term_sink(e, _result_8);
        term_sink(e, _result_12);
        term_sink(e, _result_14);
        term_sink(e, _result_22);
        u64 _nd_50 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_50 + 0] = term_ctr(CID_SCON, STAT_OFF + 406);
        r0 = term_clo(FID_IO_PRINT, _nd_50);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _result_3);
      term_sink(e, _result_4);
      term_sink(e, _result_5);
      term_sink(e, _result_6);
      term_sink(e, _result_7);
      term_sink(e, _result_8);
      term_sink(e, _result_12);
      term_sink(e, _result_14);
      term_sink(e, _result_22);
      term_sink(e, _result_24);
      term_sink(e, _result_32);
      term_sink(e, _result_38);
      u64 _nd_51 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 406);
      r0 = term_clo(FID_IO_PRINT, _nd_51);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K203)
  {
    WL_POPN(26);
    u32 _retained_5 = STK(0);
    u32 _retained_6 = STK(1);
    u32 _retained_7 = STK(2);
    u32 _retained_8 = STK(3);
    u32 _retained_9 = STK(4);
    u32 _result_39 = STK(5);
    u32 _result_40 = STK(6);
    Term _o_52 = STK(7);
    u32 _o_53 = STK(8);
    u32 _o_54 = STK(9);
    u32 _o_55 = STK(10);
    u32 _o_56 = STK(11);
    u32 _o_57 = STK(12);
    u32 _o_58 = STK(13);
    Term _result_41 = STK(14);
    Term _result_42 = STK(15);
    u32 _result_43 = STK(16);
    Term _result_44 = STK(17);
    u32 _result_45 = STK(18);
    Term _result_46 = STK(19);
    u32 _result_47 = STK(20);
    u32 _result_48 = STK(21);
    u32 _result_49 = STK(22);
    u32 _result_50 = STK(23);
    u32 _result_51 = STK(24);
    u32 _result_52 = STK(25);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _retained_5;
      STK(1) = _retained_6;
      STK(2) = _retained_7;
      STK(3) = _retained_8;
      STK(4) = _retained_9;
      STK(5) = _result_39;
      STK(6) = _result_40;
      STK(7) = _o_53;
      STK(8) = _o_54;
      STK(9) = _o_55;
      STK(10) = _o_56;
      STK(11) = _o_57;
      STK(12) = _o_58;
      STK(13) = _result_41;
      STK(14) = _result_42;
      STK(15) = _result_43;
      STK(16) = _result_44;
      STK(17) = _result_45;
      STK(18) = _result_46;
      STK(19) = _result_47;
      STK(20) = _result_48;
      STK(21) = _result_49;
      STK(22) = _result_50;
      STK(23) = _result_51;
      STK(24) = _result_52;
      STK(25) = _h_24;
      STK(26) = FID_APPLIED_K204;
      WL_PUSHN(27);
    } else {
      u64 _t_2 = task_node(e, FID_APPLIED_K204, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _retained_5;
      e.mem[_t_2 + 1] = _retained_6;
      e.mem[_t_2 + 2] = _retained_7;
      e.mem[_t_2 + 3] = _retained_8;
      e.mem[_t_2 + 4] = _retained_9;
      e.mem[_t_2 + 5] = _result_39;
      e.mem[_t_2 + 6] = _result_40;
      e.mem[_t_2 + 7] = _o_53;
      e.mem[_t_2 + 8] = _o_54;
      e.mem[_t_2 + 9] = _o_55;
      e.mem[_t_2 + 10] = _o_56;
      e.mem[_t_2 + 11] = _o_57;
      e.mem[_t_2 + 12] = _o_58;
      e.mem[_t_2 + 13] = _result_41;
      e.mem[_t_2 + 14] = _result_42;
      e.mem[_t_2 + 15] = _result_43;
      e.mem[_t_2 + 16] = _result_44;
      e.mem[_t_2 + 17] = _result_45;
      e.mem[_t_2 + 18] = _result_46;
      e.mem[_t_2 + 19] = _result_47;
      e.mem[_t_2 + 20] = _result_48;
      e.mem[_t_2 + 21] = _result_49;
      e.mem[_t_2 + 22] = _result_50;
      e.mem[_t_2 + 23] = _result_51;
      e.mem[_t_2 + 24] = _result_52;
      e.mem[_t_2 + 25] = _h_24;
      WL_CONT = term_tsk(FID_APPLIED_K204, _t_2);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_3 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _o_52;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_3);
    }
    r0 = _o_52;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K204)
  {
    WL_POPN(26);
    u32 _retained_10 = STK(0);
    u32 _retained_11 = STK(1);
    u32 _retained_12 = STK(2);
    u32 _retained_13 = STK(3);
    u32 _retained_14 = STK(4);
    u32 _result_53 = STK(5);
    u32 _result_54 = STK(6);
    u32 _o_59 = STK(7);
    u32 _o_60 = STK(8);
    u32 _o_61 = STK(9);
    u32 _o_62 = STK(10);
    u32 _o_63 = STK(11);
    u32 _o_64 = STK(12);
    Term _result_55 = STK(13);
    Term _result_56 = STK(14);
    u32 _result_57 = STK(15);
    Term _result_58 = STK(16);
    u32 _result_59 = STK(17);
    Term _result_60 = STK(18);
    u32 _result_61 = STK(19);
    u32 _result_62 = STK(20);
    u32 _result_63 = STK(21);
    u32 _result_64 = STK(22);
    u32 _result_65 = STK(23);
    u32 _result_66 = STK(24);
    Term _h_26 = STK(25);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _retained_10;
      STK(1) = _retained_11;
      STK(2) = _retained_12;
      STK(3) = _retained_13;
      STK(4) = _retained_14;
      STK(5) = _result_53;
      STK(6) = _result_54;
      STK(7) = _o_59;
      STK(8) = _o_60;
      STK(9) = _o_61;
      STK(10) = _o_62;
      STK(11) = _o_63;
      STK(12) = _o_64;
      STK(13) = _result_55;
      STK(14) = _result_56;
      STK(15) = _result_57;
      STK(16) = _result_58;
      STK(17) = _result_59;
      STK(18) = _result_60;
      STK(19) = _result_61;
      STK(20) = _result_62;
      STK(21) = _result_63;
      STK(22) = _result_64;
      STK(23) = _result_65;
      STK(24) = _result_66;
      STK(25) = _h_26;
      STK(26) = FID_APPLIED_K205;
      WL_PUSHN(27);
    } else {
      u64 _t_4 = task_node(e, FID_APPLIED_K205, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _retained_10;
      e.mem[_t_4 + 1] = _retained_11;
      e.mem[_t_4 + 2] = _retained_12;
      e.mem[_t_4 + 3] = _retained_13;
      e.mem[_t_4 + 4] = _retained_14;
      e.mem[_t_4 + 5] = _result_53;
      e.mem[_t_4 + 6] = _result_54;
      e.mem[_t_4 + 7] = _o_59;
      e.mem[_t_4 + 8] = _o_60;
      e.mem[_t_4 + 9] = _o_61;
      e.mem[_t_4 + 10] = _o_62;
      e.mem[_t_4 + 11] = _o_63;
      e.mem[_t_4 + 12] = _o_64;
      e.mem[_t_4 + 13] = _result_55;
      e.mem[_t_4 + 14] = _result_56;
      e.mem[_t_4 + 15] = _result_57;
      e.mem[_t_4 + 16] = _result_58;
      e.mem[_t_4 + 17] = _result_59;
      e.mem[_t_4 + 18] = _result_60;
      e.mem[_t_4 + 19] = _result_61;
      e.mem[_t_4 + 20] = _result_62;
      e.mem[_t_4 + 21] = _result_63;
      e.mem[_t_4 + 22] = _result_64;
      e.mem[_t_4 + 23] = _result_65;
      e.mem[_t_4 + 24] = _result_66;
      e.mem[_t_4 + 25] = _h_26;
      WL_CONT = term_tsk(FID_APPLIED_K205, _t_4);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_5 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_25;
      return term_tsk(FID_DATA, _t_5);
    }
    r0 = _h_25;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K205)
  {
    WL_POPN(26);
    u32 _retained_15 = STK(0);
    u32 _retained_16 = STK(1);
    u32 _retained_17 = STK(2);
    u32 _retained_18 = STK(3);
    u32 _retained_19 = STK(4);
    u32 _result_67 = STK(5);
    u32 _result_68 = STK(6);
    u32 _o_65 = STK(7);
    u32 _o_66 = STK(8);
    u32 _o_67 = STK(9);
    u32 _o_68 = STK(10);
    u32 _o_69 = STK(11);
    u32 _o_70 = STK(12);
    Term _result_69 = STK(13);
    Term _result_70 = STK(14);
    u32 _result_71 = STK(15);
    Term _result_72 = STK(16);
    u32 _result_73 = STK(17);
    Term _result_74 = STK(18);
    u32 _result_75 = STK(19);
    u32 _result_76 = STK(20);
    u32 _result_77 = STK(21);
    u32 _result_78 = STK(22);
    u32 _result_79 = STK(23);
    u32 _result_80 = STK(24);
    Term _h_28 = STK(25);
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _retained_15;
      STK(1) = _retained_16;
      STK(2) = _retained_17;
      STK(3) = _retained_18;
      STK(4) = _retained_19;
      STK(5) = _result_67;
      STK(6) = _result_68;
      STK(7) = _o_65;
      STK(8) = _o_66;
      STK(9) = _o_67;
      STK(10) = _o_68;
      STK(11) = _o_69;
      STK(12) = _o_70;
      STK(13) = _result_69;
      STK(14) = _result_70;
      STK(15) = _result_71;
      STK(16) = _result_72;
      STK(17) = _result_73;
      STK(18) = _result_74;
      STK(19) = _result_75;
      STK(20) = _result_76;
      STK(21) = _result_77;
      STK(22) = _result_78;
      STK(23) = _result_79;
      STK(24) = _result_80;
      STK(25) = _h_28;
      STK(26) = FID_APPLIED_K206;
      WL_PUSHN(27);
    } else {
      u64 _t_6 = task_node(e, FID_APPLIED_K206, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _retained_15;
      e.mem[_t_6 + 1] = _retained_16;
      e.mem[_t_6 + 2] = _retained_17;
      e.mem[_t_6 + 3] = _retained_18;
      e.mem[_t_6 + 4] = _retained_19;
      e.mem[_t_6 + 5] = _result_67;
      e.mem[_t_6 + 6] = _result_68;
      e.mem[_t_6 + 7] = _o_65;
      e.mem[_t_6 + 8] = _o_66;
      e.mem[_t_6 + 9] = _o_67;
      e.mem[_t_6 + 10] = _o_68;
      e.mem[_t_6 + 11] = _o_69;
      e.mem[_t_6 + 12] = _o_70;
      e.mem[_t_6 + 13] = _result_69;
      e.mem[_t_6 + 14] = _result_70;
      e.mem[_t_6 + 15] = _result_71;
      e.mem[_t_6 + 16] = _result_72;
      e.mem[_t_6 + 17] = _result_73;
      e.mem[_t_6 + 18] = _result_74;
      e.mem[_t_6 + 19] = _result_75;
      e.mem[_t_6 + 20] = _result_76;
      e.mem[_t_6 + 21] = _result_77;
      e.mem[_t_6 + 22] = _result_78;
      e.mem[_t_6 + 23] = _result_79;
      e.mem[_t_6 + 24] = _result_80;
      e.mem[_t_6 + 25] = _h_28;
      WL_CONT = term_tsk(FID_APPLIED_K206, _t_6);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_7 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_27;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_7);
    }
    r0 = _h_27;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K206)
  {
    WL_POPN(26);
    u32 _retained_20 = STK(0);
    u32 _retained_21 = STK(1);
    u32 _retained_22 = STK(2);
    u32 _retained_23 = STK(3);
    u32 _retained_24 = STK(4);
    u32 _result_81 = STK(5);
    u32 _result_82 = STK(6);
    u32 _o_71 = STK(7);
    u32 _o_72 = STK(8);
    u32 _o_73 = STK(9);
    u32 _o_74 = STK(10);
    u32 _o_75 = STK(11);
    u32 _o_76 = STK(12);
    Term _result_83 = STK(13);
    Term _result_84 = STK(14);
    u32 _result_85 = STK(15);
    Term _result_86 = STK(16);
    u32 _result_87 = STK(17);
    Term _result_88 = STK(18);
    u32 _result_89 = STK(19);
    u32 _result_90 = STK(20);
    u32 _result_91 = STK(21);
    u32 _result_92 = STK(22);
    u32 _result_93 = STK(23);
    u32 _result_94 = STK(24);
    Term _h_30 = STK(25);
    Term _h_29 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _retained_20;
      STK(1) = _retained_21;
      STK(2) = _retained_22;
      STK(3) = _retained_23;
      STK(4) = _retained_24;
      STK(5) = _result_81;
      STK(6) = _result_82;
      STK(7) = _o_72;
      STK(8) = _o_73;
      STK(9) = _o_74;
      STK(10) = _o_75;
      STK(11) = _o_76;
      STK(12) = _result_83;
      STK(13) = _result_84;
      STK(14) = _result_85;
      STK(15) = _result_86;
      STK(16) = _result_87;
      STK(17) = _result_88;
      STK(18) = _result_89;
      STK(19) = _result_90;
      STK(20) = _result_91;
      STK(21) = _result_92;
      STK(22) = _result_93;
      STK(23) = _result_94;
      STK(24) = _h_30;
      STK(25) = _h_29;
      STK(26) = FID_APPLIED_K207;
      WL_PUSHN(27);
    } else {
      u64 _t_8 = task_node(e, FID_APPLIED_K207, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _retained_20;
      e.mem[_t_8 + 1] = _retained_21;
      e.mem[_t_8 + 2] = _retained_22;
      e.mem[_t_8 + 3] = _retained_23;
      e.mem[_t_8 + 4] = _retained_24;
      e.mem[_t_8 + 5] = _result_81;
      e.mem[_t_8 + 6] = _result_82;
      e.mem[_t_8 + 7] = _o_72;
      e.mem[_t_8 + 8] = _o_73;
      e.mem[_t_8 + 9] = _o_74;
      e.mem[_t_8 + 10] = _o_75;
      e.mem[_t_8 + 11] = _o_76;
      e.mem[_t_8 + 12] = _result_83;
      e.mem[_t_8 + 13] = _result_84;
      e.mem[_t_8 + 14] = _result_85;
      e.mem[_t_8 + 15] = _result_86;
      e.mem[_t_8 + 16] = _result_87;
      e.mem[_t_8 + 17] = _result_88;
      e.mem[_t_8 + 18] = _result_89;
      e.mem[_t_8 + 19] = _result_90;
      e.mem[_t_8 + 20] = _result_91;
      e.mem[_t_8 + 21] = _result_92;
      e.mem[_t_8 + 22] = _result_93;
      e.mem[_t_8 + 23] = _result_94;
      e.mem[_t_8 + 24] = _h_30;
      e.mem[_t_8 + 25] = _h_29;
      WL_CONT = term_tsk(FID_APPLIED_K207, _t_8);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _o_71;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _o_71;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K207)
  {
    WL_POPN(26);
    u32 _retained_25 = STK(0);
    u32 _retained_26 = STK(1);
    u32 _retained_27 = STK(2);
    u32 _retained_28 = STK(3);
    u32 _retained_29 = STK(4);
    u32 _result_95 = STK(5);
    u32 _result_96 = STK(6);
    u32 _o_77 = STK(7);
    u32 _o_78 = STK(8);
    u32 _o_79 = STK(9);
    u32 _o_80 = STK(10);
    u32 _o_81 = STK(11);
    Term _result_97 = STK(12);
    Term _result_98 = STK(13);
    u32 _result_99 = STK(14);
    Term _result_100 = STK(15);
    u32 _result_101 = STK(16);
    Term _result_102 = STK(17);
    u32 _result_103 = STK(18);
    u32 _result_104 = STK(19);
    u32 _result_105 = STK(20);
    u32 _result_106 = STK(21);
    u32 _result_107 = STK(22);
    u32 _result_108 = STK(23);
    Term _h_32 = STK(24);
    Term _h_33 = STK(25);
    Term _h_31 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _retained_25;
      STK(1) = _retained_26;
      STK(2) = _retained_27;
      STK(3) = _retained_28;
      STK(4) = _retained_29;
      STK(5) = _result_95;
      STK(6) = _result_96;
      STK(7) = _result_97;
      STK(8) = _result_98;
      STK(9) = _result_99;
      STK(10) = _result_100;
      STK(11) = _result_101;
      STK(12) = _result_102;
      STK(13) = _result_103;
      STK(14) = _result_104;
      STK(15) = _result_105;
      STK(16) = _result_106;
      STK(17) = _result_107;
      STK(18) = _result_108;
      STK(19) = _h_32;
      STK(20) = _h_33;
      STK(21) = _h_31;
      STK(22) = FID_APPLIED_K208;
      WL_PUSHN(23);
    } else {
      u64 _t_10 = task_node(e, FID_APPLIED_K208, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _retained_25;
      e.mem[_t_10 + 1] = _retained_26;
      e.mem[_t_10 + 2] = _retained_27;
      e.mem[_t_10 + 3] = _retained_28;
      e.mem[_t_10 + 4] = _retained_29;
      e.mem[_t_10 + 5] = _result_95;
      e.mem[_t_10 + 6] = _result_96;
      e.mem[_t_10 + 7] = _result_97;
      e.mem[_t_10 + 8] = _result_98;
      e.mem[_t_10 + 9] = _result_99;
      e.mem[_t_10 + 10] = _result_100;
      e.mem[_t_10 + 11] = _result_101;
      e.mem[_t_10 + 12] = _result_102;
      e.mem[_t_10 + 13] = _result_103;
      e.mem[_t_10 + 14] = _result_104;
      e.mem[_t_10 + 15] = _result_105;
      e.mem[_t_10 + 16] = _result_106;
      e.mem[_t_10 + 17] = _result_107;
      e.mem[_t_10 + 18] = _result_108;
      e.mem[_t_10 + 19] = _h_32;
      e.mem[_t_10 + 20] = _h_33;
      e.mem[_t_10 + 21] = _h_31;
      WL_CONT = term_tsk(FID_APPLIED_K208, _t_10);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_POSITION)) {
      u64 _t_11 = task_node(e, FID_HOST_RENDER_RENDER_POSITION, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _o_77;
      e.mem[_t_11 + 1] = _o_78;
      e.mem[_t_11 + 2] = _o_79;
      e.mem[_t_11 + 3] = _o_80;
      e.mem[_t_11 + 4] = _o_81;
      return term_tsk(FID_HOST_RENDER_RENDER_POSITION, _t_11);
    }
    r0 = _o_77;
    r1 = _o_78;
    r2 = _o_79;
    r3 = _o_80;
    r4 = _o_81;
    WL_JMP(FID_HOST_RENDER_RENDER_POSITION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K208)
  {
    WL_POPN(22);
    u32 _retained_30 = STK(0);
    u32 _retained_31 = STK(1);
    u32 _retained_32 = STK(2);
    u32 _retained_33 = STK(3);
    u32 _retained_34 = STK(4);
    u32 _result_109 = STK(5);
    u32 _result_110 = STK(6);
    Term _result_111 = STK(7);
    Term _result_112 = STK(8);
    u32 _result_113 = STK(9);
    Term _result_114 = STK(10);
    u32 _result_115 = STK(11);
    Term _result_116 = STK(12);
    u32 _result_117 = STK(13);
    u32 _result_118 = STK(14);
    u32 _result_119 = STK(15);
    u32 _result_120 = STK(16);
    u32 _result_121 = STK(17);
    u32 _result_122 = STK(18);
    Term _h_35 = STK(19);
    Term _h_36 = STK(20);
    Term _h_37 = STK(21);
    Term _h_34 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _result_109;
      STK(1) = _result_110;
      STK(2) = _result_111;
      STK(3) = _result_112;
      STK(4) = _result_113;
      STK(5) = _result_114;
      STK(6) = _result_115;
      STK(7) = _result_116;
      STK(8) = _result_117;
      STK(9) = _result_118;
      STK(10) = _result_119;
      STK(11) = _result_120;
      STK(12) = _result_121;
      STK(13) = _result_122;
      STK(14) = _h_35;
      STK(15) = _h_36;
      STK(16) = _h_37;
      STK(17) = _h_34;
      STK(18) = FID_APPLIED_K209;
      WL_PUSHN(19);
    } else {
      u64 _t_12 = task_node(e, FID_APPLIED_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _result_109;
      e.mem[_t_12 + 1] = _result_110;
      e.mem[_t_12 + 2] = _result_111;
      e.mem[_t_12 + 3] = _result_112;
      e.mem[_t_12 + 4] = _result_113;
      e.mem[_t_12 + 5] = _result_114;
      e.mem[_t_12 + 6] = _result_115;
      e.mem[_t_12 + 7] = _result_116;
      e.mem[_t_12 + 8] = _result_117;
      e.mem[_t_12 + 9] = _result_118;
      e.mem[_t_12 + 10] = _result_119;
      e.mem[_t_12 + 11] = _result_120;
      e.mem[_t_12 + 12] = _result_121;
      e.mem[_t_12 + 13] = _result_122;
      e.mem[_t_12 + 14] = _h_35;
      e.mem[_t_12 + 15] = _h_36;
      e.mem[_t_12 + 16] = _h_37;
      e.mem[_t_12 + 17] = _h_34;
      WL_CONT = term_tsk(FID_APPLIED_K209, _t_12);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_POSITION)) {
      u64 _t_13 = task_node(e, FID_HOST_RENDER_RENDER_POSITION, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _retained_30;
      e.mem[_t_13 + 1] = _retained_31;
      e.mem[_t_13 + 2] = _retained_32;
      e.mem[_t_13 + 3] = _retained_33;
      e.mem[_t_13 + 4] = _retained_34;
      return term_tsk(FID_HOST_RENDER_RENDER_POSITION, _t_13);
    }
    r0 = _retained_30;
    r1 = _retained_31;
    r2 = _retained_32;
    r3 = _retained_33;
    r4 = _retained_34;
    WL_JMP(FID_HOST_RENDER_RENDER_POSITION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K209)
  {
    WL_POPN(18);
    u32 _result_123 = STK(0);
    u32 _result_124 = STK(1);
    Term _result_125 = STK(2);
    Term _result_126 = STK(3);
    u32 _result_127 = STK(4);
    Term _result_128 = STK(5);
    u32 _result_129 = STK(6);
    Term _result_130 = STK(7);
    u32 _result_131 = STK(8);
    u32 _result_132 = STK(9);
    u32 _result_133 = STK(10);
    u32 _result_134 = STK(11);
    u32 _result_135 = STK(12);
    u32 _result_136 = STK(13);
    Term _h_39 = STK(14);
    Term _h_40 = STK(15);
    Term _h_41 = STK(16);
    Term _h_42 = STK(17);
    Term _h_38 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _result_124;
      STK(1) = _result_125;
      STK(2) = _result_126;
      STK(3) = _result_127;
      STK(4) = _result_128;
      STK(5) = _result_129;
      STK(6) = _result_130;
      STK(7) = _result_131;
      STK(8) = _result_132;
      STK(9) = _result_133;
      STK(10) = _result_134;
      STK(11) = _result_135;
      STK(12) = _result_136;
      STK(13) = _h_39;
      STK(14) = _h_40;
      STK(15) = _h_41;
      STK(16) = _h_42;
      STK(17) = _h_38;
      STK(18) = FID_APPLIED_K210;
      WL_PUSHN(19);
    } else {
      u64 _t_14 = task_node(e, FID_APPLIED_K210, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _result_124;
      e.mem[_t_14 + 1] = _result_125;
      e.mem[_t_14 + 2] = _result_126;
      e.mem[_t_14 + 3] = _result_127;
      e.mem[_t_14 + 4] = _result_128;
      e.mem[_t_14 + 5] = _result_129;
      e.mem[_t_14 + 6] = _result_130;
      e.mem[_t_14 + 7] = _result_131;
      e.mem[_t_14 + 8] = _result_132;
      e.mem[_t_14 + 9] = _result_133;
      e.mem[_t_14 + 10] = _result_134;
      e.mem[_t_14 + 11] = _result_135;
      e.mem[_t_14 + 12] = _result_136;
      e.mem[_t_14 + 13] = _h_39;
      e.mem[_t_14 + 14] = _h_40;
      e.mem[_t_14 + 15] = _h_41;
      e.mem[_t_14 + 16] = _h_42;
      e.mem[_t_14 + 17] = _h_38;
      WL_CONT = term_tsk(FID_APPLIED_K210, _t_14);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_15 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _result_123;
      return term_tsk(FID_U32_SHOW, _t_15);
    }
    r0 = _result_123;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K210)
  {
    WL_POPN(18);
    u32 _result_137 = STK(0);
    Term _result_138 = STK(1);
    Term _result_139 = STK(2);
    u32 _result_140 = STK(3);
    Term _result_141 = STK(4);
    u32 _result_142 = STK(5);
    Term _result_143 = STK(6);
    u32 _result_144 = STK(7);
    u32 _result_145 = STK(8);
    u32 _result_146 = STK(9);
    u32 _result_147 = STK(10);
    u32 _result_148 = STK(11);
    u32 _result_149 = STK(12);
    Term _h_44 = STK(13);
    Term _h_45 = STK(14);
    Term _h_46 = STK(15);
    Term _h_47 = STK(16);
    Term _h_48 = STK(17);
    Term _h_43 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _result_138;
      STK(1) = _result_139;
      STK(2) = _result_140;
      STK(3) = _result_141;
      STK(4) = _result_142;
      STK(5) = _result_143;
      STK(6) = _result_144;
      STK(7) = _result_145;
      STK(8) = _result_146;
      STK(9) = _result_147;
      STK(10) = _result_148;
      STK(11) = _result_149;
      STK(12) = _h_44;
      STK(13) = _h_45;
      STK(14) = _h_46;
      STK(15) = _h_47;
      STK(16) = _h_48;
      STK(17) = _h_43;
      STK(18) = FID_APPLIED_K211;
      WL_PUSHN(19);
    } else {
      u64 _t_16 = task_node(e, FID_APPLIED_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _result_138;
      e.mem[_t_16 + 1] = _result_139;
      e.mem[_t_16 + 2] = _result_140;
      e.mem[_t_16 + 3] = _result_141;
      e.mem[_t_16 + 4] = _result_142;
      e.mem[_t_16 + 5] = _result_143;
      e.mem[_t_16 + 6] = _result_144;
      e.mem[_t_16 + 7] = _result_145;
      e.mem[_t_16 + 8] = _result_146;
      e.mem[_t_16 + 9] = _result_147;
      e.mem[_t_16 + 10] = _result_148;
      e.mem[_t_16 + 11] = _result_149;
      e.mem[_t_16 + 12] = _h_44;
      e.mem[_t_16 + 13] = _h_45;
      e.mem[_t_16 + 14] = _h_46;
      e.mem[_t_16 + 15] = _h_47;
      e.mem[_t_16 + 16] = _h_48;
      e.mem[_t_16 + 17] = _h_43;
      WL_CONT = term_tsk(FID_APPLIED_K211, _t_16);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _result_137;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _result_137;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K211)
  {
    WL_POPN(18);
    Term _result_150 = STK(0);
    Term _result_151 = STK(1);
    u32 _result_152 = STK(2);
    Term _result_153 = STK(3);
    u32 _result_154 = STK(4);
    Term _result_155 = STK(5);
    u32 _result_156 = STK(6);
    u32 _result_157 = STK(7);
    u32 _result_158 = STK(8);
    u32 _result_159 = STK(9);
    u32 _result_160 = STK(10);
    u32 _result_161 = STK(11);
    Term _h_50 = STK(12);
    Term _h_51 = STK(13);
    Term _h_52 = STK(14);
    Term _h_53 = STK(15);
    Term _h_54 = STK(16);
    Term _h_55 = STK(17);
    Term _h_49 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _result_150;
      STK(1) = _result_151;
      STK(2) = _result_153;
      STK(3) = _result_154;
      STK(4) = _result_155;
      STK(5) = _result_156;
      STK(6) = _result_157;
      STK(7) = _result_158;
      STK(8) = _result_159;
      STK(9) = _result_160;
      STK(10) = _result_161;
      STK(11) = _h_50;
      STK(12) = _h_51;
      STK(13) = _h_52;
      STK(14) = _h_53;
      STK(15) = _h_54;
      STK(16) = _h_55;
      STK(17) = _h_49;
      STK(18) = FID_APPLIED_K212;
      WL_PUSHN(19);
    } else {
      u64 _t_18 = task_node(e, FID_APPLIED_K212, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _result_150;
      e.mem[_t_18 + 1] = _result_151;
      e.mem[_t_18 + 2] = _result_153;
      e.mem[_t_18 + 3] = _result_154;
      e.mem[_t_18 + 4] = _result_155;
      e.mem[_t_18 + 5] = _result_156;
      e.mem[_t_18 + 6] = _result_157;
      e.mem[_t_18 + 7] = _result_158;
      e.mem[_t_18 + 8] = _result_159;
      e.mem[_t_18 + 9] = _result_160;
      e.mem[_t_18 + 10] = _result_161;
      e.mem[_t_18 + 11] = _h_50;
      e.mem[_t_18 + 12] = _h_51;
      e.mem[_t_18 + 13] = _h_52;
      e.mem[_t_18 + 14] = _h_53;
      e.mem[_t_18 + 15] = _h_54;
      e.mem[_t_18 + 16] = _h_55;
      e.mem[_t_18 + 17] = _h_49;
      WL_CONT = term_tsk(FID_APPLIED_K212, _t_18);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_19 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _result_152;
      return term_tsk(FID_U32_SHOW, _t_19);
    }
    r0 = _result_152;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K212)
  {
    WL_POPN(18);
    Term _result_162 = STK(0);
    Term _result_163 = STK(1);
    Term _result_164 = STK(2);
    u32 _result_165 = STK(3);
    Term _result_166 = STK(4);
    u32 _result_167 = STK(5);
    u32 _result_168 = STK(6);
    u32 _result_169 = STK(7);
    u32 _result_170 = STK(8);
    u32 _result_171 = STK(9);
    u32 _result_172 = STK(10);
    Term _h_57 = STK(11);
    Term _h_58 = STK(12);
    Term _h_59 = STK(13);
    Term _h_60 = STK(14);
    Term _h_61 = STK(15);
    Term _h_62 = STK(16);
    Term _h_63 = STK(17);
    Term _h_56 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _result_162;
      STK(1) = _result_163;
      STK(2) = _result_165;
      STK(3) = _result_166;
      STK(4) = _result_167;
      STK(5) = _result_168;
      STK(6) = _result_169;
      STK(7) = _result_170;
      STK(8) = _result_171;
      STK(9) = _result_172;
      STK(10) = _h_57;
      STK(11) = _h_58;
      STK(12) = _h_59;
      STK(13) = _h_60;
      STK(14) = _h_61;
      STK(15) = _h_62;
      STK(16) = _h_63;
      STK(17) = _h_56;
      STK(18) = FID_APPLIED_K213;
      WL_PUSHN(19);
    } else {
      u64 _t_20 = task_node(e, FID_APPLIED_K213, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _result_162;
      e.mem[_t_20 + 1] = _result_163;
      e.mem[_t_20 + 2] = _result_165;
      e.mem[_t_20 + 3] = _result_166;
      e.mem[_t_20 + 4] = _result_167;
      e.mem[_t_20 + 5] = _result_168;
      e.mem[_t_20 + 6] = _result_169;
      e.mem[_t_20 + 7] = _result_170;
      e.mem[_t_20 + 8] = _result_171;
      e.mem[_t_20 + 9] = _result_172;
      e.mem[_t_20 + 10] = _h_57;
      e.mem[_t_20 + 11] = _h_58;
      e.mem[_t_20 + 12] = _h_59;
      e.mem[_t_20 + 13] = _h_60;
      e.mem[_t_20 + 14] = _h_61;
      e.mem[_t_20 + 15] = _h_62;
      e.mem[_t_20 + 16] = _h_63;
      e.mem[_t_20 + 17] = _h_56;
      WL_CONT = term_tsk(FID_APPLIED_K213, _t_20);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_21 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _result_164;
      return term_tsk(FID_NAT_SHOW, _t_21);
    }
    r0 = _result_164;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K213)
  {
    WL_POPN(18);
    Term _result_173 = STK(0);
    Term _result_174 = STK(1);
    u32 _result_175 = STK(2);
    Term _result_176 = STK(3);
    u32 _result_177 = STK(4);
    u32 _result_178 = STK(5);
    u32 _result_179 = STK(6);
    u32 _result_180 = STK(7);
    u32 _result_181 = STK(8);
    u32 _result_182 = STK(9);
    Term _h_65 = STK(10);
    Term _h_66 = STK(11);
    Term _h_67 = STK(12);
    Term _h_68 = STK(13);
    Term _h_69 = STK(14);
    Term _h_70 = STK(15);
    Term _h_71 = STK(16);
    Term _h_72 = STK(17);
    Term _h_64 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _result_173;
      STK(1) = _result_174;
      STK(2) = _result_176;
      STK(3) = _result_177;
      STK(4) = _result_178;
      STK(5) = _result_179;
      STK(6) = _result_180;
      STK(7) = _result_181;
      STK(8) = _result_182;
      STK(9) = _h_65;
      STK(10) = _h_66;
      STK(11) = _h_67;
      STK(12) = _h_68;
      STK(13) = _h_69;
      STK(14) = _h_70;
      STK(15) = _h_71;
      STK(16) = _h_72;
      STK(17) = _h_64;
      STK(18) = FID_APPLIED_K214;
      WL_PUSHN(19);
    } else {
      u64 _t_22 = task_node(e, FID_APPLIED_K214, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _result_173;
      e.mem[_t_22 + 1] = _result_174;
      e.mem[_t_22 + 2] = _result_176;
      e.mem[_t_22 + 3] = _result_177;
      e.mem[_t_22 + 4] = _result_178;
      e.mem[_t_22 + 5] = _result_179;
      e.mem[_t_22 + 6] = _result_180;
      e.mem[_t_22 + 7] = _result_181;
      e.mem[_t_22 + 8] = _result_182;
      e.mem[_t_22 + 9] = _h_65;
      e.mem[_t_22 + 10] = _h_66;
      e.mem[_t_22 + 11] = _h_67;
      e.mem[_t_22 + 12] = _h_68;
      e.mem[_t_22 + 13] = _h_69;
      e.mem[_t_22 + 14] = _h_70;
      e.mem[_t_22 + 15] = _h_71;
      e.mem[_t_22 + 16] = _h_72;
      e.mem[_t_22 + 17] = _h_64;
      WL_CONT = term_tsk(FID_APPLIED_K214, _t_22);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_23 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _result_175;
      return term_tsk(FID_U32_SHOW, _t_23);
    }
    r0 = _result_175;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K214)
  {
    WL_POPN(18);
    Term _result_183 = STK(0);
    Term _result_184 = STK(1);
    Term _result_185 = STK(2);
    u32 _result_186 = STK(3);
    u32 _result_187 = STK(4);
    u32 _result_188 = STK(5);
    u32 _result_189 = STK(6);
    u32 _result_190 = STK(7);
    u32 _result_191 = STK(8);
    Term _h_74 = STK(9);
    Term _h_75 = STK(10);
    Term _h_76 = STK(11);
    Term _h_77 = STK(12);
    Term _h_78 = STK(13);
    Term _h_79 = STK(14);
    Term _h_80 = STK(15);
    Term _h_81 = STK(16);
    Term _h_82 = STK(17);
    Term _h_73 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_183;
      STK(1) = _result_184;
      STK(2) = _result_185;
      STK(3) = _result_186;
      STK(4) = _result_187;
      STK(5) = _result_188;
      STK(6) = _result_189;
      STK(7) = _result_190;
      STK(8) = _result_191;
      STK(9) = _h_74;
      STK(10) = _h_75;
      STK(11) = _h_76;
      STK(12) = _h_77;
      STK(13) = _h_78;
      STK(14) = _h_79;
      STK(15) = _h_80;
      STK(16) = _h_81;
      STK(17) = _h_82;
      STK(18) = _h_73;
      STK(19) = FID_APPLIED_K215;
      WL_PUSHN(20);
    } else {
      u64 _t_24 = task_node(e, FID_APPLIED_K215, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _result_183;
      e.mem[_t_24 + 1] = _result_184;
      e.mem[_t_24 + 2] = _result_185;
      e.mem[_t_24 + 3] = _result_186;
      e.mem[_t_24 + 4] = _result_187;
      e.mem[_t_24 + 5] = _result_188;
      e.mem[_t_24 + 6] = _result_189;
      e.mem[_t_24 + 7] = _result_190;
      e.mem[_t_24 + 8] = _result_191;
      e.mem[_t_24 + 9] = _h_74;
      e.mem[_t_24 + 10] = _h_75;
      e.mem[_t_24 + 11] = _h_76;
      e.mem[_t_24 + 12] = _h_77;
      e.mem[_t_24 + 13] = _h_78;
      e.mem[_t_24 + 14] = _h_79;
      e.mem[_t_24 + 15] = _h_80;
      e.mem[_t_24 + 16] = _h_81;
      e.mem[_t_24 + 17] = _h_82;
      e.mem[_t_24 + 18] = _h_73;
      WL_CONT = term_tsk(FID_APPLIED_K215, _t_24);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_25 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = 0ull;
      return term_tsk(FID_U32_SHOW, _t_25);
    }
    r0 = 0ull;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K215)
  {
    WL_POPN(19);
    Term _result_192 = STK(0);
    Term _result_193 = STK(1);
    Term _result_194 = STK(2);
    u32 _result_195 = STK(3);
    u32 _result_196 = STK(4);
    u32 _result_197 = STK(5);
    u32 _result_198 = STK(6);
    u32 _result_199 = STK(7);
    u32 _result_200 = STK(8);
    Term _h_84 = STK(9);
    Term _h_85 = STK(10);
    Term _h_86 = STK(11);
    Term _h_87 = STK(12);
    Term _h_88 = STK(13);
    Term _h_89 = STK(14);
    Term _h_90 = STK(15);
    Term _h_91 = STK(16);
    Term _h_92 = STK(17);
    Term _h_93 = STK(18);
    Term _h_83 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_193;
      STK(1) = _result_194;
      STK(2) = _result_195;
      STK(3) = _result_196;
      STK(4) = _result_197;
      STK(5) = _result_198;
      STK(6) = _result_199;
      STK(7) = _result_200;
      STK(8) = _h_84;
      STK(9) = _h_85;
      STK(10) = _h_86;
      STK(11) = _h_87;
      STK(12) = _h_88;
      STK(13) = _h_89;
      STK(14) = _h_90;
      STK(15) = _h_91;
      STK(16) = _h_92;
      STK(17) = _h_93;
      STK(18) = _h_83;
      STK(19) = FID_APPLIED_K216;
      WL_PUSHN(20);
    } else {
      u64 _t_26 = task_node(e, FID_APPLIED_K216, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _result_193;
      e.mem[_t_26 + 1] = _result_194;
      e.mem[_t_26 + 2] = _result_195;
      e.mem[_t_26 + 3] = _result_196;
      e.mem[_t_26 + 4] = _result_197;
      e.mem[_t_26 + 5] = _result_198;
      e.mem[_t_26 + 6] = _result_199;
      e.mem[_t_26 + 7] = _result_200;
      e.mem[_t_26 + 8] = _h_84;
      e.mem[_t_26 + 9] = _h_85;
      e.mem[_t_26 + 10] = _h_86;
      e.mem[_t_26 + 11] = _h_87;
      e.mem[_t_26 + 12] = _h_88;
      e.mem[_t_26 + 13] = _h_89;
      e.mem[_t_26 + 14] = _h_90;
      e.mem[_t_26 + 15] = _h_91;
      e.mem[_t_26 + 16] = _h_92;
      e.mem[_t_26 + 17] = _h_93;
      e.mem[_t_26 + 18] = _h_83;
      WL_CONT = term_tsk(FID_APPLIED_K216, _t_26);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_27 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _result_192;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_27);
    }
    r0 = _result_192;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K216)
  {
    WL_POPN(19);
    Term _result_201 = STK(0);
    Term _result_202 = STK(1);
    u32 _result_203 = STK(2);
    u32 _result_204 = STK(3);
    u32 _result_205 = STK(4);
    u32 _result_206 = STK(5);
    u32 _result_207 = STK(6);
    u32 _result_208 = STK(7);
    Term _h_95 = STK(8);
    Term _h_96 = STK(9);
    Term _h_97 = STK(10);
    Term _h_98 = STK(11);
    Term _h_99 = STK(12);
    Term _h_100 = STK(13);
    Term _h_101 = STK(14);
    Term _h_102 = STK(15);
    Term _h_103 = STK(16);
    Term _h_104 = STK(17);
    Term _h_105 = STK(18);
    Term _h_94 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_201;
      STK(1) = _result_202;
      STK(2) = _result_203;
      STK(3) = _result_204;
      STK(4) = _result_205;
      STK(5) = _result_206;
      STK(6) = _result_207;
      STK(7) = _result_208;
      STK(8) = _h_95;
      STK(9) = _h_96;
      STK(10) = _h_97;
      STK(11) = _h_98;
      STK(12) = _h_99;
      STK(13) = _h_100;
      STK(14) = _h_101;
      STK(15) = _h_102;
      STK(16) = _h_103;
      STK(17) = _h_104;
      STK(18) = _h_105;
      STK(19) = FID_APPLIED_K217;
      WL_PUSHN(20);
    } else {
      u64 _t_28 = task_node(e, FID_APPLIED_K217, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _result_201;
      e.mem[_t_28 + 1] = _result_202;
      e.mem[_t_28 + 2] = _result_203;
      e.mem[_t_28 + 3] = _result_204;
      e.mem[_t_28 + 4] = _result_205;
      e.mem[_t_28 + 5] = _result_206;
      e.mem[_t_28 + 6] = _result_207;
      e.mem[_t_28 + 7] = _result_208;
      e.mem[_t_28 + 8] = _h_95;
      e.mem[_t_28 + 9] = _h_96;
      e.mem[_t_28 + 10] = _h_97;
      e.mem[_t_28 + 11] = _h_98;
      e.mem[_t_28 + 12] = _h_99;
      e.mem[_t_28 + 13] = _h_100;
      e.mem[_t_28 + 14] = _h_101;
      e.mem[_t_28 + 15] = _h_102;
      e.mem[_t_28 + 16] = _h_103;
      e.mem[_t_28 + 17] = _h_104;
      e.mem[_t_28 + 18] = _h_105;
      WL_CONT = term_tsk(FID_APPLIED_K217, _t_28);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_29 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _h_94;
      return term_tsk(FID_DATA, _t_29);
    }
    r0 = _h_94;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K217)
  {
    WL_POPN(19);
    Term _result_209 = STK(0);
    Term _result_210 = STK(1);
    u32 _result_211 = STK(2);
    u32 _result_212 = STK(3);
    u32 _result_213 = STK(4);
    u32 _result_214 = STK(5);
    u32 _result_215 = STK(6);
    u32 _result_216 = STK(7);
    Term _h_107 = STK(8);
    Term _h_108 = STK(9);
    Term _h_109 = STK(10);
    Term _h_110 = STK(11);
    Term _h_111 = STK(12);
    Term _h_112 = STK(13);
    Term _h_113 = STK(14);
    Term _h_114 = STK(15);
    Term _h_115 = STK(16);
    Term _h_116 = STK(17);
    Term _h_117 = STK(18);
    Term _h_106 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_209;
      STK(1) = _result_210;
      STK(2) = _result_211;
      STK(3) = _result_212;
      STK(4) = _result_213;
      STK(5) = _result_214;
      STK(6) = _result_215;
      STK(7) = _result_216;
      STK(8) = _h_107;
      STK(9) = _h_108;
      STK(10) = _h_109;
      STK(11) = _h_110;
      STK(12) = _h_111;
      STK(13) = _h_112;
      STK(14) = _h_113;
      STK(15) = _h_114;
      STK(16) = _h_115;
      STK(17) = _h_116;
      STK(18) = _h_117;
      STK(19) = FID_APPLIED_K218;
      WL_PUSHN(20);
    } else {
      u64 _t_30 = task_node(e, FID_APPLIED_K218, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _result_209;
      e.mem[_t_30 + 1] = _result_210;
      e.mem[_t_30 + 2] = _result_211;
      e.mem[_t_30 + 3] = _result_212;
      e.mem[_t_30 + 4] = _result_213;
      e.mem[_t_30 + 5] = _result_214;
      e.mem[_t_30 + 6] = _result_215;
      e.mem[_t_30 + 7] = _result_216;
      e.mem[_t_30 + 8] = _h_107;
      e.mem[_t_30 + 9] = _h_108;
      e.mem[_t_30 + 10] = _h_109;
      e.mem[_t_30 + 11] = _h_110;
      e.mem[_t_30 + 12] = _h_111;
      e.mem[_t_30 + 13] = _h_112;
      e.mem[_t_30 + 14] = _h_113;
      e.mem[_t_30 + 15] = _h_114;
      e.mem[_t_30 + 16] = _h_115;
      e.mem[_t_30 + 17] = _h_116;
      e.mem[_t_30 + 18] = _h_117;
      WL_CONT = term_tsk(FID_APPLIED_K218, _t_30);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_31 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_106;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_31);
    }
    r0 = _h_106;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K218)
  {
    WL_POPN(19);
    Term _result_217 = STK(0);
    Term _result_218 = STK(1);
    u32 _result_219 = STK(2);
    u32 _result_220 = STK(3);
    u32 _result_221 = STK(4);
    u32 _result_222 = STK(5);
    u32 _result_223 = STK(6);
    u32 _result_224 = STK(7);
    Term _h_119 = STK(8);
    Term _h_120 = STK(9);
    Term _h_121 = STK(10);
    Term _h_122 = STK(11);
    Term _h_123 = STK(12);
    Term _h_124 = STK(13);
    Term _h_125 = STK(14);
    Term _h_126 = STK(15);
    Term _h_127 = STK(16);
    Term _h_128 = STK(17);
    Term _h_129 = STK(18);
    Term _h_118 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_218;
      STK(1) = _result_219;
      STK(2) = _result_220;
      STK(3) = _result_221;
      STK(4) = _result_222;
      STK(5) = _result_223;
      STK(6) = _result_224;
      STK(7) = _h_119;
      STK(8) = _h_120;
      STK(9) = _h_121;
      STK(10) = _h_122;
      STK(11) = _h_123;
      STK(12) = _h_124;
      STK(13) = _h_125;
      STK(14) = _h_126;
      STK(15) = _h_127;
      STK(16) = _h_128;
      STK(17) = _h_129;
      STK(18) = _h_118;
      STK(19) = FID_APPLIED_K219;
      WL_PUSHN(20);
    } else {
      u64 _t_32 = task_node(e, FID_APPLIED_K219, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _result_218;
      e.mem[_t_32 + 1] = _result_219;
      e.mem[_t_32 + 2] = _result_220;
      e.mem[_t_32 + 3] = _result_221;
      e.mem[_t_32 + 4] = _result_222;
      e.mem[_t_32 + 5] = _result_223;
      e.mem[_t_32 + 6] = _result_224;
      e.mem[_t_32 + 7] = _h_119;
      e.mem[_t_32 + 8] = _h_120;
      e.mem[_t_32 + 9] = _h_121;
      e.mem[_t_32 + 10] = _h_122;
      e.mem[_t_32 + 11] = _h_123;
      e.mem[_t_32 + 12] = _h_124;
      e.mem[_t_32 + 13] = _h_125;
      e.mem[_t_32 + 14] = _h_126;
      e.mem[_t_32 + 15] = _h_127;
      e.mem[_t_32 + 16] = _h_128;
      e.mem[_t_32 + 17] = _h_129;
      e.mem[_t_32 + 18] = _h_118;
      WL_CONT = term_tsk(FID_APPLIED_K219, _t_32);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_33 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _result_217;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_33);
    }
    r0 = _result_217;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K219)
  {
    WL_POPN(19);
    Term _result_225 = STK(0);
    u32 _result_226 = STK(1);
    u32 _result_227 = STK(2);
    u32 _result_228 = STK(3);
    u32 _result_229 = STK(4);
    u32 _result_230 = STK(5);
    u32 _result_231 = STK(6);
    Term _h_131 = STK(7);
    Term _h_132 = STK(8);
    Term _h_133 = STK(9);
    Term _h_134 = STK(10);
    Term _h_135 = STK(11);
    Term _h_136 = STK(12);
    Term _h_137 = STK(13);
    Term _h_138 = STK(14);
    Term _h_139 = STK(15);
    Term _h_140 = STK(16);
    Term _h_141 = STK(17);
    Term _h_142 = STK(18);
    Term _h_130 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_225;
      STK(1) = _result_226;
      STK(2) = _result_227;
      STK(3) = _result_228;
      STK(4) = _result_229;
      STK(5) = _result_230;
      STK(6) = _result_231;
      STK(7) = _h_131;
      STK(8) = _h_132;
      STK(9) = _h_133;
      STK(10) = _h_134;
      STK(11) = _h_135;
      STK(12) = _h_136;
      STK(13) = _h_137;
      STK(14) = _h_138;
      STK(15) = _h_139;
      STK(16) = _h_140;
      STK(17) = _h_141;
      STK(18) = _h_142;
      STK(19) = FID_APPLIED_K220;
      WL_PUSHN(20);
    } else {
      u64 _t_34 = task_node(e, FID_APPLIED_K220, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _result_225;
      e.mem[_t_34 + 1] = _result_226;
      e.mem[_t_34 + 2] = _result_227;
      e.mem[_t_34 + 3] = _result_228;
      e.mem[_t_34 + 4] = _result_229;
      e.mem[_t_34 + 5] = _result_230;
      e.mem[_t_34 + 6] = _result_231;
      e.mem[_t_34 + 7] = _h_131;
      e.mem[_t_34 + 8] = _h_132;
      e.mem[_t_34 + 9] = _h_133;
      e.mem[_t_34 + 10] = _h_134;
      e.mem[_t_34 + 11] = _h_135;
      e.mem[_t_34 + 12] = _h_136;
      e.mem[_t_34 + 13] = _h_137;
      e.mem[_t_34 + 14] = _h_138;
      e.mem[_t_34 + 15] = _h_139;
      e.mem[_t_34 + 16] = _h_140;
      e.mem[_t_34 + 17] = _h_141;
      e.mem[_t_34 + 18] = _h_142;
      WL_CONT = term_tsk(FID_APPLIED_K220, _t_34);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_35 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _h_130;
      return term_tsk(FID_DATA, _t_35);
    }
    r0 = _h_130;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K220)
  {
    WL_POPN(19);
    Term _result_232 = STK(0);
    u32 _result_233 = STK(1);
    u32 _result_234 = STK(2);
    u32 _result_235 = STK(3);
    u32 _result_236 = STK(4);
    u32 _result_237 = STK(5);
    u32 _result_238 = STK(6);
    Term _h_144 = STK(7);
    Term _h_145 = STK(8);
    Term _h_146 = STK(9);
    Term _h_147 = STK(10);
    Term _h_148 = STK(11);
    Term _h_149 = STK(12);
    Term _h_150 = STK(13);
    Term _h_151 = STK(14);
    Term _h_152 = STK(15);
    Term _h_153 = STK(16);
    Term _h_154 = STK(17);
    Term _h_155 = STK(18);
    Term _h_143 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_232;
      STK(1) = _result_233;
      STK(2) = _result_234;
      STK(3) = _result_235;
      STK(4) = _result_236;
      STK(5) = _result_237;
      STK(6) = _result_238;
      STK(7) = _h_144;
      STK(8) = _h_145;
      STK(9) = _h_146;
      STK(10) = _h_147;
      STK(11) = _h_148;
      STK(12) = _h_149;
      STK(13) = _h_150;
      STK(14) = _h_151;
      STK(15) = _h_152;
      STK(16) = _h_153;
      STK(17) = _h_154;
      STK(18) = _h_155;
      STK(19) = FID_APPLIED_K221;
      WL_PUSHN(20);
    } else {
      u64 _t_36 = task_node(e, FID_APPLIED_K221, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _result_232;
      e.mem[_t_36 + 1] = _result_233;
      e.mem[_t_36 + 2] = _result_234;
      e.mem[_t_36 + 3] = _result_235;
      e.mem[_t_36 + 4] = _result_236;
      e.mem[_t_36 + 5] = _result_237;
      e.mem[_t_36 + 6] = _result_238;
      e.mem[_t_36 + 7] = _h_144;
      e.mem[_t_36 + 8] = _h_145;
      e.mem[_t_36 + 9] = _h_146;
      e.mem[_t_36 + 10] = _h_147;
      e.mem[_t_36 + 11] = _h_148;
      e.mem[_t_36 + 12] = _h_149;
      e.mem[_t_36 + 13] = _h_150;
      e.mem[_t_36 + 14] = _h_151;
      e.mem[_t_36 + 15] = _h_152;
      e.mem[_t_36 + 16] = _h_153;
      e.mem[_t_36 + 17] = _h_154;
      e.mem[_t_36 + 18] = _h_155;
      WL_CONT = term_tsk(FID_APPLIED_K221, _t_36);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_37 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _h_143;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_37);
    }
    r0 = _h_143;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K221)
  {
    WL_POPN(19);
    Term _result_239 = STK(0);
    u32 _result_240 = STK(1);
    u32 _result_241 = STK(2);
    u32 _result_242 = STK(3);
    u32 _result_243 = STK(4);
    u32 _result_244 = STK(5);
    u32 _result_245 = STK(6);
    Term _h_157 = STK(7);
    Term _h_158 = STK(8);
    Term _h_159 = STK(9);
    Term _h_160 = STK(10);
    Term _h_161 = STK(11);
    Term _h_162 = STK(12);
    Term _h_163 = STK(13);
    Term _h_164 = STK(14);
    Term _h_165 = STK(15);
    Term _h_166 = STK(16);
    Term _h_167 = STK(17);
    Term _h_168 = STK(18);
    Term _h_156 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_240;
      STK(1) = _result_241;
      STK(2) = _result_242;
      STK(3) = _result_243;
      STK(4) = _result_244;
      STK(5) = _result_245;
      STK(6) = _h_157;
      STK(7) = _h_158;
      STK(8) = _h_159;
      STK(9) = _h_160;
      STK(10) = _h_161;
      STK(11) = _h_162;
      STK(12) = _h_163;
      STK(13) = _h_164;
      STK(14) = _h_165;
      STK(15) = _h_166;
      STK(16) = _h_167;
      STK(17) = _h_168;
      STK(18) = _h_156;
      STK(19) = FID_APPLIED_K222;
      WL_PUSHN(20);
    } else {
      u64 _t_38 = task_node(e, FID_APPLIED_K222, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _result_240;
      e.mem[_t_38 + 1] = _result_241;
      e.mem[_t_38 + 2] = _result_242;
      e.mem[_t_38 + 3] = _result_243;
      e.mem[_t_38 + 4] = _result_244;
      e.mem[_t_38 + 5] = _result_245;
      e.mem[_t_38 + 6] = _h_157;
      e.mem[_t_38 + 7] = _h_158;
      e.mem[_t_38 + 8] = _h_159;
      e.mem[_t_38 + 9] = _h_160;
      e.mem[_t_38 + 10] = _h_161;
      e.mem[_t_38 + 11] = _h_162;
      e.mem[_t_38 + 12] = _h_163;
      e.mem[_t_38 + 13] = _h_164;
      e.mem[_t_38 + 14] = _h_165;
      e.mem[_t_38 + 15] = _h_166;
      e.mem[_t_38 + 16] = _h_167;
      e.mem[_t_38 + 17] = _h_168;
      e.mem[_t_38 + 18] = _h_156;
      WL_CONT = term_tsk(FID_APPLIED_K222, _t_38);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARRAY_TO_LIST_0)) {
      u64 _t_39 = task_node(e, FID_ARRAY_TO_LIST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _result_239;
      return term_tsk(FID_ARRAY_TO_LIST_0, _t_39);
    }
    r0 = _result_239;
    WL_JMP(FID_ARRAY_TO_LIST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K222)
  {
    WL_POPN(19);
    u32 _result_246 = STK(0);
    u32 _result_247 = STK(1);
    u32 _result_248 = STK(2);
    u32 _result_249 = STK(3);
    u32 _result_250 = STK(4);
    u32 _result_251 = STK(5);
    Term _h_170 = STK(6);
    Term _h_171 = STK(7);
    Term _h_172 = STK(8);
    Term _h_173 = STK(9);
    Term _h_174 = STK(10);
    Term _h_175 = STK(11);
    Term _h_176 = STK(12);
    Term _h_177 = STK(13);
    Term _h_178 = STK(14);
    Term _h_179 = STK(15);
    Term _h_180 = STK(16);
    Term _h_181 = STK(17);
    Term _h_182 = STK(18);
    Term _h_169 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_246;
      STK(1) = _result_247;
      STK(2) = _result_248;
      STK(3) = _result_249;
      STK(4) = _result_250;
      STK(5) = _result_251;
      STK(6) = _h_170;
      STK(7) = _h_171;
      STK(8) = _h_172;
      STK(9) = _h_173;
      STK(10) = _h_174;
      STK(11) = _h_175;
      STK(12) = _h_176;
      STK(13) = _h_177;
      STK(14) = _h_178;
      STK(15) = _h_179;
      STK(16) = _h_180;
      STK(17) = _h_181;
      STK(18) = _h_182;
      STK(19) = FID_APPLIED_K223;
      WL_PUSHN(20);
    } else {
      u64 _t_40 = task_node(e, FID_APPLIED_K223, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _result_246;
      e.mem[_t_40 + 1] = _result_247;
      e.mem[_t_40 + 2] = _result_248;
      e.mem[_t_40 + 3] = _result_249;
      e.mem[_t_40 + 4] = _result_250;
      e.mem[_t_40 + 5] = _result_251;
      e.mem[_t_40 + 6] = _h_170;
      e.mem[_t_40 + 7] = _h_171;
      e.mem[_t_40 + 8] = _h_172;
      e.mem[_t_40 + 9] = _h_173;
      e.mem[_t_40 + 10] = _h_174;
      e.mem[_t_40 + 11] = _h_175;
      e.mem[_t_40 + 12] = _h_176;
      e.mem[_t_40 + 13] = _h_177;
      e.mem[_t_40 + 14] = _h_178;
      e.mem[_t_40 + 15] = _h_179;
      e.mem[_t_40 + 16] = _h_180;
      e.mem[_t_40 + 17] = _h_181;
      e.mem[_t_40 + 18] = _h_182;
      WL_CONT = term_tsk(FID_APPLIED_K223, _t_40);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_DATA)) {
      u64 _t_41 = task_node(e, FID_DATA, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = _h_169;
      return term_tsk(FID_DATA, _t_41);
    }
    r0 = _h_169;
    WL_JMP(FID_DATA);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K223)
  {
    WL_POPN(19);
    u32 _result_252 = STK(0);
    u32 _result_253 = STK(1);
    u32 _result_254 = STK(2);
    u32 _result_255 = STK(3);
    u32 _result_256 = STK(4);
    u32 _result_257 = STK(5);
    Term _h_184 = STK(6);
    Term _h_185 = STK(7);
    Term _h_186 = STK(8);
    Term _h_187 = STK(9);
    Term _h_188 = STK(10);
    Term _h_189 = STK(11);
    Term _h_190 = STK(12);
    Term _h_191 = STK(13);
    Term _h_192 = STK(14);
    Term _h_193 = STK(15);
    Term _h_194 = STK(16);
    Term _h_195 = STK(17);
    Term _h_196 = STK(18);
    Term _h_183 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_252;
      STK(1) = _result_253;
      STK(2) = _result_254;
      STK(3) = _result_255;
      STK(4) = _result_256;
      STK(5) = _result_257;
      STK(6) = _h_184;
      STK(7) = _h_185;
      STK(8) = _h_186;
      STK(9) = _h_187;
      STK(10) = _h_188;
      STK(11) = _h_189;
      STK(12) = _h_190;
      STK(13) = _h_191;
      STK(14) = _h_192;
      STK(15) = _h_193;
      STK(16) = _h_194;
      STK(17) = _h_195;
      STK(18) = _h_196;
      STK(19) = FID_APPLIED_K224;
      WL_PUSHN(20);
    } else {
      u64 _t_42 = task_node(e, FID_APPLIED_K224, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _result_252;
      e.mem[_t_42 + 1] = _result_253;
      e.mem[_t_42 + 2] = _result_254;
      e.mem[_t_42 + 3] = _result_255;
      e.mem[_t_42 + 4] = _result_256;
      e.mem[_t_42 + 5] = _result_257;
      e.mem[_t_42 + 6] = _h_184;
      e.mem[_t_42 + 7] = _h_185;
      e.mem[_t_42 + 8] = _h_186;
      e.mem[_t_42 + 9] = _h_187;
      e.mem[_t_42 + 10] = _h_188;
      e.mem[_t_42 + 11] = _h_189;
      e.mem[_t_42 + 12] = _h_190;
      e.mem[_t_42 + 13] = _h_191;
      e.mem[_t_42 + 14] = _h_192;
      e.mem[_t_42 + 15] = _h_193;
      e.mem[_t_42 + 16] = _h_194;
      e.mem[_t_42 + 17] = _h_195;
      e.mem[_t_42 + 18] = _h_196;
      WL_CONT = term_tsk(FID_APPLIED_K224, _t_42);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LIST_16)) {
      u64 _t_43 = task_node(e, FID_HOST_RENDER_RENDER_LIST_16, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _h_183;
      return term_tsk(FID_HOST_RENDER_RENDER_LIST_16, _t_43);
    }
    r0 = _h_183;
    WL_JMP(FID_HOST_RENDER_RENDER_LIST_16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K224)
  {
    WL_POPN(19);
    u32 _result_258 = STK(0);
    u32 _result_259 = STK(1);
    u32 _result_260 = STK(2);
    u32 _result_261 = STK(3);
    u32 _result_262 = STK(4);
    u32 _result_263 = STK(5);
    Term _h_198 = STK(6);
    Term _h_199 = STK(7);
    Term _h_200 = STK(8);
    Term _h_201 = STK(9);
    Term _h_202 = STK(10);
    Term _h_203 = STK(11);
    Term _h_204 = STK(12);
    Term _h_205 = STK(13);
    Term _h_206 = STK(14);
    Term _h_207 = STK(15);
    Term _h_208 = STK(16);
    Term _h_209 = STK(17);
    Term _h_210 = STK(18);
    Term _h_197 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_259;
      STK(1) = _result_260;
      STK(2) = _result_261;
      STK(3) = _result_262;
      STK(4) = _result_263;
      STK(5) = _h_198;
      STK(6) = _h_199;
      STK(7) = _h_200;
      STK(8) = _h_201;
      STK(9) = _h_202;
      STK(10) = _h_203;
      STK(11) = _h_204;
      STK(12) = _h_205;
      STK(13) = _h_206;
      STK(14) = _h_207;
      STK(15) = _h_208;
      STK(16) = _h_209;
      STK(17) = _h_210;
      STK(18) = _h_197;
      STK(19) = FID_APPLIED_K225;
      WL_PUSHN(20);
    } else {
      u64 _t_44 = task_node(e, FID_APPLIED_K225, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _result_259;
      e.mem[_t_44 + 1] = _result_260;
      e.mem[_t_44 + 2] = _result_261;
      e.mem[_t_44 + 3] = _result_262;
      e.mem[_t_44 + 4] = _result_263;
      e.mem[_t_44 + 5] = _h_198;
      e.mem[_t_44 + 6] = _h_199;
      e.mem[_t_44 + 7] = _h_200;
      e.mem[_t_44 + 8] = _h_201;
      e.mem[_t_44 + 9] = _h_202;
      e.mem[_t_44 + 10] = _h_203;
      e.mem[_t_44 + 11] = _h_204;
      e.mem[_t_44 + 12] = _h_205;
      e.mem[_t_44 + 13] = _h_206;
      e.mem[_t_44 + 14] = _h_207;
      e.mem[_t_44 + 15] = _h_208;
      e.mem[_t_44 + 16] = _h_209;
      e.mem[_t_44 + 17] = _h_210;
      e.mem[_t_44 + 18] = _h_197;
      WL_CONT = term_tsk(FID_APPLIED_K225, _t_44);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_45 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _result_258;
      return term_tsk(FID_U32_SHOW, _t_45);
    }
    r0 = _result_258;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K225)
  {
    WL_POPN(19);
    u32 _result_264 = STK(0);
    u32 _result_265 = STK(1);
    u32 _result_266 = STK(2);
    u32 _result_267 = STK(3);
    u32 _result_268 = STK(4);
    Term _h_212 = STK(5);
    Term _h_213 = STK(6);
    Term _h_214 = STK(7);
    Term _h_215 = STK(8);
    Term _h_216 = STK(9);
    Term _h_217 = STK(10);
    Term _h_218 = STK(11);
    Term _h_219 = STK(12);
    Term _h_220 = STK(13);
    Term _h_221 = STK(14);
    Term _h_222 = STK(15);
    Term _h_223 = STK(16);
    Term _h_224 = STK(17);
    Term _h_225 = STK(18);
    Term _h_211 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_212;
      STK(1) = _h_213;
      STK(2) = _h_214;
      STK(3) = _h_215;
      STK(4) = _h_216;
      STK(5) = _h_217;
      STK(6) = _h_218;
      STK(7) = _h_219;
      STK(8) = _h_220;
      STK(9) = _h_221;
      STK(10) = _h_222;
      STK(11) = _h_223;
      STK(12) = _h_224;
      STK(13) = _h_225;
      STK(14) = _h_211;
      STK(15) = FID_APPLIED_K226;
      WL_PUSHN(16);
    } else {
      u64 _t_46 = task_node(e, FID_APPLIED_K226, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_212;
      e.mem[_t_46 + 1] = _h_213;
      e.mem[_t_46 + 2] = _h_214;
      e.mem[_t_46 + 3] = _h_215;
      e.mem[_t_46 + 4] = _h_216;
      e.mem[_t_46 + 5] = _h_217;
      e.mem[_t_46 + 6] = _h_218;
      e.mem[_t_46 + 7] = _h_219;
      e.mem[_t_46 + 8] = _h_220;
      e.mem[_t_46 + 9] = _h_221;
      e.mem[_t_46 + 10] = _h_222;
      e.mem[_t_46 + 11] = _h_223;
      e.mem[_t_46 + 12] = _h_224;
      e.mem[_t_46 + 13] = _h_225;
      e.mem[_t_46 + 14] = _h_211;
      WL_CONT = term_tsk(FID_APPLIED_K226, _t_46);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HOST_RENDER_RENDER_LEDGER)) {
      u64 _t_47 = task_node(e, FID_HOST_RENDER_RENDER_LEDGER, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _result_264;
      e.mem[_t_47 + 1] = _result_265;
      e.mem[_t_47 + 2] = _result_266;
      e.mem[_t_47 + 3] = _result_267;
      e.mem[_t_47 + 4] = _result_268;
      return term_tsk(FID_HOST_RENDER_RENDER_LEDGER, _t_47);
    }
    r0 = _result_264;
    r1 = _result_265;
    r2 = _result_266;
    r3 = _result_267;
    r4 = _result_268;
    WL_JMP(FID_HOST_RENDER_RENDER_LEDGER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K226)
  {
    WL_POPN(15);
    Term _h_227 = STK(0);
    Term _h_228 = STK(1);
    Term _h_229 = STK(2);
    Term _h_230 = STK(3);
    Term _h_231 = STK(4);
    Term _h_232 = STK(5);
    Term _h_233 = STK(6);
    Term _h_234 = STK(7);
    Term _h_235 = STK(8);
    Term _h_236 = STK(9);
    Term _h_237 = STK(10);
    Term _h_238 = STK(11);
    Term _h_239 = STK(12);
    Term _h_240 = STK(13);
    Term _h_241 = STK(14);
    Term _h_226 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_227;
      STK(1) = _h_228;
      STK(2) = _h_229;
      STK(3) = _h_230;
      STK(4) = _h_231;
      STK(5) = _h_232;
      STK(6) = _h_233;
      STK(7) = _h_234;
      STK(8) = _h_235;
      STK(9) = _h_236;
      STK(10) = _h_237;
      STK(11) = _h_238;
      STK(12) = _h_239;
      STK(13) = _h_240;
      STK(14) = _h_241;
      STK(15) = FID_APPLIED_K227;
      WL_PUSHN(16);
    } else {
      u64 _t_48 = task_node(e, FID_APPLIED_K227, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_227;
      e.mem[_t_48 + 1] = _h_228;
      e.mem[_t_48 + 2] = _h_229;
      e.mem[_t_48 + 3] = _h_230;
      e.mem[_t_48 + 4] = _h_231;
      e.mem[_t_48 + 5] = _h_232;
      e.mem[_t_48 + 6] = _h_233;
      e.mem[_t_48 + 7] = _h_234;
      e.mem[_t_48 + 8] = _h_235;
      e.mem[_t_48 + 9] = _h_236;
      e.mem[_t_48 + 10] = _h_237;
      e.mem[_t_48 + 11] = _h_238;
      e.mem[_t_48 + 12] = _h_239;
      e.mem[_t_48 + 13] = _h_240;
      e.mem[_t_48 + 14] = _h_241;
      WL_CONT = term_tsk(FID_APPLIED_K227, _t_48);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = _h_226;
      e.mem[_t_49 + 1] = term_ctr(CID_SCON, STAT_OFF + 30);
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = _h_226;
    r1 = term_ctr(CID_SCON, STAT_OFF + 30);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K227)
  {
    WL_POPN(15);
    Term _h_243 = STK(0);
    Term _h_244 = STK(1);
    Term _h_245 = STK(2);
    Term _h_246 = STK(3);
    Term _h_247 = STK(4);
    Term _h_248 = STK(5);
    Term _h_249 = STK(6);
    Term _h_250 = STK(7);
    Term _h_251 = STK(8);
    Term _h_252 = STK(9);
    Term _h_253 = STK(10);
    Term _h_254 = STK(11);
    Term _h_255 = STK(12);
    Term _h_256 = STK(13);
    Term _h_257 = STK(14);
    Term _h_242 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_243;
      STK(1) = _h_244;
      STK(2) = _h_245;
      STK(3) = _h_246;
      STK(4) = _h_247;
      STK(5) = _h_248;
      STK(6) = _h_249;
      STK(7) = _h_250;
      STK(8) = _h_251;
      STK(9) = _h_252;
      STK(10) = _h_253;
      STK(11) = _h_254;
      STK(12) = _h_255;
      STK(13) = _h_256;
      STK(14) = _h_257;
      STK(15) = FID_APPLIED_K228;
      WL_PUSHN(16);
    } else {
      u64 _t_50 = task_node(e, FID_APPLIED_K228, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_243;
      e.mem[_t_50 + 1] = _h_244;
      e.mem[_t_50 + 2] = _h_245;
      e.mem[_t_50 + 3] = _h_246;
      e.mem[_t_50 + 4] = _h_247;
      e.mem[_t_50 + 5] = _h_248;
      e.mem[_t_50 + 6] = _h_249;
      e.mem[_t_50 + 7] = _h_250;
      e.mem[_t_50 + 8] = _h_251;
      e.mem[_t_50 + 9] = _h_252;
      e.mem[_t_50 + 10] = _h_253;
      e.mem[_t_50 + 11] = _h_254;
      e.mem[_t_50 + 12] = _h_255;
      e.mem[_t_50 + 13] = _h_256;
      e.mem[_t_50 + 14] = _h_257;
      WL_CONT = term_tsk(FID_APPLIED_K228, _t_50);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 134);
      e.mem[_t_51 + 1] = _h_242;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 134);
    r1 = _h_242;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K228)
  {
    WL_POPN(15);
    Term _h_259 = STK(0);
    Term _h_260 = STK(1);
    Term _h_261 = STK(2);
    Term _h_262 = STK(3);
    Term _h_263 = STK(4);
    Term _h_264 = STK(5);
    Term _h_265 = STK(6);
    Term _h_266 = STK(7);
    Term _h_267 = STK(8);
    Term _h_268 = STK(9);
    Term _h_269 = STK(10);
    Term _h_270 = STK(11);
    Term _h_271 = STK(12);
    Term _h_272 = STK(13);
    Term _h_273 = STK(14);
    Term _h_258 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_259;
      STK(1) = _h_260;
      STK(2) = _h_261;
      STK(3) = _h_262;
      STK(4) = _h_263;
      STK(5) = _h_264;
      STK(6) = _h_265;
      STK(7) = _h_266;
      STK(8) = _h_267;
      STK(9) = _h_268;
      STK(10) = _h_269;
      STK(11) = _h_270;
      STK(12) = _h_271;
      STK(13) = _h_272;
      STK(14) = FID_APPLIED_K229;
      WL_PUSHN(15);
    } else {
      u64 _t_52 = task_node(e, FID_APPLIED_K229, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_259;
      e.mem[_t_52 + 1] = _h_260;
      e.mem[_t_52 + 2] = _h_261;
      e.mem[_t_52 + 3] = _h_262;
      e.mem[_t_52 + 4] = _h_263;
      e.mem[_t_52 + 5] = _h_264;
      e.mem[_t_52 + 6] = _h_265;
      e.mem[_t_52 + 7] = _h_266;
      e.mem[_t_52 + 8] = _h_267;
      e.mem[_t_52 + 9] = _h_268;
      e.mem[_t_52 + 10] = _h_269;
      e.mem[_t_52 + 11] = _h_270;
      e.mem[_t_52 + 12] = _h_271;
      e.mem[_t_52 + 13] = _h_272;
      WL_CONT = term_tsk(FID_APPLIED_K229, _t_52);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = _h_273;
      e.mem[_t_53 + 1] = _h_258;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = _h_273;
    r1 = _h_258;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K229)
  {
    WL_POPN(14);
    Term _h_275 = STK(0);
    Term _h_276 = STK(1);
    Term _h_277 = STK(2);
    Term _h_278 = STK(3);
    Term _h_279 = STK(4);
    Term _h_280 = STK(5);
    Term _h_281 = STK(6);
    Term _h_282 = STK(7);
    Term _h_283 = STK(8);
    Term _h_284 = STK(9);
    Term _h_285 = STK(10);
    Term _h_286 = STK(11);
    Term _h_287 = STK(12);
    Term _h_288 = STK(13);
    Term _h_274 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_275;
      STK(1) = _h_276;
      STK(2) = _h_277;
      STK(3) = _h_278;
      STK(4) = _h_279;
      STK(5) = _h_280;
      STK(6) = _h_281;
      STK(7) = _h_282;
      STK(8) = _h_283;
      STK(9) = _h_284;
      STK(10) = _h_285;
      STK(11) = _h_286;
      STK(12) = _h_287;
      STK(13) = _h_288;
      STK(14) = FID_APPLIED_K230;
      WL_PUSHN(15);
    } else {
      u64 _t_54 = task_node(e, FID_APPLIED_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_275;
      e.mem[_t_54 + 1] = _h_276;
      e.mem[_t_54 + 2] = _h_277;
      e.mem[_t_54 + 3] = _h_278;
      e.mem[_t_54 + 4] = _h_279;
      e.mem[_t_54 + 5] = _h_280;
      e.mem[_t_54 + 6] = _h_281;
      e.mem[_t_54 + 7] = _h_282;
      e.mem[_t_54 + 8] = _h_283;
      e.mem[_t_54 + 9] = _h_284;
      e.mem[_t_54 + 10] = _h_285;
      e.mem[_t_54 + 11] = _h_286;
      e.mem[_t_54 + 12] = _h_287;
      e.mem[_t_54 + 13] = _h_288;
      WL_CONT = term_tsk(FID_APPLIED_K230, _t_54);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
      e.mem[_t_55 + 1] = _h_274;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 64);
    r1 = _h_274;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K230)
  {
    WL_POPN(14);
    Term _h_290 = STK(0);
    Term _h_291 = STK(1);
    Term _h_292 = STK(2);
    Term _h_293 = STK(3);
    Term _h_294 = STK(4);
    Term _h_295 = STK(5);
    Term _h_296 = STK(6);
    Term _h_297 = STK(7);
    Term _h_298 = STK(8);
    Term _h_299 = STK(9);
    Term _h_300 = STK(10);
    Term _h_301 = STK(11);
    Term _h_302 = STK(12);
    Term _h_303 = STK(13);
    Term _h_289 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_290;
      STK(1) = _h_291;
      STK(2) = _h_292;
      STK(3) = _h_293;
      STK(4) = _h_294;
      STK(5) = _h_295;
      STK(6) = _h_296;
      STK(7) = _h_297;
      STK(8) = _h_298;
      STK(9) = _h_299;
      STK(10) = _h_300;
      STK(11) = _h_301;
      STK(12) = _h_302;
      STK(13) = FID_APPLIED_K231;
      WL_PUSHN(14);
    } else {
      u64 _t_56 = task_node(e, FID_APPLIED_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_290;
      e.mem[_t_56 + 1] = _h_291;
      e.mem[_t_56 + 2] = _h_292;
      e.mem[_t_56 + 3] = _h_293;
      e.mem[_t_56 + 4] = _h_294;
      e.mem[_t_56 + 5] = _h_295;
      e.mem[_t_56 + 6] = _h_296;
      e.mem[_t_56 + 7] = _h_297;
      e.mem[_t_56 + 8] = _h_298;
      e.mem[_t_56 + 9] = _h_299;
      e.mem[_t_56 + 10] = _h_300;
      e.mem[_t_56 + 11] = _h_301;
      e.mem[_t_56 + 12] = _h_302;
      WL_CONT = term_tsk(FID_APPLIED_K231, _t_56);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _h_303;
      e.mem[_t_57 + 1] = _h_289;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = _h_303;
    r1 = _h_289;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K231)
  {
    WL_POPN(13);
    Term _h_305 = STK(0);
    Term _h_306 = STK(1);
    Term _h_307 = STK(2);
    Term _h_308 = STK(3);
    Term _h_309 = STK(4);
    Term _h_310 = STK(5);
    Term _h_311 = STK(6);
    Term _h_312 = STK(7);
    Term _h_313 = STK(8);
    Term _h_314 = STK(9);
    Term _h_315 = STK(10);
    Term _h_316 = STK(11);
    Term _h_317 = STK(12);
    Term _h_304 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_305;
      STK(1) = _h_306;
      STK(2) = _h_307;
      STK(3) = _h_308;
      STK(4) = _h_309;
      STK(5) = _h_310;
      STK(6) = _h_311;
      STK(7) = _h_312;
      STK(8) = _h_313;
      STK(9) = _h_314;
      STK(10) = _h_315;
      STK(11) = _h_316;
      STK(12) = _h_317;
      STK(13) = FID_APPLIED_K232;
      WL_PUSHN(14);
    } else {
      u64 _t_58 = task_node(e, FID_APPLIED_K232, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_305;
      e.mem[_t_58 + 1] = _h_306;
      e.mem[_t_58 + 2] = _h_307;
      e.mem[_t_58 + 3] = _h_308;
      e.mem[_t_58 + 4] = _h_309;
      e.mem[_t_58 + 5] = _h_310;
      e.mem[_t_58 + 6] = _h_311;
      e.mem[_t_58 + 7] = _h_312;
      e.mem[_t_58 + 8] = _h_313;
      e.mem[_t_58 + 9] = _h_314;
      e.mem[_t_58 + 10] = _h_315;
      e.mem[_t_58 + 11] = _h_316;
      e.mem[_t_58 + 12] = _h_317;
      WL_CONT = term_tsk(FID_APPLIED_K232, _t_58);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = term_ctr(CID_SCON, STAT_OFF + 150);
      e.mem[_t_59 + 1] = _h_304;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 150);
    r1 = _h_304;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K232)
  {
    WL_POPN(13);
    Term _h_319 = STK(0);
    Term _h_320 = STK(1);
    Term _h_321 = STK(2);
    Term _h_322 = STK(3);
    Term _h_323 = STK(4);
    Term _h_324 = STK(5);
    Term _h_325 = STK(6);
    Term _h_326 = STK(7);
    Term _h_327 = STK(8);
    Term _h_328 = STK(9);
    Term _h_329 = STK(10);
    Term _h_330 = STK(11);
    Term _h_331 = STK(12);
    Term _h_318 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_319;
      STK(1) = _h_320;
      STK(2) = _h_321;
      STK(3) = _h_322;
      STK(4) = _h_323;
      STK(5) = _h_324;
      STK(6) = _h_325;
      STK(7) = _h_326;
      STK(8) = _h_327;
      STK(9) = _h_328;
      STK(10) = _h_329;
      STK(11) = _h_330;
      STK(12) = FID_APPLIED_K233;
      WL_PUSHN(13);
    } else {
      u64 _t_60 = task_node(e, FID_APPLIED_K233, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_319;
      e.mem[_t_60 + 1] = _h_320;
      e.mem[_t_60 + 2] = _h_321;
      e.mem[_t_60 + 3] = _h_322;
      e.mem[_t_60 + 4] = _h_323;
      e.mem[_t_60 + 5] = _h_324;
      e.mem[_t_60 + 6] = _h_325;
      e.mem[_t_60 + 7] = _h_326;
      e.mem[_t_60 + 8] = _h_327;
      e.mem[_t_60 + 9] = _h_328;
      e.mem[_t_60 + 10] = _h_329;
      e.mem[_t_60 + 11] = _h_330;
      WL_CONT = term_tsk(FID_APPLIED_K233, _t_60);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_61 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = _h_331;
      e.mem[_t_61 + 1] = _h_318;
      return term_tsk(FID_STRING_APPEND, _t_61);
    }
    r0 = _h_331;
    r1 = _h_318;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K233)
  {
    WL_POPN(12);
    Term _h_333 = STK(0);
    Term _h_334 = STK(1);
    Term _h_335 = STK(2);
    Term _h_336 = STK(3);
    Term _h_337 = STK(4);
    Term _h_338 = STK(5);
    Term _h_339 = STK(6);
    Term _h_340 = STK(7);
    Term _h_341 = STK(8);
    Term _h_342 = STK(9);
    Term _h_343 = STK(10);
    Term _h_344 = STK(11);
    Term _h_332 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_333;
      STK(1) = _h_334;
      STK(2) = _h_335;
      STK(3) = _h_336;
      STK(4) = _h_337;
      STK(5) = _h_338;
      STK(6) = _h_339;
      STK(7) = _h_340;
      STK(8) = _h_341;
      STK(9) = _h_342;
      STK(10) = _h_343;
      STK(11) = _h_344;
      STK(12) = FID_APPLIED_K234;
      WL_PUSHN(13);
    } else {
      u64 _t_62 = task_node(e, FID_APPLIED_K234, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_333;
      e.mem[_t_62 + 1] = _h_334;
      e.mem[_t_62 + 2] = _h_335;
      e.mem[_t_62 + 3] = _h_336;
      e.mem[_t_62 + 4] = _h_337;
      e.mem[_t_62 + 5] = _h_338;
      e.mem[_t_62 + 6] = _h_339;
      e.mem[_t_62 + 7] = _h_340;
      e.mem[_t_62 + 8] = _h_341;
      e.mem[_t_62 + 9] = _h_342;
      e.mem[_t_62 + 10] = _h_343;
      e.mem[_t_62 + 11] = _h_344;
      WL_CONT = term_tsk(FID_APPLIED_K234, _t_62);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = term_ctr(CID_SCON, STAT_OFF + 164);
      e.mem[_t_63 + 1] = _h_332;
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 164);
    r1 = _h_332;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K234)
  {
    WL_POPN(12);
    Term _h_346 = STK(0);
    Term _h_347 = STK(1);
    Term _h_348 = STK(2);
    Term _h_349 = STK(3);
    Term _h_350 = STK(4);
    Term _h_351 = STK(5);
    Term _h_352 = STK(6);
    Term _h_353 = STK(7);
    Term _h_354 = STK(8);
    Term _h_355 = STK(9);
    Term _h_356 = STK(10);
    Term _h_357 = STK(11);
    Term _h_345 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_346;
      STK(1) = _h_347;
      STK(2) = _h_348;
      STK(3) = _h_349;
      STK(4) = _h_350;
      STK(5) = _h_351;
      STK(6) = _h_352;
      STK(7) = _h_353;
      STK(8) = _h_354;
      STK(9) = _h_355;
      STK(10) = _h_356;
      STK(11) = FID_APPLIED_K235;
      WL_PUSHN(12);
    } else {
      u64 _t_64 = task_node(e, FID_APPLIED_K235, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_346;
      e.mem[_t_64 + 1] = _h_347;
      e.mem[_t_64 + 2] = _h_348;
      e.mem[_t_64 + 3] = _h_349;
      e.mem[_t_64 + 4] = _h_350;
      e.mem[_t_64 + 5] = _h_351;
      e.mem[_t_64 + 6] = _h_352;
      e.mem[_t_64 + 7] = _h_353;
      e.mem[_t_64 + 8] = _h_354;
      e.mem[_t_64 + 9] = _h_355;
      e.mem[_t_64 + 10] = _h_356;
      WL_CONT = term_tsk(FID_APPLIED_K235, _t_64);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = _h_357;
      e.mem[_t_65 + 1] = _h_345;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = _h_357;
    r1 = _h_345;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K235)
  {
    WL_POPN(11);
    Term _h_359 = STK(0);
    Term _h_360 = STK(1);
    Term _h_361 = STK(2);
    Term _h_362 = STK(3);
    Term _h_363 = STK(4);
    Term _h_364 = STK(5);
    Term _h_365 = STK(6);
    Term _h_366 = STK(7);
    Term _h_367 = STK(8);
    Term _h_368 = STK(9);
    Term _h_369 = STK(10);
    Term _h_358 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_359;
      STK(1) = _h_360;
      STK(2) = _h_361;
      STK(3) = _h_362;
      STK(4) = _h_363;
      STK(5) = _h_364;
      STK(6) = _h_365;
      STK(7) = _h_366;
      STK(8) = _h_367;
      STK(9) = _h_368;
      STK(10) = _h_369;
      STK(11) = FID_APPLIED_K236;
      WL_PUSHN(12);
    } else {
      u64 _t_66 = task_node(e, FID_APPLIED_K236, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_359;
      e.mem[_t_66 + 1] = _h_360;
      e.mem[_t_66 + 2] = _h_361;
      e.mem[_t_66 + 3] = _h_362;
      e.mem[_t_66 + 4] = _h_363;
      e.mem[_t_66 + 5] = _h_364;
      e.mem[_t_66 + 6] = _h_365;
      e.mem[_t_66 + 7] = _h_366;
      e.mem[_t_66 + 8] = _h_367;
      e.mem[_t_66 + 9] = _h_368;
      e.mem[_t_66 + 10] = _h_369;
      WL_CONT = term_tsk(FID_APPLIED_K236, _t_66);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = term_ctr(CID_SCON, STAT_OFF + 174);
      e.mem[_t_67 + 1] = _h_358;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 174);
    r1 = _h_358;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K236)
  {
    WL_POPN(11);
    Term _h_371 = STK(0);
    Term _h_372 = STK(1);
    Term _h_373 = STK(2);
    Term _h_374 = STK(3);
    Term _h_375 = STK(4);
    Term _h_376 = STK(5);
    Term _h_377 = STK(6);
    Term _h_378 = STK(7);
    Term _h_379 = STK(8);
    Term _h_380 = STK(9);
    Term _h_381 = STK(10);
    Term _h_370 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_371;
      STK(1) = _h_372;
      STK(2) = _h_373;
      STK(3) = _h_374;
      STK(4) = _h_375;
      STK(5) = _h_376;
      STK(6) = _h_377;
      STK(7) = _h_378;
      STK(8) = _h_379;
      STK(9) = _h_380;
      STK(10) = FID_APPLIED_K237;
      WL_PUSHN(11);
    } else {
      u64 _t_68 = task_node(e, FID_APPLIED_K237, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_371;
      e.mem[_t_68 + 1] = _h_372;
      e.mem[_t_68 + 2] = _h_373;
      e.mem[_t_68 + 3] = _h_374;
      e.mem[_t_68 + 4] = _h_375;
      e.mem[_t_68 + 5] = _h_376;
      e.mem[_t_68 + 6] = _h_377;
      e.mem[_t_68 + 7] = _h_378;
      e.mem[_t_68 + 8] = _h_379;
      e.mem[_t_68 + 9] = _h_380;
      WL_CONT = term_tsk(FID_APPLIED_K237, _t_68);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = _h_381;
      e.mem[_t_69 + 1] = _h_370;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = _h_381;
    r1 = _h_370;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K237)
  {
    WL_POPN(10);
    Term _h_383 = STK(0);
    Term _h_384 = STK(1);
    Term _h_385 = STK(2);
    Term _h_386 = STK(3);
    Term _h_387 = STK(4);
    Term _h_388 = STK(5);
    Term _h_389 = STK(6);
    Term _h_390 = STK(7);
    Term _h_391 = STK(8);
    Term _h_392 = STK(9);
    Term _h_382 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_383;
      STK(1) = _h_384;
      STK(2) = _h_385;
      STK(3) = _h_386;
      STK(4) = _h_387;
      STK(5) = _h_388;
      STK(6) = _h_389;
      STK(7) = _h_390;
      STK(8) = _h_391;
      STK(9) = _h_392;
      STK(10) = FID_APPLIED_K238;
      WL_PUSHN(11);
    } else {
      u64 _t_70 = task_node(e, FID_APPLIED_K238, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _h_383;
      e.mem[_t_70 + 1] = _h_384;
      e.mem[_t_70 + 2] = _h_385;
      e.mem[_t_70 + 3] = _h_386;
      e.mem[_t_70 + 4] = _h_387;
      e.mem[_t_70 + 5] = _h_388;
      e.mem[_t_70 + 6] = _h_389;
      e.mem[_t_70 + 7] = _h_390;
      e.mem[_t_70 + 8] = _h_391;
      e.mem[_t_70 + 9] = _h_392;
      WL_CONT = term_tsk(FID_APPLIED_K238, _t_70);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = term_ctr(CID_SCON, STAT_OFF + 192);
      e.mem[_t_71 + 1] = _h_382;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 192);
    r1 = _h_382;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K238)
  {
    WL_POPN(10);
    Term _h_394 = STK(0);
    Term _h_395 = STK(1);
    Term _h_396 = STK(2);
    Term _h_397 = STK(3);
    Term _h_398 = STK(4);
    Term _h_399 = STK(5);
    Term _h_400 = STK(6);
    Term _h_401 = STK(7);
    Term _h_402 = STK(8);
    Term _h_403 = STK(9);
    Term _h_393 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_394;
      STK(1) = _h_395;
      STK(2) = _h_396;
      STK(3) = _h_397;
      STK(4) = _h_398;
      STK(5) = _h_399;
      STK(6) = _h_400;
      STK(7) = _h_401;
      STK(8) = _h_402;
      STK(9) = FID_APPLIED_K239;
      WL_PUSHN(10);
    } else {
      u64 _t_72 = task_node(e, FID_APPLIED_K239, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _h_394;
      e.mem[_t_72 + 1] = _h_395;
      e.mem[_t_72 + 2] = _h_396;
      e.mem[_t_72 + 3] = _h_397;
      e.mem[_t_72 + 4] = _h_398;
      e.mem[_t_72 + 5] = _h_399;
      e.mem[_t_72 + 6] = _h_400;
      e.mem[_t_72 + 7] = _h_401;
      e.mem[_t_72 + 8] = _h_402;
      WL_CONT = term_tsk(FID_APPLIED_K239, _t_72);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_73 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = _h_403;
      e.mem[_t_73 + 1] = _h_393;
      return term_tsk(FID_STRING_APPEND, _t_73);
    }
    r0 = _h_403;
    r1 = _h_393;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K239)
  {
    WL_POPN(9);
    Term _h_405 = STK(0);
    Term _h_406 = STK(1);
    Term _h_407 = STK(2);
    Term _h_408 = STK(3);
    Term _h_409 = STK(4);
    Term _h_410 = STK(5);
    Term _h_411 = STK(6);
    Term _h_412 = STK(7);
    Term _h_413 = STK(8);
    Term _h_404 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_405;
      STK(1) = _h_406;
      STK(2) = _h_407;
      STK(3) = _h_408;
      STK(4) = _h_409;
      STK(5) = _h_410;
      STK(6) = _h_411;
      STK(7) = _h_412;
      STK(8) = _h_413;
      STK(9) = FID_APPLIED_K240;
      WL_PUSHN(10);
    } else {
      u64 _t_74 = task_node(e, FID_APPLIED_K240, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _h_405;
      e.mem[_t_74 + 1] = _h_406;
      e.mem[_t_74 + 2] = _h_407;
      e.mem[_t_74 + 3] = _h_408;
      e.mem[_t_74 + 4] = _h_409;
      e.mem[_t_74 + 5] = _h_410;
      e.mem[_t_74 + 6] = _h_411;
      e.mem[_t_74 + 7] = _h_412;
      e.mem[_t_74 + 8] = _h_413;
      WL_CONT = term_tsk(FID_APPLIED_K240, _t_74);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_75 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = term_ctr(CID_SCON, STAT_OFF + 202);
      e.mem[_t_75 + 1] = _h_404;
      return term_tsk(FID_STRING_APPEND, _t_75);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 202);
    r1 = _h_404;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K240)
  {
    WL_POPN(9);
    Term _h_415 = STK(0);
    Term _h_416 = STK(1);
    Term _h_417 = STK(2);
    Term _h_418 = STK(3);
    Term _h_419 = STK(4);
    Term _h_420 = STK(5);
    Term _h_421 = STK(6);
    Term _h_422 = STK(7);
    Term _h_423 = STK(8);
    Term _h_414 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_415;
      STK(1) = _h_416;
      STK(2) = _h_417;
      STK(3) = _h_418;
      STK(4) = _h_419;
      STK(5) = _h_420;
      STK(6) = _h_421;
      STK(7) = _h_422;
      STK(8) = FID_APPLIED_K241;
      WL_PUSHN(9);
    } else {
      u64 _t_76 = task_node(e, FID_APPLIED_K241, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _h_415;
      e.mem[_t_76 + 1] = _h_416;
      e.mem[_t_76 + 2] = _h_417;
      e.mem[_t_76 + 3] = _h_418;
      e.mem[_t_76 + 4] = _h_419;
      e.mem[_t_76 + 5] = _h_420;
      e.mem[_t_76 + 6] = _h_421;
      e.mem[_t_76 + 7] = _h_422;
      WL_CONT = term_tsk(FID_APPLIED_K241, _t_76);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = _h_423;
      e.mem[_t_77 + 1] = _h_414;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = _h_423;
    r1 = _h_414;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K241)
  {
    WL_POPN(8);
    Term _h_425 = STK(0);
    Term _h_426 = STK(1);
    Term _h_427 = STK(2);
    Term _h_428 = STK(3);
    Term _h_429 = STK(4);
    Term _h_430 = STK(5);
    Term _h_431 = STK(6);
    Term _h_432 = STK(7);
    Term _h_424 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_425;
      STK(1) = _h_426;
      STK(2) = _h_427;
      STK(3) = _h_428;
      STK(4) = _h_429;
      STK(5) = _h_430;
      STK(6) = _h_431;
      STK(7) = _h_432;
      STK(8) = FID_APPLIED_K242;
      WL_PUSHN(9);
    } else {
      u64 _t_78 = task_node(e, FID_APPLIED_K242, WL_CONT, WL_IDX, 1);
      e.mem[_t_78 + 0] = _h_425;
      e.mem[_t_78 + 1] = _h_426;
      e.mem[_t_78 + 2] = _h_427;
      e.mem[_t_78 + 3] = _h_428;
      e.mem[_t_78 + 4] = _h_429;
      e.mem[_t_78 + 5] = _h_430;
      e.mem[_t_78 + 6] = _h_431;
      e.mem[_t_78 + 7] = _h_432;
      WL_CONT = term_tsk(FID_APPLIED_K242, _t_78);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_79 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = term_ctr(CID_SCON, STAT_OFF + 214);
      e.mem[_t_79 + 1] = _h_424;
      return term_tsk(FID_STRING_APPEND, _t_79);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 214);
    r1 = _h_424;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K242)
  {
    WL_POPN(8);
    Term _h_434 = STK(0);
    Term _h_435 = STK(1);
    Term _h_436 = STK(2);
    Term _h_437 = STK(3);
    Term _h_438 = STK(4);
    Term _h_439 = STK(5);
    Term _h_440 = STK(6);
    Term _h_441 = STK(7);
    Term _h_433 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_434;
      STK(1) = _h_435;
      STK(2) = _h_436;
      STK(3) = _h_437;
      STK(4) = _h_438;
      STK(5) = _h_439;
      STK(6) = _h_440;
      STK(7) = FID_APPLIED_K243;
      WL_PUSHN(8);
    } else {
      u64 _t_80 = task_node(e, FID_APPLIED_K243, WL_CONT, WL_IDX, 1);
      e.mem[_t_80 + 0] = _h_434;
      e.mem[_t_80 + 1] = _h_435;
      e.mem[_t_80 + 2] = _h_436;
      e.mem[_t_80 + 3] = _h_437;
      e.mem[_t_80 + 4] = _h_438;
      e.mem[_t_80 + 5] = _h_439;
      e.mem[_t_80 + 6] = _h_440;
      WL_CONT = term_tsk(FID_APPLIED_K243, _t_80);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_81 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = _h_441;
      e.mem[_t_81 + 1] = _h_433;
      return term_tsk(FID_STRING_APPEND, _t_81);
    }
    r0 = _h_441;
    r1 = _h_433;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K243)
  {
    WL_POPN(7);
    Term _h_443 = STK(0);
    Term _h_444 = STK(1);
    Term _h_445 = STK(2);
    Term _h_446 = STK(3);
    Term _h_447 = STK(4);
    Term _h_448 = STK(5);
    Term _h_449 = STK(6);
    Term _h_442 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_443;
      STK(1) = _h_444;
      STK(2) = _h_445;
      STK(3) = _h_446;
      STK(4) = _h_447;
      STK(5) = _h_448;
      STK(6) = _h_449;
      STK(7) = FID_APPLIED_K244;
      WL_PUSHN(8);
    } else {
      u64 _t_82 = task_node(e, FID_APPLIED_K244, WL_CONT, WL_IDX, 1);
      e.mem[_t_82 + 0] = _h_443;
      e.mem[_t_82 + 1] = _h_444;
      e.mem[_t_82 + 2] = _h_445;
      e.mem[_t_82 + 3] = _h_446;
      e.mem[_t_82 + 4] = _h_447;
      e.mem[_t_82 + 5] = _h_448;
      e.mem[_t_82 + 6] = _h_449;
      WL_CONT = term_tsk(FID_APPLIED_K244, _t_82);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = term_ctr(CID_SCON, STAT_OFF + 234);
      e.mem[_t_83 + 1] = _h_442;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 234);
    r1 = _h_442;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K244)
  {
    WL_POPN(7);
    Term _h_451 = STK(0);
    Term _h_452 = STK(1);
    Term _h_453 = STK(2);
    Term _h_454 = STK(3);
    Term _h_455 = STK(4);
    Term _h_456 = STK(5);
    Term _h_457 = STK(6);
    Term _h_450 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_451;
      STK(1) = _h_452;
      STK(2) = _h_453;
      STK(3) = _h_454;
      STK(4) = _h_455;
      STK(5) = _h_456;
      STK(6) = FID_APPLIED_K245;
      WL_PUSHN(7);
    } else {
      u64 _t_84 = task_node(e, FID_APPLIED_K245, WL_CONT, WL_IDX, 1);
      e.mem[_t_84 + 0] = _h_451;
      e.mem[_t_84 + 1] = _h_452;
      e.mem[_t_84 + 2] = _h_453;
      e.mem[_t_84 + 3] = _h_454;
      e.mem[_t_84 + 4] = _h_455;
      e.mem[_t_84 + 5] = _h_456;
      WL_CONT = term_tsk(FID_APPLIED_K245, _t_84);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_85 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = _h_457;
      e.mem[_t_85 + 1] = _h_450;
      return term_tsk(FID_STRING_APPEND, _t_85);
    }
    r0 = _h_457;
    r1 = _h_450;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K245)
  {
    WL_POPN(6);
    Term _h_459 = STK(0);
    Term _h_460 = STK(1);
    Term _h_461 = STK(2);
    Term _h_462 = STK(3);
    Term _h_463 = STK(4);
    Term _h_464 = STK(5);
    Term _h_458 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_459;
      STK(1) = _h_460;
      STK(2) = _h_461;
      STK(3) = _h_462;
      STK(4) = _h_463;
      STK(5) = _h_464;
      STK(6) = FID_APPLIED_K246;
      WL_PUSHN(7);
    } else {
      u64 _t_86 = task_node(e, FID_APPLIED_K246, WL_CONT, WL_IDX, 1);
      e.mem[_t_86 + 0] = _h_459;
      e.mem[_t_86 + 1] = _h_460;
      e.mem[_t_86 + 2] = _h_461;
      e.mem[_t_86 + 3] = _h_462;
      e.mem[_t_86 + 4] = _h_463;
      e.mem[_t_86 + 5] = _h_464;
      WL_CONT = term_tsk(FID_APPLIED_K246, _t_86);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_87 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_87 + 0] = term_ctr(CID_SCON, STAT_OFF + 246);
      e.mem[_t_87 + 1] = _h_458;
      return term_tsk(FID_STRING_APPEND, _t_87);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 246);
    r1 = _h_458;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K246)
  {
    WL_POPN(6);
    Term _h_466 = STK(0);
    Term _h_467 = STK(1);
    Term _h_468 = STK(2);
    Term _h_469 = STK(3);
    Term _h_470 = STK(4);
    Term _h_471 = STK(5);
    Term _h_465 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_466;
      STK(1) = _h_467;
      STK(2) = _h_468;
      STK(3) = _h_469;
      STK(4) = _h_470;
      STK(5) = FID_APPLIED_K247;
      WL_PUSHN(6);
    } else {
      u64 _t_88 = task_node(e, FID_APPLIED_K247, WL_CONT, WL_IDX, 1);
      e.mem[_t_88 + 0] = _h_466;
      e.mem[_t_88 + 1] = _h_467;
      e.mem[_t_88 + 2] = _h_468;
      e.mem[_t_88 + 3] = _h_469;
      e.mem[_t_88 + 4] = _h_470;
      WL_CONT = term_tsk(FID_APPLIED_K247, _t_88);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_89 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_89 + 0] = _h_471;
      e.mem[_t_89 + 1] = _h_465;
      return term_tsk(FID_STRING_APPEND, _t_89);
    }
    r0 = _h_471;
    r1 = _h_465;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K247)
  {
    WL_POPN(5);
    Term _h_473 = STK(0);
    Term _h_474 = STK(1);
    Term _h_475 = STK(2);
    Term _h_476 = STK(3);
    Term _h_477 = STK(4);
    Term _h_472 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_473;
      STK(1) = _h_474;
      STK(2) = _h_475;
      STK(3) = _h_476;
      STK(4) = _h_477;
      STK(5) = FID_APPLIED_K248;
      WL_PUSHN(6);
    } else {
      u64 _t_90 = task_node(e, FID_APPLIED_K248, WL_CONT, WL_IDX, 1);
      e.mem[_t_90 + 0] = _h_473;
      e.mem[_t_90 + 1] = _h_474;
      e.mem[_t_90 + 2] = _h_475;
      e.mem[_t_90 + 3] = _h_476;
      e.mem[_t_90 + 4] = _h_477;
      WL_CONT = term_tsk(FID_APPLIED_K248, _t_90);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_91 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_91 + 0] = term_ctr(CID_SCON, STAT_OFF + 266);
      e.mem[_t_91 + 1] = _h_472;
      return term_tsk(FID_STRING_APPEND, _t_91);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 266);
    r1 = _h_472;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K248)
  {
    WL_POPN(5);
    Term _h_479 = STK(0);
    Term _h_480 = STK(1);
    Term _h_481 = STK(2);
    Term _h_482 = STK(3);
    Term _h_483 = STK(4);
    Term _h_478 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_479;
      STK(1) = _h_480;
      STK(2) = _h_481;
      STK(3) = _h_482;
      STK(4) = FID_APPLIED_K249;
      WL_PUSHN(5);
    } else {
      u64 _t_92 = task_node(e, FID_APPLIED_K249, WL_CONT, WL_IDX, 1);
      e.mem[_t_92 + 0] = _h_479;
      e.mem[_t_92 + 1] = _h_480;
      e.mem[_t_92 + 2] = _h_481;
      e.mem[_t_92 + 3] = _h_482;
      WL_CONT = term_tsk(FID_APPLIED_K249, _t_92);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_93 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_93 + 0] = _h_483;
      e.mem[_t_93 + 1] = _h_478;
      return term_tsk(FID_STRING_APPEND, _t_93);
    }
    r0 = _h_483;
    r1 = _h_478;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K249)
  {
    WL_POPN(4);
    Term _h_485 = STK(0);
    Term _h_486 = STK(1);
    Term _h_487 = STK(2);
    Term _h_488 = STK(3);
    Term _h_484 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_485;
      STK(1) = _h_486;
      STK(2) = _h_487;
      STK(3) = _h_488;
      STK(4) = FID_APPLIED_K250;
      WL_PUSHN(5);
    } else {
      u64 _t_94 = task_node(e, FID_APPLIED_K250, WL_CONT, WL_IDX, 1);
      e.mem[_t_94 + 0] = _h_485;
      e.mem[_t_94 + 1] = _h_486;
      e.mem[_t_94 + 2] = _h_487;
      e.mem[_t_94 + 3] = _h_488;
      WL_CONT = term_tsk(FID_APPLIED_K250, _t_94);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_95 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_95 + 0] = term_ctr(CID_SCON, STAT_OFF + 282);
      e.mem[_t_95 + 1] = _h_484;
      return term_tsk(FID_STRING_APPEND, _t_95);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 282);
    r1 = _h_484;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K250)
  {
    WL_POPN(4);
    Term _h_490 = STK(0);
    Term _h_491 = STK(1);
    Term _h_492 = STK(2);
    Term _h_493 = STK(3);
    Term _h_489 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_490;
      STK(1) = _h_491;
      STK(2) = _h_492;
      STK(3) = FID_APPLIED_K251;
      WL_PUSHN(4);
    } else {
      u64 _t_96 = task_node(e, FID_APPLIED_K251, WL_CONT, WL_IDX, 1);
      e.mem[_t_96 + 0] = _h_490;
      e.mem[_t_96 + 1] = _h_491;
      e.mem[_t_96 + 2] = _h_492;
      WL_CONT = term_tsk(FID_APPLIED_K251, _t_96);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_97 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = _h_493;
      e.mem[_t_97 + 1] = _h_489;
      return term_tsk(FID_STRING_APPEND, _t_97);
    }
    r0 = _h_493;
    r1 = _h_489;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K251)
  {
    WL_POPN(3);
    Term _h_495 = STK(0);
    Term _h_496 = STK(1);
    Term _h_497 = STK(2);
    Term _h_494 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_495;
      STK(1) = _h_496;
      STK(2) = _h_497;
      STK(3) = FID_APPLIED_K252;
      WL_PUSHN(4);
    } else {
      u64 _t_98 = task_node(e, FID_APPLIED_K252, WL_CONT, WL_IDX, 1);
      e.mem[_t_98 + 0] = _h_495;
      e.mem[_t_98 + 1] = _h_496;
      e.mem[_t_98 + 2] = _h_497;
      WL_CONT = term_tsk(FID_APPLIED_K252, _t_98);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_99 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = term_ctr(CID_SCON, STAT_OFF + 288);
      e.mem[_t_99 + 1] = _h_494;
      return term_tsk(FID_STRING_APPEND, _t_99);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 288);
    r1 = _h_494;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K252)
  {
    WL_POPN(3);
    Term _h_499 = STK(0);
    Term _h_500 = STK(1);
    Term _h_501 = STK(2);
    Term _h_498 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_499;
      STK(1) = _h_500;
      STK(2) = FID_APPLIED_K253;
      WL_PUSHN(3);
    } else {
      u64 _t_100 = task_node(e, FID_APPLIED_K253, WL_CONT, WL_IDX, 1);
      e.mem[_t_100 + 0] = _h_499;
      e.mem[_t_100 + 1] = _h_500;
      WL_CONT = term_tsk(FID_APPLIED_K253, _t_100);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_101 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_101 + 0] = _h_501;
      e.mem[_t_101 + 1] = _h_498;
      return term_tsk(FID_STRING_APPEND, _t_101);
    }
    r0 = _h_501;
    r1 = _h_498;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K253)
  {
    WL_POPN(2);
    Term _h_503 = STK(0);
    Term _h_504 = STK(1);
    Term _h_502 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_503;
      STK(1) = _h_504;
      STK(2) = FID_APPLIED_K254;
      WL_PUSHN(3);
    } else {
      u64 _t_102 = task_node(e, FID_APPLIED_K254, WL_CONT, WL_IDX, 1);
      e.mem[_t_102 + 0] = _h_503;
      e.mem[_t_102 + 1] = _h_504;
      WL_CONT = term_tsk(FID_APPLIED_K254, _t_102);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_103 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_103 + 0] = term_ctr(CID_SCON, STAT_OFF + 300);
      e.mem[_t_103 + 1] = _h_502;
      return term_tsk(FID_STRING_APPEND, _t_103);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 300);
    r1 = _h_502;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K254)
  {
    WL_POPN(2);
    Term _h_506 = STK(0);
    Term _h_507 = STK(1);
    Term _h_505 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_506;
      STK(1) = FID_APPLIED_K255;
      WL_PUSHN(2);
    } else {
      u64 _t_104 = task_node(e, FID_APPLIED_K255, WL_CONT, WL_IDX, 1);
      e.mem[_t_104 + 0] = _h_506;
      WL_CONT = term_tsk(FID_APPLIED_K255, _t_104);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_105 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_105 + 0] = _h_507;
      e.mem[_t_105 + 1] = _h_505;
      return term_tsk(FID_STRING_APPEND, _t_105);
    }
    r0 = _h_507;
    r1 = _h_505;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K255)
  {
    WL_POPN(1);
    Term _h_509 = STK(0);
    Term _h_508 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_509;
      STK(1) = FID_APPLIED_K256;
      WL_PUSHN(2);
    } else {
      u64 _t_106 = task_node(e, FID_APPLIED_K256, WL_CONT, WL_IDX, 1);
      e.mem[_t_106 + 0] = _h_509;
      WL_CONT = term_tsk(FID_APPLIED_K256, _t_106);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_107 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_107 + 0] = term_ctr(CID_SCON, STAT_OFF + 312);
      e.mem[_t_107 + 1] = _h_508;
      return term_tsk(FID_STRING_APPEND, _t_107);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 312);
    r1 = _h_508;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K256)
  {
    WL_POPN(1);
    Term _h_511 = STK(0);
    Term _h_510 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_APPLIED_K257;
      WL_PUSHN(1);
    } else {
      u64 _t_108 = task_node(e, FID_APPLIED_K257, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_APPLIED_K257, _t_108);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_109 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_109 + 0] = _h_511;
      e.mem[_t_109 + 1] = _h_510;
      return term_tsk(FID_STRING_APPEND, _t_109);
    }
    r0 = _h_511;
    r1 = _h_510;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K257)
  {
    Term _h_512 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_APPLIED_K258;
      WL_PUSHN(1);
    } else {
      u64 _t_110 = task_node(e, FID_APPLIED_K258, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_APPLIED_K258, _t_110);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_111 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_111 + 0] = term_ctr(CID_SCON, STAT_OFF + 324);
      e.mem[_t_111 + 1] = _h_512;
      return term_tsk(FID_STRING_APPEND, _t_111);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 324);
    r1 = _h_512;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APPLIED_K258)
  {
    Term _h_513 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_513;
    r0 = term_clo(FID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C260, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C260, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C260)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K261;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K261, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K261, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K261)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORLD)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_WORLD_K263;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_WORLD_K263, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_WORLD_K263, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 2ull;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_1);
    }
    r0 = 2ull;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORLD_K263)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_WORLD_K264;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_WORLD_K264, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_WORLD_K264, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_3 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = 2ull;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_3);
    }
    r0 = 2ull;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORLD_K264)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 100ull;
    Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_0);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, 101ull);
    Term _at_2 = blk_loc(e.mem, _a_0);
    Term _at_3 = blk_at(_a_0, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, 102ull);
    Term _at_4 = blk_loc(e.mem, _a_0);
    Term _at_5 = blk_at(_a_0, 3ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, 103ull);
    Term _at_6 = blk_loc(e.mem, _h_2);
    Term _at_7 = blk_at(_h_2, 2ull, 1);
    u32 _c_3 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_4 = e.mem[_at_6 + _at_7 + 1];
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _t_4 = 1;
    if (_t_4 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_0 + 0] = rfc_seal(e, _a_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, 4ull);
      e.mem[_nd_0 + 2] = rfc_seal(e, 999ull);
      e.mem[_nd_0 + 3] = rfc_seal(e, 200ull);
      e.mem[_nd_0 + 4] = rfc_seal(e, 300ull);
      e.mem[_nd_0 + 5] = rfc_seal(e, 400ull);
      e.mem[_nd_0 + 6] = rfc_seal(e, 77ull);
      _o_1 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT, _nd_0);
    }
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _o_0);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _o_1);
    term_sink(e, _c_4);
    Term _fv_1[1];
    _fv_1[0] = 0;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_1);
    Term _at_8 = blk_loc(e.mem, _a_1);
    Term _at_9 = blk_at(_a_1, 2ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, 1);
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _t_5 = 0;
    if (_t_5 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      _o_3 = term_pak(CID_TYPES_SELECTED, 0);
    }
    Term _fv_2[2];
    _fv_2[0] = _o_2;
    _fv_2[1] = _o_3;
    Term _a_2 = blk_new(e, 1, 2ull, 1, 2, _fv_2);
    Term _at_10 = blk_loc(e.mem, _a_2);
    Term _at_11 = blk_at(_a_2, 2ull, 1);
    u32 _c_6 = blk_read(e.mem, 1, _at_10, _at_11 + 0);
    Term _c_7 = e.mem[_at_10 + _at_11 + 1];
    u32 _o_4 = 0;
    Term _o_5 = 0;
    Term _t_6 = 1;
    if (_t_6 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_TYPES_SELECTED, 55ull);
    }
    blk_write(e.mem, 1, _at_10, _at_11 + 0, _o_4);
    blk_write(e.mem, 1, _at_10, _at_11 + 1, _o_5);
    term_sink(e, _c_7);
    Term _fv_3[1];
    _fv_3[0] = 11ull;
    Term _fv_4[1];
    _fv_4[0] = 22ull;
    Term _fv_5[1];
    _fv_5[0] = 10ull;
    Term _a_3 = blk_new(e, 0, 2ull, 0, 1, _fv_5);
    Term _at_12 = blk_loc(e.mem, _a_3);
    Term _at_13 = blk_at(_a_3, 1ull, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, 11ull);
    Term _at_14 = blk_loc(e.mem, _a_3);
    Term _at_15 = blk_at(_a_3, 2ull, 0);
    u32 _c_9 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, 12ull);
    Term _at_16 = blk_loc(e.mem, _a_3);
    Term _at_17 = blk_at(_a_3, 3ull, 0);
    u32 _c_10 = blk_read(e.mem, 0, _at_16, _at_17 + 0);
    blk_write(e.mem, 0, _at_16, _at_17 + 0, 13ull);
    r0 = 7ull;
    r1 = 9ull;
    r2 = _h_2;
    r3 = _h_1;
    r4 = _a_1;
    r5 = _a_2;
    r6 = blk_new(e, 0, 2ull, 0, 1, _fv_3);
    r7 = blk_new(e, 0, 2ull, 0, 1, _fv_4);
    r8 = 4ull;
    r9 = 2ull;
    r10 = 3ull;
    r11 = term_ctr(CID_CON, STAT_OFF + 408);
    r12 = 1;
    r13 = _a_3;
    r14 = 6ull;
    r15 = 900ull;
    r16 = 901ull;
    r17 = 902ull;
    r18 = 903ull;
    r19 = 88ull;
    r20 = 0;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    u32 _world_19 = r19;
    u32 _world_20 = r20;
    u32 _handle_0 = r21;
    u32 _handle_1 = r22;
    Term _raw_0 = r23;
    u32 _raw_1 = r24;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_2[7];
    if (spin_83(e, _o_2, _raw_0, blk_loc(e.mem, _raw_0), _raw_1) == 0) {
      return 0;
    }
    _v_7 = _o_2[0];
    _v_8 = _o_2[1];
    _v_9 = _o_2[2];
    _v_10 = _o_2[3];
    _v_11 = _o_2[4];
    _v_12 = _o_2[5];
    _v_13 = _o_2[6];
    _v_0 = _v_7;
    _v_1 = _v_8;
    _v_2 = _v_9;
    _v_3 = _v_10;
    _v_4 = _v_11;
    _v_5 = _v_12;
    _v_6 = _v_13;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    if (_world_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _world_13);
      e.mem[_nd_0 + 1] = rfc_seal(e, _world_14);
      u64 _nd_1 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_1 + 0] = rfc_seal(e, _world_15);
      e.mem[_nd_1 + 1] = rfc_seal(e, _world_16);
      e.mem[_nd_1 + 2] = rfc_seal(e, _world_17);
      e.mem[_nd_1 + 3] = rfc_seal(e, _world_18);
      e.mem[_nd_1 + 4] = rfc_seal(e, _world_19);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_TYPES_MOTIONLEDGER, _nd_0));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_1));
      _o_4 = term_ctr(CID_CACHE_CACHE, _nd_2);
    }
    Term _b_0 = 0;
    if (_world_20 == 0) {
      _b_0 = term_pak(CID_TYPES_MOTIONON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_MOTIONOFF, 0);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(7));
    e.mem[_nd_3 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_3 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_3 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_3 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_3 + 5] = rfc_seal(e, _v_5);
    e.mem[_nd_3 + 6] = rfc_seal(e, _v_6);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT_K266;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT_K266, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT_K266, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_MAIN)) {
      u64 _t_1 = task_node(e, FID_COMMANDS_INSERT_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _o_3;
      e.mem[_t_1 + 13] = _o_4;
      e.mem[_t_1 + 14] = _b_0;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT, _nd_3);
      return term_tsk(FID_COMMANDS_INSERT_MAIN, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _o_3;
    r13 = _o_4;
    r14 = _b_0;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEMOTIONMAINSLOT, _nd_3);
    WL_JMP(FID_COMMANDS_INSERT_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT_K266)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    Term _h_15 = r15;
    Term _h_16 = r16;
    WL_OPEN
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    Term _o_10 = 0;
    Term _o_11 = 0;
    Term _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    u32 _o_16 = 0;
    Term _o_17 = 0;
    u32 _o_18 = 0;
    Term _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    u32 _o_25 = 0;
    u32 _o_26 = 0;
    Term _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    if (_h_0 == 0) {
      _o_5 = 0;
      u32 _o_34 = 0;
      Term _o_35 = 0;
      u32 _o_36 = 0;
      u32 _o_37 = 0;
      u32 _o_38 = 0;
      u32 _o_39 = 0;
      u32 _o_40 = 0;
      u32 _o_41 = 0;
      if (_h_13 == 0) {
        _o_34 = 0;
      } else {
        _o_34 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _h_14, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        Term _fb_2[5];
        u64 _sp_2 = ctr_take(e, _f_1, 5, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        u32 _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        u32 _f_8 = _fb_2[4];
        spare_free(e, cls_fit(5), _sp_2);
        _o_35 = _f_2;
        _o_36 = _f_3;
        _o_37 = _f_4;
        _o_38 = _f_5;
        _o_39 = _f_6;
        _o_40 = _f_7;
        _o_41 = _f_8;
      }
      u32 _o_42 = 0;
      if (term_aux(_h_15) == CID_TYPES_MOTIONON) {
        _o_42 = 0;
      } else {
        _o_42 = 1;
      }
      _o_6 = _h_1;
      _o_7 = _h_2;
      _o_8 = _h_3;
      _o_9 = _h_4;
      _o_10 = _h_5;
      _o_11 = _h_6;
      _o_12 = _h_7;
      _o_13 = _h_8;
      _o_14 = _h_9;
      _o_15 = _h_10;
      _o_16 = _h_11;
      _o_17 = _h_12;
      _o_18 = _o_34;
      _o_19 = _o_35;
      _o_20 = _o_36;
      _o_21 = _o_37;
      _o_22 = _o_38;
      _o_23 = _o_39;
      _o_24 = _o_40;
      _o_25 = _o_41;
      _o_26 = _o_42;
    } else {
      _o_5 = 1;
      u32 _o_43 = 0;
      Term _o_44 = 0;
      u32 _o_45 = 0;
      u32 _o_46 = 0;
      u32 _o_47 = 0;
      u32 _o_48 = 0;
      u32 _o_49 = 0;
      u32 _o_50 = 0;
      if (_h_13 == 0) {
        _o_43 = 0;
      } else {
        _o_43 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _h_14, 2, _fb_3);
        Term _f_9 = _fb_3[0];
        Term _f_10 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_9, 2, _fb_4);
        Term _f_11 = _fb_4[0];
        u32 _f_12 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        Term _fb_5[5];
        u64 _sp_5 = ctr_take(e, _f_10, 5, _fb_5);
        u32 _f_13 = _fb_5[0];
        u32 _f_14 = _fb_5[1];
        u32 _f_15 = _fb_5[2];
        u32 _f_16 = _fb_5[3];
        u32 _f_17 = _fb_5[4];
        spare_free(e, cls_fit(5), _sp_5);
        _o_44 = _f_11;
        _o_45 = _f_12;
        _o_46 = _f_13;
        _o_47 = _f_14;
        _o_48 = _f_15;
        _o_49 = _f_16;
        _o_50 = _f_17;
      }
      u32 _o_51 = 0;
      if (term_aux(_h_15) == CID_TYPES_MOTIONON) {
        _o_51 = 0;
      } else {
        _o_51 = 1;
      }
      Term _fb_6[7];
      u64 _sp_6 = ctr_take(e, _h_16, 7, _fb_6);
      Term _f_18 = _fb_6[0];
      u32 _f_19 = _fb_6[1];
      u32 _f_20 = _fb_6[2];
      u32 _f_21 = _fb_6[3];
      u32 _f_22 = _fb_6[4];
      u32 _f_23 = _fb_6[5];
      u32 _f_24 = _fb_6[6];
      spare_free(e, cls_fit(7), _sp_6);
      _o_6 = _h_1;
      _o_7 = _h_2;
      _o_8 = _h_3;
      _o_9 = _h_4;
      _o_10 = _h_5;
      _o_11 = _h_6;
      _o_12 = _h_7;
      _o_13 = _h_8;
      _o_14 = _h_9;
      _o_15 = _h_10;
      _o_16 = _h_11;
      _o_17 = _h_12;
      _o_18 = _o_43;
      _o_19 = _o_44;
      _o_20 = _o_45;
      _o_21 = _o_46;
      _o_22 = _o_47;
      _o_23 = _o_48;
      _o_24 = _o_49;
      _o_25 = _o_50;
      _o_26 = _o_51;
      _o_27 = _f_18;
      _o_28 = _f_19;
      _o_29 = _f_20;
      _o_30 = _f_21;
      _o_31 = _f_22;
      _o_32 = _f_23;
      _o_33 = _f_24;
    }
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _o_53[24];
    if (spin_84(e, _o_53, _o_5, _o_6, _o_7, _o_8, blk_loc(e.mem, _o_8), _o_9, blk_loc(e.mem, _o_9), _o_10, blk_loc(e.mem, _o_10), _o_11, blk_loc(e.mem, _o_11), _o_12, blk_loc(e.mem, _o_12), _o_13, blk_loc(e.mem, _o_13), _o_14, _o_15, _o_16, _o_17, blk_loc(e.mem, _o_17), _o_18, _o_19, blk_loc(e.mem, _o_19), _o_20, _o_21, _o_22, _o_23, _o_24, _o_25, _o_26, _o_27, blk_loc(e.mem, _o_27), _o_28, _o_29, _o_30, _o_31, _o_32, _o_33) == 0) {
      return 0;
    }
    _v_42 = _o_53[0];
    _v_43 = _o_53[1];
    _v_44 = _o_53[2];
    _v_45 = _o_53[3];
    _v_46 = _o_53[4];
    _v_47 = _o_53[5];
    _v_48 = _o_53[6];
    _v_49 = _o_53[7];
    _v_50 = _o_53[8];
    _v_51 = _o_53[9];
    _v_52 = _o_53[10];
    _v_53 = _o_53[11];
    _v_54 = _o_53[12];
    _v_55 = _o_53[13];
    _v_56 = _o_53[14];
    _v_57 = _o_53[15];
    _v_58 = _o_53[16];
    _v_59 = _o_53[17];
    _v_60 = _o_53[18];
    _v_61 = _o_53[19];
    _v_62 = _o_53[20];
    _v_63 = _o_53[21];
    _v_64 = _o_53[22];
    _v_65 = _o_53[23];
    r0 = _v_42;
    r1 = _v_43;
    r2 = _v_44;
    r3 = _v_45;
    r4 = _v_46;
    r5 = _v_47;
    r6 = _v_48;
    r7 = _v_49;
    r8 = _v_50;
    r9 = _v_51;
    r10 = _v_52;
    r11 = _v_53;
    r12 = _v_54;
    r13 = _v_55;
    r14 = _v_56;
    r15 = _v_57;
    r16 = _v_58;
    r17 = _v_59;
    r18 = _v_60;
    r19 = _v_61;
    r20 = _v_62;
    r21 = _v_63;
    r22 = _v_64;
    r23 = _v_65;
    WL_RETN(24);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K276;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K276, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K276, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_WORLD)) {
      u64 _t_1 = task_node(e, FID_WORLD, WL_CONT, WL_IDX, 0);
      return term_tsk(FID_WORLD, _t_1);
    }
    WL_JMP(FID_WORLD);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K276)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 700ull;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K277;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K277, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K277, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT)) {
      u64 _t_3 = task_node(e, FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      e.mem[_t_3 + 12] = _h_12;
      e.mem[_t_3 + 13] = _h_13;
      e.mem[_t_3 + 14] = _h_14;
      e.mem[_t_3 + 15] = _h_15;
      e.mem[_t_3 + 16] = _h_16;
      e.mem[_t_3 + 17] = _h_17;
      e.mem[_t_3 + 18] = _h_18;
      e.mem[_t_3 + 19] = _h_19;
      e.mem[_t_3 + 20] = _h_20;
      e.mem[_t_3 + 21] = 7ull;
      e.mem[_t_3 + 22] = 2ull;
      e.mem[_t_3 + 23] = blk_new(e, 0, 2ull, 0, 1, _fv_0);
      e.mem[_t_3 + 24] = 91ull;
      return term_tsk(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    r18 = _h_18;
    r19 = _h_19;
    r20 = _h_20;
    r21 = 7ull;
    r22 = 2ull;
    r23 = blk_new(e, 0, 2ull, 0, 1, _fv_0);
    r24 = 91ull;
    WL_JMP(FID_RAW_BOUNDARIES_PROTOTYPE_PACKED_MOTION_INSERT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K277)
  {
    u32 _h_21 = r0;
    u32 _h_22 = r1;
    u32 _h_23 = r2;
    Term _h_24 = r3;
    Term _h_25 = r4;
    Term _h_26 = r5;
    Term _h_27 = r6;
    Term _h_28 = r7;
    Term _h_29 = r8;
    u32 _h_30 = r9;
    Term _h_31 = r10;
    u32 _h_32 = r11;
    Term _h_33 = r12;
    u32 _h_34 = r13;
    Term _h_35 = r14;
    u32 _h_36 = r15;
    u32 _h_37 = r16;
    u32 _h_38 = r17;
    u32 _h_39 = r18;
    u32 _h_40 = r19;
    u32 _h_41 = r20;
    u32 _h_42 = r21;
    Term _h_43 = r22;
    u32 _h_44 = r23;
    WL_OPEN
    if (_h_21 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(21));
      e.mem[_nd_0 + 0] = _h_22;
      e.mem[_nd_0 + 1] = _h_23;
      e.mem[_nd_0 + 2] = _h_24;
      e.mem[_nd_0 + 3] = _h_25;
      e.mem[_nd_0 + 4] = _h_26;
      e.mem[_nd_0 + 5] = _h_27;
      e.mem[_nd_0 + 6] = _h_28;
      e.mem[_nd_0 + 7] = _h_29;
      e.mem[_nd_0 + 8] = _h_30;
      e.mem[_nd_0 + 9] = _h_31;
      e.mem[_nd_0 + 10] = _h_32;
      e.mem[_nd_0 + 11] = _h_33;
      e.mem[_nd_0 + 12] = _h_34;
      e.mem[_nd_0 + 13] = _h_35;
      e.mem[_nd_0 + 14] = _h_36;
      e.mem[_nd_0 + 15] = _h_37;
      e.mem[_nd_0 + 16] = _h_38;
      e.mem[_nd_0 + 17] = _h_39;
      e.mem[_nd_0 + 18] = _h_40;
      e.mem[_nd_0 + 19] = _h_41;
      e.mem[_nd_0 + 20] = _h_42;
      r0 = term_clo(FID_MAIN_C278, _nd_0);
      WL_RETN(1);
    } else {
      term_sink(e, _h_24);
      term_sink(e, _h_25);
      term_sink(e, _h_26);
      term_sink(e, _h_27);
      term_sink(e, _h_28);
      term_sink(e, _h_29);
      term_sink(e, _h_33);
      term_sink(e, _h_35);
      term_sink(e, _h_43);
      u64 _nd_7 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 490);
      r0 = term_clo(FID_IO_PRINT, _nd_7);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C278)
  {
    u32 _h_45 = r0;
    u32 _h_46 = r1;
    Term _h_47 = r2;
    Term _h_48 = r3;
    Term _h_49 = r4;
    Term _h_50 = r5;
    Term _h_51 = r6;
    Term _h_52 = r7;
    u32 _h_53 = r8;
    Term _h_54 = r9;
    u32 _h_55 = r10;
    Term _h_56 = r11;
    u32 _h_57 = r12;
    Term _h_58 = r13;
    u32 _h_59 = r14;
    u32 _h_60 = r15;
    u32 _h_61 = r16;
    u32 _h_62 = r17;
    u32 _h_63 = r18;
    u32 _h_64 = r19;
    u32 _h_65 = r20;
    Term _x_0 = r21;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 450);
    u64 _nd_2 = heap_alloc(e, cls_fit(21));
    e.mem[_nd_2 + 0] = _h_45;
    e.mem[_nd_2 + 1] = _h_46;
    e.mem[_nd_2 + 2] = _h_47;
    e.mem[_nd_2 + 3] = _h_48;
    e.mem[_nd_2 + 4] = _h_49;
    e.mem[_nd_2 + 5] = _h_50;
    e.mem[_nd_2 + 6] = _h_51;
    e.mem[_nd_2 + 7] = _h_52;
    e.mem[_nd_2 + 8] = _h_53;
    e.mem[_nd_2 + 9] = _h_54;
    e.mem[_nd_2 + 10] = _h_55;
    e.mem[_nd_2 + 11] = _h_56;
    e.mem[_nd_2 + 12] = _h_57;
    e.mem[_nd_2 + 13] = _h_58;
    e.mem[_nd_2 + 14] = _h_59;
    e.mem[_nd_2 + 15] = _h_60;
    e.mem[_nd_2 + 16] = _h_61;
    e.mem[_nd_2 + 17] = _h_62;
    e.mem[_nd_2 + 18] = _h_63;
    e.mem[_nd_2 + 19] = _h_64;
    e.mem[_nd_2 + 20] = _h_65;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_10 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_10 + 1] = term_clo(FID_MAIN_C279, _nd_2);
      e.mem[_t_10 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_10);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_MAIN_C279, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C279)
  {
    u32 _h_66 = r0;
    u32 _h_67 = r1;
    Term _h_68 = r2;
    Term _h_69 = r3;
    Term _h_70 = r4;
    Term _h_71 = r5;
    Term _h_72 = r6;
    Term _h_73 = r7;
    u32 _h_74 = r8;
    Term _h_75 = r9;
    u32 _h_76 = r10;
    Term _h_77 = r11;
    u32 _h_78 = r12;
    Term _h_79 = r13;
    u32 _h_80 = r14;
    u32 _h_81 = r15;
    u32 _h_82 = r16;
    u32 _h_83 = r17;
    u32 _h_84 = r18;
    u32 _h_85 = r19;
    u32 _h_86 = r20;
    Term _x_1 = r21;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_78 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _h_79);
      e.mem[_nd_3 + 1] = rfc_seal(e, _h_80);
      u64 _nd_4 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_4 + 0] = rfc_seal(e, _h_81);
      e.mem[_nd_4 + 1] = rfc_seal(e, _h_82);
      e.mem[_nd_4 + 2] = rfc_seal(e, _h_83);
      e.mem[_nd_4 + 3] = rfc_seal(e, _h_84);
      e.mem[_nd_4 + 4] = rfc_seal(e, _h_85);
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_TYPES_MOTIONLEDGER, _nd_3));
      e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_TYPES_LEDGERVIEW, _nd_4));
      _o_1 = term_ctr(CID_CACHE_CACHE, _nd_5);
    }
    Term _b_0 = 0;
    if (_h_86 == 0) {
      _b_0 = term_pak(CID_TYPES_MOTIONON, 0);
    } else {
      _b_0 = term_pak(CID_TYPES_MOTIONOFF, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K280;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K280, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K280, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_APPLY_CHECKED)) {
      u64 _t_5 = task_node(e, FID_COMMANDS_APPLY_CHECKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_66;
      e.mem[_t_5 + 1] = _h_67;
      e.mem[_t_5 + 2] = _h_68;
      e.mem[_t_5 + 3] = _h_69;
      e.mem[_t_5 + 4] = _h_70;
      e.mem[_t_5 + 5] = _h_71;
      e.mem[_t_5 + 6] = _h_72;
      e.mem[_t_5 + 7] = _h_73;
      e.mem[_t_5 + 8] = _h_74;
      e.mem[_t_5 + 9] = _h_75;
      e.mem[_t_5 + 10] = _h_76;
      e.mem[_t_5 + 11] = _h_77;
      e.mem[_t_5 + 12] = _o_0;
      e.mem[_t_5 + 13] = _o_1;
      e.mem[_t_5 + 14] = _b_0;
      e.mem[_t_5 + 15] = 99ull;
      return term_tsk(FID_COMMANDS_APPLY_CHECKED, _t_5);
    }
    r0 = _h_66;
    r1 = _h_67;
    r2 = _h_68;
    r3 = _h_69;
    r4 = _h_70;
    r5 = _h_71;
    r6 = _h_72;
    r7 = _h_73;
    r8 = _h_74;
    r9 = _h_75;
    r10 = _h_76;
    r11 = _h_77;
    r12 = _o_0;
    r13 = _o_1;
    r14 = _b_0;
    r15 = 99ull;
    WL_JMP(FID_COMMANDS_APPLY_CHECKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K280)
  {
    u32 _h_87 = r0;
    u32 _h_88 = r1;
    u32 _h_89 = r2;
    Term _h_90 = r3;
    Term _h_91 = r4;
    Term _h_92 = r5;
    Term _h_93 = r6;
    Term _h_94 = r7;
    Term _h_95 = r8;
    u32 _h_96 = r9;
    Term _h_97 = r10;
    u32 _h_98 = r11;
    Term _h_99 = r12;
    u32 _h_100 = r13;
    Term _h_101 = r14;
    Term _h_102 = r15;
    Term _h_103 = r16;
    u32 _h_104 = r17;
    Term _h_105 = r18;
    u32 _h_106 = r19;
    Term _h_107 = r20;
    u32 _h_108 = r21;
    Term _h_109 = r22;
    u32 _h_110 = r23;
    u32 _h_111 = r24;
    Term _h_112 = r25;
    WL_OPEN
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    Term _o_10 = 0;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    u32 _o_13 = 0;
    Term _o_14 = 0;
    u32 _o_15 = 0;
    Term _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    Term _o_24 = 0;
    u32 _o_25 = 0;
    Term _o_26 = 0;
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    u32 _o_32 = 0;
    u32 _o_33 = 0;
    Term _o_34 = 0;
    u32 _o_35 = 0;
    u32 _o_36 = 0;
    u32 _o_37 = 0;
    u32 _o_38 = 0;
    u32 _o_39 = 0;
    Term _o_40 = 0;
    if (_h_87 == 0) {
      _o_2 = 0;
      u32 _o_41 = 0;
      Term _o_42 = 0;
      u32 _o_43 = 0;
      u32 _o_44 = 0;
      u32 _o_45 = 0;
      u32 _o_46 = 0;
      u32 _o_47 = 0;
      u32 _o_48 = 0;
      if (_h_100 == 0) {
        _o_41 = 0;
      } else {
        _o_41 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _h_101, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        Term _fb_2[5];
        u64 _sp_2 = ctr_take(e, _f_1, 5, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        u32 _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        u32 _f_8 = _fb_2[4];
        spare_free(e, cls_fit(5), _sp_2);
        _o_42 = _f_2;
        _o_43 = _f_3;
        _o_44 = _f_4;
        _o_45 = _f_5;
        _o_46 = _f_6;
        _o_47 = _f_7;
        _o_48 = _f_8;
      }
      u32 _o_49 = 0;
      if (term_aux(_h_102) == CID_TYPES_MOTIONON) {
        _o_49 = 0;
      } else {
        _o_49 = 1;
      }
      _o_3 = _h_88;
      _o_4 = _h_89;
      _o_5 = _h_90;
      _o_6 = _h_91;
      _o_7 = _h_92;
      _o_8 = _h_93;
      _o_9 = _h_94;
      _o_10 = _h_95;
      _o_11 = _h_96;
      _o_12 = _h_97;
      _o_13 = _h_98;
      _o_14 = _h_99;
      _o_15 = _o_41;
      _o_16 = _o_42;
      _o_17 = _o_43;
      _o_18 = _o_44;
      _o_19 = _o_45;
      _o_20 = _o_46;
      _o_21 = _o_47;
      _o_22 = _o_48;
      _o_23 = _o_49;
      _o_24 = _h_103;
    } else if (_h_87 == 1) {
      _o_2 = 1;
      u32 _o_50 = 0;
      Term _o_51 = 0;
      u32 _o_52 = 0;
      u32 _o_53 = 0;
      u32 _o_54 = 0;
      u32 _o_55 = 0;
      u32 _o_56 = 0;
      u32 _o_57 = 0;
      if (_h_100 == 0) {
        _o_50 = 0;
      } else {
        _o_50 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _h_101, 2, _fb_3);
        Term _f_9 = _fb_3[0];
        Term _f_10 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_9, 2, _fb_4);
        Term _f_11 = _fb_4[0];
        u32 _f_12 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        Term _fb_5[5];
        u64 _sp_5 = ctr_take(e, _f_10, 5, _fb_5);
        u32 _f_13 = _fb_5[0];
        u32 _f_14 = _fb_5[1];
        u32 _f_15 = _fb_5[2];
        u32 _f_16 = _fb_5[3];
        u32 _f_17 = _fb_5[4];
        spare_free(e, cls_fit(5), _sp_5);
        _o_51 = _f_11;
        _o_52 = _f_12;
        _o_53 = _f_13;
        _o_54 = _f_14;
        _o_55 = _f_15;
        _o_56 = _f_16;
        _o_57 = _f_17;
      }
      u32 _o_58 = 0;
      if (term_aux(_h_102) == CID_TYPES_MOTIONON) {
        _o_58 = 0;
      } else {
        _o_58 = 1;
      }
      _o_3 = _h_88;
      _o_4 = _h_89;
      _o_5 = _h_90;
      _o_6 = _h_91;
      _o_7 = _h_92;
      _o_8 = _h_93;
      _o_9 = _h_94;
      _o_10 = _h_95;
      _o_11 = _h_96;
      _o_12 = _h_97;
      _o_13 = _h_98;
      _o_14 = _h_99;
      _o_15 = _o_50;
      _o_16 = _o_51;
      _o_17 = _o_52;
      _o_18 = _o_53;
      _o_19 = _o_54;
      _o_20 = _o_55;
      _o_21 = _o_56;
      _o_22 = _o_57;
      _o_23 = _o_58;
    } else {
      _o_2 = 2;
      u32 _o_59 = 0;
      Term _o_60 = 0;
      u32 _o_61 = 0;
      u32 _o_62 = 0;
      u32 _o_63 = 0;
      u32 _o_64 = 0;
      u32 _o_65 = 0;
      u32 _o_66 = 0;
      if (_h_100 == 0) {
        _o_59 = 0;
      } else {
        _o_59 = 1;
        Term _fb_6[2];
        u64 _sp_6 = ctr_take(e, _h_101, 2, _fb_6);
        Term _f_18 = _fb_6[0];
        Term _f_19 = _fb_6[1];
        spare_free(e, cls_fit(2), _sp_6);
        Term _fb_7[2];
        u64 _sp_7 = ctr_take(e, _f_18, 2, _fb_7);
        Term _f_20 = _fb_7[0];
        u32 _f_21 = _fb_7[1];
        spare_free(e, cls_fit(2), _sp_7);
        Term _fb_8[5];
        u64 _sp_8 = ctr_take(e, _f_19, 5, _fb_8);
        u32 _f_22 = _fb_8[0];
        u32 _f_23 = _fb_8[1];
        u32 _f_24 = _fb_8[2];
        u32 _f_25 = _fb_8[3];
        u32 _f_26 = _fb_8[4];
        spare_free(e, cls_fit(5), _sp_8);
        _o_60 = _f_20;
        _o_61 = _f_21;
        _o_62 = _f_22;
        _o_63 = _f_23;
        _o_64 = _f_24;
        _o_65 = _f_25;
        _o_66 = _f_26;
      }
      u32 _o_67 = 0;
      if (term_aux(_h_102) == CID_TYPES_MOTIONON) {
        _o_67 = 0;
      } else {
        _o_67 = 1;
      }
      u32 _o_68 = 0;
      Term _o_69 = 0;
      u32 _o_70 = 0;
      u32 _o_71 = 0;
      u32 _o_72 = 0;
      u32 _o_73 = 0;
      u32 _o_74 = 0;
      u32 _o_75 = 0;
      if (_h_104 == 0) {
        _o_68 = 0;
      } else {
        _o_68 = 1;
        Term _fb_9[7];
        u64 _sp_9 = ctr_take(e, _h_105, 7, _fb_9);
        Term _f_27 = _fb_9[0];
        u32 _f_28 = _fb_9[1];
        u32 _f_29 = _fb_9[2];
        u32 _f_30 = _fb_9[3];
        u32 _f_31 = _fb_9[4];
        u32 _f_32 = _fb_9[5];
        u32 _f_33 = _fb_9[6];
        spare_free(e, cls_fit(7), _sp_9);
        _o_69 = _f_27;
        _o_70 = _f_28;
        _o_71 = _f_29;
        _o_72 = _f_30;
        _o_73 = _f_31;
        _o_74 = _f_32;
        _o_75 = _f_33;
      }
      u32 _o_76 = 0;
      Term _o_77 = 0;
      u32 _o_78 = 0;
      if (_h_106 == 0) {
        _o_76 = 0;
      } else {
        _o_76 = 1;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _h_107, 2, _fb_10);
        Term _f_34 = _fb_10[0];
        u32 _f_35 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        _o_77 = _f_34;
        _o_78 = _f_35;
      }
      u32 _o_79 = 0;
      u32 _o_80 = 0;
      if (_h_108 == 0) {
        _o_79 = 0;
      } else {
        _o_79 = 1;
        _o_80 = term_loc(_h_109);
      }
      _o_3 = _h_88;
      _o_4 = _h_89;
      _o_5 = _h_90;
      _o_6 = _h_91;
      _o_7 = _h_92;
      _o_8 = _h_93;
      _o_9 = _h_94;
      _o_10 = _h_95;
      _o_11 = _h_96;
      _o_12 = _h_97;
      _o_13 = _h_98;
      _o_14 = _h_99;
      _o_15 = _o_59;
      _o_16 = _o_60;
      _o_17 = _o_61;
      _o_18 = _o_62;
      _o_19 = _o_63;
      _o_20 = _o_64;
      _o_21 = _o_65;
      _o_22 = _o_66;
      _o_23 = _o_67;
      _o_24 = _h_103;
      _o_25 = _o_68;
      _o_26 = _o_69;
      _o_27 = _o_70;
      _o_28 = _o_71;
      _o_29 = _o_72;
      _o_30 = _o_73;
      _o_31 = _o_74;
      _o_32 = _o_75;
      _o_33 = _o_76;
      _o_34 = _o_77;
      _o_35 = _o_78;
      _o_36 = _o_79;
      _o_37 = _o_80;
      _o_38 = _h_110;
      _o_39 = _h_111;
      _o_40 = _h_112;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K281;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K281, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K281, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_APPLIED)) {
      u64 _t_7 = task_node(e, FID_APPLIED, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _o_2;
      e.mem[_t_7 + 1] = _o_3;
      e.mem[_t_7 + 2] = _o_4;
      e.mem[_t_7 + 3] = _o_5;
      e.mem[_t_7 + 4] = _o_6;
      e.mem[_t_7 + 5] = _o_7;
      e.mem[_t_7 + 6] = _o_8;
      e.mem[_t_7 + 7] = _o_9;
      e.mem[_t_7 + 8] = _o_10;
      e.mem[_t_7 + 9] = _o_11;
      e.mem[_t_7 + 10] = _o_12;
      e.mem[_t_7 + 11] = _o_13;
      e.mem[_t_7 + 12] = _o_14;
      e.mem[_t_7 + 13] = _o_15;
      e.mem[_t_7 + 14] = _o_16;
      e.mem[_t_7 + 15] = _o_17;
      e.mem[_t_7 + 16] = _o_18;
      e.mem[_t_7 + 17] = _o_19;
      e.mem[_t_7 + 18] = _o_20;
      e.mem[_t_7 + 19] = _o_21;
      e.mem[_t_7 + 20] = _o_22;
      e.mem[_t_7 + 21] = _o_23;
      e.mem[_t_7 + 22] = _o_24;
      e.mem[_t_7 + 23] = _o_25;
      e.mem[_t_7 + 24] = _o_26;
      e.mem[_t_7 + 25] = _o_27;
      e.mem[_t_7 + 26] = _o_28;
      e.mem[_t_7 + 27] = _o_29;
      e.mem[_t_7 + 28] = _o_30;
      e.mem[_t_7 + 29] = _o_31;
      e.mem[_t_7 + 30] = _o_32;
      e.mem[_t_7 + 31] = _o_33;
      e.mem[_t_7 + 32] = _o_34;
      e.mem[_t_7 + 33] = _o_35;
      e.mem[_t_7 + 34] = _o_36;
      e.mem[_t_7 + 35] = _o_37;
      e.mem[_t_7 + 36] = _o_38;
      e.mem[_t_7 + 37] = _o_39;
      e.mem[_t_7 + 38] = _o_40;
      return term_tsk(FID_APPLIED, _t_7);
    }
    r0 = _o_2;
    r1 = _o_3;
    r2 = _o_4;
    r3 = _o_5;
    r4 = _o_6;
    r5 = _o_7;
    r6 = _o_8;
    r7 = _o_9;
    r8 = _o_10;
    r9 = _o_11;
    r10 = _o_12;
    r11 = _o_13;
    r12 = _o_14;
    r13 = _o_15;
    r14 = _o_16;
    r15 = _o_17;
    r16 = _o_18;
    r17 = _o_19;
    r18 = _o_20;
    r19 = _o_21;
    r20 = _o_22;
    r21 = _o_23;
    r22 = _o_24;
    r23 = _o_25;
    r24 = _o_26;
    r25 = _o_27;
    r26 = _o_28;
    r27 = _o_29;
    r28 = _o_30;
    r29 = _o_31;
    r30 = _o_32;
    r31 = _o_33;
    r32 = _o_34;
    r33 = _o_35;
    r34 = _o_36;
    r35 = _o_37;
    r36 = _o_38;
    r37 = _o_39;
    r38 = _o_40;
    WL_JMP(FID_APPLIED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K281)
  {
    Term _h_113 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_113;
    r0 = term_clo(FID_MAIN_C282, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C282)
  {
    Term _h_114 = r0;
    Term _x_2 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_114;
      e.mem[_t_9 + 1] = term_clo(FID_MAIN_C283, 0);
      e.mem[_t_9 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = _h_114;
    r1 = term_clo(FID_MAIN_C283, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C283)
  {
    Term _x_3 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C284, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C284)
  {
    Term _x_4 = r0;
    WL_OPEN
    Term _x_5 = term_pak(CID_UNIT, 0);
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_8 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _x_4;
      e.mem[_t_8 + 1] = _x_5;
      return term_tsk(FID_CLO_APPLY, _t_8);
    }
    r0 = _x_4;
    r1 = _x_5;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_2 = r0;
    Term _k_2 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _text_2;
    e.mem[_nd_2 + 1] = _k_2;
    r0 = term_ctr(CID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
