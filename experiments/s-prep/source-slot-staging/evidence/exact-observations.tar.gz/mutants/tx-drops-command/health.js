function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$(run_loop($one$(0)), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $IO$print$(run_loop($one$(1)), _x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$((_x_7) => $IO$print$(run_loop($one$(2)), _x_7), run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $IO$bind$((_x_10) => $IO$print$(run_loop($one$(3)), _x_10), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $IO$bind$((_x_13) => $IO$print$(run_loop($one$(4)), _x_13), run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $IO$bind$((_x_16) => $IO$print$(($tx_one$(0)), _x_16), run_clo((_x_17) => {
  return run_clo((_x_18) => {
  return $IO$bind$((_x_19) => $IO$print$(($tx_one$(1)), _x_19), run_clo((_x_20) => {
  return run_clo((_x_21) => {
  return $IO$bind$((_x_22) => $IO$print$(($tx_one$(2)), _x_22), run_clo((_x_23) => {
  return run_clo((_x_24) => {
  return $IO$bind$((_x_25) => $IO$print$(($tx_one$(3)), _x_25), run_clo((_x_26) => {
  return (_x_27) => $IO$print$(($tx_one$(4)), _x_27);
}), _x_24);
});
}), _x_21);
});
}), _x_18);
});
}), _x_15);
});
}), _x_12);
});
}), _x_9);
});
}), _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $one$(_depth_0) {
  return $a_created$(_depth_0, ($identity$058create$1260$(($identity$058factory$()), {$: "Unit"})));
}

function $tx_one$(_depth_0) {
  return $tx_created$(_depth_0, ($identity$058create$1260$(($identity$058factory$()), {$: "Unit"})));
}

function $a_created$(_depth_0, _result_0) {
  if (_result_0.$ === "types.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $a_reserved$(_depth_0, _factory_0, ($commands$058reserve$(_world_0, {$: "storage.Bundle", "main": {$: "Some", "value": ($make_slot$(_depth_0, 10))}, "aux": {$: "None"}, "flag": {$: "None"}})));
  } else {
    return "BAD_CREATE_A";
  }
}

function $identity$058create$1260$(_factory_0, _mode_0) {
  const _namespace_0 = _factory_0["next"];
  return $identity$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _mode_0);
}

function $identity$058factory$() {
  return {$: "storage.Factory", "next": 1};
}

function $tx_created$(_depth_0, _result_0) {
  if (_result_0.$ === "types.Created") {
    const _world_0 = _result_0["world"];
    return $tx_reserved$(_depth_0, ($identity$058reserve_id$(_world_0)));
  } else {
    return "BAD_TX_CREATE";
  }
}

function $a_reserved$(_depth_0, _factory_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return $a_applied$(_depth_0, _factory_0, _handle_0, ($commands$058apply_checked$(_world_0, 1)));
  } else {
    return "BAD_RESERVE_A";
  }
}

function $commands$058reserve$(_world_0, _bundle_0) {
  return $commands$058reserved$(_bundle_0, ($identity$058reserve_id$(_world_0)));
}

function $make_slot$(_depth_0, _seed_0) {
  return $cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($arr$(_depth_0, _seed_0)), "reserve": 17, "class": 23});
}

function $identity$058create_checked$1260$(_available_0, _namespace_0, _mode_0) {
  if (!_available_0) {
    return {$: "types.CreateRejected", "factory": {$: "storage.Factory", "next": _namespace_0}};
  } else {
    return {$: "types.Created", "factory": {$: "storage.Factory", "next": ((_namespace_0 + 1) >>> 0)}, "world": {$: "storage.World", "namespace": _namespace_0, "next": 1, "rows": ($storage$058rows_empty$()), "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Unit"}}, "mode": _mode_0}};
  }
}

function $tx_reserved$(_depth_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _handle_0 = _t_0["value"];
    return $tx_text$(_depth_0, ($transaction$058tx_finish_success$(($transaction$058tx_stage_ping$(($transaction$058tx_stage_ping$(($tx_loop$(32, _depth_0, 1, ($transaction$058tx_begin$(_world_0, _handle_0)))), 81)), 82)))));
  } else {
    return "BAD_TX_RESERVE";
  }
}

function $identity$058reserve_id$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $identity$058reserve_checked$((_next_0 < 4294967295), _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0);
}

function $a_applied$(_depth_0, _factory_0, _local_0, _result_0) {
  if (_result_0.$ === "commands.Applied") {
    const _world_0 = _result_0["world"];
    return $b_created$(_depth_0, _world_0, _local_0, ($identity$058create$1260$(_factory_0, {$: "Unit"})));
  } else {
    return "BAD_APPLY_A";
  }
}

function $commands$058apply_checked$(_world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, ($commands$058preflight$(_pending_0, _rows_0)));
}

function $commands$058reserved$(_bundle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "types.ReserveRejected", "world": _world_0, "payload": _bundle_0};
  } else {
    const _t_1 = _t_0["value"];
    const _namespace_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    return {$: "types.Reserved", "world": ($storage$058publish$(_world_0, {$: "Con", "head": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "tail": {$: "Nil"}})), "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $cached$045payload$058prototype_slot_vitals_new$(_raw_0) {
  return $cached$045payload$058prototype_slot_vitals_result$(($uncached$045payload$058vitals_get$(_raw_0)));
}

function $arr$(_depth_0, _seed_0) {
  const _x_0 = ($U32$pow$(2, _depth_0));
  return $filled$(_x_0, 0, array_new(_depth_0, 0), _seed_0);
}

function $storage$058rows_empty$() {
  return {$: "storage.Rows", "main": [{$: "None"}], "aux": [{$: "None"}], "metadata": ($storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0};
}

function $tx_text$(_depth_0, _result_0) {
  if (_result_0.$ === "transaction.Committed") {
    const _commands_0 = _result_0["commands"];
    const _pings_0 = _result_0["pings"];
    return $tx_text_done$(_pings_0, run_loop($queue_text$(_depth_0, _commands_0, {$: "Nil"}, "")));
  } else {
    return "BAD_TX_REVERTED";
  }
}

function $transaction$058tx_finish_success$(_t_0) {
  const _world_0 = _t_0["world"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "transaction.Committed", "world": _world_0, "commands": ($List$reverse$(_commands_0)), "pings": ($List$reverse$(_pings_0)), "marks": _marks_0};
}

function $transaction$058tx_stage_ping$(_t_0, _code_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": {$: "Con", "head": _code_0, "tail": _pings_0}, "marks": _marks_0};
}

function $tx_loop$($0, $1, $2, $3) {
  for (;;) {
    {
      const _n_0 = $0;
      const _depth_0 = $1;
      const _id_0 = $2;
      const _owner_0 = $3;
      if (_n_0 === 0) {
        return _owner_0;
      } else {
        const _tail_0 = (_n_0 - 1);
        $0 = _tail_0;
        $1 = _depth_0;
        $2 = ((_id_0 + 1) >>> 0);
        $3 = ($transaction$058tx_stage_command$(_owner_0, {$: "storage.InsertMain", "id": _id_0, "main": ($make_slot$(_depth_0, ((100 + _id_0) >>> 0)))}));
        continue;
      }
    }
  }
}

function $transaction$058tx_begin$(_world_0, _selected_0) {
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "pings": {$: "Nil"}, "marks": {$: "Nil"}};
}

function $identity$058reserve_checked$(_available_0, _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": ((_next_0 + 1) >>> 0), "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "Some", "value": {$: "storage.Handle", "namespace": _namespace_0, "id": _next_0}}};
  }
}

function $b_created$(_depth_0, _a_0, _local_0, _result_0) {
  if (_result_0.$ === "types.Created") {
    const _world_0 = _result_0["world"];
    return $b_reserved$(_depth_0, _a_0, _local_0, ($commands$058reserve$(_world_0, {$: "storage.Bundle", "main": {$: "Some", "value": ($make_slot$(_depth_0, 20))}, "aux": {$: "None"}, "flag": {$: "None"}})));
  } else {
    return "BAD_CREATE_B";
  }
}

function $commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, _result_0) {
  const _rows_0 = _result_0["rows"];
  const _pending_0 = _result_0["commands"];
  const _t_0 = _result_0["valid"];
  if (!_t_0) {
    return {$: "commands.CapacityRejected", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}};
  } else {
    return $commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, ($commands$058batch$(($List$reverse$(_pending_0)), _namespace_0, _tick_0, {$: "commands.Running", "rows": _rows_0, "reverseChanges": {$: "Nil"}})));
  }
}

function $commands$058preflight$(_commands_0, _rows_0) {
  return $commands$058preflight_go$(_commands_0, {$: "commands.Preflight", "rows": _rows_0, "commands": {$: "Nil"}, "valid": true});
}

function $storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0};
}

function $cached$045payload$058prototype_slot_vitals_result$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _levels_0 = _t_0["levels"];
  const _rawreserve_0 = _t_0["reserve"];
  const _rawclass_0 = _t_0["class"];
  const _t_1 = _result_0["snd"];
  const _t_2 = _t_1["levels"];
  const _a_0 = _t_2["a"];
  const _b_0 = _t_2["b"];
  const _c_0 = _t_2["c"];
  const _d_0 = _t_2["d"];
  const _cachedreserve_0 = _t_1["reserve"];
  const _cachedclass_0 = _t_1["class"];
  return {$: "cached-payload.PrototypeHealthMainSlot", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0};
}

function $uncached$045payload$058vitals_get$(_owner_0) {
  const _array_0 = _owner_0["levels"];
  const _reserve_0 = _owner_0["reserve"];
  const _class_0 = _owner_0["class"];
  return $uncached$045payload$058vitals_observed$(_reserve_0, _class_0, ($uncached$045payload$058four$(_array_0)));
}

function $filled$($0, $1, $2, $3) {
  for (;;) {
    {
      const _n_0 = $0;
      const _i_0 = $1;
      const _owner_0 = $2;
      const _seed_0 = $3;
      if (_n_0 === 0) {
        return _owner_0;
      } else {
        const _tail_0 = (_n_0 - 1);
        const _x_0 = ((_seed_0 + _i_0) >>> 0);
        $0 = _tail_0;
        $1 = ((_i_0 + 1) >>> 0);
        $2 = (_owner_0[_i_0 % _owner_0.length] = _x_0, _owner_0);
        $3 = _seed_0;
        continue;
      }
    }
  }
}

function $U32$pow$(_a_0, _n_0) {
  if (_n_0 === 0) {
    return 1;
  } else {
    const _p_0 = (_n_0 - 1);
    const _x_0 = ($U32$pow$(_a_0, _p_0));
    return (Math.imul(_a_0, _x_0) >>> 0);
  }
}

function $storage$058metadata_empty$(_depth_0) {
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)};
}

function $tx_text_done$(_pings_0, _pair_0) {
  const _text_0 = _pair_0["snd"];
  const _x_0 = ($ping_text$(_pings_0, ""));
  const _x_1 = ("|pings:" + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return ("tx:" + _x_2);
}

function $queue_text$(_depth_0, _pending_0, _restored_0, _text_0) {
  if (_pending_0.$ === "Nil") {
    return {$: "Tuple", "fst": ($List$reverse$(_restored_0)), "snd": _text_0};
  } else {
    const _command_0 = _pending_0["head"];
    const _tail_0 = _pending_0["tail"];
    return $queue_next$(_restored_0, _text_0, ($command_text$(_depth_0, _command_0)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $queue_text$(_depth_0, _tail_0, _x_0, _x_1);
});
}));
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $transaction$058tx_stage_command$(_t_0, _command_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
}

function $b_reserved$(_depth_0, _a_0, _local_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return $b_applied$(_depth_0, _a_0, _local_0, _handle_0, ($commands$058apply_checked$(_world_0, 1)));
  } else {
    return "BAD_RESERVE_B";
  }
}

function $commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _result_0) {
  if (_result_0.$ === "commands.Completed") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Applied", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": {$: "Nil"}, "ledger": _ledger_0, "mode": _mode_0}, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    const _remaining_0 = _result_0["remaining"];
    const _changes_1 = _result_0["changes"];
    return {$: "commands.InvariantFault", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_1, "pending": ($List$reverse$(_remaining_0)), "ledger": _ledger_0, "mode": _mode_0}, "row": _row_0, "changes": _changes_1};
  }
}

function $commands$058batch$($0, $1, $2, $3) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _namespace_0 = $1;
      const _tick_0 = $2;
      const _state_0 = $3;
      if (_commands_0.$ === "Nil") {
        return $commands$058state_finish$(_state_0);
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = _namespace_0;
        $2 = _tick_0;
        $3 = ($commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0));
        continue;
      }
    }
  }
}

function $commands$058preflight_go$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        const _rows_0 = _state_0["rows"];
        const _reverse_0 = _state_0["commands"];
        const _valid_0 = _state_0["valid"];
        return {$: "commands.Preflight", "rows": _rows_0, "commands": ($List$reverse$(_reverse_0)), "valid": _valid_0};
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        const _rows_1 = _state_0["rows"];
        const _reverse_1 = _state_0["commands"];
        const _valid_1 = _state_0["valid"];
        $0 = _tail_0;
        $1 = ($commands$058preflight_step$(_reverse_1, _valid_1, ($commands$058command_bound$(_rows_1, _command_0))));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $uncached$045payload$058vitals_observed$(_reserve_0, _class_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.Vitals", "levels": _array_0, "reserve": _reserve_0, "class": _class_0}, "snd": {$: "types.VitalsView", "levels": _values_0, "reserve": _reserve_0, "class": _class_0}};
}

function $uncached$045payload$058four$(_array_0) {
  return $uncached$045payload$058original_four$(_array_0);
}

function $ping_text$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _text_0 = $1;
      if (_values_0.$ === "Nil") {
        return _text_0;
      } else {
        const _value_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        const _x_0 = ($U32$show$(_value_0));
        const _x_1 = (_x_0 + ",");
        $0 = _tail_0;
        $1 = (_text_0 + _x_1);
        continue;
      }
    }
  }
}

function $queue_next$(_restored_0, _text_0, _pair_0, _continue_owner_0) {
  const _command_0 = _pair_0["fst"];
  const _one_0 = _pair_0["snd"];
  const _x_0 = (_one_0 + ";");
  return run_tail(_continue_owner_0({$: "Con", "head": _command_0, "tail": _restored_0}), (_text_0 + _x_0));
}

function $command_text$(_depth_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $spawn_done$(_id_0, ($bundle_text$(_depth_0, _bundle_0)));
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $insert_done$(_id_1, ($slot_text$(_depth_0, _main_0)));
  } else if (_command_0.$ === "storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    const _x_0 = ($U32$show$(_id_2));
    return {$: "Tuple", "fst": {$: "storage.InsertFlag", "id": _id_2, "flag": _flag_0}, "snd": ("flag:" + _x_0)};
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    const _x_1 = ($U32$show$(_id_3));
    return {$: "Tuple", "fst": {$: "storage.RemoveMain", "id": _id_3}, "snd": ("removeMain:" + _x_1)};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    const _x_2 = ($U32$show$(_id_4));
    return {$: "Tuple", "fst": {$: "storage.RemoveFlag", "id": _id_4}, "snd": ("removeFlag:" + _x_2)};
  } else {
    const _id_5 = _command_0["id"];
    const _x_3 = ($U32$show$(_id_5));
    return {$: "Tuple", "fst": {$: "storage.Despawn", "id": _id_5}, "snd": ("despawn:" + _x_3)};
  }
}

function $b_applied$(_depth_0, _a_0, _local_0, _foreign_0, _result_0) {
  if (_result_0.$ === "commands.Applied") {
    return $initial$(_depth_0, _a_0, _local_0, _foreign_0);
  } else {
    return "BAD_APPLY_B";
  }
}

function $commands$058state_finish$(_state_0) {
  if (_state_0.$ === "commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return {$: "commands.Completed", "rows": _rows_0, "changes": ($List$reverse$(_changes_0))};
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "commands.BatchFault", "rows": _rows_1, "row": _row_0, "remaining": ($List$reverse$(_remaining_0)), "changes": _changes_1};
  }
}

function $commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0) {
  if (_state_0.$ === "commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return $commands$058state_step$(_changes_0, ($commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0)));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Con", "head": _command_0, "tail": _remaining_0}, "changes": _changes_1};
  }
}

function $commands$058preflight_step$(_reverse_0, _valid_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _command_0 = _t_0["fst"];
  const _bounded_0 = _t_0["snd"];
  return {$: "commands.Preflight", "rows": _rows_0, "commands": {$: "Con", "head": _command_0, "tail": _reverse_0}, "valid": ($Bool$and$(_valid_0, _bounded_0))};
}

function $commands$058command_bound$(_rows_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $commands$058bounded_spawn$(_id_0, _bundle_0, ($storage$058rows_can_place$(_rows_0, _id_0)));
  } else {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": _command_0, "snd": true}};
  }
}

function $uncached$045payload$058original_four$(_array_0) {
  return $uncached$045payload$058four_a$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $spawn_done$(_id_0, _pair_0) {
  const _bundle_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = (":" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  return {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": ("spawn:" + _x_2)};
}

function $bundle_text$(_depth_0, _bundle_0) {
  const _main_0 = _bundle_0["main"];
  const _aux_0 = _bundle_0["aux"];
  const _flag_0 = _bundle_0["flag"];
  return $bundle_done$(_aux_0, _flag_0, ($main_text$(_depth_0, _main_0)));
}

function $insert_done$(_id_0, _pair_0) {
  const _main_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = (":" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  return {$: "Tuple", "fst": {$: "storage.InsertMain", "id": _id_0, "main": _main_0}, "snd": ("insert:" + _x_2)};
}

function $slot_text$(_depth_0, _main_0) {
  const _owner_0 = _main_0["levels"];
  const _rawreserve_0 = _main_0["rawreserve"];
  const _rawclass_0 = _main_0["rawclass"];
  const _a_0 = _main_0["a"];
  const _b_0 = _main_0["b"];
  const _c_0 = _main_0["c"];
  const _d_0 = _main_0["d"];
  const _cachedreserve_0 = _main_0["cachedreserve"];
  const _cachedclass_0 = _main_0["cachedclass"];
  const _x_0 = ($U32$pow$(2, _depth_0));
  return $slot_done$(_rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, run_loop($arr_text$(_x_0, 0, "", _owner_0)));
}

function $initial$(_depth_0, _world_0, _local_0, _foreign_0) {
  return $initial_reserved$(_depth_0, _local_0, _foreign_0, ($commands$058reserve$(_world_0, {$: "storage.Bundle", "main": {$: "Some", "value": ($make_slot$(_depth_0, 50))}, "aux": {$: "None"}, "flag": {$: "None"}})));
}

function $commands$058state_step$(_reverseChanges_0, _result_0) {
  if (_result_0.$ === "commands.Stepped") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Running", "rows": _rows_0, "reverseChanges": ($List$reverse$go$(_changes_0, _reverseChanges_0))};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Nil"}, "changes": ($List$reverse$(_reverseChanges_0))};
  }
}

function $commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0);
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $commands$058main_effect$(_namespace_0, _id_1, ($storage$058rows_replace_main$(_rows_0, _id_1, {$: "Some", "value": _main_0}, _tick_0)));
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_2 = _command_0["id"];
    return $commands$058main_effect$(_namespace_0, _id_2, ($storage$058rows_replace_main$(_rows_0, _id_2, {$: "None"}, _tick_0)));
  } else {
    return $commands$058edit_target$(_namespace_0, _tick_0, _rows_0, ($commands$058targeted$(_command_0)));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $commands$058bounded_spawn$(_id_0, _bundle_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _valid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _valid_0}};
}

function $storage$058rows_can_place$(_rows_0, _id_0) {
  return {$: "Tuple", "fst": _rows_0, "snd": ($Bool$and$((0 < _id_0), (_id_0 <= 131072)))};
}

function $uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $uncached$045payload$058four_b$(_a_0, {$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]});
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $bundle_done$(_aux_0, _flag_0, _pair_0) {
  const _main_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Bundle", "main": _main_0, "aux": _aux_0, "flag": _flag_0}, "snd": _text_0};
}

function $main_text$(_depth_0, _main_0) {
  if (_main_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _owner_0 = _main_0["value"];
    return $main_text_done$(($slot_text$(_depth_0, _owner_0)));
  }
}

function $slot_done$(_rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_cachedclass_0));
  const _x_1 = ($U32$show$(_cachedreserve_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_d_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_c_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_b_0));
  const _x_11 = (":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($U32$show$(_a_0));
  const _x_14 = (":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_rawclass_0));
  const _x_17 = (":" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_rawreserve_0));
  const _x_20 = (":" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ("]:" + _x_21);
  const _x_23 = (_text_0 + _x_22);
  return {$: "Tuple", "fst": {$: "cached-payload.PrototypeHealthMainSlot", "levels": _owner_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}, "snd": ("[" + _x_23)};
}

function $arr_text$(_n_0, _i_0, _text_0, _owner_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _owner_0, "snd": _text_0};
  } else {
    const _tail_0 = (_n_0 - 1);
    return $arr_text_next$(_text_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[_i_0 % _owner_0.length]}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $arr_text$(_tail_0, ((_i_0 + 1) >>> 0), _x_1, _x_0);
});
}));
  }
}

function $initial_reserved$(_depth_0, _local_0, _foreign_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _world_0 = _result_0["world"];
    return $seeded_despawn$(_depth_0, _local_0, _foreign_0, _world_0);
  } else {
    return "BAD_SEED_RESERVE";
  }
}

function $commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0) {
  const _t_0 = _bundle_0["main"];
  if (_t_0.$ === "None") {
    const _aux_0 = _bundle_0["aux"];
    const _flag_0 = _bundle_0["flag"];
    return $commands$058placed$({$: "Nil"}, ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": 0, "changed": 0})));
  } else {
    const _main_0 = _t_0["value"];
    const _aux_1 = _bundle_0["aux"];
    const _flag_1 = _bundle_0["flag"];
    return $commands$058placed$({$: "Con", "head": {$: "storage.MainAdded", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}, ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": _id_0, "main": {$: "Some", "value": _main_0}, "aux": _aux_1, "flag": _flag_1, "added": _tick_0, "changed": _tick_0})));
  }
}

function $commands$058main_effect$(_namespace_0, _id_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "storage.AddedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainAdded", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}};
  } else if (_t_0.$ === "storage.ChangedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "storage.RemovedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainRemoved", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "storage.MissingMainTarget") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  }
}

function $storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _replacement_0);
}

function $commands$058edit_target$(_namespace_0, _tick_0, _rows_0, _result_0) {
  const _command_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $commands$058targeted$(_command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _id_0};
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return {$: "Tuple", "fst": {$: "storage.InsertMain", "id": _id_1, "main": _main_0}, "snd": _id_1};
  } else if (_command_0.$ === "storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    return {$: "Tuple", "fst": {$: "storage.InsertFlag", "id": _id_2, "flag": _flag_0}, "snd": _id_2};
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveMain", "id": _id_3}, "snd": _id_3};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveFlag", "id": _id_4}, "snd": _id_4};
  } else {
    const _id_5 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.Despawn", "id": _id_5}, "snd": _id_5};
  }
}

function $uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $uncached$045payload$058four_c$(_a_0, _b_0, {$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]});
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $main_text_done$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _text_0};
}

function $arr_text_next$(_text_0, _result_0, _continue_owner_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_value_0));
  const _x_1 = (_x_0 + ",");
  return run_tail(_continue_owner_0(_owner_0), (_text_0 + _x_1));
}

function $seeded_despawn$(_depth_0, _local_0, _foreign_0, _world_0) {
  return $seeded_result$(($commands$058despawn$(_world_0, _local_0)), run_clo((_x_0) => {
  return $seeded_remove_flag$(_depth_0, _local_0, _foreign_0, _x_0);
}));
}

function $commands$058placed$(_changes_0, _result_0) {
  if (_result_0.$ === "storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return {$: "commands.Stepped", "rows": _rows_0, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "commands.PlacementFault", "rows": _rows_1, "row": _row_0};
  }
}

function $storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    const _row_0 = _t_0["value"];
    return $commands$058edited$(_rows_0, _id_0, ($commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0)));
  }
}

function $storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $uncached$045payload$058four_done$(_a_0, _b_0, _c_0, {$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]});
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $seeded_result$(_result_0, _continue_world_0) {
  if (_result_0.$ === "types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return run_tail(_continue_world_0, _world_0);
  } else {
    return "BAD_SEED_MISSING";
  }
}

function $commands$058despawn$(_world_0, _handle_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_despawn$(_x_0, _x_1);
});
}));
}

function $seeded_remove_flag$(_depth_0, _local_0, _foreign_0, _world_0) {
  return $seeded_result$(($commands$058remove_flag$(_world_0, _local_0)), run_clo((_x_0) => {
  return $seeded_remove_main$(_depth_0, _local_0, _foreign_0, _x_0);
}));
}

function $storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_grown$(run_loop($storage$058grow$(17, _id_0, _rows_0)), {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
  }
}

function $storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $commands$058edited$(_rows_0, _id_0, _result_0) {
  const _t_0 = _result_0["row"];
  if (_t_0.$ === "Some") {
    const _row_0 = _t_0["value"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Stepped", "rows": ($storage$058rows_restore$(_rows_0, _row_0)), "changes": _changes_0};
  } else {
    const _changes_1 = _result_0["changes"];
    return $commands$058removed$(_changes_1, ($storage$058rows_remove$(_rows_0, _id_0)));
  }
}

function $commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0) {
  if (_command_0.$ === "storage.InsertFlag") {
    const _flag_0 = _command_0["flag"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return {$: "commands.RowEdit", "row": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": {$: "Some", "value": _flag_0}, "added": _added_0, "changed": _changed_0}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_1 = _row_0["id"];
    const _main_1 = _row_0["main"];
    const _aux_1 = _row_0["aux"];
    const _added_1 = _row_0["added"];
    const _changed_1 = _row_0["changed"];
    return {$: "commands.RowEdit", "row": {$: "Some", "value": {$: "storage.Row", "id": _id_1, "main": _main_1, "aux": _aux_1, "flag": {$: "None"}, "added": _added_1, "changed": _changed_1}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.InsertMain") {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.RemoveMain") {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.Despawn") {
    const _id_2 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "Some") {
      return {$: "commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "storage.MainRemoved", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Con", "head": {$: "storage.Despawned", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}}};
    } else {
      return {$: "commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "storage.Despawned", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}};
    }
  } else {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  }
}

function $storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $commands$058queue_owned$(_world_0, _handle_0, _payload_0, _build_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $commands$058queue_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _payload_0, _build_0);
}

function $commands$058build_despawn$(_id_0, _unit_0) {
  return {$: "storage.Despawn", "id": _id_0};
}

function $commands$058remove_flag$(_world_0, _handle_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_remove_flag$(_x_0, _x_1);
});
}));
}

function $seeded_remove_main$(_depth_0, _local_0, _foreign_0, _world_0) {
  return $seeded_result$(($commands$058remove_main$(_world_0, _local_0)), run_clo((_x_0) => {
  return $seeded_flag$(_depth_0, _local_0, _foreign_0, _x_0);
}));
}

function $storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, run_clo((_x_0) => {
  return $storage$058grow$(_n_0, _id_0, _x_0);
}));
  }
}

function $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function $storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $commands$058removed$(_changes_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  return {$: "commands.Stepped", "rows": _rows_0, "changes": _changes_0};
}

function $storage$058rows_remove$(_rows_0, _id_0) {
  return $storage$058remove_done$(_id_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $commands$058queue_checked$(_valid_0, _world_0, _target_0, _payload_0, _build_0) {
  if (!_valid_0) {
    return {$: "types.CommandMissing", "world": _world_0, "payload": _payload_0};
  } else {
    return {$: "types.CommandQueued", "world": ($storage$058publish$(_world_0, {$: "Con", "head": _build_0(_target_0)(_payload_0), "tail": {$: "Nil"}}))};
  }
}

function $commands$058build_remove_flag$(_id_0, _unit_0) {
  return {$: "storage.RemoveFlag", "id": _id_0};
}

function $commands$058remove_main$(_world_0, _handle_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_remove_main$(_x_0, _x_1);
});
}));
}

function $seeded_flag$(_depth_0, _local_0, _foreign_0, _world_0) {
  return $seeded_result$(($commands$058insert_flag$(_world_0, _local_0, {$: "Unit"})), run_clo((_x_0) => {
  return $seeded_main$(_depth_0, _local_0, _foreign_0, _x_0);
}));
}

function $storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, ($storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, {$: "storage.Rows", "main": array_node(_m_0, ($storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($storage$058slots_empty$(_d_0))), "metadata": ($storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0});
  }
}

function $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, () => _x_1));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = {$: "Some", "value": _value_0};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, () => _x_3));
  }
}

function $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, {$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]});
}

function $storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "None"}};
  } else {
    const _row_0 = _t_1["value"];
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": false, "flag": {$: "None"}, "added": 0, "changed": 0})), "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "Some", "value": _row_0}};
  }
}

function $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $commands$058build_remove_main$(_id_0, _unit_0) {
  return {$: "storage.RemoveMain", "id": _id_0};
}

function $commands$058insert_flag$(_world_0, _handle_0, _flag_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, _flag_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_flag$(_x_0, _x_1);
});
}));
}

function $seeded_main$(_depth_0, _local_0, _foreign_0, _world_0) {
  return $seeded_result$(($commands$058insert_main$(_world_0, _local_0, ($make_slot$(_depth_0, 30)))), run_clo((_x_0) => {
  return $prepared$(_depth_0, _local_0, _foreign_0, ($snapshot$(_depth_0, _x_0)));
}));
}

function $storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($storage$058slots_empty$(_d_0)), ($storage$058slots_empty$(_d_0)));
  }
}

function $storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))};
}

function $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]});
}

function $storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $commands$058build_flag$(_id_0, _flag_0) {
  return {$: "storage.InsertFlag", "id": _id_0, "flag": _flag_0};
}

function $commands$058insert_main$(_world_0, _handle_0, _main_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, _main_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_main$(_x_0, _x_1);
});
}));
}

function $prepared$(_depth_0, _local_0, _foreign_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _prior_0 = _pair_0["snd"];
  return $foreign_insert_flag$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0);
}

function $snapshot$(_depth_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $snapshot_access$(_depth_0, ($storage$058with_main$({$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, {$: "storage.Handle", "namespace": _ns_0, "id": 1}, run_clo((_x_0) => {
  return $slot_text$(_depth_0, _x_0);
}))));
}

function $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.NoMainChange"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.RemovedMain"}};
    }
  } else {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.AddedMain"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.ChangedMain"}};
    }
  }
}

function $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $commands$058build_main$(_id_0, _main_0) {
  return {$: "storage.InsertMain", "id": _id_0, "main": _main_0};
}

function $foreign_insert_flag$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0) {
  return $foreign_insert_flag_result$(_depth_0, _local_0, _prior_0, _foreign_0, ($commands$058insert_flag$(_world_0, _foreign_0, {$: "Unit"})));
}

function $snapshot_access$(_depth_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "types.Found") {
    const _text_0 = _t_0["value"];
    const _x_0 = (_text_0 + "|");
    return $snapshot_pending$(_depth_0, ("live:" + _x_0), _world_0);
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": "BAD_LIVE_LOOKUP"};
  }
}

function $storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return {$: "storage.Rejected", "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return {$: "storage.Placed", "rows": {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}};
  }
}

function $foreign_insert_flag_result$(_depth_0, _local_0, _prior_0, _foreign_0, _result_0) {
  if (_result_0.$ === "types.CommandMissing") {
    const _world_0 = _result_0["world"];
    return $foreign_remove_main$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0);
  } else {
    return "BAD_QUEUED";
  }
}

function $snapshot_pending$(_depth_0, _prefix_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $snapshot_done$(_ns_0, _next_0, _rows_0, _ledger_0, _mode_0, run_loop($queue_text$(_depth_0, _pending_0, {$: "Nil"}, _prefix_0)));
}

function $storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $foreign_remove_main$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0) {
  return $foreign_remove_main_result$(_depth_0, _local_0, _prior_0, _foreign_0, ($commands$058remove_main$(_world_0, _foreign_0)));
}

function $snapshot_done$(_ns_0, _next_0, _rows_0, _ledger_0, _mode_0, _pair_0) {
  const _pending_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ($U32$show$(_next_0));
  const _x_1 = ("|" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($U32$show$(_ns_0));
  const _x_4 = (":" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": ("world:" + _x_5)};
}

function $storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

function $foreign_remove_main_result$(_depth_0, _local_0, _prior_0, _foreign_0, _result_0) {
  if (_result_0.$ === "types.CommandMissing") {
    const _world_0 = _result_0["world"];
    return $foreign_remove_flag$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0);
  } else {
    return "BAD_QUEUED";
  }
}

function $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $foreign_remove_flag$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0) {
  return $foreign_remove_flag_result$(_depth_0, _local_0, _prior_0, _foreign_0, ($commands$058remove_flag$(_world_0, _foreign_0)));
}

function $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $foreign_remove_flag_result$(_depth_0, _local_0, _prior_0, _foreign_0, _result_0) {
  if (_result_0.$ === "types.CommandMissing") {
    const _world_0 = _result_0["world"];
    return $foreign_despawn$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0);
  } else {
    return "BAD_QUEUED";
  }
}

function $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $foreign_despawn$(_depth_0, _local_0, _prior_0, _world_0, _foreign_0) {
  return $foreign_despawn_result$(_depth_0, _local_0, _prior_0, _foreign_0, ($commands$058despawn$(_world_0, _foreign_0)));
}

function $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $foreign_despawn_result$(_depth_0, _local_0, _prior_0, _foreign_0, _result_0) {
  if (_result_0.$ === "types.CommandMissing") {
    const _world_0 = _result_0["world"];
    return $finish_slot$(_depth_0, _local_0, _prior_0, ($commands$058insert_main$(_world_0, _foreign_0, ($make_slot$(_depth_0, 90)))));
  } else {
    return "BAD_QUEUED";
  }
}

function $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Found", "value": _observation_0}};
}

function $finish_slot$(_depth_0, _local_0, _prior_0, _result_0) {
  if (_result_0.$ === "types.CommandMissing") {
    const _world_0 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    return $finish_payload$(_depth_0, _local_0, _prior_0, ($slot_text$(_depth_0, _payload_0)), ($snapshot$(_depth_0, _world_0)));
  } else {
    return "BAD_QUEUED";
  }
}

function $finish_payload$(_depth_0, _local_0, _prior_0, _payload_0, _current_0) {
  const _full_0 = _payload_0["snd"];
  const _world_0 = _current_0["fst"];
  const _now_0 = _current_0["snd"];
  const _x_0 = ("|" + _now_0);
  const _x_1 = (_full_0 + _x_0);
  const _x_2 = ($Bool$show$(($String$eq$(_prior_0, _now_0))));
  const _x_3 = ("|" + _x_1);
  return $local_queue$(_depth_0, _local_0, (_x_2 + _x_3), _world_0);
}

function $local_queue$(_depth_0, _local_0, _prefix_0, _world_0) {
  return $local_done$(_depth_0, _prefix_0, ($commands$058insert_main$(_world_0, _local_0, ($make_slot$(_depth_0, 70)))));
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $local_done$(_depth_0, _prefix_0, _result_0) {
  if (_result_0.$ === "types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return $local_snapshot$(_prefix_0, ($snapshot$(_depth_0, _world_0)));
  } else {
    return "BAD_LOCAL_MISSING";
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $local_snapshot$(_prefix_0, _result_0) {
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|local:" + _text_0);
  return (_prefix_0 + _x_0);
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);