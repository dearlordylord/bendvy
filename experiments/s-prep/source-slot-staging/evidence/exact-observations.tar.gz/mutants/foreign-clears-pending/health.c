
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_CHR 13
#define CID_TYPES_CREATED 14
#define CID_TYPES_CREATEREJECTED 15
#define CID_STORAGE_FACTORY 16
#define CID_STORAGE_WORLD 17
#define CID_TYPES_HEALTHSCHEMA 18
#define CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT 19
#define CID_STORAGE_ROWS 20
#define CID_NIL 21
#define CID_CON 22
#define CID_STORAGE_SPAWN 23
#define CID_STORAGE_INSERTMAIN 24
#define CID_STORAGE_INSERTFLAG 25
#define CID_STORAGE_REMOVEMAIN 26
#define CID_STORAGE_REMOVEFLAG 27
#define CID_STORAGE_DESPAWN 28
#define CID_TYPES_RESERVED 29
#define CID_TYPES_RESERVEREJECTED 30
#define CID_STORAGE_HANDLE 31
#define CID_STORAGE_BUNDLE 32
#define CID_STORAGE_METADATACOLUMNS 33
#define CID_COMMANDS_APPLIED 34
#define CID_COMMANDS_CAPACITYREJECTED 35
#define CID_COMMANDS_INVARIANTFAULT 36
#define CID_TYPES_VITALS 37
#define CID_TRANSACTION_COMMITTED 38
#define CID_TRANSACTION_REVERTED 39
#define CID_TRANSACTION_TX 40
#define CID_STORAGE_MAINADDED 41
#define CID_STORAGE_MAINCHANGED 42
#define CID_STORAGE_MAINREMOVED 43
#define CID_STORAGE_DESPAWNED 44
#define CID_STORAGE_ROW 45
#define CID_COMMANDS_PREFLIGHT 46
#define CID_TYPES_VITALSVIEW 47
#define CID_TRANSACTION_MAININVERSE 48
#define CID_TRANSACTION_LEDGERINVERSE 49
#define CID_COMMANDS_COMPLETED 50
#define CID_COMMANDS_BATCHFAULT 51
#define CID_COMMANDS_RUNNING 52
#define CID_COMMANDS_FAULTED 53
#define CID_TYPES_FOUR 54
#define CID_COMMANDS_STEPPED 55
#define CID_COMMANDS_PLACEMENTFAULT 56
#define CID_STORAGE_MISSINGMAINTARGET 57
#define CID_STORAGE_ADDEDMAIN 58
#define CID_STORAGE_CHANGEDMAIN 59
#define CID_STORAGE_REMOVEDMAIN 60
#define CID_STORAGE_NOMAINCHANGE 61
#define CID_STORAGE_PLACED 62
#define CID_STORAGE_REJECTED 63
#define CID_TYPES_COMMANDQUEUED 64
#define CID_TYPES_COMMANDMISSING 65
#define CID_STORAGE_METADATA 66
#define CID_COMMANDS_ROWEDIT 67
#define CID_TYPES_FOUND 68
#define CID_TYPES_MISMATCH 69
#define CID_TYPES_MISSING 70
#define CID_LT 71
#define CID_EQ 72
#define CID_GT 73
#define CID_IO_PRINT 74
#define FID_STRING_CMP 0
#define FID_STRING_CMP_K5 1
#define FID_STRING_ORDER 2
#define FID_STRING_ORDER_K10 3
#define FID_STRING_EQ 4
#define FID_STRING_EQ_K16 5
#define FID_STORAGE_WITH_MAIN 6
#define FID_STORAGE_WITH_MAIN_K189 7
#define FID_SNAPSHOT 8
#define FID_SNAPSHOT_C226 9
#define FID_SNAPSHOT_K227 10
#define FID_SNAPSHOT_K228 11
#define FID_SNAPSHOT_K229 12
#define FID_SNAPSHOT_K230 13
#define FID_SNAPSHOT_K231 14
#define FID_SNAPSHOT_K232 15
#define FID_SNAPSHOT_K233 16
#define FID_SNAPSHOT_K234 17
#define FID_SNAPSHOT_K235 18
#define FID_SNAPSHOT_K236 19
#define FID_SNAPSHOT_K237 20
#define FID_SNAPSHOT_K238 21
#define FID_COMMANDS_INSERT_MAIN 22
#define FID_COMMANDS_INSERT_MAIN_C258 23
#define FID_COMMANDS_INSERT_MAIN_C259 24
#define FID_STORAGE_SLOTS_EMPTY 25
#define FID_STORAGE_SLOTS_EMPTY_K266 26
#define FID_STORAGE_SLOTS_EMPTY_K267 27
#define FID_COMMANDS_INSERT_FLAG 28
#define FID_COMMANDS_INSERT_FLAG_C293 29
#define FID_COMMANDS_INSERT_FLAG_C294 30
#define FID_COMMANDS_REMOVE_MAIN 31
#define FID_COMMANDS_REMOVE_MAIN_C332 32
#define FID_COMMANDS_REMOVE_MAIN_C333 33
#define FID_COMMANDS_REMOVE_MAIN_K334 34
#define FID_STORAGE_GROW 35
#define FID_STORAGE_GROW_C346 36
#define FID_STORAGE_GROW_K347 37
#define FID_STORAGE_GROW_K348 38
#define FID_STORAGE_GROW_K349 39
#define FID_STORAGE_GROW_K350 40
#define FID_COMMANDS_REMOVE_FLAG 41
#define FID_COMMANDS_REMOVE_FLAG_C379 42
#define FID_COMMANDS_REMOVE_FLAG_C380 43
#define FID_COMMANDS_REMOVE_FLAG_K381 44
#define FID_COMMANDS_QUEUE_OWNED 45
#define FID_COMMANDS_QUEUE_OWNED_K384 46
#define FID_COMMANDS_QUEUE_OWNED_K385 47
#define FID_COMMANDS_DESPAWN 48
#define FID_COMMANDS_DESPAWN_C423 49
#define FID_COMMANDS_DESPAWN_C424 50
#define FID_COMMANDS_DESPAWN_K425 51
#define FID_SEEDED_RESULT 52
#define FID_STORAGE_ROWS_PLACE 53
#define FID_STORAGE_ROWS_PLACE_K433 54
#define FID_U32_SHOW_GO 55
#define FID_ARR_TEXT 56
#define FID_ARR_TEXT_C512 57
#define FID_ARR_TEXT_C513 58
#define FID_ARR_TEXT_K514 59
#define FID_ARR_TEXT_K515 60
#define FID_ARR_TEXT_K516 61
#define FID_ARR_TEXT_K517 62
#define FID_ARR_TEXT_K518 63
#define FID_ARR_TEXT_K519 64
#define FID_MAIN_TEXT 65
#define FID_MAIN_TEXT_K547 66
#define FID_COMMANDS_STEP 67
#define FID_COMMANDS_STEP_K555 68
#define FID_COMMANDS_STEP_K556 69
#define FID_SLOT_TEXT 70
#define FID_SLOT_TEXT_K590 71
#define FID_SLOT_TEXT_K591 72
#define FID_SLOT_TEXT_K592 73
#define FID_SLOT_TEXT_K593 74
#define FID_SLOT_TEXT_K594 75
#define FID_SLOT_TEXT_K595 76
#define FID_SLOT_TEXT_K596 77
#define FID_SLOT_TEXT_K597 78
#define FID_SLOT_TEXT_K598 79
#define FID_SLOT_TEXT_K599 80
#define FID_SLOT_TEXT_K600 81
#define FID_SLOT_TEXT_K601 82
#define FID_SLOT_TEXT_K602 83
#define FID_SLOT_TEXT_K603 84
#define FID_SLOT_TEXT_K604 85
#define FID_SLOT_TEXT_K605 86
#define FID_SLOT_TEXT_K606 87
#define FID_SLOT_TEXT_K607 88
#define FID_SLOT_TEXT_K608 89
#define FID_SLOT_TEXT_K609 90
#define FID_SLOT_TEXT_K610 91
#define FID_SLOT_TEXT_K611 92
#define FID_SLOT_TEXT_K612 93
#define FID_SLOT_TEXT_K613 94
#define FID_SLOT_TEXT_K614 95
#define FID_SLOT_TEXT_K615 96
#define FID_SLOT_TEXT_K616 97
#define FID_BUNDLE_TEXT 98
#define FID_BUNDLE_TEXT_K623 99
#define FID_U32_SHOW 100
#define FID_COMMANDS_STATE_COMMAND 101
#define FID_COMMANDS_STATE_COMMAND_K634 102
#define FID_COMMAND_TEXT 103
#define FID_COMMAND_TEXT_K668 104
#define FID_COMMAND_TEXT_K669 105
#define FID_COMMAND_TEXT_K670 106
#define FID_COMMAND_TEXT_K671 107
#define FID_COMMAND_TEXT_K672 108
#define FID_COMMAND_TEXT_K673 109
#define FID_COMMAND_TEXT_K674 110
#define FID_COMMAND_TEXT_K675 111
#define FID_COMMAND_TEXT_K676 112
#define FID_COMMAND_TEXT_K677 113
#define FID_COMMAND_TEXT_K678 114
#define FID_COMMAND_TEXT_K679 115
#define FID_COMMAND_TEXT_K680 116
#define FID_COMMAND_TEXT_K681 117
#define FID_COMMAND_TEXT_K682 118
#define FID_COMMAND_TEXT_K683 119
#define FID_COMMAND_TEXT_K684 120
#define FID_COMMAND_TEXT_K685 121
#define FID_PING_TEXT 122
#define FID_PING_TEXT_K692 123
#define FID_PING_TEXT_K693 124
#define FID_PING_TEXT_K694 125
#define FID_STRING_APPEND 126
#define FID_STRING_APPEND_K696 127
#define FID_COMMANDS_BATCH 128
#define FID_COMMANDS_BATCH_K702 129
#define FID_QUEUE_TEXT 130
#define FID_QUEUE_TEXT_K739 131
#define FID_QUEUE_TEXT_C740 132
#define FID_QUEUE_TEXT_C741 133
#define FID_QUEUE_TEXT_K742 134
#define FID_QUEUE_TEXT_K743 135
#define FID_QUEUE_TEXT_K744 136
#define FID_QUEUE_TEXT_K745 137
#define FID_QUEUE_TEXT_K746 138
#define FID_U32_POW 139
#define FID_U32_POW_K753 140
#define FID_TX_LOOP 141
#define FID_TX_LOOP_K797 142
#define FID_ARR 143
#define FID_ARR_K807 144
#define FID_COMMANDS_APPLY_CHECKED 145
#define FID_COMMANDS_APPLY_CHECKED_K811 146
#define FID_MAKE_SLOT 147
#define FID_MAKE_SLOT_K854 148
#define FID_TX_ONE 149
#define FID_TX_ONE_K934 150
#define FID_TX_ONE_K935 151
#define FID_TX_ONE_K936 152
#define FID_TX_ONE_K937 153
#define FID_TX_ONE_K938 154
#define FID_ONE 155
#define FID_ONE_K940 156
#define FID_ONE_K941 157
#define FID_ONE_K942 158
#define FID_ONE_K943 159
#define FID_ONE_K944 160
#define FID_ONE_K945 161
#define FID_ONE_C946 162
#define FID_ONE_K947 163
#define FID_ONE_C948 164
#define FID_ONE_K949 165
#define FID_ONE_C950 166
#define FID_ONE_K951 167
#define FID_ONE_C952 168
#define FID_ONE_K953 169
#define FID_ONE_K954 170
#define FID_ONE_C955 171
#define FID_ONE_K956 172
#define FID_ONE_K957 173
#define FID_ONE_K958 174
#define FID_ONE_K959 175
#define FID_ONE_K960 176
#define FID_ONE_K961 177
#define FID_ONE_K962 178
#define FID_ONE_K963 179
#define FID_ONE_K964 180
#define FID_ONE_K965 181
#define FID_ONE_K966 182
#define FID_ONE_K967 183
#define FID_ONE_K968 184
#define FID_ONE_K969 185
#define FID_ONE_K970 186
#define FID_ONE_K971 187
#define FID_ONE_K972 188
#define FID_ONE_K973 189
#define FID_IO_BIND 190
#define FID_IO_BIND_C975 191
#define FID_IO_BIND_K976 192
#define FID_MAIN 193
#define FID_MAIN_K978 194
#define FID_MAIN_C979 195
#define FID_MAIN_C980 196
#define FID_MAIN_K981 197
#define FID_MAIN_C982 198
#define FID_MAIN_C983 199
#define FID_MAIN_K984 200
#define FID_MAIN_C985 201
#define FID_MAIN_C986 202
#define FID_MAIN_K987 203
#define FID_MAIN_C988 204
#define FID_MAIN_C989 205
#define FID_MAIN_K990 206
#define FID_MAIN_C991 207
#define FID_MAIN_C992 208
#define FID_MAIN_K993 209
#define FID_MAIN_C994 210
#define FID_MAIN_C995 211
#define FID_MAIN_K996 212
#define FID_MAIN_C997 213
#define FID_MAIN_C998 214
#define FID_MAIN_K999 215
#define FID_MAIN_C1000 216
#define FID_MAIN_C1001 217
#define FID_MAIN_K1002 218
#define FID_MAIN_C1003 219
#define FID_MAIN_C1004 220
#define FID_MAIN_K1005 221
#define FID_IO_PRINT 222
#define FID_IO_EMIT 223
#define FID_CLO_APPLY 224
#define FID_EXIT 225
#define FID_ENTER 226
CONSTV u8 FID_T[][3] = { { 2, 0, 2 }, { 5, 3, 2 }, { 2, 0, 2 }, { 3, 3, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 18, 0, 2 }, { 17, 1, 2 }, { 14, 0, 2 }, { 2, 0, 2 }, { 10, 10, 2 }, { 18, 17, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 2, 2 }, { 15, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 18, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 18, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 11, 0, 2 }, { 3, 0, 2 }, { 9, 9, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 1, 1, 2 }, { 17, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 19, 0, 2 }, { 17, 1, 2 }, { 16, 1, 2 }, { 17, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 17, 17, 2 }, { 16, 0, 2 }, { 18, 0, 2 }, { 18, 9, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 2, 2, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 11, 0, 2 }, { 10, 10, 2 }, { 19, 0, 2 }, { 19, 19, 2 }, { 21, 19, 2 }, { 10, 0, 2 }, { 10, 1, 2 }, { 10, 2, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 15, 1, 2 }, { 16, 1, 2 }, { 17, 1, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 17, 1, 2 }, { 17, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 13, 0, 2 }, { 13, 11, 2 }, { 1, 0, 2 }, { 31, 0, 2 }, { 20, 19, 2 }, { 15, 0, 2 }, { 14, 13, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 11, 10, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 24, 0, 2 }, { 24, 21, 2 }, { 4, 0, 2 }, { 19, 15, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 2, 2, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 22, 0, 2 }, { 31, 9, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 16, 0, 2 }, { 26, 21, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 20, 19, 2 }, { 3, 2, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 24, 9, 2 }, { 30, 26, 2 }, { 38, 9, 2 }, { 44, 26, 2 }, { 27, 9, 2 }, { 21, 16, 2 }, { 6, 0, 2 }, { 21, 16, 2 }, { 6, 0, 2 }, { 21, 16, 2 }, { 6, 0, 2 }, { 22, 17, 2 }, { 6, 0, 2 }, { 27, 9, 2 }, { 22, 17, 2 }, { 6, 0, 2 }, { 19, 14, 2 }, { 23, 17, 2 }, { 22, 16, 2 }, { 22, 16, 2 }, { 22, 16, 2 }, { 28, 9, 2 }, { 21, 17, 2 }, { 27, 10, 2 }, { 28, 14, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 17, 1, 2 }, { 26, 9, 2 }, { 19, 17, 2 }, { 15, 14, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 15, 1 }, { 0, 1 }, { 9, 1 }, { 9, 1 }, { 0, 1 }, { 2, 1 }, { 7, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 6, 1 }, { 4, 1 }, { 16, 1 }, { 15, 1 }, { 25, 1 }, { 3, 1 }, { 4, 0 }, { 1, 0 }, { 6, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 9, 1 }, { 11, 0 }, { 6, 1 }, { 2, 1 }, { 1, 1 }, { 10, 1 }, { 20, 1 }, { 10, 1 }, { 20, 1 }, { 4, 1 }, { 10, 1 }, { 18, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 9, 1 }, { 18, 1 }, { 1, 1 }, { 2, 1 }, { 5, 1 }, { 11, 0 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 2, 0 } };
#define STAT_LEN 466

#define WL_RESW 26
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
    if ((N) <= 29) break; r29 = e.mem[(A) + 29]; \
    if ((N) <= 30) break; r30 = e.mem[(A) + 30]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
    case 29: r29 = (X); \
      break; \
    case 30: r30 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30

#define WL_TABLE WL_X(FID_STRING_CMP) WL_X(FID_STRING_CMP_K5) WL_X(FID_STRING_ORDER) WL_X(FID_STRING_ORDER_K10) WL_X(FID_STRING_EQ) WL_X(FID_STRING_EQ_K16) WL_X(FID_STORAGE_WITH_MAIN) WL_X(FID_STORAGE_WITH_MAIN_K189) WL_X(FID_SNAPSHOT) WL_X(FID_SNAPSHOT_C226) WL_X(FID_SNAPSHOT_K227) WL_X(FID_SNAPSHOT_K228) WL_X(FID_SNAPSHOT_K229) WL_X(FID_SNAPSHOT_K230) WL_X(FID_SNAPSHOT_K231) WL_X(FID_SNAPSHOT_K232) WL_X(FID_SNAPSHOT_K233) WL_X(FID_SNAPSHOT_K234) WL_X(FID_SNAPSHOT_K235) WL_X(FID_SNAPSHOT_K236) WL_X(FID_SNAPSHOT_K237) WL_X(FID_SNAPSHOT_K238) WL_X(FID_COMMANDS_INSERT_MAIN) WL_X(FID_COMMANDS_INSERT_MAIN_C258) WL_X(FID_COMMANDS_INSERT_MAIN_C259) WL_X(FID_STORAGE_SLOTS_EMPTY) WL_X(FID_STORAGE_SLOTS_EMPTY_K266) WL_X(FID_STORAGE_SLOTS_EMPTY_K267) WL_X(FID_COMMANDS_INSERT_FLAG) WL_X(FID_COMMANDS_INSERT_FLAG_C293) WL_X(FID_COMMANDS_INSERT_FLAG_C294) WL_X(FID_COMMANDS_REMOVE_MAIN) WL_X(FID_COMMANDS_REMOVE_MAIN_C332) WL_X(FID_COMMANDS_REMOVE_MAIN_C333) WL_X(FID_COMMANDS_REMOVE_MAIN_K334) WL_X(FID_STORAGE_GROW) WL_X(FID_STORAGE_GROW_C346) WL_X(FID_STORAGE_GROW_K347) WL_X(FID_STORAGE_GROW_K348) WL_X(FID_STORAGE_GROW_K349) WL_X(FID_STORAGE_GROW_K350) WL_X(FID_COMMANDS_REMOVE_FLAG) WL_X(FID_COMMANDS_REMOVE_FLAG_C379) WL_X(FID_COMMANDS_REMOVE_FLAG_C380) WL_X(FID_COMMANDS_REMOVE_FLAG_K381) WL_X(FID_COMMANDS_QUEUE_OWNED) WL_X(FID_COMMANDS_QUEUE_OWNED_K384) WL_X(FID_COMMANDS_QUEUE_OWNED_K385) WL_X(FID_COMMANDS_DESPAWN) WL_X(FID_COMMANDS_DESPAWN_C423) WL_X(FID_COMMANDS_DESPAWN_C424) WL_X(FID_COMMANDS_DESPAWN_K425) WL_X(FID_SEEDED_RESULT) WL_X(FID_STORAGE_ROWS_PLACE) WL_X(FID_STORAGE_ROWS_PLACE_K433) WL_X(FID_U32_SHOW_GO) WL_X(FID_ARR_TEXT) WL_X(FID_ARR_TEXT_C512) WL_X(FID_ARR_TEXT_C513) WL_X(FID_ARR_TEXT_K514) WL_X(FID_ARR_TEXT_K515) WL_X(FID_ARR_TEXT_K516) WL_X(FID_ARR_TEXT_K517) WL_X(FID_ARR_TEXT_K518) WL_X(FID_ARR_TEXT_K519) WL_X(FID_MAIN_TEXT) WL_X(FID_MAIN_TEXT_K547) WL_X(FID_COMMANDS_STEP) WL_X(FID_COMMANDS_STEP_K555) WL_X(FID_COMMANDS_STEP_K556) WL_X(FID_SLOT_TEXT) WL_X(FID_SLOT_TEXT_K590) WL_X(FID_SLOT_TEXT_K591) WL_X(FID_SLOT_TEXT_K592) WL_X(FID_SLOT_TEXT_K593) WL_X(FID_SLOT_TEXT_K594) WL_X(FID_SLOT_TEXT_K595) WL_X(FID_SLOT_TEXT_K596) WL_X(FID_SLOT_TEXT_K597) WL_X(FID_SLOT_TEXT_K598) WL_X(FID_SLOT_TEXT_K599) WL_X(FID_SLOT_TEXT_K600) WL_X(FID_SLOT_TEXT_K601) WL_X(FID_SLOT_TEXT_K602) WL_X(FID_SLOT_TEXT_K603) WL_X(FID_SLOT_TEXT_K604) WL_X(FID_SLOT_TEXT_K605) WL_X(FID_SLOT_TEXT_K606) WL_X(FID_SLOT_TEXT_K607) WL_X(FID_SLOT_TEXT_K608) WL_X(FID_SLOT_TEXT_K609) WL_X(FID_SLOT_TEXT_K610) WL_X(FID_SLOT_TEXT_K611) WL_X(FID_SLOT_TEXT_K612) WL_X(FID_SLOT_TEXT_K613) WL_X(FID_SLOT_TEXT_K614) WL_X(FID_SLOT_TEXT_K615) WL_X(FID_SLOT_TEXT_K616) WL_X(FID_BUNDLE_TEXT) WL_X(FID_BUNDLE_TEXT_K623) WL_X(FID_U32_SHOW) WL_X(FID_COMMANDS_STATE_COMMAND) WL_X(FID_COMMANDS_STATE_COMMAND_K634) WL_X(FID_COMMAND_TEXT) WL_X(FID_COMMAND_TEXT_K668) WL_X(FID_COMMAND_TEXT_K669) WL_X(FID_COMMAND_TEXT_K670) WL_X(FID_COMMAND_TEXT_K671) WL_X(FID_COMMAND_TEXT_K672) WL_X(FID_COMMAND_TEXT_K673) WL_X(FID_COMMAND_TEXT_K674) WL_X(FID_COMMAND_TEXT_K675) WL_X(FID_COMMAND_TEXT_K676) WL_X(FID_COMMAND_TEXT_K677) WL_X(FID_COMMAND_TEXT_K678) WL_X(FID_COMMAND_TEXT_K679) WL_X(FID_COMMAND_TEXT_K680) WL_X(FID_COMMAND_TEXT_K681) WL_X(FID_COMMAND_TEXT_K682) WL_X(FID_COMMAND_TEXT_K683) WL_X(FID_COMMAND_TEXT_K684) WL_X(FID_COMMAND_TEXT_K685) WL_X(FID_PING_TEXT) WL_X(FID_PING_TEXT_K692) WL_X(FID_PING_TEXT_K693) WL_X(FID_PING_TEXT_K694) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K696) WL_X(FID_COMMANDS_BATCH) WL_X(FID_COMMANDS_BATCH_K702) WL_X(FID_QUEUE_TEXT) WL_X(FID_QUEUE_TEXT_K739) WL_X(FID_QUEUE_TEXT_C740) WL_X(FID_QUEUE_TEXT_C741) WL_X(FID_QUEUE_TEXT_K742) WL_X(FID_QUEUE_TEXT_K743) WL_X(FID_QUEUE_TEXT_K744) WL_X(FID_QUEUE_TEXT_K745) WL_X(FID_QUEUE_TEXT_K746) WL_X(FID_U32_POW) WL_X(FID_U32_POW_K753) WL_X(FID_TX_LOOP) WL_X(FID_TX_LOOP_K797) WL_X(FID_ARR) WL_X(FID_ARR_K807) WL_X(FID_COMMANDS_APPLY_CHECKED) WL_X(FID_COMMANDS_APPLY_CHECKED_K811) WL_X(FID_MAKE_SLOT) WL_X(FID_MAKE_SLOT_K854) WL_X(FID_TX_ONE) WL_X(FID_TX_ONE_K934) WL_X(FID_TX_ONE_K935) WL_X(FID_TX_ONE_K936) WL_X(FID_TX_ONE_K937) WL_X(FID_TX_ONE_K938) WL_X(FID_ONE) WL_X(FID_ONE_K940) WL_X(FID_ONE_K941) WL_X(FID_ONE_K942) WL_X(FID_ONE_K943) WL_X(FID_ONE_K944) WL_X(FID_ONE_K945) WL_X(FID_ONE_C946) WL_X(FID_ONE_K947) WL_X(FID_ONE_C948) WL_X(FID_ONE_K949) WL_X(FID_ONE_C950) WL_X(FID_ONE_K951) WL_X(FID_ONE_C952) WL_X(FID_ONE_K953) WL_X(FID_ONE_K954) WL_X(FID_ONE_C955) WL_X(FID_ONE_K956) WL_X(FID_ONE_K957) WL_X(FID_ONE_K958) WL_X(FID_ONE_K959) WL_X(FID_ONE_K960) WL_X(FID_ONE_K961) WL_X(FID_ONE_K962) WL_X(FID_ONE_K963) WL_X(FID_ONE_K964) WL_X(FID_ONE_K965) WL_X(FID_ONE_K966) WL_X(FID_ONE_K967) WL_X(FID_ONE_K968) WL_X(FID_ONE_K969) WL_X(FID_ONE_K970) WL_X(FID_ONE_K971) WL_X(FID_ONE_K972) WL_X(FID_ONE_K973) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C975) WL_X(FID_IO_BIND_K976) WL_X(FID_MAIN) WL_X(FID_MAIN_K978) WL_X(FID_MAIN_C979) WL_X(FID_MAIN_C980) WL_X(FID_MAIN_K981) WL_X(FID_MAIN_C982) WL_X(FID_MAIN_C983) WL_X(FID_MAIN_K984) WL_X(FID_MAIN_C985) WL_X(FID_MAIN_C986) WL_X(FID_MAIN_K987) WL_X(FID_MAIN_C988) WL_X(FID_MAIN_C989) WL_X(FID_MAIN_K990) WL_X(FID_MAIN_C991) WL_X(FID_MAIN_C992) WL_X(FID_MAIN_K993) WL_X(FID_MAIN_C994) WL_X(FID_MAIN_C995) WL_X(FID_MAIN_K996) WL_X(FID_MAIN_C997) WL_X(FID_MAIN_C998) WL_X(FID_MAIN_K999) WL_X(FID_MAIN_C1000) WL_X(FID_MAIN_C1001) WL_X(FID_MAIN_K1002) WL_X(FID_MAIN_C1003) WL_X(FID_MAIN_C1004) WL_X(FID_MAIN_K1005) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 58ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 2), 99ull, term_ctr(CID_SCON, STAT_OFF + 4), 111ull, term_ctr(CID_SCON, STAT_OFF + 6), 108ull, term_ctr(CID_SCON, STAT_OFF + 8), 124ull, term_ctr(CID_SCON, STAT_OFF + 10), 71ull, term_pak(CID_SNIL, 0), 78ull, term_ctr(CID_SCON, STAT_OFF + 14), 73ull, term_ctr(CID_SCON, STAT_OFF + 16), 83ull, term_ctr(CID_SCON, STAT_OFF + 18), 83ull, term_ctr(CID_SCON, STAT_OFF + 20), 73ull, term_ctr(CID_SCON, STAT_OFF + 22), 77ull, term_ctr(CID_SCON, STAT_OFF + 24), 95ull, term_ctr(CID_SCON, STAT_OFF + 26), 76ull, term_ctr(CID_SCON, STAT_OFF + 28), 65ull, term_ctr(CID_SCON, STAT_OFF + 30), 67ull, term_ctr(CID_SCON, STAT_OFF + 32), 79ull, term_ctr(CID_SCON, STAT_OFF + 34), 76ull, term_ctr(CID_SCON, STAT_OFF + 36), 95ull, term_ctr(CID_SCON, STAT_OFF + 38), 68ull, term_ctr(CID_SCON, STAT_OFF + 40), 65ull, term_ctr(CID_SCON, STAT_OFF + 42), 66ull, term_ctr(CID_SCON, STAT_OFF + 44), 101ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 48), 108ull, term_ctr(CID_SCON, STAT_OFF + 50), 97ull, term_ctr(CID_SCON, STAT_OFF + 52), 70ull, term_ctr(CID_SCON, STAT_OFF + 54), 117ull, term_ctr(CID_SCON, STAT_OFF + 48), 114ull, term_ctr(CID_SCON, STAT_OFF + 58), 84ull, term_ctr(CID_SCON, STAT_OFF + 60), 124ull, term_pak(CID_SNIL, 0), 68ull, term_pak(CID_SNIL, 0), 69ull, term_ctr(CID_SCON, STAT_OFF + 66), 85ull, term_ctr(CID_SCON, STAT_OFF + 68), 69ull, term_ctr(CID_SCON, STAT_OFF + 70), 85ull, term_ctr(CID_SCON, STAT_OFF + 72), 81ull, term_ctr(CID_SCON, STAT_OFF + 74), 95ull, term_ctr(CID_SCON, STAT_OFF + 76), 68ull, term_ctr(CID_SCON, STAT_OFF + 78), 65ull, term_ctr(CID_SCON, STAT_OFF + 80), 66ull, term_ctr(CID_SCON, STAT_OFF + 82), 100ull, term_ctr(CID_SCON, STAT_OFF + 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 86), 114ull, term_ctr(CID_SCON, STAT_OFF + 88), 111ull, term_ctr(CID_SCON, STAT_OFF + 90), 119ull, term_ctr(CID_SCON, STAT_OFF + 92), 101ull, term_ctr(CID_SCON, STAT_OFF + 0), 118ull, term_ctr(CID_SCON, STAT_OFF + 96), 105ull, term_ctr(CID_SCON, STAT_OFF + 98), 108ull, term_ctr(CID_SCON, STAT_OFF + 100), 80ull, term_pak(CID_SNIL, 0), 85ull, term_ctr(CID_SCON, STAT_OFF + 104), 75ull, term_ctr(CID_SCON, STAT_OFF + 106), 79ull, term_ctr(CID_SCON, STAT_OFF + 108), 79ull, term_ctr(CID_SCON, STAT_OFF + 110), 76ull, term_ctr(CID_SCON, STAT_OFF + 112), 95ull, term_ctr(CID_SCON, STAT_OFF + 114), 69ull, term_ctr(CID_SCON, STAT_OFF + 116), 86ull, term_ctr(CID_SCON, STAT_OFF + 118), 73ull, term_ctr(CID_SCON, STAT_OFF + 120), 76ull, term_ctr(CID_SCON, STAT_OFF + 122), 95ull, term_ctr(CID_SCON, STAT_OFF + 124), 68ull, term_ctr(CID_SCON, STAT_OFF + 126), 65ull, term_ctr(CID_SCON, STAT_OFF + 128), 66ull, term_ctr(CID_SCON, STAT_OFF + 130), 68ull, term_ctr(CID_SCON, STAT_OFF + 28), 69ull, term_ctr(CID_SCON, STAT_OFF + 134), 69ull, term_ctr(CID_SCON, STAT_OFF + 136), 83ull, term_ctr(CID_SCON, STAT_OFF + 138), 95ull, term_ctr(CID_SCON, STAT_OFF + 140), 68ull, term_ctr(CID_SCON, STAT_OFF + 142), 65ull, term_ctr(CID_SCON, STAT_OFF + 144), 66ull, term_ctr(CID_SCON, STAT_OFF + 146), 44ull, term_pak(CID_SNIL, 0), 69ull, term_pak(CID_SNIL, 0), 86ull, term_ctr(CID_SCON, STAT_OFF + 152), 82ull, term_ctr(CID_SCON, STAT_OFF + 154), 69ull, term_ctr(CID_SCON, STAT_OFF + 156), 83ull, term_ctr(CID_SCON, STAT_OFF + 158), 69ull, term_ctr(CID_SCON, STAT_OFF + 160), 82ull, term_ctr(CID_SCON, STAT_OFF + 162), 95ull, term_ctr(CID_SCON, STAT_OFF + 164), 68ull, term_ctr(CID_SCON, STAT_OFF + 166), 69ull, term_ctr(CID_SCON, STAT_OFF + 168), 69ull, term_ctr(CID_SCON, STAT_OFF + 170), 83ull, term_ctr(CID_SCON, STAT_OFF + 172), 95ull, term_ctr(CID_SCON, STAT_OFF + 174), 68ull, term_ctr(CID_SCON, STAT_OFF + 176), 65ull, term_ctr(CID_SCON, STAT_OFF + 178), 66ull, term_ctr(CID_SCON, STAT_OFF + 180), 93ull, term_ctr(CID_SCON, STAT_OFF + 0), 91ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 48), 111ull, term_ctr(CID_SCON, STAT_OFF + 188), 110ull, term_ctr(CID_SCON, STAT_OFF + 190), 48ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 196), 101ull, term_ctr(CID_SCON, STAT_OFF + 198), 115ull, term_ctr(CID_SCON, STAT_OFF + 200), 110ull, term_ctr(CID_SCON, STAT_OFF + 202), 105ull, term_ctr(CID_SCON, STAT_OFF + 204), 110ull, term_ctr(CID_SCON, STAT_OFF + 0), 119ull, term_ctr(CID_SCON, STAT_OFF + 208), 97ull, term_ctr(CID_SCON, STAT_OFF + 210), 112ull, term_ctr(CID_SCON, STAT_OFF + 212), 115ull, term_ctr(CID_SCON, STAT_OFF + 214), 66ull, term_pak(CID_SNIL, 0), 95ull, term_ctr(CID_SCON, STAT_OFF + 218), 89ull, term_ctr(CID_SCON, STAT_OFF + 220), 76ull, term_ctr(CID_SCON, STAT_OFF + 222), 80ull, term_ctr(CID_SCON, STAT_OFF + 224), 80ull, term_ctr(CID_SCON, STAT_OFF + 226), 65ull, term_ctr(CID_SCON, STAT_OFF + 228), 95ull, term_ctr(CID_SCON, STAT_OFF + 230), 68ull, term_ctr(CID_SCON, STAT_OFF + 232), 65ull, term_ctr(CID_SCON, STAT_OFF + 234), 66ull, term_ctr(CID_SCON, STAT_OFF + 236), 103ull, term_ctr(CID_SCON, STAT_OFF + 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 240), 108ull, term_ctr(CID_SCON, STAT_OFF + 242), 102ull, term_ctr(CID_SCON, STAT_OFF + 244), 105ull, term_ctr(CID_SCON, STAT_OFF + 208), 97ull, term_ctr(CID_SCON, STAT_OFF + 248), 77ull, term_ctr(CID_SCON, STAT_OFF + 250), 101ull, term_ctr(CID_SCON, STAT_OFF + 252), 118ull, term_ctr(CID_SCON, STAT_OFF + 254), 111ull, term_ctr(CID_SCON, STAT_OFF + 256), 109ull, term_ctr(CID_SCON, STAT_OFF + 258), 101ull, term_ctr(CID_SCON, STAT_OFF + 260), 114ull, term_ctr(CID_SCON, STAT_OFF + 262), 70ull, term_ctr(CID_SCON, STAT_OFF + 244), 101ull, term_ctr(CID_SCON, STAT_OFF + 266), 118ull, term_ctr(CID_SCON, STAT_OFF + 268), 111ull, term_ctr(CID_SCON, STAT_OFF + 270), 109ull, term_ctr(CID_SCON, STAT_OFF + 272), 101ull, term_ctr(CID_SCON, STAT_OFF + 274), 114ull, term_ctr(CID_SCON, STAT_OFF + 276), 101ull, term_ctr(CID_SCON, STAT_OFF + 216), 100ull, term_ctr(CID_SCON, STAT_OFF + 280), 59ull, term_pak(CID_SNIL, 0), 69ull, term_ctr(CID_SCON, STAT_OFF + 220), 86ull, term_ctr(CID_SCON, STAT_OFF + 286), 82ull, term_ctr(CID_SCON, STAT_OFF + 288), 69ull, term_ctr(CID_SCON, STAT_OFF + 290), 83ull, term_ctr(CID_SCON, STAT_OFF + 292), 69ull, term_ctr(CID_SCON, STAT_OFF + 294), 82ull, term_ctr(CID_SCON, STAT_OFF + 296), 95ull, term_ctr(CID_SCON, STAT_OFF + 298), 68ull, term_ctr(CID_SCON, STAT_OFF + 300), 65ull, term_ctr(CID_SCON, STAT_OFF + 302), 66ull, term_ctr(CID_SCON, STAT_OFF + 304), 115ull, term_ctr(CID_SCON, STAT_OFF + 0), 103ull, term_ctr(CID_SCON, STAT_OFF + 308), 110ull, term_ctr(CID_SCON, STAT_OFF + 310), 105ull, term_ctr(CID_SCON, STAT_OFF + 312), 112ull, term_ctr(CID_SCON, STAT_OFF + 314), 124ull, term_ctr(CID_SCON, STAT_OFF + 316), 120ull, term_ctr(CID_SCON, STAT_OFF + 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 320), 84ull, term_ctr(CID_SCON, STAT_OFF + 286), 65ull, term_ctr(CID_SCON, STAT_OFF + 324), 69ull, term_ctr(CID_SCON, STAT_OFF + 326), 82ull, term_ctr(CID_SCON, STAT_OFF + 328), 67ull, term_ctr(CID_SCON, STAT_OFF + 330), 95ull, term_ctr(CID_SCON, STAT_OFF + 332), 68ull, term_ctr(CID_SCON, STAT_OFF + 334), 65ull, term_ctr(CID_SCON, STAT_OFF + 336), 66ull, term_ctr(CID_SCON, STAT_OFF + 338), 84ull, term_ctr(CID_SCON, STAT_OFF + 68), 82ull, term_ctr(CID_SCON, STAT_OFF + 342), 69ull, term_ctr(CID_SCON, STAT_OFF + 344), 86ull, term_ctr(CID_SCON, STAT_OFF + 346), 69ull, term_ctr(CID_SCON, STAT_OFF + 348), 82ull, term_ctr(CID_SCON, STAT_OFF + 350), 95ull, term_ctr(CID_SCON, STAT_OFF + 352), 88ull, term_ctr(CID_SCON, STAT_OFF + 354), 84ull, term_ctr(CID_SCON, STAT_OFF + 356), 95ull, term_ctr(CID_SCON, STAT_OFF + 358), 68ull, term_ctr(CID_SCON, STAT_OFF + 360), 65ull, term_ctr(CID_SCON, STAT_OFF + 362), 66ull, term_ctr(CID_SCON, STAT_OFF + 364), 65ull, term_pak(CID_SNIL, 0), 95ull, term_ctr(CID_SCON, STAT_OFF + 368), 89ull, term_ctr(CID_SCON, STAT_OFF + 370), 76ull, term_ctr(CID_SCON, STAT_OFF + 372), 80ull, term_ctr(CID_SCON, STAT_OFF + 374), 80ull, term_ctr(CID_SCON, STAT_OFF + 376), 65ull, term_ctr(CID_SCON, STAT_OFF + 378), 95ull, term_ctr(CID_SCON, STAT_OFF + 380), 68ull, term_ctr(CID_SCON, STAT_OFF + 382), 65ull, term_ctr(CID_SCON, STAT_OFF + 384), 66ull, term_ctr(CID_SCON, STAT_OFF + 386), 88ull, term_ctr(CID_SCON, STAT_OFF + 166), 84ull, term_ctr(CID_SCON, STAT_OFF + 390), 95ull, term_ctr(CID_SCON, STAT_OFF + 392), 68ull, term_ctr(CID_SCON, STAT_OFF + 394), 65ull, term_ctr(CID_SCON, STAT_OFF + 396), 66ull, term_ctr(CID_SCON, STAT_OFF + 398), 69ull, term_ctr(CID_SCON, STAT_OFF + 370), 86ull, term_ctr(CID_SCON, STAT_OFF + 402), 82ull, term_ctr(CID_SCON, STAT_OFF + 404), 69ull, term_ctr(CID_SCON, STAT_OFF + 406), 83ull, term_ctr(CID_SCON, STAT_OFF + 408), 69ull, term_ctr(CID_SCON, STAT_OFF + 410), 82ull, term_ctr(CID_SCON, STAT_OFF + 412), 95ull, term_ctr(CID_SCON, STAT_OFF + 414), 68ull, term_ctr(CID_SCON, STAT_OFF + 416), 65ull, term_ctr(CID_SCON, STAT_OFF + 418), 66ull, term_ctr(CID_SCON, STAT_OFF + 420), 84ull, term_ctr(CID_SCON, STAT_OFF + 152), 65ull, term_ctr(CID_SCON, STAT_OFF + 424), 69ull, term_ctr(CID_SCON, STAT_OFF + 426), 82ull, term_ctr(CID_SCON, STAT_OFF + 428), 67ull, term_ctr(CID_SCON, STAT_OFF + 430), 95ull, term_ctr(CID_SCON, STAT_OFF + 432), 88ull, term_ctr(CID_SCON, STAT_OFF + 434), 84ull, term_ctr(CID_SCON, STAT_OFF + 436), 95ull, term_ctr(CID_SCON, STAT_OFF + 438), 68ull, term_ctr(CID_SCON, STAT_OFF + 440), 65ull, term_ctr(CID_SCON, STAT_OFF + 442), 66ull, term_ctr(CID_SCON, STAT_OFF + 444), 84ull, term_ctr(CID_SCON, STAT_OFF + 402), 65ull, term_ctr(CID_SCON, STAT_OFF + 448), 69ull, term_ctr(CID_SCON, STAT_OFF + 450), 82ull, term_ctr(CID_SCON, STAT_OFF + 452), 67ull, term_ctr(CID_SCON, STAT_OFF + 454), 95ull, term_ctr(CID_SCON, STAT_OFF + 456), 68ull, term_ctr(CID_SCON, STAT_OFF + 458), 65ull, term_ctr(CID_SCON, STAT_OFF + 460), 66ull, term_ctr(CID_SCON, STAT_OFF + 462) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_3 = 0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _h1b_0 = r0;
  u32 _h2b_0 = r1;
  Term _rr_0 = r2;
  Term _rr_1 = r3;
  u32 _rr_2 = r4;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h1b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _rr_0);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h2b_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _rr_1);
    _v_3 = term_ctr(CID_SCON, _nd_2);
    _v_4 = term_ctr(CID_SCON, _nd_3);
    _v_5 = _rr_2;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = (U32_BIN(_a_1, >, _b_1) + U32_BIN(_a_1, >=, _b_1));
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_0);
    _v_1 = _p_1;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_1 = 0;
  u32 _c_0 = r0;
  WL_SPIN
    if (_c_0 == 1) {
      _v_1 = 1;
    } else {
      _v_1 = 0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 56);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 62);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  Term _aux_2 = r2;
  Term _metadata_8 = r3;
  Term _metadata_9 = r4;
  Term _metadata_10 = r5;
  Term _metadata_11 = r6;
  u32 _capacity_2 = r7;
  Term _depth_2 = r8;
  u32 _high_2 = r9;
  Term _pending_2 = r10;
  u32 _ledger_4 = r11;
  Term _ledger_5 = r12;
  Term _mode_2 = r13;
  Term _main_0 = r14;
  u32 _index_2 = r15;
  Term _result_4 = r16;
  Term _result_5 = r17;
  WL_SPIN
    Term _at_0 = _main_0 == h14 ? q14 : blk_loc(e.mem, _main_0);
    Term _at_1 = blk_at(_main_0, _index_2, 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, 1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _result_4);
    term_sink(e, _c_1);
    _v_17 = _namespace_2;
    _v_18 = _next_2;
    _v_19 = _main_0;
    _v_20 = _aux_2;
    _v_21 = _metadata_8;
    _v_22 = _metadata_9;
    _v_23 = _metadata_10;
    _v_24 = _metadata_11;
    _v_25 = _capacity_2;
    _v_26 = _depth_2;
    _v_27 = _high_2;
    _v_28 = _pending_2;
    _v_29 = _ledger_4;
    _v_30 = _ledger_5;
    _v_31 = _mode_2;
    _v_32 = 0;
    _v_33 = _result_5;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _c_0 = r0;
  Term _a_1 = r1;
  Term _b_1 = r2;
  WL_SPIN
    if (_c_0 == 0) {
      term_sink(e, _a_1);
      _v_1 = _b_1;
    } else {
      term_sink(e, _b_1);
      _v_1 = _a_1;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_3 = 0;
    } else {
      _v_3 = _b_0;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_4 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_5 = blk_at(_columns_0, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_0);
    Term _at_6 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_7 = blk_at(_columns_1, _index_0, 1);
    u32 _c_5 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_6 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _meta_1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _meta_2);
    term_sink(e, _c_6);
    Term _at_8 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_9 = blk_at(_columns_2, _index_0, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _meta_3);
    Term _at_10 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_11 = blk_at(_columns_3, _index_0, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _meta_4);
    _v_8 = _columns_0;
    _v_9 = _columns_1;
    _v_10 = _columns_2;
    _v_11 = _columns_3;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_14 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    u32 _x_0 = ((_a_0 >> 0) & 1);
    u32 _x_1 = ((_a_0 >> 1) & 1);
    u32 _x_2 = ((_a_0 >> 2) & 1);
    u32 _x_3 = ((_a_0 >> 3) & 1);
    u32 _x_4 = ((_a_0 >> 4) & 1);
    u32 _x_5 = ((_a_0 >> 5) & 1);
    u32 _x_6 = ((_a_0 >> 6) & 1);
    u32 _x_7 = ((_a_0 >> 7) & 1);
    u32 _x_8 = ((_a_0 >> 8) & 1);
    u32 _x_9 = ((_a_0 >> 9) & 1);
    u32 _x_10 = ((_a_0 >> 10) & 1);
    u32 _x_11 = ((_a_0 >> 11) & 1);
    u32 _x_12 = ((_a_0 >> 12) & 1);
    u32 _x_13 = ((_a_0 >> 13) & 1);
    u32 _x_14 = ((_a_0 >> 14) & 1);
    u32 _x_15 = ((_a_0 >> 15) & 1);
    u32 _x_16 = ((_a_0 >> 16) & 1);
    u32 _x_17 = ((_a_0 >> 17) & 1);
    u32 _x_18 = ((_a_0 >> 18) & 1);
    u32 _x_19 = ((_a_0 >> 19) & 1);
    u32 _x_20 = ((_a_0 >> 20) & 1);
    u32 _x_21 = ((_a_0 >> 21) & 1);
    u32 _x_22 = ((_a_0 >> 22) & 1);
    u32 _x_23 = ((_a_0 >> 23) & 1);
    u32 _x_24 = ((_a_0 >> 24) & 1);
    u32 _x_25 = ((_a_0 >> 25) & 1);
    u32 _x_26 = ((_a_0 >> 26) & 1);
    u32 _x_27 = ((_a_0 >> 27) & 1);
    u32 _x_28 = ((_a_0 >> 28) & 1);
    u32 _x_29 = ((_a_0 >> 29) & 1);
    u32 _x_30 = ((_a_0 >> 30) & 1);
    u32 _x_31 = ((_a_0 >> 31) & 1);
    u32 _y_0 = ((_b_0 >> 0) & 1);
    u32 _y_1 = ((_b_0 >> 1) & 1);
    u32 _y_2 = ((_b_0 >> 2) & 1);
    u32 _y_3 = ((_b_0 >> 3) & 1);
    u32 _y_4 = ((_b_0 >> 4) & 1);
    u32 _y_5 = ((_b_0 >> 5) & 1);
    u32 _y_6 = ((_b_0 >> 6) & 1);
    u32 _y_7 = ((_b_0 >> 7) & 1);
    u32 _y_8 = ((_b_0 >> 8) & 1);
    u32 _y_9 = ((_b_0 >> 9) & 1);
    u32 _y_10 = ((_b_0 >> 10) & 1);
    u32 _y_11 = ((_b_0 >> 11) & 1);
    u32 _y_12 = ((_b_0 >> 12) & 1);
    u32 _y_13 = ((_b_0 >> 13) & 1);
    u32 _y_14 = ((_b_0 >> 14) & 1);
    u32 _y_15 = ((_b_0 >> 15) & 1);
    u32 _y_16 = ((_b_0 >> 16) & 1);
    u32 _y_17 = ((_b_0 >> 17) & 1);
    u32 _y_18 = ((_b_0 >> 18) & 1);
    u32 _y_19 = ((_b_0 >> 19) & 1);
    u32 _y_20 = ((_b_0 >> 20) & 1);
    u32 _y_21 = ((_b_0 >> 21) & 1);
    u32 _y_22 = ((_b_0 >> 22) & 1);
    u32 _y_23 = ((_b_0 >> 23) & 1);
    u32 _y_24 = ((_b_0 >> 24) & 1);
    u32 _y_25 = ((_b_0 >> 25) & 1);
    u32 _y_26 = ((_b_0 >> 26) & 1);
    u32 _y_27 = ((_b_0 >> 27) & 1);
    u32 _y_28 = ((_b_0 >> 28) & 1);
    u32 _y_29 = ((_b_0 >> 29) & 1);
    u32 _y_30 = ((_b_0 >> 30) & 1);
    u32 _y_31 = ((_b_0 >> 31) & 1);
    Term _v_15 = 0;
    Term _o_1[1];
    Term _a_1 = (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31));
    Term _a_2 = (((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31));
    if (spin_6(e, _o_1, U32_BIN((((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31)), <, (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31))), _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_15 = _o_1[0];
    _v_14 = _v_15;
  break;
  }
  o[0] = _v_14;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_4 = r2;
  Term _metadata_5 = r3;
  Term _metadata_6 = r4;
  Term _metadata_7 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _live_0 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_live_0 == 1) {
      _v_19 = 1;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _metadata_4;
      _v_23 = _metadata_5;
      _v_24 = _metadata_6;
      _v_25 = _metadata_7;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _high_1;
      _v_29 = _row_9;
      _v_30 = _row_10;
      _v_31 = _row_11;
      _v_32 = _row_12;
      _v_33 = _row_13;
      _v_34 = _row_14;
      _v_35 = _row_15;
      _v_36 = _row_16;
      _v_37 = _row_17;
    } else {
      Term _at_0 = _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_10);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_11);
      term_sink(e, _c_1);
      Term _at_2 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
      Term _at_3 = blk_at(_aux_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_12);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_13);
      term_sink(e, _c_3);
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_0[4];
      if (spin_8(e, _o_0, _metadata_4, _metadata_4 == h2 ? q2 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h3 ? q3 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h4 ? q4 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h5 ? q5 : blk_loc(e.mem, _metadata_7), U32_BIN(_row_9, -, 1ull), 1, _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
        return 0;
      }
      _v_42 = _o_0[0];
      _v_43 = _o_0[1];
      _v_44 = _o_0[2];
      _v_45 = _o_0[3];
      _v_38 = _v_42;
      _v_39 = _v_43;
      _v_40 = _v_44;
      _v_41 = _v_45;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_1[1];
      if (spin_9(e, _o_1, _high_1, _row_9) == 0) {
        return 0;
      }
      _v_47 = _o_1[0];
      _v_46 = _v_47;
      _v_19 = 0;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _v_38;
      _v_23 = _v_39;
      _v_24 = _v_40;
      _v_25 = _v_41;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _v_46;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  Term _main_1 = r1;
  WL_SPIN
    _v_8 = 1;
    _v_9 = _id_0;
    _v_10 = _main_1;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, Term r12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h16 = r16;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  Term _main_1 = r1;
  u32 _value_2 = r2;
  Term _value_3 = r3;
  Term _aux_0 = r4;
  u32 _av_0 = r5;
  Term _av_1 = r6;
  Term _metadata_4 = r7;
  Term _metadata_5 = r8;
  Term _metadata_6 = r9;
  Term _metadata_7 = r10;
  u32 _capacity_1 = r11;
  Term _depth_1 = r12;
  u32 _high_1 = r13;
  u32 _meta_5 = r14;
  u32 _meta_6 = r15;
  Term _meta_7 = r16;
  u32 _meta_8 = r17;
  u32 _meta_9 = r18;
  WL_SPIN
    _v_19 = _main_1;
    _v_20 = _aux_0;
    _v_21 = _metadata_4;
    _v_22 = _metadata_5;
    _v_23 = _metadata_6;
    _v_24 = _metadata_7;
    _v_25 = _capacity_1;
    _v_26 = _depth_1;
    _v_27 = _high_1;
    _v_28 = 1;
    _v_29 = _id_1;
    _v_30 = _value_2;
    _v_31 = _value_3;
    _v_32 = _av_0;
    _v_33 = _av_1;
    _v_34 = _meta_6;
    _v_35 = _meta_7;
    _v_36 = _meta_8;
    _v_37 = _meta_9;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _live_1 = r0;
  Term _flags_1 = r1;
  Term _added_0 = r2;
  u32 _l_1 = r3;
  u32 _f_2 = r4;
  Term _f_3 = r5;
  u32 _a_0 = r6;
  Term _result_2 = r7;
  u32 _result_3 = r8;
  WL_SPIN
    _v_9 = _live_1;
    _v_10 = _flags_1;
    _v_11 = _added_0;
    _v_12 = _result_2;
    _v_13 = _l_1;
    _v_14 = _f_2;
    _v_15 = _f_3;
    _v_16 = _a_0;
    _v_17 = _result_3;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h17 = r17;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_0 = r2;
  Term _aux_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _flag_2 = r11;
  Term _flag_3 = r12;
  u32 _added_1 = r13;
  u32 _changed_1 = r14;
  u32 _insert_1 = r15;
  u32 _old_0 = r16;
  Term _old_1 = r17;
  WL_SPIN
    if (_insert_1 == 0) {
      if (_old_0 == 0) {
        term_sink(e, _flag_3);
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _metadata_4;
        _v_13 = _metadata_5;
        _v_14 = _metadata_6;
        _v_15 = _metadata_7;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 4;
      } else {
        term_sink(e, _old_1);
        Term _v_20 = 0;
        Term _v_21 = 0;
        Term _v_22 = 0;
        Term _v_23 = 0;
        Term _v_24 = 0;
        Term _v_25 = 0;
        Term _v_26 = 0;
        Term _v_27 = 0;
        Term _o_0[4];
        if (spin_8(e, _o_0, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), 0ull, 0ull) == 0) {
          return 0;
        }
        _v_24 = _o_0[0];
        _v_25 = _o_0[1];
        _v_26 = _o_0[2];
        _v_27 = _o_0[3];
        _v_20 = _v_24;
        _v_21 = _v_25;
        _v_22 = _v_26;
        _v_23 = _v_27;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_20;
        _v_13 = _v_21;
        _v_14 = _v_22;
        _v_15 = _v_23;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 3;
      }
    } else {
      if (_old_0 == 0) {
        Term _v_28 = 0;
        Term _v_29 = 0;
        Term _v_30 = 0;
        Term _v_31 = 0;
        Term _v_32 = 0;
        Term _v_33 = 0;
        Term _v_34 = 0;
        Term _v_35 = 0;
        Term _o_1[4];
        if (spin_8(e, _o_1, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), _tick_1, _tick_1) == 0) {
          return 0;
        }
        _v_32 = _o_1[0];
        _v_33 = _o_1[1];
        _v_34 = _o_1[2];
        _v_35 = _o_1[3];
        _v_28 = _v_32;
        _v_29 = _v_33;
        _v_30 = _v_34;
        _v_31 = _v_35;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_28;
        _v_13 = _v_29;
        _v_14 = _v_30;
        _v_15 = _v_31;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 1;
      } else {
        term_sink(e, _old_1);
        Term _v_36 = 0;
        Term _v_37 = 0;
        Term _v_38 = 0;
        Term _v_39 = 0;
        Term _v_40 = 0;
        Term _v_41 = 0;
        Term _v_42 = 0;
        Term _v_43 = 0;
        Term _o_2[4];
        if (spin_8(e, _o_2, _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), U32_BIN(_id_1, -, 1ull), 1, _flag_2, _flag_3, _flag_3 == h12 ? q12 : blk_loc(e.mem, _flag_3), _added_1, _tick_1) == 0) {
          return 0;
        }
        _v_40 = _o_2[0];
        _v_41 = _o_2[1];
        _v_42 = _o_2[2];
        _v_43 = _o_2[3];
        _v_36 = _v_40;
        _v_37 = _v_41;
        _v_38 = _v_42;
        _v_39 = _v_43;
        _v_10 = _main_0;
        _v_11 = _aux_1;
        _v_12 = _v_36;
        _v_13 = _v_37;
        _v_14 = _v_38;
        _v_15 = _v_39;
        _v_16 = _capacity_1;
        _v_17 = _depth_1;
        _v_18 = _high_1;
        _v_19 = 2;
      }
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  Term _result_0 = r3;
  u32 _result_1 = r4;
  WL_SPIN
    _v_5 = _result_0;
    _v_6 = _flags_0;
    _v_7 = _added_0;
    _v_8 = _changed_0;
    _v_9 = _result_1;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _row_9 = r9;
  u32 _row_10 = r10;
  Term _row_11 = r11;
  u32 _row_12 = r12;
  Term _row_13 = r13;
  u32 _row_14 = r14;
  Term _row_15 = r15;
  u32 _row_16 = r16;
  u32 _row_17 = r17;
  u32 _meta_0 = r18;
  WL_SPIN
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_10(e, _o_0, _main_1, _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _row_9, _row_10, _row_11, _row_11 == h11 ? q11 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h13 ? q13 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h15 ? q15 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  Term _flag_1 = r1;
  WL_SPIN
    _v_8 = 2;
    _v_9 = _id_0;
    _v_10 = _flag_1;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  Term _main_0 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _meta_5 = r11;
  u32 _meta_6 = r12;
  Term _meta_7 = r13;
  u32 _meta_8 = r14;
  u32 _meta_9 = r15;
  Term _result_3 = r16;
  u32 _result_4 = r17;
  Term _result_5 = r18;
  WL_SPIN
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_12(e, _o_0, _id_1, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _value_0, _value_1, _value_1 == h3 ? q3 : blk_loc(e.mem, _value_1), _result_3, _result_3 == h16 ? q16 : blk_loc(e.mem, _result_3), _result_4, _result_5, _result_5 == h18 ? q18 : blk_loc(e.mem, _result_5), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _meta_5, _meta_6, _meta_7, _meta_7 == h13 ? q13 : blk_loc(e.mem, _meta_7), _meta_8, _meta_9) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _live_1 = r0;
  Term _flags_0 = r1;
  Term _changed_1 = r2;
  u32 _index_1 = r3;
  u32 _l_1 = r4;
  u32 _f_0 = r5;
  Term _f_1 = r6;
  Term _result_3 = r7;
  u32 _result_4 = r8;
  WL_SPIN
    Term _at_2 = _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1);
    Term _at_3 = blk_at(_changed_1, _index_1, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _o_0[9];
    if (spin_13(e, _o_0, _live_1, _live_1 == h0 ? q0 : blk_loc(e.mem, _live_1), _flags_0, _flags_0 == h1 ? q1 : blk_loc(e.mem, _flags_0), _result_3, _result_3 == h7 ? q7 : blk_loc(e.mem, _result_3), _l_1, _f_0, _f_1, _f_1 == h6 ? q6 : blk_loc(e.mem, _f_1), _result_4, _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _c_1) == 0) {
      return 0;
    }
    _v_18 = _o_0[0];
    _v_19 = _o_0[1];
    _v_20 = _o_0[2];
    _v_21 = _o_0[3];
    _v_22 = _o_0[4];
    _v_23 = _o_0[5];
    _v_24 = _o_0[6];
    _v_25 = _o_0[7];
    _v_26 = _o_0[8];
    _v_9 = _v_18;
    _v_10 = _v_19;
    _v_11 = _v_20;
    _v_12 = _v_21;
    _v_13 = _v_22;
    _v_14 = _v_23;
    _v_15 = _v_24;
    _v_16 = _v_25;
    _v_17 = _v_26;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _aux_1 = r2;
  Term _metadata_4 = r3;
  Term _metadata_5 = r4;
  Term _metadata_6 = r5;
  Term _metadata_7 = r6;
  u32 _capacity_1 = r7;
  Term _depth_1 = r8;
  u32 _high_1 = r9;
  u32 _flag_2 = r10;
  Term _flag_3 = r11;
  u32 _added_1 = r12;
  u32 _changed_1 = r13;
  u32 _insert_0 = r14;
  Term _result_0 = r15;
  u32 _result_1 = r16;
  Term _result_2 = r17;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[10];
    if (spin_14(e, _o_0, _id_1, _tick_1, _result_0, _result_0 == h15 ? q15 : blk_loc(e.mem, _result_0), _aux_1, _aux_1 == h2 ? q2 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h3 ? q3 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h4 ? q4 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h5 ? q5 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h6 ? q6 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_2, _flag_3, _flag_3 == h11 ? q11 : blk_loc(e.mem, _flag_3), _added_1, _changed_1, _insert_0, _result_1, _result_2, _result_2 == h17 ? q17 : blk_loc(e.mem, _result_2)) == 0) {
      return 0;
    }
    _v_20 = _o_0[0];
    _v_21 = _o_0[1];
    _v_22 = _o_0[2];
    _v_23 = _o_0[3];
    _v_24 = _o_0[4];
    _v_25 = _o_0[5];
    _v_26 = _o_0[6];
    _v_27 = _o_0[7];
    _v_28 = _o_0[8];
    _v_29 = _o_0[9];
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  Term _depth_0 = r4;
  WL_SPIN
    Term _fv_0[1];
    _fv_0[0] = 0;
    Term _fv_1[2];
    _fv_1[0] = 0;
    _fv_1[1] = 0;
    Term _fv_2[1];
    _fv_2[0] = 0ull;
    Term _fv_3[1];
    _fv_3[0] = 0ull;
    _v_8 = blk_node(e, _columns_0, blk_new(e, 0, _depth_0, 0, 1, _fv_0));
    _v_9 = blk_node(e, _columns_1, blk_new(e, 1, _depth_0, 1, 2, _fv_1));
    _v_10 = blk_node(e, _columns_2, blk_new(e, 0, _depth_0, 0, 1, _fv_2));
    _v_11 = blk_node(e, _columns_3, blk_new(e, 0, _depth_0, 0, 1, _fv_3));
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[5];
    if (spin_15(e, _o_0, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h7 = r7;
  Term h9 = r9;
  Term h11 = r11;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _main_0 = r0;
  Term _aux_0 = r1;
  u32 _capacity_0 = r2;
  Term _depth_0 = r3;
  u32 _high_0 = r4;
  u32 _row_9 = r5;
  u32 _row_10 = r6;
  Term _row_11 = r7;
  u32 _row_12 = r8;
  Term _row_13 = r9;
  u32 _row_14 = r10;
  Term _row_15 = r11;
  u32 _row_16 = r12;
  u32 _row_17 = r13;
  Term _result_0 = r14;
  Term _result_1 = r15;
  Term _result_2 = r16;
  Term _result_3 = r17;
  u32 _result_4 = r18;
  WL_SPIN
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _o_2[19];
    if (spin_16(e, _o_2, _main_0, _main_0 == h0 ? q0 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h1 ? q1 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h14 ? q14 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h15 ? q15 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h16 ? q16 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h17 ? q17 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _row_9, _row_10, _row_11, _row_11 == h7 ? q7 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h9 ? q9 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h11 ? q11 : blk_loc(e.mem, _row_15), _row_16, _row_17, _result_4) == 0) {
      return 0;
    }
    _v_58 = _o_2[0];
    _v_59 = _o_2[1];
    _v_60 = _o_2[2];
    _v_61 = _o_2[3];
    _v_62 = _o_2[4];
    _v_63 = _o_2[5];
    _v_64 = _o_2[6];
    _v_65 = _o_2[7];
    _v_66 = _o_2[8];
    _v_67 = _o_2[9];
    _v_68 = _o_2[10];
    _v_69 = _o_2[11];
    _v_70 = _o_2[12];
    _v_71 = _o_2[13];
    _v_72 = _o_2[14];
    _v_73 = _o_2[15];
    _v_74 = _o_2[16];
    _v_75 = _o_2[17];
    _v_76 = _o_2[18];
    _v_39 = _v_58;
    _v_40 = _v_59;
    _v_41 = _v_60;
    _v_42 = _v_61;
    _v_43 = _v_62;
    _v_44 = _v_63;
    _v_45 = _v_64;
    _v_46 = _v_65;
    _v_47 = _v_66;
    _v_48 = _v_67;
    _v_49 = _v_68;
    _v_50 = _v_69;
    _v_51 = _v_70;
    _v_52 = _v_71;
    _v_53 = _v_72;
    _v_54 = _v_73;
    _v_55 = _v_74;
    _v_56 = _v_75;
    _v_57 = _v_76;
  break;
  }
  o[0] = _v_39;
  o[1] = _v_40;
  o[2] = _v_41;
  o[3] = _v_42;
  o[4] = _v_43;
  o[5] = _v_44;
  o[6] = _v_45;
  o[7] = _v_46;
  o[8] = _v_47;
  o[9] = _v_48;
  o[10] = _v_49;
  o[11] = _v_50;
  o[12] = _v_51;
  o[13] = _v_52;
  o[14] = _v_53;
  o[15] = _v_54;
  o[16] = _v_55;
  o[17] = _v_56;
  o[18] = _v_57;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  WL_SPIN
    _v_8 = 3;
    _v_9 = _id_0;
    _v_10 = 0;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _world_15 = r0;
  u32 _world_16 = r1;
  Term _world_17 = r2;
  Term _world_18 = r3;
  Term _world_19 = r4;
  Term _world_20 = r5;
  Term _world_21 = r6;
  Term _world_22 = r7;
  u32 _world_23 = r8;
  Term _world_24 = r9;
  u32 _world_25 = r10;
  Term _world_26 = r11;
  u32 _world_27 = r12;
  Term _world_28 = r13;
  Term _world_29 = r14;
  WL_SPIN
    term_sink(e, _world_26);
    _v_30 = _world_15;
    _v_31 = _world_16;
    _v_32 = _world_17;
    _v_33 = _world_18;
    _v_34 = _world_19;
    _v_35 = _world_20;
    _v_36 = _world_21;
    _v_37 = _world_22;
    _v_38 = _world_23;
    _v_39 = _world_24;
    _v_40 = _world_25;
    _v_41 = term_pak(CID_NIL, 0);
    _v_42 = _world_27;
    _v_43 = _world_28;
    _v_44 = _world_29;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_95 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_95 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_1 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_1);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_28);
    }
  break;
  }
  o[0] = _v_95;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_93 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_94 = 0;
    Term _o_1[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_28(e, _o_1, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_94 = _o_1[0];
    _v_93 = _v_94;
  break;
  }
  o[0] = _v_93;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  Term _v_77 = 0;
  Term _v_78 = 0;
  Term _v_79 = 0;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  u32 _v_83 = 0;
  Term _v_84 = 0;
  u32 _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  Term _v_89 = 0;
  u32 _world_60 = r0;
  u32 _world_61 = r1;
  Term _world_62 = r2;
  Term _world_63 = r3;
  Term _world_64 = r4;
  Term _world_65 = r5;
  Term _world_66 = r6;
  Term _world_67 = r7;
  u32 _world_68 = r8;
  Term _world_69 = r9;
  u32 _world_70 = r10;
  Term _world_71 = r11;
  u32 _world_72 = r12;
  Term _world_73 = r13;
  Term _world_74 = r14;
  Term _staged_0 = r15;
  WL_SPIN
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _o_2[1];
    if (spin_27(e, _o_2, _staged_0, _staged_0 == h15 ? q15 : blk_loc(e.mem, _staged_0)) == 0) {
      return 0;
    }
    _v_92 = _o_2[0];
    _v_91 = _v_92;
    Term _v_96 = 0;
    Term _o_3[1];
    if (spin_28(e, _o_3, _v_91, _v_91 == h15 ? q15 : _v_91 == h14 ? q14 : _v_91 == h13 ? q13 : _v_91 == h11 ? q11 : _v_91 == h7 ? q7 : _v_91 == h6 ? q6 : _v_91 == h5 ? q5 : _v_91 == h4 ? q4 : _v_91 == h3 ? q3 : _v_91 == h2 ? q2 : blk_loc(e.mem, _v_91), _world_71, _world_71 == h11 ? q11 : blk_loc(e.mem, _world_71)) == 0) {
      return 0;
    }
    _v_96 = _o_3[0];
    _v_90 = _v_96;
    _v_75 = _world_60;
    _v_76 = _world_61;
    _v_77 = _world_62;
    _v_78 = _world_63;
    _v_79 = _world_64;
    _v_80 = _world_65;
    _v_81 = _world_66;
    _v_82 = _world_67;
    _v_83 = _world_68;
    _v_84 = _world_69;
    _v_85 = _world_70;
    _v_86 = _v_90;
    _v_87 = _world_72;
    _v_88 = _world_73;
    _v_89 = _world_74;
  break;
  }
  o[0] = _v_75;
  o[1] = _v_76;
  o[2] = _v_77;
  o[3] = _v_78;
  o[4] = _v_79;
  o[5] = _v_80;
  o[6] = _v_81;
  o[7] = _v_82;
  o[8] = _v_83;
  o[9] = _v_84;
  o[10] = _v_85;
  o[11] = _v_86;
  o[12] = _v_87;
  o[13] = _v_88;
  o[14] = _v_89;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _meta_0 = r9;
  u32 _meta_1 = r10;
  Term _meta_2 = r11;
  u32 _meta_3 = r12;
  u32 _meta_4 = r13;
  Term _result_9 = r14;
  u32 _result_10 = r15;
  Term _result_11 = r16;
  WL_SPIN
    Term _at_2 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
    Term _at_3 = blk_at(_aux_1, U32_BIN(_id_1, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, 0);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, 0);
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_18(e, _o_0, _id_1, _result_9, _result_9 == h14 ? q14 : blk_loc(e.mem, _result_9), _result_10, _result_11, _result_11 == h16 ? q16 : blk_loc(e.mem, _result_11), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _meta_1, _meta_2, _meta_2 == h11 ? q11 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _c_2, _c_3, _c_3 == h16 ? q16 : _c_3 == h14 ? q14 : _c_3 == h11 ? q11 : _c_3 == h5 ? q5 : _c_3 == h4 ? q4 : _c_3 == h3 ? q3 : _c_3 == h2 ? q2 : _c_3 == h1 ? q1 : blk_loc(e.mem, _c_3)) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_153 = 0;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  Term _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  Term _live_0 = r0;
  Term _added_1 = r1;
  Term _changed_1 = r2;
  u32 _index_2 = r3;
  u32 _l_0 = r4;
  Term _result_2 = r5;
  u32 _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    Term _at_4 = _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1);
    Term _at_5 = blk_at(_added_1, _index_2, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    Term _v_162 = 0;
    Term _v_163 = 0;
    Term _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    Term _o_2[9];
    if (spin_19(e, _o_2, _live_0, _live_0 == h0 ? q0 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h5 ? q5 : blk_loc(e.mem, _result_2), _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _index_2, _l_0, _result_3, _result_4, _result_4 == h7 ? q7 : blk_loc(e.mem, _result_4), _added_1, _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1), _c_3) == 0) {
      return 0;
    }
    _v_162 = _o_2[0];
    _v_163 = _o_2[1];
    _v_164 = _o_2[2];
    _v_165 = _o_2[3];
    _v_166 = _o_2[4];
    _v_167 = _o_2[5];
    _v_168 = _o_2[6];
    _v_169 = _o_2[7];
    _v_170 = _o_2[8];
    _v_153 = _v_162;
    _v_154 = _v_163;
    _v_155 = _v_164;
    _v_156 = _v_165;
    _v_157 = _v_166;
    _v_158 = _v_167;
    _v_159 = _v_168;
    _v_160 = _v_169;
    _v_161 = _v_170;
  break;
  }
  o[0] = _v_153;
  o[1] = _v_154;
  o[2] = _v_155;
  o[3] = _v_156;
  o[4] = _v_157;
  o[5] = _v_158;
  o[6] = _v_159;
  o[7] = _v_160;
  o[8] = _v_161;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term _v_135 = 0;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  Term _v_141 = 0;
  u32 _v_142 = 0;
  u32 _v_143 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  u32 _index_1 = r3;
  Term _result_0 = r4;
  u32 _result_1 = r5;
  WL_SPIN
    Term _at_2 = _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0);
    Term _at_3 = blk_at(_flags_0, _index_1, 1);
    u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
    Term _v_144 = 0;
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    Term _o_3[9];
    if (spin_34(e, _o_3, _result_0, _result_0 == h4 ? q4 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h1 ? q1 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), _index_1, _result_1, _flags_0, _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0), _c_1, _c_2, _c_2 == h4 ? q4 : _c_2 == h2 ? q2 : _c_2 == h1 ? q1 : _c_2 == h0 ? q0 : blk_loc(e.mem, _c_2)) == 0) {
      return 0;
    }
    _v_144 = _o_3[0];
    _v_145 = _o_3[1];
    _v_146 = _o_3[2];
    _v_147 = _o_3[3];
    _v_148 = _o_3[4];
    _v_149 = _o_3[5];
    _v_150 = _o_3[6];
    _v_151 = _o_3[7];
    _v_152 = _o_3[8];
    _v_135 = _v_144;
    _v_136 = _v_145;
    _v_137 = _v_146;
    _v_138 = _v_147;
    _v_139 = _v_148;
    _v_140 = _v_149;
    _v_141 = _v_150;
    _v_142 = _v_151;
    _v_143 = _v_152;
  break;
  }
  o[0] = _v_135;
  o[1] = _v_136;
  o[2] = _v_137;
  o[3] = _v_138;
  o[4] = _v_139;
  o[5] = _v_140;
  o[6] = _v_141;
  o[7] = _v_142;
  o[8] = _v_143;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  u32 _v_121 = 0;
  u32 _v_122 = 0;
  Term _v_123 = 0;
  u32 _v_124 = 0;
  u32 _v_125 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_126 = 0;
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    Term _o_4[9];
    if (spin_33(e, _o_4, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _index_0, _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_126 = _o_4[0];
    _v_127 = _o_4[1];
    _v_128 = _o_4[2];
    _v_129 = _o_4[3];
    _v_130 = _o_4[4];
    _v_131 = _o_4[5];
    _v_132 = _o_4[6];
    _v_133 = _o_4[7];
    _v_134 = _o_4[8];
    _v_117 = _v_126;
    _v_118 = _v_127;
    _v_119 = _v_128;
    _v_120 = _v_129;
    _v_121 = _v_130;
    _v_122 = _v_131;
    _v_123 = _v_132;
    _v_124 = _v_133;
    _v_125 = _v_134;
  break;
  }
  o[0] = _v_117;
  o[1] = _v_118;
  o[2] = _v_119;
  o[3] = _v_120;
  o[4] = _v_121;
  o[5] = _v_122;
  o[6] = _v_123;
  o[7] = _v_124;
  o[8] = _v_125;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term _v_190 = 0;
  Term _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  Term _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  Term _v_197 = 0;
  u32 _v_198 = 0;
  u32 _v_199 = 0;
  u32 _v_200 = 0;
  u32 _v_201 = 0;
  Term _v_202 = 0;
  u32 _v_203 = 0;
  Term _v_204 = 0;
  u32 _v_205 = 0;
  Term _v_206 = 0;
  u32 _v_207 = 0;
  u32 _v_208 = 0;
  u32 _id_3 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  u32 _capacity_0 = r3;
  Term _depth_0 = r4;
  u32 _high_0 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  Term _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  u32 _result_10 = r11;
  Term _result_11 = r12;
  u32 _result_12 = r13;
  u32 _result_13 = r14;
  WL_SPIN
    if (_result_9 == 0) {
      term_sink(e, _result_11);
      _v_190 = _main_0;
      _v_191 = _aux_0;
      _v_192 = _result_5;
      _v_193 = _result_6;
      _v_194 = _result_7;
      _v_195 = _result_8;
      _v_196 = _capacity_0;
      _v_197 = _depth_0;
      _v_198 = _high_0;
      _v_199 = 0;
      _v_200 = 0;
      _v_201 = 0;
      _v_202 = 0;
      _v_203 = 0;
      _v_204 = 0;
      _v_205 = 0;
      _v_206 = 0;
      _v_207 = 0;
      _v_208 = 0;
    } else {
      Term _at_6 = _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0);
      Term _at_7 = blk_at(_main_0, U32_BIN(_id_3, -, 1ull), 1);
      u32 _c_4 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
      Term _c_5 = e.mem[_at_6 + _at_7 + 1];
      blk_write(e.mem, 1, _at_6, _at_7 + 0, 0);
      blk_write(e.mem, 1, _at_6, _at_7 + 1, 0);
      Term _v_209 = 0;
      Term _v_210 = 0;
      Term _v_211 = 0;
      Term _v_212 = 0;
      Term _v_213 = 0;
      Term _v_214 = 0;
      u32 _v_215 = 0;
      Term _v_216 = 0;
      u32 _v_217 = 0;
      u32 _v_218 = 0;
      u32 _v_219 = 0;
      u32 _v_220 = 0;
      Term _v_221 = 0;
      u32 _v_222 = 0;
      Term _v_223 = 0;
      u32 _v_224 = 0;
      Term _v_225 = 0;
      u32 _v_226 = 0;
      u32 _v_227 = 0;
      Term _o_6[19];
      if (spin_29(e, _o_6, _id_3, _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _result_5, _result_5 == h6 ? q6 : blk_loc(e.mem, _result_5), _result_6, _result_6 == h7 ? q7 : blk_loc(e.mem, _result_6), _result_7, _result_7 == h8 ? q8 : blk_loc(e.mem, _result_7), _result_8, _result_8 == h9 ? q9 : blk_loc(e.mem, _result_8), _capacity_0, _depth_0, _high_0, 1, _result_10, _result_11, _result_11 == h12 ? q12 : blk_loc(e.mem, _result_11), _result_12, _result_13, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _c_4, _c_5, _c_5 == h12 ? q12 : _c_5 == h9 ? q9 : _c_5 == h8 ? q8 : _c_5 == h7 ? q7 : _c_5 == h6 ? q6 : _c_5 == h2 ? q2 : _c_5 == h1 ? q1 : blk_loc(e.mem, _c_5)) == 0) {
        return 0;
      }
      _v_209 = _o_6[0];
      _v_210 = _o_6[1];
      _v_211 = _o_6[2];
      _v_212 = _o_6[3];
      _v_213 = _o_6[4];
      _v_214 = _o_6[5];
      _v_215 = _o_6[6];
      _v_216 = _o_6[7];
      _v_217 = _o_6[8];
      _v_218 = _o_6[9];
      _v_219 = _o_6[10];
      _v_220 = _o_6[11];
      _v_221 = _o_6[12];
      _v_222 = _o_6[13];
      _v_223 = _o_6[14];
      _v_224 = _o_6[15];
      _v_225 = _o_6[16];
      _v_226 = _o_6[17];
      _v_227 = _o_6[18];
      _v_190 = _v_209;
      _v_191 = _v_210;
      _v_192 = _v_211;
      _v_193 = _v_212;
      _v_194 = _v_213;
      _v_195 = _v_214;
      _v_196 = _v_215;
      _v_197 = _v_216;
      _v_198 = _v_217;
      _v_199 = _v_218;
      _v_200 = _v_219;
      _v_201 = _v_220;
      _v_202 = _v_221;
      _v_203 = _v_222;
      _v_204 = _v_223;
      _v_205 = _v_224;
      _v_206 = _v_225;
      _v_207 = _v_226;
      _v_208 = _v_227;
    }
  break;
  }
  o[0] = _v_190;
  o[1] = _v_191;
  o[2] = _v_192;
  o[3] = _v_193;
  o[4] = _v_194;
  o[5] = _v_195;
  o[6] = _v_196;
  o[7] = _v_197;
  o[8] = _v_198;
  o[9] = _v_199;
  o[10] = _v_200;
  o[11] = _v_201;
  o[12] = _v_202;
  o[13] = _v_203;
  o[14] = _v_204;
  o[15] = _v_205;
  o[16] = _v_206;
  o[17] = _v_207;
  o[18] = _v_208;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  Term _v_94 = 0;
  u32 _v_95 = 0;
  Term _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _valid_0 = r0;
  u32 _id_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_80 = _rows_18;
      _v_81 = _rows_19;
      _v_82 = _rows_20;
      _v_83 = _rows_21;
      _v_84 = _rows_22;
      _v_85 = _rows_23;
      _v_86 = _rows_24;
      _v_87 = _rows_25;
      _v_88 = _rows_26;
      _v_89 = 0;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
    } else {
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      u32 _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_5[9];
      if (spin_32(e, _o_5, _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), U32_BIN(_id_2, -, 1ull)) == 0) {
        return 0;
      }
      _v_108 = _o_5[0];
      _v_109 = _o_5[1];
      _v_110 = _o_5[2];
      _v_111 = _o_5[3];
      _v_112 = _o_5[4];
      _v_113 = _o_5[5];
      _v_114 = _o_5[6];
      _v_115 = _o_5[7];
      _v_116 = _o_5[8];
      _v_99 = _v_108;
      _v_100 = _v_109;
      _v_101 = _v_110;
      _v_102 = _v_111;
      _v_103 = _v_112;
      _v_104 = _v_113;
      _v_105 = _v_114;
      _v_106 = _v_115;
      _v_107 = _v_116;
      Term _v_171 = 0;
      Term _v_172 = 0;
      Term _v_173 = 0;
      Term _v_174 = 0;
      Term _v_175 = 0;
      Term _v_176 = 0;
      u32 _v_177 = 0;
      Term _v_178 = 0;
      u32 _v_179 = 0;
      u32 _v_180 = 0;
      u32 _v_181 = 0;
      u32 _v_182 = 0;
      Term _v_183 = 0;
      u32 _v_184 = 0;
      Term _v_185 = 0;
      u32 _v_186 = 0;
      Term _v_187 = 0;
      u32 _v_188 = 0;
      u32 _v_189 = 0;
      Term _o_7[19];
      if (spin_35(e, _o_7, _id_2, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_24, _rows_25, _rows_26, _v_99, _v_99 == h7 ? q7 : _v_99 == h6 ? q6 : _v_99 == h5 ? q5 : _v_99 == h4 ? q4 : _v_99 == h3 ? q3 : _v_99 == h2 ? q2 : blk_loc(e.mem, _v_99), _v_100, _v_100 == h7 ? q7 : _v_100 == h6 ? q6 : _v_100 == h5 ? q5 : _v_100 == h4 ? q4 : _v_100 == h3 ? q3 : _v_100 == h2 ? q2 : blk_loc(e.mem, _v_100), _v_101, _v_101 == h7 ? q7 : _v_101 == h6 ? q6 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : blk_loc(e.mem, _v_101), _v_102, _v_102 == h7 ? q7 : _v_102 == h6 ? q6 : _v_102 == h5 ? q5 : _v_102 == h4 ? q4 : _v_102 == h3 ? q3 : _v_102 == h2 ? q2 : blk_loc(e.mem, _v_102), _v_103, _v_104, _v_105, _v_105 == h7 ? q7 : _v_105 == h6 ? q6 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_171 = _o_7[0];
      _v_172 = _o_7[1];
      _v_173 = _o_7[2];
      _v_174 = _o_7[3];
      _v_175 = _o_7[4];
      _v_176 = _o_7[5];
      _v_177 = _o_7[6];
      _v_178 = _o_7[7];
      _v_179 = _o_7[8];
      _v_180 = _o_7[9];
      _v_181 = _o_7[10];
      _v_182 = _o_7[11];
      _v_183 = _o_7[12];
      _v_184 = _o_7[13];
      _v_185 = _o_7[14];
      _v_186 = _o_7[15];
      _v_187 = _o_7[16];
      _v_188 = _o_7[17];
      _v_189 = _o_7[18];
      _v_80 = _v_171;
      _v_81 = _v_172;
      _v_82 = _v_173;
      _v_83 = _v_174;
      _v_84 = _v_175;
      _v_85 = _v_176;
      _v_86 = _v_177;
      _v_87 = _v_178;
      _v_88 = _v_179;
      _v_89 = _v_180;
      _v_90 = _v_181;
      _v_91 = _v_182;
      _v_92 = _v_183;
      _v_93 = _v_184;
      _v_94 = _v_185;
      _v_95 = _v_186;
      _v_96 = _v_187;
      _v_97 = _v_188;
      _v_98 = _v_189;
    }
  break;
  }
  o[0] = _v_80;
  o[1] = _v_81;
  o[2] = _v_82;
  o[3] = _v_83;
  o[4] = _v_84;
  o[5] = _v_85;
  o[6] = _v_86;
  o[7] = _v_87;
  o[8] = _v_88;
  o[9] = _v_89;
  o[10] = _v_90;
  o[11] = _v_91;
  o[12] = _v_92;
  o[13] = _v_93;
  o[14] = _v_94;
  o[15] = _v_95;
  o[16] = _v_96;
  o[17] = _v_97;
  o[18] = _v_98;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, U32_BIN(_id_1, <=, _rows_15), U32_BIN(_id_1, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_59 = _o_0[0];
    _v_58 = _v_59;
    u32 _v_60 = 0;
    Term _o_1[1];
    if (spin_7(e, _o_1, U32_BIN(0ull, <, _id_1), _v_58) == 0) {
      return 0;
    }
    _v_60 = _o_1[0];
    _v_57 = _v_60;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_8[19];
    if (spin_31(e, _o_8, _v_57, _id_1, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17) == 0) {
      return 0;
    }
    _v_61 = _o_8[0];
    _v_62 = _o_8[1];
    _v_63 = _o_8[2];
    _v_64 = _o_8[3];
    _v_65 = _o_8[4];
    _v_66 = _o_8[5];
    _v_67 = _o_8[6];
    _v_68 = _o_8[7];
    _v_69 = _o_8[8];
    _v_70 = _o_8[9];
    _v_71 = _o_8[10];
    _v_72 = _o_8[11];
    _v_73 = _o_8[12];
    _v_74 = _o_8[13];
    _v_75 = _o_8[14];
    _v_76 = _o_8[15];
    _v_77 = _o_8[16];
    _v_78 = _o_8[17];
    _v_79 = _o_8[18];
    _v_38 = _v_61;
    _v_39 = _v_62;
    _v_40 = _v_63;
    _v_41 = _v_64;
    _v_42 = _v_65;
    _v_43 = _v_66;
    _v_44 = _v_67;
    _v_45 = _v_68;
    _v_46 = _v_69;
    _v_47 = _v_70;
    _v_48 = _v_71;
    _v_49 = _v_72;
    _v_50 = _v_73;
    _v_51 = _v_74;
    _v_52 = _v_75;
    _v_53 = _v_76;
    _v_54 = _v_77;
    _v_55 = _v_78;
    _v_56 = _v_79;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_247 = 0;
  Term _v_248 = 0;
  Term _v_249 = 0;
  Term _v_250 = 0;
  Term _v_251 = 0;
  Term _v_252 = 0;
  u32 _v_253 = 0;
  Term _v_254 = 0;
  u32 _v_255 = 0;
  u32 _v_256 = 0;
  u32 _v_257 = 0;
  u32 _v_258 = 0;
  Term _v_259 = 0;
  u32 _v_260 = 0;
  Term _v_261 = 0;
  u32 _v_262 = 0;
  Term _v_263 = 0;
  u32 _v_264 = 0;
  u32 _v_265 = 0;
  u32 _id_4 = r0;
  Term _result_14 = r1;
  Term _result_15 = r2;
  Term _result_16 = r3;
  Term _result_17 = r4;
  Term _result_18 = r5;
  Term _result_19 = r6;
  u32 _result_20 = r7;
  Term _result_21 = r8;
  u32 _result_22 = r9;
  u32 _result_23 = r10;
  u32 _result_24 = r11;
  u32 _result_25 = r12;
  Term _result_26 = r13;
  u32 _result_27 = r14;
  Term _result_28 = r15;
  u32 _result_29 = r16;
  Term _result_30 = r17;
  u32 _result_31 = r18;
  u32 _result_32 = r19;
  WL_SPIN
    if (_result_23 == 0) {
      _v_247 = _result_14;
      _v_248 = _result_15;
      _v_249 = _result_16;
      _v_250 = _result_17;
      _v_251 = _result_18;
      _v_252 = _result_19;
      _v_253 = _result_20;
      _v_254 = _result_21;
      _v_255 = _result_22;
      _v_256 = 0;
      _v_257 = 0;
      _v_258 = 0;
      _v_259 = 0;
      _v_260 = 0;
      _v_261 = 0;
      _v_262 = 0;
      _v_263 = 0;
      _v_264 = 0;
      _v_265 = 0;
    } else {
      Term _v_266 = 0;
      Term _v_267 = 0;
      Term _v_268 = 0;
      Term _v_269 = 0;
      Term _v_270 = 0;
      Term _v_271 = 0;
      Term _v_272 = 0;
      Term _v_273 = 0;
      Term _o_10[4];
      Term _a_0 = 0;
      if (spin_8(e, _o_10, _result_16, _result_16 == h3 ? q3 : blk_loc(e.mem, _result_16), _result_17, _result_17 == h4 ? q4 : blk_loc(e.mem, _result_17), _result_18, _result_18 == h5 ? q5 : blk_loc(e.mem, _result_18), _result_19, _result_19 == h6 ? q6 : blk_loc(e.mem, _result_19), U32_BIN(_id_4, -, 1ull), 0, 0, _a_0, _a_0 == h17 ? q17 : _a_0 == h15 ? q15 : _a_0 == h13 ? q13 : _a_0 == h6 ? q6 : _a_0 == h5 ? q5 : _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : blk_loc(e.mem, _a_0), 0ull, 0ull) == 0) {
        return 0;
      }
      _v_270 = _o_10[0];
      _v_271 = _o_10[1];
      _v_272 = _o_10[2];
      _v_273 = _o_10[3];
      _v_266 = _v_270;
      _v_267 = _v_271;
      _v_268 = _v_272;
      _v_269 = _v_273;
      _v_247 = _result_14;
      _v_248 = _result_15;
      _v_249 = _v_266;
      _v_250 = _v_267;
      _v_251 = _v_268;
      _v_252 = _v_269;
      _v_253 = _result_20;
      _v_254 = _result_21;
      _v_255 = _result_22;
      _v_256 = 1;
      _v_257 = _result_24;
      _v_258 = _result_25;
      _v_259 = _result_26;
      _v_260 = _result_27;
      _v_261 = _result_28;
      _v_262 = _result_29;
      _v_263 = _result_30;
      _v_264 = _result_31;
      _v_265 = _result_32;
    }
  break;
  }
  o[0] = _v_247;
  o[1] = _v_248;
  o[2] = _v_249;
  o[3] = _v_250;
  o[4] = _v_251;
  o[5] = _v_252;
  o[6] = _v_253;
  o[7] = _v_254;
  o[8] = _v_255;
  o[9] = _v_256;
  o[10] = _v_257;
  o[11] = _v_258;
  o[12] = _v_259;
  o[13] = _v_260;
  o[14] = _v_261;
  o[15] = _v_262;
  o[16] = _v_263;
  o[17] = _v_264;
  o[18] = _v_265;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h16 = r16;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _flag_0 = r11;
  Term _flag_1 = r12;
  u32 _added_0 = r13;
  u32 _changed_0 = r14;
  u32 _replacement_2 = r15;
  Term _replacement_3 = r16;
  WL_SPIN
    if (_replacement_2 == 0) {
      Term _at_0 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, 0);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, 0);
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _o_0[10];
      if (spin_20(e, _o_0, _id_1, _tick_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_0, _changed_0, 0, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_0, _c_1, _c_1 == h16 ? q16 : _c_1 == h12 ? q12 : _c_1 == h7 ? q7 : _c_1 == h6 ? q6 : _c_1 == h5 ? q5 : _c_1 == h4 ? q4 : _c_1 == h3 ? q3 : _c_1 == h2 ? q2 : blk_loc(e.mem, _c_1)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    } else {
      Term _at_2 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
      Term _at_3 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, 1);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _replacement_3);
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      u32 _v_36 = 0;
      Term _v_37 = 0;
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      Term _o_1[10];
      if (spin_20(e, _o_1, _id_1, _tick_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_1, _depth_1, _high_1, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_0, _changed_0, 1, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_2, _c_3, _c_3 == h16 ? q16 : _c_3 == h12 ? q12 : _c_3 == h7 ? q7 : _c_3 == h6 ? q6 : _c_3 == h5 ? q5 : _c_3 == h4 ? q4 : _c_3 == h3 ? q3 : _c_3 == h2 ? q2 : blk_loc(e.mem, _c_3)) == 0) {
        return 0;
      }
      _v_30 = _o_1[0];
      _v_31 = _o_1[1];
      _v_32 = _o_1[2];
      _v_33 = _o_1[3];
      _v_34 = _o_1[4];
      _v_35 = _o_1[5];
      _v_36 = _o_1[6];
      _v_37 = _o_1[7];
      _v_38 = _o_1[8];
      _v_39 = _o_1[9];
      _v_10 = _v_30;
      _v_11 = _v_31;
      _v_12 = _v_32;
      _v_13 = _v_33;
      _v_14 = _v_34;
      _v_15 = _v_35;
      _v_16 = _v_36;
      _v_17 = _v_37;
      _v_18 = _v_38;
      _v_19 = _v_39;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _valid_0 = r0;
  Term _rows_9 = r1;
  Term _rows_10 = r2;
  Term _rows_11 = r3;
  Term _rows_12 = r4;
  Term _rows_13 = r5;
  Term _rows_14 = r6;
  u32 _rows_15 = r7;
  Term _rows_16 = r8;
  u32 _rows_17 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_21 = 1;
      _v_22 = _rows_9;
      _v_23 = _rows_10;
      _v_24 = _rows_11;
      _v_25 = _rows_12;
      _v_26 = _rows_13;
      _v_27 = _rows_14;
      _v_28 = _rows_15;
      _v_29 = _rows_16;
      _v_30 = _rows_17;
      _v_31 = _row_9;
      _v_32 = _row_10;
      _v_33 = _row_11;
      _v_34 = _row_12;
      _v_35 = _row_13;
      _v_36 = _row_14;
      _v_37 = _row_15;
      _v_38 = _row_16;
      _v_39 = _row_17;
    } else {
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      u32 _v_49 = 0;
      Term _o_1[5];
      if (spin_22(e, _o_1, _rows_11, _rows_11 == h3 ? q3 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h4 ? q4 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h5 ? q5 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h6 ? q6 : blk_loc(e.mem, _rows_14), U32_BIN(_row_9, -, 1ull)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_46 = _o_1[1];
      _v_47 = _o_1[2];
      _v_48 = _o_1[3];
      _v_49 = _o_1[4];
      _v_40 = _v_45;
      _v_41 = _v_46;
      _v_42 = _v_47;
      _v_43 = _v_48;
      _v_44 = _v_49;
      u32 _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      Term _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      u32 _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      Term _o_2[19];
      if (spin_23(e, _o_2, _rows_9, _rows_9 == h1 ? q1 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h2 ? q2 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _row_9, _row_10, _row_11, _row_11 == h12 ? q12 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h14 ? q14 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17, _v_40, _v_40 == h16 ? q16 : _v_40 == h14 ? q14 : _v_40 == h12 ? q12 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h16 ? q16 : _v_41 == h14 ? q14 : _v_41 == h12 ? q12 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h16 ? q16 : _v_42 == h14 ? q14 : _v_42 == h12 ? q12 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h16 ? q16 : _v_43 == h14 ? q14 : _v_43 == h12 ? q12 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : blk_loc(e.mem, _v_43), _v_44) == 0) {
        return 0;
      }
      _v_50 = _o_2[0];
      _v_51 = _o_2[1];
      _v_52 = _o_2[2];
      _v_53 = _o_2[3];
      _v_54 = _o_2[4];
      _v_55 = _o_2[5];
      _v_56 = _o_2[6];
      _v_57 = _o_2[7];
      _v_58 = _o_2[8];
      _v_59 = _o_2[9];
      _v_60 = _o_2[10];
      _v_61 = _o_2[11];
      _v_62 = _o_2[12];
      _v_63 = _o_2[13];
      _v_64 = _o_2[14];
      _v_65 = _o_2[15];
      _v_66 = _o_2[16];
      _v_67 = _o_2[17];
      _v_68 = _o_2[18];
      _v_21 = _v_50;
      _v_22 = _v_51;
      _v_23 = _v_52;
      _v_24 = _v_53;
      _v_25 = _v_54;
      _v_26 = _v_55;
      _v_27 = _v_56;
      _v_28 = _v_57;
      _v_29 = _v_58;
      _v_30 = _v_59;
      _v_31 = _v_60;
      _v_32 = _v_61;
      _v_33 = _v_62;
      _v_34 = _v_63;
      _v_35 = _v_64;
      _v_36 = _v_65;
      _v_37 = _v_66;
      _v_38 = _v_67;
      _v_39 = _v_68;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  WL_SPIN
    _v_8 = 4;
    _v_9 = _id_0;
    _v_10 = 0;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_0 = r9;
  u32 _row_1 = r10;
  Term _row_2 = r11;
  u32 _row_3 = r12;
  Term _row_4 = r13;
  u32 _row_5 = r14;
  Term _row_6 = r15;
  u32 _row_7 = r16;
  u32 _row_8 = r17;
  WL_SPIN
    Term _at_0 = _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9);
    Term _at_1 = blk_at(_rows_9, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_2);
    term_sink(e, _c_1);
    Term _at_2 = _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10);
    Term _at_3 = blk_at(_rows_10, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_3);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_4);
    term_sink(e, _c_3);
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _o_0[4];
    if (spin_8(e, _o_0, _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), U32_BIN(_row_0, -, 1ull), 1, _row_5, _row_6, _row_6 == h15 ? q15 : blk_loc(e.mem, _row_6), _row_7, _row_8) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_32 = _o_0[1];
    _v_33 = _o_0[2];
    _v_34 = _o_0[3];
    _v_27 = _v_31;
    _v_28 = _v_32;
    _v_29 = _v_33;
    _v_30 = _v_34;
    _v_18 = _rows_9;
    _v_19 = _rows_10;
    _v_20 = _v_27;
    _v_21 = _v_28;
    _v_22 = _v_29;
    _v_23 = _v_30;
    _v_24 = _rows_15;
    _v_25 = _rows_16;
    _v_26 = _rows_17;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_73 = 0;
  Term _v_74 = 0;
  Term _v_75 = 0;
  Term _v_76 = 0;
  Term _v_77 = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _rows_18 = r0;
  Term _rows_19 = r1;
  Term _rows_20 = r2;
  Term _rows_21 = r3;
  Term _rows_22 = r4;
  Term _rows_23 = r5;
  u32 _rows_24 = r6;
  Term _rows_25 = r7;
  u32 _rows_26 = r8;
  u32 _id_1 = r9;
  WL_SPIN
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    Term _v_104 = 0;
    u32 _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    Term _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    Term _v_116 = 0;
    u32 _v_117 = 0;
    Term _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    Term _v_123 = 0;
    u32 _v_124 = 0;
    Term _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    Term _o_2[19];
    if (spin_30(e, _o_2, _rows_18, _rows_18 == h0 ? q0 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h1 ? q1 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h2 ? q2 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h3 ? q3 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h4 ? q4 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h5 ? q5 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26, _id_1) == 0) {
      return 0;
    }
    _v_111 = _o_2[0];
    _v_112 = _o_2[1];
    _v_113 = _o_2[2];
    _v_114 = _o_2[3];
    _v_115 = _o_2[4];
    _v_116 = _o_2[5];
    _v_117 = _o_2[6];
    _v_118 = _o_2[7];
    _v_119 = _o_2[8];
    _v_120 = _o_2[9];
    _v_121 = _o_2[10];
    _v_122 = _o_2[11];
    _v_123 = _o_2[12];
    _v_124 = _o_2[13];
    _v_125 = _o_2[14];
    _v_126 = _o_2[15];
    _v_127 = _o_2[16];
    _v_128 = _o_2[17];
    _v_129 = _o_2[18];
    _v_92 = _v_111;
    _v_93 = _v_112;
    _v_94 = _v_113;
    _v_95 = _v_114;
    _v_96 = _v_115;
    _v_97 = _v_116;
    _v_98 = _v_117;
    _v_99 = _v_118;
    _v_100 = _v_119;
    _v_101 = _v_120;
    _v_102 = _v_121;
    _v_103 = _v_122;
    _v_104 = _v_123;
    _v_105 = _v_124;
    _v_106 = _v_125;
    _v_107 = _v_126;
    _v_108 = _v_127;
    _v_109 = _v_128;
    _v_110 = _v_129;
    Term _v_130 = 0;
    Term _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    Term _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    Term _v_142 = 0;
    u32 _v_143 = 0;
    Term _v_144 = 0;
    u32 _v_145 = 0;
    Term _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    Term _o_3[19];
    if (spin_36(e, _o_3, _id_1, _v_92, _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : _v_92 == h2 ? q2 : _v_92 == h1 ? q1 : _v_92 == h0 ? q0 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h5 ? q5 : _v_93 == h4 ? q4 : _v_93 == h3 ? q3 : _v_93 == h2 ? q2 : _v_93 == h1 ? q1 : _v_93 == h0 ? q0 : blk_loc(e.mem, _v_93), _v_94, _v_94 == h5 ? q5 : _v_94 == h4 ? q4 : _v_94 == h3 ? q3 : _v_94 == h2 ? q2 : _v_94 == h1 ? q1 : _v_94 == h0 ? q0 : blk_loc(e.mem, _v_94), _v_95, _v_95 == h5 ? q5 : _v_95 == h4 ? q4 : _v_95 == h3 ? q3 : _v_95 == h2 ? q2 : _v_95 == h1 ? q1 : _v_95 == h0 ? q0 : blk_loc(e.mem, _v_95), _v_96, _v_96 == h5 ? q5 : _v_96 == h4 ? q4 : _v_96 == h3 ? q3 : _v_96 == h2 ? q2 : _v_96 == h1 ? q1 : _v_96 == h0 ? q0 : blk_loc(e.mem, _v_96), _v_97, _v_97 == h5 ? q5 : _v_97 == h4 ? q4 : _v_97 == h3 ? q3 : _v_97 == h2 ? q2 : _v_97 == h1 ? q1 : _v_97 == h0 ? q0 : blk_loc(e.mem, _v_97), _v_98, _v_99, _v_100, _v_101, _v_102, _v_103, _v_104, _v_104 == h5 ? q5 : _v_104 == h4 ? q4 : _v_104 == h3 ? q3 : _v_104 == h2 ? q2 : _v_104 == h1 ? q1 : _v_104 == h0 ? q0 : blk_loc(e.mem, _v_104), _v_105, _v_106, _v_106 == h5 ? q5 : _v_106 == h4 ? q4 : _v_106 == h3 ? q3 : _v_106 == h2 ? q2 : _v_106 == h1 ? q1 : _v_106 == h0 ? q0 : blk_loc(e.mem, _v_106), _v_107, _v_108, _v_108 == h5 ? q5 : _v_108 == h4 ? q4 : _v_108 == h3 ? q3 : _v_108 == h2 ? q2 : _v_108 == h1 ? q1 : _v_108 == h0 ? q0 : blk_loc(e.mem, _v_108), _v_109, _v_110) == 0) {
      return 0;
    }
    _v_130 = _o_3[0];
    _v_131 = _o_3[1];
    _v_132 = _o_3[2];
    _v_133 = _o_3[3];
    _v_134 = _o_3[4];
    _v_135 = _o_3[5];
    _v_136 = _o_3[6];
    _v_137 = _o_3[7];
    _v_138 = _o_3[8];
    _v_139 = _o_3[9];
    _v_140 = _o_3[10];
    _v_141 = _o_3[11];
    _v_142 = _o_3[12];
    _v_143 = _o_3[13];
    _v_144 = _o_3[14];
    _v_145 = _o_3[15];
    _v_146 = _o_3[16];
    _v_147 = _o_3[17];
    _v_148 = _o_3[18];
    _v_73 = _v_130;
    _v_74 = _v_131;
    _v_75 = _v_132;
    _v_76 = _v_133;
    _v_77 = _v_134;
    _v_78 = _v_135;
    _v_79 = _v_136;
    _v_80 = _v_137;
    _v_81 = _v_138;
    _v_82 = _v_139;
    _v_83 = _v_140;
    _v_84 = _v_141;
    _v_85 = _v_142;
    _v_86 = _v_143;
    _v_87 = _v_144;
    _v_88 = _v_145;
    _v_89 = _v_146;
    _v_90 = _v_147;
    _v_91 = _v_148;
  break;
  }
  o[0] = _v_73;
  o[1] = _v_74;
  o[2] = _v_75;
  o[3] = _v_76;
  o[4] = _v_77;
  o[5] = _v_78;
  o[6] = _v_79;
  o[7] = _v_80;
  o[8] = _v_81;
  o[9] = _v_82;
  o[10] = _v_83;
  o[11] = _v_84;
  o[12] = _v_85;
  o[13] = _v_86;
  o[14] = _v_87;
  o[15] = _v_88;
  o[16] = _v_89;
  o[17] = _v_90;
  o[18] = _v_91;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_168 = 0;
  Term _v_169 = 0;
  Term _v_170 = 0;
  Term _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  Term _v_176 = 0;
  u32 _v_177 = 0;
  Term _v_178 = 0;
  u32 _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  Term _v_184 = 0;
  u32 _v_185 = 0;
  u32 _v_186 = 0;
  Term _changes_0 = r0;
  Term _result_11 = r1;
  Term _result_12 = r2;
  Term _result_13 = r3;
  Term _result_14 = r4;
  Term _result_15 = r5;
  Term _result_16 = r6;
  u32 _result_17 = r7;
  Term _result_18 = r8;
  u32 _result_19 = r9;
  u32 _result_20 = r10;
  u32 _result_21 = r11;
  u32 _result_22 = r12;
  Term _result_23 = r13;
  u32 _result_24 = r14;
  Term _result_25 = r15;
  u32 _result_26 = r16;
  Term _result_27 = r17;
  u32 _result_28 = r18;
  u32 _result_29 = r19;
  WL_SPIN
    term_sink(e, _result_23);
    term_sink(e, _result_25);
    term_sink(e, _result_27);
    _v_168 = 0;
    _v_169 = _result_11;
    _v_170 = _result_12;
    _v_171 = _result_13;
    _v_172 = _result_14;
    _v_173 = _result_15;
    _v_174 = _result_16;
    _v_175 = _result_17;
    _v_176 = _result_18;
    _v_177 = _result_19;
    _v_178 = _changes_0;
    _v_179 = 0;
    _v_180 = 0;
    _v_181 = 0;
    _v_182 = 0;
    _v_183 = 0;
    _v_184 = 0;
    _v_185 = 0;
    _v_186 = 0;
  break;
  }
  o[0] = _v_168;
  o[1] = _v_169;
  o[2] = _v_170;
  o[3] = _v_171;
  o[4] = _v_172;
  o[5] = _v_173;
  o[6] = _v_174;
  o[7] = _v_175;
  o[8] = _v_176;
  o[9] = _v_177;
  o[10] = _v_178;
  o[11] = _v_179;
  o[12] = _v_180;
  o[13] = _v_181;
  o[14] = _v_182;
  o[15] = _v_183;
  o[16] = _v_184;
  o[17] = _v_185;
  o[18] = _v_186;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _metadata_0 = r4;
  Term _metadata_1 = r5;
  Term _metadata_2 = r6;
  Term _metadata_3 = r7;
  u32 _capacity_1 = r8;
  Term _depth_1 = r9;
  u32 _high_1 = r10;
  u32 _replacement_2 = r11;
  Term _replacement_3 = r12;
  u32 _meta_0 = r13;
  u32 _meta_1 = r14;
  Term _meta_2 = r15;
  u32 _meta_3 = r16;
  u32 _meta_4 = r17;
  WL_SPIN
    if (_meta_0 == 0) {
      term_sink(e, _replacement_3);
      term_sink(e, _meta_2);
      _v_10 = _main_1;
      _v_11 = _aux_1;
      _v_12 = _metadata_0;
      _v_13 = _metadata_1;
      _v_14 = _metadata_2;
      _v_15 = _metadata_3;
      _v_16 = _capacity_1;
      _v_17 = _depth_1;
      _v_18 = _high_1;
      _v_19 = 0;
    } else {
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _o_0[10];
      if (spin_37(e, _o_0, _id_1, _tick_1, _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h4 ? q4 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h5 ? q5 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h6 ? q6 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h7 ? q7 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_1, _meta_2, _meta_2 == h15 ? q15 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _replacement_2, _replacement_3, _replacement_3 == h12 ? q12 : blk_loc(e.mem, _replacement_3)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_18 = r9;
  u32 _row_19 = r10;
  Term _row_20 = r11;
  u32 _row_21 = r12;
  Term _row_22 = r13;
  u32 _row_23 = r14;
  Term _row_24 = r15;
  u32 _row_25 = r16;
  u32 _row_26 = r17;
  WL_SPIN
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, U32_BIN(0ull, <, _row_18), U32_BIN(_row_18, <=, _rows_15)) == 0) {
      return 0;
    }
    _v_39 = _o_0[0];
    _v_38 = _v_39;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    Term _o_1[19];
    if (spin_38(e, _o_1, _v_38, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _row_18, _row_19, _row_20, _row_20 == h11 ? q11 : blk_loc(e.mem, _row_20), _row_21, _row_22, _row_22 == h13 ? q13 : blk_loc(e.mem, _row_22), _row_23, _row_24, _row_24 == h15 ? q15 : blk_loc(e.mem, _row_24), _row_25, _row_26) == 0) {
      return 0;
    }
    _v_40 = _o_1[0];
    _v_41 = _o_1[1];
    _v_42 = _o_1[2];
    _v_43 = _o_1[3];
    _v_44 = _o_1[4];
    _v_45 = _o_1[5];
    _v_46 = _o_1[6];
    _v_47 = _o_1[7];
    _v_48 = _o_1[8];
    _v_49 = _o_1[9];
    _v_50 = _o_1[10];
    _v_51 = _o_1[11];
    _v_52 = _o_1[12];
    _v_53 = _o_1[13];
    _v_54 = _o_1[14];
    _v_55 = _o_1[15];
    _v_56 = _o_1[16];
    _v_57 = _o_1[17];
    _v_58 = _o_1[18];
    _v_19 = _v_40;
    _v_20 = _v_41;
    _v_21 = _v_42;
    _v_22 = _v_43;
    _v_23 = _v_44;
    _v_24 = _v_45;
    _v_25 = _v_46;
    _v_26 = _v_47;
    _v_27 = _v_48;
    _v_28 = _v_49;
    _v_29 = _v_50;
    _v_30 = _v_51;
    _v_31 = _v_52;
    _v_32 = _v_53;
    _v_33 = _v_54;
    _v_34 = _v_55;
    _v_35 = _v_56;
    _v_36 = _v_57;
    _v_37 = _v_58;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _id_0 = r0;
  WL_SPIN
    _v_8 = 5;
    _v_9 = _id_0;
    _v_10 = 0;
    _v_11 = 0;
    _v_12 = 0;
    _v_13 = 0;
    _v_14 = 0;
    _v_15 = 0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  u32 _c_1 = r2;
  Term _result_2 = r3;
  u32 _result_3 = r4;
  WL_SPIN
    _v_5 = _result_2;
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = _c_1;
    _v_9 = _result_3;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term h9 = r9;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  u32 _namespace_1 = r0;
  u32 _tick_1 = r1;
  u32 _command_8 = r2;
  u32 _command_9 = r3;
  Term _command_10 = r4;
  Term _command_11 = r5;
  u32 _command_12 = r6;
  Term _command_13 = r7;
  u32 _command_14 = r8;
  Term _command_15 = r9;
  u32 _row_0 = r10;
  u32 _row_1 = r11;
  Term _row_2 = r12;
  u32 _row_3 = r13;
  Term _row_4 = r14;
  u32 _row_5 = r15;
  Term _row_6 = r16;
  u32 _row_7 = r17;
  u32 _row_8 = r18;
  WL_SPIN
    if (_command_8 == 2) {
      term_sink(e, _row_6);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = 1;
      _v_29 = _command_10;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 4) {
      term_sink(e, _row_6);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = 0;
      _v_29 = 0;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 1) {
      term_sink(e, _command_10);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 3) {
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    } else if (_command_8 == 5) {
      if (_row_1 == 1) {
        term_sink(e, _row_2);
        term_sink(e, _row_4);
        term_sink(e, _row_6);
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_0 + 1] = rfc_seal(e, _row_0);
        u64 _nd_1 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _row_0);
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_DESPAWNED, _nd_1));
        e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINREMOVED, _nd_0));
        e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
        _v_22 = 0;
        _v_23 = 0;
        _v_24 = 0;
        _v_25 = 0;
        _v_26 = 0;
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0;
        _v_30 = 0;
        _v_31 = 0;
        _v_32 = term_ctr(CID_CON, _nd_3);
      } else {
        term_sink(e, _row_4);
        term_sink(e, _row_6);
        u64 _nd_4 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_4 + 0] = rfc_seal(e, _namespace_1);
        e.mem[_nd_4 + 1] = rfc_seal(e, _row_0);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_DESPAWNED, _nd_4));
        e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        _v_22 = 0;
        _v_23 = 0;
        _v_24 = 0;
        _v_25 = 0;
        _v_26 = 0;
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0;
        _v_30 = 0;
        _v_31 = 0;
        _v_32 = term_ctr(CID_CON, _nd_5);
      }
    } else {
      term_sink(e, _command_11);
      term_sink(e, _command_13);
      term_sink(e, _command_15);
      _v_22 = 1;
      _v_23 = _row_0;
      _v_24 = _row_1;
      _v_25 = _row_2;
      _v_26 = _row_3;
      _v_27 = _row_4;
      _v_28 = _row_5;
      _v_29 = _row_6;
      _v_30 = _row_7;
      _v_31 = _row_8;
      _v_32 = term_pak(CID_NIL, 0);
    }
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term h20 = r20;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  u32 _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _id_1 = r9;
  u32 _result_19 = r10;
  u32 _result_20 = r11;
  u32 _result_21 = r12;
  Term _result_22 = r13;
  u32 _result_23 = r14;
  Term _result_24 = r15;
  u32 _result_25 = r16;
  Term _result_26 = r17;
  u32 _result_27 = r18;
  u32 _result_28 = r19;
  Term _result_29 = r20;
  WL_SPIN
    if (_result_19 == 1) {
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      u32 _v_77 = 0;
      Term _v_78 = 0;
      u32 _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      u32 _v_88 = 0;
      Term _o_1[9];
      if (spin_40(e, _o_1, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _result_20, _result_21, _result_22, _result_22 == h13 ? q13 : blk_loc(e.mem, _result_22), _result_23, _result_24, _result_24 == h15 ? q15 : blk_loc(e.mem, _result_24), _result_25, _result_26, _result_26 == h17 ? q17 : blk_loc(e.mem, _result_26), _result_27, _result_28) == 0) {
        return 0;
      }
      _v_80 = _o_1[0];
      _v_81 = _o_1[1];
      _v_82 = _o_1[2];
      _v_83 = _o_1[3];
      _v_84 = _o_1[4];
      _v_85 = _o_1[5];
      _v_86 = _o_1[6];
      _v_87 = _o_1[7];
      _v_88 = _o_1[8];
      _v_71 = _v_80;
      _v_72 = _v_81;
      _v_73 = _v_82;
      _v_74 = _v_83;
      _v_75 = _v_84;
      _v_76 = _v_85;
      _v_77 = _v_86;
      _v_78 = _v_87;
      _v_79 = _v_88;
      _v_52 = 0;
      _v_53 = _v_71;
      _v_54 = _v_72;
      _v_55 = _v_73;
      _v_56 = _v_74;
      _v_57 = _v_75;
      _v_58 = _v_76;
      _v_59 = _v_77;
      _v_60 = _v_78;
      _v_61 = _v_79;
      _v_62 = _result_29;
      _v_63 = 0;
      _v_64 = 0;
      _v_65 = 0;
      _v_66 = 0;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
    } else {
      Term _v_89 = 0;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      u32 _v_102 = 0;
      Term _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      Term _v_112 = 0;
      Term _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      u32 _v_118 = 0;
      u32 _v_119 = 0;
      Term _v_120 = 0;
      u32 _v_121 = 0;
      Term _v_122 = 0;
      u32 _v_123 = 0;
      Term _v_124 = 0;
      u32 _v_125 = 0;
      u32 _v_126 = 0;
      Term _o_2[19];
      if (spin_41(e, _o_2, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _id_1) == 0) {
        return 0;
      }
      _v_108 = _o_2[0];
      _v_109 = _o_2[1];
      _v_110 = _o_2[2];
      _v_111 = _o_2[3];
      _v_112 = _o_2[4];
      _v_113 = _o_2[5];
      _v_114 = _o_2[6];
      _v_115 = _o_2[7];
      _v_116 = _o_2[8];
      _v_117 = _o_2[9];
      _v_118 = _o_2[10];
      _v_119 = _o_2[11];
      _v_120 = _o_2[12];
      _v_121 = _o_2[13];
      _v_122 = _o_2[14];
      _v_123 = _o_2[15];
      _v_124 = _o_2[16];
      _v_125 = _o_2[17];
      _v_126 = _o_2[18];
      _v_89 = _v_108;
      _v_90 = _v_109;
      _v_91 = _v_110;
      _v_92 = _v_111;
      _v_93 = _v_112;
      _v_94 = _v_113;
      _v_95 = _v_114;
      _v_96 = _v_115;
      _v_97 = _v_116;
      _v_98 = _v_117;
      _v_99 = _v_118;
      _v_100 = _v_119;
      _v_101 = _v_120;
      _v_102 = _v_121;
      _v_103 = _v_122;
      _v_104 = _v_123;
      _v_105 = _v_124;
      _v_106 = _v_125;
      _v_107 = _v_126;
      u32 _v_127 = 0;
      Term _v_128 = 0;
      Term _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      u32 _v_134 = 0;
      Term _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      Term _v_139 = 0;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      u32 _v_142 = 0;
      Term _v_143 = 0;
      u32 _v_144 = 0;
      u32 _v_145 = 0;
      Term _o_3[19];
      if (spin_42(e, _o_3, _result_29, _result_29 == h20 ? q20 : blk_loc(e.mem, _result_29), _v_89, _v_89 == h20 ? q20 : _v_89 == h17 ? q17 : _v_89 == h15 ? q15 : _v_89 == h13 ? q13 : _v_89 == h5 ? q5 : _v_89 == h4 ? q4 : _v_89 == h3 ? q3 : _v_89 == h2 ? q2 : _v_89 == h1 ? q1 : _v_89 == h0 ? q0 : blk_loc(e.mem, _v_89), _v_90, _v_90 == h20 ? q20 : _v_90 == h17 ? q17 : _v_90 == h15 ? q15 : _v_90 == h13 ? q13 : _v_90 == h5 ? q5 : _v_90 == h4 ? q4 : _v_90 == h3 ? q3 : _v_90 == h2 ? q2 : _v_90 == h1 ? q1 : _v_90 == h0 ? q0 : blk_loc(e.mem, _v_90), _v_91, _v_91 == h20 ? q20 : _v_91 == h17 ? q17 : _v_91 == h15 ? q15 : _v_91 == h13 ? q13 : _v_91 == h5 ? q5 : _v_91 == h4 ? q4 : _v_91 == h3 ? q3 : _v_91 == h2 ? q2 : _v_91 == h1 ? q1 : _v_91 == h0 ? q0 : blk_loc(e.mem, _v_91), _v_92, _v_92 == h20 ? q20 : _v_92 == h17 ? q17 : _v_92 == h15 ? q15 : _v_92 == h13 ? q13 : _v_92 == h5 ? q5 : _v_92 == h4 ? q4 : _v_92 == h3 ? q3 : _v_92 == h2 ? q2 : _v_92 == h1 ? q1 : _v_92 == h0 ? q0 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h20 ? q20 : _v_93 == h17 ? q17 : _v_93 == h15 ? q15 : _v_93 == h13 ? q13 : _v_93 == h5 ? q5 : _v_93 == h4 ? q4 : _v_93 == h3 ? q3 : _v_93 == h2 ? q2 : _v_93 == h1 ? q1 : _v_93 == h0 ? q0 : blk_loc(e.mem, _v_93), _v_94, _v_94 == h20 ? q20 : _v_94 == h17 ? q17 : _v_94 == h15 ? q15 : _v_94 == h13 ? q13 : _v_94 == h5 ? q5 : _v_94 == h4 ? q4 : _v_94 == h3 ? q3 : _v_94 == h2 ? q2 : _v_94 == h1 ? q1 : _v_94 == h0 ? q0 : blk_loc(e.mem, _v_94), _v_95, _v_96, _v_97, _v_98, _v_99, _v_100, _v_101, _v_101 == h20 ? q20 : _v_101 == h17 ? q17 : _v_101 == h15 ? q15 : _v_101 == h13 ? q13 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : _v_101 == h1 ? q1 : _v_101 == h0 ? q0 : blk_loc(e.mem, _v_101), _v_102, _v_103, _v_103 == h20 ? q20 : _v_103 == h17 ? q17 : _v_103 == h15 ? q15 : _v_103 == h13 ? q13 : _v_103 == h5 ? q5 : _v_103 == h4 ? q4 : _v_103 == h3 ? q3 : _v_103 == h2 ? q2 : _v_103 == h1 ? q1 : _v_103 == h0 ? q0 : blk_loc(e.mem, _v_103), _v_104, _v_105, _v_105 == h20 ? q20 : _v_105 == h17 ? q17 : _v_105 == h15 ? q15 : _v_105 == h13 ? q13 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : _v_105 == h1 ? q1 : _v_105 == h0 ? q0 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_127 = _o_3[0];
      _v_128 = _o_3[1];
      _v_129 = _o_3[2];
      _v_130 = _o_3[3];
      _v_131 = _o_3[4];
      _v_132 = _o_3[5];
      _v_133 = _o_3[6];
      _v_134 = _o_3[7];
      _v_135 = _o_3[8];
      _v_136 = _o_3[9];
      _v_137 = _o_3[10];
      _v_138 = _o_3[11];
      _v_139 = _o_3[12];
      _v_140 = _o_3[13];
      _v_141 = _o_3[14];
      _v_142 = _o_3[15];
      _v_143 = _o_3[16];
      _v_144 = _o_3[17];
      _v_145 = _o_3[18];
      _v_52 = _v_127;
      _v_53 = _v_128;
      _v_54 = _v_129;
      _v_55 = _v_130;
      _v_56 = _v_131;
      _v_57 = _v_132;
      _v_58 = _v_133;
      _v_59 = _v_134;
      _v_60 = _v_135;
      _v_61 = _v_136;
      _v_62 = _v_137;
      _v_63 = _v_138;
      _v_64 = _v_139;
      _v_65 = _v_140;
      _v_66 = _v_141;
      _v_67 = _v_142;
      _v_68 = _v_143;
      _v_69 = _v_144;
      _v_70 = _v_145;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  o[18] = _v_70;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _id_1 = r0;
  u32 _tick_1 = r1;
  Term _main_0 = r2;
  Term _aux_0 = r3;
  u32 _capacity_0 = r4;
  Term _depth_0 = r5;
  u32 _high_0 = r6;
  u32 _replacement_2 = r7;
  Term _replacement_3 = r8;
  Term _result_0 = r9;
  Term _result_1 = r10;
  Term _result_2 = r11;
  Term _result_3 = r12;
  u32 _result_4 = r13;
  u32 _result_5 = r14;
  Term _result_6 = r15;
  u32 _result_7 = r16;
  u32 _result_8 = r17;
  WL_SPIN
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_1[10];
    if (spin_43(e, _o_1, _id_1, _tick_1, _main_0, _main_0 == h2 ? q2 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h3 ? q3 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h9 ? q9 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h10 ? q10 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h11 ? q11 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h12 ? q12 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _replacement_2, _replacement_3, _replacement_3 == h8 ? q8 : blk_loc(e.mem, _replacement_3), _result_4, _result_5, _result_6, _result_6 == h15 ? q15 : blk_loc(e.mem, _result_6), _result_7, _result_8) == 0) {
      return 0;
    }
    _v_38 = _o_1[0];
    _v_39 = _o_1[1];
    _v_40 = _o_1[2];
    _v_41 = _o_1[3];
    _v_42 = _o_1[4];
    _v_43 = _o_1[5];
    _v_44 = _o_1[6];
    _v_45 = _o_1[7];
    _v_46 = _o_1[8];
    _v_47 = _o_1[9];
    _v_28 = _v_38;
    _v_29 = _v_39;
    _v_30 = _v_40;
    _v_31 = _v_41;
    _v_32 = _v_42;
    _v_33 = _v_43;
    _v_34 = _v_44;
    _v_35 = _v_45;
    _v_36 = _v_46;
    _v_37 = _v_47;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_1 = r0;
  u32 _b_0 = r1;
  Term _result_2 = r2;
  u32 _result_3 = r3;
  WL_SPIN
    Term _at_2 = _result_2 == h2 ? q2 : blk_loc(e.mem, _result_2);
    Term _at_3 = blk_at(_result_2, 3ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_46(e, _o_0, _a_1, _b_0, _result_3, _result_2, _result_2 == h2 ? q2 : blk_loc(e.mem, _result_2), _c_1) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, Term r18, u32 r19, u32 r20, u32 r21, u32 r22, Term r23, u64 q23, u32 r24, Term r25, u64 q25, u32 r26, Term r27, u64 q27, u32 r28, u32 r29) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h23 = r23;
  Term h25 = r25;
  Term h27 = r27;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _namespace_1 = r0;
  u32 _tick_1 = r1;
  u32 _id_0 = r2;
  u32 _command_0 = r3;
  u32 _command_1 = r4;
  Term _command_2 = r5;
  Term _command_3 = r6;
  u32 _command_4 = r7;
  Term _command_5 = r8;
  u32 _command_6 = r9;
  Term _command_7 = r10;
  Term _result_9 = r11;
  Term _result_10 = r12;
  Term _result_11 = r13;
  Term _result_12 = r14;
  Term _result_13 = r15;
  Term _result_14 = r16;
  u32 _result_15 = r17;
  Term _result_16 = r18;
  u32 _result_17 = r19;
  u32 _result_18 = r20;
  u32 _result_19 = r21;
  u32 _result_20 = r22;
  Term _result_21 = r23;
  u32 _result_22 = r24;
  Term _result_23 = r25;
  u32 _result_24 = r26;
  Term _result_25 = r27;
  u32 _result_26 = r28;
  u32 _result_27 = r29;
  WL_SPIN
    if (_result_18 == 0) {
      term_sink(e, _command_2);
      term_sink(e, _command_3);
      term_sink(e, _command_5);
      term_sink(e, _command_7);
      _v_57 = 0;
      _v_58 = _result_9;
      _v_59 = _result_10;
      _v_60 = _result_11;
      _v_61 = _result_12;
      _v_62 = _result_13;
      _v_63 = _result_14;
      _v_64 = _result_15;
      _v_65 = _result_16;
      _v_66 = _result_17;
      _v_67 = term_pak(CID_NIL, 0);
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
      _v_71 = 0;
      _v_72 = 0;
      _v_73 = 0;
      _v_74 = 0;
      _v_75 = 0;
    } else {
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      u32 _v_85 = 0;
      Term _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      u32 _v_96 = 0;
      Term _v_97 = 0;
      Term _o_1[11];
      if (spin_47(e, _o_1, _namespace_1, _tick_1, _command_0, _command_1, _command_2, _command_2 == h5 ? q5 : blk_loc(e.mem, _command_2), _command_3, _command_3 == h6 ? q6 : blk_loc(e.mem, _command_3), _command_4, _command_5, _command_5 == h8 ? q8 : blk_loc(e.mem, _command_5), _command_6, _command_7, _command_7 == h10 ? q10 : blk_loc(e.mem, _command_7), _result_19, _result_20, _result_21, _result_21 == h23 ? q23 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h25 ? q25 : blk_loc(e.mem, _result_23), _result_24, _result_25, _result_25 == h27 ? q27 : blk_loc(e.mem, _result_25), _result_26, _result_27) == 0) {
        return 0;
      }
      _v_87 = _o_1[0];
      _v_88 = _o_1[1];
      _v_89 = _o_1[2];
      _v_90 = _o_1[3];
      _v_91 = _o_1[4];
      _v_92 = _o_1[5];
      _v_93 = _o_1[6];
      _v_94 = _o_1[7];
      _v_95 = _o_1[8];
      _v_96 = _o_1[9];
      _v_97 = _o_1[10];
      _v_76 = _v_87;
      _v_77 = _v_88;
      _v_78 = _v_89;
      _v_79 = _v_90;
      _v_80 = _v_91;
      _v_81 = _v_92;
      _v_82 = _v_93;
      _v_83 = _v_94;
      _v_84 = _v_95;
      _v_85 = _v_96;
      _v_86 = _v_97;
      u32 _v_98 = 0;
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      Term _v_103 = 0;
      Term _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      u32 _v_109 = 0;
      Term _v_110 = 0;
      u32 _v_111 = 0;
      Term _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_2[19];
      if (spin_48(e, _o_2, _result_9, _result_9 == h11 ? q11 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h12 ? q12 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h13 ? q13 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h14 ? q14 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h15 ? q15 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h16 ? q16 : blk_loc(e.mem, _result_14), _result_15, _result_16, _result_17, _id_0, _v_76, _v_77, _v_78, _v_79, _v_79 == h27 ? q27 : _v_79 == h25 ? q25 : _v_79 == h23 ? q23 : _v_79 == h16 ? q16 : _v_79 == h15 ? q15 : _v_79 == h14 ? q14 : _v_79 == h13 ? q13 : _v_79 == h12 ? q12 : _v_79 == h11 ? q11 : _v_79 == h10 ? q10 : _v_79 == h8 ? q8 : _v_79 == h6 ? q6 : _v_79 == h5 ? q5 : blk_loc(e.mem, _v_79), _v_80, _v_81, _v_81 == h27 ? q27 : _v_81 == h25 ? q25 : _v_81 == h23 ? q23 : _v_81 == h16 ? q16 : _v_81 == h15 ? q15 : _v_81 == h14 ? q14 : _v_81 == h13 ? q13 : _v_81 == h12 ? q12 : _v_81 == h11 ? q11 : _v_81 == h10 ? q10 : _v_81 == h8 ? q8 : _v_81 == h6 ? q6 : _v_81 == h5 ? q5 : blk_loc(e.mem, _v_81), _v_82, _v_83, _v_83 == h27 ? q27 : _v_83 == h25 ? q25 : _v_83 == h23 ? q23 : _v_83 == h16 ? q16 : _v_83 == h15 ? q15 : _v_83 == h14 ? q14 : _v_83 == h13 ? q13 : _v_83 == h12 ? q12 : _v_83 == h11 ? q11 : _v_83 == h10 ? q10 : _v_83 == h8 ? q8 : _v_83 == h6 ? q6 : _v_83 == h5 ? q5 : blk_loc(e.mem, _v_83), _v_84, _v_85, _v_86, _v_86 == h27 ? q27 : _v_86 == h25 ? q25 : _v_86 == h23 ? q23 : _v_86 == h16 ? q16 : _v_86 == h15 ? q15 : _v_86 == h14 ? q14 : _v_86 == h13 ? q13 : _v_86 == h12 ? q12 : _v_86 == h11 ? q11 : _v_86 == h10 ? q10 : _v_86 == h8 ? q8 : _v_86 == h6 ? q6 : _v_86 == h5 ? q5 : blk_loc(e.mem, _v_86)) == 0) {
        return 0;
      }
      _v_98 = _o_2[0];
      _v_99 = _o_2[1];
      _v_100 = _o_2[2];
      _v_101 = _o_2[3];
      _v_102 = _o_2[4];
      _v_103 = _o_2[5];
      _v_104 = _o_2[6];
      _v_105 = _o_2[7];
      _v_106 = _o_2[8];
      _v_107 = _o_2[9];
      _v_108 = _o_2[10];
      _v_109 = _o_2[11];
      _v_110 = _o_2[12];
      _v_111 = _o_2[13];
      _v_112 = _o_2[14];
      _v_113 = _o_2[15];
      _v_114 = _o_2[16];
      _v_115 = _o_2[17];
      _v_116 = _o_2[18];
      _v_57 = _v_98;
      _v_58 = _v_99;
      _v_59 = _v_100;
      _v_60 = _v_101;
      _v_61 = _v_102;
      _v_62 = _v_103;
      _v_63 = _v_104;
      _v_64 = _v_105;
      _v_65 = _v_106;
      _v_66 = _v_107;
      _v_67 = _v_108;
      _v_68 = _v_109;
      _v_69 = _v_110;
      _v_70 = _v_111;
      _v_71 = _v_112;
      _v_72 = _v_113;
      _v_73 = _v_114;
      _v_74 = _v_115;
      _v_75 = _v_116;
    }
  break;
  }
  o[0] = _v_57;
  o[1] = _v_58;
  o[2] = _v_59;
  o[3] = _v_60;
  o[4] = _v_61;
  o[5] = _v_62;
  o[6] = _v_63;
  o[7] = _v_64;
  o[8] = _v_65;
  o[9] = _v_66;
  o[10] = _v_67;
  o[11] = _v_68;
  o[12] = _v_69;
  o[13] = _v_70;
  o[14] = _v_71;
  o[15] = _v_72;
  o[16] = _v_73;
  o[17] = _v_74;
  o[18] = _v_75;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h13 = r13;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  u32 _tick_1 = r2;
  Term _rows_9 = r3;
  Term _rows_10 = r4;
  Term _rows_11 = r5;
  Term _rows_12 = r6;
  Term _rows_13 = r7;
  Term _rows_14 = r8;
  u32 _rows_15 = r9;
  Term _rows_16 = r10;
  u32 _rows_17 = r11;
  u32 _replacement_2 = r12;
  Term _replacement_3 = r13;
  WL_SPIN
    if (_valid_0 == 0) {
      term_sink(e, _replacement_3);
      _v_14 = _rows_9;
      _v_15 = _rows_10;
      _v_16 = _rows_11;
      _v_17 = _rows_12;
      _v_18 = _rows_13;
      _v_19 = _rows_14;
      _v_20 = _rows_15;
      _v_21 = _rows_16;
      _v_22 = _rows_17;
      _v_23 = 0;
    } else {
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      Term _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      Term _o_2[9];
      if (spin_32(e, _o_2, _rows_11, _rows_11 == h5 ? q5 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h6 ? q6 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h7 ? q7 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h8 ? q8 : blk_loc(e.mem, _rows_14), U32_BIN(_id_1, -, 1ull)) == 0) {
        return 0;
      }
      _v_33 = _o_2[0];
      _v_34 = _o_2[1];
      _v_35 = _o_2[2];
      _v_36 = _o_2[3];
      _v_37 = _o_2[4];
      _v_38 = _o_2[5];
      _v_39 = _o_2[6];
      _v_40 = _o_2[7];
      _v_41 = _o_2[8];
      _v_24 = _v_33;
      _v_25 = _v_34;
      _v_26 = _v_35;
      _v_27 = _v_36;
      _v_28 = _v_37;
      _v_29 = _v_38;
      _v_30 = _v_39;
      _v_31 = _v_40;
      _v_32 = _v_41;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      Term _o_3[10];
      if (spin_49(e, _o_3, _id_1, _tick_1, _rows_9, _rows_9 == h3 ? q3 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h4 ? q4 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _replacement_2, _replacement_3, _replacement_3 == h13 ? q13 : blk_loc(e.mem, _replacement_3), _v_24, _v_24 == h13 ? q13 : _v_24 == h8 ? q8 : _v_24 == h7 ? q7 : _v_24 == h6 ? q6 : _v_24 == h5 ? q5 : _v_24 == h4 ? q4 : _v_24 == h3 ? q3 : blk_loc(e.mem, _v_24), _v_25, _v_25 == h13 ? q13 : _v_25 == h8 ? q8 : _v_25 == h7 ? q7 : _v_25 == h6 ? q6 : _v_25 == h5 ? q5 : _v_25 == h4 ? q4 : _v_25 == h3 ? q3 : blk_loc(e.mem, _v_25), _v_26, _v_26 == h13 ? q13 : _v_26 == h8 ? q8 : _v_26 == h7 ? q7 : _v_26 == h6 ? q6 : _v_26 == h5 ? q5 : _v_26 == h4 ? q4 : _v_26 == h3 ? q3 : blk_loc(e.mem, _v_26), _v_27, _v_27 == h13 ? q13 : _v_27 == h8 ? q8 : _v_27 == h7 ? q7 : _v_27 == h6 ? q6 : _v_27 == h5 ? q5 : _v_27 == h4 ? q4 : _v_27 == h3 ? q3 : blk_loc(e.mem, _v_27), _v_28, _v_29, _v_30, _v_30 == h13 ? q13 : _v_30 == h8 ? q8 : _v_30 == h7 ? q7 : _v_30 == h6 ? q6 : _v_30 == h5 ? q5 : _v_30 == h4 ? q4 : _v_30 == h3 ? q3 : blk_loc(e.mem, _v_30), _v_31, _v_32) == 0) {
        return 0;
      }
      _v_42 = _o_3[0];
      _v_43 = _o_3[1];
      _v_44 = _o_3[2];
      _v_45 = _o_3[3];
      _v_46 = _o_3[4];
      _v_47 = _o_3[5];
      _v_48 = _o_3[6];
      _v_49 = _o_3[7];
      _v_50 = _o_3[8];
      _v_51 = _o_3[9];
      _v_14 = _v_42;
      _v_15 = _v_43;
      _v_16 = _v_44;
      _v_17 = _v_45;
      _v_18 = _v_46;
      _v_19 = _v_47;
      _v_20 = _v_48;
      _v_21 = _v_49;
      _v_22 = _v_50;
      _v_23 = _v_51;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _changes_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  Term _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  u32 _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  u32 _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  u32 _result_13 = r14;
  Term _result_14 = r15;
  u32 _result_15 = r16;
  Term _result_16 = r17;
  u32 _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      _v_19 = 0;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _changes_0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    } else {
      term_sink(e, _changes_0);
      _v_19 = 1;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _result_10;
      _v_30 = _result_11;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h9 = r9;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _pair_0 = r0;
  u32 _pair_1 = r1;
  u32 _pair_2 = r2;
  u32 _pair_3 = r3;
  u32 _pair_4 = r4;
  u32 _pair_5 = r5;
  u32 _pair_6 = r6;
  u32 _pair_7 = r7;
  u32 _pair_8 = r8;
  Term _pair_9 = r9;
  WL_SPIN
    _v_11 = 1;
    _v_12 = _pair_0;
    _v_13 = _pair_1;
    _v_14 = _pair_2;
    _v_15 = _pair_3;
    _v_16 = _pair_4;
    _v_17 = _pair_5;
    _v_18 = _pair_6;
    _v_19 = _pair_7;
    _v_20 = _pair_8;
    _v_21 = _pair_9;
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _a_0 = r0;
  Term _result_2 = r1;
  u32 _result_3 = r2;
  WL_SPIN
    Term _at_2 = _result_2 == h1 ? q1 : blk_loc(e.mem, _result_2);
    Term _at_3 = blk_at(_result_2, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_50(e, _o_0, _a_0, _result_3, _result_2, _result_2 == h1 ? q1 : blk_loc(e.mem, _result_2), _c_1) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  u32 _replacement_0 = r10;
  Term _replacement_1 = r11;
  u32 _tick_1 = r12;
  WL_SPIN
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _o_2[1];
    if (spin_7(e, _o_2, U32_BIN(_id_0, <=, _rows_15), U32_BIN(_id_0, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_70 = _o_2[0];
    _v_69 = _v_70;
    u32 _v_71 = 0;
    Term _o_3[1];
    if (spin_7(e, _o_3, U32_BIN(0ull, <, _id_0), _v_69) == 0) {
      return 0;
    }
    _v_71 = _o_3[0];
    _v_68 = _v_71;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _o_4[10];
    if (spin_52(e, _o_4, _v_68, _id_0, _tick_1, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _replacement_0, _replacement_1, _replacement_1 == h11 ? q11 : blk_loc(e.mem, _replacement_1)) == 0) {
      return 0;
    }
    _v_72 = _o_4[0];
    _v_73 = _o_4[1];
    _v_74 = _o_4[2];
    _v_75 = _o_4[3];
    _v_76 = _o_4[4];
    _v_77 = _o_4[5];
    _v_78 = _o_4[6];
    _v_79 = _o_4[7];
    _v_80 = _o_4[8];
    _v_81 = _o_4[9];
    _v_58 = _v_72;
    _v_59 = _v_73;
    _v_60 = _v_74;
    _v_61 = _v_75;
    _v_62 = _v_76;
    _v_63 = _v_77;
    _v_64 = _v_78;
    _v_65 = _v_79;
    _v_66 = _v_80;
    _v_67 = _v_81;
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  o[5] = _v_63;
  o[6] = _v_64;
  o[7] = _v_65;
  o[8] = _v_66;
  o[9] = _v_67;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  Term _v_103 = 0;
  Term _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  u32 _v_108 = 0;
  Term _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  u32 _v_114 = 0;
  Term _v_115 = 0;
  u32 _v_116 = 0;
  Term _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _namespace_2 = r0;
  u32 _id_1 = r1;
  Term _result_0 = r2;
  Term _result_1 = r3;
  Term _result_2 = r4;
  Term _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  Term _result_7 = r9;
  u32 _result_8 = r10;
  u32 _result_9 = r11;
  WL_SPIN
    if (_result_9 == 1) {
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_4 + 1] = rfc_seal(e, _id_1);
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_5 + 1] = rfc_seal(e, _id_1);
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_5));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINADDED, _nd_4));
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_7);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 2) {
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_8 + 1] = rfc_seal(e, _id_1);
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_8));
      e.mem[_nd_9 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_9);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 3) {
      u64 _nd_10 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_10 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_10 + 1] = rfc_seal(e, _id_1);
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINREMOVED, _nd_10));
      e.mem[_nd_11 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_ctr(CID_CON, _nd_11);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else if (_result_9 == 0) {
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_pak(CID_NIL, 0);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    } else {
      _v_101 = 0;
      _v_102 = _result_0;
      _v_103 = _result_1;
      _v_104 = _result_2;
      _v_105 = _result_3;
      _v_106 = _result_4;
      _v_107 = _result_5;
      _v_108 = _result_6;
      _v_109 = _result_7;
      _v_110 = _result_8;
      _v_111 = term_pak(CID_NIL, 0);
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
      _v_116 = 0;
      _v_117 = 0;
      _v_118 = 0;
      _v_119 = 0;
    }
  break;
  }
  o[0] = _v_101;
  o[1] = _v_102;
  o[2] = _v_103;
  o[3] = _v_104;
  o[4] = _v_105;
  o[5] = _v_106;
  o[6] = _v_107;
  o[7] = _v_108;
  o[8] = _v_109;
  o[9] = _v_110;
  o[10] = _v_111;
  o[11] = _v_112;
  o[12] = _v_113;
  o[13] = _v_114;
  o[14] = _v_115;
  o[15] = _v_116;
  o[16] = _v_117;
  o[17] = _v_118;
  o[18] = _v_119;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h7 = r7;
  u32 _v_177 = 0;
  u32 _v_178 = 0;
  Term _v_179 = 0;
  Term _v_180 = 0;
  u32 _v_181 = 0;
  Term _v_182 = 0;
  u32 _v_183 = 0;
  Term _v_184 = 0;
  u32 _v_185 = 0;
  u32 _command_9 = r0;
  u32 _command_10 = r1;
  Term _command_11 = r2;
  Term _command_12 = r3;
  u32 _command_13 = r4;
  Term _command_14 = r5;
  u32 _command_15 = r6;
  Term _command_16 = r7;
  WL_SPIN
    if (_command_9 == 0) {
      _v_177 = 0;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = _command_12;
      _v_181 = _command_13;
      _v_182 = _command_14;
      _v_183 = _command_15;
      _v_184 = _command_16;
      _v_185 = _command_10;
    } else if (_command_9 == 1) {
      _v_177 = 1;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 2) {
      _v_177 = 2;
      _v_178 = _command_10;
      _v_179 = _command_11;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 3) {
      _v_177 = 3;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else if (_command_9 == 4) {
      _v_177 = 4;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    } else {
      _v_177 = 5;
      _v_178 = _command_10;
      _v_179 = 0;
      _v_180 = 0;
      _v_181 = 0;
      _v_182 = 0;
      _v_183 = 0;
      _v_184 = 0;
      _v_185 = _command_10;
    }
  break;
  }
  o[0] = _v_177;
  o[1] = _v_178;
  o[2] = _v_179;
  o[3] = _v_180;
  o[4] = _v_181;
  o[5] = _v_182;
  o[6] = _v_183;
  o[7] = _v_184;
  o[8] = _v_185;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  u32 _v_205 = 0;
  Term _v_206 = 0;
  Term _v_207 = 0;
  Term _v_208 = 0;
  Term _v_209 = 0;
  Term _v_210 = 0;
  Term _v_211 = 0;
  u32 _v_212 = 0;
  Term _v_213 = 0;
  u32 _v_214 = 0;
  Term _v_215 = 0;
  u32 _v_216 = 0;
  Term _v_217 = 0;
  u32 _v_218 = 0;
  Term _v_219 = 0;
  u32 _v_220 = 0;
  Term _v_221 = 0;
  u32 _v_222 = 0;
  u32 _v_223 = 0;
  u32 _namespace_3 = r0;
  u32 _tick_2 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  u32 _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  Term _result_13 = r14;
  u32 _result_14 = r15;
  Term _result_15 = r16;
  u32 _result_16 = r17;
  Term _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    Term _v_224 = 0;
    Term _v_225 = 0;
    Term _v_226 = 0;
    Term _v_227 = 0;
    Term _v_228 = 0;
    Term _v_229 = 0;
    u32 _v_230 = 0;
    Term _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    u32 _v_235 = 0;
    Term _v_236 = 0;
    u32 _v_237 = 0;
    Term _v_238 = 0;
    u32 _v_239 = 0;
    Term _v_240 = 0;
    u32 _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    Term _v_244 = 0;
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    Term _v_248 = 0;
    u32 _v_249 = 0;
    Term _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    Term _v_255 = 0;
    u32 _v_256 = 0;
    Term _v_257 = 0;
    u32 _v_258 = 0;
    Term _v_259 = 0;
    u32 _v_260 = 0;
    u32 _v_261 = 0;
    Term _o_10[19];
    if (spin_30(e, _o_10, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), _rows_24, _rows_25, _rows_26, _result_18) == 0) {
      return 0;
    }
    _v_243 = _o_10[0];
    _v_244 = _o_10[1];
    _v_245 = _o_10[2];
    _v_246 = _o_10[3];
    _v_247 = _o_10[4];
    _v_248 = _o_10[5];
    _v_249 = _o_10[6];
    _v_250 = _o_10[7];
    _v_251 = _o_10[8];
    _v_252 = _o_10[9];
    _v_253 = _o_10[10];
    _v_254 = _o_10[11];
    _v_255 = _o_10[12];
    _v_256 = _o_10[13];
    _v_257 = _o_10[14];
    _v_258 = _o_10[15];
    _v_259 = _o_10[16];
    _v_260 = _o_10[17];
    _v_261 = _o_10[18];
    _v_224 = _v_243;
    _v_225 = _v_244;
    _v_226 = _v_245;
    _v_227 = _v_246;
    _v_228 = _v_247;
    _v_229 = _v_248;
    _v_230 = _v_249;
    _v_231 = _v_250;
    _v_232 = _v_251;
    _v_233 = _v_252;
    _v_234 = _v_253;
    _v_235 = _v_254;
    _v_236 = _v_255;
    _v_237 = _v_256;
    _v_238 = _v_257;
    _v_239 = _v_258;
    _v_240 = _v_259;
    _v_241 = _v_260;
    _v_242 = _v_261;
    u32 _v_262 = 0;
    Term _v_263 = 0;
    Term _v_264 = 0;
    Term _v_265 = 0;
    Term _v_266 = 0;
    Term _v_267 = 0;
    Term _v_268 = 0;
    u32 _v_269 = 0;
    Term _v_270 = 0;
    u32 _v_271 = 0;
    Term _v_272 = 0;
    u32 _v_273 = 0;
    Term _v_274 = 0;
    u32 _v_275 = 0;
    Term _v_276 = 0;
    u32 _v_277 = 0;
    Term _v_278 = 0;
    u32 _v_279 = 0;
    u32 _v_280 = 0;
    Term _o_11[19];
    if (spin_51(e, _o_11, _namespace_3, _tick_2, _result_18, _result_10, _result_11, _result_12, _result_12 == h13 ? q13 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h14 ? q14 : blk_loc(e.mem, _result_13), _result_14, _result_15, _result_15 == h16 ? q16 : blk_loc(e.mem, _result_15), _result_16, _result_17, _result_17 == h18 ? q18 : blk_loc(e.mem, _result_17), _v_224, _v_224 == h18 ? q18 : _v_224 == h16 ? q16 : _v_224 == h14 ? q14 : _v_224 == h13 ? q13 : _v_224 == h7 ? q7 : _v_224 == h6 ? q6 : _v_224 == h5 ? q5 : _v_224 == h4 ? q4 : _v_224 == h3 ? q3 : _v_224 == h2 ? q2 : blk_loc(e.mem, _v_224), _v_225, _v_225 == h18 ? q18 : _v_225 == h16 ? q16 : _v_225 == h14 ? q14 : _v_225 == h13 ? q13 : _v_225 == h7 ? q7 : _v_225 == h6 ? q6 : _v_225 == h5 ? q5 : _v_225 == h4 ? q4 : _v_225 == h3 ? q3 : _v_225 == h2 ? q2 : blk_loc(e.mem, _v_225), _v_226, _v_226 == h18 ? q18 : _v_226 == h16 ? q16 : _v_226 == h14 ? q14 : _v_226 == h13 ? q13 : _v_226 == h7 ? q7 : _v_226 == h6 ? q6 : _v_226 == h5 ? q5 : _v_226 == h4 ? q4 : _v_226 == h3 ? q3 : _v_226 == h2 ? q2 : blk_loc(e.mem, _v_226), _v_227, _v_227 == h18 ? q18 : _v_227 == h16 ? q16 : _v_227 == h14 ? q14 : _v_227 == h13 ? q13 : _v_227 == h7 ? q7 : _v_227 == h6 ? q6 : _v_227 == h5 ? q5 : _v_227 == h4 ? q4 : _v_227 == h3 ? q3 : _v_227 == h2 ? q2 : blk_loc(e.mem, _v_227), _v_228, _v_228 == h18 ? q18 : _v_228 == h16 ? q16 : _v_228 == h14 ? q14 : _v_228 == h13 ? q13 : _v_228 == h7 ? q7 : _v_228 == h6 ? q6 : _v_228 == h5 ? q5 : _v_228 == h4 ? q4 : _v_228 == h3 ? q3 : _v_228 == h2 ? q2 : blk_loc(e.mem, _v_228), _v_229, _v_229 == h18 ? q18 : _v_229 == h16 ? q16 : _v_229 == h14 ? q14 : _v_229 == h13 ? q13 : _v_229 == h7 ? q7 : _v_229 == h6 ? q6 : _v_229 == h5 ? q5 : _v_229 == h4 ? q4 : _v_229 == h3 ? q3 : _v_229 == h2 ? q2 : blk_loc(e.mem, _v_229), _v_230, _v_231, _v_232, _v_233, _v_234, _v_235, _v_236, _v_236 == h18 ? q18 : _v_236 == h16 ? q16 : _v_236 == h14 ? q14 : _v_236 == h13 ? q13 : _v_236 == h7 ? q7 : _v_236 == h6 ? q6 : _v_236 == h5 ? q5 : _v_236 == h4 ? q4 : _v_236 == h3 ? q3 : _v_236 == h2 ? q2 : blk_loc(e.mem, _v_236), _v_237, _v_238, _v_238 == h18 ? q18 : _v_238 == h16 ? q16 : _v_238 == h14 ? q14 : _v_238 == h13 ? q13 : _v_238 == h7 ? q7 : _v_238 == h6 ? q6 : _v_238 == h5 ? q5 : _v_238 == h4 ? q4 : _v_238 == h3 ? q3 : _v_238 == h2 ? q2 : blk_loc(e.mem, _v_238), _v_239, _v_240, _v_240 == h18 ? q18 : _v_240 == h16 ? q16 : _v_240 == h14 ? q14 : _v_240 == h13 ? q13 : _v_240 == h7 ? q7 : _v_240 == h6 ? q6 : _v_240 == h5 ? q5 : _v_240 == h4 ? q4 : _v_240 == h3 ? q3 : _v_240 == h2 ? q2 : blk_loc(e.mem, _v_240), _v_241, _v_242) == 0) {
      return 0;
    }
    _v_262 = _o_11[0];
    _v_263 = _o_11[1];
    _v_264 = _o_11[2];
    _v_265 = _o_11[3];
    _v_266 = _o_11[4];
    _v_267 = _o_11[5];
    _v_268 = _o_11[6];
    _v_269 = _o_11[7];
    _v_270 = _o_11[8];
    _v_271 = _o_11[9];
    _v_272 = _o_11[10];
    _v_273 = _o_11[11];
    _v_274 = _o_11[12];
    _v_275 = _o_11[13];
    _v_276 = _o_11[14];
    _v_277 = _o_11[15];
    _v_278 = _o_11[16];
    _v_279 = _o_11[17];
    _v_280 = _o_11[18];
    _v_205 = _v_262;
    _v_206 = _v_263;
    _v_207 = _v_264;
    _v_208 = _v_265;
    _v_209 = _v_266;
    _v_210 = _v_267;
    _v_211 = _v_268;
    _v_212 = _v_269;
    _v_213 = _v_270;
    _v_214 = _v_271;
    _v_215 = _v_272;
    _v_216 = _v_273;
    _v_217 = _v_274;
    _v_218 = _v_275;
    _v_219 = _v_276;
    _v_220 = _v_277;
    _v_221 = _v_278;
    _v_222 = _v_279;
    _v_223 = _v_280;
  break;
  }
  o[0] = _v_205;
  o[1] = _v_206;
  o[2] = _v_207;
  o[3] = _v_208;
  o[4] = _v_209;
  o[5] = _v_210;
  o[6] = _v_211;
  o[7] = _v_212;
  o[8] = _v_213;
  o[9] = _v_214;
  o[10] = _v_215;
  o[11] = _v_216;
  o[12] = _v_217;
  o[13] = _v_218;
  o[14] = _v_219;
  o[15] = _v_220;
  o[16] = _v_221;
  o[17] = _v_222;
  o[18] = _v_223;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_138 = 0;
  u32 _v_139 = 0;
  Term _v_140 = 0;
  Term _v_141 = 0;
  Term _v_142 = 0;
  Term _v_143 = 0;
  Term _v_144 = 0;
  Term _v_145 = 0;
  u32 _v_146 = 0;
  Term _v_147 = 0;
  u32 _v_148 = 0;
  Term _v_149 = 0;
  u32 _v_150 = 0;
  Term _v_151 = 0;
  Term _v_152 = 0;
  u32 _v_153 = 0;
  u32 _v_154 = 0;
  u32 _v_155 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  u32 _next_0 = r2;
  Term _rows_0 = r3;
  Term _rows_1 = r4;
  Term _rows_2 = r5;
  Term _rows_3 = r6;
  Term _rows_4 = r7;
  Term _rows_5 = r8;
  u32 _rows_6 = r9;
  Term _rows_7 = r10;
  u32 _rows_8 = r11;
  Term _pending_0 = r12;
  u32 _ledger_0 = r13;
  Term _ledger_1 = r14;
  Term _mode_0 = r15;
  WL_SPIN
    if (_available_0 == 0) {
      _v_138 = _namespace_0;
      _v_139 = _next_0;
      _v_140 = _rows_0;
      _v_141 = _rows_1;
      _v_142 = _rows_2;
      _v_143 = _rows_3;
      _v_144 = _rows_4;
      _v_145 = _rows_5;
      _v_146 = _rows_6;
      _v_147 = _rows_7;
      _v_148 = _rows_8;
      _v_149 = _pending_0;
      _v_150 = _ledger_0;
      _v_151 = _ledger_1;
      _v_152 = _mode_0;
      _v_153 = 0;
      _v_154 = 0;
      _v_155 = 0;
    } else {
      _v_138 = _namespace_0;
      _v_139 = U32_BIN(_next_0, +, 1ull);
      _v_140 = _rows_0;
      _v_141 = _rows_1;
      _v_142 = _rows_2;
      _v_143 = _rows_3;
      _v_144 = _rows_4;
      _v_145 = _rows_5;
      _v_146 = _rows_6;
      _v_147 = _rows_7;
      _v_148 = _rows_8;
      _v_149 = _pending_0;
      _v_150 = _ledger_0;
      _v_151 = _ledger_1;
      _v_152 = _mode_0;
      _v_153 = 1;
      _v_154 = _namespace_0;
      _v_155 = _next_0;
    }
  break;
  }
  o[0] = _v_138;
  o[1] = _v_139;
  o[2] = _v_140;
  o[3] = _v_141;
  o[4] = _v_142;
  o[5] = _v_143;
  o[6] = _v_144;
  o[7] = _v_145;
  o[8] = _v_146;
  o[9] = _v_147;
  o[10] = _v_148;
  o[11] = _v_149;
  o[12] = _v_150;
  o[13] = _v_151;
  o[14] = _v_152;
  o[15] = _v_153;
  o[16] = _v_154;
  o[17] = _v_155;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_102 = 0;
  u32 _v_103 = 0;
  Term _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  Term _v_108 = 0;
  Term _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  u32 _v_114 = 0;
  Term _v_115 = 0;
  Term _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _world_41 = r0;
  u32 _world_42 = r1;
  Term _world_43 = r2;
  Term _world_44 = r3;
  Term _world_45 = r4;
  Term _world_46 = r5;
  Term _world_47 = r6;
  Term _world_48 = r7;
  u32 _world_49 = r8;
  Term _world_50 = r9;
  u32 _world_51 = r10;
  Term _world_52 = r11;
  u32 _world_53 = r12;
  Term _world_54 = r13;
  Term _world_55 = r14;
  WL_SPIN
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    Term _v_122 = 0;
    Term _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    Term _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    Term _v_131 = 0;
    u32 _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    Term _o_2[18];
    if (spin_64(e, _o_2, U32_BIN(_world_42, <, 4294967295ull), _world_41, _world_42, _world_43, _world_43 == h2 ? q2 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h3 ? q3 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h4 ? q4 : blk_loc(e.mem, _world_45), _world_46, _world_46 == h5 ? q5 : blk_loc(e.mem, _world_46), _world_47, _world_47 == h6 ? q6 : blk_loc(e.mem, _world_47), _world_48, _world_48 == h7 ? q7 : blk_loc(e.mem, _world_48), _world_49, _world_50, _world_51, _world_52, _world_52 == h11 ? q11 : blk_loc(e.mem, _world_52), _world_53, _world_54, _world_54 == h13 ? q13 : blk_loc(e.mem, _world_54), _world_55, _world_55 == h14 ? q14 : blk_loc(e.mem, _world_55)) == 0) {
      return 0;
    }
    _v_120 = _o_2[0];
    _v_121 = _o_2[1];
    _v_122 = _o_2[2];
    _v_123 = _o_2[3];
    _v_124 = _o_2[4];
    _v_125 = _o_2[5];
    _v_126 = _o_2[6];
    _v_127 = _o_2[7];
    _v_128 = _o_2[8];
    _v_129 = _o_2[9];
    _v_130 = _o_2[10];
    _v_131 = _o_2[11];
    _v_132 = _o_2[12];
    _v_133 = _o_2[13];
    _v_134 = _o_2[14];
    _v_135 = _o_2[15];
    _v_136 = _o_2[16];
    _v_137 = _o_2[17];
    _v_102 = _v_120;
    _v_103 = _v_121;
    _v_104 = _v_122;
    _v_105 = _v_123;
    _v_106 = _v_124;
    _v_107 = _v_125;
    _v_108 = _v_126;
    _v_109 = _v_127;
    _v_110 = _v_128;
    _v_111 = _v_129;
    _v_112 = _v_130;
    _v_113 = _v_131;
    _v_114 = _v_132;
    _v_115 = _v_133;
    _v_116 = _v_134;
    _v_117 = _v_135;
    _v_118 = _v_136;
    _v_119 = _v_137;
  break;
  }
  o[0] = _v_102;
  o[1] = _v_103;
  o[2] = _v_104;
  o[3] = _v_105;
  o[4] = _v_106;
  o[5] = _v_107;
  o[6] = _v_108;
  o[7] = _v_109;
  o[8] = _v_110;
  o[9] = _v_111;
  o[10] = _v_112;
  o[11] = _v_113;
  o[12] = _v_114;
  o[13] = _v_115;
  o[14] = _v_116;
  o[15] = _v_117;
  o[16] = _v_118;
  o[17] = _v_119;
  return 1;
}

INLINE Term spin_68(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_250 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_250 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_3 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_3);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_68);
    }
  break;
  }
  o[0] = _v_250;
  return 1;
}

INLINE Term spin_67(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_248 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_249 = 0;
    Term _o_4[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_68(e, _o_4, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_249 = _o_4[0];
    _v_248 = _v_249;
  break;
  }
  o[0] = _v_248;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_230 = 0;
  u32 _v_231 = 0;
  Term _v_232 = 0;
  Term _v_233 = 0;
  Term _v_234 = 0;
  Term _v_235 = 0;
  Term _v_236 = 0;
  Term _v_237 = 0;
  u32 _v_238 = 0;
  Term _v_239 = 0;
  u32 _v_240 = 0;
  Term _v_241 = 0;
  u32 _v_242 = 0;
  Term _v_243 = 0;
  Term _v_244 = 0;
  u32 _world_56 = r0;
  u32 _world_57 = r1;
  Term _world_58 = r2;
  Term _world_59 = r3;
  Term _world_60 = r4;
  Term _world_61 = r5;
  Term _world_62 = r6;
  Term _world_63 = r7;
  u32 _world_64 = r8;
  Term _world_65 = r9;
  u32 _world_66 = r10;
  Term _world_67 = r11;
  u32 _world_68 = r12;
  Term _world_69 = r13;
  Term _world_70 = r14;
  Term _staged_0 = r15;
  WL_SPIN
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    Term _o_5[1];
    if (spin_67(e, _o_5, _staged_0, _staged_0 == h15 ? q15 : blk_loc(e.mem, _staged_0)) == 0) {
      return 0;
    }
    _v_247 = _o_5[0];
    _v_246 = _v_247;
    Term _v_251 = 0;
    Term _o_6[1];
    if (spin_68(e, _o_6, _v_246, _v_246 == h15 ? q15 : _v_246 == h14 ? q14 : _v_246 == h13 ? q13 : _v_246 == h11 ? q11 : _v_246 == h7 ? q7 : _v_246 == h6 ? q6 : _v_246 == h5 ? q5 : _v_246 == h4 ? q4 : _v_246 == h3 ? q3 : _v_246 == h2 ? q2 : blk_loc(e.mem, _v_246), _world_67, _world_67 == h11 ? q11 : blk_loc(e.mem, _world_67)) == 0) {
      return 0;
    }
    _v_251 = _o_6[0];
    _v_245 = _v_251;
    _v_230 = _world_56;
    _v_231 = _world_57;
    _v_232 = _world_58;
    _v_233 = _world_59;
    _v_234 = _world_60;
    _v_235 = _world_61;
    _v_236 = _world_62;
    _v_237 = _world_63;
    _v_238 = _world_64;
    _v_239 = _world_65;
    _v_240 = _world_66;
    _v_241 = _v_245;
    _v_242 = _world_68;
    _v_243 = _world_69;
    _v_244 = _world_70;
  break;
  }
  o[0] = _v_230;
  o[1] = _v_231;
  o[2] = _v_232;
  o[3] = _v_233;
  o[4] = _v_234;
  o[5] = _v_235;
  o[6] = _v_236;
  o[7] = _v_237;
  o[8] = _v_238;
  o[9] = _v_239;
  o[10] = _v_240;
  o[11] = _v_241;
  o[12] = _v_242;
  o[13] = _v_243;
  o[14] = _v_244;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, Term r15, u32 r16, Term r17, u64 q17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, u32 r21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h17 = r17;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  u32 _v_180 = 0;
  Term _v_181 = 0;
  Term _v_182 = 0;
  Term _v_183 = 0;
  Term _v_184 = 0;
  Term _v_185 = 0;
  Term _v_186 = 0;
  u32 _v_187 = 0;
  Term _v_188 = 0;
  u32 _v_189 = 0;
  Term _v_190 = 0;
  u32 _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  u32 _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  Term _v_197 = 0;
  u32 _v_198 = 0;
  Term _v_199 = 0;
  u32 _bundle_6 = r0;
  Term _bundle_7 = r1;
  u32 _bundle_8 = r2;
  Term _bundle_9 = r3;
  u32 _bundle_10 = r4;
  Term _bundle_11 = r5;
  u32 _result_0 = r6;
  u32 _result_1 = r7;
  Term _result_2 = r8;
  Term _result_3 = r9;
  Term _result_4 = r10;
  Term _result_5 = r11;
  Term _result_6 = r12;
  Term _result_7 = r13;
  u32 _result_8 = r14;
  Term _result_9 = r15;
  u32 _result_10 = r16;
  Term _result_11 = r17;
  u32 _result_12 = r18;
  Term _result_13 = r19;
  Term _result_14 = r20;
  u32 _result_15 = r21;
  u32 _result_16 = r22;
  u32 _result_17 = r23;
  WL_SPIN
    if (_result_15 == 0) {
      _v_178 = 1;
      _v_179 = _result_0;
      _v_180 = _result_1;
      _v_181 = _result_2;
      _v_182 = _result_3;
      _v_183 = _result_4;
      _v_184 = _result_5;
      _v_185 = _result_6;
      _v_186 = _result_7;
      _v_187 = _result_8;
      _v_188 = _result_9;
      _v_189 = _result_10;
      _v_190 = _result_11;
      _v_191 = _result_12;
      _v_192 = _result_13;
      _v_193 = _result_14;
      _v_194 = _bundle_6;
      _v_195 = _bundle_7;
      _v_196 = _bundle_8;
      _v_197 = _bundle_9;
      _v_198 = _bundle_10;
      _v_199 = _bundle_11;
    } else {
      u32 _v_200 = 0;
      u32 _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      Term _v_204 = 0;
      Term _v_205 = 0;
      Term _v_206 = 0;
      Term _v_207 = 0;
      u32 _v_208 = 0;
      Term _v_209 = 0;
      u32 _v_210 = 0;
      Term _v_211 = 0;
      u32 _v_212 = 0;
      Term _v_213 = 0;
      Term _v_214 = 0;
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_17);
      e.mem[_nd_1 + 1] = rfc_seal(e, _bundle_6);
      e.mem[_nd_1 + 2] = rfc_seal(e, _bundle_7);
      e.mem[_nd_1 + 3] = rfc_seal(e, _bundle_8);
      e.mem[_nd_1 + 4] = rfc_seal(e, _bundle_9);
      e.mem[_nd_1 + 5] = rfc_seal(e, _bundle_10);
      e.mem[_nd_1 + 6] = rfc_seal(e, _bundle_11);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_SPAWN, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      Term _v_217 = 0;
      Term _v_218 = 0;
      Term _v_219 = 0;
      Term _v_220 = 0;
      Term _v_221 = 0;
      Term _v_222 = 0;
      u32 _v_223 = 0;
      Term _v_224 = 0;
      u32 _v_225 = 0;
      Term _v_226 = 0;
      u32 _v_227 = 0;
      Term _v_228 = 0;
      Term _v_229 = 0;
      Term _o_7[15];
      Term _a_1 = term_ctr(CID_CON, _nd_2);
      if (spin_66(e, _o_7, _result_0, _result_1, _result_2, _result_2 == h8 ? q8 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h9 ? q9 : blk_loc(e.mem, _result_3), _result_4, _result_4 == h10 ? q10 : blk_loc(e.mem, _result_4), _result_5, _result_5 == h11 ? q11 : blk_loc(e.mem, _result_5), _result_6, _result_6 == h12 ? q12 : blk_loc(e.mem, _result_6), _result_7, _result_7 == h13 ? q13 : blk_loc(e.mem, _result_7), _result_8, _result_9, _result_10, _result_11, _result_11 == h17 ? q17 : blk_loc(e.mem, _result_11), _result_12, _result_13, _result_13 == h19 ? q19 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h20 ? q20 : blk_loc(e.mem, _result_14), _a_1, _a_1 == h20 ? q20 : _a_1 == h19 ? q19 : _a_1 == h17 ? q17 : _a_1 == h13 ? q13 : _a_1 == h12 ? q12 : _a_1 == h11 ? q11 : _a_1 == h10 ? q10 : _a_1 == h9 ? q9 : _a_1 == h8 ? q8 : _a_1 == h5 ? q5 : _a_1 == h3 ? q3 : _a_1 == h1 ? q1 : blk_loc(e.mem, _a_1)) == 0) {
        return 0;
      }
      _v_215 = _o_7[0];
      _v_216 = _o_7[1];
      _v_217 = _o_7[2];
      _v_218 = _o_7[3];
      _v_219 = _o_7[4];
      _v_220 = _o_7[5];
      _v_221 = _o_7[6];
      _v_222 = _o_7[7];
      _v_223 = _o_7[8];
      _v_224 = _o_7[9];
      _v_225 = _o_7[10];
      _v_226 = _o_7[11];
      _v_227 = _o_7[12];
      _v_228 = _o_7[13];
      _v_229 = _o_7[14];
      _v_200 = _v_215;
      _v_201 = _v_216;
      _v_202 = _v_217;
      _v_203 = _v_218;
      _v_204 = _v_219;
      _v_205 = _v_220;
      _v_206 = _v_221;
      _v_207 = _v_222;
      _v_208 = _v_223;
      _v_209 = _v_224;
      _v_210 = _v_225;
      _v_211 = _v_226;
      _v_212 = _v_227;
      _v_213 = _v_228;
      _v_214 = _v_229;
      _v_178 = 0;
      _v_179 = _v_200;
      _v_180 = _v_201;
      _v_181 = _v_202;
      _v_182 = _v_203;
      _v_183 = _v_204;
      _v_184 = _v_205;
      _v_185 = _v_206;
      _v_186 = _v_207;
      _v_187 = _v_208;
      _v_188 = _v_209;
      _v_189 = _v_210;
      _v_190 = _v_211;
      _v_191 = _v_212;
      _v_192 = _v_213;
      _v_193 = _v_214;
      _v_194 = _result_16;
      _v_195 = _result_17;
      _v_196 = 0;
      _v_197 = 0;
      _v_198 = 0;
      _v_199 = 0;
    }
  break;
  }
  o[0] = _v_178;
  o[1] = _v_179;
  o[2] = _v_180;
  o[3] = _v_181;
  o[4] = _v_182;
  o[5] = _v_183;
  o[6] = _v_184;
  o[7] = _v_185;
  o[8] = _v_186;
  o[9] = _v_187;
  o[10] = _v_188;
  o[11] = _v_189;
  o[12] = _v_190;
  o[13] = _v_191;
  o[14] = _v_192;
  o[15] = _v_193;
  o[16] = _v_194;
  o[17] = _v_195;
  o[18] = _v_196;
  o[19] = _v_197;
  o[20] = _v_198;
  o[21] = _v_199;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  Term h20 = r20;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _world_26 = r0;
  u32 _world_27 = r1;
  Term _world_28 = r2;
  Term _world_29 = r3;
  Term _world_30 = r4;
  Term _world_31 = r5;
  Term _world_32 = r6;
  Term _world_33 = r7;
  u32 _world_34 = r8;
  Term _world_35 = r9;
  u32 _world_36 = r10;
  Term _world_37 = r11;
  u32 _world_38 = r12;
  Term _world_39 = r13;
  Term _world_40 = r14;
  u32 _bundle_0 = r15;
  Term _bundle_1 = r16;
  u32 _bundle_2 = r17;
  Term _bundle_3 = r18;
  u32 _bundle_4 = r19;
  Term _bundle_5 = r20;
  WL_SPIN
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    u32 _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    Term _v_95 = 0;
    u32 _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    Term _o_3[18];
    if (spin_63(e, _o_3, _world_26, _world_27, _world_28, _world_28 == h2 ? q2 : blk_loc(e.mem, _world_28), _world_29, _world_29 == h3 ? q3 : blk_loc(e.mem, _world_29), _world_30, _world_30 == h4 ? q4 : blk_loc(e.mem, _world_30), _world_31, _world_31 == h5 ? q5 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h6 ? q6 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h7 ? q7 : blk_loc(e.mem, _world_33), _world_34, _world_35, _world_36, _world_37, _world_37 == h11 ? q11 : blk_loc(e.mem, _world_37), _world_38, _world_39, _world_39 == h13 ? q13 : blk_loc(e.mem, _world_39), _world_40, _world_40 == h14 ? q14 : blk_loc(e.mem, _world_40)) == 0) {
      return 0;
    }
    _v_84 = _o_3[0];
    _v_85 = _o_3[1];
    _v_86 = _o_3[2];
    _v_87 = _o_3[3];
    _v_88 = _o_3[4];
    _v_89 = _o_3[5];
    _v_90 = _o_3[6];
    _v_91 = _o_3[7];
    _v_92 = _o_3[8];
    _v_93 = _o_3[9];
    _v_94 = _o_3[10];
    _v_95 = _o_3[11];
    _v_96 = _o_3[12];
    _v_97 = _o_3[13];
    _v_98 = _o_3[14];
    _v_99 = _o_3[15];
    _v_100 = _o_3[16];
    _v_101 = _o_3[17];
    _v_66 = _v_84;
    _v_67 = _v_85;
    _v_68 = _v_86;
    _v_69 = _v_87;
    _v_70 = _v_88;
    _v_71 = _v_89;
    _v_72 = _v_90;
    _v_73 = _v_91;
    _v_74 = _v_92;
    _v_75 = _v_93;
    _v_76 = _v_94;
    _v_77 = _v_95;
    _v_78 = _v_96;
    _v_79 = _v_97;
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    u32 _v_158 = 0;
    Term _v_159 = 0;
    Term _v_160 = 0;
    Term _v_161 = 0;
    Term _v_162 = 0;
    Term _v_163 = 0;
    Term _v_164 = 0;
    u32 _v_165 = 0;
    Term _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    Term _v_170 = 0;
    Term _v_171 = 0;
    u32 _v_172 = 0;
    Term _v_173 = 0;
    u32 _v_174 = 0;
    Term _v_175 = 0;
    u32 _v_176 = 0;
    Term _v_177 = 0;
    Term _o_8[22];
    if (spin_65(e, _o_8, _bundle_0, _bundle_1, _bundle_1 == h16 ? q16 : blk_loc(e.mem, _bundle_1), _bundle_2, _bundle_3, _bundle_3 == h18 ? q18 : blk_loc(e.mem, _bundle_3), _bundle_4, _bundle_5, _bundle_5 == h20 ? q20 : blk_loc(e.mem, _bundle_5), _v_66, _v_67, _v_68, _v_68 == h20 ? q20 : _v_68 == h18 ? q18 : _v_68 == h16 ? q16 : _v_68 == h14 ? q14 : _v_68 == h13 ? q13 : _v_68 == h11 ? q11 : _v_68 == h7 ? q7 : _v_68 == h6 ? q6 : _v_68 == h5 ? q5 : _v_68 == h4 ? q4 : _v_68 == h3 ? q3 : _v_68 == h2 ? q2 : blk_loc(e.mem, _v_68), _v_69, _v_69 == h20 ? q20 : _v_69 == h18 ? q18 : _v_69 == h16 ? q16 : _v_69 == h14 ? q14 : _v_69 == h13 ? q13 : _v_69 == h11 ? q11 : _v_69 == h7 ? q7 : _v_69 == h6 ? q6 : _v_69 == h5 ? q5 : _v_69 == h4 ? q4 : _v_69 == h3 ? q3 : _v_69 == h2 ? q2 : blk_loc(e.mem, _v_69), _v_70, _v_70 == h20 ? q20 : _v_70 == h18 ? q18 : _v_70 == h16 ? q16 : _v_70 == h14 ? q14 : _v_70 == h13 ? q13 : _v_70 == h11 ? q11 : _v_70 == h7 ? q7 : _v_70 == h6 ? q6 : _v_70 == h5 ? q5 : _v_70 == h4 ? q4 : _v_70 == h3 ? q3 : _v_70 == h2 ? q2 : blk_loc(e.mem, _v_70), _v_71, _v_71 == h20 ? q20 : _v_71 == h18 ? q18 : _v_71 == h16 ? q16 : _v_71 == h14 ? q14 : _v_71 == h13 ? q13 : _v_71 == h11 ? q11 : _v_71 == h7 ? q7 : _v_71 == h6 ? q6 : _v_71 == h5 ? q5 : _v_71 == h4 ? q4 : _v_71 == h3 ? q3 : _v_71 == h2 ? q2 : blk_loc(e.mem, _v_71), _v_72, _v_72 == h20 ? q20 : _v_72 == h18 ? q18 : _v_72 == h16 ? q16 : _v_72 == h14 ? q14 : _v_72 == h13 ? q13 : _v_72 == h11 ? q11 : _v_72 == h7 ? q7 : _v_72 == h6 ? q6 : _v_72 == h5 ? q5 : _v_72 == h4 ? q4 : _v_72 == h3 ? q3 : _v_72 == h2 ? q2 : blk_loc(e.mem, _v_72), _v_73, _v_73 == h20 ? q20 : _v_73 == h18 ? q18 : _v_73 == h16 ? q16 : _v_73 == h14 ? q14 : _v_73 == h13 ? q13 : _v_73 == h11 ? q11 : _v_73 == h7 ? q7 : _v_73 == h6 ? q6 : _v_73 == h5 ? q5 : _v_73 == h4 ? q4 : _v_73 == h3 ? q3 : _v_73 == h2 ? q2 : blk_loc(e.mem, _v_73), _v_74, _v_75, _v_76, _v_77, _v_77 == h20 ? q20 : _v_77 == h18 ? q18 : _v_77 == h16 ? q16 : _v_77 == h14 ? q14 : _v_77 == h13 ? q13 : _v_77 == h11 ? q11 : _v_77 == h7 ? q7 : _v_77 == h6 ? q6 : _v_77 == h5 ? q5 : _v_77 == h4 ? q4 : _v_77 == h3 ? q3 : _v_77 == h2 ? q2 : blk_loc(e.mem, _v_77), _v_78, _v_79, _v_79 == h20 ? q20 : _v_79 == h18 ? q18 : _v_79 == h16 ? q16 : _v_79 == h14 ? q14 : _v_79 == h13 ? q13 : _v_79 == h11 ? q11 : _v_79 == h7 ? q7 : _v_79 == h6 ? q6 : _v_79 == h5 ? q5 : _v_79 == h4 ? q4 : _v_79 == h3 ? q3 : _v_79 == h2 ? q2 : blk_loc(e.mem, _v_79), _v_80, _v_80 == h20 ? q20 : _v_80 == h18 ? q18 : _v_80 == h16 ? q16 : _v_80 == h14 ? q14 : _v_80 == h13 ? q13 : _v_80 == h11 ? q11 : _v_80 == h7 ? q7 : _v_80 == h6 ? q6 : _v_80 == h5 ? q5 : _v_80 == h4 ? q4 : _v_80 == h3 ? q3 : _v_80 == h2 ? q2 : blk_loc(e.mem, _v_80), _v_81, _v_82, _v_83) == 0) {
      return 0;
    }
    _v_156 = _o_8[0];
    _v_157 = _o_8[1];
    _v_158 = _o_8[2];
    _v_159 = _o_8[3];
    _v_160 = _o_8[4];
    _v_161 = _o_8[5];
    _v_162 = _o_8[6];
    _v_163 = _o_8[7];
    _v_164 = _o_8[8];
    _v_165 = _o_8[9];
    _v_166 = _o_8[10];
    _v_167 = _o_8[11];
    _v_168 = _o_8[12];
    _v_169 = _o_8[13];
    _v_170 = _o_8[14];
    _v_171 = _o_8[15];
    _v_172 = _o_8[16];
    _v_173 = _o_8[17];
    _v_174 = _o_8[18];
    _v_175 = _o_8[19];
    _v_176 = _o_8[20];
    _v_177 = _o_8[21];
    _v_44 = _v_156;
    _v_45 = _v_157;
    _v_46 = _v_158;
    _v_47 = _v_159;
    _v_48 = _v_160;
    _v_49 = _v_161;
    _v_50 = _v_162;
    _v_51 = _v_163;
    _v_52 = _v_164;
    _v_53 = _v_165;
    _v_54 = _v_166;
    _v_55 = _v_167;
    _v_56 = _v_168;
    _v_57 = _v_169;
    _v_58 = _v_170;
    _v_59 = _v_171;
    _v_60 = _v_172;
    _v_61 = _v_173;
    _v_62 = _v_174;
    _v_63 = _v_175;
    _v_64 = _v_176;
    _v_65 = _v_177;
  break;
  }
  o[0] = _v_44;
  o[1] = _v_45;
  o[2] = _v_46;
  o[3] = _v_47;
  o[4] = _v_48;
  o[5] = _v_49;
  o[6] = _v_50;
  o[7] = _v_51;
  o[8] = _v_52;
  o[9] = _v_53;
  o[10] = _v_54;
  o[11] = _v_55;
  o[12] = _v_56;
  o[13] = _v_57;
  o[14] = _v_58;
  o[15] = _v_59;
  o[16] = _v_60;
  o[17] = _v_61;
  o[18] = _v_62;
  o[19] = _v_63;
  o[20] = _v_64;
  o[21] = _v_65;
  return 1;
}

INLINE Term spin_69(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h12 = r12;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _aux_0 = r0;
  u32 _flag_0 = r1;
  u32 _pair_0 = r2;
  Term _pair_1 = r3;
  u32 _pair_2 = r4;
  u32 _pair_3 = r5;
  u32 _pair_4 = r6;
  u32 _pair_5 = r7;
  u32 _pair_6 = r8;
  u32 _pair_7 = r9;
  u32 _pair_8 = r10;
  u32 _pair_9 = r11;
  Term _pair_10 = r12;
  WL_SPIN
    _v_13 = _pair_0;
    _v_14 = _pair_1;
    _v_15 = _pair_2;
    _v_16 = _pair_3;
    _v_17 = _pair_4;
    _v_18 = _pair_5;
    _v_19 = _pair_6;
    _v_20 = _pair_7;
    _v_21 = _pair_8;
    _v_22 = _pair_9;
    _v_23 = _aux_0;
    _v_24 = _flag_0;
    _v_25 = _pair_10;
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  o[5] = _v_18;
  o[6] = _v_19;
  o[7] = _v_20;
  o[8] = _v_21;
  o[9] = _v_22;
  o[10] = _v_23;
  o[11] = _v_24;
  o[12] = _v_25;
  return 1;
}

INLINE Term spin_70(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  WL_SPIN
    Term _at_2 = _result_0 == h0 ? q0 : blk_loc(e.mem, _result_0);
    Term _at_3 = blk_at(_result_0, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_55(e, _o_0, _result_1, _result_0, _result_0 == h0 ? q0 : blk_loc(e.mem, _result_0), _c_1) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_71(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  WL_SPIN
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, U32_BIN(0ull, <, _id_0), U32_BIN(_id_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_30 = _v_31;
    _v_20 = _rows_9;
    _v_21 = _rows_10;
    _v_22 = _rows_11;
    _v_23 = _rows_12;
    _v_24 = _rows_13;
    _v_25 = _rows_14;
    _v_26 = _rows_15;
    _v_27 = _rows_16;
    _v_28 = _rows_17;
    _v_29 = _v_30;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  return 1;
}

INLINE Term spin_72(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _id_1 = r0;
  u32 _bundle_0 = r1;
  Term _bundle_1 = r2;
  u32 _bundle_2 = r3;
  Term _bundle_3 = r4;
  u32 _bundle_4 = r5;
  Term _bundle_5 = r6;
  Term _result_0 = r7;
  Term _result_1 = r8;
  Term _result_2 = r9;
  Term _result_3 = r10;
  Term _result_4 = r11;
  Term _result_5 = r12;
  u32 _result_6 = r13;
  Term _result_7 = r14;
  u32 _result_8 = r15;
  u32 _result_9 = r16;
  WL_SPIN
    _v_50 = _result_0;
    _v_51 = _result_1;
    _v_52 = _result_2;
    _v_53 = _result_3;
    _v_54 = _result_4;
    _v_55 = _result_5;
    _v_56 = _result_6;
    _v_57 = _result_7;
    _v_58 = _result_8;
    _v_59 = 0;
    _v_60 = _id_1;
    _v_61 = _bundle_0;
    _v_62 = _bundle_1;
    _v_63 = _bundle_2;
    _v_64 = _bundle_3;
    _v_65 = _bundle_4;
    _v_66 = _bundle_5;
    _v_67 = _result_9;
  break;
  }
  o[0] = _v_50;
  o[1] = _v_51;
  o[2] = _v_52;
  o[3] = _v_53;
  o[4] = _v_54;
  o[5] = _v_55;
  o[6] = _v_56;
  o[7] = _v_57;
  o[8] = _v_58;
  o[9] = _v_59;
  o[10] = _v_60;
  o[11] = _v_61;
  o[12] = _v_62;
  o[13] = _v_63;
  o[14] = _v_64;
  o[15] = _v_65;
  o[16] = _v_66;
  o[17] = _v_67;
  return 1;
}

INLINE Term spin_74(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_44 = 0;
  Term _xs_0 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      _v_44 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_0 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_74);
    }
  break;
  }
  o[0] = _v_44;
  return 1;
}

INLINE Term spin_75(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_47 = 0;
  Term _xs_1 = r0;
  WL_SPIN
    Term _v_48 = 0;
    Term _o_1[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_74(e, _o_1, _xs_1, _xs_1 == h0 ? q0 : blk_loc(e.mem, _xs_1), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_48 = _o_1[0];
    _v_47 = _v_48;
  break;
  }
  o[0] = _v_47;
  return 1;
}

INLINE Term spin_73(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _reverseChanges_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  Term _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  u32 _result_7 = r8;
  Term _result_8 = r9;
  u32 _result_9 = r10;
  Term _result_10 = r11;
  u32 _result_11 = r12;
  Term _result_12 = r13;
  u32 _result_13 = r14;
  Term _result_14 = r15;
  u32 _result_15 = r16;
  Term _result_16 = r17;
  u32 _result_17 = r18;
  u32 _result_18 = r19;
  WL_SPIN
    if (_result_0 == 0) {
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _o_0[1];
      if (spin_74(e, _o_0, _result_10, _result_10 == h11 ? q11 : blk_loc(e.mem, _result_10), _reverseChanges_0, _reverseChanges_0 == h0 ? q0 : blk_loc(e.mem, _reverseChanges_0)) == 0) {
        return 0;
      }
      _v_43 = _o_0[0];
      _v_42 = _v_43;
      _v_21 = 0;
      _v_22 = _result_1;
      _v_23 = _result_2;
      _v_24 = _result_3;
      _v_25 = _result_4;
      _v_26 = _result_5;
      _v_27 = _result_6;
      _v_28 = _result_7;
      _v_29 = _result_8;
      _v_30 = _result_9;
      _v_31 = _v_42;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
    } else {
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _o_2[1];
      if (spin_75(e, _o_2, _reverseChanges_0, _reverseChanges_0 == h0 ? q0 : blk_loc(e.mem, _reverseChanges_0)) == 0) {
        return 0;
      }
      _v_46 = _o_2[0];
      _v_45 = _v_46;
      _v_21 = 1;
      _v_22 = _result_1;
      _v_23 = _result_2;
      _v_24 = _result_3;
      _v_25 = _result_4;
      _v_26 = _result_5;
      _v_27 = _result_6;
      _v_28 = _result_7;
      _v_29 = _result_8;
      _v_30 = _result_9;
      _v_31 = _result_10;
      _v_32 = _result_11;
      _v_33 = _result_12;
      _v_34 = _result_13;
      _v_35 = _result_14;
      _v_36 = _result_15;
      _v_37 = _result_16;
      _v_38 = _result_17;
      _v_39 = _result_18;
      _v_40 = term_pak(CID_NIL, 0);
      _v_41 = _v_45;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_78(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _array_1 = r0;
  WL_SPIN
    Term _at_0 = _array_1 == h0 ? q0 : blk_loc(e.mem, _array_1);
    Term _at_1 = blk_at(_array_1, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_0[5];
    if (spin_70(e, _o_0, _array_1, _array_1 == h0 ? q0 : blk_loc(e.mem, _array_1), _c_0) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_81(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  Term _rows_0 = r0;
  Term _rows_1 = r1;
  Term _rows_2 = r2;
  Term _rows_3 = r3;
  Term _rows_4 = r4;
  Term _rows_5 = r5;
  u32 _rows_6 = r6;
  Term _rows_7 = r7;
  u32 _rows_8 = r8;
  u32 _command_0 = r9;
  u32 _command_1 = r10;
  Term _command_2 = r11;
  Term _command_3 = r12;
  u32 _command_4 = r13;
  Term _command_5 = r14;
  u32 _command_6 = r15;
  Term _command_7 = r16;
  WL_SPIN
    if (_command_0 == 0) {
      Term _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      Term _o_10[10];
      if (spin_71(e, _o_10, _rows_0, _rows_0 == h0 ? q0 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h1 ? q1 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h2 ? q2 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h3 ? q3 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h4 ? q4 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h5 ? q5 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1) == 0) {
        return 0;
      }
      _v_80 = _o_10[0];
      _v_81 = _o_10[1];
      _v_82 = _o_10[2];
      _v_83 = _o_10[3];
      _v_84 = _o_10[4];
      _v_85 = _o_10[5];
      _v_86 = _o_10[6];
      _v_87 = _o_10[7];
      _v_88 = _o_10[8];
      _v_89 = _o_10[9];
      _v_70 = _v_80;
      _v_71 = _v_81;
      _v_72 = _v_82;
      _v_73 = _v_83;
      _v_74 = _v_84;
      _v_75 = _v_85;
      _v_76 = _v_86;
      _v_77 = _v_87;
      _v_78 = _v_88;
      _v_79 = _v_89;
      Term _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      Term _v_95 = 0;
      u32 _v_96 = 0;
      Term _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      Term _v_104 = 0;
      u32 _v_105 = 0;
      Term _v_106 = 0;
      u32 _v_107 = 0;
      Term _o_11[18];
      if (spin_72(e, _o_11, _command_1, _command_2, _command_3, _command_3 == h12 ? q12 : blk_loc(e.mem, _command_3), _command_4, _command_5, _command_5 == h14 ? q14 : blk_loc(e.mem, _command_5), _command_6, _command_7, _command_7 == h16 ? q16 : blk_loc(e.mem, _command_7), _v_70, _v_70 == h16 ? q16 : _v_70 == h14 ? q14 : _v_70 == h12 ? q12 : _v_70 == h11 ? q11 : _v_70 == h5 ? q5 : _v_70 == h4 ? q4 : _v_70 == h3 ? q3 : _v_70 == h2 ? q2 : _v_70 == h1 ? q1 : _v_70 == h0 ? q0 : blk_loc(e.mem, _v_70), _v_71, _v_71 == h16 ? q16 : _v_71 == h14 ? q14 : _v_71 == h12 ? q12 : _v_71 == h11 ? q11 : _v_71 == h5 ? q5 : _v_71 == h4 ? q4 : _v_71 == h3 ? q3 : _v_71 == h2 ? q2 : _v_71 == h1 ? q1 : _v_71 == h0 ? q0 : blk_loc(e.mem, _v_71), _v_72, _v_72 == h16 ? q16 : _v_72 == h14 ? q14 : _v_72 == h12 ? q12 : _v_72 == h11 ? q11 : _v_72 == h5 ? q5 : _v_72 == h4 ? q4 : _v_72 == h3 ? q3 : _v_72 == h2 ? q2 : _v_72 == h1 ? q1 : _v_72 == h0 ? q0 : blk_loc(e.mem, _v_72), _v_73, _v_73 == h16 ? q16 : _v_73 == h14 ? q14 : _v_73 == h12 ? q12 : _v_73 == h11 ? q11 : _v_73 == h5 ? q5 : _v_73 == h4 ? q4 : _v_73 == h3 ? q3 : _v_73 == h2 ? q2 : _v_73 == h1 ? q1 : _v_73 == h0 ? q0 : blk_loc(e.mem, _v_73), _v_74, _v_74 == h16 ? q16 : _v_74 == h14 ? q14 : _v_74 == h12 ? q12 : _v_74 == h11 ? q11 : _v_74 == h5 ? q5 : _v_74 == h4 ? q4 : _v_74 == h3 ? q3 : _v_74 == h2 ? q2 : _v_74 == h1 ? q1 : _v_74 == h0 ? q0 : blk_loc(e.mem, _v_74), _v_75, _v_75 == h16 ? q16 : _v_75 == h14 ? q14 : _v_75 == h12 ? q12 : _v_75 == h11 ? q11 : _v_75 == h5 ? q5 : _v_75 == h4 ? q4 : _v_75 == h3 ? q3 : _v_75 == h2 ? q2 : _v_75 == h1 ? q1 : _v_75 == h0 ? q0 : blk_loc(e.mem, _v_75), _v_76, _v_77, _v_78, _v_79) == 0) {
        return 0;
      }
      _v_90 = _o_11[0];
      _v_91 = _o_11[1];
      _v_92 = _o_11[2];
      _v_93 = _o_11[3];
      _v_94 = _o_11[4];
      _v_95 = _o_11[5];
      _v_96 = _o_11[6];
      _v_97 = _o_11[7];
      _v_98 = _o_11[8];
      _v_99 = _o_11[9];
      _v_100 = _o_11[10];
      _v_101 = _o_11[11];
      _v_102 = _o_11[12];
      _v_103 = _o_11[13];
      _v_104 = _o_11[14];
      _v_105 = _o_11[15];
      _v_106 = _o_11[16];
      _v_107 = _o_11[17];
      _v_52 = _v_90;
      _v_53 = _v_91;
      _v_54 = _v_92;
      _v_55 = _v_93;
      _v_56 = _v_94;
      _v_57 = _v_95;
      _v_58 = _v_96;
      _v_59 = _v_97;
      _v_60 = _v_98;
      _v_61 = _v_99;
      _v_62 = _v_100;
      _v_63 = _v_101;
      _v_64 = _v_102;
      _v_65 = _v_103;
      _v_66 = _v_104;
      _v_67 = _v_105;
      _v_68 = _v_106;
      _v_69 = _v_107;
    } else {
      _v_52 = _rows_0;
      _v_53 = _rows_1;
      _v_54 = _rows_2;
      _v_55 = _rows_3;
      _v_56 = _rows_4;
      _v_57 = _rows_5;
      _v_58 = _rows_6;
      _v_59 = _rows_7;
      _v_60 = _rows_8;
      _v_61 = _command_0;
      _v_62 = _command_1;
      _v_63 = _command_2;
      _v_64 = _command_3;
      _v_65 = _command_4;
      _v_66 = _command_5;
      _v_67 = _command_6;
      _v_68 = _command_7;
      _v_69 = 1;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  return 1;
}

INLINE Term spin_82(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, u32 r19) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  Term _v_122 = 0;
  Term _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  Term _v_126 = 0;
  u32 _v_127 = 0;
  Term _v_128 = 0;
  u32 _v_129 = 0;
  Term _reverse_0 = r0;
  u32 _valid_0 = r1;
  Term _result_0 = r2;
  Term _result_1 = r3;
  Term _result_2 = r4;
  Term _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  Term _result_7 = r9;
  u32 _result_8 = r10;
  u32 _result_9 = r11;
  u32 _result_10 = r12;
  Term _result_11 = r13;
  Term _result_12 = r14;
  u32 _result_13 = r15;
  Term _result_14 = r16;
  u32 _result_15 = r17;
  Term _result_16 = r18;
  u32 _result_17 = r19;
  WL_SPIN
    Term _b_0 = 0;
    if (_result_9 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_11);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_12);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_13);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_14);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_15);
      e.mem[_nd_1 + 6] = rfc_seal(e, _result_16);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_result_9 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_2 + 1] = rfc_seal(e, _result_11);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_result_9 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _result_10);
      e.mem[_nd_3 + 1] = rfc_seal(e, _result_11);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_result_9 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _result_10);
    } else if (_result_9 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _result_10);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _result_10);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _reverse_0);
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _o_13[1];
    if (spin_7(e, _o_13, _valid_0, _result_17) == 0) {
      return 0;
    }
    _v_131 = _o_13[0];
    _v_130 = _v_131;
    _v_119 = _result_0;
    _v_120 = _result_1;
    _v_121 = _result_2;
    _v_122 = _result_3;
    _v_123 = _result_4;
    _v_124 = _result_5;
    _v_125 = _result_6;
    _v_126 = _result_7;
    _v_127 = _result_8;
    _v_128 = term_ctr(CID_CON, _nd_4);
    _v_129 = _v_130;
  break;
  }
  o[0] = _v_119;
  o[1] = _v_120;
  o[2] = _v_121;
  o[3] = _v_122;
  o[4] = _v_123;
  o[5] = _v_124;
  o[6] = _v_125;
  o[7] = _v_126;
  o[8] = _v_127;
  o[9] = _v_128;
  o[10] = _v_129;
  return 1;
}

INLINE Term spin_83(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  u32 _state_21 = r0;
  Term _state_22 = r1;
  Term _state_23 = r2;
  Term _state_24 = r3;
  Term _state_25 = r4;
  Term _state_26 = r5;
  Term _state_27 = r6;
  u32 _state_28 = r7;
  Term _state_29 = r8;
  u32 _state_30 = r9;
  Term _state_31 = r10;
  u32 _state_32 = r11;
  Term _state_33 = r12;
  u32 _state_34 = r13;
  Term _state_35 = r14;
  u32 _state_36 = r15;
  Term _state_37 = r16;
  u32 _state_38 = r17;
  u32 _state_39 = r18;
  Term _state_40 = r19;
  Term _state_41 = r20;
  WL_SPIN
    if (_state_21 == 0) {
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _o_0[1];
      if (spin_75(e, _o_0, _state_31, _state_31 == h10 ? q10 : blk_loc(e.mem, _state_31)) == 0) {
        return 0;
      }
      _v_43 = _o_0[0];
      _v_42 = _v_43;
      _v_21 = 0;
      _v_22 = _state_22;
      _v_23 = _state_23;
      _v_24 = _state_24;
      _v_25 = _state_25;
      _v_26 = _state_26;
      _v_27 = _state_27;
      _v_28 = _state_28;
      _v_29 = _state_29;
      _v_30 = _state_30;
      _v_31 = _v_42;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
    } else {
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_1[1];
      if (spin_27(e, _o_1, _state_40, _state_40 == h19 ? q19 : blk_loc(e.mem, _state_40)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_44 = _v_45;
      _v_21 = 1;
      _v_22 = _state_22;
      _v_23 = _state_23;
      _v_24 = _state_24;
      _v_25 = _state_25;
      _v_26 = _state_26;
      _v_27 = _state_27;
      _v_28 = _state_28;
      _v_29 = _state_29;
      _v_30 = _state_30;
      _v_31 = _state_31;
      _v_32 = _state_32;
      _v_33 = _state_33;
      _v_34 = _state_34;
      _v_35 = _state_35;
      _v_36 = _state_36;
      _v_37 = _state_37;
      _v_38 = _state_38;
      _v_39 = _state_39;
      _v_40 = _v_44;
      _v_41 = _state_41;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_86(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_4 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_4 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_86);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_85(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_86(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_87(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _array_0 = r0;
  WL_SPIN
    Term _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[5];
    if (spin_78(e, _o_0, _array_0, _array_0 == h0 ? q0 : blk_loc(e.mem, _array_0)) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_88(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _reserve_0 = r0;
  u32 _class_0 = r1;
  Term _result_0 = r2;
  u32 _result_1 = r3;
  u32 _result_2 = r4;
  u32 _result_3 = r5;
  u32 _result_4 = r6;
  WL_SPIN
    _v_29 = _result_0;
    _v_30 = _reserve_0;
    _v_31 = _class_0;
    _v_32 = _result_1;
    _v_33 = _result_2;
    _v_34 = _result_3;
    _v_35 = _result_4;
    _v_36 = _reserve_0;
    _v_37 = _class_0;
  break;
  }
  o[0] = _v_29;
  o[1] = _v_30;
  o[2] = _v_31;
  o[3] = _v_32;
  o[4] = _v_33;
  o[5] = _v_34;
  o[6] = _v_35;
  o[7] = _v_36;
  o[8] = _v_37;
  return 1;
}

INLINE Term spin_91(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_26 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_26 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_91);
    }
  break;
  }
  o[0] = _v_26;
  return 1;
}

INLINE Term spin_90(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_24 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_25 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_91(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_25 = _o_0[0];
    _v_24 = _v_25;
  break;
  }
  o[0] = _v_24;
  return 1;
}

INLINE Term spin_89(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _commands_1 = r0;
  Term _state_0 = r1;
  Term _state_1 = r2;
  Term _state_2 = r3;
  Term _state_3 = r4;
  Term _state_4 = r5;
  Term _state_5 = r6;
  u32 _state_6 = r7;
  Term _state_7 = r8;
  u32 _state_8 = r9;
  Term _state_9 = r10;
  u32 _state_10 = r11;
  WL_SPIN
    if (term_aux(_commands_1) == CID_NIL) {
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _o_1[1];
      if (spin_90(e, _o_1, _state_9, _state_9 == h10 ? q10 : blk_loc(e.mem, _state_9)) == 0) {
        return 0;
      }
      _v_23 = _o_1[0];
      _v_22 = _v_23;
      _v_11 = _state_0;
      _v_12 = _state_1;
      _v_13 = _state_2;
      _v_14 = _state_3;
      _v_15 = _state_4;
      _v_16 = _state_5;
      _v_17 = _state_6;
      _v_18 = _state_7;
      _v_19 = _state_8;
      _v_20 = _v_22;
      _v_21 = _state_10;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _commands_1, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      u32 _o_6 = 0;
      Term _o_7 = 0;
      u32 _o_8 = 0;
      Term _o_9 = 0;
      if (term_aux(_f_2) == CID_STORAGE_SPAWN) {
        _o_2 = 0;
        Term _fb_2[7];
        u64 _sp_2 = ctr_take(e, _f_2, 7, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        Term _f_8 = _fb_2[4];
        u32 _f_9 = _fb_2[5];
        Term _f_10 = _fb_2[6];
        spare_free(e, cls_fit(7), _sp_2);
        _o_3 = _f_4;
        _o_4 = _f_5;
        _o_5 = _f_6;
        _o_6 = _f_7;
        _o_7 = _f_8;
        _o_8 = _f_9;
        _o_9 = _f_10;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTMAIN) {
        _o_2 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_2, 2, _fb_3);
        u32 _f_11 = _fb_3[0];
        Term _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_3 = _f_11;
        _o_4 = _f_12;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTFLAG) {
        _o_2 = 2;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_2, 2, _fb_4);
        u32 _f_13 = _fb_4[0];
        Term _f_14 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        _o_3 = _f_13;
        _o_4 = _f_14;
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEMAIN) {
        _o_2 = 3;
        _o_3 = term_loc(_f_2);
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEFLAG) {
        _o_2 = 4;
        _o_3 = term_loc(_f_2);
      } else {
        _o_2 = 5;
        _o_3 = term_loc(_f_2);
      }
      Term _v_27 = 0;
      Term _v_28 = 0;
      Term _v_29 = 0;
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      u32 _v_33 = 0;
      Term _v_34 = 0;
      u32 _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      u32 _v_51 = 0;
      Term _v_52 = 0;
      u32 _v_53 = 0;
      Term _v_54 = 0;
      u32 _v_55 = 0;
      Term _v_56 = 0;
      Term _v_57 = 0;
      Term _v_58 = 0;
      Term _v_59 = 0;
      Term _v_60 = 0;
      Term _v_61 = 0;
      u32 _v_62 = 0;
      Term _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      u32 _v_69 = 0;
      Term _v_70 = 0;
      u32 _v_71 = 0;
      Term _v_72 = 0;
      u32 _v_73 = 0;
      Term _o_10[18];
      if (spin_81(e, _o_10, _state_0, _state_0 == h1 ? q1 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h2 ? q2 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h3 ? q3 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h4 ? q4 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h5 ? q5 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h6 ? q6 : blk_loc(e.mem, _state_5), _state_6, _state_7, _state_8, _o_2, _o_3, _o_4, _o_4 == h10 ? q10 : _o_4 == h6 ? q6 : _o_4 == h5 ? q5 : _o_4 == h4 ? q4 : _o_4 == h3 ? q3 : _o_4 == h2 ? q2 : _o_4 == h1 ? q1 : _o_4 == h0 ? q0 : blk_loc(e.mem, _o_4), _o_5, _o_5 == h10 ? q10 : _o_5 == h6 ? q6 : _o_5 == h5 ? q5 : _o_5 == h4 ? q4 : _o_5 == h3 ? q3 : _o_5 == h2 ? q2 : _o_5 == h1 ? q1 : _o_5 == h0 ? q0 : blk_loc(e.mem, _o_5), _o_6, _o_7, _o_7 == h10 ? q10 : _o_7 == h6 ? q6 : _o_7 == h5 ? q5 : _o_7 == h4 ? q4 : _o_7 == h3 ? q3 : _o_7 == h2 ? q2 : _o_7 == h1 ? q1 : _o_7 == h0 ? q0 : blk_loc(e.mem, _o_7), _o_8, _o_9, _o_9 == h10 ? q10 : _o_9 == h6 ? q6 : _o_9 == h5 ? q5 : _o_9 == h4 ? q4 : _o_9 == h3 ? q3 : _o_9 == h2 ? q2 : _o_9 == h1 ? q1 : _o_9 == h0 ? q0 : blk_loc(e.mem, _o_9)) == 0) {
        return 0;
      }
      _v_56 = _o_10[0];
      _v_57 = _o_10[1];
      _v_58 = _o_10[2];
      _v_59 = _o_10[3];
      _v_60 = _o_10[4];
      _v_61 = _o_10[5];
      _v_62 = _o_10[6];
      _v_63 = _o_10[7];
      _v_64 = _o_10[8];
      _v_65 = _o_10[9];
      _v_66 = _o_10[10];
      _v_67 = _o_10[11];
      _v_68 = _o_10[12];
      _v_69 = _o_10[13];
      _v_70 = _o_10[14];
      _v_71 = _o_10[15];
      _v_72 = _o_10[16];
      _v_73 = _o_10[17];
      _v_38 = _v_56;
      _v_39 = _v_57;
      _v_40 = _v_58;
      _v_41 = _v_59;
      _v_42 = _v_60;
      _v_43 = _v_61;
      _v_44 = _v_62;
      _v_45 = _v_63;
      _v_46 = _v_64;
      _v_47 = _v_65;
      _v_48 = _v_66;
      _v_49 = _v_67;
      _v_50 = _v_68;
      _v_51 = _v_69;
      _v_52 = _v_70;
      _v_53 = _v_71;
      _v_54 = _v_72;
      _v_55 = _v_73;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      Term _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      Term _o_11[11];
      if (spin_82(e, _o_11, _state_9, _state_9 == h10 ? q10 : blk_loc(e.mem, _state_9), _state_10, _v_38, _v_38 == h10 ? q10 : _v_38 == h6 ? q6 : _v_38 == h5 ? q5 : _v_38 == h4 ? q4 : _v_38 == h3 ? q3 : _v_38 == h2 ? q2 : _v_38 == h1 ? q1 : _v_38 == h0 ? q0 : blk_loc(e.mem, _v_38), _v_39, _v_39 == h10 ? q10 : _v_39 == h6 ? q6 : _v_39 == h5 ? q5 : _v_39 == h4 ? q4 : _v_39 == h3 ? q3 : _v_39 == h2 ? q2 : _v_39 == h1 ? q1 : _v_39 == h0 ? q0 : blk_loc(e.mem, _v_39), _v_40, _v_40 == h10 ? q10 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : _v_40 == h0 ? q0 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h10 ? q10 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : _v_41 == h0 ? q0 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h10 ? q10 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : _v_42 == h0 ? q0 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h10 ? q10 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : _v_43 == h0 ? q0 : blk_loc(e.mem, _v_43), _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_49 == h10 ? q10 : _v_49 == h6 ? q6 : _v_49 == h5 ? q5 : _v_49 == h4 ? q4 : _v_49 == h3 ? q3 : _v_49 == h2 ? q2 : _v_49 == h1 ? q1 : _v_49 == h0 ? q0 : blk_loc(e.mem, _v_49), _v_50, _v_50 == h10 ? q10 : _v_50 == h6 ? q6 : _v_50 == h5 ? q5 : _v_50 == h4 ? q4 : _v_50 == h3 ? q3 : _v_50 == h2 ? q2 : _v_50 == h1 ? q1 : _v_50 == h0 ? q0 : blk_loc(e.mem, _v_50), _v_51, _v_52, _v_52 == h10 ? q10 : _v_52 == h6 ? q6 : _v_52 == h5 ? q5 : _v_52 == h4 ? q4 : _v_52 == h3 ? q3 : _v_52 == h2 ? q2 : _v_52 == h1 ? q1 : _v_52 == h0 ? q0 : blk_loc(e.mem, _v_52), _v_53, _v_54, _v_54 == h10 ? q10 : _v_54 == h6 ? q6 : _v_54 == h5 ? q5 : _v_54 == h4 ? q4 : _v_54 == h3 ? q3 : _v_54 == h2 ? q2 : _v_54 == h1 ? q1 : _v_54 == h0 ? q0 : blk_loc(e.mem, _v_54), _v_55) == 0) {
        return 0;
      }
      _v_74 = _o_11[0];
      _v_75 = _o_11[1];
      _v_76 = _o_11[2];
      _v_77 = _o_11[3];
      _v_78 = _o_11[4];
      _v_79 = _o_11[5];
      _v_80 = _o_11[6];
      _v_81 = _o_11[7];
      _v_82 = _o_11[8];
      _v_83 = _o_11[9];
      _v_84 = _o_11[10];
      _v_27 = _v_74;
      _v_28 = _v_75;
      _v_29 = _v_76;
      _v_30 = _v_77;
      _v_31 = _v_78;
      _v_32 = _v_79;
      _v_33 = _v_80;
      _v_34 = _v_81;
      _v_35 = _v_82;
      _v_36 = _v_83;
      _v_37 = _v_84;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _v_27;
      r2 = _v_28;
      r3 = _v_29;
      r4 = _v_30;
      r5 = _v_31;
      r6 = _v_32;
      r7 = _v_33;
      r8 = _v_34;
      r9 = _v_35;
      r10 = _v_36;
      r11 = _v_37;
      _commands_1 = r0;
      _state_0 = r1;
      _state_1 = r2;
      _state_2 = r3;
      _state_3 = r4;
      _state_4 = r5;
      _state_5 = r6;
      _state_6 = r7;
      _state_7 = r8;
      _state_8 = r9;
      _state_9 = r10;
      _state_10 = r11;
      WL_AGAIN(spin_89);
    }
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_92(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, Term r19, u64 q19, u32 r20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term h19 = r19;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _v_45 = 0;
  Term _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  u32 _ledger_4 = r2;
  Term _ledger_5 = r3;
  Term _mode_2 = r4;
  u32 _result_11 = r5;
  Term _result_12 = r6;
  Term _result_13 = r7;
  Term _result_14 = r8;
  Term _result_15 = r9;
  Term _result_16 = r10;
  Term _result_17 = r11;
  u32 _result_18 = r12;
  Term _result_19 = r13;
  u32 _result_20 = r14;
  Term _result_21 = r15;
  u32 _result_22 = r16;
  Term _result_23 = r17;
  u32 _result_24 = r18;
  Term _result_25 = r19;
  u32 _result_26 = r20;
  Term _result_27 = r21;
  u32 _result_28 = r22;
  u32 _result_29 = r23;
  Term _result_30 = r24;
  Term _result_31 = r25;
  WL_SPIN
    if (_result_11 == 0) {
      _v_28 = 0;
      _v_29 = _namespace_2;
      _v_30 = _next_2;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
      _v_38 = _result_19;
      _v_39 = _result_20;
      _v_40 = term_pak(CID_NIL, 0);
      _v_41 = _ledger_4;
      _v_42 = _ledger_5;
      _v_43 = _mode_2;
      _v_44 = _result_21;
      _v_45 = 0;
      _v_46 = 0;
      _v_47 = 0;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
      _v_52 = 0;
      _v_53 = 0;
    } else {
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _o_1[1];
      if (spin_27(e, _o_1, _result_30, _result_30 == h24 ? q24 : blk_loc(e.mem, _result_30)) == 0) {
        return 0;
      }
      _v_55 = _o_1[0];
      _v_54 = _v_55;
      _v_28 = 2;
      _v_29 = _namespace_2;
      _v_30 = _next_2;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = _result_18;
      _v_38 = _result_19;
      _v_39 = _result_20;
      _v_40 = _v_54;
      _v_41 = _ledger_4;
      _v_42 = _ledger_5;
      _v_43 = _mode_2;
      _v_44 = _result_21;
      _v_45 = _result_22;
      _v_46 = _result_23;
      _v_47 = _result_24;
      _v_48 = _result_25;
      _v_49 = _result_26;
      _v_50 = _result_27;
      _v_51 = _result_28;
      _v_52 = _result_29;
      _v_53 = _result_31;
    }
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  o[14] = _v_42;
  o[15] = _v_43;
  o[16] = _v_44;
  o[17] = _v_45;
  o[18] = _v_46;
  o[19] = _v_47;
  o[20] = _v_48;
  o[21] = _v_49;
  o[22] = _v_50;
  o[23] = _v_51;
  o[24] = _v_52;
  o[25] = _v_53;
  return 1;
}

INLINE Term spin_93(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _t_2 = r0;
  Term _t_3 = r1;
  Term _t_4 = r2;
  Term _t_5 = r3;
  Term _t_6 = r4;
  Term _t_7 = r5;
  Term _command_0 = r6;
  WL_SPIN
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _command_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _t_5);
    _v_12 = _t_2;
    _v_13 = _t_3;
    _v_14 = _t_4;
    _v_15 = term_ctr(CID_CON, _nd_4);
    _v_16 = _t_6;
    _v_17 = _t_7;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_96(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_8 = 0;
  Term _xs_2 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_2) == CID_NIL) {
      _v_8 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_2, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_2 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_96);
    }
  break;
  }
  o[0] = _v_8;
  return 1;
}

INLINE Term spin_95(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_6 = 0;
  Term _xs_1 = r0;
  WL_SPIN
    Term _v_7 = 0;
    Term _o_2[1];
    Term _a_1 = term_pak(CID_NIL, 0);
    if (spin_96(e, _o_2, _xs_1, _xs_1 == h0 ? q0 : blk_loc(e.mem, _xs_1), _a_1, _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_7 = _o_2[0];
    _v_6 = _v_7;
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_97(Env e, THR Term* o, Term r0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_1 = 0;
  Term _n_0 = r0;
  u32 _i_0 = r1;
  Term _owner_0 = r2;
  u32 _seed_2 = r3;
  WL_SPIN
    if (_n_0 == 0) {
      _v_1 = _owner_0;
    } else {
      Term _tail_0 = (_n_0 - 1);
      Term _at_0 = _owner_0 == h2 ? q2 : blk_loc(e.mem, _owner_0);
      Term _at_1 = blk_at(_owner_0, _i_0, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      blk_write(e.mem, 0, _at_0, _at_1 + 0, U32_BIN(_seed_2, +, _i_0));
      r0 = _tail_0;
      r1 = U32_BIN(_i_0, +, 1ull);
      r2 = _owner_0;
      r3 = _seed_2;
      _n_0 = r0;
      _i_0 = r1;
      _owner_0 = r2;
      _seed_2 = r3;
      WL_AGAIN(spin_97);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_98(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _owner_0 = r0;
  u32 _owner_1 = r1;
  u32 _owner_2 = r2;
  WL_SPIN
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    Term _o_0[5];
    if (spin_87(e, _o_0, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0)) == 0) {
      return 0;
    }
    _v_32 = _o_0[0];
    _v_33 = _o_0[1];
    _v_34 = _o_0[2];
    _v_35 = _o_0[3];
    _v_36 = _o_0[4];
    _v_27 = _v_32;
    _v_28 = _v_33;
    _v_29 = _v_34;
    _v_30 = _v_35;
    _v_31 = _v_36;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    Term _o_1[9];
    if (spin_88(e, _o_1, _owner_1, _owner_2, _v_27, _v_27 == h0 ? q0 : blk_loc(e.mem, _v_27), _v_28, _v_29, _v_30, _v_31) == 0) {
      return 0;
    }
    _v_37 = _o_1[0];
    _v_38 = _o_1[1];
    _v_39 = _o_1[2];
    _v_40 = _o_1[3];
    _v_41 = _o_1[4];
    _v_42 = _o_1[5];
    _v_43 = _o_1[6];
    _v_44 = _o_1[7];
    _v_45 = _o_1[8];
    _v_18 = _v_37;
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_99(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  WL_SPIN
    _v_55 = _result_0;
    _v_56 = _result_1;
    _v_57 = _result_2;
    _v_58 = _result_3;
    _v_59 = _result_4;
    _v_60 = _result_5;
    _v_61 = _result_6;
    _v_62 = _result_7;
    _v_63 = _result_8;
  break;
  }
  o[0] = _v_55;
  o[1] = _v_56;
  o[2] = _v_57;
  o[3] = _v_58;
  o[4] = _v_59;
  o[5] = _v_60;
  o[6] = _v_61;
  o[7] = _v_62;
  o[8] = _v_63;
  return 1;
}

INLINE Term spin_100(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _commands_0 = r0;
  Term _rows_0 = r1;
  Term _rows_1 = r2;
  Term _rows_2 = r3;
  Term _rows_3 = r4;
  Term _rows_4 = r5;
  Term _rows_5 = r6;
  u32 _rows_6 = r7;
  Term _rows_7 = r8;
  u32 _rows_8 = r9;
  WL_SPIN
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _o_0[11];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_89(e, _o_0, _commands_0, _commands_0 == h0 ? q0 : blk_loc(e.mem, _commands_0), _rows_0, _rows_0 == h1 ? q1 : blk_loc(e.mem, _rows_0), _rows_1, _rows_1 == h2 ? q2 : blk_loc(e.mem, _rows_1), _rows_2, _rows_2 == h3 ? q3 : blk_loc(e.mem, _rows_2), _rows_3, _rows_3 == h4 ? q4 : blk_loc(e.mem, _rows_3), _rows_4, _rows_4 == h5 ? q5 : blk_loc(e.mem, _rows_4), _rows_5, _rows_5 == h6 ? q6 : blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _a_0, _a_0 == h6 ? q6 : _a_0 == h5 ? q5 : _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), 1) == 0) {
      return 0;
    }
    _v_33 = _o_0[0];
    _v_34 = _o_0[1];
    _v_35 = _o_0[2];
    _v_36 = _o_0[3];
    _v_37 = _o_0[4];
    _v_38 = _o_0[5];
    _v_39 = _o_0[6];
    _v_40 = _o_0[7];
    _v_41 = _o_0[8];
    _v_42 = _o_0[9];
    _v_43 = _o_0[10];
    _v_22 = _v_33;
    _v_23 = _v_34;
    _v_24 = _v_35;
    _v_25 = _v_36;
    _v_26 = _v_37;
    _v_27 = _v_38;
    _v_28 = _v_39;
    _v_29 = _v_40;
    _v_30 = _v_41;
    _v_31 = _v_42;
    _v_32 = _v_43;
  break;
  }
  o[0] = _v_22;
  o[1] = _v_23;
  o[2] = _v_24;
  o[3] = _v_25;
  o[4] = _v_26;
  o[5] = _v_27;
  o[6] = _v_28;
  o[7] = _v_29;
  o[8] = _v_30;
  o[9] = _v_31;
  o[10] = _v_32;
  return 1;
}

INLINE Term spin_102(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  Term _v_65 = 0;
  Term _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  WL_SPIN
    if (_available_0 == 0) {
      _v_60 = 1;
      _v_61 = _namespace_0;
      _v_62 = 0;
      _v_63 = 0;
      _v_64 = 0;
      _v_65 = 0;
      _v_66 = 0;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
      _v_70 = 0;
      _v_71 = 0;
      _v_72 = 0;
      _v_73 = 0;
      _v_74 = 0;
    } else {
      Term _fv_0[2];
      _fv_0[0] = 0;
      _fv_0[1] = 0;
      Term _fv_1[2];
      _fv_1[0] = 0;
      _fv_1[1] = 0;
      Term _fv_2[1];
      _fv_2[0] = 0;
      Term _fv_3[2];
      _fv_3[0] = 0;
      _fv_3[1] = 0;
      Term _fv_4[1];
      _fv_4[0] = 0ull;
      Term _fv_5[1];
      _fv_5[0] = 0ull;
      _v_60 = 0;
      _v_61 = U32_BIN(_namespace_0, +, 1ull);
      _v_62 = _namespace_0;
      _v_63 = 1ull;
      _v_64 = blk_new(e, 1, 0, 1, 2, _fv_0);
      _v_65 = blk_new(e, 1, 0, 1, 2, _fv_1);
      _v_66 = blk_new(e, 0, 0, 0, 1, _fv_2);
      _v_67 = blk_new(e, 1, 0, 1, 2, _fv_3);
      _v_68 = blk_new(e, 0, 0, 0, 1, _fv_4);
      _v_69 = blk_new(e, 0, 0, 0, 1, _fv_5);
      _v_70 = 1ull;
      _v_71 = 0;
      _v_72 = 0ull;
      _v_73 = term_pak(CID_NIL, 0);
      _v_74 = 1;
    }
  break;
  }
  o[0] = _v_60;
  o[1] = _v_61;
  o[2] = _v_62;
  o[3] = _v_63;
  o[4] = _v_64;
  o[5] = _v_65;
  o[6] = _v_66;
  o[7] = _v_67;
  o[8] = _v_68;
  o[9] = _v_69;
  o[10] = _v_70;
  o[11] = _v_71;
  o[12] = _v_72;
  o[13] = _v_73;
  o[14] = _v_74;
  return 1;
}

INLINE Term spin_101(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _factory_1 = r0;
  WL_SPIN
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_0[15];
    if (spin_102(e, _o_0, U32_BIN(_factory_1, <, 4294967295ull), _factory_1) == 0) {
      return 0;
    }
    _v_45 = _o_0[0];
    _v_46 = _o_0[1];
    _v_47 = _o_0[2];
    _v_48 = _o_0[3];
    _v_49 = _o_0[4];
    _v_50 = _o_0[5];
    _v_51 = _o_0[6];
    _v_52 = _o_0[7];
    _v_53 = _o_0[8];
    _v_54 = _o_0[9];
    _v_55 = _o_0[10];
    _v_56 = _o_0[11];
    _v_57 = _o_0[12];
    _v_58 = _o_0[13];
    _v_59 = _o_0[14];
    _v_30 = _v_45;
    _v_31 = _v_46;
    _v_32 = _v_47;
    _v_33 = _v_48;
    _v_34 = _v_49;
    _v_35 = _v_50;
    _v_36 = _v_51;
    _v_37 = _v_52;
    _v_38 = _v_53;
    _v_39 = _v_54;
    _v_40 = _v_55;
    _v_41 = _v_56;
    _v_42 = _v_57;
    _v_43 = _v_58;
    _v_44 = _v_59;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  return 1;
}

INLINE Term spin_104(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _world_0 = r0;
  Term _selected_0 = r1;
  WL_SPIN
    _v_12 = _world_0;
    _v_13 = _selected_0;
    _v_14 = term_pak(CID_NIL, 0);
    _v_15 = term_pak(CID_NIL, 0);
    _v_16 = term_pak(CID_NIL, 0);
    _v_17 = term_pak(CID_NIL, 0);
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_105(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _t_2 = r0;
  Term _t_3 = r1;
  Term _t_4 = r2;
  Term _t_5 = r3;
  Term _t_6 = r4;
  Term _t_7 = r5;
  u32 _code_0 = r6;
  WL_SPIN
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _code_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _t_6);
    _v_41 = _t_2;
    _v_42 = _t_3;
    _v_43 = _t_4;
    _v_44 = _t_5;
    _v_45 = term_ctr(CID_CON, _nd_4);
    _v_46 = _t_7;
  break;
  }
  o[0] = _v_41;
  o[1] = _v_42;
  o[2] = _v_43;
  o[3] = _v_44;
  o[4] = _v_45;
  o[5] = _v_46;
  return 1;
}

INLINE Term spin_106(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  u32 _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _t_8 = r0;
  Term _t_9 = r1;
  Term _t_10 = r2;
  Term _t_11 = r3;
  Term _t_12 = r4;
  Term _t_13 = r5;
  WL_SPIN
    term_sink(e, _t_9);
    term_sink(e, _t_10);
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _o_8[1];
    if (spin_85(e, _o_8, _t_11, _t_11 == h3 ? q3 : blk_loc(e.mem, _t_11)) == 0) {
      return 0;
    }
    _v_64 = _o_8[0];
    _v_63 = _v_64;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _o_9[1];
    if (spin_95(e, _o_9, _t_12, _t_12 == h4 ? q4 : blk_loc(e.mem, _t_12)) == 0) {
      return 0;
    }
    _v_66 = _o_9[0];
    _v_65 = _v_66;
    _v_58 = 0;
    _v_59 = _t_8;
    _v_60 = _v_63;
    _v_61 = _v_65;
    _v_62 = _t_13;
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  return 1;
}

INLINE Term spin_107(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _raw_0 = r0;
  u32 _raw_1 = r1;
  u32 _raw_2 = r2;
  WL_SPIN
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_0[9];
    if (spin_98(e, _o_0, _raw_0, _raw_0 == h0 ? q0 : blk_loc(e.mem, _raw_0), _raw_1, _raw_2) == 0) {
      return 0;
    }
    _v_27 = _o_0[0];
    _v_28 = _o_0[1];
    _v_29 = _o_0[2];
    _v_30 = _o_0[3];
    _v_31 = _o_0[4];
    _v_32 = _o_0[5];
    _v_33 = _o_0[6];
    _v_34 = _o_0[7];
    _v_35 = _o_0[8];
    _v_18 = _v_27;
    _v_19 = _v_28;
    _v_20 = _v_29;
    _v_21 = _v_30;
    _v_22 = _v_31;
    _v_23 = _v_32;
    _v_24 = _v_33;
    _v_25 = _v_34;
    _v_26 = _v_35;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _o_1[9];
    if (spin_99(e, _o_1, _v_18, _v_18 == h0 ? q0 : blk_loc(e.mem, _v_18), _v_19, _v_20, _v_21, _v_22, _v_23, _v_24, _v_25, _v_26) == 0) {
      return 0;
    }
    _v_36 = _o_1[0];
    _v_37 = _o_1[1];
    _v_38 = _o_1[2];
    _v_39 = _o_1[3];
    _v_40 = _o_1[4];
    _v_41 = _o_1[5];
    _v_42 = _o_1[6];
    _v_43 = _o_1[7];
    _v_44 = _o_1[8];
    _v_9 = _v_36;
    _v_10 = _v_37;
    _v_11 = _v_38;
    _v_12 = _v_39;
    _v_13 = _v_40;
    _v_14 = _v_41;
    _v_15 = _v_42;
    _v_16 = _v_43;
    _v_17 = _v_44;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_STRING_CMP)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      if (term_aux(_b_0) == CID_SNIL) {
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 1;
        WL_RETN(3);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _b_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_ctr(CID_SCON, _nd_0);
        r2 = 0;
        WL_RETN(3);
      }
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _a_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      if (term_aux(_b_0) == CID_SNIL) {
        u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
        r0 = term_ctr(CID_SCON, _nd_1);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 2;
        WL_RETN(3);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _b_0, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        u32 _v_0 = 0;
        u32 _v_1 = 0;
        u32 _v_2 = 0;
        u32 _v_3 = 0;
        u32 _v_4 = 0;
        u32 _v_5 = 0;
        Term _o_0[3];
        if (spin_1(e, _o_0, _f_2, _f_4) == 0) {
          return 0;
        }
        _v_3 = _o_0[0];
        _v_4 = _o_0[1];
        _v_5 = _o_0[2];
        _v_0 = _v_3;
        _v_1 = _v_4;
        _v_2 = _v_5;
        if (_v_2 == 0) {
          u64 _nd_2 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_2 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_2 + 1] = rfc_seal(e, _f_3);
          u64 _nd_3 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_3 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_2);
          r1 = term_ctr(CID_SCON, _nd_3);
          r2 = 0;
          WL_RETN(3);
        } else if (_v_2 == 1) {
          spare_free(e, cls_fit(2), _sp_2);
          spare_free(e, cls_fit(2), _sp_1);
          if (seq) {
            WL_ROOM(3);
            STK(0) = _v_0;
            STK(1) = _v_1;
            STK(2) = FID_STRING_CMP_K5;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_STRING_CMP_K5, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_0;
            e.mem[_t_0 + 1] = _v_1;
            WL_CONT = term_tsk(FID_STRING_CMP_K5, _t_0);
            WL_IDX = 2;
          }
          r0 = _f_3;
          r1 = _f_5;
          _a_0 = r0;
          _b_0 = r1;
          WL_AGAIN(FID_STRING_CMP);
        } else {
          u64 _nd_4 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_4 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_4 + 1] = rfc_seal(e, _f_3);
          u64 _nd_5 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_5 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_5 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_4);
          r1 = term_ctr(CID_SCON, _nd_5);
          r2 = 2;
          WL_RETN(3);
        }
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP_K5)
  {
    WL_POPN(2);
    u32 _v_9 = STK(0);
    u32 _v_10 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_1[3];
    if (spin_0(e, _o_1, _v_9, _v_10, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    r0 = _v_11;
    r1 = _v_12;
    r2 = _v_13;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_ORDER_K10;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_ORDER_K10, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_ORDER_K10, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_CMP)) {
      u64 _t_1 = task_node(e, FID_STRING_CMP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_CMP, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_CMP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER_K10)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    Term _b_1 = 0;
    if (_h_2 == 0) {
      _b_1 = term_pak(CID_LT, 0);
    } else if (_h_2 == 1) {
      _b_1 = term_pak(CID_EQ, 0);
    } else {
      _b_1 = term_pak(CID_GT, 0);
    }
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_1 = term_ctr(CID_TUPLE, _nd_0);
    if (spin_2(e, _o_0, _a_1, blk_loc(e.mem, _a_1), _b_1, blk_loc(e.mem, _b_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    u32 _o_1 = 0;
    if (term_aux(_v_0) == CID_LT) {
      _o_1 = 0;
    } else if (term_aux(_v_0) == CID_EQ) {
      _o_1 = 1;
    } else {
      _o_1 = 2;
    }
    r0 = _o_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_EQ_K16;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_EQ_K16, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_EQ_K16, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_ORDER)) {
      u64 _t_1 = task_node(e, FID_STRING_ORDER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_ORDER, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_ORDER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ_K16)
  {
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_3(e, _o_0, _h_0) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _transform_0 = r17;
    WL_OPEN
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _transform_0);
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = 2;
      r16 = 0;
      WL_RETN(17);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _o_0[1];
      if (spin_7(e, _o_0, U32_BIN(_handle_1, <=, _world_8), U32_BIN(_handle_1, <=, _world_10)) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
      u32 _v_3 = 0;
      Term _o_1[1];
      if (spin_7(e, _o_1, U32_BIN(0ull, <, _handle_1), _v_1) == 0) {
        return 0;
      }
      _v_3 = _o_1[0];
      _v_0 = _v_3;
      if (_v_0 == 0) {
        term_sink(e, _transform_0);
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = 2;
        r16 = 0;
        WL_RETN(17);
      } else {
        u32 _index_0 = U32_BIN(_handle_1, -, 1ull);
        Term _at_0 = blk_loc(e.mem, _world_4);
        Term _at_1 = blk_at(_world_4, _index_0, 0);
        u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
        if (_c_0 == 0) {
          term_sink(e, _transform_0);
          r0 = _world_0;
          r1 = _world_1;
          r2 = _world_2;
          r3 = _world_3;
          r4 = _world_4;
          r5 = _world_5;
          r6 = _world_6;
          r7 = _world_7;
          r8 = _world_8;
          r9 = _world_9;
          r10 = _world_10;
          r11 = _world_11;
          r12 = _world_12;
          r13 = _world_13;
          r14 = _world_14;
          r15 = 2;
          r16 = 0;
          WL_RETN(17);
        } else {
          Term _at_2 = blk_loc(e.mem, _world_2);
          Term _at_3 = blk_at(_world_2, _index_0, 1);
          u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
          Term _c_2 = e.mem[_at_2 + _at_3 + 1];
          blk_write(e.mem, 1, _at_2, _at_3 + 0, 0);
          blk_write(e.mem, 1, _at_2, _at_3 + 1, 0);
          if (_c_1 == 0) {
            term_sink(e, _transform_0);
            r0 = _world_0;
            r1 = _world_1;
            r2 = _world_2;
            r3 = _world_3;
            r4 = _world_4;
            r5 = _world_5;
            r6 = _world_6;
            r7 = _world_7;
            r8 = _world_8;
            r9 = _world_9;
            r10 = _world_10;
            r11 = _world_11;
            r12 = _world_12;
            r13 = _world_13;
            r14 = _world_14;
            r15 = 1;
            r16 = 0;
            WL_RETN(17);
          } else {
            if (seq) {
              WL_ROOM(17);
              STK(0) = _world_0;
              STK(1) = _world_1;
              STK(2) = _world_3;
              STK(3) = _world_4;
              STK(4) = _world_5;
              STK(5) = _world_6;
              STK(6) = _world_7;
              STK(7) = _world_8;
              STK(8) = _world_9;
              STK(9) = _world_10;
              STK(10) = _world_11;
              STK(11) = _world_12;
              STK(12) = _world_13;
              STK(13) = _world_14;
              STK(14) = _index_0;
              STK(15) = _world_2;
              STK(16) = FID_STORAGE_WITH_MAIN_K189;
              WL_PUSHN(17);
            } else {
              u64 _t_0 = task_node(e, FID_STORAGE_WITH_MAIN_K189, WL_CONT, WL_IDX, 1);
              e.mem[_t_0 + 0] = _world_0;
              e.mem[_t_0 + 1] = _world_1;
              e.mem[_t_0 + 2] = _world_3;
              e.mem[_t_0 + 3] = _world_4;
              e.mem[_t_0 + 4] = _world_5;
              e.mem[_t_0 + 5] = _world_6;
              e.mem[_t_0 + 6] = _world_7;
              e.mem[_t_0 + 7] = _world_8;
              e.mem[_t_0 + 8] = _world_9;
              e.mem[_t_0 + 9] = _world_10;
              e.mem[_t_0 + 10] = _world_11;
              e.mem[_t_0 + 11] = _world_12;
              e.mem[_t_0 + 12] = _world_13;
              e.mem[_t_0 + 13] = _world_14;
              e.mem[_t_0 + 14] = _index_0;
              e.mem[_t_0 + 15] = _world_2;
              WL_CONT = term_tsk(FID_STORAGE_WITH_MAIN_K189, _t_0);
              WL_IDX = 16;
            }
            if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
              u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
              e.mem[_t_1 + 0] = _transform_0;
              e.mem[_t_1 + 1] = _c_2;
              return term_tsk(FID_CLO_APPLY, _t_1);
            }
            r0 = _transform_0;
            r1 = _c_2;
            WL_JMP(FID_CLO_APPLY);
          }
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_MAIN_K189)
  {
    WL_POPN(16);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    u32 _world_22 = STK(7);
    Term _world_23 = STK(8);
    u32 _world_24 = STK(9);
    Term _world_25 = STK(10);
    u32 _world_26 = STK(11);
    Term _world_27 = STK(12);
    Term _world_28 = STK(13);
    u32 _index_1 = STK(14);
    Term _world_29 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _o_2[17];
    if (spin_5(e, _o_2, _world_15, _world_16, _world_17, blk_loc(e.mem, _world_17), _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, blk_loc(e.mem, _world_21), _world_22, _world_23, _world_24, _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27, blk_loc(e.mem, _world_27), _world_28, blk_loc(e.mem, _world_28), _world_29, blk_loc(e.mem, _world_29), _index_1, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_4 = _o_2[0];
    _v_5 = _o_2[1];
    _v_6 = _o_2[2];
    _v_7 = _o_2[3];
    _v_8 = _o_2[4];
    _v_9 = _o_2[5];
    _v_10 = _o_2[6];
    _v_11 = _o_2[7];
    _v_12 = _o_2[8];
    _v_13 = _o_2[9];
    _v_14 = _o_2[10];
    _v_15 = _o_2[11];
    _v_16 = _o_2[12];
    _v_17 = _o_2[13];
    _v_18 = _o_2[14];
    _v_19 = _o_2[15];
    _v_20 = _o_2[16];
    r0 = _v_4;
    r1 = _v_5;
    r2 = _v_6;
    r3 = _v_7;
    r4 = _v_8;
    r5 = _v_9;
    r6 = _v_10;
    r7 = _v_11;
    r8 = _v_12;
    r9 = _v_13;
    r10 = _v_14;
    r11 = _v_15;
    r12 = _v_16;
    r13 = _v_17;
    r14 = _v_18;
    r15 = _v_19;
    r16 = _v_20;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT)
  {
    Term _depth_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    Term _world_2 = r3;
    Term _world_3 = r4;
    Term _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    u32 _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    Term _world_11 = r12;
    u32 _world_12 = r13;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_world_12 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _depth_0;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _depth_0;
      STK(1) = FID_SNAPSHOT_K228;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_SNAPSHOT_K228, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _depth_0;
      WL_CONT = term_tsk(FID_SNAPSHOT_K228, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_MAIN)) {
      u64 _t_3 = task_node(e, FID_STORAGE_WITH_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _world_0;
      e.mem[_t_3 + 1] = _world_1;
      e.mem[_t_3 + 2] = _world_2;
      e.mem[_t_3 + 3] = _world_3;
      e.mem[_t_3 + 4] = _world_4;
      e.mem[_t_3 + 5] = _world_5;
      e.mem[_t_3 + 6] = _world_6;
      e.mem[_t_3 + 7] = _world_7;
      e.mem[_t_3 + 8] = _world_8;
      e.mem[_t_3 + 9] = _world_9;
      e.mem[_t_3 + 10] = _world_10;
      e.mem[_t_3 + 11] = _world_11;
      e.mem[_t_3 + 12] = _o_0;
      e.mem[_t_3 + 13] = _o_1;
      e.mem[_t_3 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_3 + 15] = _world_0;
      e.mem[_t_3 + 16] = 1ull;
      e.mem[_t_3 + 17] = term_clo(FID_SNAPSHOT_C226, _nd_0);
      return term_tsk(FID_STORAGE_WITH_MAIN, _t_3);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _o_0;
    r13 = _o_1;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _world_0;
    r16 = 1ull;
    r17 = term_clo(FID_SNAPSHOT_C226, _nd_0);
    WL_JMP(FID_STORAGE_WITH_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_C226)
  {
    Term _depth_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    u32 _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    u32 _f_5 = _fb_0[5];
    u32 _f_6 = _fb_0[6];
    u32 _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SNAPSHOT_K227;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_SNAPSHOT_K227, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SNAPSHOT_K227, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SLOT_TEXT)) {
      u64 _t_1 = task_node(e, FID_SLOT_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _depth_1;
      e.mem[_t_1 + 1] = _f_0;
      e.mem[_t_1 + 2] = _f_1;
      e.mem[_t_1 + 3] = _f_2;
      e.mem[_t_1 + 4] = _f_3;
      e.mem[_t_1 + 5] = _f_4;
      e.mem[_t_1 + 6] = _f_5;
      e.mem[_t_1 + 7] = _f_6;
      e.mem[_t_1 + 8] = _f_7;
      e.mem[_t_1 + 9] = _f_8;
      return term_tsk(FID_SLOT_TEXT, _t_1);
    }
    r0 = _depth_1;
    r1 = _f_0;
    r2 = _f_1;
    r3 = _f_2;
    r4 = _f_3;
    r5 = _f_4;
    r6 = _f_5;
    r7 = _f_6;
    r8 = _f_7;
    r9 = _f_8;
    WL_JMP(FID_SLOT_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K227)
  {
    Term _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    u32 _r_3 = r3;
    u32 _r_4 = r4;
    u32 _r_5 = r5;
    u32 _r_6 = r6;
    u32 _r_7 = r7;
    u32 _r_8 = r8;
    Term _r_9 = r9;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_1 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_1 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_1 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_1 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_1 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_1 + 8] = rfc_seal(e, _r_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _r_9);
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K228)
  {
    WL_POPN(1);
    Term _depth_2 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    WL_OPEN
    u32 _o_2 = 0;
    if (_h_12 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
    }
    if (_h_15 == 0) {
      if (seq) {
        WL_ROOM(15);
        STK(0) = _depth_2;
        STK(1) = _h_0;
        STK(2) = _h_1;
        STK(3) = _h_2;
        STK(4) = _h_3;
        STK(5) = _h_4;
        STK(6) = _h_5;
        STK(7) = _h_6;
        STK(8) = _h_7;
        STK(9) = _h_8;
        STK(10) = _h_9;
        STK(11) = _h_10;
        STK(12) = _h_11;
        STK(13) = _o_2;
        STK(14) = FID_SNAPSHOT_K229;
        WL_PUSHN(15);
      } else {
        u64 _t_4 = task_node(e, FID_SNAPSHOT_K229, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _depth_2;
        e.mem[_t_4 + 1] = _h_0;
        e.mem[_t_4 + 2] = _h_1;
        e.mem[_t_4 + 3] = _h_2;
        e.mem[_t_4 + 4] = _h_3;
        e.mem[_t_4 + 5] = _h_4;
        e.mem[_t_4 + 6] = _h_5;
        e.mem[_t_4 + 7] = _h_6;
        e.mem[_t_4 + 8] = _h_7;
        e.mem[_t_4 + 9] = _h_8;
        e.mem[_t_4 + 10] = _h_9;
        e.mem[_t_4 + 11] = _h_10;
        e.mem[_t_4 + 12] = _h_11;
        e.mem[_t_4 + 13] = _o_2;
        WL_CONT = term_tsk(FID_SNAPSHOT_K229, _t_4);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _h_16;
        e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 64);
        return term_tsk(FID_STRING_APPEND, _t_5);
      }
      r0 = _h_16;
      r1 = term_ctr(CID_SCON, STAT_OFF + 64);
      WL_JMP(FID_STRING_APPEND);
    } else {
      term_sink(e, _h_16);
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      r5 = _h_5;
      r6 = _h_6;
      r7 = _h_7;
      r8 = _h_8;
      r9 = _h_9;
      r10 = _h_10;
      r11 = _h_11;
      r12 = _o_2;
      r13 = term_ctr(CID_SCON, STAT_OFF + 132);
      WL_RETN(14);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K229)
  {
    WL_POPN(14);
    Term _depth_3 = STK(0);
    u32 _h_18 = STK(1);
    u32 _h_19 = STK(2);
    Term _h_20 = STK(3);
    Term _h_21 = STK(4);
    Term _h_22 = STK(5);
    Term _h_23 = STK(6);
    Term _h_24 = STK(7);
    Term _h_25 = STK(8);
    u32 _h_26 = STK(9);
    Term _h_27 = STK(10);
    u32 _h_28 = STK(11);
    Term _h_29 = STK(12);
    u32 _o_3 = STK(13);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _depth_3;
      STK(1) = _h_18;
      STK(2) = _h_19;
      STK(3) = _h_20;
      STK(4) = _h_21;
      STK(5) = _h_22;
      STK(6) = _h_23;
      STK(7) = _h_24;
      STK(8) = _h_25;
      STK(9) = _h_26;
      STK(10) = _h_27;
      STK(11) = _h_28;
      STK(12) = _h_29;
      STK(13) = _o_3;
      STK(14) = FID_SNAPSHOT_K230;
      WL_PUSHN(15);
    } else {
      u64 _t_6 = task_node(e, FID_SNAPSHOT_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _depth_3;
      e.mem[_t_6 + 1] = _h_18;
      e.mem[_t_6 + 2] = _h_19;
      e.mem[_t_6 + 3] = _h_20;
      e.mem[_t_6 + 4] = _h_21;
      e.mem[_t_6 + 5] = _h_22;
      e.mem[_t_6 + 6] = _h_23;
      e.mem[_t_6 + 7] = _h_24;
      e.mem[_t_6 + 8] = _h_25;
      e.mem[_t_6 + 9] = _h_26;
      e.mem[_t_6 + 10] = _h_27;
      e.mem[_t_6 + 11] = _h_28;
      e.mem[_t_6 + 12] = _h_29;
      e.mem[_t_6 + 13] = _o_3;
      WL_CONT = term_tsk(FID_SNAPSHOT_K230, _t_6);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 102);
      e.mem[_t_7 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 102);
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K230)
  {
    WL_POPN(14);
    Term _depth_4 = STK(0);
    u32 _h_31 = STK(1);
    u32 _h_32 = STK(2);
    Term _h_33 = STK(3);
    Term _h_34 = STK(4);
    Term _h_35 = STK(5);
    Term _h_36 = STK(6);
    Term _h_37 = STK(7);
    Term _h_38 = STK(8);
    u32 _h_39 = STK(9);
    Term _h_40 = STK(10);
    u32 _h_41 = STK(11);
    Term _h_42 = STK(12);
    u32 _o_4 = STK(13);
    Term _h_30 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_31;
      STK(1) = _h_32;
      STK(2) = _h_33;
      STK(3) = _h_34;
      STK(4) = _h_35;
      STK(5) = _h_36;
      STK(6) = _h_37;
      STK(7) = _h_38;
      STK(8) = _h_39;
      STK(9) = _h_40;
      STK(10) = _h_41;
      STK(11) = _o_4;
      STK(12) = FID_SNAPSHOT_K231;
      WL_PUSHN(13);
    } else {
      u64 _t_8 = task_node(e, FID_SNAPSHOT_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_31;
      e.mem[_t_8 + 1] = _h_32;
      e.mem[_t_8 + 2] = _h_33;
      e.mem[_t_8 + 3] = _h_34;
      e.mem[_t_8 + 4] = _h_35;
      e.mem[_t_8 + 5] = _h_36;
      e.mem[_t_8 + 6] = _h_37;
      e.mem[_t_8 + 7] = _h_38;
      e.mem[_t_8 + 8] = _h_39;
      e.mem[_t_8 + 9] = _h_40;
      e.mem[_t_8 + 10] = _h_41;
      e.mem[_t_8 + 11] = _o_4;
      WL_CONT = term_tsk(FID_SNAPSHOT_K231, _t_8);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUEUE_TEXT)) {
      u64 _t_9 = task_node(e, FID_QUEUE_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _depth_4;
      e.mem[_t_9 + 1] = _h_42;
      e.mem[_t_9 + 2] = term_pak(CID_NIL, 0);
      e.mem[_t_9 + 3] = _h_30;
      return term_tsk(FID_QUEUE_TEXT, _t_9);
    }
    r0 = _depth_4;
    r1 = _h_42;
    r2 = term_pak(CID_NIL, 0);
    r3 = _h_30;
    WL_JMP(FID_QUEUE_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K231)
  {
    WL_POPN(12);
    u32 _h_45 = STK(0);
    u32 _h_46 = STK(1);
    Term _h_47 = STK(2);
    Term _h_48 = STK(3);
    Term _h_49 = STK(4);
    Term _h_50 = STK(5);
    Term _h_51 = STK(6);
    Term _h_52 = STK(7);
    u32 _h_53 = STK(8);
    Term _h_54 = STK(9);
    u32 _h_55 = STK(10);
    u32 _o_5 = STK(11);
    Term _h_43 = r0;
    Term _h_44 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_45;
      STK(1) = _h_46;
      STK(2) = _h_47;
      STK(3) = _h_48;
      STK(4) = _h_49;
      STK(5) = _h_50;
      STK(6) = _h_51;
      STK(7) = _h_52;
      STK(8) = _h_53;
      STK(9) = _h_54;
      STK(10) = _h_55;
      STK(11) = _o_5;
      STK(12) = _h_43;
      STK(13) = _h_44;
      STK(14) = FID_SNAPSHOT_K232;
      WL_PUSHN(15);
    } else {
      u64 _t_10 = task_node(e, FID_SNAPSHOT_K232, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_45;
      e.mem[_t_10 + 1] = _h_46;
      e.mem[_t_10 + 2] = _h_47;
      e.mem[_t_10 + 3] = _h_48;
      e.mem[_t_10 + 4] = _h_49;
      e.mem[_t_10 + 5] = _h_50;
      e.mem[_t_10 + 6] = _h_51;
      e.mem[_t_10 + 7] = _h_52;
      e.mem[_t_10 + 8] = _h_53;
      e.mem[_t_10 + 9] = _h_54;
      e.mem[_t_10 + 10] = _h_55;
      e.mem[_t_10 + 11] = _o_5;
      e.mem[_t_10 + 12] = _h_43;
      e.mem[_t_10 + 13] = _h_44;
      WL_CONT = term_tsk(FID_SNAPSHOT_K232, _t_10);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_45;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _h_45;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K232)
  {
    WL_POPN(14);
    u32 _h_57 = STK(0);
    u32 _h_58 = STK(1);
    Term _h_59 = STK(2);
    Term _h_60 = STK(3);
    Term _h_61 = STK(4);
    Term _h_62 = STK(5);
    Term _h_63 = STK(6);
    Term _h_64 = STK(7);
    u32 _h_65 = STK(8);
    Term _h_66 = STK(9);
    u32 _h_67 = STK(10);
    u32 _o_6 = STK(11);
    Term _h_68 = STK(12);
    Term _h_69 = STK(13);
    Term _h_56 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_57;
      STK(1) = _h_58;
      STK(2) = _h_59;
      STK(3) = _h_60;
      STK(4) = _h_61;
      STK(5) = _h_62;
      STK(6) = _h_63;
      STK(7) = _h_64;
      STK(8) = _h_65;
      STK(9) = _h_66;
      STK(10) = _h_67;
      STK(11) = _o_6;
      STK(12) = _h_68;
      STK(13) = _h_69;
      STK(14) = _h_56;
      STK(15) = FID_SNAPSHOT_K233;
      WL_PUSHN(16);
    } else {
      u64 _t_12 = task_node(e, FID_SNAPSHOT_K233, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_57;
      e.mem[_t_12 + 1] = _h_58;
      e.mem[_t_12 + 2] = _h_59;
      e.mem[_t_12 + 3] = _h_60;
      e.mem[_t_12 + 4] = _h_61;
      e.mem[_t_12 + 5] = _h_62;
      e.mem[_t_12 + 6] = _h_63;
      e.mem[_t_12 + 7] = _h_64;
      e.mem[_t_12 + 8] = _h_65;
      e.mem[_t_12 + 9] = _h_66;
      e.mem[_t_12 + 10] = _h_67;
      e.mem[_t_12 + 11] = _o_6;
      e.mem[_t_12 + 12] = _h_68;
      e.mem[_t_12 + 13] = _h_69;
      e.mem[_t_12 + 14] = _h_56;
      WL_CONT = term_tsk(FID_SNAPSHOT_K233, _t_12);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_58;
      return term_tsk(FID_U32_SHOW, _t_13);
    }
    r0 = _h_58;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K233)
  {
    WL_POPN(15);
    u32 _h_71 = STK(0);
    u32 _h_72 = STK(1);
    Term _h_73 = STK(2);
    Term _h_74 = STK(3);
    Term _h_75 = STK(4);
    Term _h_76 = STK(5);
    Term _h_77 = STK(6);
    Term _h_78 = STK(7);
    u32 _h_79 = STK(8);
    Term _h_80 = STK(9);
    u32 _h_81 = STK(10);
    u32 _o_7 = STK(11);
    Term _h_82 = STK(12);
    Term _h_83 = STK(13);
    Term _h_84 = STK(14);
    Term _h_70 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_71;
      STK(1) = _h_72;
      STK(2) = _h_73;
      STK(3) = _h_74;
      STK(4) = _h_75;
      STK(5) = _h_76;
      STK(6) = _h_77;
      STK(7) = _h_78;
      STK(8) = _h_79;
      STK(9) = _h_80;
      STK(10) = _h_81;
      STK(11) = _o_7;
      STK(12) = _h_82;
      STK(13) = _h_84;
      STK(14) = _h_70;
      STK(15) = FID_SNAPSHOT_K234;
      WL_PUSHN(16);
    } else {
      u64 _t_14 = task_node(e, FID_SNAPSHOT_K234, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_71;
      e.mem[_t_14 + 1] = _h_72;
      e.mem[_t_14 + 2] = _h_73;
      e.mem[_t_14 + 3] = _h_74;
      e.mem[_t_14 + 4] = _h_75;
      e.mem[_t_14 + 5] = _h_76;
      e.mem[_t_14 + 6] = _h_77;
      e.mem[_t_14 + 7] = _h_78;
      e.mem[_t_14 + 8] = _h_79;
      e.mem[_t_14 + 9] = _h_80;
      e.mem[_t_14 + 10] = _h_81;
      e.mem[_t_14 + 11] = _o_7;
      e.mem[_t_14 + 12] = _h_82;
      e.mem[_t_14 + 13] = _h_84;
      e.mem[_t_14 + 14] = _h_70;
      WL_CONT = term_tsk(FID_SNAPSHOT_K234, _t_14);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
      e.mem[_t_15 + 1] = _h_83;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 64);
    r1 = _h_83;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K234)
  {
    WL_POPN(15);
    u32 _h_86 = STK(0);
    u32 _h_87 = STK(1);
    Term _h_88 = STK(2);
    Term _h_89 = STK(3);
    Term _h_90 = STK(4);
    Term _h_91 = STK(5);
    Term _h_92 = STK(6);
    Term _h_93 = STK(7);
    u32 _h_94 = STK(8);
    Term _h_95 = STK(9);
    u32 _h_96 = STK(10);
    u32 _o_8 = STK(11);
    Term _h_97 = STK(12);
    Term _h_98 = STK(13);
    Term _h_99 = STK(14);
    Term _h_85 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_86;
      STK(1) = _h_87;
      STK(2) = _h_88;
      STK(3) = _h_89;
      STK(4) = _h_90;
      STK(5) = _h_91;
      STK(6) = _h_92;
      STK(7) = _h_93;
      STK(8) = _h_94;
      STK(9) = _h_95;
      STK(10) = _h_96;
      STK(11) = _o_8;
      STK(12) = _h_97;
      STK(13) = _h_98;
      STK(14) = FID_SNAPSHOT_K235;
      WL_PUSHN(15);
    } else {
      u64 _t_16 = task_node(e, FID_SNAPSHOT_K235, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_86;
      e.mem[_t_16 + 1] = _h_87;
      e.mem[_t_16 + 2] = _h_88;
      e.mem[_t_16 + 3] = _h_89;
      e.mem[_t_16 + 4] = _h_90;
      e.mem[_t_16 + 5] = _h_91;
      e.mem[_t_16 + 6] = _h_92;
      e.mem[_t_16 + 7] = _h_93;
      e.mem[_t_16 + 8] = _h_94;
      e.mem[_t_16 + 9] = _h_95;
      e.mem[_t_16 + 10] = _h_96;
      e.mem[_t_16 + 11] = _o_8;
      e.mem[_t_16 + 12] = _h_97;
      e.mem[_t_16 + 13] = _h_98;
      WL_CONT = term_tsk(FID_SNAPSHOT_K235, _t_16);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_99;
      e.mem[_t_17 + 1] = _h_85;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = _h_99;
    r1 = _h_85;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K235)
  {
    WL_POPN(14);
    u32 _h_101 = STK(0);
    u32 _h_102 = STK(1);
    Term _h_103 = STK(2);
    Term _h_104 = STK(3);
    Term _h_105 = STK(4);
    Term _h_106 = STK(5);
    Term _h_107 = STK(6);
    Term _h_108 = STK(7);
    u32 _h_109 = STK(8);
    Term _h_110 = STK(9);
    u32 _h_111 = STK(10);
    u32 _o_9 = STK(11);
    Term _h_112 = STK(12);
    Term _h_113 = STK(13);
    Term _h_100 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_101;
      STK(1) = _h_102;
      STK(2) = _h_103;
      STK(3) = _h_104;
      STK(4) = _h_105;
      STK(5) = _h_106;
      STK(6) = _h_107;
      STK(7) = _h_108;
      STK(8) = _h_109;
      STK(9) = _h_110;
      STK(10) = _h_111;
      STK(11) = _o_9;
      STK(12) = _h_112;
      STK(13) = _h_113;
      STK(14) = FID_SNAPSHOT_K236;
      WL_PUSHN(15);
    } else {
      u64 _t_18 = task_node(e, FID_SNAPSHOT_K236, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_101;
      e.mem[_t_18 + 1] = _h_102;
      e.mem[_t_18 + 2] = _h_103;
      e.mem[_t_18 + 3] = _h_104;
      e.mem[_t_18 + 4] = _h_105;
      e.mem[_t_18 + 5] = _h_106;
      e.mem[_t_18 + 6] = _h_107;
      e.mem[_t_18 + 7] = _h_108;
      e.mem[_t_18 + 8] = _h_109;
      e.mem[_t_18 + 9] = _h_110;
      e.mem[_t_18 + 10] = _h_111;
      e.mem[_t_18 + 11] = _o_9;
      e.mem[_t_18 + 12] = _h_112;
      e.mem[_t_18 + 13] = _h_113;
      WL_CONT = term_tsk(FID_SNAPSHOT_K236, _t_18);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_19 + 1] = _h_100;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_100;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K236)
  {
    WL_POPN(14);
    u32 _h_115 = STK(0);
    u32 _h_116 = STK(1);
    Term _h_117 = STK(2);
    Term _h_118 = STK(3);
    Term _h_119 = STK(4);
    Term _h_120 = STK(5);
    Term _h_121 = STK(6);
    Term _h_122 = STK(7);
    u32 _h_123 = STK(8);
    Term _h_124 = STK(9);
    u32 _h_125 = STK(10);
    u32 _o_10 = STK(11);
    Term _h_126 = STK(12);
    Term _h_127 = STK(13);
    Term _h_114 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_115;
      STK(1) = _h_116;
      STK(2) = _h_117;
      STK(3) = _h_118;
      STK(4) = _h_119;
      STK(5) = _h_120;
      STK(6) = _h_121;
      STK(7) = _h_122;
      STK(8) = _h_123;
      STK(9) = _h_124;
      STK(10) = _h_125;
      STK(11) = _o_10;
      STK(12) = _h_126;
      STK(13) = FID_SNAPSHOT_K237;
      WL_PUSHN(14);
    } else {
      u64 _t_20 = task_node(e, FID_SNAPSHOT_K237, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_115;
      e.mem[_t_20 + 1] = _h_116;
      e.mem[_t_20 + 2] = _h_117;
      e.mem[_t_20 + 3] = _h_118;
      e.mem[_t_20 + 4] = _h_119;
      e.mem[_t_20 + 5] = _h_120;
      e.mem[_t_20 + 6] = _h_121;
      e.mem[_t_20 + 7] = _h_122;
      e.mem[_t_20 + 8] = _h_123;
      e.mem[_t_20 + 9] = _h_124;
      e.mem[_t_20 + 10] = _h_125;
      e.mem[_t_20 + 11] = _o_10;
      e.mem[_t_20 + 12] = _h_126;
      WL_CONT = term_tsk(FID_SNAPSHOT_K237, _t_20);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_127;
      e.mem[_t_21 + 1] = _h_114;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_127;
    r1 = _h_114;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K237)
  {
    WL_POPN(13);
    u32 _h_129 = STK(0);
    u32 _h_130 = STK(1);
    Term _h_131 = STK(2);
    Term _h_132 = STK(3);
    Term _h_133 = STK(4);
    Term _h_134 = STK(5);
    Term _h_135 = STK(6);
    Term _h_136 = STK(7);
    u32 _h_137 = STK(8);
    Term _h_138 = STK(9);
    u32 _h_139 = STK(10);
    u32 _o_11 = STK(11);
    Term _h_140 = STK(12);
    Term _h_128 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_129;
      STK(1) = _h_130;
      STK(2) = _h_131;
      STK(3) = _h_132;
      STK(4) = _h_133;
      STK(5) = _h_134;
      STK(6) = _h_135;
      STK(7) = _h_136;
      STK(8) = _h_137;
      STK(9) = _h_138;
      STK(10) = _h_139;
      STK(11) = _o_11;
      STK(12) = _h_140;
      STK(13) = FID_SNAPSHOT_K238;
      WL_PUSHN(14);
    } else {
      u64 _t_22 = task_node(e, FID_SNAPSHOT_K238, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_129;
      e.mem[_t_22 + 1] = _h_130;
      e.mem[_t_22 + 2] = _h_131;
      e.mem[_t_22 + 3] = _h_132;
      e.mem[_t_22 + 4] = _h_133;
      e.mem[_t_22 + 5] = _h_134;
      e.mem[_t_22 + 6] = _h_135;
      e.mem[_t_22 + 7] = _h_136;
      e.mem[_t_22 + 8] = _h_137;
      e.mem[_t_22 + 9] = _h_138;
      e.mem[_t_22 + 10] = _h_139;
      e.mem[_t_22 + 11] = _o_11;
      e.mem[_t_22 + 12] = _h_140;
      WL_CONT = term_tsk(FID_SNAPSHOT_K238, _t_22);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 94);
      e.mem[_t_23 + 1] = _h_128;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 94);
    r1 = _h_128;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K238)
  {
    WL_POPN(13);
    u32 _h_142 = STK(0);
    u32 _h_143 = STK(1);
    Term _h_144 = STK(2);
    Term _h_145 = STK(3);
    Term _h_146 = STK(4);
    Term _h_147 = STK(5);
    Term _h_148 = STK(6);
    Term _h_149 = STK(7);
    u32 _h_150 = STK(8);
    Term _h_151 = STK(9);
    u32 _h_152 = STK(10);
    u32 _o_12 = STK(11);
    Term _h_153 = STK(12);
    Term _h_141 = r0;
    WL_OPEN
    r0 = _h_142;
    r1 = _h_143;
    r2 = _h_144;
    r3 = _h_145;
    r4 = _h_146;
    r5 = _h_147;
    r6 = _h_148;
    r7 = _h_149;
    r8 = _h_150;
    r9 = _h_151;
    r10 = _h_152;
    r11 = _h_153;
    r12 = _o_12;
    r13 = _h_141;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _main_0 = r17;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_0 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _handle_0;
      e.mem[_t_0 + 16] = _handle_1;
      e.mem[_t_0 + 17] = _main_0;
      e.mem[_t_0 + 18] = term_clo(FID_COMMANDS_INSERT_MAIN_C258, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_0);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = _main_0;
    r18 = term_clo(FID_COMMANDS_INSERT_MAIN_C258, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_C258)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_INSERT_MAIN_C259, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_MAIN_C259)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_11(e, _o_0, _x_2, _x_1, blk_loc(e.mem, _x_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY)
  {
    Term _depth_0 = r0;
    WL_OPEN
    WL_SPIN
    if (_depth_0 == 0) {
      Term _fv_0[2];
      _fv_0[0] = 0;
      _fv_0[1] = 0;
      r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
      WL_RETN(1);
    } else {
      Term _d_0 = (_depth_0 - 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _d_0;
        STK(1) = FID_STORAGE_SLOTS_EMPTY_K266;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K266, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _d_0;
        WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K266, _t_0);
        WL_IDX = 1;
      }
      r0 = _d_0;
      _depth_0 = r0;
      WL_AGAIN(FID_STORAGE_SLOTS_EMPTY);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K266)
  {
    WL_POPN(1);
    Term _d_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_STORAGE_SLOTS_EMPTY_K267;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K267, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K267, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_2 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _d_1;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_2);
    }
    r0 = _d_1;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K267)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_2, _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_FLAG)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _flag_0 = r17;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_0 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _handle_0;
      e.mem[_t_0 + 16] = _handle_1;
      e.mem[_t_0 + 17] = _flag_0;
      e.mem[_t_0 + 18] = term_clo(FID_COMMANDS_INSERT_FLAG_C293, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_0);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = _flag_0;
    r18 = term_clo(FID_COMMANDS_INSERT_FLAG_C293, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_FLAG_C293)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_INSERT_FLAG_C294, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_INSERT_FLAG_C294)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_17(e, _o_0, _x_2, _x_1, blk_loc(e.mem, _x_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_COMMANDS_REMOVE_MAIN_K334;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_COMMANDS_REMOVE_MAIN_K334, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_COMMANDS_REMOVE_MAIN_K334, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_1 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_pak(CID_UNIT, 0);
      e.mem[_t_1 + 18] = term_clo(FID_COMMANDS_REMOVE_MAIN_C332, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_pak(CID_UNIT, 0);
    r18 = term_clo(FID_COMMANDS_REMOVE_MAIN_C332, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_MAIN_C332)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_REMOVE_MAIN_C333, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_MAIN_C333)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_24(e, _o_0, _x_2) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_MAIN_K334)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    u32 _r_9 = r9;
    Term _r_10 = r10;
    u32 _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    Term _r_14 = r14;
    Term _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    Term _o_11 = 0;
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    if (_r_0 == 0) {
      _o_1 = 0;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    } else {
      _o_1 = 1;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    r14 = _o_15;
    r15 = _o_16;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW)
  {
    Term _fuel_0 = r0;
    u32 _id_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    WL_OPEN
    if (_fuel_0 == 0) {
      r0 = _rows_0;
      r1 = _rows_1;
      r2 = _rows_2;
      r3 = _rows_3;
      r4 = _rows_4;
      r5 = _rows_5;
      r6 = _rows_6;
      r7 = _rows_7;
      r8 = _rows_8;
      WL_RETN(9);
    } else {
      Term _n_0 = (_fuel_0 - 1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_7(e, _o_0, U32_BIN(_rows_6, <, _id_0), U32_BIN(_rows_6, <=, 65536ull)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _n_0;
      e.mem[_nd_0 + 1] = _id_0;
      if (_v_0 == 0) {
        Term _recurse_0 = term_clo(FID_STORAGE_GROW_C346, _nd_0);
        term_sink(e, _recurse_0);
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        WL_RETN(9);
      } else {
        Term _recurse_1 = term_clo(FID_STORAGE_GROW_C346, _nd_0);
        if (seq) {
          WL_ROOM(11);
          STK(0) = _rows_0;
          STK(1) = _rows_1;
          STK(2) = _rows_2;
          STK(3) = _rows_3;
          STK(4) = _rows_4;
          STK(5) = _rows_5;
          STK(6) = _rows_6;
          STK(7) = _rows_7;
          STK(8) = _rows_8;
          STK(9) = _recurse_1;
          STK(10) = FID_STORAGE_GROW_K348;
          WL_PUSHN(11);
        } else {
          u64 _t_2 = task_node(e, FID_STORAGE_GROW_K348, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _rows_0;
          e.mem[_t_2 + 1] = _rows_1;
          e.mem[_t_2 + 2] = _rows_2;
          e.mem[_t_2 + 3] = _rows_3;
          e.mem[_t_2 + 4] = _rows_4;
          e.mem[_t_2 + 5] = _rows_5;
          e.mem[_t_2 + 6] = _rows_6;
          e.mem[_t_2 + 7] = _rows_7;
          e.mem[_t_2 + 8] = _rows_8;
          e.mem[_t_2 + 9] = _recurse_1;
          WL_CONT = term_tsk(FID_STORAGE_GROW_K348, _t_2);
          WL_IDX = 10;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
          u64 _t_3 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_7;
          return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_3);
        }
        r0 = _rows_7;
        WL_JMP(FID_STORAGE_SLOTS_EMPTY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_C346)
  {
    Term _n_1 = r0;
    u32 _id_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    u32 _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K347;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STORAGE_GROW_K347, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K347, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
      u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _n_1;
      e.mem[_t_1 + 1] = _id_1;
      e.mem[_t_1 + 2] = _f_0;
      e.mem[_t_1 + 3] = _f_1;
      e.mem[_t_1 + 4] = _f_2;
      e.mem[_t_1 + 5] = _f_3;
      e.mem[_t_1 + 6] = _f_4;
      e.mem[_t_1 + 7] = _f_5;
      e.mem[_t_1 + 8] = _f_6;
      e.mem[_t_1 + 9] = _f_7;
      e.mem[_t_1 + 10] = _f_8;
      return term_tsk(FID_STORAGE_GROW, _t_1);
    }
    r0 = _n_1;
    r1 = _id_1;
    r2 = _f_0;
    r3 = _f_1;
    r4 = _f_2;
    r5 = _f_3;
    r6 = _f_4;
    r7 = _f_5;
    r8 = _f_6;
    r9 = _f_7;
    r10 = _f_8;
    WL_JMP(FID_STORAGE_GROW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K347)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    u32 _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_1 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_1 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_1 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_1 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_1 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_1 + 8] = rfc_seal(e, _r_8);
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K348)
  {
    WL_POPN(10);
    Term _rows_9 = STK(0);
    Term _rows_10 = STK(1);
    Term _rows_11 = STK(2);
    Term _rows_12 = STK(3);
    Term _rows_13 = STK(4);
    Term _rows_14 = STK(5);
    u32 _rows_15 = STK(6);
    Term _rows_16 = STK(7);
    u32 _rows_17 = STK(8);
    Term _recurse_2 = STK(9);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_9;
      STK(1) = _rows_10;
      STK(2) = _rows_11;
      STK(3) = _rows_12;
      STK(4) = _rows_13;
      STK(5) = _rows_14;
      STK(6) = _rows_15;
      STK(7) = _rows_16;
      STK(8) = _rows_17;
      STK(9) = _recurse_2;
      STK(10) = _h_0;
      STK(11) = FID_STORAGE_GROW_K349;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_STORAGE_GROW_K349, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _rows_9;
      e.mem[_t_4 + 1] = _rows_10;
      e.mem[_t_4 + 2] = _rows_11;
      e.mem[_t_4 + 3] = _rows_12;
      e.mem[_t_4 + 4] = _rows_13;
      e.mem[_t_4 + 5] = _rows_14;
      e.mem[_t_4 + 6] = _rows_15;
      e.mem[_t_4 + 7] = _rows_16;
      e.mem[_t_4 + 8] = _rows_17;
      e.mem[_t_4 + 9] = _recurse_2;
      e.mem[_t_4 + 10] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_GROW_K349, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_5 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rows_16;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_5);
    }
    r0 = _rows_16;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K349)
  {
    WL_POPN(11);
    Term _rows_18 = STK(0);
    Term _rows_19 = STK(1);
    Term _rows_20 = STK(2);
    Term _rows_21 = STK(3);
    Term _rows_22 = STK(4);
    Term _rows_23 = STK(5);
    u32 _rows_24 = STK(6);
    Term _rows_25 = STK(7);
    u32 _rows_26 = STK(8);
    Term _recurse_3 = STK(9);
    Term _h_2 = STK(10);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _o_1[4];
    if (spin_21(e, _o_1, _rows_20, blk_loc(e.mem, _rows_20), _rows_21, blk_loc(e.mem, _rows_21), _rows_22, blk_loc(e.mem, _rows_22), _rows_23, blk_loc(e.mem, _rows_23), _rows_25) == 0) {
      return 0;
    }
    _v_6 = _o_1[0];
    _v_7 = _o_1[1];
    _v_8 = _o_1[2];
    _v_9 = _o_1[3];
    _v_2 = _v_6;
    _v_3 = _v_7;
    _v_4 = _v_8;
    _v_5 = _v_9;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = rfc_seal(e, blk_node(e, _rows_18, _h_2));
    e.mem[_nd_2 + 1] = rfc_seal(e, blk_node(e, _rows_19, _h_1));
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 6] = rfc_seal(e, U32_BIN(_rows_24, +, _rows_24));
    e.mem[_nd_2 + 7] = rfc_seal(e, nat_chk(e, _rows_25 + 1));
    e.mem[_nd_2 + 8] = rfc_seal(e, _rows_26);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K350;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_STORAGE_GROW_K350, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K350, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _recurse_3;
      e.mem[_t_7 + 1] = term_ctr(CID_STORAGE_ROWS, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _recurse_3;
    r1 = term_ctr(CID_STORAGE_ROWS, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K350)
  {
    Term _r_9 = r0;
    WL_OPEN
    Term _fb_1[9];
    u64 _sp_1 = ctr_take(e, _r_9, 9, _fb_1);
    Term _f_9 = _fb_1[0];
    Term _f_10 = _fb_1[1];
    Term _f_11 = _fb_1[2];
    Term _f_12 = _fb_1[3];
    Term _f_13 = _fb_1[4];
    Term _f_14 = _fb_1[5];
    u32 _f_15 = _fb_1[6];
    Term _f_16 = _fb_1[7];
    u32 _f_17 = _fb_1[8];
    spare_free(e, cls_fit(9), _sp_1);
    r0 = _f_9;
    r1 = _f_10;
    r2 = _f_11;
    r3 = _f_12;
    r4 = _f_13;
    r5 = _f_14;
    r6 = _f_15;
    r7 = _f_16;
    r8 = _f_17;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_COMMANDS_REMOVE_FLAG_K381;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_COMMANDS_REMOVE_FLAG_K381, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_COMMANDS_REMOVE_FLAG_K381, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_1 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_pak(CID_UNIT, 0);
      e.mem[_t_1 + 18] = term_clo(FID_COMMANDS_REMOVE_FLAG_C379, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_pak(CID_UNIT, 0);
    r18 = term_clo(FID_COMMANDS_REMOVE_FLAG_C379, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG_C379)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_REMOVE_FLAG_C380, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG_C380)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_39(e, _o_0, _x_2) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_REMOVE_FLAG_K381)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    u32 _r_9 = r9;
    Term _r_10 = r10;
    u32 _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    Term _r_14 = r14;
    Term _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    Term _o_11 = 0;
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    if (_r_0 == 0) {
      _o_1 = 0;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    } else {
      _o_1 = 1;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    r14 = _o_15;
    r15 = _o_16;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_QUEUE_OWNED)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _payload_0 = r17;
    Term _build_0 = r18;
    WL_OPEN
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _build_0);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      Term _v_9 = 0;
      u32 _v_10 = 0;
      Term _v_11 = 0;
      u32 _v_12 = 0;
      Term _v_13 = 0;
      Term _v_14 = 0;
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      u32 _v_23 = 0;
      Term _v_24 = 0;
      u32 _v_25 = 0;
      Term _v_26 = 0;
      u32 _v_27 = 0;
      Term _v_28 = 0;
      Term _v_29 = 0;
      Term _o_0[15];
      if (spin_25(e, _o_0, _world_0, _world_1, _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, blk_loc(e.mem, _world_11), _world_12, _world_13, blk_loc(e.mem, _world_13), _world_14, blk_loc(e.mem, _world_14)) == 0) {
        return 0;
      }
      _v_15 = _o_0[0];
      _v_16 = _o_0[1];
      _v_17 = _o_0[2];
      _v_18 = _o_0[3];
      _v_19 = _o_0[4];
      _v_20 = _o_0[5];
      _v_21 = _o_0[6];
      _v_22 = _o_0[7];
      _v_23 = _o_0[8];
      _v_24 = _o_0[9];
      _v_25 = _o_0[10];
      _v_26 = _o_0[11];
      _v_27 = _o_0[12];
      _v_28 = _o_0[13];
      _v_29 = _o_0[14];
      _v_0 = _v_15;
      _v_1 = _v_16;
      _v_2 = _v_17;
      _v_3 = _v_18;
      _v_4 = _v_19;
      _v_5 = _v_20;
      _v_6 = _v_21;
      _v_7 = _v_22;
      _v_8 = _v_23;
      _v_9 = _v_24;
      _v_10 = _v_25;
      _v_11 = _v_26;
      _v_12 = _v_27;
      _v_13 = _v_28;
      _v_14 = _v_29;
      r0 = 1;
      r1 = _v_0;
      r2 = _v_1;
      r3 = _v_2;
      r4 = _v_3;
      r5 = _v_4;
      r6 = _v_5;
      r7 = _v_6;
      r8 = _v_7;
      r9 = _v_8;
      r10 = _v_9;
      r11 = _v_10;
      r12 = _v_11;
      r13 = _v_12;
      r14 = _v_13;
      r15 = _v_14;
      r16 = _payload_0;
      WL_RETN(17);
    } else {
      if (seq) {
        WL_ROOM(17);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_2;
        STK(3) = _world_3;
        STK(4) = _world_4;
        STK(5) = _world_5;
        STK(6) = _world_6;
        STK(7) = _world_7;
        STK(8) = _world_8;
        STK(9) = _world_9;
        STK(10) = _world_10;
        STK(11) = _world_11;
        STK(12) = _world_12;
        STK(13) = _world_13;
        STK(14) = _world_14;
        STK(15) = _payload_0;
        STK(16) = FID_COMMANDS_QUEUE_OWNED_K384;
        WL_PUSHN(17);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_QUEUE_OWNED_K384, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_2;
        e.mem[_t_0 + 3] = _world_3;
        e.mem[_t_0 + 4] = _world_4;
        e.mem[_t_0 + 5] = _world_5;
        e.mem[_t_0 + 6] = _world_6;
        e.mem[_t_0 + 7] = _world_7;
        e.mem[_t_0 + 8] = _world_8;
        e.mem[_t_0 + 9] = _world_9;
        e.mem[_t_0 + 10] = _world_10;
        e.mem[_t_0 + 11] = _world_11;
        e.mem[_t_0 + 12] = _world_12;
        e.mem[_t_0 + 13] = _world_13;
        e.mem[_t_0 + 14] = _world_14;
        e.mem[_t_0 + 15] = _payload_0;
        WL_CONT = term_tsk(FID_COMMANDS_QUEUE_OWNED_K384, _t_0);
        WL_IDX = 16;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _build_0;
        e.mem[_t_1 + 1] = _handle_1;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _build_0;
      r1 = _handle_1;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_QUEUE_OWNED_K384)
  {
    WL_POPN(16);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    Term _world_22 = STK(7);
    u32 _world_23 = STK(8);
    Term _world_24 = STK(9);
    u32 _world_25 = STK(10);
    Term _world_26 = STK(11);
    u32 _world_27 = STK(12);
    Term _world_28 = STK(13);
    Term _world_29 = STK(14);
    Term _payload_1 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _world_15;
      STK(1) = _world_16;
      STK(2) = _world_17;
      STK(3) = _world_18;
      STK(4) = _world_19;
      STK(5) = _world_20;
      STK(6) = _world_21;
      STK(7) = _world_22;
      STK(8) = _world_23;
      STK(9) = _world_24;
      STK(10) = _world_25;
      STK(11) = _world_26;
      STK(12) = _world_27;
      STK(13) = _world_28;
      STK(14) = _world_29;
      STK(15) = FID_COMMANDS_QUEUE_OWNED_K385;
      WL_PUSHN(16);
    } else {
      u64 _t_2 = task_node(e, FID_COMMANDS_QUEUE_OWNED_K385, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _world_15;
      e.mem[_t_2 + 1] = _world_16;
      e.mem[_t_2 + 2] = _world_17;
      e.mem[_t_2 + 3] = _world_18;
      e.mem[_t_2 + 4] = _world_19;
      e.mem[_t_2 + 5] = _world_20;
      e.mem[_t_2 + 6] = _world_21;
      e.mem[_t_2 + 7] = _world_22;
      e.mem[_t_2 + 8] = _world_23;
      e.mem[_t_2 + 9] = _world_24;
      e.mem[_t_2 + 10] = _world_25;
      e.mem[_t_2 + 11] = _world_26;
      e.mem[_t_2 + 12] = _world_27;
      e.mem[_t_2 + 13] = _world_28;
      e.mem[_t_2 + 14] = _world_29;
      WL_CONT = term_tsk(FID_COMMANDS_QUEUE_OWNED_K385, _t_2);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _payload_1;
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _h_0;
    r1 = _payload_1;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_QUEUE_OWNED_K385)
  {
    WL_POPN(15);
    u32 _world_30 = STK(0);
    u32 _world_31 = STK(1);
    Term _world_32 = STK(2);
    Term _world_33 = STK(3);
    Term _world_34 = STK(4);
    Term _world_35 = STK(5);
    Term _world_36 = STK(6);
    Term _world_37 = STK(7);
    u32 _world_38 = STK(8);
    Term _world_39 = STK(9);
    u32 _world_40 = STK(10);
    Term _world_41 = STK(11);
    u32 _world_42 = STK(12);
    Term _world_43 = STK(13);
    Term _world_44 = STK(14);
    Term _h_1 = r0;
    WL_OPEN
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _o_1[15];
    Term _a_0 = term_ctr(CID_CON, _nd_0);
    if (spin_26(e, _o_1, _world_30, _world_31, _world_32, blk_loc(e.mem, _world_32), _world_33, blk_loc(e.mem, _world_33), _world_34, blk_loc(e.mem, _world_34), _world_35, blk_loc(e.mem, _world_35), _world_36, blk_loc(e.mem, _world_36), _world_37, blk_loc(e.mem, _world_37), _world_38, _world_39, _world_40, _world_41, blk_loc(e.mem, _world_41), _world_42, _world_43, blk_loc(e.mem, _world_43), _world_44, blk_loc(e.mem, _world_44), _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_45 = _o_1[0];
    _v_46 = _o_1[1];
    _v_47 = _o_1[2];
    _v_48 = _o_1[3];
    _v_49 = _o_1[4];
    _v_50 = _o_1[5];
    _v_51 = _o_1[6];
    _v_52 = _o_1[7];
    _v_53 = _o_1[8];
    _v_54 = _o_1[9];
    _v_55 = _o_1[10];
    _v_56 = _o_1[11];
    _v_57 = _o_1[12];
    _v_58 = _o_1[13];
    _v_59 = _o_1[14];
    _v_30 = _v_45;
    _v_31 = _v_46;
    _v_32 = _v_47;
    _v_33 = _v_48;
    _v_34 = _v_49;
    _v_35 = _v_50;
    _v_36 = _v_51;
    _v_37 = _v_52;
    _v_38 = _v_53;
    _v_39 = _v_54;
    _v_40 = _v_55;
    _v_41 = _v_56;
    _v_42 = _v_57;
    _v_43 = _v_58;
    _v_44 = _v_59;
    r0 = 0;
    r1 = _v_30;
    r2 = _v_31;
    r3 = _v_32;
    r4 = _v_33;
    r5 = _v_34;
    r6 = _v_35;
    r7 = _v_36;
    r8 = _v_37;
    r9 = _v_38;
    r10 = _v_39;
    r11 = _v_40;
    r12 = _v_41;
    r13 = _v_42;
    r14 = _v_43;
    r15 = _v_44;
    r16 = 0;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_COMMANDS_DESPAWN_K425;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_COMMANDS_DESPAWN_K425, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_COMMANDS_DESPAWN_K425, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_QUEUE_OWNED)) {
      u64 _t_1 = task_node(e, FID_COMMANDS_QUEUE_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _handle_0;
      e.mem[_t_1 + 16] = _handle_1;
      e.mem[_t_1 + 17] = term_pak(CID_UNIT, 0);
      e.mem[_t_1 + 18] = term_clo(FID_COMMANDS_DESPAWN_C423, 0);
      return term_tsk(FID_COMMANDS_QUEUE_OWNED, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _handle_0;
    r16 = _handle_1;
    r17 = term_pak(CID_UNIT, 0);
    r18 = term_clo(FID_COMMANDS_DESPAWN_C423, 0);
    WL_JMP(FID_COMMANDS_QUEUE_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN_C423)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _x_0;
    r0 = term_clo(FID_COMMANDS_DESPAWN_C424, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN_C424)
  {
    u32 _x_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_45(e, _o_0, _x_2) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
      e.mem[_nd_1 + 5] = rfc_seal(e, _v_6);
      e.mem[_nd_1 + 6] = rfc_seal(e, _v_7);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
    } else if (_v_0 == 1) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
    } else if (_v_0 == 2) {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _v_2);
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
    } else if (_v_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _v_1);
    } else if (_v_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _v_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _v_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_DESPAWN_K425)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    u32 _r_9 = r9;
    Term _r_10 = r10;
    u32 _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    Term _r_14 = r14;
    Term _r_15 = r15;
    Term _r_16 = r16;
    WL_OPEN
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    u32 _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    Term _o_11 = 0;
    u32 _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    if (_r_0 == 0) {
      _o_1 = 0;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    } else {
      _o_1 = 1;
      _o_2 = _r_1;
      _o_3 = _r_2;
      _o_4 = _r_3;
      _o_5 = _r_4;
      _o_6 = _r_5;
      _o_7 = _r_6;
      _o_8 = _r_7;
      _o_9 = _r_8;
      _o_10 = _r_9;
      _o_11 = _r_10;
      _o_12 = _r_11;
      _o_13 = _r_12;
      _o_14 = _r_13;
      _o_15 = _r_14;
      _o_16 = _r_15;
    }
    r0 = _o_1;
    r1 = _o_2;
    r2 = _o_3;
    r3 = _o_4;
    r4 = _o_5;
    r5 = _o_6;
    r6 = _o_7;
    r7 = _o_8;
    r8 = _o_9;
    r9 = _o_10;
    r10 = _o_11;
    r11 = _o_12;
    r12 = _o_13;
    r13 = _o_14;
    r14 = _o_15;
    r15 = _o_16;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SEEDED_RESULT)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    u32 _result_2 = r2;
    Term _result_3 = r3;
    Term _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    Term _result_8 = r8;
    u32 _result_9 = r9;
    Term _result_10 = r10;
    u32 _result_11 = r11;
    Term _result_12 = r12;
    u32 _result_13 = r13;
    Term _result_14 = r14;
    Term _continue_world_0 = r15;
    WL_OPEN
    if (_result_0 == 0) {
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (_result_13 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        _o_1 = term_pak(CID_UNIT, 0);
      }
      u64 _nd_0 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_0 + 0] = rfc_seal(e, _result_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _result_2);
      e.mem[_nd_0 + 2] = rfc_seal(e, _result_3);
      e.mem[_nd_0 + 3] = rfc_seal(e, _result_4);
      e.mem[_nd_0 + 4] = rfc_seal(e, _result_5);
      e.mem[_nd_0 + 5] = rfc_seal(e, _result_6);
      e.mem[_nd_0 + 6] = rfc_seal(e, _result_7);
      e.mem[_nd_0 + 7] = rfc_seal(e, _result_8);
      e.mem[_nd_0 + 8] = rfc_seal(e, _result_9);
      e.mem[_nd_0 + 9] = rfc_seal(e, _result_10);
      e.mem[_nd_0 + 10] = rfc_seal(e, _result_11);
      e.mem[_nd_0 + 11] = rfc_seal(e, _result_12);
      e.mem[_nd_0 + 12] = rfc_seal(e, _o_0);
      e.mem[_nd_0 + 13] = rfc_seal(e, _o_1);
      e.mem[_nd_0 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _continue_world_0;
        e.mem[_t_0 + 1] = term_ctr(CID_STORAGE_WORLD, _nd_0);
        return term_tsk(FID_CLO_APPLY, _t_0);
      }
      r0 = _continue_world_0;
      r1 = term_ctr(CID_STORAGE_WORLD, _nd_0);
      WL_JMP(FID_CLO_APPLY);
    } else {
      term_sink(e, _result_3);
      term_sink(e, _result_4);
      term_sink(e, _result_5);
      term_sink(e, _result_6);
      term_sink(e, _result_7);
      term_sink(e, _result_8);
      term_sink(e, _result_12);
      term_sink(e, _result_14);
      term_sink(e, _continue_world_0);
      r0 = term_ctr(CID_SCON, STAT_OFF + 148);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    u32 _row_0 = r9;
    u32 _row_1 = r10;
    Term _row_2 = r11;
    u32 _row_3 = r12;
    Term _row_4 = r13;
    u32 _row_5 = r14;
    Term _row_6 = r15;
    u32 _row_7 = r16;
    u32 _row_8 = r17;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_7(e, _o_0, U32_BIN(0ull, <, _row_0), U32_BIN(_row_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (_v_0 == 0) {
      r0 = 1;
      r1 = _rows_0;
      r2 = _rows_1;
      r3 = _rows_2;
      r4 = _rows_3;
      r5 = _rows_4;
      r6 = _rows_5;
      r7 = _rows_6;
      r8 = _rows_7;
      r9 = _rows_8;
      r10 = _row_0;
      r11 = _row_1;
      r12 = _row_2;
      r13 = _row_3;
      r14 = _row_4;
      r15 = _row_5;
      r16 = _row_6;
      r17 = _row_7;
      r18 = _row_8;
      WL_RETN(19);
    } else {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _row_0;
        STK(1) = _row_1;
        STK(2) = _row_2;
        STK(3) = _row_3;
        STK(4) = _row_4;
        STK(5) = _row_5;
        STK(6) = _row_6;
        STK(7) = _row_7;
        STK(8) = _row_8;
        STK(9) = FID_STORAGE_ROWS_PLACE_K433;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_ROWS_PLACE_K433, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _row_0;
        e.mem[_t_0 + 1] = _row_1;
        e.mem[_t_0 + 2] = _row_2;
        e.mem[_t_0 + 3] = _row_3;
        e.mem[_t_0 + 4] = _row_4;
        e.mem[_t_0 + 5] = _row_5;
        e.mem[_t_0 + 6] = _row_6;
        e.mem[_t_0 + 7] = _row_7;
        e.mem[_t_0 + 8] = _row_8;
        WL_CONT = term_tsk(FID_STORAGE_ROWS_PLACE_K433, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
        u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = 17ull;
        e.mem[_t_1 + 1] = _row_0;
        e.mem[_t_1 + 2] = _rows_0;
        e.mem[_t_1 + 3] = _rows_1;
        e.mem[_t_1 + 4] = _rows_2;
        e.mem[_t_1 + 5] = _rows_3;
        e.mem[_t_1 + 6] = _rows_4;
        e.mem[_t_1 + 7] = _rows_5;
        e.mem[_t_1 + 8] = _rows_6;
        e.mem[_t_1 + 9] = _rows_7;
        e.mem[_t_1 + 10] = _rows_8;
        return term_tsk(FID_STORAGE_GROW, _t_1);
      }
      r0 = 17ull;
      r1 = _row_0;
      r2 = _rows_0;
      r3 = _rows_1;
      r4 = _rows_2;
      r5 = _rows_3;
      r6 = _rows_4;
      r7 = _rows_5;
      r8 = _rows_6;
      r9 = _rows_7;
      r10 = _rows_8;
      WL_JMP(FID_STORAGE_GROW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE_K433)
  {
    WL_POPN(9);
    u32 _row_9 = STK(0);
    u32 _row_10 = STK(1);
    Term _row_11 = STK(2);
    u32 _row_12 = STK(3);
    Term _row_13 = STK(4);
    u32 _row_14 = STK(5);
    Term _row_15 = STK(6);
    u32 _row_16 = STK(7);
    u32 _row_17 = STK(8);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _o_1[19];
    if (spin_44(e, _o_1, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, _row_9, _row_10, _row_11, blk_loc(e.mem, _row_11), _row_12, _row_13, blk_loc(e.mem, _row_13), _row_14, _row_15, blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    _v_3 = _o_1[1];
    _v_4 = _o_1[2];
    _v_5 = _o_1[3];
    _v_6 = _o_1[4];
    _v_7 = _o_1[5];
    _v_8 = _o_1[6];
    _v_9 = _o_1[7];
    _v_10 = _o_1[8];
    _v_11 = _o_1[9];
    _v_12 = _o_1[10];
    _v_13 = _o_1[11];
    _v_14 = _o_1[12];
    _v_15 = _o_1[13];
    _v_16 = _o_1[14];
    _v_17 = _o_1[15];
    _v_18 = _o_1[16];
    _v_19 = _o_1[17];
    _v_20 = _o_1[18];
    r0 = _v_2;
    r1 = _v_3;
    r2 = _v_4;
    r3 = _v_5;
    r4 = _v_6;
    r5 = _v_7;
    r6 = _v_8;
    r7 = _v_9;
    r8 = _v_10;
    r9 = _v_11;
    r10 = _v_12;
    r11 = _v_13;
    r12 = _v_14;
    r13 = _v_15;
    r14 = _v_16;
    r15 = _v_17;
    r16 = _v_18;
    r17 = _v_19;
    r18 = _v_20;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT)
  {
    Term _n_0 = r0;
    u32 _i_0 = r1;
    Term _text_0 = r2;
    Term _owner_0 = r3;
    WL_OPEN
    if (_n_0 == 0) {
      r0 = _owner_0;
      r1 = _text_0;
      WL_RETN(2);
    } else {
      Term _tail_0 = (_n_0 - 1);
      Term _at_0 = blk_loc(e.mem, _owner_0);
      Term _at_1 = blk_at(_owner_0, _i_0, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _tail_0;
      e.mem[_nd_0 + 1] = _i_0;
      Term _continue_owner_0 = term_clo(FID_ARR_TEXT_C512, _nd_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _text_0;
        STK(1) = _c_0;
        STK(2) = FID_ARR_TEXT_K515;
        WL_PUSHN(3);
      } else {
        u64 _t_2 = task_node(e, FID_ARR_TEXT_K515, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _text_0;
        e.mem[_t_2 + 1] = _c_0;
        WL_CONT = term_tsk(FID_ARR_TEXT_K515, _t_2);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _continue_owner_0;
        e.mem[_t_3 + 1] = _owner_0;
        return term_tsk(FID_CLO_APPLY, _t_3);
      }
      r0 = _continue_owner_0;
      r1 = _owner_0;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_C512)
  {
    Term _tail_1 = r0;
    u32 _i_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = _tail_1;
    e.mem[_nd_1 + 1] = _i_1;
    e.mem[_nd_1 + 2] = _x_0;
    r0 = term_clo(FID_ARR_TEXT_C513, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_C513)
  {
    Term _tail_2 = r0;
    u32 _i_2 = r1;
    Term _x_2 = r2;
    Term _x_1 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ARR_TEXT_K514;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_ARR_TEXT_K514, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ARR_TEXT_K514, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARR_TEXT)) {
      u64 _t_1 = task_node(e, FID_ARR_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _tail_2;
      e.mem[_t_1 + 1] = U32_BIN(_i_2, +, 1ull);
      e.mem[_t_1 + 2] = _x_1;
      e.mem[_t_1 + 3] = _x_2;
      return term_tsk(FID_ARR_TEXT, _t_1);
    }
    r0 = _tail_2;
    r1 = U32_BIN(_i_2, +, 1ull);
    r2 = _x_1;
    r3 = _x_2;
    WL_JMP(FID_ARR_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_K514)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _r_1);
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_K515)
  {
    WL_POPN(2);
    Term _text_1 = STK(0);
    u32 _c_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _text_1;
      STK(1) = _h_0;
      STK(2) = FID_ARR_TEXT_K516;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_ARR_TEXT_K516, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _text_1;
      e.mem[_t_4 + 1] = _h_0;
      WL_CONT = term_tsk(FID_ARR_TEXT_K516, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _c_1;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _c_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_K516)
  {
    WL_POPN(2);
    Term _text_2 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _text_2;
      STK(1) = _h_2;
      STK(2) = FID_ARR_TEXT_K517;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_ARR_TEXT_K517, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _text_2;
      e.mem[_t_6 + 1] = _h_2;
      WL_CONT = term_tsk(FID_ARR_TEXT_K517, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_1;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 150);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 150);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_K517)
  {
    WL_POPN(2);
    Term _text_3 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_4;
      STK(1) = FID_ARR_TEXT_K518;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_ARR_TEXT_K518, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_4;
      WL_CONT = term_tsk(FID_ARR_TEXT_K518, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _text_3;
      e.mem[_t_9 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _text_3;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_K518)
  {
    WL_POPN(1);
    Term _h_6 = STK(0);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ARR_TEXT_K519;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_ARR_TEXT_K519, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ARR_TEXT_K519, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_11 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_6;
      e.mem[_t_11 + 1] = _h_5;
      return term_tsk(FID_CLO_APPLY, _t_11);
    }
    r0 = _h_6;
    r1 = _h_5;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_TEXT_K519)
  {
    Term _r_2 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _r_2, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    r0 = _f_0;
    r1 = _f_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_TEXT)
  {
    Term _depth_0 = r0;
    u32 _main_0 = r1;
    Term _main_1 = r2;
    u32 _main_2 = r3;
    u32 _main_3 = r4;
    u32 _main_4 = r5;
    u32 _main_5 = r6;
    u32 _main_6 = r7;
    u32 _main_7 = r8;
    u32 _main_8 = r9;
    u32 _main_9 = r10;
    WL_OPEN
    if (_main_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = term_ctr(CID_SCON, STAT_OFF + 192);
      WL_RETN(11);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_MAIN_TEXT_K547;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_MAIN_TEXT_K547, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_MAIN_TEXT_K547, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SLOT_TEXT)) {
        u64 _t_1 = task_node(e, FID_SLOT_TEXT, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _depth_0;
        e.mem[_t_1 + 1] = _main_1;
        e.mem[_t_1 + 2] = _main_2;
        e.mem[_t_1 + 3] = _main_3;
        e.mem[_t_1 + 4] = _main_4;
        e.mem[_t_1 + 5] = _main_5;
        e.mem[_t_1 + 6] = _main_6;
        e.mem[_t_1 + 7] = _main_7;
        e.mem[_t_1 + 8] = _main_8;
        e.mem[_t_1 + 9] = _main_9;
        return term_tsk(FID_SLOT_TEXT, _t_1);
      }
      r0 = _depth_0;
      r1 = _main_1;
      r2 = _main_2;
      r3 = _main_3;
      r4 = _main_4;
      r5 = _main_5;
      r6 = _main_6;
      r7 = _main_7;
      r8 = _main_8;
      r9 = _main_9;
      WL_JMP(FID_SLOT_TEXT);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_TEXT_K547)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _o_0[11];
    if (spin_54(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, _h_3, _h_4, _h_5, _h_6, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP)
  {
    u32 _namespace_0 = r0;
    u32 _tick_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    u32 _command_0 = r11;
    u32 _command_1 = r12;
    Term _command_2 = r13;
    Term _command_3 = r14;
    u32 _command_4 = r15;
    Term _command_5 = r16;
    u32 _command_6 = r17;
    Term _command_7 = r18;
    WL_OPEN
    if (_command_0 == 0) {
      if (_command_2 == 0) {
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_COMMANDS_STEP_K555;
          WL_PUSHN(1);
        } else {
          u64 _t_0 = task_node(e, FID_COMMANDS_STEP_K555, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_COMMANDS_STEP_K555, _t_0);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
          u64 _t_1 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _rows_0;
          e.mem[_t_1 + 1] = _rows_1;
          e.mem[_t_1 + 2] = _rows_2;
          e.mem[_t_1 + 3] = _rows_3;
          e.mem[_t_1 + 4] = _rows_4;
          e.mem[_t_1 + 5] = _rows_5;
          e.mem[_t_1 + 6] = _rows_6;
          e.mem[_t_1 + 7] = _rows_7;
          e.mem[_t_1 + 8] = _rows_8;
          e.mem[_t_1 + 9] = _command_1;
          e.mem[_t_1 + 10] = 0;
          e.mem[_t_1 + 11] = 0;
          e.mem[_t_1 + 12] = _command_4;
          e.mem[_t_1 + 13] = _command_5;
          e.mem[_t_1 + 14] = _command_6;
          e.mem[_t_1 + 15] = _command_7;
          e.mem[_t_1 + 16] = 0ull;
          e.mem[_t_1 + 17] = 0ull;
          return term_tsk(FID_STORAGE_ROWS_PLACE, _t_1);
        }
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        r9 = _command_1;
        r10 = 0;
        r11 = 0;
        r12 = _command_4;
        r13 = _command_5;
        r14 = _command_6;
        r15 = _command_7;
        r16 = 0ull;
        r17 = 0ull;
        WL_JMP(FID_STORAGE_ROWS_PLACE);
      } else {
        if (seq) {
          WL_ROOM(3);
          STK(0) = _namespace_0;
          STK(1) = _command_1;
          STK(2) = FID_COMMANDS_STEP_K556;
          WL_PUSHN(3);
        } else {
          u64 _t_2 = task_node(e, FID_COMMANDS_STEP_K556, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _namespace_0;
          e.mem[_t_2 + 1] = _command_1;
          WL_CONT = term_tsk(FID_COMMANDS_STEP_K556, _t_2);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
          u64 _t_3 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_0;
          e.mem[_t_3 + 1] = _rows_1;
          e.mem[_t_3 + 2] = _rows_2;
          e.mem[_t_3 + 3] = _rows_3;
          e.mem[_t_3 + 4] = _rows_4;
          e.mem[_t_3 + 5] = _rows_5;
          e.mem[_t_3 + 6] = _rows_6;
          e.mem[_t_3 + 7] = _rows_7;
          e.mem[_t_3 + 8] = _rows_8;
          e.mem[_t_3 + 9] = _command_1;
          e.mem[_t_3 + 10] = 1;
          e.mem[_t_3 + 11] = _command_3;
          e.mem[_t_3 + 12] = _command_4;
          e.mem[_t_3 + 13] = _command_5;
          e.mem[_t_3 + 14] = _command_6;
          e.mem[_t_3 + 15] = _command_7;
          e.mem[_t_3 + 16] = _tick_0;
          e.mem[_t_3 + 17] = _tick_0;
          return term_tsk(FID_STORAGE_ROWS_PLACE, _t_3);
        }
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        r9 = _command_1;
        r10 = 1;
        r11 = _command_3;
        r12 = _command_4;
        r13 = _command_5;
        r14 = _command_6;
        r15 = _command_7;
        r16 = _tick_0;
        r17 = _tick_0;
        WL_JMP(FID_STORAGE_ROWS_PLACE);
      }
    } else if (_command_0 == 1) {
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      Term _o_5[10];
      if (spin_56(e, _o_5, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1, 1, _command_2, blk_loc(e.mem, _command_2), _tick_0) == 0) {
        return 0;
      }
      _v_48 = _o_5[0];
      _v_49 = _o_5[1];
      _v_50 = _o_5[2];
      _v_51 = _o_5[3];
      _v_52 = _o_5[4];
      _v_53 = _o_5[5];
      _v_54 = _o_5[6];
      _v_55 = _o_5[7];
      _v_56 = _o_5[8];
      _v_57 = _o_5[9];
      _v_38 = _v_48;
      _v_39 = _v_49;
      _v_40 = _v_50;
      _v_41 = _v_51;
      _v_42 = _v_52;
      _v_43 = _v_53;
      _v_44 = _v_54;
      _v_45 = _v_55;
      _v_46 = _v_56;
      _v_47 = _v_57;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      Term _v_85 = 0;
      Term _v_86 = 0;
      Term _v_87 = 0;
      Term _v_88 = 0;
      u32 _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      u32 _v_93 = 0;
      Term _v_94 = 0;
      u32 _v_95 = 0;
      Term _v_96 = 0;
      u32 _v_97 = 0;
      Term _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _o_6[19];
      if (spin_57(e, _o_6, _namespace_0, _command_1, _v_38, blk_loc(e.mem, _v_38), _v_39, blk_loc(e.mem, _v_39), _v_40, blk_loc(e.mem, _v_40), _v_41, blk_loc(e.mem, _v_41), _v_42, blk_loc(e.mem, _v_42), _v_43, blk_loc(e.mem, _v_43), _v_44, _v_45, _v_46, _v_47) == 0) {
        return 0;
      }
      _v_82 = _o_6[0];
      _v_83 = _o_6[1];
      _v_84 = _o_6[2];
      _v_85 = _o_6[3];
      _v_86 = _o_6[4];
      _v_87 = _o_6[5];
      _v_88 = _o_6[6];
      _v_89 = _o_6[7];
      _v_90 = _o_6[8];
      _v_91 = _o_6[9];
      _v_92 = _o_6[10];
      _v_93 = _o_6[11];
      _v_94 = _o_6[12];
      _v_95 = _o_6[13];
      _v_96 = _o_6[14];
      _v_97 = _o_6[15];
      _v_98 = _o_6[16];
      _v_99 = _o_6[17];
      _v_100 = _o_6[18];
      r0 = _v_82;
      r1 = _v_83;
      r2 = _v_84;
      r3 = _v_85;
      r4 = _v_86;
      r5 = _v_87;
      r6 = _v_88;
      r7 = _v_89;
      r8 = _v_90;
      r9 = _v_91;
      r10 = _v_92;
      r11 = _v_93;
      r12 = _v_94;
      r13 = _v_95;
      r14 = _v_96;
      r15 = _v_97;
      r16 = _v_98;
      r17 = _v_99;
      r18 = _v_100;
      WL_RETN(19);
    } else if (_command_0 == 3) {
      Term _v_120 = 0;
      Term _v_121 = 0;
      Term _v_122 = 0;
      Term _v_123 = 0;
      Term _v_124 = 0;
      Term _v_125 = 0;
      u32 _v_126 = 0;
      Term _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      Term _v_134 = 0;
      Term _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      u32 _v_139 = 0;
      Term _o_7[10];
      Term _a_2 = 0;
      if (spin_56(e, _o_7, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _command_1, 0, _a_2, blk_loc(e.mem, _a_2), _tick_0) == 0) {
        return 0;
      }
      _v_130 = _o_7[0];
      _v_131 = _o_7[1];
      _v_132 = _o_7[2];
      _v_133 = _o_7[3];
      _v_134 = _o_7[4];
      _v_135 = _o_7[5];
      _v_136 = _o_7[6];
      _v_137 = _o_7[7];
      _v_138 = _o_7[8];
      _v_139 = _o_7[9];
      _v_120 = _v_130;
      _v_121 = _v_131;
      _v_122 = _v_132;
      _v_123 = _v_133;
      _v_124 = _v_134;
      _v_125 = _v_135;
      _v_126 = _v_136;
      _v_127 = _v_137;
      _v_128 = _v_138;
      _v_129 = _v_139;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      Term _v_142 = 0;
      Term _v_143 = 0;
      Term _v_144 = 0;
      Term _v_145 = 0;
      Term _v_146 = 0;
      u32 _v_147 = 0;
      Term _v_148 = 0;
      u32 _v_149 = 0;
      Term _v_150 = 0;
      u32 _v_151 = 0;
      Term _v_152 = 0;
      u32 _v_153 = 0;
      Term _v_154 = 0;
      u32 _v_155 = 0;
      Term _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      Term _o_8[19];
      if (spin_57(e, _o_8, _namespace_0, _command_1, _v_120, blk_loc(e.mem, _v_120), _v_121, blk_loc(e.mem, _v_121), _v_122, blk_loc(e.mem, _v_122), _v_123, blk_loc(e.mem, _v_123), _v_124, blk_loc(e.mem, _v_124), _v_125, blk_loc(e.mem, _v_125), _v_126, _v_127, _v_128, _v_129) == 0) {
        return 0;
      }
      _v_140 = _o_8[0];
      _v_141 = _o_8[1];
      _v_142 = _o_8[2];
      _v_143 = _o_8[3];
      _v_144 = _o_8[4];
      _v_145 = _o_8[5];
      _v_146 = _o_8[6];
      _v_147 = _o_8[7];
      _v_148 = _o_8[8];
      _v_149 = _o_8[9];
      _v_150 = _o_8[10];
      _v_151 = _o_8[11];
      _v_152 = _o_8[12];
      _v_153 = _o_8[13];
      _v_154 = _o_8[14];
      _v_155 = _o_8[15];
      _v_156 = _o_8[16];
      _v_157 = _o_8[17];
      _v_158 = _o_8[18];
      r0 = _v_140;
      r1 = _v_141;
      r2 = _v_142;
      r3 = _v_143;
      r4 = _v_144;
      r5 = _v_145;
      r6 = _v_146;
      r7 = _v_147;
      r8 = _v_148;
      r9 = _v_149;
      r10 = _v_150;
      r11 = _v_151;
      r12 = _v_152;
      r13 = _v_153;
      r14 = _v_154;
      r15 = _v_155;
      r16 = _v_156;
      r17 = _v_157;
      r18 = _v_158;
      WL_RETN(19);
    } else {
      u32 _v_159 = 0;
      u32 _v_160 = 0;
      Term _v_161 = 0;
      Term _v_162 = 0;
      u32 _v_163 = 0;
      Term _v_164 = 0;
      u32 _v_165 = 0;
      Term _v_166 = 0;
      u32 _v_167 = 0;
      u32 _v_168 = 0;
      u32 _v_169 = 0;
      Term _v_170 = 0;
      Term _v_171 = 0;
      u32 _v_172 = 0;
      Term _v_173 = 0;
      u32 _v_174 = 0;
      Term _v_175 = 0;
      u32 _v_176 = 0;
      Term _o_9[9];
      if (spin_58(e, _o_9, _command_0, _command_1, _command_2, blk_loc(e.mem, _command_2), _command_3, blk_loc(e.mem, _command_3), _command_4, _command_5, blk_loc(e.mem, _command_5), _command_6, _command_7, blk_loc(e.mem, _command_7)) == 0) {
        return 0;
      }
      _v_168 = _o_9[0];
      _v_169 = _o_9[1];
      _v_170 = _o_9[2];
      _v_171 = _o_9[3];
      _v_172 = _o_9[4];
      _v_173 = _o_9[5];
      _v_174 = _o_9[6];
      _v_175 = _o_9[7];
      _v_176 = _o_9[8];
      _v_159 = _v_168;
      _v_160 = _v_169;
      _v_161 = _v_170;
      _v_162 = _v_171;
      _v_163 = _v_172;
      _v_164 = _v_173;
      _v_165 = _v_174;
      _v_166 = _v_175;
      _v_167 = _v_176;
      u32 _v_186 = 0;
      Term _v_187 = 0;
      Term _v_188 = 0;
      Term _v_189 = 0;
      Term _v_190 = 0;
      Term _v_191 = 0;
      Term _v_192 = 0;
      u32 _v_193 = 0;
      Term _v_194 = 0;
      u32 _v_195 = 0;
      Term _v_196 = 0;
      u32 _v_197 = 0;
      Term _v_198 = 0;
      u32 _v_199 = 0;
      Term _v_200 = 0;
      u32 _v_201 = 0;
      Term _v_202 = 0;
      u32 _v_203 = 0;
      u32 _v_204 = 0;
      Term _o_12[19];
      if (spin_59(e, _o_12, _namespace_0, _tick_0, _rows_0, blk_loc(e.mem, _rows_0), _rows_1, blk_loc(e.mem, _rows_1), _rows_2, blk_loc(e.mem, _rows_2), _rows_3, blk_loc(e.mem, _rows_3), _rows_4, blk_loc(e.mem, _rows_4), _rows_5, blk_loc(e.mem, _rows_5), _rows_6, _rows_7, _rows_8, _v_159, _v_160, _v_161, blk_loc(e.mem, _v_161), _v_162, blk_loc(e.mem, _v_162), _v_163, _v_164, blk_loc(e.mem, _v_164), _v_165, _v_166, blk_loc(e.mem, _v_166), _v_167) == 0) {
        return 0;
      }
      _v_186 = _o_12[0];
      _v_187 = _o_12[1];
      _v_188 = _o_12[2];
      _v_189 = _o_12[3];
      _v_190 = _o_12[4];
      _v_191 = _o_12[5];
      _v_192 = _o_12[6];
      _v_193 = _o_12[7];
      _v_194 = _o_12[8];
      _v_195 = _o_12[9];
      _v_196 = _o_12[10];
      _v_197 = _o_12[11];
      _v_198 = _o_12[12];
      _v_199 = _o_12[13];
      _v_200 = _o_12[14];
      _v_201 = _o_12[15];
      _v_202 = _o_12[16];
      _v_203 = _o_12[17];
      _v_204 = _o_12[18];
      r0 = _v_186;
      r1 = _v_187;
      r2 = _v_188;
      r3 = _v_189;
      r4 = _v_190;
      r5 = _v_191;
      r6 = _v_192;
      r7 = _v_193;
      r8 = _v_194;
      r9 = _v_195;
      r10 = _v_196;
      r11 = _v_197;
      r12 = _v_198;
      r13 = _v_199;
      r14 = _v_200;
      r15 = _v_201;
      r16 = _v_202;
      r17 = _v_203;
      r18 = _v_204;
      WL_RETN(19);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP_K555)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _o_0[19];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_53(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STEP_K556)
  {
    WL_POPN(2);
    u32 _namespace_1 = STK(0);
    u32 _command_8 = STK(1);
    u32 _h_19 = r0;
    Term _h_20 = r1;
    Term _h_21 = r2;
    Term _h_22 = r3;
    Term _h_23 = r4;
    Term _h_24 = r5;
    Term _h_25 = r6;
    u32 _h_26 = r7;
    Term _h_27 = r8;
    u32 _h_28 = r9;
    u32 _h_29 = r10;
    u32 _h_30 = r11;
    Term _h_31 = r12;
    u32 _h_32 = r13;
    Term _h_33 = r14;
    u32 _h_34 = r15;
    Term _h_35 = r16;
    u32 _h_36 = r17;
    u32 _h_37 = r18;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _command_8);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, _command_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINCHANGED, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_STORAGE_MAINADDED, _nd_0));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_1[19];
    Term _a_1 = term_ctr(CID_CON, _nd_3);
    if (spin_53(e, _o_1, _a_1, blk_loc(e.mem, _a_1), _h_19, _h_20, blk_loc(e.mem, _h_20), _h_21, blk_loc(e.mem, _h_21), _h_22, blk_loc(e.mem, _h_22), _h_23, blk_loc(e.mem, _h_23), _h_24, blk_loc(e.mem, _h_24), _h_25, blk_loc(e.mem, _h_25), _h_26, _h_27, _h_28, _h_29, _h_30, _h_31, blk_loc(e.mem, _h_31), _h_32, _h_33, blk_loc(e.mem, _h_33), _h_34, _h_35, blk_loc(e.mem, _h_35), _h_36, _h_37) == 0) {
      return 0;
    }
    _v_19 = _o_1[0];
    _v_20 = _o_1[1];
    _v_21 = _o_1[2];
    _v_22 = _o_1[3];
    _v_23 = _o_1[4];
    _v_24 = _o_1[5];
    _v_25 = _o_1[6];
    _v_26 = _o_1[7];
    _v_27 = _o_1[8];
    _v_28 = _o_1[9];
    _v_29 = _o_1[10];
    _v_30 = _o_1[11];
    _v_31 = _o_1[12];
    _v_32 = _o_1[13];
    _v_33 = _o_1[14];
    _v_34 = _o_1[15];
    _v_35 = _o_1[16];
    _v_36 = _o_1[17];
    _v_37 = _o_1[18];
    r0 = _v_19;
    r1 = _v_20;
    r2 = _v_21;
    r3 = _v_22;
    r4 = _v_23;
    r5 = _v_24;
    r6 = _v_25;
    r7 = _v_26;
    r8 = _v_27;
    r9 = _v_28;
    r10 = _v_29;
    r11 = _v_30;
    r12 = _v_31;
    r13 = _v_32;
    r14 = _v_33;
    r15 = _v_34;
    r16 = _v_35;
    r17 = _v_36;
    r18 = _v_37;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT)
  {
    Term _depth_0 = r0;
    Term _main_0 = r1;
    u32 _main_1 = r2;
    u32 _main_2 = r3;
    u32 _main_3 = r4;
    u32 _main_4 = r5;
    u32 _main_5 = r6;
    u32 _main_6 = r7;
    u32 _main_7 = r8;
    u32 _main_8 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _main_0;
      STK(1) = _main_1;
      STK(2) = _main_2;
      STK(3) = _main_3;
      STK(4) = _main_4;
      STK(5) = _main_5;
      STK(6) = _main_6;
      STK(7) = _main_7;
      STK(8) = _main_8;
      STK(9) = FID_SLOT_TEXT_K590;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID_SLOT_TEXT_K590, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _main_0;
      e.mem[_t_0 + 1] = _main_1;
      e.mem[_t_0 + 2] = _main_2;
      e.mem[_t_0 + 3] = _main_3;
      e.mem[_t_0 + 4] = _main_4;
      e.mem[_t_0 + 5] = _main_5;
      e.mem[_t_0 + 6] = _main_6;
      e.mem[_t_0 + 7] = _main_7;
      e.mem[_t_0 + 8] = _main_8;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K590, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_POW)) {
      u64 _t_1 = task_node(e, FID_U32_POW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 2ull;
      e.mem[_t_1 + 1] = _depth_0;
      return term_tsk(FID_U32_POW, _t_1);
    }
    r0 = 2ull;
    r1 = _depth_0;
    WL_JMP(FID_U32_POW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K590)
  {
    WL_POPN(9);
    Term _main_9 = STK(0);
    u32 _main_10 = STK(1);
    u32 _main_11 = STK(2);
    u32 _main_12 = STK(3);
    u32 _main_13 = STK(4);
    u32 _main_14 = STK(5);
    u32 _main_15 = STK(6);
    u32 _main_16 = STK(7);
    u32 _main_17 = STK(8);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _main_10;
      STK(1) = _main_11;
      STK(2) = _main_12;
      STK(3) = _main_13;
      STK(4) = _main_14;
      STK(5) = _main_15;
      STK(6) = _main_16;
      STK(7) = _main_17;
      STK(8) = FID_SLOT_TEXT_K591;
      WL_PUSHN(9);
    } else {
      u64 _t_2 = task_node(e, FID_SLOT_TEXT_K591, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _main_10;
      e.mem[_t_2 + 1] = _main_11;
      e.mem[_t_2 + 2] = _main_12;
      e.mem[_t_2 + 3] = _main_13;
      e.mem[_t_2 + 4] = _main_14;
      e.mem[_t_2 + 5] = _main_15;
      e.mem[_t_2 + 6] = _main_16;
      e.mem[_t_2 + 7] = _main_17;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K591, _t_2);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARR_TEXT)) {
      u64 _t_3 = task_node(e, FID_ARR_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = ((u64)_h_0);
      e.mem[_t_3 + 1] = 0ull;
      e.mem[_t_3 + 2] = term_pak(CID_SNIL, 0);
      e.mem[_t_3 + 3] = _main_9;
      return term_tsk(FID_ARR_TEXT, _t_3);
    }
    r0 = ((u64)_h_0);
    r1 = 0ull;
    r2 = term_pak(CID_SNIL, 0);
    r3 = _main_9;
    WL_JMP(FID_ARR_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K591)
  {
    WL_POPN(8);
    u32 _main_18 = STK(0);
    u32 _main_19 = STK(1);
    u32 _main_20 = STK(2);
    u32 _main_21 = STK(3);
    u32 _main_22 = STK(4);
    u32 _main_23 = STK(5);
    u32 _main_24 = STK(6);
    u32 _main_25 = STK(7);
    Term _h_1 = r0;
    Term _h_2 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _main_18;
      STK(1) = _main_19;
      STK(2) = _main_20;
      STK(3) = _main_21;
      STK(4) = _main_22;
      STK(5) = _main_23;
      STK(6) = _main_24;
      STK(7) = _main_25;
      STK(8) = _h_1;
      STK(9) = _h_2;
      STK(10) = FID_SLOT_TEXT_K592;
      WL_PUSHN(11);
    } else {
      u64 _t_4 = task_node(e, FID_SLOT_TEXT_K592, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _main_18;
      e.mem[_t_4 + 1] = _main_19;
      e.mem[_t_4 + 2] = _main_20;
      e.mem[_t_4 + 3] = _main_21;
      e.mem[_t_4 + 4] = _main_22;
      e.mem[_t_4 + 5] = _main_23;
      e.mem[_t_4 + 6] = _main_24;
      e.mem[_t_4 + 7] = _main_25;
      e.mem[_t_4 + 8] = _h_1;
      e.mem[_t_4 + 9] = _h_2;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K592, _t_4);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _main_18;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _main_18;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K592)
  {
    WL_POPN(10);
    u32 _main_26 = STK(0);
    u32 _main_27 = STK(1);
    u32 _main_28 = STK(2);
    u32 _main_29 = STK(3);
    u32 _main_30 = STK(4);
    u32 _main_31 = STK(5);
    u32 _main_32 = STK(6);
    u32 _main_33 = STK(7);
    Term _h_4 = STK(8);
    Term _h_5 = STK(9);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _main_26;
      STK(1) = _main_27;
      STK(2) = _main_28;
      STK(3) = _main_29;
      STK(4) = _main_30;
      STK(5) = _main_31;
      STK(6) = _main_32;
      STK(7) = _main_33;
      STK(8) = _h_4;
      STK(9) = _h_5;
      STK(10) = _h_3;
      STK(11) = FID_SLOT_TEXT_K593;
      WL_PUSHN(12);
    } else {
      u64 _t_6 = task_node(e, FID_SLOT_TEXT_K593, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _main_26;
      e.mem[_t_6 + 1] = _main_27;
      e.mem[_t_6 + 2] = _main_28;
      e.mem[_t_6 + 3] = _main_29;
      e.mem[_t_6 + 4] = _main_30;
      e.mem[_t_6 + 5] = _main_31;
      e.mem[_t_6 + 6] = _main_32;
      e.mem[_t_6 + 7] = _main_33;
      e.mem[_t_6 + 8] = _h_4;
      e.mem[_t_6 + 9] = _h_5;
      e.mem[_t_6 + 10] = _h_3;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K593, _t_6);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _main_27;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _main_27;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K593)
  {
    WL_POPN(11);
    u32 _main_34 = STK(0);
    u32 _main_35 = STK(1);
    u32 _main_36 = STK(2);
    u32 _main_37 = STK(3);
    u32 _main_38 = STK(4);
    u32 _main_39 = STK(5);
    u32 _main_40 = STK(6);
    u32 _main_41 = STK(7);
    Term _h_7 = STK(8);
    Term _h_8 = STK(9);
    Term _h_9 = STK(10);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _main_34;
      STK(1) = _main_35;
      STK(2) = _main_36;
      STK(3) = _main_37;
      STK(4) = _main_38;
      STK(5) = _main_39;
      STK(6) = _main_40;
      STK(7) = _main_41;
      STK(8) = _h_7;
      STK(9) = _h_8;
      STK(10) = _h_9;
      STK(11) = _h_6;
      STK(12) = FID_SLOT_TEXT_K594;
      WL_PUSHN(13);
    } else {
      u64 _t_8 = task_node(e, FID_SLOT_TEXT_K594, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _main_34;
      e.mem[_t_8 + 1] = _main_35;
      e.mem[_t_8 + 2] = _main_36;
      e.mem[_t_8 + 3] = _main_37;
      e.mem[_t_8 + 4] = _main_38;
      e.mem[_t_8 + 5] = _main_39;
      e.mem[_t_8 + 6] = _main_40;
      e.mem[_t_8 + 7] = _main_41;
      e.mem[_t_8 + 8] = _h_7;
      e.mem[_t_8 + 9] = _h_8;
      e.mem[_t_8 + 10] = _h_9;
      e.mem[_t_8 + 11] = _h_6;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K594, _t_8);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _main_36;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _main_36;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K594)
  {
    WL_POPN(12);
    u32 _main_42 = STK(0);
    u32 _main_43 = STK(1);
    u32 _main_44 = STK(2);
    u32 _main_45 = STK(3);
    u32 _main_46 = STK(4);
    u32 _main_47 = STK(5);
    u32 _main_48 = STK(6);
    u32 _main_49 = STK(7);
    Term _h_11 = STK(8);
    Term _h_12 = STK(9);
    Term _h_13 = STK(10);
    Term _h_14 = STK(11);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _main_42;
      STK(1) = _main_43;
      STK(2) = _main_44;
      STK(3) = _main_45;
      STK(4) = _main_46;
      STK(5) = _main_47;
      STK(6) = _main_48;
      STK(7) = _main_49;
      STK(8) = _h_11;
      STK(9) = _h_12;
      STK(10) = _h_13;
      STK(11) = _h_14;
      STK(12) = _h_10;
      STK(13) = FID_SLOT_TEXT_K595;
      WL_PUSHN(14);
    } else {
      u64 _t_10 = task_node(e, FID_SLOT_TEXT_K595, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _main_42;
      e.mem[_t_10 + 1] = _main_43;
      e.mem[_t_10 + 2] = _main_44;
      e.mem[_t_10 + 3] = _main_45;
      e.mem[_t_10 + 4] = _main_46;
      e.mem[_t_10 + 5] = _main_47;
      e.mem[_t_10 + 6] = _main_48;
      e.mem[_t_10 + 7] = _main_49;
      e.mem[_t_10 + 8] = _h_11;
      e.mem[_t_10 + 9] = _h_12;
      e.mem[_t_10 + 10] = _h_13;
      e.mem[_t_10 + 11] = _h_14;
      e.mem[_t_10 + 12] = _h_10;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K595, _t_10);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _main_45;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _main_45;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K595)
  {
    WL_POPN(13);
    u32 _main_50 = STK(0);
    u32 _main_51 = STK(1);
    u32 _main_52 = STK(2);
    u32 _main_53 = STK(3);
    u32 _main_54 = STK(4);
    u32 _main_55 = STK(5);
    u32 _main_56 = STK(6);
    u32 _main_57 = STK(7);
    Term _h_16 = STK(8);
    Term _h_17 = STK(9);
    Term _h_18 = STK(10);
    Term _h_19 = STK(11);
    Term _h_20 = STK(12);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _main_50;
      STK(1) = _main_51;
      STK(2) = _main_52;
      STK(3) = _main_53;
      STK(4) = _main_54;
      STK(5) = _main_55;
      STK(6) = _main_56;
      STK(7) = _main_57;
      STK(8) = _h_16;
      STK(9) = _h_17;
      STK(10) = _h_18;
      STK(11) = _h_19;
      STK(12) = _h_20;
      STK(13) = _h_15;
      STK(14) = FID_SLOT_TEXT_K596;
      WL_PUSHN(15);
    } else {
      u64 _t_12 = task_node(e, FID_SLOT_TEXT_K596, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _main_50;
      e.mem[_t_12 + 1] = _main_51;
      e.mem[_t_12 + 2] = _main_52;
      e.mem[_t_12 + 3] = _main_53;
      e.mem[_t_12 + 4] = _main_54;
      e.mem[_t_12 + 5] = _main_55;
      e.mem[_t_12 + 6] = _main_56;
      e.mem[_t_12 + 7] = _main_57;
      e.mem[_t_12 + 8] = _h_16;
      e.mem[_t_12 + 9] = _h_17;
      e.mem[_t_12 + 10] = _h_18;
      e.mem[_t_12 + 11] = _h_19;
      e.mem[_t_12 + 12] = _h_20;
      e.mem[_t_12 + 13] = _h_15;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K596, _t_12);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _main_54;
      return term_tsk(FID_U32_SHOW, _t_13);
    }
    r0 = _main_54;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K596)
  {
    WL_POPN(14);
    u32 _main_58 = STK(0);
    u32 _main_59 = STK(1);
    u32 _main_60 = STK(2);
    u32 _main_61 = STK(3);
    u32 _main_62 = STK(4);
    u32 _main_63 = STK(5);
    u32 _main_64 = STK(6);
    u32 _main_65 = STK(7);
    Term _h_22 = STK(8);
    Term _h_23 = STK(9);
    Term _h_24 = STK(10);
    Term _h_25 = STK(11);
    Term _h_26 = STK(12);
    Term _h_27 = STK(13);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _main_58;
      STK(1) = _main_59;
      STK(2) = _main_60;
      STK(3) = _main_61;
      STK(4) = _main_62;
      STK(5) = _main_63;
      STK(6) = _main_64;
      STK(7) = _main_65;
      STK(8) = _h_22;
      STK(9) = _h_23;
      STK(10) = _h_24;
      STK(11) = _h_25;
      STK(12) = _h_26;
      STK(13) = _h_27;
      STK(14) = _h_21;
      STK(15) = FID_SLOT_TEXT_K597;
      WL_PUSHN(16);
    } else {
      u64 _t_14 = task_node(e, FID_SLOT_TEXT_K597, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _main_58;
      e.mem[_t_14 + 1] = _main_59;
      e.mem[_t_14 + 2] = _main_60;
      e.mem[_t_14 + 3] = _main_61;
      e.mem[_t_14 + 4] = _main_62;
      e.mem[_t_14 + 5] = _main_63;
      e.mem[_t_14 + 6] = _main_64;
      e.mem[_t_14 + 7] = _main_65;
      e.mem[_t_14 + 8] = _h_22;
      e.mem[_t_14 + 9] = _h_23;
      e.mem[_t_14 + 10] = _h_24;
      e.mem[_t_14 + 11] = _h_25;
      e.mem[_t_14 + 12] = _h_26;
      e.mem[_t_14 + 13] = _h_27;
      e.mem[_t_14 + 14] = _h_21;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K597, _t_14);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_15 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _main_63;
      return term_tsk(FID_U32_SHOW, _t_15);
    }
    r0 = _main_63;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K597)
  {
    WL_POPN(15);
    u32 _main_66 = STK(0);
    u32 _main_67 = STK(1);
    u32 _main_68 = STK(2);
    u32 _main_69 = STK(3);
    u32 _main_70 = STK(4);
    u32 _main_71 = STK(5);
    u32 _main_72 = STK(6);
    u32 _main_73 = STK(7);
    Term _h_29 = STK(8);
    Term _h_30 = STK(9);
    Term _h_31 = STK(10);
    Term _h_32 = STK(11);
    Term _h_33 = STK(12);
    Term _h_34 = STK(13);
    Term _h_35 = STK(14);
    Term _h_28 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _main_66;
      STK(1) = _main_67;
      STK(2) = _main_68;
      STK(3) = _main_69;
      STK(4) = _main_70;
      STK(5) = _main_71;
      STK(6) = _main_72;
      STK(7) = _main_73;
      STK(8) = _h_29;
      STK(9) = _h_30;
      STK(10) = _h_31;
      STK(11) = _h_32;
      STK(12) = _h_33;
      STK(13) = _h_34;
      STK(14) = _h_35;
      STK(15) = _h_28;
      STK(16) = FID_SLOT_TEXT_K598;
      WL_PUSHN(17);
    } else {
      u64 _t_16 = task_node(e, FID_SLOT_TEXT_K598, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _main_66;
      e.mem[_t_16 + 1] = _main_67;
      e.mem[_t_16 + 2] = _main_68;
      e.mem[_t_16 + 3] = _main_69;
      e.mem[_t_16 + 4] = _main_70;
      e.mem[_t_16 + 5] = _main_71;
      e.mem[_t_16 + 6] = _main_72;
      e.mem[_t_16 + 7] = _main_73;
      e.mem[_t_16 + 8] = _h_29;
      e.mem[_t_16 + 9] = _h_30;
      e.mem[_t_16 + 10] = _h_31;
      e.mem[_t_16 + 11] = _h_32;
      e.mem[_t_16 + 12] = _h_33;
      e.mem[_t_16 + 13] = _h_34;
      e.mem[_t_16 + 14] = _h_35;
      e.mem[_t_16 + 15] = _h_28;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K598, _t_16);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _main_72;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _main_72;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K598)
  {
    WL_POPN(16);
    u32 _main_74 = STK(0);
    u32 _main_75 = STK(1);
    u32 _main_76 = STK(2);
    u32 _main_77 = STK(3);
    u32 _main_78 = STK(4);
    u32 _main_79 = STK(5);
    u32 _main_80 = STK(6);
    u32 _main_81 = STK(7);
    Term _h_37 = STK(8);
    Term _h_38 = STK(9);
    Term _h_39 = STK(10);
    Term _h_40 = STK(11);
    Term _h_41 = STK(12);
    Term _h_42 = STK(13);
    Term _h_43 = STK(14);
    Term _h_44 = STK(15);
    Term _h_36 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _main_74;
      STK(1) = _main_75;
      STK(2) = _main_76;
      STK(3) = _main_77;
      STK(4) = _main_78;
      STK(5) = _main_79;
      STK(6) = _main_80;
      STK(7) = _main_81;
      STK(8) = _h_37;
      STK(9) = _h_38;
      STK(10) = _h_39;
      STK(11) = _h_40;
      STK(12) = _h_41;
      STK(13) = _h_42;
      STK(14) = _h_43;
      STK(15) = _h_44;
      STK(16) = _h_36;
      STK(17) = FID_SLOT_TEXT_K599;
      WL_PUSHN(18);
    } else {
      u64 _t_18 = task_node(e, FID_SLOT_TEXT_K599, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _main_74;
      e.mem[_t_18 + 1] = _main_75;
      e.mem[_t_18 + 2] = _main_76;
      e.mem[_t_18 + 3] = _main_77;
      e.mem[_t_18 + 4] = _main_78;
      e.mem[_t_18 + 5] = _main_79;
      e.mem[_t_18 + 6] = _main_80;
      e.mem[_t_18 + 7] = _main_81;
      e.mem[_t_18 + 8] = _h_37;
      e.mem[_t_18 + 9] = _h_38;
      e.mem[_t_18 + 10] = _h_39;
      e.mem[_t_18 + 11] = _h_40;
      e.mem[_t_18 + 12] = _h_41;
      e.mem[_t_18 + 13] = _h_42;
      e.mem[_t_18 + 14] = _h_43;
      e.mem[_t_18 + 15] = _h_44;
      e.mem[_t_18 + 16] = _h_36;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K599, _t_18);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_19 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _main_81;
      return term_tsk(FID_U32_SHOW, _t_19);
    }
    r0 = _main_81;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K599)
  {
    WL_POPN(17);
    u32 _main_82 = STK(0);
    u32 _main_83 = STK(1);
    u32 _main_84 = STK(2);
    u32 _main_85 = STK(3);
    u32 _main_86 = STK(4);
    u32 _main_87 = STK(5);
    u32 _main_88 = STK(6);
    u32 _main_89 = STK(7);
    Term _h_46 = STK(8);
    Term _h_47 = STK(9);
    Term _h_48 = STK(10);
    Term _h_49 = STK(11);
    Term _h_50 = STK(12);
    Term _h_51 = STK(13);
    Term _h_52 = STK(14);
    Term _h_53 = STK(15);
    Term _h_54 = STK(16);
    Term _h_45 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _main_82;
      STK(1) = _main_83;
      STK(2) = _main_84;
      STK(3) = _main_85;
      STK(4) = _main_86;
      STK(5) = _main_87;
      STK(6) = _main_88;
      STK(7) = _main_89;
      STK(8) = _h_46;
      STK(9) = _h_47;
      STK(10) = _h_48;
      STK(11) = _h_49;
      STK(12) = _h_50;
      STK(13) = _h_51;
      STK(14) = _h_52;
      STK(15) = _h_53;
      STK(16) = _h_54;
      STK(17) = FID_SLOT_TEXT_K600;
      WL_PUSHN(18);
    } else {
      u64 _t_20 = task_node(e, FID_SLOT_TEXT_K600, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _main_82;
      e.mem[_t_20 + 1] = _main_83;
      e.mem[_t_20 + 2] = _main_84;
      e.mem[_t_20 + 3] = _main_85;
      e.mem[_t_20 + 4] = _main_86;
      e.mem[_t_20 + 5] = _main_87;
      e.mem[_t_20 + 6] = _main_88;
      e.mem[_t_20 + 7] = _main_89;
      e.mem[_t_20 + 8] = _h_46;
      e.mem[_t_20 + 9] = _h_47;
      e.mem[_t_20 + 10] = _h_48;
      e.mem[_t_20 + 11] = _h_49;
      e.mem[_t_20 + 12] = _h_50;
      e.mem[_t_20 + 13] = _h_51;
      e.mem[_t_20 + 14] = _h_52;
      e.mem[_t_20 + 15] = _h_53;
      e.mem[_t_20 + 16] = _h_54;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K600, _t_20);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_21 + 1] = _h_45;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_45;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K600)
  {
    WL_POPN(17);
    u32 _main_90 = STK(0);
    u32 _main_91 = STK(1);
    u32 _main_92 = STK(2);
    u32 _main_93 = STK(3);
    u32 _main_94 = STK(4);
    u32 _main_95 = STK(5);
    u32 _main_96 = STK(6);
    u32 _main_97 = STK(7);
    Term _h_56 = STK(8);
    Term _h_57 = STK(9);
    Term _h_58 = STK(10);
    Term _h_59 = STK(11);
    Term _h_60 = STK(12);
    Term _h_61 = STK(13);
    Term _h_62 = STK(14);
    Term _h_63 = STK(15);
    Term _h_64 = STK(16);
    Term _h_55 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _main_90;
      STK(1) = _main_91;
      STK(2) = _main_92;
      STK(3) = _main_93;
      STK(4) = _main_94;
      STK(5) = _main_95;
      STK(6) = _main_96;
      STK(7) = _main_97;
      STK(8) = _h_56;
      STK(9) = _h_57;
      STK(10) = _h_58;
      STK(11) = _h_59;
      STK(12) = _h_60;
      STK(13) = _h_61;
      STK(14) = _h_62;
      STK(15) = _h_63;
      STK(16) = FID_SLOT_TEXT_K601;
      WL_PUSHN(17);
    } else {
      u64 _t_22 = task_node(e, FID_SLOT_TEXT_K601, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _main_90;
      e.mem[_t_22 + 1] = _main_91;
      e.mem[_t_22 + 2] = _main_92;
      e.mem[_t_22 + 3] = _main_93;
      e.mem[_t_22 + 4] = _main_94;
      e.mem[_t_22 + 5] = _main_95;
      e.mem[_t_22 + 6] = _main_96;
      e.mem[_t_22 + 7] = _main_97;
      e.mem[_t_22 + 8] = _h_56;
      e.mem[_t_22 + 9] = _h_57;
      e.mem[_t_22 + 10] = _h_58;
      e.mem[_t_22 + 11] = _h_59;
      e.mem[_t_22 + 12] = _h_60;
      e.mem[_t_22 + 13] = _h_61;
      e.mem[_t_22 + 14] = _h_62;
      e.mem[_t_22 + 15] = _h_63;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K601, _t_22);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_64;
      e.mem[_t_23 + 1] = _h_55;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_64;
    r1 = _h_55;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K601)
  {
    WL_POPN(16);
    u32 _main_98 = STK(0);
    u32 _main_99 = STK(1);
    u32 _main_100 = STK(2);
    u32 _main_101 = STK(3);
    u32 _main_102 = STK(4);
    u32 _main_103 = STK(5);
    u32 _main_104 = STK(6);
    u32 _main_105 = STK(7);
    Term _h_66 = STK(8);
    Term _h_67 = STK(9);
    Term _h_68 = STK(10);
    Term _h_69 = STK(11);
    Term _h_70 = STK(12);
    Term _h_71 = STK(13);
    Term _h_72 = STK(14);
    Term _h_73 = STK(15);
    Term _h_65 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _main_98;
      STK(1) = _main_99;
      STK(2) = _main_100;
      STK(3) = _main_101;
      STK(4) = _main_102;
      STK(5) = _main_103;
      STK(6) = _main_104;
      STK(7) = _main_105;
      STK(8) = _h_66;
      STK(9) = _h_67;
      STK(10) = _h_68;
      STK(11) = _h_69;
      STK(12) = _h_70;
      STK(13) = _h_71;
      STK(14) = _h_72;
      STK(15) = _h_73;
      STK(16) = FID_SLOT_TEXT_K602;
      WL_PUSHN(17);
    } else {
      u64 _t_24 = task_node(e, FID_SLOT_TEXT_K602, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _main_98;
      e.mem[_t_24 + 1] = _main_99;
      e.mem[_t_24 + 2] = _main_100;
      e.mem[_t_24 + 3] = _main_101;
      e.mem[_t_24 + 4] = _main_102;
      e.mem[_t_24 + 5] = _main_103;
      e.mem[_t_24 + 6] = _main_104;
      e.mem[_t_24 + 7] = _main_105;
      e.mem[_t_24 + 8] = _h_66;
      e.mem[_t_24 + 9] = _h_67;
      e.mem[_t_24 + 10] = _h_68;
      e.mem[_t_24 + 11] = _h_69;
      e.mem[_t_24 + 12] = _h_70;
      e.mem[_t_24 + 13] = _h_71;
      e.mem[_t_24 + 14] = _h_72;
      e.mem[_t_24 + 15] = _h_73;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K602, _t_24);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_25 + 1] = _h_65;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_65;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K602)
  {
    WL_POPN(16);
    u32 _main_106 = STK(0);
    u32 _main_107 = STK(1);
    u32 _main_108 = STK(2);
    u32 _main_109 = STK(3);
    u32 _main_110 = STK(4);
    u32 _main_111 = STK(5);
    u32 _main_112 = STK(6);
    u32 _main_113 = STK(7);
    Term _h_75 = STK(8);
    Term _h_76 = STK(9);
    Term _h_77 = STK(10);
    Term _h_78 = STK(11);
    Term _h_79 = STK(12);
    Term _h_80 = STK(13);
    Term _h_81 = STK(14);
    Term _h_82 = STK(15);
    Term _h_74 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _main_106;
      STK(1) = _main_107;
      STK(2) = _main_108;
      STK(3) = _main_109;
      STK(4) = _main_110;
      STK(5) = _main_111;
      STK(6) = _main_112;
      STK(7) = _main_113;
      STK(8) = _h_75;
      STK(9) = _h_76;
      STK(10) = _h_77;
      STK(11) = _h_78;
      STK(12) = _h_79;
      STK(13) = _h_80;
      STK(14) = _h_81;
      STK(15) = FID_SLOT_TEXT_K603;
      WL_PUSHN(16);
    } else {
      u64 _t_26 = task_node(e, FID_SLOT_TEXT_K603, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _main_106;
      e.mem[_t_26 + 1] = _main_107;
      e.mem[_t_26 + 2] = _main_108;
      e.mem[_t_26 + 3] = _main_109;
      e.mem[_t_26 + 4] = _main_110;
      e.mem[_t_26 + 5] = _main_111;
      e.mem[_t_26 + 6] = _main_112;
      e.mem[_t_26 + 7] = _main_113;
      e.mem[_t_26 + 8] = _h_75;
      e.mem[_t_26 + 9] = _h_76;
      e.mem[_t_26 + 10] = _h_77;
      e.mem[_t_26 + 11] = _h_78;
      e.mem[_t_26 + 12] = _h_79;
      e.mem[_t_26 + 13] = _h_80;
      e.mem[_t_26 + 14] = _h_81;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K603, _t_26);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _h_82;
      e.mem[_t_27 + 1] = _h_74;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = _h_82;
    r1 = _h_74;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K603)
  {
    WL_POPN(15);
    u32 _main_114 = STK(0);
    u32 _main_115 = STK(1);
    u32 _main_116 = STK(2);
    u32 _main_117 = STK(3);
    u32 _main_118 = STK(4);
    u32 _main_119 = STK(5);
    u32 _main_120 = STK(6);
    u32 _main_121 = STK(7);
    Term _h_84 = STK(8);
    Term _h_85 = STK(9);
    Term _h_86 = STK(10);
    Term _h_87 = STK(11);
    Term _h_88 = STK(12);
    Term _h_89 = STK(13);
    Term _h_90 = STK(14);
    Term _h_83 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _main_114;
      STK(1) = _main_115;
      STK(2) = _main_116;
      STK(3) = _main_117;
      STK(4) = _main_118;
      STK(5) = _main_119;
      STK(6) = _main_120;
      STK(7) = _main_121;
      STK(8) = _h_84;
      STK(9) = _h_85;
      STK(10) = _h_86;
      STK(11) = _h_87;
      STK(12) = _h_88;
      STK(13) = _h_89;
      STK(14) = _h_90;
      STK(15) = FID_SLOT_TEXT_K604;
      WL_PUSHN(16);
    } else {
      u64 _t_28 = task_node(e, FID_SLOT_TEXT_K604, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _main_114;
      e.mem[_t_28 + 1] = _main_115;
      e.mem[_t_28 + 2] = _main_116;
      e.mem[_t_28 + 3] = _main_117;
      e.mem[_t_28 + 4] = _main_118;
      e.mem[_t_28 + 5] = _main_119;
      e.mem[_t_28 + 6] = _main_120;
      e.mem[_t_28 + 7] = _main_121;
      e.mem[_t_28 + 8] = _h_84;
      e.mem[_t_28 + 9] = _h_85;
      e.mem[_t_28 + 10] = _h_86;
      e.mem[_t_28 + 11] = _h_87;
      e.mem[_t_28 + 12] = _h_88;
      e.mem[_t_28 + 13] = _h_89;
      e.mem[_t_28 + 14] = _h_90;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K604, _t_28);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_29 + 1] = _h_83;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_83;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K604)
  {
    WL_POPN(15);
    u32 _main_122 = STK(0);
    u32 _main_123 = STK(1);
    u32 _main_124 = STK(2);
    u32 _main_125 = STK(3);
    u32 _main_126 = STK(4);
    u32 _main_127 = STK(5);
    u32 _main_128 = STK(6);
    u32 _main_129 = STK(7);
    Term _h_92 = STK(8);
    Term _h_93 = STK(9);
    Term _h_94 = STK(10);
    Term _h_95 = STK(11);
    Term _h_96 = STK(12);
    Term _h_97 = STK(13);
    Term _h_98 = STK(14);
    Term _h_91 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _main_122;
      STK(1) = _main_123;
      STK(2) = _main_124;
      STK(3) = _main_125;
      STK(4) = _main_126;
      STK(5) = _main_127;
      STK(6) = _main_128;
      STK(7) = _main_129;
      STK(8) = _h_92;
      STK(9) = _h_93;
      STK(10) = _h_94;
      STK(11) = _h_95;
      STK(12) = _h_96;
      STK(13) = _h_97;
      STK(14) = FID_SLOT_TEXT_K605;
      WL_PUSHN(15);
    } else {
      u64 _t_30 = task_node(e, FID_SLOT_TEXT_K605, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _main_122;
      e.mem[_t_30 + 1] = _main_123;
      e.mem[_t_30 + 2] = _main_124;
      e.mem[_t_30 + 3] = _main_125;
      e.mem[_t_30 + 4] = _main_126;
      e.mem[_t_30 + 5] = _main_127;
      e.mem[_t_30 + 6] = _main_128;
      e.mem[_t_30 + 7] = _main_129;
      e.mem[_t_30 + 8] = _h_92;
      e.mem[_t_30 + 9] = _h_93;
      e.mem[_t_30 + 10] = _h_94;
      e.mem[_t_30 + 11] = _h_95;
      e.mem[_t_30 + 12] = _h_96;
      e.mem[_t_30 + 13] = _h_97;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K605, _t_30);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_98;
      e.mem[_t_31 + 1] = _h_91;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = _h_98;
    r1 = _h_91;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K605)
  {
    WL_POPN(14);
    u32 _main_130 = STK(0);
    u32 _main_131 = STK(1);
    u32 _main_132 = STK(2);
    u32 _main_133 = STK(3);
    u32 _main_134 = STK(4);
    u32 _main_135 = STK(5);
    u32 _main_136 = STK(6);
    u32 _main_137 = STK(7);
    Term _h_100 = STK(8);
    Term _h_101 = STK(9);
    Term _h_102 = STK(10);
    Term _h_103 = STK(11);
    Term _h_104 = STK(12);
    Term _h_105 = STK(13);
    Term _h_99 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _main_130;
      STK(1) = _main_131;
      STK(2) = _main_132;
      STK(3) = _main_133;
      STK(4) = _main_134;
      STK(5) = _main_135;
      STK(6) = _main_136;
      STK(7) = _main_137;
      STK(8) = _h_100;
      STK(9) = _h_101;
      STK(10) = _h_102;
      STK(11) = _h_103;
      STK(12) = _h_104;
      STK(13) = _h_105;
      STK(14) = FID_SLOT_TEXT_K606;
      WL_PUSHN(15);
    } else {
      u64 _t_32 = task_node(e, FID_SLOT_TEXT_K606, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _main_130;
      e.mem[_t_32 + 1] = _main_131;
      e.mem[_t_32 + 2] = _main_132;
      e.mem[_t_32 + 3] = _main_133;
      e.mem[_t_32 + 4] = _main_134;
      e.mem[_t_32 + 5] = _main_135;
      e.mem[_t_32 + 6] = _main_136;
      e.mem[_t_32 + 7] = _main_137;
      e.mem[_t_32 + 8] = _h_100;
      e.mem[_t_32 + 9] = _h_101;
      e.mem[_t_32 + 10] = _h_102;
      e.mem[_t_32 + 11] = _h_103;
      e.mem[_t_32 + 12] = _h_104;
      e.mem[_t_32 + 13] = _h_105;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K606, _t_32);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_33 + 1] = _h_99;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_99;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K606)
  {
    WL_POPN(14);
    u32 _main_138 = STK(0);
    u32 _main_139 = STK(1);
    u32 _main_140 = STK(2);
    u32 _main_141 = STK(3);
    u32 _main_142 = STK(4);
    u32 _main_143 = STK(5);
    u32 _main_144 = STK(6);
    u32 _main_145 = STK(7);
    Term _h_107 = STK(8);
    Term _h_108 = STK(9);
    Term _h_109 = STK(10);
    Term _h_110 = STK(11);
    Term _h_111 = STK(12);
    Term _h_112 = STK(13);
    Term _h_106 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _main_138;
      STK(1) = _main_139;
      STK(2) = _main_140;
      STK(3) = _main_141;
      STK(4) = _main_142;
      STK(5) = _main_143;
      STK(6) = _main_144;
      STK(7) = _main_145;
      STK(8) = _h_107;
      STK(9) = _h_108;
      STK(10) = _h_109;
      STK(11) = _h_110;
      STK(12) = _h_111;
      STK(13) = FID_SLOT_TEXT_K607;
      WL_PUSHN(14);
    } else {
      u64 _t_34 = task_node(e, FID_SLOT_TEXT_K607, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _main_138;
      e.mem[_t_34 + 1] = _main_139;
      e.mem[_t_34 + 2] = _main_140;
      e.mem[_t_34 + 3] = _main_141;
      e.mem[_t_34 + 4] = _main_142;
      e.mem[_t_34 + 5] = _main_143;
      e.mem[_t_34 + 6] = _main_144;
      e.mem[_t_34 + 7] = _main_145;
      e.mem[_t_34 + 8] = _h_107;
      e.mem[_t_34 + 9] = _h_108;
      e.mem[_t_34 + 10] = _h_109;
      e.mem[_t_34 + 11] = _h_110;
      e.mem[_t_34 + 12] = _h_111;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K607, _t_34);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _h_112;
      e.mem[_t_35 + 1] = _h_106;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = _h_112;
    r1 = _h_106;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K607)
  {
    WL_POPN(13);
    u32 _main_146 = STK(0);
    u32 _main_147 = STK(1);
    u32 _main_148 = STK(2);
    u32 _main_149 = STK(3);
    u32 _main_150 = STK(4);
    u32 _main_151 = STK(5);
    u32 _main_152 = STK(6);
    u32 _main_153 = STK(7);
    Term _h_114 = STK(8);
    Term _h_115 = STK(9);
    Term _h_116 = STK(10);
    Term _h_117 = STK(11);
    Term _h_118 = STK(12);
    Term _h_113 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _main_146;
      STK(1) = _main_147;
      STK(2) = _main_148;
      STK(3) = _main_149;
      STK(4) = _main_150;
      STK(5) = _main_151;
      STK(6) = _main_152;
      STK(7) = _main_153;
      STK(8) = _h_114;
      STK(9) = _h_115;
      STK(10) = _h_116;
      STK(11) = _h_117;
      STK(12) = _h_118;
      STK(13) = FID_SLOT_TEXT_K608;
      WL_PUSHN(14);
    } else {
      u64 _t_36 = task_node(e, FID_SLOT_TEXT_K608, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _main_146;
      e.mem[_t_36 + 1] = _main_147;
      e.mem[_t_36 + 2] = _main_148;
      e.mem[_t_36 + 3] = _main_149;
      e.mem[_t_36 + 4] = _main_150;
      e.mem[_t_36 + 5] = _main_151;
      e.mem[_t_36 + 6] = _main_152;
      e.mem[_t_36 + 7] = _main_153;
      e.mem[_t_36 + 8] = _h_114;
      e.mem[_t_36 + 9] = _h_115;
      e.mem[_t_36 + 10] = _h_116;
      e.mem[_t_36 + 11] = _h_117;
      e.mem[_t_36 + 12] = _h_118;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K608, _t_36);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_37 + 1] = _h_113;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_113;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K608)
  {
    WL_POPN(13);
    u32 _main_154 = STK(0);
    u32 _main_155 = STK(1);
    u32 _main_156 = STK(2);
    u32 _main_157 = STK(3);
    u32 _main_158 = STK(4);
    u32 _main_159 = STK(5);
    u32 _main_160 = STK(6);
    u32 _main_161 = STK(7);
    Term _h_120 = STK(8);
    Term _h_121 = STK(9);
    Term _h_122 = STK(10);
    Term _h_123 = STK(11);
    Term _h_124 = STK(12);
    Term _h_119 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _main_154;
      STK(1) = _main_155;
      STK(2) = _main_156;
      STK(3) = _main_157;
      STK(4) = _main_158;
      STK(5) = _main_159;
      STK(6) = _main_160;
      STK(7) = _main_161;
      STK(8) = _h_120;
      STK(9) = _h_121;
      STK(10) = _h_122;
      STK(11) = _h_123;
      STK(12) = FID_SLOT_TEXT_K609;
      WL_PUSHN(13);
    } else {
      u64 _t_38 = task_node(e, FID_SLOT_TEXT_K609, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _main_154;
      e.mem[_t_38 + 1] = _main_155;
      e.mem[_t_38 + 2] = _main_156;
      e.mem[_t_38 + 3] = _main_157;
      e.mem[_t_38 + 4] = _main_158;
      e.mem[_t_38 + 5] = _main_159;
      e.mem[_t_38 + 6] = _main_160;
      e.mem[_t_38 + 7] = _main_161;
      e.mem[_t_38 + 8] = _h_120;
      e.mem[_t_38 + 9] = _h_121;
      e.mem[_t_38 + 10] = _h_122;
      e.mem[_t_38 + 11] = _h_123;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K609, _t_38);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_39 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _h_124;
      e.mem[_t_39 + 1] = _h_119;
      return term_tsk(FID_STRING_APPEND, _t_39);
    }
    r0 = _h_124;
    r1 = _h_119;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K609)
  {
    WL_POPN(12);
    u32 _main_162 = STK(0);
    u32 _main_163 = STK(1);
    u32 _main_164 = STK(2);
    u32 _main_165 = STK(3);
    u32 _main_166 = STK(4);
    u32 _main_167 = STK(5);
    u32 _main_168 = STK(6);
    u32 _main_169 = STK(7);
    Term _h_126 = STK(8);
    Term _h_127 = STK(9);
    Term _h_128 = STK(10);
    Term _h_129 = STK(11);
    Term _h_125 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _main_162;
      STK(1) = _main_163;
      STK(2) = _main_164;
      STK(3) = _main_165;
      STK(4) = _main_166;
      STK(5) = _main_167;
      STK(6) = _main_168;
      STK(7) = _main_169;
      STK(8) = _h_126;
      STK(9) = _h_127;
      STK(10) = _h_128;
      STK(11) = _h_129;
      STK(12) = FID_SLOT_TEXT_K610;
      WL_PUSHN(13);
    } else {
      u64 _t_40 = task_node(e, FID_SLOT_TEXT_K610, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _main_162;
      e.mem[_t_40 + 1] = _main_163;
      e.mem[_t_40 + 2] = _main_164;
      e.mem[_t_40 + 3] = _main_165;
      e.mem[_t_40 + 4] = _main_166;
      e.mem[_t_40 + 5] = _main_167;
      e.mem[_t_40 + 6] = _main_168;
      e.mem[_t_40 + 7] = _main_169;
      e.mem[_t_40 + 8] = _h_126;
      e.mem[_t_40 + 9] = _h_127;
      e.mem[_t_40 + 10] = _h_128;
      e.mem[_t_40 + 11] = _h_129;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K610, _t_40);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_41 + 1] = _h_125;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_125;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K610)
  {
    WL_POPN(12);
    u32 _main_170 = STK(0);
    u32 _main_171 = STK(1);
    u32 _main_172 = STK(2);
    u32 _main_173 = STK(3);
    u32 _main_174 = STK(4);
    u32 _main_175 = STK(5);
    u32 _main_176 = STK(6);
    u32 _main_177 = STK(7);
    Term _h_131 = STK(8);
    Term _h_132 = STK(9);
    Term _h_133 = STK(10);
    Term _h_134 = STK(11);
    Term _h_130 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _main_170;
      STK(1) = _main_171;
      STK(2) = _main_172;
      STK(3) = _main_173;
      STK(4) = _main_174;
      STK(5) = _main_175;
      STK(6) = _main_176;
      STK(7) = _main_177;
      STK(8) = _h_131;
      STK(9) = _h_132;
      STK(10) = _h_133;
      STK(11) = FID_SLOT_TEXT_K611;
      WL_PUSHN(12);
    } else {
      u64 _t_42 = task_node(e, FID_SLOT_TEXT_K611, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _main_170;
      e.mem[_t_42 + 1] = _main_171;
      e.mem[_t_42 + 2] = _main_172;
      e.mem[_t_42 + 3] = _main_173;
      e.mem[_t_42 + 4] = _main_174;
      e.mem[_t_42 + 5] = _main_175;
      e.mem[_t_42 + 6] = _main_176;
      e.mem[_t_42 + 7] = _main_177;
      e.mem[_t_42 + 8] = _h_131;
      e.mem[_t_42 + 9] = _h_132;
      e.mem[_t_42 + 10] = _h_133;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K611, _t_42);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_43 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _h_134;
      e.mem[_t_43 + 1] = _h_130;
      return term_tsk(FID_STRING_APPEND, _t_43);
    }
    r0 = _h_134;
    r1 = _h_130;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K611)
  {
    WL_POPN(11);
    u32 _main_178 = STK(0);
    u32 _main_179 = STK(1);
    u32 _main_180 = STK(2);
    u32 _main_181 = STK(3);
    u32 _main_182 = STK(4);
    u32 _main_183 = STK(5);
    u32 _main_184 = STK(6);
    u32 _main_185 = STK(7);
    Term _h_136 = STK(8);
    Term _h_137 = STK(9);
    Term _h_138 = STK(10);
    Term _h_135 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _main_178;
      STK(1) = _main_179;
      STK(2) = _main_180;
      STK(3) = _main_181;
      STK(4) = _main_182;
      STK(5) = _main_183;
      STK(6) = _main_184;
      STK(7) = _main_185;
      STK(8) = _h_136;
      STK(9) = _h_137;
      STK(10) = _h_138;
      STK(11) = FID_SLOT_TEXT_K612;
      WL_PUSHN(12);
    } else {
      u64 _t_44 = task_node(e, FID_SLOT_TEXT_K612, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _main_178;
      e.mem[_t_44 + 1] = _main_179;
      e.mem[_t_44 + 2] = _main_180;
      e.mem[_t_44 + 3] = _main_181;
      e.mem[_t_44 + 4] = _main_182;
      e.mem[_t_44 + 5] = _main_183;
      e.mem[_t_44 + 6] = _main_184;
      e.mem[_t_44 + 7] = _main_185;
      e.mem[_t_44 + 8] = _h_136;
      e.mem[_t_44 + 9] = _h_137;
      e.mem[_t_44 + 10] = _h_138;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K612, _t_44);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_45 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_45 + 1] = _h_135;
      return term_tsk(FID_STRING_APPEND, _t_45);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_135;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K612)
  {
    WL_POPN(11);
    u32 _main_186 = STK(0);
    u32 _main_187 = STK(1);
    u32 _main_188 = STK(2);
    u32 _main_189 = STK(3);
    u32 _main_190 = STK(4);
    u32 _main_191 = STK(5);
    u32 _main_192 = STK(6);
    u32 _main_193 = STK(7);
    Term _h_140 = STK(8);
    Term _h_141 = STK(9);
    Term _h_142 = STK(10);
    Term _h_139 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _main_186;
      STK(1) = _main_187;
      STK(2) = _main_188;
      STK(3) = _main_189;
      STK(4) = _main_190;
      STK(5) = _main_191;
      STK(6) = _main_192;
      STK(7) = _main_193;
      STK(8) = _h_140;
      STK(9) = _h_141;
      STK(10) = FID_SLOT_TEXT_K613;
      WL_PUSHN(11);
    } else {
      u64 _t_46 = task_node(e, FID_SLOT_TEXT_K613, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _main_186;
      e.mem[_t_46 + 1] = _main_187;
      e.mem[_t_46 + 2] = _main_188;
      e.mem[_t_46 + 3] = _main_189;
      e.mem[_t_46 + 4] = _main_190;
      e.mem[_t_46 + 5] = _main_191;
      e.mem[_t_46 + 6] = _main_192;
      e.mem[_t_46 + 7] = _main_193;
      e.mem[_t_46 + 8] = _h_140;
      e.mem[_t_46 + 9] = _h_141;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K613, _t_46);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _h_142;
      e.mem[_t_47 + 1] = _h_139;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = _h_142;
    r1 = _h_139;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K613)
  {
    WL_POPN(10);
    u32 _main_194 = STK(0);
    u32 _main_195 = STK(1);
    u32 _main_196 = STK(2);
    u32 _main_197 = STK(3);
    u32 _main_198 = STK(4);
    u32 _main_199 = STK(5);
    u32 _main_200 = STK(6);
    u32 _main_201 = STK(7);
    Term _h_144 = STK(8);
    Term _h_145 = STK(9);
    Term _h_143 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _main_194;
      STK(1) = _main_195;
      STK(2) = _main_196;
      STK(3) = _main_197;
      STK(4) = _main_198;
      STK(5) = _main_199;
      STK(6) = _main_200;
      STK(7) = _main_201;
      STK(8) = _h_144;
      STK(9) = _h_145;
      STK(10) = FID_SLOT_TEXT_K614;
      WL_PUSHN(11);
    } else {
      u64 _t_48 = task_node(e, FID_SLOT_TEXT_K614, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _main_194;
      e.mem[_t_48 + 1] = _main_195;
      e.mem[_t_48 + 2] = _main_196;
      e.mem[_t_48 + 3] = _main_197;
      e.mem[_t_48 + 4] = _main_198;
      e.mem[_t_48 + 5] = _main_199;
      e.mem[_t_48 + 6] = _main_200;
      e.mem[_t_48 + 7] = _main_201;
      e.mem[_t_48 + 8] = _h_144;
      e.mem[_t_48 + 9] = _h_145;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K614, _t_48);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 184);
      e.mem[_t_49 + 1] = _h_143;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 184);
    r1 = _h_143;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K614)
  {
    WL_POPN(10);
    u32 _main_202 = STK(0);
    u32 _main_203 = STK(1);
    u32 _main_204 = STK(2);
    u32 _main_205 = STK(3);
    u32 _main_206 = STK(4);
    u32 _main_207 = STK(5);
    u32 _main_208 = STK(6);
    u32 _main_209 = STK(7);
    Term _h_147 = STK(8);
    Term _h_148 = STK(9);
    Term _h_146 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _main_202;
      STK(1) = _main_203;
      STK(2) = _main_204;
      STK(3) = _main_205;
      STK(4) = _main_206;
      STK(5) = _main_207;
      STK(6) = _main_208;
      STK(7) = _main_209;
      STK(8) = _h_147;
      STK(9) = FID_SLOT_TEXT_K615;
      WL_PUSHN(10);
    } else {
      u64 _t_50 = task_node(e, FID_SLOT_TEXT_K615, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _main_202;
      e.mem[_t_50 + 1] = _main_203;
      e.mem[_t_50 + 2] = _main_204;
      e.mem[_t_50 + 3] = _main_205;
      e.mem[_t_50 + 4] = _main_206;
      e.mem[_t_50 + 5] = _main_207;
      e.mem[_t_50 + 6] = _main_208;
      e.mem[_t_50 + 7] = _main_209;
      e.mem[_t_50 + 8] = _h_147;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K615, _t_50);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _h_148;
      e.mem[_t_51 + 1] = _h_146;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = _h_148;
    r1 = _h_146;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K615)
  {
    WL_POPN(9);
    u32 _main_210 = STK(0);
    u32 _main_211 = STK(1);
    u32 _main_212 = STK(2);
    u32 _main_213 = STK(3);
    u32 _main_214 = STK(4);
    u32 _main_215 = STK(5);
    u32 _main_216 = STK(6);
    u32 _main_217 = STK(7);
    Term _h_150 = STK(8);
    Term _h_149 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _main_210;
      STK(1) = _main_211;
      STK(2) = _main_212;
      STK(3) = _main_213;
      STK(4) = _main_214;
      STK(5) = _main_215;
      STK(6) = _main_216;
      STK(7) = _main_217;
      STK(8) = _h_150;
      STK(9) = FID_SLOT_TEXT_K616;
      WL_PUSHN(10);
    } else {
      u64 _t_52 = task_node(e, FID_SLOT_TEXT_K616, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _main_210;
      e.mem[_t_52 + 1] = _main_211;
      e.mem[_t_52 + 2] = _main_212;
      e.mem[_t_52 + 3] = _main_213;
      e.mem[_t_52 + 4] = _main_214;
      e.mem[_t_52 + 5] = _main_215;
      e.mem[_t_52 + 6] = _main_216;
      e.mem[_t_52 + 7] = _main_217;
      e.mem[_t_52 + 8] = _h_150;
      WL_CONT = term_tsk(FID_SLOT_TEXT_K616, _t_52);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 186);
      e.mem[_t_53 + 1] = _h_149;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 186);
    r1 = _h_149;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SLOT_TEXT_K616)
  {
    WL_POPN(9);
    u32 _main_218 = STK(0);
    u32 _main_219 = STK(1);
    u32 _main_220 = STK(2);
    u32 _main_221 = STK(3);
    u32 _main_222 = STK(4);
    u32 _main_223 = STK(5);
    u32 _main_224 = STK(6);
    u32 _main_225 = STK(7);
    Term _h_152 = STK(8);
    Term _h_151 = r0;
    WL_OPEN
    r0 = _h_152;
    r1 = _main_218;
    r2 = _main_219;
    r3 = _main_220;
    r4 = _main_221;
    r5 = _main_222;
    r6 = _main_223;
    r7 = _main_224;
    r8 = _main_225;
    r9 = _h_151;
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BUNDLE_TEXT)
  {
    Term _depth_0 = r0;
    u32 _bundle_0 = r1;
    Term _bundle_1 = r2;
    u32 _bundle_2 = r3;
    u32 _bundle_3 = r4;
    u32 _bundle_4 = r5;
    u32 _bundle_5 = r6;
    u32 _bundle_6 = r7;
    u32 _bundle_7 = r8;
    u32 _bundle_8 = r9;
    u32 _bundle_9 = r10;
    u32 _bundle_10 = r11;
    u32 _bundle_11 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _bundle_10;
      STK(1) = _bundle_11;
      STK(2) = FID_BUNDLE_TEXT_K623;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_BUNDLE_TEXT_K623, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _bundle_10;
      e.mem[_t_0 + 1] = _bundle_11;
      WL_CONT = term_tsk(FID_BUNDLE_TEXT_K623, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MAIN_TEXT)) {
      u64 _t_1 = task_node(e, FID_MAIN_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _depth_0;
      e.mem[_t_1 + 1] = _bundle_0;
      e.mem[_t_1 + 2] = _bundle_1;
      e.mem[_t_1 + 3] = _bundle_2;
      e.mem[_t_1 + 4] = _bundle_3;
      e.mem[_t_1 + 5] = _bundle_4;
      e.mem[_t_1 + 6] = _bundle_5;
      e.mem[_t_1 + 7] = _bundle_6;
      e.mem[_t_1 + 8] = _bundle_7;
      e.mem[_t_1 + 9] = _bundle_8;
      e.mem[_t_1 + 10] = _bundle_9;
      return term_tsk(FID_MAIN_TEXT, _t_1);
    }
    r0 = _depth_0;
    r1 = _bundle_0;
    r2 = _bundle_1;
    r3 = _bundle_2;
    r4 = _bundle_3;
    r5 = _bundle_4;
    r6 = _bundle_5;
    r7 = _bundle_6;
    r8 = _bundle_7;
    r9 = _bundle_8;
    r10 = _bundle_9;
    WL_JMP(FID_MAIN_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BUNDLE_TEXT_K623)
  {
    WL_POPN(2);
    u32 _bundle_12 = STK(0);
    u32 _bundle_13 = STK(1);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    Term _o_0[13];
    if (spin_69(e, _o_0, _bundle_12, _bundle_13, _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, _h_4, _h_5, _h_6, _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 194);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STATE_COMMAND)
  {
    u32 _namespace_0 = r0;
    u32 _tick_0 = r1;
    u32 _command_0 = r2;
    u32 _command_1 = r3;
    Term _command_2 = r4;
    Term _command_3 = r5;
    u32 _command_4 = r6;
    Term _command_5 = r7;
    u32 _command_6 = r8;
    Term _command_7 = r9;
    u32 _state_0 = r10;
    Term _state_1 = r11;
    Term _state_2 = r12;
    Term _state_3 = r13;
    Term _state_4 = r14;
    Term _state_5 = r15;
    Term _state_6 = r16;
    u32 _state_7 = r17;
    Term _state_8 = r18;
    u32 _state_9 = r19;
    Term _state_10 = r20;
    u32 _state_11 = r21;
    Term _state_12 = r22;
    u32 _state_13 = r23;
    Term _state_14 = r24;
    u32 _state_15 = r25;
    Term _state_16 = r26;
    u32 _state_17 = r27;
    u32 _state_18 = r28;
    Term _state_19 = r29;
    Term _state_20 = r30;
    WL_OPEN
    if (_state_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _state_10;
        STK(1) = FID_COMMANDS_STATE_COMMAND_K634;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_STATE_COMMAND_K634, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _state_10;
        WL_CONT = term_tsk(FID_COMMANDS_STATE_COMMAND_K634, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_STEP)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_STEP, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _namespace_0;
        e.mem[_t_1 + 1] = _tick_0;
        e.mem[_t_1 + 2] = _state_1;
        e.mem[_t_1 + 3] = _state_2;
        e.mem[_t_1 + 4] = _state_3;
        e.mem[_t_1 + 5] = _state_4;
        e.mem[_t_1 + 6] = _state_5;
        e.mem[_t_1 + 7] = _state_6;
        e.mem[_t_1 + 8] = _state_7;
        e.mem[_t_1 + 9] = _state_8;
        e.mem[_t_1 + 10] = _state_9;
        e.mem[_t_1 + 11] = _command_0;
        e.mem[_t_1 + 12] = _command_1;
        e.mem[_t_1 + 13] = _command_2;
        e.mem[_t_1 + 14] = _command_3;
        e.mem[_t_1 + 15] = _command_4;
        e.mem[_t_1 + 16] = _command_5;
        e.mem[_t_1 + 17] = _command_6;
        e.mem[_t_1 + 18] = _command_7;
        return term_tsk(FID_COMMANDS_STEP, _t_1);
      }
      r0 = _namespace_0;
      r1 = _tick_0;
      r2 = _state_1;
      r3 = _state_2;
      r4 = _state_3;
      r5 = _state_4;
      r6 = _state_5;
      r7 = _state_6;
      r8 = _state_7;
      r9 = _state_8;
      r10 = _state_9;
      r11 = _command_0;
      r12 = _command_1;
      r13 = _command_2;
      r14 = _command_3;
      r15 = _command_4;
      r16 = _command_5;
      r17 = _command_6;
      r18 = _command_7;
      WL_JMP(FID_COMMANDS_STEP);
    } else {
      Term _b_0 = 0;
      if (_command_0 == 0) {
        u64 _nd_1 = heap_alloc(e, cls_fit(7));
        e.mem[_nd_1 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _command_2);
        e.mem[_nd_1 + 2] = rfc_seal(e, _command_3);
        e.mem[_nd_1 + 3] = rfc_seal(e, _command_4);
        e.mem[_nd_1 + 4] = rfc_seal(e, _command_5);
        e.mem[_nd_1 + 5] = rfc_seal(e, _command_6);
        e.mem[_nd_1 + 6] = rfc_seal(e, _command_7);
        _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_1);
      } else if (_command_0 == 1) {
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_2 + 1] = rfc_seal(e, _command_2);
        _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_2);
      } else if (_command_0 == 2) {
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, _command_1);
        e.mem[_nd_3 + 1] = rfc_seal(e, _command_2);
        _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_3);
      } else if (_command_0 == 3) {
        _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _command_1);
      } else if (_command_0 == 4) {
        _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _command_1);
      } else {
        _b_0 = term_pak(CID_STORAGE_DESPAWN, _command_1);
      }
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_4 + 1] = rfc_seal(e, _state_19);
      r0 = 1;
      r1 = _state_1;
      r2 = _state_2;
      r3 = _state_3;
      r4 = _state_4;
      r5 = _state_5;
      r6 = _state_6;
      r7 = _state_7;
      r8 = _state_8;
      r9 = _state_9;
      r10 = _state_10;
      r11 = _state_11;
      r12 = _state_12;
      r13 = _state_13;
      r14 = _state_14;
      r15 = _state_15;
      r16 = _state_16;
      r17 = _state_17;
      r18 = _state_18;
      r19 = term_ctr(CID_CON, _nd_4);
      r20 = _state_20;
      WL_RETN(21);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_STATE_COMMAND_K634)
  {
    WL_POPN(1);
    Term _state_21 = STK(0);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_3[21];
    if (spin_73(e, _o_3, _state_21, blk_loc(e.mem, _state_21), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18) == 0) {
      return 0;
    }
    _v_0 = _o_3[0];
    _v_1 = _o_3[1];
    _v_2 = _o_3[2];
    _v_3 = _o_3[3];
    _v_4 = _o_3[4];
    _v_5 = _o_3[5];
    _v_6 = _o_3[6];
    _v_7 = _o_3[7];
    _v_8 = _o_3[8];
    _v_9 = _o_3[9];
    _v_10 = _o_3[10];
    _v_11 = _o_3[11];
    _v_12 = _o_3[12];
    _v_13 = _o_3[13];
    _v_14 = _o_3[14];
    _v_15 = _o_3[15];
    _v_16 = _o_3[16];
    _v_17 = _o_3[17];
    _v_18 = _o_3[18];
    _v_19 = _o_3[19];
    _v_20 = _o_3[20];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT)
  {
    Term _depth_0 = r0;
    u32 _command_0 = r1;
    u32 _command_1 = r2;
    Term _command_2 = r3;
    Term _command_3 = r4;
    u32 _command_4 = r5;
    u32 _command_5 = r6;
    u32 _command_6 = r7;
    u32 _command_7 = r8;
    u32 _command_8 = r9;
    u32 _command_9 = r10;
    u32 _command_10 = r11;
    u32 _command_11 = r12;
    u32 _command_12 = r13;
    u32 _command_13 = r14;
    WL_OPEN
    if (_command_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _command_1;
        STK(1) = FID_COMMAND_TEXT_K668;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_COMMAND_TEXT_K668, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _command_1;
        WL_CONT = term_tsk(FID_COMMAND_TEXT_K668, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_BUNDLE_TEXT)) {
        u64 _t_1 = task_node(e, FID_BUNDLE_TEXT, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _depth_0;
        e.mem[_t_1 + 1] = _command_2;
        e.mem[_t_1 + 2] = _command_3;
        e.mem[_t_1 + 3] = _command_4;
        e.mem[_t_1 + 4] = _command_5;
        e.mem[_t_1 + 5] = _command_6;
        e.mem[_t_1 + 6] = _command_7;
        e.mem[_t_1 + 7] = _command_8;
        e.mem[_t_1 + 8] = _command_9;
        e.mem[_t_1 + 9] = _command_10;
        e.mem[_t_1 + 10] = _command_11;
        e.mem[_t_1 + 11] = _command_12;
        e.mem[_t_1 + 12] = _command_13;
        return term_tsk(FID_BUNDLE_TEXT, _t_1);
      }
      r0 = _depth_0;
      r1 = _command_2;
      r2 = _command_3;
      r3 = _command_4;
      r4 = _command_5;
      r5 = _command_6;
      r6 = _command_7;
      r7 = _command_8;
      r8 = _command_9;
      r9 = _command_10;
      r10 = _command_11;
      r11 = _command_12;
      r12 = _command_13;
      WL_JMP(FID_BUNDLE_TEXT);
    } else if (_command_0 == 1) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _command_1;
        STK(1) = FID_COMMAND_TEXT_K673;
        WL_PUSHN(2);
      } else {
        u64 _t_10 = task_node(e, FID_COMMAND_TEXT_K673, WL_CONT, WL_IDX, 1);
        e.mem[_t_10 + 0] = _command_1;
        WL_CONT = term_tsk(FID_COMMAND_TEXT_K673, _t_10);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SLOT_TEXT)) {
        u64 _t_11 = task_node(e, FID_SLOT_TEXT, WL_CONT, WL_IDX, 0);
        e.mem[_t_11 + 0] = _depth_0;
        e.mem[_t_11 + 1] = _command_2;
        e.mem[_t_11 + 2] = _command_3;
        e.mem[_t_11 + 3] = _command_4;
        e.mem[_t_11 + 4] = _command_5;
        e.mem[_t_11 + 5] = _command_6;
        e.mem[_t_11 + 6] = _command_7;
        e.mem[_t_11 + 7] = _command_8;
        e.mem[_t_11 + 8] = _command_9;
        e.mem[_t_11 + 9] = _command_10;
        return term_tsk(FID_SLOT_TEXT, _t_11);
      }
      r0 = _depth_0;
      r1 = _command_2;
      r2 = _command_3;
      r3 = _command_4;
      r4 = _command_5;
      r5 = _command_6;
      r6 = _command_7;
      r7 = _command_8;
      r8 = _command_9;
      r9 = _command_10;
      WL_JMP(FID_SLOT_TEXT);
    } else if (_command_0 == 2) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _command_1;
        STK(1) = FID_COMMAND_TEXT_K678;
        WL_PUSHN(2);
      } else {
        u64 _t_20 = task_node(e, FID_COMMAND_TEXT_K678, WL_CONT, WL_IDX, 1);
        e.mem[_t_20 + 0] = _command_1;
        WL_CONT = term_tsk(FID_COMMAND_TEXT_K678, _t_20);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_21 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_21 + 0] = _command_1;
        return term_tsk(FID_U32_SHOW, _t_21);
      }
      r0 = _command_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_command_0 == 3) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _command_1;
        STK(1) = FID_COMMAND_TEXT_K680;
        WL_PUSHN(2);
      } else {
        u64 _t_24 = task_node(e, FID_COMMAND_TEXT_K680, WL_CONT, WL_IDX, 1);
        e.mem[_t_24 + 0] = _command_1;
        WL_CONT = term_tsk(FID_COMMAND_TEXT_K680, _t_24);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_25 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_25 + 0] = _command_1;
        return term_tsk(FID_U32_SHOW, _t_25);
      }
      r0 = _command_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_command_0 == 4) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _command_1;
        STK(1) = FID_COMMAND_TEXT_K682;
        WL_PUSHN(2);
      } else {
        u64 _t_28 = task_node(e, FID_COMMAND_TEXT_K682, WL_CONT, WL_IDX, 1);
        e.mem[_t_28 + 0] = _command_1;
        WL_CONT = term_tsk(FID_COMMAND_TEXT_K682, _t_28);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_29 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_29 + 0] = _command_1;
        return term_tsk(FID_U32_SHOW, _t_29);
      }
      r0 = _command_1;
      WL_JMP(FID_U32_SHOW);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _command_1;
        STK(1) = FID_COMMAND_TEXT_K684;
        WL_PUSHN(2);
      } else {
        u64 _t_32 = task_node(e, FID_COMMAND_TEXT_K684, WL_CONT, WL_IDX, 1);
        e.mem[_t_32 + 0] = _command_1;
        WL_CONT = term_tsk(FID_COMMAND_TEXT_K684, _t_32);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_33 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_33 + 0] = _command_1;
        return term_tsk(FID_U32_SHOW, _t_33);
      }
      r0 = _command_1;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K668)
  {
    WL_POPN(1);
    u32 _command_14 = STK(0);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _command_14;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = _h_2;
      STK(4) = _h_3;
      STK(5) = _h_4;
      STK(6) = _h_5;
      STK(7) = _h_6;
      STK(8) = _h_7;
      STK(9) = _h_8;
      STK(10) = _h_9;
      STK(11) = _h_10;
      STK(12) = _h_11;
      STK(13) = _h_12;
      STK(14) = FID_COMMAND_TEXT_K669;
      WL_PUSHN(15);
    } else {
      u64 _t_2 = task_node(e, FID_COMMAND_TEXT_K669, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _command_14;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      e.mem[_t_2 + 4] = _h_3;
      e.mem[_t_2 + 5] = _h_4;
      e.mem[_t_2 + 6] = _h_5;
      e.mem[_t_2 + 7] = _h_6;
      e.mem[_t_2 + 8] = _h_7;
      e.mem[_t_2 + 9] = _h_8;
      e.mem[_t_2 + 10] = _h_9;
      e.mem[_t_2 + 11] = _h_10;
      e.mem[_t_2 + 12] = _h_11;
      e.mem[_t_2 + 13] = _h_12;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K669, _t_2);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _command_14;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _command_14;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K669)
  {
    WL_POPN(14);
    u32 _command_15 = STK(0);
    u32 _h_14 = STK(1);
    Term _h_15 = STK(2);
    u32 _h_16 = STK(3);
    u32 _h_17 = STK(4);
    u32 _h_18 = STK(5);
    u32 _h_19 = STK(6);
    u32 _h_20 = STK(7);
    u32 _h_21 = STK(8);
    u32 _h_22 = STK(9);
    u32 _h_23 = STK(10);
    u32 _h_24 = STK(11);
    u32 _h_25 = STK(12);
    Term _h_26 = STK(13);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _command_15;
      STK(1) = _h_14;
      STK(2) = _h_15;
      STK(3) = _h_16;
      STK(4) = _h_17;
      STK(5) = _h_18;
      STK(6) = _h_19;
      STK(7) = _h_20;
      STK(8) = _h_21;
      STK(9) = _h_22;
      STK(10) = _h_23;
      STK(11) = _h_24;
      STK(12) = _h_25;
      STK(13) = _h_13;
      STK(14) = FID_COMMAND_TEXT_K670;
      WL_PUSHN(15);
    } else {
      u64 _t_4 = task_node(e, FID_COMMAND_TEXT_K670, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _command_15;
      e.mem[_t_4 + 1] = _h_14;
      e.mem[_t_4 + 2] = _h_15;
      e.mem[_t_4 + 3] = _h_16;
      e.mem[_t_4 + 4] = _h_17;
      e.mem[_t_4 + 5] = _h_18;
      e.mem[_t_4 + 6] = _h_19;
      e.mem[_t_4 + 7] = _h_20;
      e.mem[_t_4 + 8] = _h_21;
      e.mem[_t_4 + 9] = _h_22;
      e.mem[_t_4 + 10] = _h_23;
      e.mem[_t_4 + 11] = _h_24;
      e.mem[_t_4 + 12] = _h_25;
      e.mem[_t_4 + 13] = _h_13;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K670, _t_4);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_5 + 1] = _h_26;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_26;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K670)
  {
    WL_POPN(14);
    u32 _command_16 = STK(0);
    u32 _h_28 = STK(1);
    Term _h_29 = STK(2);
    u32 _h_30 = STK(3);
    u32 _h_31 = STK(4);
    u32 _h_32 = STK(5);
    u32 _h_33 = STK(6);
    u32 _h_34 = STK(7);
    u32 _h_35 = STK(8);
    u32 _h_36 = STK(9);
    u32 _h_37 = STK(10);
    u32 _h_38 = STK(11);
    u32 _h_39 = STK(12);
    Term _h_40 = STK(13);
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _command_16;
      STK(1) = _h_28;
      STK(2) = _h_29;
      STK(3) = _h_30;
      STK(4) = _h_31;
      STK(5) = _h_32;
      STK(6) = _h_33;
      STK(7) = _h_34;
      STK(8) = _h_35;
      STK(9) = _h_36;
      STK(10) = _h_37;
      STK(11) = _h_38;
      STK(12) = _h_39;
      STK(13) = FID_COMMAND_TEXT_K671;
      WL_PUSHN(14);
    } else {
      u64 _t_6 = task_node(e, FID_COMMAND_TEXT_K671, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _command_16;
      e.mem[_t_6 + 1] = _h_28;
      e.mem[_t_6 + 2] = _h_29;
      e.mem[_t_6 + 3] = _h_30;
      e.mem[_t_6 + 4] = _h_31;
      e.mem[_t_6 + 5] = _h_32;
      e.mem[_t_6 + 6] = _h_33;
      e.mem[_t_6 + 7] = _h_34;
      e.mem[_t_6 + 8] = _h_35;
      e.mem[_t_6 + 9] = _h_36;
      e.mem[_t_6 + 10] = _h_37;
      e.mem[_t_6 + 11] = _h_38;
      e.mem[_t_6 + 12] = _h_39;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K671, _t_6);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_40;
      e.mem[_t_7 + 1] = _h_27;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_40;
    r1 = _h_27;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K671)
  {
    WL_POPN(13);
    u32 _command_17 = STK(0);
    u32 _h_42 = STK(1);
    Term _h_43 = STK(2);
    u32 _h_44 = STK(3);
    u32 _h_45 = STK(4);
    u32 _h_46 = STK(5);
    u32 _h_47 = STK(6);
    u32 _h_48 = STK(7);
    u32 _h_49 = STK(8);
    u32 _h_50 = STK(9);
    u32 _h_51 = STK(10);
    u32 _h_52 = STK(11);
    u32 _h_53 = STK(12);
    Term _h_41 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _command_17;
      STK(1) = _h_42;
      STK(2) = _h_43;
      STK(3) = _h_44;
      STK(4) = _h_45;
      STK(5) = _h_46;
      STK(6) = _h_47;
      STK(7) = _h_48;
      STK(8) = _h_49;
      STK(9) = _h_50;
      STK(10) = _h_51;
      STK(11) = _h_52;
      STK(12) = _h_53;
      STK(13) = FID_COMMAND_TEXT_K672;
      WL_PUSHN(14);
    } else {
      u64 _t_8 = task_node(e, FID_COMMAND_TEXT_K672, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _command_17;
      e.mem[_t_8 + 1] = _h_42;
      e.mem[_t_8 + 2] = _h_43;
      e.mem[_t_8 + 3] = _h_44;
      e.mem[_t_8 + 4] = _h_45;
      e.mem[_t_8 + 5] = _h_46;
      e.mem[_t_8 + 6] = _h_47;
      e.mem[_t_8 + 7] = _h_48;
      e.mem[_t_8 + 8] = _h_49;
      e.mem[_t_8 + 9] = _h_50;
      e.mem[_t_8 + 10] = _h_51;
      e.mem[_t_8 + 11] = _h_52;
      e.mem[_t_8 + 12] = _h_53;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K672, _t_8);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 216);
      e.mem[_t_9 + 1] = _h_41;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 216);
    r1 = _h_41;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K672)
  {
    WL_POPN(13);
    u32 _command_18 = STK(0);
    u32 _h_55 = STK(1);
    Term _h_56 = STK(2);
    u32 _h_57 = STK(3);
    u32 _h_58 = STK(4);
    u32 _h_59 = STK(5);
    u32 _h_60 = STK(6);
    u32 _h_61 = STK(7);
    u32 _h_62 = STK(8);
    u32 _h_63 = STK(9);
    u32 _h_64 = STK(10);
    u32 _h_65 = STK(11);
    u32 _h_66 = STK(12);
    Term _h_54 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _command_18;
    r2 = _h_55;
    r3 = _h_56;
    r4 = _h_57;
    r5 = _h_58;
    r6 = _h_59;
    r7 = _h_60;
    r8 = _h_61;
    r9 = _h_62;
    r10 = _h_63;
    r11 = _h_64;
    r12 = _h_65;
    r13 = _h_66;
    r14 = _h_54;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K673)
  {
    WL_POPN(1);
    u32 _command_19 = STK(0);
    Term _h_67 = r0;
    u32 _h_68 = r1;
    u32 _h_69 = r2;
    u32 _h_70 = r3;
    u32 _h_71 = r4;
    u32 _h_72 = r5;
    u32 _h_73 = r6;
    u32 _h_74 = r7;
    u32 _h_75 = r8;
    Term _h_76 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _command_19;
      STK(1) = _h_67;
      STK(2) = _h_68;
      STK(3) = _h_69;
      STK(4) = _h_70;
      STK(5) = _h_71;
      STK(6) = _h_72;
      STK(7) = _h_73;
      STK(8) = _h_74;
      STK(9) = _h_75;
      STK(10) = _h_76;
      STK(11) = FID_COMMAND_TEXT_K674;
      WL_PUSHN(12);
    } else {
      u64 _t_12 = task_node(e, FID_COMMAND_TEXT_K674, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _command_19;
      e.mem[_t_12 + 1] = _h_67;
      e.mem[_t_12 + 2] = _h_68;
      e.mem[_t_12 + 3] = _h_69;
      e.mem[_t_12 + 4] = _h_70;
      e.mem[_t_12 + 5] = _h_71;
      e.mem[_t_12 + 6] = _h_72;
      e.mem[_t_12 + 7] = _h_73;
      e.mem[_t_12 + 8] = _h_74;
      e.mem[_t_12 + 9] = _h_75;
      e.mem[_t_12 + 10] = _h_76;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K674, _t_12);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _command_19;
      return term_tsk(FID_U32_SHOW, _t_13);
    }
    r0 = _command_19;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K674)
  {
    WL_POPN(11);
    u32 _command_20 = STK(0);
    Term _h_78 = STK(1);
    u32 _h_79 = STK(2);
    u32 _h_80 = STK(3);
    u32 _h_81 = STK(4);
    u32 _h_82 = STK(5);
    u32 _h_83 = STK(6);
    u32 _h_84 = STK(7);
    u32 _h_85 = STK(8);
    u32 _h_86 = STK(9);
    Term _h_87 = STK(10);
    Term _h_77 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _command_20;
      STK(1) = _h_78;
      STK(2) = _h_79;
      STK(3) = _h_80;
      STK(4) = _h_81;
      STK(5) = _h_82;
      STK(6) = _h_83;
      STK(7) = _h_84;
      STK(8) = _h_85;
      STK(9) = _h_86;
      STK(10) = _h_77;
      STK(11) = FID_COMMAND_TEXT_K675;
      WL_PUSHN(12);
    } else {
      u64 _t_14 = task_node(e, FID_COMMAND_TEXT_K675, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _command_20;
      e.mem[_t_14 + 1] = _h_78;
      e.mem[_t_14 + 2] = _h_79;
      e.mem[_t_14 + 3] = _h_80;
      e.mem[_t_14 + 4] = _h_81;
      e.mem[_t_14 + 5] = _h_82;
      e.mem[_t_14 + 6] = _h_83;
      e.mem[_t_14 + 7] = _h_84;
      e.mem[_t_14 + 8] = _h_85;
      e.mem[_t_14 + 9] = _h_86;
      e.mem[_t_14 + 10] = _h_77;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K675, _t_14);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_15 + 1] = _h_87;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _h_87;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K675)
  {
    WL_POPN(11);
    u32 _command_21 = STK(0);
    Term _h_89 = STK(1);
    u32 _h_90 = STK(2);
    u32 _h_91 = STK(3);
    u32 _h_92 = STK(4);
    u32 _h_93 = STK(5);
    u32 _h_94 = STK(6);
    u32 _h_95 = STK(7);
    u32 _h_96 = STK(8);
    u32 _h_97 = STK(9);
    Term _h_98 = STK(10);
    Term _h_88 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _command_21;
      STK(1) = _h_89;
      STK(2) = _h_90;
      STK(3) = _h_91;
      STK(4) = _h_92;
      STK(5) = _h_93;
      STK(6) = _h_94;
      STK(7) = _h_95;
      STK(8) = _h_96;
      STK(9) = _h_97;
      STK(10) = FID_COMMAND_TEXT_K676;
      WL_PUSHN(11);
    } else {
      u64 _t_16 = task_node(e, FID_COMMAND_TEXT_K676, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _command_21;
      e.mem[_t_16 + 1] = _h_89;
      e.mem[_t_16 + 2] = _h_90;
      e.mem[_t_16 + 3] = _h_91;
      e.mem[_t_16 + 4] = _h_92;
      e.mem[_t_16 + 5] = _h_93;
      e.mem[_t_16 + 6] = _h_94;
      e.mem[_t_16 + 7] = _h_95;
      e.mem[_t_16 + 8] = _h_96;
      e.mem[_t_16 + 9] = _h_97;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K676, _t_16);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_98;
      e.mem[_t_17 + 1] = _h_88;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = _h_98;
    r1 = _h_88;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K676)
  {
    WL_POPN(10);
    u32 _command_22 = STK(0);
    Term _h_100 = STK(1);
    u32 _h_101 = STK(2);
    u32 _h_102 = STK(3);
    u32 _h_103 = STK(4);
    u32 _h_104 = STK(5);
    u32 _h_105 = STK(6);
    u32 _h_106 = STK(7);
    u32 _h_107 = STK(8);
    u32 _h_108 = STK(9);
    Term _h_99 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _command_22;
      STK(1) = _h_100;
      STK(2) = _h_101;
      STK(3) = _h_102;
      STK(4) = _h_103;
      STK(5) = _h_104;
      STK(6) = _h_105;
      STK(7) = _h_106;
      STK(8) = _h_107;
      STK(9) = _h_108;
      STK(10) = FID_COMMAND_TEXT_K677;
      WL_PUSHN(11);
    } else {
      u64 _t_18 = task_node(e, FID_COMMAND_TEXT_K677, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _command_22;
      e.mem[_t_18 + 1] = _h_100;
      e.mem[_t_18 + 2] = _h_101;
      e.mem[_t_18 + 3] = _h_102;
      e.mem[_t_18 + 4] = _h_103;
      e.mem[_t_18 + 5] = _h_104;
      e.mem[_t_18 + 6] = _h_105;
      e.mem[_t_18 + 7] = _h_106;
      e.mem[_t_18 + 8] = _h_107;
      e.mem[_t_18 + 9] = _h_108;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K677, _t_18);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 206);
      e.mem[_t_19 + 1] = _h_99;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 206);
    r1 = _h_99;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K677)
  {
    WL_POPN(10);
    u32 _command_23 = STK(0);
    Term _h_110 = STK(1);
    u32 _h_111 = STK(2);
    u32 _h_112 = STK(3);
    u32 _h_113 = STK(4);
    u32 _h_114 = STK(5);
    u32 _h_115 = STK(6);
    u32 _h_116 = STK(7);
    u32 _h_117 = STK(8);
    u32 _h_118 = STK(9);
    Term _h_109 = r0;
    WL_OPEN
    r0 = 1;
    r1 = _command_23;
    r2 = _h_110;
    r3 = _h_111;
    r4 = _h_112;
    r5 = _h_113;
    r6 = _h_114;
    r7 = _h_115;
    r8 = _h_116;
    r9 = _h_117;
    r10 = _h_118;
    r11 = 0;
    r12 = 0;
    r13 = 0;
    r14 = _h_109;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K678)
  {
    WL_POPN(1);
    u32 _command_24 = STK(0);
    Term _h_119 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _command_24;
      STK(1) = FID_COMMAND_TEXT_K679;
      WL_PUSHN(2);
    } else {
      u64 _t_22 = task_node(e, FID_COMMAND_TEXT_K679, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _command_24;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K679, _t_22);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 246);
      e.mem[_t_23 + 1] = _h_119;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 246);
    r1 = _h_119;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K679)
  {
    WL_POPN(1);
    u32 _command_25 = STK(0);
    Term _h_120 = r0;
    WL_OPEN
    r0 = 2;
    r1 = _command_25;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    r8 = 0;
    r9 = 0;
    r10 = 0;
    r11 = 0;
    r12 = 0;
    r13 = 0;
    r14 = _h_120;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K680)
  {
    WL_POPN(1);
    u32 _command_26 = STK(0);
    Term _h_121 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _command_26;
      STK(1) = FID_COMMAND_TEXT_K681;
      WL_PUSHN(2);
    } else {
      u64 _t_26 = task_node(e, FID_COMMAND_TEXT_K681, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _command_26;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K681, _t_26);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 264);
      e.mem[_t_27 + 1] = _h_121;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 264);
    r1 = _h_121;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K681)
  {
    WL_POPN(1);
    u32 _command_27 = STK(0);
    Term _h_122 = r0;
    WL_OPEN
    r0 = 3;
    r1 = _command_27;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    r8 = 0;
    r9 = 0;
    r10 = 0;
    r11 = 0;
    r12 = 0;
    r13 = 0;
    r14 = _h_122;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K682)
  {
    WL_POPN(1);
    u32 _command_28 = STK(0);
    Term _h_123 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _command_28;
      STK(1) = FID_COMMAND_TEXT_K683;
      WL_PUSHN(2);
    } else {
      u64 _t_30 = task_node(e, FID_COMMAND_TEXT_K683, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _command_28;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K683, _t_30);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 278);
      e.mem[_t_31 + 1] = _h_123;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 278);
    r1 = _h_123;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K683)
  {
    WL_POPN(1);
    u32 _command_29 = STK(0);
    Term _h_124 = r0;
    WL_OPEN
    r0 = 4;
    r1 = _command_29;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    r8 = 0;
    r9 = 0;
    r10 = 0;
    r11 = 0;
    r12 = 0;
    r13 = 0;
    r14 = _h_124;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K684)
  {
    WL_POPN(1);
    u32 _command_30 = STK(0);
    Term _h_125 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _command_30;
      STK(1) = FID_COMMAND_TEXT_K685;
      WL_PUSHN(2);
    } else {
      u64 _t_34 = task_node(e, FID_COMMAND_TEXT_K685, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _command_30;
      WL_CONT = term_tsk(FID_COMMAND_TEXT_K685, _t_34);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 282);
      e.mem[_t_35 + 1] = _h_125;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 282);
    r1 = _h_125;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMAND_TEXT_K685)
  {
    WL_POPN(1);
    u32 _command_31 = STK(0);
    Term _h_126 = r0;
    WL_OPEN
    r0 = 5;
    r1 = _command_31;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    r8 = 0;
    r9 = 0;
    r10 = 0;
    r11 = 0;
    r12 = 0;
    r13 = 0;
    r14 = _h_126;
    WL_RETN(15);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PING_TEXT)
  {
    Term _values_0 = r0;
    Term _text_0 = r1;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = _text_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_1;
        STK(1) = _text_0;
        STK(2) = FID_PING_TEXT_K692;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_PING_TEXT_K692, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _text_0;
        WL_CONT = term_tsk(FID_PING_TEXT_K692, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PING_TEXT_K692)
  {
    WL_POPN(2);
    Term _f_2 = STK(0);
    Term _text_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_2;
      STK(1) = _text_1;
      STK(2) = FID_PING_TEXT_K693;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_PING_TEXT_K693, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _text_1;
      WL_CONT = term_tsk(FID_PING_TEXT_K693, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 150);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 150);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PING_TEXT_K693)
  {
    WL_POPN(2);
    Term _f_3 = STK(0);
    Term _text_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_3;
      STK(1) = FID_PING_TEXT_K694;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_PING_TEXT_K694, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _f_3;
      WL_CONT = term_tsk(FID_PING_TEXT_K694, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _text_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _text_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PING_TEXT_K694)
  {
    WL_POPN(1);
    Term _f_4 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_PING_TEXT)) {
      u64 _t_6 = task_node(e, FID_PING_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _f_4;
      e.mem[_t_6 + 1] = _h_2;
      return term_tsk(FID_PING_TEXT, _t_6);
    }
    r0 = _f_4;
    r1 = _h_2;
    WL_JMP(FID_PING_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K696;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K696, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K696, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K696)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_BATCH)
  {
    Term _commands_0 = r0;
    u32 _namespace_0 = r1;
    u32 _tick_0 = r2;
    u32 _state_0 = r3;
    Term _state_1 = r4;
    Term _state_2 = r5;
    Term _state_3 = r6;
    Term _state_4 = r7;
    Term _state_5 = r8;
    Term _state_6 = r9;
    u32 _state_7 = r10;
    Term _state_8 = r11;
    u32 _state_9 = r12;
    Term _state_10 = r13;
    u32 _state_11 = r14;
    Term _state_12 = r15;
    u32 _state_13 = r16;
    Term _state_14 = r17;
    u32 _state_15 = r18;
    Term _state_16 = r19;
    u32 _state_17 = r20;
    u32 _state_18 = r21;
    Term _state_19 = r22;
    Term _state_20 = r23;
    WL_OPEN
    if (term_aux(_commands_0) == CID_NIL) {
      u32 _v_0 = 0;
      Term _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      u32 _v_7 = 0;
      Term _v_8 = 0;
      u32 _v_9 = 0;
      Term _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      u32 _v_13 = 0;
      Term _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _o_2[21];
      if (spin_83(e, _o_2, _state_0, _state_1, blk_loc(e.mem, _state_1), _state_2, blk_loc(e.mem, _state_2), _state_3, blk_loc(e.mem, _state_3), _state_4, blk_loc(e.mem, _state_4), _state_5, blk_loc(e.mem, _state_5), _state_6, blk_loc(e.mem, _state_6), _state_7, _state_8, _state_9, _state_10, blk_loc(e.mem, _state_10), _state_11, _state_12, blk_loc(e.mem, _state_12), _state_13, _state_14, blk_loc(e.mem, _state_14), _state_15, _state_16, blk_loc(e.mem, _state_16), _state_17, _state_18, _state_19, blk_loc(e.mem, _state_19), _state_20, blk_loc(e.mem, _state_20)) == 0) {
        return 0;
      }
      _v_0 = _o_2[0];
      _v_1 = _o_2[1];
      _v_2 = _o_2[2];
      _v_3 = _o_2[3];
      _v_4 = _o_2[4];
      _v_5 = _o_2[5];
      _v_6 = _o_2[6];
      _v_7 = _o_2[7];
      _v_8 = _o_2[8];
      _v_9 = _o_2[9];
      _v_10 = _o_2[10];
      _v_11 = _o_2[11];
      _v_12 = _o_2[12];
      _v_13 = _o_2[13];
      _v_14 = _o_2[14];
      _v_15 = _o_2[15];
      _v_16 = _o_2[16];
      _v_17 = _o_2[17];
      _v_18 = _o_2[18];
      _v_19 = _o_2[19];
      _v_20 = _o_2[20];
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      WL_RETN(21);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_3 = 0;
      u32 _o_4 = 0;
      Term _o_5 = 0;
      Term _o_6 = 0;
      u32 _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      if (term_aux(_f_0) == CID_STORAGE_SPAWN) {
        _o_3 = 0;
        Term _fb_1[7];
        u64 _sp_1 = ctr_take(e, _f_0, 7, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        u32 _f_7 = _fb_1[5];
        Term _f_8 = _fb_1[6];
        spare_free(e, cls_fit(7), _sp_1);
        _o_4 = _f_2;
        _o_5 = _f_3;
        _o_6 = _f_4;
        _o_7 = _f_5;
        _o_8 = _f_6;
        _o_9 = _f_7;
        _o_10 = _f_8;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTMAIN) {
        _o_3 = 1;
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _f_0, 2, _fb_2);
        u32 _f_9 = _fb_2[0];
        Term _f_10 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        _o_4 = _f_9;
        _o_5 = _f_10;
      } else if (term_aux(_f_0) == CID_STORAGE_INSERTFLAG) {
        _o_3 = 2;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_0, 2, _fb_3);
        u32 _f_11 = _fb_3[0];
        Term _f_12 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_4 = _f_11;
        _o_5 = _f_12;
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEMAIN) {
        _o_3 = 3;
        _o_4 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID_STORAGE_REMOVEFLAG) {
        _o_3 = 4;
        _o_4 = term_loc(_f_0);
      } else {
        _o_3 = 5;
        _o_4 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_1;
        STK(1) = _namespace_0;
        STK(2) = _tick_0;
        STK(3) = FID_COMMANDS_BATCH_K702;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_BATCH_K702, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _namespace_0;
        e.mem[_t_0 + 2] = _tick_0;
        WL_CONT = term_tsk(FID_COMMANDS_BATCH_K702, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_STATE_COMMAND)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_STATE_COMMAND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _namespace_0;
        e.mem[_t_1 + 1] = _tick_0;
        e.mem[_t_1 + 2] = _o_3;
        e.mem[_t_1 + 3] = _o_4;
        e.mem[_t_1 + 4] = _o_5;
        e.mem[_t_1 + 5] = _o_6;
        e.mem[_t_1 + 6] = _o_7;
        e.mem[_t_1 + 7] = _o_8;
        e.mem[_t_1 + 8] = _o_9;
        e.mem[_t_1 + 9] = _o_10;
        e.mem[_t_1 + 10] = _state_0;
        e.mem[_t_1 + 11] = _state_1;
        e.mem[_t_1 + 12] = _state_2;
        e.mem[_t_1 + 13] = _state_3;
        e.mem[_t_1 + 14] = _state_4;
        e.mem[_t_1 + 15] = _state_5;
        e.mem[_t_1 + 16] = _state_6;
        e.mem[_t_1 + 17] = _state_7;
        e.mem[_t_1 + 18] = _state_8;
        e.mem[_t_1 + 19] = _state_9;
        e.mem[_t_1 + 20] = _state_10;
        e.mem[_t_1 + 21] = _state_11;
        e.mem[_t_1 + 22] = _state_12;
        e.mem[_t_1 + 23] = _state_13;
        e.mem[_t_1 + 24] = _state_14;
        e.mem[_t_1 + 25] = _state_15;
        e.mem[_t_1 + 26] = _state_16;
        e.mem[_t_1 + 27] = _state_17;
        e.mem[_t_1 + 28] = _state_18;
        e.mem[_t_1 + 29] = _state_19;
        e.mem[_t_1 + 30] = _state_20;
        return term_tsk(FID_COMMANDS_STATE_COMMAND, _t_1);
      }
      r0 = _namespace_0;
      r1 = _tick_0;
      r2 = _o_3;
      r3 = _o_4;
      r4 = _o_5;
      r5 = _o_6;
      r6 = _o_7;
      r7 = _o_8;
      r8 = _o_9;
      r9 = _o_10;
      r10 = _state_0;
      r11 = _state_1;
      r12 = _state_2;
      r13 = _state_3;
      r14 = _state_4;
      r15 = _state_5;
      r16 = _state_6;
      r17 = _state_7;
      r18 = _state_8;
      r19 = _state_9;
      r20 = _state_10;
      r21 = _state_11;
      r22 = _state_12;
      r23 = _state_13;
      r24 = _state_14;
      r25 = _state_15;
      r26 = _state_16;
      r27 = _state_17;
      r28 = _state_18;
      r29 = _state_19;
      r30 = _state_20;
      WL_JMP(FID_COMMANDS_STATE_COMMAND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_BATCH_K702)
  {
    WL_POPN(3);
    Term _f_13 = STK(0);
    u32 _namespace_1 = STK(1);
    u32 _tick_1 = STK(2);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_BATCH)) {
      u64 _t_2 = task_node(e, FID_COMMANDS_BATCH, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_13;
      e.mem[_t_2 + 1] = _namespace_1;
      e.mem[_t_2 + 2] = _tick_1;
      e.mem[_t_2 + 3] = _h_0;
      e.mem[_t_2 + 4] = _h_1;
      e.mem[_t_2 + 5] = _h_2;
      e.mem[_t_2 + 6] = _h_3;
      e.mem[_t_2 + 7] = _h_4;
      e.mem[_t_2 + 8] = _h_5;
      e.mem[_t_2 + 9] = _h_6;
      e.mem[_t_2 + 10] = _h_7;
      e.mem[_t_2 + 11] = _h_8;
      e.mem[_t_2 + 12] = _h_9;
      e.mem[_t_2 + 13] = _h_10;
      e.mem[_t_2 + 14] = _h_11;
      e.mem[_t_2 + 15] = _h_12;
      e.mem[_t_2 + 16] = _h_13;
      e.mem[_t_2 + 17] = _h_14;
      e.mem[_t_2 + 18] = _h_15;
      e.mem[_t_2 + 19] = _h_16;
      e.mem[_t_2 + 20] = _h_17;
      e.mem[_t_2 + 21] = _h_18;
      e.mem[_t_2 + 22] = _h_19;
      e.mem[_t_2 + 23] = _h_20;
      return term_tsk(FID_COMMANDS_BATCH, _t_2);
    }
    r0 = _f_13;
    r1 = _namespace_1;
    r2 = _tick_1;
    r3 = _h_0;
    r4 = _h_1;
    r5 = _h_2;
    r6 = _h_3;
    r7 = _h_4;
    r8 = _h_5;
    r9 = _h_6;
    r10 = _h_7;
    r11 = _h_8;
    r12 = _h_9;
    r13 = _h_10;
    r14 = _h_11;
    r15 = _h_12;
    r16 = _h_13;
    r17 = _h_14;
    r18 = _h_15;
    r19 = _h_16;
    r20 = _h_17;
    r21 = _h_18;
    r22 = _h_19;
    r23 = _h_20;
    WL_JMP(FID_COMMANDS_BATCH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT)
  {
    Term _depth_0 = r0;
    Term _pending_0 = r1;
    Term _restored_0 = r2;
    Term _text_0 = r3;
    WL_OPEN
    if (term_aux(_pending_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _v_1 = 0;
      Term _o_1[1];
      if (spin_85(e, _o_1, _restored_0, blk_loc(e.mem, _restored_0)) == 0) {
        return 0;
      }
      _v_1 = _o_1[0];
      _v_0 = _v_1;
      r0 = _v_0;
      r1 = _text_0;
      WL_RETN(2);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _pending_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      u32 _o_12 = 0;
      u32 _o_13 = 0;
      u32 _o_14 = 0;
      u32 _o_15 = 0;
      if (term_aux(_f_2) == CID_STORAGE_SPAWN) {
        _o_2 = 0;
        Term _fb_2[7];
        u64 _sp_2 = ctr_take(e, _f_2, 7, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        Term _f_8 = _fb_2[4];
        u32 _f_9 = _fb_2[5];
        Term _f_10 = _fb_2[6];
        spare_free(e, cls_fit(7), _sp_2);
        u32 _o_16 = 0;
        Term _o_17 = 0;
        u32 _o_18 = 0;
        u32 _o_19 = 0;
        u32 _o_20 = 0;
        u32 _o_21 = 0;
        u32 _o_22 = 0;
        u32 _o_23 = 0;
        u32 _o_24 = 0;
        u32 _o_25 = 0;
        if (_f_5 == 0) {
          _o_16 = 0;
        } else {
          _o_16 = 1;
          Term _fb_3[9];
          u64 _sp_3 = ctr_take(e, _f_6, 9, _fb_3);
          Term _f_11 = _fb_3[0];
          u32 _f_12 = _fb_3[1];
          u32 _f_13 = _fb_3[2];
          u32 _f_14 = _fb_3[3];
          u32 _f_15 = _fb_3[4];
          u32 _f_16 = _fb_3[5];
          u32 _f_17 = _fb_3[6];
          u32 _f_18 = _fb_3[7];
          u32 _f_19 = _fb_3[8];
          spare_free(e, cls_fit(9), _sp_3);
          _o_17 = _f_11;
          _o_18 = _f_12;
          _o_19 = _f_13;
          _o_20 = _f_14;
          _o_21 = _f_15;
          _o_22 = _f_16;
          _o_23 = _f_17;
          _o_24 = _f_18;
          _o_25 = _f_19;
        }
        u32 _o_26 = 0;
        if (_f_7 == 0) {
          _o_26 = 0;
        } else {
          _o_26 = 1;
        }
        u32 _o_27 = 0;
        if (_f_9 == 0) {
          _o_27 = 0;
        } else {
          _o_27 = 1;
        }
        _o_3 = _f_4;
        _o_4 = _o_16;
        _o_5 = _o_17;
        _o_6 = _o_18;
        _o_7 = _o_19;
        _o_8 = _o_20;
        _o_9 = _o_21;
        _o_10 = _o_22;
        _o_11 = _o_23;
        _o_12 = _o_24;
        _o_13 = _o_25;
        _o_14 = _o_26;
        _o_15 = _o_27;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTMAIN) {
        _o_2 = 1;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_2, 2, _fb_4);
        u32 _f_20 = _fb_4[0];
        Term _f_21 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        Term _fb_5[9];
        u64 _sp_5 = ctr_take(e, _f_21, 9, _fb_5);
        Term _f_22 = _fb_5[0];
        u32 _f_23 = _fb_5[1];
        u32 _f_24 = _fb_5[2];
        u32 _f_25 = _fb_5[3];
        u32 _f_26 = _fb_5[4];
        u32 _f_27 = _fb_5[5];
        u32 _f_28 = _fb_5[6];
        u32 _f_29 = _fb_5[7];
        u32 _f_30 = _fb_5[8];
        spare_free(e, cls_fit(9), _sp_5);
        _o_3 = _f_20;
        _o_4 = _f_22;
        _o_5 = _f_23;
        _o_6 = _f_24;
        _o_7 = _f_25;
        _o_8 = _f_26;
        _o_9 = _f_27;
        _o_10 = _f_28;
        _o_11 = _f_29;
        _o_12 = _f_30;
      } else if (term_aux(_f_2) == CID_STORAGE_INSERTFLAG) {
        _o_2 = 2;
        Term _fb_6[2];
        u64 _sp_6 = ctr_take(e, _f_2, 2, _fb_6);
        u32 _f_31 = _fb_6[0];
        Term _f_32 = _fb_6[1];
        spare_free(e, cls_fit(2), _sp_6);
        _o_3 = _f_31;
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEMAIN) {
        _o_2 = 3;
        _o_3 = term_loc(_f_2);
      } else if (term_aux(_f_2) == CID_STORAGE_REMOVEFLAG) {
        _o_2 = 4;
        _o_3 = term_loc(_f_2);
      } else {
        _o_2 = 5;
        _o_3 = term_loc(_f_2);
      }
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _depth_0;
        STK(1) = _f_3;
        STK(2) = _restored_0;
        STK(3) = _text_0;
        STK(4) = FID_QUEUE_TEXT_K739;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID_QUEUE_TEXT_K739, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _depth_0;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _restored_0;
        e.mem[_t_0 + 3] = _text_0;
        WL_CONT = term_tsk(FID_QUEUE_TEXT_K739, _t_0);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMAND_TEXT)) {
        u64 _t_1 = task_node(e, FID_COMMAND_TEXT, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _depth_0;
        e.mem[_t_1 + 1] = _o_2;
        e.mem[_t_1 + 2] = _o_3;
        e.mem[_t_1 + 3] = _o_4;
        e.mem[_t_1 + 4] = _o_5;
        e.mem[_t_1 + 5] = _o_6;
        e.mem[_t_1 + 6] = _o_7;
        e.mem[_t_1 + 7] = _o_8;
        e.mem[_t_1 + 8] = _o_9;
        e.mem[_t_1 + 9] = _o_10;
        e.mem[_t_1 + 10] = _o_11;
        e.mem[_t_1 + 11] = _o_12;
        e.mem[_t_1 + 12] = _o_13;
        e.mem[_t_1 + 13] = _o_14;
        e.mem[_t_1 + 14] = _o_15;
        return term_tsk(FID_COMMAND_TEXT, _t_1);
      }
      r0 = _depth_0;
      r1 = _o_2;
      r2 = _o_3;
      r3 = _o_4;
      r4 = _o_5;
      r5 = _o_6;
      r6 = _o_7;
      r7 = _o_8;
      r8 = _o_9;
      r9 = _o_10;
      r10 = _o_11;
      r11 = _o_12;
      r12 = _o_13;
      r13 = _o_14;
      r14 = _o_15;
      WL_JMP(FID_COMMAND_TEXT);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_K739)
  {
    WL_POPN(4);
    Term _depth_1 = STK(0);
    Term _f_33 = STK(1);
    Term _restored_1 = STK(2);
    Term _text_1 = STK(3);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _depth_1;
    e.mem[_nd_1 + 1] = _f_33;
    Term _continue_owner_0 = term_clo(FID_QUEUE_TEXT_C740, _nd_1);
    Term _b_0 = 0;
    if (_h_0 == 0) {
      u32 _o_28 = 0;
      Term _o_29 = 0;
      if (_h_2 == 0) {
        _o_28 = 0;
      } else {
        _o_28 = 1;
        u64 _nd_4 = heap_alloc(e, cls_fit(9));
        e.mem[_nd_4 + 0] = rfc_seal(e, _h_3);
        e.mem[_nd_4 + 1] = rfc_seal(e, _h_4);
        e.mem[_nd_4 + 2] = rfc_seal(e, _h_5);
        e.mem[_nd_4 + 3] = rfc_seal(e, _h_6);
        e.mem[_nd_4 + 4] = rfc_seal(e, _h_7);
        e.mem[_nd_4 + 5] = rfc_seal(e, _h_8);
        e.mem[_nd_4 + 6] = rfc_seal(e, _h_9);
        e.mem[_nd_4 + 7] = rfc_seal(e, _h_10);
        e.mem[_nd_4 + 8] = rfc_seal(e, _h_11);
        _o_29 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_4);
      }
      u32 _o_30 = 0;
      Term _o_31 = 0;
      if (_h_12 == 0) {
        _o_30 = 0;
      } else {
        _o_30 = 1;
        _o_31 = term_pak(CID_UNIT, 0);
      }
      u32 _o_32 = 0;
      Term _o_33 = 0;
      if (_h_13 == 0) {
        _o_32 = 0;
      } else {
        _o_32 = 1;
        _o_33 = term_pak(CID_UNIT, 0);
      }
      u64 _nd_5 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_5 + 0] = rfc_seal(e, _h_1);
      e.mem[_nd_5 + 1] = rfc_seal(e, _o_28);
      e.mem[_nd_5 + 2] = rfc_seal(e, _o_29);
      e.mem[_nd_5 + 3] = rfc_seal(e, _o_30);
      e.mem[_nd_5 + 4] = rfc_seal(e, _o_31);
      e.mem[_nd_5 + 5] = rfc_seal(e, _o_32);
      e.mem[_nd_5 + 6] = rfc_seal(e, _o_33);
      _b_0 = term_ctr(CID_STORAGE_SPAWN, _nd_5);
    } else if (_h_0 == 1) {
      u64 _nd_6 = heap_alloc(e, cls_fit(9));
      e.mem[_nd_6 + 0] = rfc_seal(e, _h_2);
      e.mem[_nd_6 + 1] = rfc_seal(e, _h_3);
      e.mem[_nd_6 + 2] = rfc_seal(e, _h_4);
      e.mem[_nd_6 + 3] = rfc_seal(e, _h_5);
      e.mem[_nd_6 + 4] = rfc_seal(e, _h_6);
      e.mem[_nd_6 + 5] = rfc_seal(e, _h_7);
      e.mem[_nd_6 + 6] = rfc_seal(e, _h_8);
      e.mem[_nd_6 + 7] = rfc_seal(e, _h_9);
      e.mem[_nd_6 + 8] = rfc_seal(e, _h_10);
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, _h_1);
      e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_6));
      _b_0 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_7);
    } else if (_h_0 == 2) {
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, _h_1);
      e.mem[_nd_8 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
      _b_0 = term_ctr(CID_STORAGE_INSERTFLAG, _nd_8);
    } else if (_h_0 == 3) {
      _b_0 = term_pak(CID_STORAGE_REMOVEMAIN, _h_1);
    } else if (_h_0 == 4) {
      _b_0 = term_pak(CID_STORAGE_REMOVEFLAG, _h_1);
    } else {
      _b_0 = term_pak(CID_STORAGE_DESPAWN, _h_1);
    }
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_9 + 1] = rfc_seal(e, _restored_1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _text_1;
      STK(1) = _h_14;
      STK(2) = FID_QUEUE_TEXT_K743;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_QUEUE_TEXT_K743, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _text_1;
      e.mem[_t_4 + 1] = _h_14;
      WL_CONT = term_tsk(FID_QUEUE_TEXT_K743, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _continue_owner_0;
      e.mem[_t_5 + 1] = term_ctr(CID_CON, _nd_9);
      return term_tsk(FID_CLO_APPLY, _t_5);
    }
    r0 = _continue_owner_0;
    r1 = term_ctr(CID_CON, _nd_9);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_C740)
  {
    Term _depth_2 = r0;
    Term _f_34 = r1;
    Term _x_0 = r2;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = _depth_2;
    e.mem[_nd_2 + 1] = _f_34;
    e.mem[_nd_2 + 2] = _x_0;
    r0 = term_clo(FID_QUEUE_TEXT_C741, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_C741)
  {
    Term _depth_3 = r0;
    Term _f_35 = r1;
    Term _x_2 = r2;
    Term _x_1 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_QUEUE_TEXT_K742;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_QUEUE_TEXT_K742, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_QUEUE_TEXT_K742, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_QUEUE_TEXT)) {
      u64 _t_3 = task_node(e, FID_QUEUE_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _depth_3;
      e.mem[_t_3 + 1] = _f_35;
      e.mem[_t_3 + 2] = _x_2;
      e.mem[_t_3 + 3] = _x_1;
      return term_tsk(FID_QUEUE_TEXT, _t_3);
    }
    r0 = _depth_3;
    r1 = _f_35;
    r2 = _x_2;
    r3 = _x_1;
    WL_JMP(FID_QUEUE_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_K742)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _r_1);
    r0 = term_ctr(CID_TUPLE, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_K743)
  {
    WL_POPN(2);
    Term _text_2 = STK(0);
    Term _h_16 = STK(1);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _text_2;
      STK(1) = _h_15;
      STK(2) = FID_QUEUE_TEXT_K744;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_QUEUE_TEXT_K744, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _text_2;
      e.mem[_t_6 + 1] = _h_15;
      WL_CONT = term_tsk(FID_QUEUE_TEXT_K744, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_16;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 284);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_16;
    r1 = term_ctr(CID_SCON, STAT_OFF + 284);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_K744)
  {
    WL_POPN(2);
    Term _text_3 = STK(0);
    Term _h_18 = STK(1);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_18;
      STK(1) = FID_QUEUE_TEXT_K745;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_QUEUE_TEXT_K745, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_18;
      WL_CONT = term_tsk(FID_QUEUE_TEXT_K745, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _text_3;
      e.mem[_t_9 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _text_3;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_K745)
  {
    WL_POPN(1);
    Term _h_20 = STK(0);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_QUEUE_TEXT_K746;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_QUEUE_TEXT_K746, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_QUEUE_TEXT_K746, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_11 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_20;
      e.mem[_t_11 + 1] = _h_19;
      return term_tsk(FID_CLO_APPLY, _t_11);
    }
    r0 = _h_20;
    r1 = _h_19;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_TEXT_K746)
  {
    Term _r_2 = r0;
    WL_OPEN
    Term _fb_7[2];
    u64 _sp_7 = ctr_take(e, _r_2, 2, _fb_7);
    Term _f_36 = _fb_7[0];
    Term _f_37 = _fb_7[1];
    spare_free(e, cls_fit(2), _sp_7);
    r0 = _f_36;
    r1 = _f_37;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_POW)
  {
    u32 _a_0 = r0;
    Term _n_0 = r1;
    WL_OPEN
    WL_SPIN
    if (_n_0 == 0) {
      r0 = 1ull;
      WL_RETN(1);
    } else {
      Term _p_0 = (_n_0 - 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _a_0;
        STK(1) = FID_U32_POW_K753;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_U32_POW_K753, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _a_0;
        WL_CONT = term_tsk(FID_U32_POW_K753, _t_0);
        WL_IDX = 1;
      }
      r0 = _a_0;
      r1 = _p_0;
      _a_0 = r0;
      _n_0 = r1;
      WL_AGAIN(FID_U32_POW);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_POW_K753)
  {
    WL_POPN(1);
    u32 _a_1 = STK(0);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = U32_BIN(_a_1, *, _h_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_LOOP)
  {
    Term _n_0 = r0;
    Term _depth_0 = r1;
    u32 _id_0 = r2;
    u32 _owner_0 = r3;
    u32 _owner_1 = r4;
    Term _owner_2 = r5;
    Term _owner_3 = r6;
    Term _owner_4 = r7;
    Term _owner_5 = r8;
    Term _owner_6 = r9;
    Term _owner_7 = r10;
    u32 _owner_8 = r11;
    Term _owner_9 = r12;
    u32 _owner_10 = r13;
    Term _owner_11 = r14;
    u32 _owner_12 = r15;
    u32 _owner_13 = r16;
    u32 _owner_14 = r17;
    Term _owner_15 = r18;
    Term _owner_16 = r19;
    Term _owner_17 = r20;
    Term _owner_18 = r21;
    WL_OPEN
    if (_n_0 == 0) {
      r0 = _owner_0;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = _owner_3;
      r4 = _owner_4;
      r5 = _owner_5;
      r6 = _owner_6;
      r7 = _owner_7;
      r8 = _owner_8;
      r9 = _owner_9;
      r10 = _owner_10;
      r11 = _owner_11;
      r12 = _owner_12;
      r13 = _owner_13;
      r14 = _owner_14;
      r15 = _owner_15;
      r16 = _owner_16;
      r17 = _owner_17;
      r18 = _owner_18;
      WL_RETN(19);
    } else {
      Term _tail_0 = (_n_0 - 1);
      if (seq) {
        WL_ROOM(23);
        STK(0) = _tail_0;
        STK(1) = _depth_0;
        STK(2) = _id_0;
        STK(3) = _owner_0;
        STK(4) = _owner_1;
        STK(5) = _owner_2;
        STK(6) = _owner_3;
        STK(7) = _owner_4;
        STK(8) = _owner_5;
        STK(9) = _owner_6;
        STK(10) = _owner_7;
        STK(11) = _owner_8;
        STK(12) = _owner_9;
        STK(13) = _owner_10;
        STK(14) = _owner_11;
        STK(15) = _owner_12;
        STK(16) = _owner_13;
        STK(17) = _owner_14;
        STK(18) = _owner_15;
        STK(19) = _owner_16;
        STK(20) = _owner_17;
        STK(21) = _owner_18;
        STK(22) = FID_TX_LOOP_K797;
        WL_PUSHN(23);
      } else {
        u64 _t_0 = task_node(e, FID_TX_LOOP_K797, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _tail_0;
        e.mem[_t_0 + 1] = _depth_0;
        e.mem[_t_0 + 2] = _id_0;
        e.mem[_t_0 + 3] = _owner_0;
        e.mem[_t_0 + 4] = _owner_1;
        e.mem[_t_0 + 5] = _owner_2;
        e.mem[_t_0 + 6] = _owner_3;
        e.mem[_t_0 + 7] = _owner_4;
        e.mem[_t_0 + 8] = _owner_5;
        e.mem[_t_0 + 9] = _owner_6;
        e.mem[_t_0 + 10] = _owner_7;
        e.mem[_t_0 + 11] = _owner_8;
        e.mem[_t_0 + 12] = _owner_9;
        e.mem[_t_0 + 13] = _owner_10;
        e.mem[_t_0 + 14] = _owner_11;
        e.mem[_t_0 + 15] = _owner_12;
        e.mem[_t_0 + 16] = _owner_13;
        e.mem[_t_0 + 17] = _owner_14;
        e.mem[_t_0 + 18] = _owner_15;
        e.mem[_t_0 + 19] = _owner_16;
        e.mem[_t_0 + 20] = _owner_17;
        e.mem[_t_0 + 21] = _owner_18;
        WL_CONT = term_tsk(FID_TX_LOOP_K797, _t_0);
        WL_IDX = 22;
      }
      if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
        u64 _t_1 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _depth_0;
        e.mem[_t_1 + 1] = U32_BIN(100ull, +, _id_0);
        return term_tsk(FID_MAKE_SLOT, _t_1);
      }
      r0 = _depth_0;
      r1 = U32_BIN(100ull, +, _id_0);
      WL_JMP(FID_MAKE_SLOT);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_LOOP_K797)
  {
    WL_POPN(22);
    Term _tail_1 = STK(0);
    Term _depth_1 = STK(1);
    u32 _id_1 = STK(2);
    u32 _owner_19 = STK(3);
    u32 _owner_20 = STK(4);
    Term _owner_21 = STK(5);
    Term _owner_22 = STK(6);
    Term _owner_23 = STK(7);
    Term _owner_24 = STK(8);
    Term _owner_25 = STK(9);
    Term _owner_26 = STK(10);
    u32 _owner_27 = STK(11);
    Term _owner_28 = STK(12);
    u32 _owner_29 = STK(13);
    Term _owner_30 = STK(14);
    u32 _owner_31 = STK(15);
    u32 _owner_32 = STK(16);
    u32 _owner_33 = STK(17);
    Term _owner_34 = STK(18);
    Term _owner_35 = STK(19);
    Term _owner_36 = STK(20);
    Term _owner_37 = STK(21);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u64 _nd_0 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _h_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, _h_8);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _id_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_0));
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_owner_31 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      _o_1 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_2 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_2 + 0] = rfc_seal(e, _owner_19);
    e.mem[_nd_2 + 1] = rfc_seal(e, _owner_20);
    e.mem[_nd_2 + 2] = rfc_seal(e, _owner_21);
    e.mem[_nd_2 + 3] = rfc_seal(e, _owner_22);
    e.mem[_nd_2 + 4] = rfc_seal(e, _owner_23);
    e.mem[_nd_2 + 5] = rfc_seal(e, _owner_24);
    e.mem[_nd_2 + 6] = rfc_seal(e, _owner_25);
    e.mem[_nd_2 + 7] = rfc_seal(e, _owner_26);
    e.mem[_nd_2 + 8] = rfc_seal(e, _owner_27);
    e.mem[_nd_2 + 9] = rfc_seal(e, _owner_28);
    e.mem[_nd_2 + 10] = rfc_seal(e, _owner_29);
    e.mem[_nd_2 + 11] = rfc_seal(e, _owner_30);
    e.mem[_nd_2 + 12] = rfc_seal(e, _o_0);
    e.mem[_nd_2 + 13] = rfc_seal(e, _o_1);
    e.mem[_nd_2 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _owner_32);
    e.mem[_nd_3 + 1] = rfc_seal(e, _owner_33);
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _o_2[6];
    Term _a_0 = term_ctr(CID_STORAGE_WORLD, _nd_2);
    Term _a_1 = term_ctr(CID_STORAGE_HANDLE, _nd_3);
    Term _a_2 = term_ctr(CID_STORAGE_INSERTMAIN, _nd_1);
    if (spin_93(e, _o_2, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1), _owner_34, blk_loc(e.mem, _owner_34), _owner_35, blk_loc(e.mem, _owner_35), _owner_36, blk_loc(e.mem, _owner_36), _owner_37, blk_loc(e.mem, _owner_37), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_6 = _o_2[0];
    _v_7 = _o_2[1];
    _v_8 = _o_2[2];
    _v_9 = _o_2[3];
    _v_10 = _o_2[4];
    _v_11 = _o_2[5];
    _v_0 = _v_6;
    _v_1 = _v_7;
    _v_2 = _v_8;
    _v_3 = _v_9;
    _v_4 = _v_10;
    _v_5 = _v_11;
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _v_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    u32 _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    Term _f_13 = _fb_0[13];
    Term _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    u32 _o_3 = 0;
    if (_f_12 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
    }
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _v_1, 2, _fb_1);
    u32 _f_15 = _fb_1[0];
    u32 _f_16 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    if (!DEVICE && !seq && fid_nofk(FID_TX_LOOP)) {
      u64 _t_8 = task_node(e, FID_TX_LOOP, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _tail_1;
      e.mem[_t_8 + 1] = _depth_1;
      e.mem[_t_8 + 2] = U32_BIN(_id_1, +, 1ull);
      e.mem[_t_8 + 3] = _f_0;
      e.mem[_t_8 + 4] = _f_1;
      e.mem[_t_8 + 5] = _f_2;
      e.mem[_t_8 + 6] = _f_3;
      e.mem[_t_8 + 7] = _f_4;
      e.mem[_t_8 + 8] = _f_5;
      e.mem[_t_8 + 9] = _f_6;
      e.mem[_t_8 + 10] = _f_7;
      e.mem[_t_8 + 11] = _f_8;
      e.mem[_t_8 + 12] = _f_9;
      e.mem[_t_8 + 13] = _f_10;
      e.mem[_t_8 + 14] = _f_11;
      e.mem[_t_8 + 15] = _o_3;
      e.mem[_t_8 + 16] = _f_15;
      e.mem[_t_8 + 17] = _f_16;
      e.mem[_t_8 + 18] = _v_2;
      e.mem[_t_8 + 19] = _v_3;
      e.mem[_t_8 + 20] = _v_4;
      e.mem[_t_8 + 21] = _v_5;
      return term_tsk(FID_TX_LOOP, _t_8);
    }
    r0 = _tail_1;
    r1 = _depth_1;
    r2 = U32_BIN(_id_1, +, 1ull);
    r3 = _f_0;
    r4 = _f_1;
    r5 = _f_2;
    r6 = _f_3;
    r7 = _f_4;
    r8 = _f_5;
    r9 = _f_6;
    r10 = _f_7;
    r11 = _f_8;
    r12 = _f_9;
    r13 = _f_10;
    r14 = _f_11;
    r15 = _o_3;
    r16 = _f_15;
    r17 = _f_16;
    r18 = _v_2;
    r19 = _v_3;
    r20 = _v_4;
    r21 = _v_5;
    WL_JMP(FID_TX_LOOP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR)
  {
    Term _depth_0 = r0;
    u32 _seed_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _depth_0;
      STK(1) = _seed_0;
      STK(2) = FID_ARR_K807;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_ARR_K807, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _depth_0;
      e.mem[_t_0 + 1] = _seed_0;
      WL_CONT = term_tsk(FID_ARR_K807, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_POW)) {
      u64 _t_1 = task_node(e, FID_U32_POW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 2ull;
      e.mem[_t_1 + 1] = _depth_0;
      return term_tsk(FID_U32_POW, _t_1);
    }
    r0 = 2ull;
    r1 = _depth_0;
    WL_JMP(FID_U32_POW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ARR_K807)
  {
    WL_POPN(2);
    Term _depth_1 = STK(0);
    u32 _seed_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 0ull;
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_0 = blk_new(e, 0, _depth_1, 0, 1, _fv_0);
    if (spin_97(e, _o_0, ((u64)_h_0), 0ull, _a_0, blk_loc(e.mem, _a_0), _seed_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_APPLY_CHECKED)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _tick_0 = r15;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_1[11];
    if (spin_100(e, _o_1, _world_11, blk_loc(e.mem, _world_11), _world_2, blk_loc(e.mem, _world_2), _world_3, blk_loc(e.mem, _world_3), _world_4, blk_loc(e.mem, _world_4), _world_5, blk_loc(e.mem, _world_5), _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    _v_14 = _o_1[3];
    _v_15 = _o_1[4];
    _v_16 = _o_1[5];
    _v_17 = _o_1[6];
    _v_18 = _o_1[7];
    _v_19 = _o_1[8];
    _v_20 = _o_1[9];
    _v_21 = _o_1[10];
    _v_0 = _v_11;
    _v_1 = _v_12;
    _v_2 = _v_13;
    _v_3 = _v_14;
    _v_4 = _v_15;
    _v_5 = _v_16;
    _v_6 = _v_17;
    _v_7 = _v_18;
    _v_8 = _v_19;
    _v_9 = _v_20;
    _v_10 = _v_21;
    if (_v_10 == 0) {
      r0 = 1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _v_0;
      r4 = _v_1;
      r5 = _v_2;
      r6 = _v_3;
      r7 = _v_4;
      r8 = _v_5;
      r9 = _v_6;
      r10 = _v_7;
      r11 = _v_8;
      r12 = _v_9;
      r13 = _world_12;
      r14 = _world_13;
      r15 = _world_14;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      WL_RETN(26);
    } else {
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_2[1];
      if (spin_27(e, _o_2, _v_9, blk_loc(e.mem, _v_9)) == 0) {
        return 0;
      }
      _v_45 = _o_2[0];
      _v_44 = _v_45;
      if (seq) {
        WL_ROOM(6);
        STK(0) = _world_0;
        STK(1) = _world_1;
        STK(2) = _world_12;
        STK(3) = _world_13;
        STK(4) = _world_14;
        STK(5) = FID_COMMANDS_APPLY_CHECKED_K811;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_COMMANDS_APPLY_CHECKED_K811, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _world_0;
        e.mem[_t_0 + 1] = _world_1;
        e.mem[_t_0 + 2] = _world_12;
        e.mem[_t_0 + 3] = _world_13;
        e.mem[_t_0 + 4] = _world_14;
        WL_CONT = term_tsk(FID_COMMANDS_APPLY_CHECKED_K811, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_BATCH)) {
        u64 _t_1 = task_node(e, FID_COMMANDS_BATCH, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_44;
        e.mem[_t_1 + 1] = _world_0;
        e.mem[_t_1 + 2] = _tick_0;
        e.mem[_t_1 + 3] = 0;
        e.mem[_t_1 + 4] = _v_0;
        e.mem[_t_1 + 5] = _v_1;
        e.mem[_t_1 + 6] = _v_2;
        e.mem[_t_1 + 7] = _v_3;
        e.mem[_t_1 + 8] = _v_4;
        e.mem[_t_1 + 9] = _v_5;
        e.mem[_t_1 + 10] = _v_6;
        e.mem[_t_1 + 11] = _v_7;
        e.mem[_t_1 + 12] = _v_8;
        e.mem[_t_1 + 13] = term_pak(CID_NIL, 0);
        e.mem[_t_1 + 14] = 0;
        e.mem[_t_1 + 15] = 0;
        e.mem[_t_1 + 16] = 0;
        e.mem[_t_1 + 17] = 0;
        e.mem[_t_1 + 18] = 0;
        e.mem[_t_1 + 19] = 0;
        e.mem[_t_1 + 20] = 0;
        e.mem[_t_1 + 21] = 0;
        e.mem[_t_1 + 22] = 0;
        e.mem[_t_1 + 23] = 0;
        return term_tsk(FID_COMMANDS_BATCH, _t_1);
      }
      r0 = _v_44;
      r1 = _world_0;
      r2 = _tick_0;
      r3 = 0;
      r4 = _v_0;
      r5 = _v_1;
      r6 = _v_2;
      r7 = _v_3;
      r8 = _v_4;
      r9 = _v_5;
      r10 = _v_6;
      r11 = _v_7;
      r12 = _v_8;
      r13 = term_pak(CID_NIL, 0);
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      WL_JMP(FID_COMMANDS_BATCH);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMMANDS_APPLY_CHECKED_K811)
  {
    WL_POPN(5);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    u32 _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    WL_OPEN
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _o_3[26];
    if (spin_92(e, _o_3, _world_15, _world_16, _world_17, _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_46 = _o_3[0];
    _v_47 = _o_3[1];
    _v_48 = _o_3[2];
    _v_49 = _o_3[3];
    _v_50 = _o_3[4];
    _v_51 = _o_3[5];
    _v_52 = _o_3[6];
    _v_53 = _o_3[7];
    _v_54 = _o_3[8];
    _v_55 = _o_3[9];
    _v_56 = _o_3[10];
    _v_57 = _o_3[11];
    _v_58 = _o_3[12];
    _v_59 = _o_3[13];
    _v_60 = _o_3[14];
    _v_61 = _o_3[15];
    _v_62 = _o_3[16];
    _v_63 = _o_3[17];
    _v_64 = _o_3[18];
    _v_65 = _o_3[19];
    _v_66 = _o_3[20];
    _v_67 = _o_3[21];
    _v_68 = _o_3[22];
    _v_69 = _o_3[23];
    _v_70 = _o_3[24];
    _v_71 = _o_3[25];
    r0 = _v_46;
    r1 = _v_47;
    r2 = _v_48;
    r3 = _v_49;
    r4 = _v_50;
    r5 = _v_51;
    r6 = _v_52;
    r7 = _v_53;
    r8 = _v_54;
    r9 = _v_55;
    r10 = _v_56;
    r11 = _v_57;
    r12 = _v_58;
    r13 = _v_59;
    r14 = _v_60;
    r15 = _v_61;
    r16 = _v_62;
    r17 = _v_63;
    r18 = _v_64;
    r19 = _v_65;
    r20 = _v_66;
    r21 = _v_67;
    r22 = _v_68;
    r23 = _v_69;
    r24 = _v_70;
    r25 = _v_71;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAKE_SLOT)
  {
    Term _depth_0 = r0;
    u32 _seed_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAKE_SLOT_K854;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAKE_SLOT_K854, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAKE_SLOT_K854, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ARR)) {
      u64 _t_1 = task_node(e, FID_ARR, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _depth_0;
      e.mem[_t_1 + 1] = _seed_0;
      return term_tsk(FID_ARR, _t_1);
    }
    r0 = _depth_0;
    r1 = _seed_0;
    WL_JMP(FID_ARR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAKE_SLOT_K854)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _o_2[9];
    if (spin_107(e, _o_2, _h_0, blk_loc(e.mem, _h_0), 17ull, 23ull) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    _v_7 = _o_2[7];
    _v_8 = _o_2[8];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_ONE)
  {
    Term _depth_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[15];
    if (spin_102(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_20 = _o_0[5];
    _v_21 = _o_0[6];
    _v_22 = _o_0[7];
    _v_23 = _o_0[8];
    _v_24 = _o_0[9];
    _v_25 = _o_0[10];
    _v_26 = _o_0[11];
    _v_27 = _o_0[12];
    _v_28 = _o_0[13];
    _v_29 = _o_0[14];
    _v_0 = _v_15;
    _v_1 = _v_16;
    _v_2 = _v_17;
    _v_3 = _v_18;
    _v_4 = _v_19;
    _v_5 = _v_20;
    _v_6 = _v_21;
    _v_7 = _v_22;
    _v_8 = _v_23;
    _v_9 = _v_24;
    _v_10 = _v_25;
    _v_11 = _v_26;
    _v_12 = _v_27;
    _v_13 = _v_28;
    _v_14 = _v_29;
    if (_v_0 == 0) {
      u32 _v_30 = 0;
      u32 _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      Term _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      u32 _v_40 = 0;
      Term _v_41 = 0;
      u32 _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      u32 _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      if (_v_14 == 0) {
        _o_1 = 0;
      } else {
        _o_1 = 1;
        _o_2 = term_pak(CID_UNIT, 0);
      }
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      Term _v_57 = 0;
      u32 _v_58 = 0;
      Term _v_59 = 0;
      u32 _v_60 = 0;
      Term _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      Term _o_3[18];
      Term _a_0 = term_pak(CID_UNIT, 0);
      if (spin_63(e, _o_3, _v_2, _v_3, _v_4, blk_loc(e.mem, _v_4), _v_5, blk_loc(e.mem, _v_5), _v_6, blk_loc(e.mem, _v_6), _v_7, blk_loc(e.mem, _v_7), _v_8, blk_loc(e.mem, _v_8), _v_9, blk_loc(e.mem, _v_9), _v_10, _v_11, _v_12, _v_13, blk_loc(e.mem, _v_13), _o_1, _o_2, blk_loc(e.mem, _o_2), _a_0, blk_loc(e.mem, _a_0)) == 0) {
        return 0;
      }
      _v_48 = _o_3[0];
      _v_49 = _o_3[1];
      _v_50 = _o_3[2];
      _v_51 = _o_3[3];
      _v_52 = _o_3[4];
      _v_53 = _o_3[5];
      _v_54 = _o_3[6];
      _v_55 = _o_3[7];
      _v_56 = _o_3[8];
      _v_57 = _o_3[9];
      _v_58 = _o_3[10];
      _v_59 = _o_3[11];
      _v_60 = _o_3[12];
      _v_61 = _o_3[13];
      _v_62 = _o_3[14];
      _v_63 = _o_3[15];
      _v_64 = _o_3[16];
      _v_65 = _o_3[17];
      _v_30 = _v_48;
      _v_31 = _v_49;
      _v_32 = _v_50;
      _v_33 = _v_51;
      _v_34 = _v_52;
      _v_35 = _v_53;
      _v_36 = _v_54;
      _v_37 = _v_55;
      _v_38 = _v_56;
      _v_39 = _v_57;
      _v_40 = _v_58;
      _v_41 = _v_59;
      _v_42 = _v_60;
      _v_43 = _v_61;
      _v_44 = _v_62;
      _v_45 = _v_63;
      _v_46 = _v_64;
      _v_47 = _v_65;
      u32 _o_4 = 0;
      if (_v_42 == 0) {
        _o_4 = 0;
      } else {
        _o_4 = 1;
      }
      if (_v_45 == 1) {
        Term _v_66 = 0;
        Term _v_67 = 0;
        Term _v_68 = 0;
        Term _v_69 = 0;
        Term _v_70 = 0;
        Term _v_71 = 0;
        u32 _o_5 = 0;
        Term _o_6 = 0;
        if (_o_4 == 0) {
          _o_5 = 0;
        } else {
          _o_5 = 1;
          _o_6 = term_pak(CID_UNIT, 0);
        }
        u64 _nd_0 = heap_alloc(e, cls_fit(15));
        e.mem[_nd_0 + 0] = rfc_seal(e, _v_30);
        e.mem[_nd_0 + 1] = rfc_seal(e, _v_31);
        e.mem[_nd_0 + 2] = rfc_seal(e, _v_32);
        e.mem[_nd_0 + 3] = rfc_seal(e, _v_33);
        e.mem[_nd_0 + 4] = rfc_seal(e, _v_34);
        e.mem[_nd_0 + 5] = rfc_seal(e, _v_35);
        e.mem[_nd_0 + 6] = rfc_seal(e, _v_36);
        e.mem[_nd_0 + 7] = rfc_seal(e, _v_37);
        e.mem[_nd_0 + 8] = rfc_seal(e, _v_38);
        e.mem[_nd_0 + 9] = rfc_seal(e, _v_39);
        e.mem[_nd_0 + 10] = rfc_seal(e, _v_40);
        e.mem[_nd_0 + 11] = rfc_seal(e, _v_41);
        e.mem[_nd_0 + 12] = rfc_seal(e, _o_5);
        e.mem[_nd_0 + 13] = rfc_seal(e, _o_6);
        e.mem[_nd_0 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
        u64 _nd_1 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _v_46);
        e.mem[_nd_1 + 1] = rfc_seal(e, _v_47);
        Term _v_72 = 0;
        Term _v_73 = 0;
        Term _v_74 = 0;
        Term _v_75 = 0;
        Term _v_76 = 0;
        Term _v_77 = 0;
        Term _o_7[6];
        Term _a_1 = term_ctr(CID_STORAGE_WORLD, _nd_0);
        Term _a_2 = term_ctr(CID_STORAGE_HANDLE, _nd_1);
        if (spin_104(e, _o_7, _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
          return 0;
        }
        _v_72 = _o_7[0];
        _v_73 = _o_7[1];
        _v_74 = _o_7[2];
        _v_75 = _o_7[3];
        _v_76 = _o_7[4];
        _v_77 = _o_7[5];
        _v_66 = _v_72;
        _v_67 = _v_73;
        _v_68 = _v_74;
        _v_69 = _v_75;
        _v_70 = _v_76;
        _v_71 = _v_77;
        Term _fb_0[15];
        u64 _sp_0 = ctr_take(e, _v_66, 15, _fb_0);
        u32 _f_0 = _fb_0[0];
        u32 _f_1 = _fb_0[1];
        Term _f_2 = _fb_0[2];
        Term _f_3 = _fb_0[3];
        Term _f_4 = _fb_0[4];
        Term _f_5 = _fb_0[5];
        Term _f_6 = _fb_0[6];
        Term _f_7 = _fb_0[7];
        u32 _f_8 = _fb_0[8];
        Term _f_9 = _fb_0[9];
        u32 _f_10 = _fb_0[10];
        Term _f_11 = _fb_0[11];
        u32 _f_12 = _fb_0[12];
        Term _f_13 = _fb_0[13];
        Term _f_14 = _fb_0[14];
        spare_free(e, cls_fit(15), _sp_0);
        u32 _o_8 = 0;
        if (_f_12 == 0) {
          _o_8 = 0;
        } else {
          _o_8 = 1;
        }
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _v_67, 2, _fb_1);
        u32 _f_15 = _fb_1[0];
        u32 _f_16 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _depth_0;
          STK(1) = FID_TX_ONE_K934;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID_TX_ONE_K934, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _depth_0;
          WL_CONT = term_tsk(FID_TX_ONE_K934, _t_0);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_TX_LOOP)) {
          u64 _t_1 = task_node(e, FID_TX_LOOP, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = 32ull;
          e.mem[_t_1 + 1] = _depth_0;
          e.mem[_t_1 + 2] = 1ull;
          e.mem[_t_1 + 3] = _f_0;
          e.mem[_t_1 + 4] = _f_1;
          e.mem[_t_1 + 5] = _f_2;
          e.mem[_t_1 + 6] = _f_3;
          e.mem[_t_1 + 7] = _f_4;
          e.mem[_t_1 + 8] = _f_5;
          e.mem[_t_1 + 9] = _f_6;
          e.mem[_t_1 + 10] = _f_7;
          e.mem[_t_1 + 11] = _f_8;
          e.mem[_t_1 + 12] = _f_9;
          e.mem[_t_1 + 13] = _f_10;
          e.mem[_t_1 + 14] = _f_11;
          e.mem[_t_1 + 15] = _o_8;
          e.mem[_t_1 + 16] = _f_15;
          e.mem[_t_1 + 17] = _f_16;
          e.mem[_t_1 + 18] = _v_68;
          e.mem[_t_1 + 19] = _v_69;
          e.mem[_t_1 + 20] = _v_70;
          e.mem[_t_1 + 21] = _v_71;
          return term_tsk(FID_TX_LOOP, _t_1);
        }
        r0 = 32ull;
        r1 = _depth_0;
        r2 = 1ull;
        r3 = _f_0;
        r4 = _f_1;
        r5 = _f_2;
        r6 = _f_3;
        r7 = _f_4;
        r8 = _f_5;
        r9 = _f_6;
        r10 = _f_7;
        r11 = _f_8;
        r12 = _f_9;
        r13 = _f_10;
        r14 = _f_11;
        r15 = _o_8;
        r16 = _f_15;
        r17 = _f_16;
        r18 = _v_68;
        r19 = _v_69;
        r20 = _v_70;
        r21 = _v_71;
        WL_JMP(FID_TX_LOOP);
      } else {
        term_sink(e, _v_32);
        term_sink(e, _v_33);
        term_sink(e, _v_34);
        term_sink(e, _v_35);
        term_sink(e, _v_36);
        term_sink(e, _v_37);
        term_sink(e, _v_41);
        r0 = term_ctr(CID_SCON, STAT_OFF + 400);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _v_4);
      term_sink(e, _v_5);
      term_sink(e, _v_6);
      term_sink(e, _v_7);
      term_sink(e, _v_8);
      term_sink(e, _v_9);
      term_sink(e, _v_13);
      r0 = term_ctr(CID_SCON, STAT_OFF + 446);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_ONE_K934)
  {
    WL_POPN(1);
    Term _depth_1 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    Term _h_15 = r15;
    Term _h_16 = r16;
    Term _h_17 = r17;
    Term _h_18 = r18;
    WL_OPEN
    u32 _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    u32 _o_9 = 0;
    Term _o_10 = 0;
    if (_h_12 == 0) {
      _o_9 = 0;
    } else {
      _o_9 = 1;
      _o_10 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_2 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_2 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_2 + 6] = rfc_seal(e, _h_6);
    e.mem[_nd_2 + 7] = rfc_seal(e, _h_7);
    e.mem[_nd_2 + 8] = rfc_seal(e, _h_8);
    e.mem[_nd_2 + 9] = rfc_seal(e, _h_9);
    e.mem[_nd_2 + 10] = rfc_seal(e, _h_10);
    e.mem[_nd_2 + 11] = rfc_seal(e, _h_11);
    e.mem[_nd_2 + 12] = rfc_seal(e, _o_9);
    e.mem[_nd_2 + 13] = rfc_seal(e, _o_10);
    e.mem[_nd_2 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h_13);
    e.mem[_nd_3 + 1] = rfc_seal(e, _h_14);
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    Term _v_100 = 0;
    Term _o_11[6];
    Term _a_3 = term_ctr(CID_STORAGE_WORLD, _nd_2);
    Term _a_4 = term_ctr(CID_STORAGE_HANDLE, _nd_3);
    if (spin_105(e, _o_11, _a_3, blk_loc(e.mem, _a_3), _a_4, blk_loc(e.mem, _a_4), _h_15, blk_loc(e.mem, _h_15), _h_16, blk_loc(e.mem, _h_16), _h_17, blk_loc(e.mem, _h_17), _h_18, blk_loc(e.mem, _h_18), 81ull) == 0) {
      return 0;
    }
    _v_95 = _o_11[0];
    _v_96 = _o_11[1];
    _v_97 = _o_11[2];
    _v_98 = _o_11[3];
    _v_99 = _o_11[4];
    _v_100 = _o_11[5];
    _v_89 = _v_95;
    _v_90 = _v_96;
    _v_91 = _v_97;
    _v_92 = _v_98;
    _v_93 = _v_99;
    _v_94 = _v_100;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    Term _o_12[6];
    if (spin_105(e, _o_12, _v_89, blk_loc(e.mem, _v_89), _v_90, blk_loc(e.mem, _v_90), _v_91, blk_loc(e.mem, _v_91), _v_92, blk_loc(e.mem, _v_92), _v_93, blk_loc(e.mem, _v_93), _v_94, blk_loc(e.mem, _v_94), 82ull) == 0) {
      return 0;
    }
    _v_101 = _o_12[0];
    _v_102 = _o_12[1];
    _v_103 = _o_12[2];
    _v_104 = _o_12[3];
    _v_105 = _o_12[4];
    _v_106 = _o_12[5];
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    Term _v_109 = 0;
    Term _v_110 = 0;
    Term _v_111 = 0;
    Term _o_13[5];
    if (spin_106(e, _o_13, _v_83, blk_loc(e.mem, _v_83), _v_84, blk_loc(e.mem, _v_84), _v_85, blk_loc(e.mem, _v_85), _v_86, blk_loc(e.mem, _v_86), _v_87, blk_loc(e.mem, _v_87), _v_88, blk_loc(e.mem, _v_88)) == 0) {
      return 0;
    }
    _v_107 = _o_13[0];
    _v_108 = _o_13[1];
    _v_109 = _o_13[2];
    _v_110 = _o_13[3];
    _v_111 = _o_13[4];
    _v_78 = _v_107;
    _v_79 = _v_108;
    _v_80 = _v_109;
    _v_81 = _v_110;
    _v_82 = _v_111;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    Term _o_17 = 0;
    Term _o_18 = 0;
    Term _o_19 = 0;
    Term _o_20 = 0;
    Term _o_21 = 0;
    Term _o_22 = 0;
    u32 _o_23 = 0;
    Term _o_24 = 0;
    u32 _o_25 = 0;
    Term _o_26 = 0;
    u32 _o_27 = 0;
    Term _o_28 = 0;
    Term _o_29 = 0;
    Term _o_30 = 0;
    if (_v_78 == 0) {
      _o_14 = 0;
      Term _fb_2[15];
      u64 _sp_2 = ctr_take(e, _v_79, 15, _fb_2);
      u32 _f_17 = _fb_2[0];
      u32 _f_18 = _fb_2[1];
      Term _f_19 = _fb_2[2];
      Term _f_20 = _fb_2[3];
      Term _f_21 = _fb_2[4];
      Term _f_22 = _fb_2[5];
      Term _f_23 = _fb_2[6];
      Term _f_24 = _fb_2[7];
      u32 _f_25 = _fb_2[8];
      Term _f_26 = _fb_2[9];
      u32 _f_27 = _fb_2[10];
      Term _f_28 = _fb_2[11];
      u32 _f_29 = _fb_2[12];
      Term _f_30 = _fb_2[13];
      Term _f_31 = _fb_2[14];
      spare_free(e, cls_fit(15), _sp_2);
      u32 _o_31 = 0;
      if (_f_29 == 0) {
        _o_31 = 0;
      } else {
        _o_31 = 1;
      }
      _o_15 = _f_17;
      _o_16 = _f_18;
      _o_17 = _f_19;
      _o_18 = _f_20;
      _o_19 = _f_21;
      _o_20 = _f_22;
      _o_21 = _f_23;
      _o_22 = _f_24;
      _o_23 = _f_25;
      _o_24 = _f_26;
      _o_25 = _f_27;
      _o_26 = _f_28;
      _o_27 = _o_31;
      _o_28 = _v_80;
      _o_29 = _v_81;
      _o_30 = _v_82;
    } else {
      _o_14 = 1;
      Term _fb_3[15];
      u64 _sp_3 = ctr_take(e, _v_79, 15, _fb_3);
      u32 _f_32 = _fb_3[0];
      u32 _f_33 = _fb_3[1];
      Term _f_34 = _fb_3[2];
      Term _f_35 = _fb_3[3];
      Term _f_36 = _fb_3[4];
      Term _f_37 = _fb_3[5];
      Term _f_38 = _fb_3[6];
      Term _f_39 = _fb_3[7];
      u32 _f_40 = _fb_3[8];
      Term _f_41 = _fb_3[9];
      u32 _f_42 = _fb_3[10];
      Term _f_43 = _fb_3[11];
      u32 _f_44 = _fb_3[12];
      Term _f_45 = _fb_3[13];
      Term _f_46 = _fb_3[14];
      spare_free(e, cls_fit(15), _sp_3);
      u32 _o_32 = 0;
      if (_f_44 == 0) {
        _o_32 = 0;
      } else {
        _o_32 = 1;
      }
      _o_15 = _f_32;
      _o_16 = _f_33;
      _o_17 = _f_34;
      _o_18 = _f_35;
      _o_19 = _f_36;
      _o_20 = _f_37;
      _o_21 = _f_38;
      _o_22 = _f_39;
      _o_23 = _f_40;
      _o_24 = _f_41;
      _o_25 = _f_42;
      _o_26 = _f_43;
      _o_27 = _o_32;
    }
    if (_o_14 == 0) {
      term_sink(e, _o_17);
      term_sink(e, _o_18);
      term_sink(e, _o_19);
      term_sink(e, _o_20);
      term_sink(e, _o_21);
      term_sink(e, _o_22);
      term_sink(e, _o_26);
      term_sink(e, _o_30);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _o_29;
        STK(1) = FID_TX_ONE_K935;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID_TX_ONE_K935, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _o_29;
        WL_CONT = term_tsk(FID_TX_ONE_K935, _t_2);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_QUEUE_TEXT)) {
        u64 _t_3 = task_node(e, FID_QUEUE_TEXT, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _depth_1;
        e.mem[_t_3 + 1] = _o_28;
        e.mem[_t_3 + 2] = term_pak(CID_NIL, 0);
        e.mem[_t_3 + 3] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_QUEUE_TEXT, _t_3);
      }
      r0 = _depth_1;
      r1 = _o_28;
      r2 = term_pak(CID_NIL, 0);
      r3 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_QUEUE_TEXT);
    } else {
      term_sink(e, _o_17);
      term_sink(e, _o_18);
      term_sink(e, _o_19);
      term_sink(e, _o_20);
      term_sink(e, _o_21);
      term_sink(e, _o_22);
      term_sink(e, _o_26);
      r0 = term_ctr(CID_SCON, STAT_OFF + 366);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_ONE_K935)
  {
    WL_POPN(1);
    Term _o_33 = STK(0);
    Term _h_19 = r0;
    Term _h_20 = r1;
    WL_OPEN
    term_sink(e, _h_19);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_20;
      STK(1) = FID_TX_ONE_K936;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_TX_ONE_K936, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_20;
      WL_CONT = term_tsk(FID_TX_ONE_K936, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PING_TEXT)) {
      u64 _t_5 = task_node(e, FID_PING_TEXT, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _o_33;
      e.mem[_t_5 + 1] = term_pak(CID_SNIL, 0);
      return term_tsk(FID_PING_TEXT, _t_5);
    }
    r0 = _o_33;
    r1 = term_pak(CID_SNIL, 0);
    WL_JMP(FID_PING_TEXT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_ONE_K936)
  {
    WL_POPN(1);
    Term _h_22 = STK(0);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_22;
      STK(1) = FID_TX_ONE_K937;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_TX_ONE_K937, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_22;
      WL_CONT = term_tsk(FID_TX_ONE_K937, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 318);
      e.mem[_t_7 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 318);
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_ONE_K937)
  {
    WL_POPN(1);
    Term _h_24 = STK(0);
    Term _h_23 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TX_ONE_K938;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_TX_ONE_K938, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TX_ONE_K938, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_24;
      e.mem[_t_9 + 1] = _h_23;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_24;
    r1 = _h_23;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TX_ONE_K938)
  {
    Term _h_25 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 322);
      e.mem[_t_10 + 1] = _h_25;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 322);
    r1 = _h_25;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE)
  {
    Term _depth_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[15];
    if (spin_102(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_20 = _o_0[5];
    _v_21 = _o_0[6];
    _v_22 = _o_0[7];
    _v_23 = _o_0[8];
    _v_24 = _o_0[9];
    _v_25 = _o_0[10];
    _v_26 = _o_0[11];
    _v_27 = _o_0[12];
    _v_28 = _o_0[13];
    _v_29 = _o_0[14];
    _v_0 = _v_15;
    _v_1 = _v_16;
    _v_2 = _v_17;
    _v_3 = _v_18;
    _v_4 = _v_19;
    _v_5 = _v_20;
    _v_6 = _v_21;
    _v_7 = _v_22;
    _v_8 = _v_23;
    _v_9 = _v_24;
    _v_10 = _v_25;
    _v_11 = _v_26;
    _v_12 = _v_27;
    _v_13 = _v_28;
    _v_14 = _v_29;
    if (_v_0 == 0) {
      if (seq) {
        WL_ROOM(16);
        STK(0) = _depth_0;
        STK(1) = _v_1;
        STK(2) = _v_2;
        STK(3) = _v_3;
        STK(4) = _v_4;
        STK(5) = _v_5;
        STK(6) = _v_6;
        STK(7) = _v_7;
        STK(8) = _v_8;
        STK(9) = _v_9;
        STK(10) = _v_10;
        STK(11) = _v_11;
        STK(12) = _v_12;
        STK(13) = _v_13;
        STK(14) = _v_14;
        STK(15) = FID_ONE_K940;
        WL_PUSHN(16);
      } else {
        u64 _t_0 = task_node(e, FID_ONE_K940, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _depth_0;
        e.mem[_t_0 + 1] = _v_1;
        e.mem[_t_0 + 2] = _v_2;
        e.mem[_t_0 + 3] = _v_3;
        e.mem[_t_0 + 4] = _v_4;
        e.mem[_t_0 + 5] = _v_5;
        e.mem[_t_0 + 6] = _v_6;
        e.mem[_t_0 + 7] = _v_7;
        e.mem[_t_0 + 8] = _v_8;
        e.mem[_t_0 + 9] = _v_9;
        e.mem[_t_0 + 10] = _v_10;
        e.mem[_t_0 + 11] = _v_11;
        e.mem[_t_0 + 12] = _v_12;
        e.mem[_t_0 + 13] = _v_13;
        e.mem[_t_0 + 14] = _v_14;
        WL_CONT = term_tsk(FID_ONE_K940, _t_0);
        WL_IDX = 15;
      }
      if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
        u64 _t_1 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _depth_0;
        e.mem[_t_1 + 1] = 10ull;
        return term_tsk(FID_MAKE_SLOT, _t_1);
      }
      r0 = _depth_0;
      r1 = 10ull;
      WL_JMP(FID_MAKE_SLOT);
    } else {
      term_sink(e, _v_4);
      term_sink(e, _v_5);
      term_sink(e, _v_6);
      term_sink(e, _v_7);
      term_sink(e, _v_8);
      term_sink(e, _v_9);
      term_sink(e, _v_13);
      r0 = term_ctr(CID_SCON, STAT_OFF + 464);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K940)
  {
    WL_POPN(15);
    Term _depth_1 = STK(0);
    u32 _v_30 = STK(1);
    u32 _v_31 = STK(2);
    u32 _v_32 = STK(3);
    Term _v_33 = STK(4);
    Term _v_34 = STK(5);
    Term _v_35 = STK(6);
    Term _v_36 = STK(7);
    Term _v_37 = STK(8);
    Term _v_38 = STK(9);
    u32 _v_39 = STK(10);
    Term _v_40 = STK(11);
    u32 _v_41 = STK(12);
    Term _v_42 = STK(13);
    u32 _v_43 = STK(14);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    u64 _nd_0 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _h_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, _h_8);
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_v_43 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      _o_2 = term_pak(CID_UNIT, 0);
    }
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    Term _v_83 = 0;
    u32 _v_84 = 0;
    Term _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    Term _o_3[22];
    Term _a_0 = term_pak(CID_UNIT, 0);
    Term _a_1 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_0);
    Term _a_2 = 0;
    Term _a_3 = 0;
    if (spin_62(e, _o_3, _v_31, _v_32, _v_33, blk_loc(e.mem, _v_33), _v_34, blk_loc(e.mem, _v_34), _v_35, blk_loc(e.mem, _v_35), _v_36, blk_loc(e.mem, _v_36), _v_37, blk_loc(e.mem, _v_37), _v_38, blk_loc(e.mem, _v_38), _v_39, _v_40, _v_41, _v_42, blk_loc(e.mem, _v_42), _o_1, _o_2, blk_loc(e.mem, _o_2), _a_0, blk_loc(e.mem, _a_0), 1, _a_1, blk_loc(e.mem, _a_1), 0, _a_2, blk_loc(e.mem, _a_2), 0, _a_3, blk_loc(e.mem, _a_3)) == 0) {
      return 0;
    }
    _v_66 = _o_3[0];
    _v_67 = _o_3[1];
    _v_68 = _o_3[2];
    _v_69 = _o_3[3];
    _v_70 = _o_3[4];
    _v_71 = _o_3[5];
    _v_72 = _o_3[6];
    _v_73 = _o_3[7];
    _v_74 = _o_3[8];
    _v_75 = _o_3[9];
    _v_76 = _o_3[10];
    _v_77 = _o_3[11];
    _v_78 = _o_3[12];
    _v_79 = _o_3[13];
    _v_80 = _o_3[14];
    _v_81 = _o_3[15];
    _v_82 = _o_3[16];
    _v_83 = _o_3[17];
    _v_84 = _o_3[18];
    _v_85 = _o_3[19];
    _v_86 = _o_3[20];
    _v_87 = _o_3[21];
    _v_44 = _v_66;
    _v_45 = _v_67;
    _v_46 = _v_68;
    _v_47 = _v_69;
    _v_48 = _v_70;
    _v_49 = _v_71;
    _v_50 = _v_72;
    _v_51 = _v_73;
    _v_52 = _v_74;
    _v_53 = _v_75;
    _v_54 = _v_76;
    _v_55 = _v_77;
    _v_56 = _v_78;
    _v_57 = _v_79;
    _v_58 = _v_80;
    _v_59 = _v_81;
    _v_60 = _v_82;
    _v_61 = _v_83;
    _v_62 = _v_84;
    _v_63 = _v_85;
    _v_64 = _v_86;
    _v_65 = _v_87;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    u32 _o_6 = 0;
    Term _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    Term _o_10 = 0;
    Term _o_11 = 0;
    Term _o_12 = 0;
    u32 _o_13 = 0;
    Term _o_14 = 0;
    u32 _o_15 = 0;
    Term _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    Term _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    u32 _o_25 = 0;
    u32 _o_26 = 0;
    u32 _o_27 = 0;
    u32 _o_28 = 0;
    u32 _o_29 = 0;
    if (_v_44 == 0) {
      _o_4 = 0;
      u32 _o_30 = 0;
      if (_v_57 == 0) {
        _o_30 = 0;
      } else {
        _o_30 = 1;
      }
      _o_5 = _v_45;
      _o_6 = _v_46;
      _o_7 = _v_47;
      _o_8 = _v_48;
      _o_9 = _v_49;
      _o_10 = _v_50;
      _o_11 = _v_51;
      _o_12 = _v_52;
      _o_13 = _v_53;
      _o_14 = _v_54;
      _o_15 = _v_55;
      _o_16 = _v_56;
      _o_17 = _o_30;
      _o_18 = _v_60;
      _o_19 = _v_61;
    } else {
      _o_4 = 1;
      u32 _o_31 = 0;
      if (_v_57 == 0) {
        _o_31 = 0;
      } else {
        _o_31 = 1;
      }
      u32 _o_32 = 0;
      Term _o_33 = 0;
      u32 _o_34 = 0;
      u32 _o_35 = 0;
      u32 _o_36 = 0;
      u32 _o_37 = 0;
      u32 _o_38 = 0;
      u32 _o_39 = 0;
      u32 _o_40 = 0;
      u32 _o_41 = 0;
      if (_v_60 == 0) {
        _o_32 = 0;
      } else {
        _o_32 = 1;
        Term _fb_0[9];
        u64 _sp_0 = ctr_take(e, _v_61, 9, _fb_0);
        Term _f_0 = _fb_0[0];
        u32 _f_1 = _fb_0[1];
        u32 _f_2 = _fb_0[2];
        u32 _f_3 = _fb_0[3];
        u32 _f_4 = _fb_0[4];
        u32 _f_5 = _fb_0[5];
        u32 _f_6 = _fb_0[6];
        u32 _f_7 = _fb_0[7];
        u32 _f_8 = _fb_0[8];
        spare_free(e, cls_fit(9), _sp_0);
        _o_33 = _f_0;
        _o_34 = _f_1;
        _o_35 = _f_2;
        _o_36 = _f_3;
        _o_37 = _f_4;
        _o_38 = _f_5;
        _o_39 = _f_6;
        _o_40 = _f_7;
        _o_41 = _f_8;
      }
      u32 _o_42 = 0;
      if (_v_62 == 0) {
        _o_42 = 0;
      } else {
        _o_42 = 1;
      }
      u32 _o_43 = 0;
      if (_v_64 == 0) {
        _o_43 = 0;
      } else {
        _o_43 = 1;
      }
      _o_5 = _v_45;
      _o_6 = _v_46;
      _o_7 = _v_47;
      _o_8 = _v_48;
      _o_9 = _v_49;
      _o_10 = _v_50;
      _o_11 = _v_51;
      _o_12 = _v_52;
      _o_13 = _v_53;
      _o_14 = _v_54;
      _o_15 = _v_55;
      _o_16 = _v_56;
      _o_17 = _o_31;
      _o_18 = _o_32;
      _o_19 = _o_33;
      _o_20 = _o_34;
      _o_21 = _o_35;
      _o_22 = _o_36;
      _o_23 = _o_37;
      _o_24 = _o_38;
      _o_25 = _o_39;
      _o_26 = _o_40;
      _o_27 = _o_41;
      _o_28 = _o_42;
      _o_29 = _o_43;
    }
    if (_o_4 == 0) {
      u32 _o_44 = 0;
      Term _o_45 = 0;
      if (_o_17 == 0) {
        _o_44 = 0;
      } else {
        _o_44 = 1;
        _o_45 = term_pak(CID_UNIT, 0);
      }
      if (seq) {
        WL_ROOM(5);
        STK(0) = _depth_1;
        STK(1) = _v_30;
        STK(2) = _o_18;
        STK(3) = _o_19;
        STK(4) = FID_ONE_K941;
        WL_PUSHN(5);
      } else {
        u64 _t_2 = task_node(e, FID_ONE_K941, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _depth_1;
        e.mem[_t_2 + 1] = _v_30;
        e.mem[_t_2 + 2] = _o_18;
        e.mem[_t_2 + 3] = _o_19;
        WL_CONT = term_tsk(FID_ONE_K941, _t_2);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_APPLY_CHECKED)) {
        u64 _t_3 = task_node(e, FID_COMMANDS_APPLY_CHECKED, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _o_5;
        e.mem[_t_3 + 1] = _o_6;
        e.mem[_t_3 + 2] = _o_7;
        e.mem[_t_3 + 3] = _o_8;
        e.mem[_t_3 + 4] = _o_9;
        e.mem[_t_3 + 5] = _o_10;
        e.mem[_t_3 + 6] = _o_11;
        e.mem[_t_3 + 7] = _o_12;
        e.mem[_t_3 + 8] = _o_13;
        e.mem[_t_3 + 9] = _o_14;
        e.mem[_t_3 + 10] = _o_15;
        e.mem[_t_3 + 11] = _o_16;
        e.mem[_t_3 + 12] = _o_44;
        e.mem[_t_3 + 13] = _o_45;
        e.mem[_t_3 + 14] = term_pak(CID_UNIT, 0);
        e.mem[_t_3 + 15] = 1ull;
        return term_tsk(FID_COMMANDS_APPLY_CHECKED, _t_3);
      }
      r0 = _o_5;
      r1 = _o_6;
      r2 = _o_7;
      r3 = _o_8;
      r4 = _o_9;
      r5 = _o_10;
      r6 = _o_11;
      r7 = _o_12;
      r8 = _o_13;
      r9 = _o_14;
      r10 = _o_15;
      r11 = _o_16;
      r12 = _o_44;
      r13 = _o_45;
      r14 = term_pak(CID_UNIT, 0);
      r15 = 1ull;
      WL_JMP(FID_COMMANDS_APPLY_CHECKED);
    } else {
      term_sink(e, _o_7);
      term_sink(e, _o_8);
      term_sink(e, _o_9);
      term_sink(e, _o_10);
      term_sink(e, _o_11);
      term_sink(e, _o_12);
      term_sink(e, _o_16);
      term_sink(e, _o_19);
      r0 = term_ctr(CID_SCON, STAT_OFF + 422);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K941)
  {
    WL_POPN(4);
    Term _depth_2 = STK(0);
    u32 _v_88 = STK(1);
    u32 _o_46 = STK(2);
    u32 _o_47 = STK(3);
    u32 _h_9 = r0;
    u32 _h_10 = r1;
    u32 _h_11 = r2;
    Term _h_12 = r3;
    Term _h_13 = r4;
    Term _h_14 = r5;
    Term _h_15 = r6;
    Term _h_16 = r7;
    Term _h_17 = r8;
    u32 _h_18 = r9;
    Term _h_19 = r10;
    u32 _h_20 = r11;
    Term _h_21 = r12;
    u32 _h_22 = r13;
    Term _h_23 = r14;
    Term _h_24 = r15;
    Term _h_25 = r16;
    u32 _h_26 = r17;
    Term _h_27 = r18;
    u32 _h_28 = r19;
    Term _h_29 = r20;
    u32 _h_30 = r21;
    Term _h_31 = r22;
    u32 _h_32 = r23;
    u32 _h_33 = r24;
    Term _h_34 = r25;
    WL_OPEN
    u32 _o_48 = 0;
    u32 _o_49 = 0;
    u32 _o_50 = 0;
    Term _o_51 = 0;
    Term _o_52 = 0;
    Term _o_53 = 0;
    Term _o_54 = 0;
    Term _o_55 = 0;
    Term _o_56 = 0;
    u32 _o_57 = 0;
    Term _o_58 = 0;
    u32 _o_59 = 0;
    Term _o_60 = 0;
    u32 _o_61 = 0;
    Term _o_62 = 0;
    u32 _o_63 = 0;
    Term _o_64 = 0;
    u32 _o_65 = 0;
    u32 _o_66 = 0;
    u32 _o_67 = 0;
    u32 _o_68 = 0;
    u32 _o_69 = 0;
    u32 _o_70 = 0;
    u32 _o_71 = 0;
    u32 _o_72 = 0;
    u32 _o_73 = 0;
    u32 _o_74 = 0;
    u32 _o_75 = 0;
    u32 _o_76 = 0;
    Term _o_77 = 0;
    if (_h_9 == 0) {
      _o_48 = 0;
      u32 _o_78 = 0;
      if (_h_22 == 0) {
        _o_78 = 0;
      } else {
        _o_78 = 1;
      }
      _o_49 = _h_10;
      _o_50 = _h_11;
      _o_51 = _h_12;
      _o_52 = _h_13;
      _o_53 = _h_14;
      _o_54 = _h_15;
      _o_55 = _h_16;
      _o_56 = _h_17;
      _o_57 = _h_18;
      _o_58 = _h_19;
      _o_59 = _h_20;
      _o_60 = _h_21;
      _o_61 = _o_78;
      _o_62 = _h_25;
    } else if (_h_9 == 1) {
      _o_48 = 1;
      u32 _o_79 = 0;
      if (_h_22 == 0) {
        _o_79 = 0;
      } else {
        _o_79 = 1;
      }
      _o_49 = _h_10;
      _o_50 = _h_11;
      _o_51 = _h_12;
      _o_52 = _h_13;
      _o_53 = _h_14;
      _o_54 = _h_15;
      _o_55 = _h_16;
      _o_56 = _h_17;
      _o_57 = _h_18;
      _o_58 = _h_19;
      _o_59 = _h_20;
      _o_60 = _h_21;
      _o_61 = _o_79;
    } else {
      _o_48 = 2;
      u32 _o_80 = 0;
      if (_h_22 == 0) {
        _o_80 = 0;
      } else {
        _o_80 = 1;
      }
      u32 _o_81 = 0;
      Term _o_82 = 0;
      u32 _o_83 = 0;
      u32 _o_84 = 0;
      u32 _o_85 = 0;
      u32 _o_86 = 0;
      u32 _o_87 = 0;
      u32 _o_88 = 0;
      u32 _o_89 = 0;
      u32 _o_90 = 0;
      if (_h_26 == 0) {
        _o_81 = 0;
      } else {
        _o_81 = 1;
        Term _fb_1[9];
        u64 _sp_1 = ctr_take(e, _h_27, 9, _fb_1);
        Term _f_9 = _fb_1[0];
        u32 _f_10 = _fb_1[1];
        u32 _f_11 = _fb_1[2];
        u32 _f_12 = _fb_1[3];
        u32 _f_13 = _fb_1[4];
        u32 _f_14 = _fb_1[5];
        u32 _f_15 = _fb_1[6];
        u32 _f_16 = _fb_1[7];
        u32 _f_17 = _fb_1[8];
        spare_free(e, cls_fit(9), _sp_1);
        _o_82 = _f_9;
        _o_83 = _f_10;
        _o_84 = _f_11;
        _o_85 = _f_12;
        _o_86 = _f_13;
        _o_87 = _f_14;
        _o_88 = _f_15;
        _o_89 = _f_16;
        _o_90 = _f_17;
      }
      u32 _o_91 = 0;
      if (_h_28 == 0) {
        _o_91 = 0;
      } else {
        _o_91 = 1;
      }
      u32 _o_92 = 0;
      if (_h_30 == 0) {
        _o_92 = 0;
      } else {
        _o_92 = 1;
      }
      _o_49 = _h_10;
      _o_50 = _h_11;
      _o_51 = _h_12;
      _o_52 = _h_13;
      _o_53 = _h_14;
      _o_54 = _h_15;
      _o_55 = _h_16;
      _o_56 = _h_17;
      _o_57 = _h_18;
      _o_58 = _h_19;
      _o_59 = _h_20;
      _o_60 = _h_21;
      _o_61 = _o_80;
      _o_62 = _h_25;
      _o_63 = _o_81;
      _o_64 = _o_82;
      _o_65 = _o_83;
      _o_66 = _o_84;
      _o_67 = _o_85;
      _o_68 = _o_86;
      _o_69 = _o_87;
      _o_70 = _o_88;
      _o_71 = _o_89;
      _o_72 = _o_90;
      _o_73 = _o_91;
      _o_74 = _o_92;
      _o_75 = _h_32;
      _o_76 = _h_33;
      _o_77 = _h_34;
    }
    if (_o_48 == 0) {
      term_sink(e, _o_62);
      u32 _v_89 = 0;
      u32 _v_90 = 0;
      u32 _v_91 = 0;
      u32 _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      Term _v_95 = 0;
      Term _v_96 = 0;
      Term _v_97 = 0;
      Term _v_98 = 0;
      u32 _v_99 = 0;
      Term _v_100 = 0;
      u32 _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      u32 _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      Term _v_112 = 0;
      Term _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      Term _v_117 = 0;
      u32 _v_118 = 0;
      Term _o_93[15];
      if (spin_101(e, _o_93, _v_88) == 0) {
        return 0;
      }
      _v_104 = _o_93[0];
      _v_105 = _o_93[1];
      _v_106 = _o_93[2];
      _v_107 = _o_93[3];
      _v_108 = _o_93[4];
      _v_109 = _o_93[5];
      _v_110 = _o_93[6];
      _v_111 = _o_93[7];
      _v_112 = _o_93[8];
      _v_113 = _o_93[9];
      _v_114 = _o_93[10];
      _v_115 = _o_93[11];
      _v_116 = _o_93[12];
      _v_117 = _o_93[13];
      _v_118 = _o_93[14];
      _v_89 = _v_104;
      _v_90 = _v_105;
      _v_91 = _v_106;
      _v_92 = _v_107;
      _v_93 = _v_108;
      _v_94 = _v_109;
      _v_95 = _v_110;
      _v_96 = _v_111;
      _v_97 = _v_112;
      _v_98 = _v_113;
      _v_99 = _v_114;
      _v_100 = _v_115;
      _v_101 = _v_116;
      _v_102 = _v_117;
      _v_103 = _v_118;
      if (_v_89 == 0) {
        if (seq) {
          WL_ROOM(30);
          STK(0) = _depth_2;
          STK(1) = _o_49;
          STK(2) = _o_50;
          STK(3) = _o_51;
          STK(4) = _o_52;
          STK(5) = _o_53;
          STK(6) = _o_54;
          STK(7) = _o_55;
          STK(8) = _o_56;
          STK(9) = _o_57;
          STK(10) = _o_58;
          STK(11) = _o_59;
          STK(12) = _o_60;
          STK(13) = _o_61;
          STK(14) = _o_46;
          STK(15) = _o_47;
          STK(16) = _v_91;
          STK(17) = _v_92;
          STK(18) = _v_93;
          STK(19) = _v_94;
          STK(20) = _v_95;
          STK(21) = _v_96;
          STK(22) = _v_97;
          STK(23) = _v_98;
          STK(24) = _v_99;
          STK(25) = _v_100;
          STK(26) = _v_101;
          STK(27) = _v_102;
          STK(28) = _v_103;
          STK(29) = FID_ONE_K942;
          WL_PUSHN(30);
        } else {
          u64 _t_4 = task_node(e, FID_ONE_K942, WL_CONT, WL_IDX, 1);
          e.mem[_t_4 + 0] = _depth_2;
          e.mem[_t_4 + 1] = _o_49;
          e.mem[_t_4 + 2] = _o_50;
          e.mem[_t_4 + 3] = _o_51;
          e.mem[_t_4 + 4] = _o_52;
          e.mem[_t_4 + 5] = _o_53;
          e.mem[_t_4 + 6] = _o_54;
          e.mem[_t_4 + 7] = _o_55;
          e.mem[_t_4 + 8] = _o_56;
          e.mem[_t_4 + 9] = _o_57;
          e.mem[_t_4 + 10] = _o_58;
          e.mem[_t_4 + 11] = _o_59;
          e.mem[_t_4 + 12] = _o_60;
          e.mem[_t_4 + 13] = _o_61;
          e.mem[_t_4 + 14] = _o_46;
          e.mem[_t_4 + 15] = _o_47;
          e.mem[_t_4 + 16] = _v_91;
          e.mem[_t_4 + 17] = _v_92;
          e.mem[_t_4 + 18] = _v_93;
          e.mem[_t_4 + 19] = _v_94;
          e.mem[_t_4 + 20] = _v_95;
          e.mem[_t_4 + 21] = _v_96;
          e.mem[_t_4 + 22] = _v_97;
          e.mem[_t_4 + 23] = _v_98;
          e.mem[_t_4 + 24] = _v_99;
          e.mem[_t_4 + 25] = _v_100;
          e.mem[_t_4 + 26] = _v_101;
          e.mem[_t_4 + 27] = _v_102;
          e.mem[_t_4 + 28] = _v_103;
          WL_CONT = term_tsk(FID_ONE_K942, _t_4);
          WL_IDX = 29;
        }
        if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
          u64 _t_5 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
          e.mem[_t_5 + 0] = _depth_2;
          e.mem[_t_5 + 1] = 20ull;
          return term_tsk(FID_MAKE_SLOT, _t_5);
        }
        r0 = _depth_2;
        r1 = 20ull;
        WL_JMP(FID_MAKE_SLOT);
      } else {
        term_sink(e, _o_51);
        term_sink(e, _o_52);
        term_sink(e, _o_53);
        term_sink(e, _o_54);
        term_sink(e, _o_55);
        term_sink(e, _o_56);
        term_sink(e, _o_60);
        term_sink(e, _v_93);
        term_sink(e, _v_94);
        term_sink(e, _v_95);
        term_sink(e, _v_96);
        term_sink(e, _v_97);
        term_sink(e, _v_98);
        term_sink(e, _v_102);
        r0 = term_ctr(CID_SCON, STAT_OFF + 340);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _o_51);
      term_sink(e, _o_52);
      term_sink(e, _o_53);
      term_sink(e, _o_54);
      term_sink(e, _o_55);
      term_sink(e, _o_56);
      term_sink(e, _o_60);
      term_sink(e, _o_62);
      term_sink(e, _o_64);
      term_sink(e, _o_77);
      r0 = term_ctr(CID_SCON, STAT_OFF + 388);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K942)
  {
    WL_POPN(29);
    Term _depth_3 = STK(0);
    u32 _o_94 = STK(1);
    u32 _o_95 = STK(2);
    Term _o_96 = STK(3);
    Term _o_97 = STK(4);
    Term _o_98 = STK(5);
    Term _o_99 = STK(6);
    Term _o_100 = STK(7);
    Term _o_101 = STK(8);
    u32 _o_102 = STK(9);
    Term _o_103 = STK(10);
    u32 _o_104 = STK(11);
    Term _o_105 = STK(12);
    u32 _o_106 = STK(13);
    u32 _o_107 = STK(14);
    u32 _o_108 = STK(15);
    u32 _v_119 = STK(16);
    u32 _v_120 = STK(17);
    Term _v_121 = STK(18);
    Term _v_122 = STK(19);
    Term _v_123 = STK(20);
    Term _v_124 = STK(21);
    Term _v_125 = STK(22);
    Term _v_126 = STK(23);
    u32 _v_127 = STK(24);
    Term _v_128 = STK(25);
    u32 _v_129 = STK(26);
    Term _v_130 = STK(27);
    u32 _v_131 = STK(28);
    Term _h_35 = r0;
    u32 _h_36 = r1;
    u32 _h_37 = r2;
    u32 _h_38 = r3;
    u32 _h_39 = r4;
    u32 _h_40 = r5;
    u32 _h_41 = r6;
    u32 _h_42 = r7;
    u32 _h_43 = r8;
    WL_OPEN
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    Term _v_135 = 0;
    Term _v_136 = 0;
    Term _v_137 = 0;
    Term _v_138 = 0;
    Term _v_139 = 0;
    Term _v_140 = 0;
    u32 _v_141 = 0;
    Term _v_142 = 0;
    u32 _v_143 = 0;
    Term _v_144 = 0;
    u32 _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    u32 _v_148 = 0;
    Term _v_149 = 0;
    u32 _v_150 = 0;
    Term _v_151 = 0;
    u32 _v_152 = 0;
    Term _v_153 = 0;
    u64 _nd_1 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_1 + 0] = rfc_seal(e, _h_35);
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_36);
    e.mem[_nd_1 + 2] = rfc_seal(e, _h_37);
    e.mem[_nd_1 + 3] = rfc_seal(e, _h_38);
    e.mem[_nd_1 + 4] = rfc_seal(e, _h_39);
    e.mem[_nd_1 + 5] = rfc_seal(e, _h_40);
    e.mem[_nd_1 + 6] = rfc_seal(e, _h_41);
    e.mem[_nd_1 + 7] = rfc_seal(e, _h_42);
    e.mem[_nd_1 + 8] = rfc_seal(e, _h_43);
    u32 _o_109 = 0;
    Term _o_110 = 0;
    if (_v_131 == 0) {
      _o_109 = 0;
    } else {
      _o_109 = 1;
      _o_110 = term_pak(CID_UNIT, 0);
    }
    u32 _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    Term _v_157 = 0;
    Term _v_158 = 0;
    Term _v_159 = 0;
    Term _v_160 = 0;
    Term _v_161 = 0;
    Term _v_162 = 0;
    u32 _v_163 = 0;
    Term _v_164 = 0;
    u32 _v_165 = 0;
    Term _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    Term _v_169 = 0;
    u32 _v_170 = 0;
    Term _v_171 = 0;
    u32 _v_172 = 0;
    Term _v_173 = 0;
    u32 _v_174 = 0;
    Term _v_175 = 0;
    Term _o_111[22];
    Term _a_4 = term_pak(CID_UNIT, 0);
    Term _a_5 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_1);
    Term _a_6 = 0;
    Term _a_7 = 0;
    if (spin_62(e, _o_111, _v_119, _v_120, _v_121, blk_loc(e.mem, _v_121), _v_122, blk_loc(e.mem, _v_122), _v_123, blk_loc(e.mem, _v_123), _v_124, blk_loc(e.mem, _v_124), _v_125, blk_loc(e.mem, _v_125), _v_126, blk_loc(e.mem, _v_126), _v_127, _v_128, _v_129, _v_130, blk_loc(e.mem, _v_130), _o_109, _o_110, blk_loc(e.mem, _o_110), _a_4, blk_loc(e.mem, _a_4), 1, _a_5, blk_loc(e.mem, _a_5), 0, _a_6, blk_loc(e.mem, _a_6), 0, _a_7, blk_loc(e.mem, _a_7)) == 0) {
      return 0;
    }
    _v_154 = _o_111[0];
    _v_155 = _o_111[1];
    _v_156 = _o_111[2];
    _v_157 = _o_111[3];
    _v_158 = _o_111[4];
    _v_159 = _o_111[5];
    _v_160 = _o_111[6];
    _v_161 = _o_111[7];
    _v_162 = _o_111[8];
    _v_163 = _o_111[9];
    _v_164 = _o_111[10];
    _v_165 = _o_111[11];
    _v_166 = _o_111[12];
    _v_167 = _o_111[13];
    _v_168 = _o_111[14];
    _v_169 = _o_111[15];
    _v_170 = _o_111[16];
    _v_171 = _o_111[17];
    _v_172 = _o_111[18];
    _v_173 = _o_111[19];
    _v_174 = _o_111[20];
    _v_175 = _o_111[21];
    _v_132 = _v_154;
    _v_133 = _v_155;
    _v_134 = _v_156;
    _v_135 = _v_157;
    _v_136 = _v_158;
    _v_137 = _v_159;
    _v_138 = _v_160;
    _v_139 = _v_161;
    _v_140 = _v_162;
    _v_141 = _v_163;
    _v_142 = _v_164;
    _v_143 = _v_165;
    _v_144 = _v_166;
    _v_145 = _v_167;
    _v_146 = _v_168;
    _v_147 = _v_169;
    _v_148 = _v_170;
    _v_149 = _v_171;
    _v_150 = _v_172;
    _v_151 = _v_173;
    _v_152 = _v_174;
    _v_153 = _v_175;
    u32 _o_112 = 0;
    u32 _o_113 = 0;
    u32 _o_114 = 0;
    Term _o_115 = 0;
    Term _o_116 = 0;
    Term _o_117 = 0;
    Term _o_118 = 0;
    Term _o_119 = 0;
    Term _o_120 = 0;
    u32 _o_121 = 0;
    Term _o_122 = 0;
    u32 _o_123 = 0;
    Term _o_124 = 0;
    u32 _o_125 = 0;
    u32 _o_126 = 0;
    Term _o_127 = 0;
    u32 _o_128 = 0;
    u32 _o_129 = 0;
    u32 _o_130 = 0;
    u32 _o_131 = 0;
    u32 _o_132 = 0;
    u32 _o_133 = 0;
    u32 _o_134 = 0;
    u32 _o_135 = 0;
    u32 _o_136 = 0;
    u32 _o_137 = 0;
    if (_v_132 == 0) {
      _o_112 = 0;
      u32 _o_138 = 0;
      if (_v_145 == 0) {
        _o_138 = 0;
      } else {
        _o_138 = 1;
      }
      _o_113 = _v_133;
      _o_114 = _v_134;
      _o_115 = _v_135;
      _o_116 = _v_136;
      _o_117 = _v_137;
      _o_118 = _v_138;
      _o_119 = _v_139;
      _o_120 = _v_140;
      _o_121 = _v_141;
      _o_122 = _v_142;
      _o_123 = _v_143;
      _o_124 = _v_144;
      _o_125 = _o_138;
      _o_126 = _v_148;
      _o_127 = _v_149;
    } else {
      _o_112 = 1;
      u32 _o_139 = 0;
      if (_v_145 == 0) {
        _o_139 = 0;
      } else {
        _o_139 = 1;
      }
      u32 _o_140 = 0;
      Term _o_141 = 0;
      u32 _o_142 = 0;
      u32 _o_143 = 0;
      u32 _o_144 = 0;
      u32 _o_145 = 0;
      u32 _o_146 = 0;
      u32 _o_147 = 0;
      u32 _o_148 = 0;
      u32 _o_149 = 0;
      if (_v_148 == 0) {
        _o_140 = 0;
      } else {
        _o_140 = 1;
        Term _fb_2[9];
        u64 _sp_2 = ctr_take(e, _v_149, 9, _fb_2);
        Term _f_18 = _fb_2[0];
        u32 _f_19 = _fb_2[1];
        u32 _f_20 = _fb_2[2];
        u32 _f_21 = _fb_2[3];
        u32 _f_22 = _fb_2[4];
        u32 _f_23 = _fb_2[5];
        u32 _f_24 = _fb_2[6];
        u32 _f_25 = _fb_2[7];
        u32 _f_26 = _fb_2[8];
        spare_free(e, cls_fit(9), _sp_2);
        _o_141 = _f_18;
        _o_142 = _f_19;
        _o_143 = _f_20;
        _o_144 = _f_21;
        _o_145 = _f_22;
        _o_146 = _f_23;
        _o_147 = _f_24;
        _o_148 = _f_25;
        _o_149 = _f_26;
      }
      u32 _o_150 = 0;
      if (_v_150 == 0) {
        _o_150 = 0;
      } else {
        _o_150 = 1;
      }
      u32 _o_151 = 0;
      if (_v_152 == 0) {
        _o_151 = 0;
      } else {
        _o_151 = 1;
      }
      _o_113 = _v_133;
      _o_114 = _v_134;
      _o_115 = _v_135;
      _o_116 = _v_136;
      _o_117 = _v_137;
      _o_118 = _v_138;
      _o_119 = _v_139;
      _o_120 = _v_140;
      _o_121 = _v_141;
      _o_122 = _v_142;
      _o_123 = _v_143;
      _o_124 = _v_144;
      _o_125 = _o_139;
      _o_126 = _o_140;
      _o_127 = _o_141;
      _o_128 = _o_142;
      _o_129 = _o_143;
      _o_130 = _o_144;
      _o_131 = _o_145;
      _o_132 = _o_146;
      _o_133 = _o_147;
      _o_134 = _o_148;
      _o_135 = _o_149;
      _o_136 = _o_150;
      _o_137 = _o_151;
    }
    if (_o_112 == 0) {
      u32 _o_152 = 0;
      Term _o_153 = 0;
      if (_o_125 == 0) {
        _o_152 = 0;
      } else {
        _o_152 = 1;
        _o_153 = term_pak(CID_UNIT, 0);
      }
      if (seq) {
        WL_ROOM(19);
        STK(0) = _depth_3;
        STK(1) = _o_94;
        STK(2) = _o_95;
        STK(3) = _o_96;
        STK(4) = _o_97;
        STK(5) = _o_98;
        STK(6) = _o_99;
        STK(7) = _o_100;
        STK(8) = _o_101;
        STK(9) = _o_102;
        STK(10) = _o_103;
        STK(11) = _o_104;
        STK(12) = _o_105;
        STK(13) = _o_106;
        STK(14) = _o_107;
        STK(15) = _o_108;
        STK(16) = _o_126;
        STK(17) = _o_127;
        STK(18) = FID_ONE_K943;
        WL_PUSHN(19);
      } else {
        u64 _t_6 = task_node(e, FID_ONE_K943, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _depth_3;
        e.mem[_t_6 + 1] = _o_94;
        e.mem[_t_6 + 2] = _o_95;
        e.mem[_t_6 + 3] = _o_96;
        e.mem[_t_6 + 4] = _o_97;
        e.mem[_t_6 + 5] = _o_98;
        e.mem[_t_6 + 6] = _o_99;
        e.mem[_t_6 + 7] = _o_100;
        e.mem[_t_6 + 8] = _o_101;
        e.mem[_t_6 + 9] = _o_102;
        e.mem[_t_6 + 10] = _o_103;
        e.mem[_t_6 + 11] = _o_104;
        e.mem[_t_6 + 12] = _o_105;
        e.mem[_t_6 + 13] = _o_106;
        e.mem[_t_6 + 14] = _o_107;
        e.mem[_t_6 + 15] = _o_108;
        e.mem[_t_6 + 16] = _o_126;
        e.mem[_t_6 + 17] = _o_127;
        WL_CONT = term_tsk(FID_ONE_K943, _t_6);
        WL_IDX = 18;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_APPLY_CHECKED)) {
        u64 _t_7 = task_node(e, FID_COMMANDS_APPLY_CHECKED, WL_CONT, WL_IDX, 0);
        e.mem[_t_7 + 0] = _o_113;
        e.mem[_t_7 + 1] = _o_114;
        e.mem[_t_7 + 2] = _o_115;
        e.mem[_t_7 + 3] = _o_116;
        e.mem[_t_7 + 4] = _o_117;
        e.mem[_t_7 + 5] = _o_118;
        e.mem[_t_7 + 6] = _o_119;
        e.mem[_t_7 + 7] = _o_120;
        e.mem[_t_7 + 8] = _o_121;
        e.mem[_t_7 + 9] = _o_122;
        e.mem[_t_7 + 10] = _o_123;
        e.mem[_t_7 + 11] = _o_124;
        e.mem[_t_7 + 12] = _o_152;
        e.mem[_t_7 + 13] = _o_153;
        e.mem[_t_7 + 14] = term_pak(CID_UNIT, 0);
        e.mem[_t_7 + 15] = 1ull;
        return term_tsk(FID_COMMANDS_APPLY_CHECKED, _t_7);
      }
      r0 = _o_113;
      r1 = _o_114;
      r2 = _o_115;
      r3 = _o_116;
      r4 = _o_117;
      r5 = _o_118;
      r6 = _o_119;
      r7 = _o_120;
      r8 = _o_121;
      r9 = _o_122;
      r10 = _o_123;
      r11 = _o_124;
      r12 = _o_152;
      r13 = _o_153;
      r14 = term_pak(CID_UNIT, 0);
      r15 = 1ull;
      WL_JMP(FID_COMMANDS_APPLY_CHECKED);
    } else {
      term_sink(e, _o_96);
      term_sink(e, _o_97);
      term_sink(e, _o_98);
      term_sink(e, _o_99);
      term_sink(e, _o_100);
      term_sink(e, _o_101);
      term_sink(e, _o_105);
      term_sink(e, _o_115);
      term_sink(e, _o_116);
      term_sink(e, _o_117);
      term_sink(e, _o_118);
      term_sink(e, _o_119);
      term_sink(e, _o_120);
      term_sink(e, _o_124);
      term_sink(e, _o_127);
      r0 = term_ctr(CID_SCON, STAT_OFF + 306);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K943)
  {
    WL_POPN(18);
    Term _depth_4 = STK(0);
    u32 _o_154 = STK(1);
    u32 _o_155 = STK(2);
    Term _o_156 = STK(3);
    Term _o_157 = STK(4);
    Term _o_158 = STK(5);
    Term _o_159 = STK(6);
    Term _o_160 = STK(7);
    Term _o_161 = STK(8);
    u32 _o_162 = STK(9);
    Term _o_163 = STK(10);
    u32 _o_164 = STK(11);
    Term _o_165 = STK(12);
    u32 _o_166 = STK(13);
    u32 _o_167 = STK(14);
    u32 _o_168 = STK(15);
    u32 _o_169 = STK(16);
    u32 _o_170 = STK(17);
    u32 _h_44 = r0;
    u32 _h_45 = r1;
    u32 _h_46 = r2;
    Term _h_47 = r3;
    Term _h_48 = r4;
    Term _h_49 = r5;
    Term _h_50 = r6;
    Term _h_51 = r7;
    Term _h_52 = r8;
    u32 _h_53 = r9;
    Term _h_54 = r10;
    u32 _h_55 = r11;
    Term _h_56 = r12;
    u32 _h_57 = r13;
    Term _h_58 = r14;
    Term _h_59 = r15;
    Term _h_60 = r16;
    u32 _h_61 = r17;
    Term _h_62 = r18;
    u32 _h_63 = r19;
    Term _h_64 = r20;
    u32 _h_65 = r21;
    Term _h_66 = r22;
    u32 _h_67 = r23;
    u32 _h_68 = r24;
    Term _h_69 = r25;
    WL_OPEN
    u32 _o_171 = 0;
    u32 _o_172 = 0;
    u32 _o_173 = 0;
    Term _o_174 = 0;
    Term _o_175 = 0;
    Term _o_176 = 0;
    Term _o_177 = 0;
    Term _o_178 = 0;
    Term _o_179 = 0;
    u32 _o_180 = 0;
    Term _o_181 = 0;
    u32 _o_182 = 0;
    Term _o_183 = 0;
    u32 _o_184 = 0;
    Term _o_185 = 0;
    u32 _o_186 = 0;
    Term _o_187 = 0;
    u32 _o_188 = 0;
    u32 _o_189 = 0;
    u32 _o_190 = 0;
    u32 _o_191 = 0;
    u32 _o_192 = 0;
    u32 _o_193 = 0;
    u32 _o_194 = 0;
    u32 _o_195 = 0;
    u32 _o_196 = 0;
    u32 _o_197 = 0;
    u32 _o_198 = 0;
    u32 _o_199 = 0;
    Term _o_200 = 0;
    if (_h_44 == 0) {
      _o_171 = 0;
      u32 _o_201 = 0;
      if (_h_57 == 0) {
        _o_201 = 0;
      } else {
        _o_201 = 1;
      }
      _o_172 = _h_45;
      _o_173 = _h_46;
      _o_174 = _h_47;
      _o_175 = _h_48;
      _o_176 = _h_49;
      _o_177 = _h_50;
      _o_178 = _h_51;
      _o_179 = _h_52;
      _o_180 = _h_53;
      _o_181 = _h_54;
      _o_182 = _h_55;
      _o_183 = _h_56;
      _o_184 = _o_201;
      _o_185 = _h_60;
    } else if (_h_44 == 1) {
      _o_171 = 1;
      u32 _o_202 = 0;
      if (_h_57 == 0) {
        _o_202 = 0;
      } else {
        _o_202 = 1;
      }
      _o_172 = _h_45;
      _o_173 = _h_46;
      _o_174 = _h_47;
      _o_175 = _h_48;
      _o_176 = _h_49;
      _o_177 = _h_50;
      _o_178 = _h_51;
      _o_179 = _h_52;
      _o_180 = _h_53;
      _o_181 = _h_54;
      _o_182 = _h_55;
      _o_183 = _h_56;
      _o_184 = _o_202;
    } else {
      _o_171 = 2;
      u32 _o_203 = 0;
      if (_h_57 == 0) {
        _o_203 = 0;
      } else {
        _o_203 = 1;
      }
      u32 _o_204 = 0;
      Term _o_205 = 0;
      u32 _o_206 = 0;
      u32 _o_207 = 0;
      u32 _o_208 = 0;
      u32 _o_209 = 0;
      u32 _o_210 = 0;
      u32 _o_211 = 0;
      u32 _o_212 = 0;
      u32 _o_213 = 0;
      if (_h_61 == 0) {
        _o_204 = 0;
      } else {
        _o_204 = 1;
        Term _fb_3[9];
        u64 _sp_3 = ctr_take(e, _h_62, 9, _fb_3);
        Term _f_27 = _fb_3[0];
        u32 _f_28 = _fb_3[1];
        u32 _f_29 = _fb_3[2];
        u32 _f_30 = _fb_3[3];
        u32 _f_31 = _fb_3[4];
        u32 _f_32 = _fb_3[5];
        u32 _f_33 = _fb_3[6];
        u32 _f_34 = _fb_3[7];
        u32 _f_35 = _fb_3[8];
        spare_free(e, cls_fit(9), _sp_3);
        _o_205 = _f_27;
        _o_206 = _f_28;
        _o_207 = _f_29;
        _o_208 = _f_30;
        _o_209 = _f_31;
        _o_210 = _f_32;
        _o_211 = _f_33;
        _o_212 = _f_34;
        _o_213 = _f_35;
      }
      u32 _o_214 = 0;
      if (_h_63 == 0) {
        _o_214 = 0;
      } else {
        _o_214 = 1;
      }
      u32 _o_215 = 0;
      if (_h_65 == 0) {
        _o_215 = 0;
      } else {
        _o_215 = 1;
      }
      _o_172 = _h_45;
      _o_173 = _h_46;
      _o_174 = _h_47;
      _o_175 = _h_48;
      _o_176 = _h_49;
      _o_177 = _h_50;
      _o_178 = _h_51;
      _o_179 = _h_52;
      _o_180 = _h_53;
      _o_181 = _h_54;
      _o_182 = _h_55;
      _o_183 = _h_56;
      _o_184 = _o_203;
      _o_185 = _h_60;
      _o_186 = _o_204;
      _o_187 = _o_205;
      _o_188 = _o_206;
      _o_189 = _o_207;
      _o_190 = _o_208;
      _o_191 = _o_209;
      _o_192 = _o_210;
      _o_193 = _o_211;
      _o_194 = _o_212;
      _o_195 = _o_213;
      _o_196 = _o_214;
      _o_197 = _o_215;
      _o_198 = _h_67;
      _o_199 = _h_68;
      _o_200 = _h_69;
    }
    if (_o_171 == 0) {
      term_sink(e, _o_174);
      term_sink(e, _o_175);
      term_sink(e, _o_176);
      term_sink(e, _o_177);
      term_sink(e, _o_178);
      term_sink(e, _o_179);
      term_sink(e, _o_183);
      term_sink(e, _o_185);
      if (seq) {
        WL_ROOM(19);
        STK(0) = _depth_4;
        STK(1) = _o_154;
        STK(2) = _o_155;
        STK(3) = _o_156;
        STK(4) = _o_157;
        STK(5) = _o_158;
        STK(6) = _o_159;
        STK(7) = _o_160;
        STK(8) = _o_161;
        STK(9) = _o_162;
        STK(10) = _o_163;
        STK(11) = _o_164;
        STK(12) = _o_165;
        STK(13) = _o_166;
        STK(14) = _o_167;
        STK(15) = _o_168;
        STK(16) = _o_169;
        STK(17) = _o_170;
        STK(18) = FID_ONE_K944;
        WL_PUSHN(19);
      } else {
        u64 _t_8 = task_node(e, FID_ONE_K944, WL_CONT, WL_IDX, 1);
        e.mem[_t_8 + 0] = _depth_4;
        e.mem[_t_8 + 1] = _o_154;
        e.mem[_t_8 + 2] = _o_155;
        e.mem[_t_8 + 3] = _o_156;
        e.mem[_t_8 + 4] = _o_157;
        e.mem[_t_8 + 5] = _o_158;
        e.mem[_t_8 + 6] = _o_159;
        e.mem[_t_8 + 7] = _o_160;
        e.mem[_t_8 + 8] = _o_161;
        e.mem[_t_8 + 9] = _o_162;
        e.mem[_t_8 + 10] = _o_163;
        e.mem[_t_8 + 11] = _o_164;
        e.mem[_t_8 + 12] = _o_165;
        e.mem[_t_8 + 13] = _o_166;
        e.mem[_t_8 + 14] = _o_167;
        e.mem[_t_8 + 15] = _o_168;
        e.mem[_t_8 + 16] = _o_169;
        e.mem[_t_8 + 17] = _o_170;
        WL_CONT = term_tsk(FID_ONE_K944, _t_8);
        WL_IDX = 18;
      }
      if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
        u64 _t_9 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_9 + 0] = _depth_4;
        e.mem[_t_9 + 1] = 50ull;
        return term_tsk(FID_MAKE_SLOT, _t_9);
      }
      r0 = _depth_4;
      r1 = 50ull;
      WL_JMP(FID_MAKE_SLOT);
    } else {
      term_sink(e, _o_156);
      term_sink(e, _o_157);
      term_sink(e, _o_158);
      term_sink(e, _o_159);
      term_sink(e, _o_160);
      term_sink(e, _o_161);
      term_sink(e, _o_165);
      term_sink(e, _o_174);
      term_sink(e, _o_175);
      term_sink(e, _o_176);
      term_sink(e, _o_177);
      term_sink(e, _o_178);
      term_sink(e, _o_179);
      term_sink(e, _o_183);
      term_sink(e, _o_185);
      term_sink(e, _o_187);
      term_sink(e, _o_200);
      r0 = term_ctr(CID_SCON, STAT_OFF + 238);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K944)
  {
    WL_POPN(18);
    Term _depth_5 = STK(0);
    u32 _o_216 = STK(1);
    u32 _o_217 = STK(2);
    Term _o_218 = STK(3);
    Term _o_219 = STK(4);
    Term _o_220 = STK(5);
    Term _o_221 = STK(6);
    Term _o_222 = STK(7);
    Term _o_223 = STK(8);
    u32 _o_224 = STK(9);
    Term _o_225 = STK(10);
    u32 _o_226 = STK(11);
    Term _o_227 = STK(12);
    u32 _o_228 = STK(13);
    u32 _o_229 = STK(14);
    u32 _o_230 = STK(15);
    u32 _o_231 = STK(16);
    u32 _o_232 = STK(17);
    Term _h_70 = r0;
    u32 _h_71 = r1;
    u32 _h_72 = r2;
    u32 _h_73 = r3;
    u32 _h_74 = r4;
    u32 _h_75 = r5;
    u32 _h_76 = r6;
    u32 _h_77 = r7;
    u32 _h_78 = r8;
    WL_OPEN
    u32 _v_176 = 0;
    u32 _v_177 = 0;
    u32 _v_178 = 0;
    Term _v_179 = 0;
    Term _v_180 = 0;
    Term _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    Term _v_184 = 0;
    u32 _v_185 = 0;
    Term _v_186 = 0;
    u32 _v_187 = 0;
    Term _v_188 = 0;
    u32 _v_189 = 0;
    Term _v_190 = 0;
    Term _v_191 = 0;
    u32 _v_192 = 0;
    Term _v_193 = 0;
    u32 _v_194 = 0;
    Term _v_195 = 0;
    u32 _v_196 = 0;
    Term _v_197 = 0;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_70);
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_71);
    e.mem[_nd_2 + 2] = rfc_seal(e, _h_72);
    e.mem[_nd_2 + 3] = rfc_seal(e, _h_73);
    e.mem[_nd_2 + 4] = rfc_seal(e, _h_74);
    e.mem[_nd_2 + 5] = rfc_seal(e, _h_75);
    e.mem[_nd_2 + 6] = rfc_seal(e, _h_76);
    e.mem[_nd_2 + 7] = rfc_seal(e, _h_77);
    e.mem[_nd_2 + 8] = rfc_seal(e, _h_78);
    u32 _o_233 = 0;
    Term _o_234 = 0;
    if (_o_228 == 0) {
      _o_233 = 0;
    } else {
      _o_233 = 1;
      _o_234 = term_pak(CID_UNIT, 0);
    }
    u32 _v_198 = 0;
    u32 _v_199 = 0;
    u32 _v_200 = 0;
    Term _v_201 = 0;
    Term _v_202 = 0;
    Term _v_203 = 0;
    Term _v_204 = 0;
    Term _v_205 = 0;
    Term _v_206 = 0;
    u32 _v_207 = 0;
    Term _v_208 = 0;
    u32 _v_209 = 0;
    Term _v_210 = 0;
    u32 _v_211 = 0;
    Term _v_212 = 0;
    Term _v_213 = 0;
    u32 _v_214 = 0;
    Term _v_215 = 0;
    u32 _v_216 = 0;
    Term _v_217 = 0;
    u32 _v_218 = 0;
    Term _v_219 = 0;
    Term _o_235[22];
    Term _a_8 = term_pak(CID_UNIT, 0);
    Term _a_9 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_2);
    Term _a_10 = 0;
    Term _a_11 = 0;
    if (spin_62(e, _o_235, _o_216, _o_217, _o_218, blk_loc(e.mem, _o_218), _o_219, blk_loc(e.mem, _o_219), _o_220, blk_loc(e.mem, _o_220), _o_221, blk_loc(e.mem, _o_221), _o_222, blk_loc(e.mem, _o_222), _o_223, blk_loc(e.mem, _o_223), _o_224, _o_225, _o_226, _o_227, blk_loc(e.mem, _o_227), _o_233, _o_234, blk_loc(e.mem, _o_234), _a_8, blk_loc(e.mem, _a_8), 1, _a_9, blk_loc(e.mem, _a_9), 0, _a_10, blk_loc(e.mem, _a_10), 0, _a_11, blk_loc(e.mem, _a_11)) == 0) {
      return 0;
    }
    _v_198 = _o_235[0];
    _v_199 = _o_235[1];
    _v_200 = _o_235[2];
    _v_201 = _o_235[3];
    _v_202 = _o_235[4];
    _v_203 = _o_235[5];
    _v_204 = _o_235[6];
    _v_205 = _o_235[7];
    _v_206 = _o_235[8];
    _v_207 = _o_235[9];
    _v_208 = _o_235[10];
    _v_209 = _o_235[11];
    _v_210 = _o_235[12];
    _v_211 = _o_235[13];
    _v_212 = _o_235[14];
    _v_213 = _o_235[15];
    _v_214 = _o_235[16];
    _v_215 = _o_235[17];
    _v_216 = _o_235[18];
    _v_217 = _o_235[19];
    _v_218 = _o_235[20];
    _v_219 = _o_235[21];
    _v_176 = _v_198;
    _v_177 = _v_199;
    _v_178 = _v_200;
    _v_179 = _v_201;
    _v_180 = _v_202;
    _v_181 = _v_203;
    _v_182 = _v_204;
    _v_183 = _v_205;
    _v_184 = _v_206;
    _v_185 = _v_207;
    _v_186 = _v_208;
    _v_187 = _v_209;
    _v_188 = _v_210;
    _v_189 = _v_211;
    _v_190 = _v_212;
    _v_191 = _v_213;
    _v_192 = _v_214;
    _v_193 = _v_215;
    _v_194 = _v_216;
    _v_195 = _v_217;
    _v_196 = _v_218;
    _v_197 = _v_219;
    u32 _o_236 = 0;
    u32 _o_237 = 0;
    u32 _o_238 = 0;
    Term _o_239 = 0;
    Term _o_240 = 0;
    Term _o_241 = 0;
    Term _o_242 = 0;
    Term _o_243 = 0;
    Term _o_244 = 0;
    u32 _o_245 = 0;
    Term _o_246 = 0;
    u32 _o_247 = 0;
    Term _o_248 = 0;
    u32 _o_249 = 0;
    u32 _o_250 = 0;
    Term _o_251 = 0;
    u32 _o_252 = 0;
    u32 _o_253 = 0;
    u32 _o_254 = 0;
    u32 _o_255 = 0;
    u32 _o_256 = 0;
    u32 _o_257 = 0;
    u32 _o_258 = 0;
    u32 _o_259 = 0;
    u32 _o_260 = 0;
    u32 _o_261 = 0;
    if (_v_176 == 0) {
      _o_236 = 0;
      u32 _o_262 = 0;
      if (_v_189 == 0) {
        _o_262 = 0;
      } else {
        _o_262 = 1;
      }
      _o_237 = _v_177;
      _o_238 = _v_178;
      _o_239 = _v_179;
      _o_240 = _v_180;
      _o_241 = _v_181;
      _o_242 = _v_182;
      _o_243 = _v_183;
      _o_244 = _v_184;
      _o_245 = _v_185;
      _o_246 = _v_186;
      _o_247 = _v_187;
      _o_248 = _v_188;
      _o_249 = _o_262;
      _o_250 = _v_192;
      _o_251 = _v_193;
    } else {
      _o_236 = 1;
      u32 _o_263 = 0;
      if (_v_189 == 0) {
        _o_263 = 0;
      } else {
        _o_263 = 1;
      }
      u32 _o_264 = 0;
      Term _o_265 = 0;
      u32 _o_266 = 0;
      u32 _o_267 = 0;
      u32 _o_268 = 0;
      u32 _o_269 = 0;
      u32 _o_270 = 0;
      u32 _o_271 = 0;
      u32 _o_272 = 0;
      u32 _o_273 = 0;
      if (_v_192 == 0) {
        _o_264 = 0;
      } else {
        _o_264 = 1;
        Term _fb_4[9];
        u64 _sp_4 = ctr_take(e, _v_193, 9, _fb_4);
        Term _f_36 = _fb_4[0];
        u32 _f_37 = _fb_4[1];
        u32 _f_38 = _fb_4[2];
        u32 _f_39 = _fb_4[3];
        u32 _f_40 = _fb_4[4];
        u32 _f_41 = _fb_4[5];
        u32 _f_42 = _fb_4[6];
        u32 _f_43 = _fb_4[7];
        u32 _f_44 = _fb_4[8];
        spare_free(e, cls_fit(9), _sp_4);
        _o_265 = _f_36;
        _o_266 = _f_37;
        _o_267 = _f_38;
        _o_268 = _f_39;
        _o_269 = _f_40;
        _o_270 = _f_41;
        _o_271 = _f_42;
        _o_272 = _f_43;
        _o_273 = _f_44;
      }
      u32 _o_274 = 0;
      if (_v_194 == 0) {
        _o_274 = 0;
      } else {
        _o_274 = 1;
      }
      u32 _o_275 = 0;
      if (_v_196 == 0) {
        _o_275 = 0;
      } else {
        _o_275 = 1;
      }
      _o_237 = _v_177;
      _o_238 = _v_178;
      _o_239 = _v_179;
      _o_240 = _v_180;
      _o_241 = _v_181;
      _o_242 = _v_182;
      _o_243 = _v_183;
      _o_244 = _v_184;
      _o_245 = _v_185;
      _o_246 = _v_186;
      _o_247 = _v_187;
      _o_248 = _v_188;
      _o_249 = _o_263;
      _o_250 = _o_264;
      _o_251 = _o_265;
      _o_252 = _o_266;
      _o_253 = _o_267;
      _o_254 = _o_268;
      _o_255 = _o_269;
      _o_256 = _o_270;
      _o_257 = _o_271;
      _o_258 = _o_272;
      _o_259 = _o_273;
      _o_260 = _o_274;
      _o_261 = _o_275;
    }
    if (_o_236 == 0) {
      u32 _o_276 = 0;
      Term _o_277 = 0;
      if (_o_249 == 0) {
        _o_276 = 0;
      } else {
        _o_276 = 1;
        _o_277 = term_pak(CID_UNIT, 0);
      }
      if (seq) {
        WL_ROOM(6);
        STK(0) = _depth_5;
        STK(1) = _o_229;
        STK(2) = _o_230;
        STK(3) = _o_231;
        STK(4) = _o_232;
        STK(5) = FID_ONE_K945;
        WL_PUSHN(6);
      } else {
        u64 _t_10 = task_node(e, FID_ONE_K945, WL_CONT, WL_IDX, 1);
        e.mem[_t_10 + 0] = _depth_5;
        e.mem[_t_10 + 1] = _o_229;
        e.mem[_t_10 + 2] = _o_230;
        e.mem[_t_10 + 3] = _o_231;
        e.mem[_t_10 + 4] = _o_232;
        WL_CONT = term_tsk(FID_ONE_K945, _t_10);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_DESPAWN)) {
        u64 _t_11 = task_node(e, FID_COMMANDS_DESPAWN, WL_CONT, WL_IDX, 0);
        e.mem[_t_11 + 0] = _o_237;
        e.mem[_t_11 + 1] = _o_238;
        e.mem[_t_11 + 2] = _o_239;
        e.mem[_t_11 + 3] = _o_240;
        e.mem[_t_11 + 4] = _o_241;
        e.mem[_t_11 + 5] = _o_242;
        e.mem[_t_11 + 6] = _o_243;
        e.mem[_t_11 + 7] = _o_244;
        e.mem[_t_11 + 8] = _o_245;
        e.mem[_t_11 + 9] = _o_246;
        e.mem[_t_11 + 10] = _o_247;
        e.mem[_t_11 + 11] = _o_248;
        e.mem[_t_11 + 12] = _o_276;
        e.mem[_t_11 + 13] = _o_277;
        e.mem[_t_11 + 14] = term_pak(CID_UNIT, 0);
        e.mem[_t_11 + 15] = _o_229;
        e.mem[_t_11 + 16] = _o_230;
        return term_tsk(FID_COMMANDS_DESPAWN, _t_11);
      }
      r0 = _o_237;
      r1 = _o_238;
      r2 = _o_239;
      r3 = _o_240;
      r4 = _o_241;
      r5 = _o_242;
      r6 = _o_243;
      r7 = _o_244;
      r8 = _o_245;
      r9 = _o_246;
      r10 = _o_247;
      r11 = _o_248;
      r12 = _o_276;
      r13 = _o_277;
      r14 = term_pak(CID_UNIT, 0);
      r15 = _o_229;
      r16 = _o_230;
      WL_JMP(FID_COMMANDS_DESPAWN);
    } else {
      term_sink(e, _o_239);
      term_sink(e, _o_240);
      term_sink(e, _o_241);
      term_sink(e, _o_242);
      term_sink(e, _o_243);
      term_sink(e, _o_244);
      term_sink(e, _o_248);
      term_sink(e, _o_251);
      r0 = term_ctr(CID_SCON, STAT_OFF + 182);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K945)
  {
    WL_POPN(5);
    Term _depth_6 = STK(0);
    u32 _o_278 = STK(1);
    u32 _o_279 = STK(2);
    u32 _o_280 = STK(3);
    u32 _o_281 = STK(4);
    u32 _h_79 = r0;
    u32 _h_80 = r1;
    u32 _h_81 = r2;
    Term _h_82 = r3;
    Term _h_83 = r4;
    Term _h_84 = r5;
    Term _h_85 = r6;
    Term _h_86 = r7;
    Term _h_87 = r8;
    u32 _h_88 = r9;
    Term _h_89 = r10;
    u32 _h_90 = r11;
    Term _h_91 = r12;
    u32 _h_92 = r13;
    Term _h_93 = r14;
    Term _h_94 = r15;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_3 + 0] = _depth_6;
    e.mem[_nd_3 + 1] = _o_278;
    e.mem[_nd_3 + 2] = _o_279;
    e.mem[_nd_3 + 3] = _o_280;
    e.mem[_nd_3 + 4] = _o_281;
    u32 _o_599 = 0;
    u32 _o_600 = 0;
    u32 _o_601 = 0;
    Term _o_602 = 0;
    Term _o_603 = 0;
    Term _o_604 = 0;
    Term _o_605 = 0;
    Term _o_606 = 0;
    Term _o_607 = 0;
    u32 _o_608 = 0;
    Term _o_609 = 0;
    u32 _o_610 = 0;
    Term _o_611 = 0;
    u32 _o_612 = 0;
    Term _o_613 = 0;
    if (_h_79 == 0) {
      _o_599 = 0;
      u32 _o_614 = 0;
      if (_h_92 == 0) {
        _o_614 = 0;
      } else {
        _o_614 = 1;
      }
      _o_600 = _h_80;
      _o_601 = _h_81;
      _o_602 = _h_82;
      _o_603 = _h_83;
      _o_604 = _h_84;
      _o_605 = _h_85;
      _o_606 = _h_86;
      _o_607 = _h_87;
      _o_608 = _h_88;
      _o_609 = _h_89;
      _o_610 = _h_90;
      _o_611 = _h_91;
      _o_612 = _o_614;
    } else {
      _o_599 = 1;
      u32 _o_615 = 0;
      if (_h_92 == 0) {
        _o_615 = 0;
      } else {
        _o_615 = 1;
      }
      _o_600 = _h_80;
      _o_601 = _h_81;
      _o_602 = _h_82;
      _o_603 = _h_83;
      _o_604 = _h_84;
      _o_605 = _h_85;
      _o_606 = _h_86;
      _o_607 = _h_87;
      _o_608 = _h_88;
      _o_609 = _h_89;
      _o_610 = _h_90;
      _o_611 = _h_91;
      _o_612 = _o_615;
      _o_613 = term_pak(CID_UNIT, 0);
    }
    if (!DEVICE && !seq && fid_nofk(FID_SEEDED_RESULT)) {
      u64 _t_63 = task_node(e, FID_SEEDED_RESULT, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _o_599;
      e.mem[_t_63 + 1] = _o_600;
      e.mem[_t_63 + 2] = _o_601;
      e.mem[_t_63 + 3] = _o_602;
      e.mem[_t_63 + 4] = _o_603;
      e.mem[_t_63 + 5] = _o_604;
      e.mem[_t_63 + 6] = _o_605;
      e.mem[_t_63 + 7] = _o_606;
      e.mem[_t_63 + 8] = _o_607;
      e.mem[_t_63 + 9] = _o_608;
      e.mem[_t_63 + 10] = _o_609;
      e.mem[_t_63 + 11] = _o_610;
      e.mem[_t_63 + 12] = _o_611;
      e.mem[_t_63 + 13] = _o_612;
      e.mem[_t_63 + 14] = _o_613;
      e.mem[_t_63 + 15] = term_clo(FID_ONE_C946, _nd_3);
      return term_tsk(FID_SEEDED_RESULT, _t_63);
    }
    r0 = _o_599;
    r1 = _o_600;
    r2 = _o_601;
    r3 = _o_602;
    r4 = _o_603;
    r5 = _o_604;
    r6 = _o_605;
    r7 = _o_606;
    r8 = _o_607;
    r9 = _o_608;
    r10 = _o_609;
    r11 = _o_610;
    r12 = _o_611;
    r13 = _o_612;
    r14 = _o_613;
    r15 = term_clo(FID_ONE_C946, _nd_3);
    WL_JMP(FID_SEEDED_RESULT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_C946)
  {
    Term _depth_7 = r0;
    u32 _o_282 = r1;
    u32 _o_283 = r2;
    u32 _o_284 = r3;
    u32 _o_285 = r4;
    Term _x_0 = r5;
    WL_OPEN
    Term _fb_5[15];
    u64 _sp_5 = ctr_take(e, _x_0, 15, _fb_5);
    u32 _f_45 = _fb_5[0];
    u32 _f_46 = _fb_5[1];
    Term _f_47 = _fb_5[2];
    Term _f_48 = _fb_5[3];
    Term _f_49 = _fb_5[4];
    Term _f_50 = _fb_5[5];
    Term _f_51 = _fb_5[6];
    Term _f_52 = _fb_5[7];
    u32 _f_53 = _fb_5[8];
    Term _f_54 = _fb_5[9];
    u32 _f_55 = _fb_5[10];
    Term _f_56 = _fb_5[11];
    u32 _f_57 = _fb_5[12];
    Term _f_58 = _fb_5[13];
    Term _f_59 = _fb_5[14];
    spare_free(e, cls_fit(15), _sp_5);
    u32 _o_286 = 0;
    if (_f_57 == 0) {
      _o_286 = 0;
    } else {
      _o_286 = 1;
    }
    u32 _o_287 = 0;
    Term _o_288 = 0;
    if (_o_286 == 0) {
      _o_287 = 0;
    } else {
      _o_287 = 1;
      _o_288 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(6);
      STK(0) = _depth_7;
      STK(1) = _o_282;
      STK(2) = _o_283;
      STK(3) = _o_284;
      STK(4) = _o_285;
      STK(5) = FID_ONE_K947;
      WL_PUSHN(6);
    } else {
      u64 _t_12 = task_node(e, FID_ONE_K947, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _depth_7;
      e.mem[_t_12 + 1] = _o_282;
      e.mem[_t_12 + 2] = _o_283;
      e.mem[_t_12 + 3] = _o_284;
      e.mem[_t_12 + 4] = _o_285;
      WL_CONT = term_tsk(FID_ONE_K947, _t_12);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_REMOVE_FLAG)) {
      u64 _t_13 = task_node(e, FID_COMMANDS_REMOVE_FLAG, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _f_45;
      e.mem[_t_13 + 1] = _f_46;
      e.mem[_t_13 + 2] = _f_47;
      e.mem[_t_13 + 3] = _f_48;
      e.mem[_t_13 + 4] = _f_49;
      e.mem[_t_13 + 5] = _f_50;
      e.mem[_t_13 + 6] = _f_51;
      e.mem[_t_13 + 7] = _f_52;
      e.mem[_t_13 + 8] = _f_53;
      e.mem[_t_13 + 9] = _f_54;
      e.mem[_t_13 + 10] = _f_55;
      e.mem[_t_13 + 11] = _f_56;
      e.mem[_t_13 + 12] = _o_287;
      e.mem[_t_13 + 13] = _o_288;
      e.mem[_t_13 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_13 + 15] = _o_282;
      e.mem[_t_13 + 16] = _o_283;
      return term_tsk(FID_COMMANDS_REMOVE_FLAG, _t_13);
    }
    r0 = _f_45;
    r1 = _f_46;
    r2 = _f_47;
    r3 = _f_48;
    r4 = _f_49;
    r5 = _f_50;
    r6 = _f_51;
    r7 = _f_52;
    r8 = _f_53;
    r9 = _f_54;
    r10 = _f_55;
    r11 = _f_56;
    r12 = _o_287;
    r13 = _o_288;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_282;
    r16 = _o_283;
    WL_JMP(FID_COMMANDS_REMOVE_FLAG);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K947)
  {
    WL_POPN(5);
    Term _depth_8 = STK(0);
    u32 _o_289 = STK(1);
    u32 _o_290 = STK(2);
    u32 _o_291 = STK(3);
    u32 _o_292 = STK(4);
    u32 _h_95 = r0;
    u32 _h_96 = r1;
    u32 _h_97 = r2;
    Term _h_98 = r3;
    Term _h_99 = r4;
    Term _h_100 = r5;
    Term _h_101 = r6;
    Term _h_102 = r7;
    Term _h_103 = r8;
    u32 _h_104 = r9;
    Term _h_105 = r10;
    u32 _h_106 = r11;
    Term _h_107 = r12;
    u32 _h_108 = r13;
    Term _h_109 = r14;
    Term _h_110 = r15;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_4 + 0] = _depth_8;
    e.mem[_nd_4 + 1] = _o_289;
    e.mem[_nd_4 + 2] = _o_290;
    e.mem[_nd_4 + 3] = _o_291;
    e.mem[_nd_4 + 4] = _o_292;
    u32 _o_582 = 0;
    u32 _o_583 = 0;
    u32 _o_584 = 0;
    Term _o_585 = 0;
    Term _o_586 = 0;
    Term _o_587 = 0;
    Term _o_588 = 0;
    Term _o_589 = 0;
    Term _o_590 = 0;
    u32 _o_591 = 0;
    Term _o_592 = 0;
    u32 _o_593 = 0;
    Term _o_594 = 0;
    u32 _o_595 = 0;
    Term _o_596 = 0;
    if (_h_95 == 0) {
      _o_582 = 0;
      u32 _o_597 = 0;
      if (_h_108 == 0) {
        _o_597 = 0;
      } else {
        _o_597 = 1;
      }
      _o_583 = _h_96;
      _o_584 = _h_97;
      _o_585 = _h_98;
      _o_586 = _h_99;
      _o_587 = _h_100;
      _o_588 = _h_101;
      _o_589 = _h_102;
      _o_590 = _h_103;
      _o_591 = _h_104;
      _o_592 = _h_105;
      _o_593 = _h_106;
      _o_594 = _h_107;
      _o_595 = _o_597;
    } else {
      _o_582 = 1;
      u32 _o_598 = 0;
      if (_h_108 == 0) {
        _o_598 = 0;
      } else {
        _o_598 = 1;
      }
      _o_583 = _h_96;
      _o_584 = _h_97;
      _o_585 = _h_98;
      _o_586 = _h_99;
      _o_587 = _h_100;
      _o_588 = _h_101;
      _o_589 = _h_102;
      _o_590 = _h_103;
      _o_591 = _h_104;
      _o_592 = _h_105;
      _o_593 = _h_106;
      _o_594 = _h_107;
      _o_595 = _o_598;
      _o_596 = term_pak(CID_UNIT, 0);
    }
    if (!DEVICE && !seq && fid_nofk(FID_SEEDED_RESULT)) {
      u64 _t_62 = task_node(e, FID_SEEDED_RESULT, WL_CONT, WL_IDX, 0);
      e.mem[_t_62 + 0] = _o_582;
      e.mem[_t_62 + 1] = _o_583;
      e.mem[_t_62 + 2] = _o_584;
      e.mem[_t_62 + 3] = _o_585;
      e.mem[_t_62 + 4] = _o_586;
      e.mem[_t_62 + 5] = _o_587;
      e.mem[_t_62 + 6] = _o_588;
      e.mem[_t_62 + 7] = _o_589;
      e.mem[_t_62 + 8] = _o_590;
      e.mem[_t_62 + 9] = _o_591;
      e.mem[_t_62 + 10] = _o_592;
      e.mem[_t_62 + 11] = _o_593;
      e.mem[_t_62 + 12] = _o_594;
      e.mem[_t_62 + 13] = _o_595;
      e.mem[_t_62 + 14] = _o_596;
      e.mem[_t_62 + 15] = term_clo(FID_ONE_C948, _nd_4);
      return term_tsk(FID_SEEDED_RESULT, _t_62);
    }
    r0 = _o_582;
    r1 = _o_583;
    r2 = _o_584;
    r3 = _o_585;
    r4 = _o_586;
    r5 = _o_587;
    r6 = _o_588;
    r7 = _o_589;
    r8 = _o_590;
    r9 = _o_591;
    r10 = _o_592;
    r11 = _o_593;
    r12 = _o_594;
    r13 = _o_595;
    r14 = _o_596;
    r15 = term_clo(FID_ONE_C948, _nd_4);
    WL_JMP(FID_SEEDED_RESULT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_C948)
  {
    Term _depth_9 = r0;
    u32 _o_293 = r1;
    u32 _o_294 = r2;
    u32 _o_295 = r3;
    u32 _o_296 = r4;
    Term _x_1 = r5;
    WL_OPEN
    Term _fb_6[15];
    u64 _sp_6 = ctr_take(e, _x_1, 15, _fb_6);
    u32 _f_60 = _fb_6[0];
    u32 _f_61 = _fb_6[1];
    Term _f_62 = _fb_6[2];
    Term _f_63 = _fb_6[3];
    Term _f_64 = _fb_6[4];
    Term _f_65 = _fb_6[5];
    Term _f_66 = _fb_6[6];
    Term _f_67 = _fb_6[7];
    u32 _f_68 = _fb_6[8];
    Term _f_69 = _fb_6[9];
    u32 _f_70 = _fb_6[10];
    Term _f_71 = _fb_6[11];
    u32 _f_72 = _fb_6[12];
    Term _f_73 = _fb_6[13];
    Term _f_74 = _fb_6[14];
    spare_free(e, cls_fit(15), _sp_6);
    u32 _o_297 = 0;
    if (_f_72 == 0) {
      _o_297 = 0;
    } else {
      _o_297 = 1;
    }
    u32 _o_298 = 0;
    Term _o_299 = 0;
    if (_o_297 == 0) {
      _o_298 = 0;
    } else {
      _o_298 = 1;
      _o_299 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(6);
      STK(0) = _depth_9;
      STK(1) = _o_293;
      STK(2) = _o_294;
      STK(3) = _o_295;
      STK(4) = _o_296;
      STK(5) = FID_ONE_K949;
      WL_PUSHN(6);
    } else {
      u64 _t_14 = task_node(e, FID_ONE_K949, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _depth_9;
      e.mem[_t_14 + 1] = _o_293;
      e.mem[_t_14 + 2] = _o_294;
      e.mem[_t_14 + 3] = _o_295;
      e.mem[_t_14 + 4] = _o_296;
      WL_CONT = term_tsk(FID_ONE_K949, _t_14);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_REMOVE_MAIN)) {
      u64 _t_15 = task_node(e, FID_COMMANDS_REMOVE_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _f_60;
      e.mem[_t_15 + 1] = _f_61;
      e.mem[_t_15 + 2] = _f_62;
      e.mem[_t_15 + 3] = _f_63;
      e.mem[_t_15 + 4] = _f_64;
      e.mem[_t_15 + 5] = _f_65;
      e.mem[_t_15 + 6] = _f_66;
      e.mem[_t_15 + 7] = _f_67;
      e.mem[_t_15 + 8] = _f_68;
      e.mem[_t_15 + 9] = _f_69;
      e.mem[_t_15 + 10] = _f_70;
      e.mem[_t_15 + 11] = _f_71;
      e.mem[_t_15 + 12] = _o_298;
      e.mem[_t_15 + 13] = _o_299;
      e.mem[_t_15 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_15 + 15] = _o_293;
      e.mem[_t_15 + 16] = _o_294;
      return term_tsk(FID_COMMANDS_REMOVE_MAIN, _t_15);
    }
    r0 = _f_60;
    r1 = _f_61;
    r2 = _f_62;
    r3 = _f_63;
    r4 = _f_64;
    r5 = _f_65;
    r6 = _f_66;
    r7 = _f_67;
    r8 = _f_68;
    r9 = _f_69;
    r10 = _f_70;
    r11 = _f_71;
    r12 = _o_298;
    r13 = _o_299;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_293;
    r16 = _o_294;
    WL_JMP(FID_COMMANDS_REMOVE_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K949)
  {
    WL_POPN(5);
    Term _depth_10 = STK(0);
    u32 _o_300 = STK(1);
    u32 _o_301 = STK(2);
    u32 _o_302 = STK(3);
    u32 _o_303 = STK(4);
    u32 _h_111 = r0;
    u32 _h_112 = r1;
    u32 _h_113 = r2;
    Term _h_114 = r3;
    Term _h_115 = r4;
    Term _h_116 = r5;
    Term _h_117 = r6;
    Term _h_118 = r7;
    Term _h_119 = r8;
    u32 _h_120 = r9;
    Term _h_121 = r10;
    u32 _h_122 = r11;
    Term _h_123 = r12;
    u32 _h_124 = r13;
    Term _h_125 = r14;
    Term _h_126 = r15;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_5 + 0] = _depth_10;
    e.mem[_nd_5 + 1] = _o_300;
    e.mem[_nd_5 + 2] = _o_301;
    e.mem[_nd_5 + 3] = _o_302;
    e.mem[_nd_5 + 4] = _o_303;
    u32 _o_565 = 0;
    u32 _o_566 = 0;
    u32 _o_567 = 0;
    Term _o_568 = 0;
    Term _o_569 = 0;
    Term _o_570 = 0;
    Term _o_571 = 0;
    Term _o_572 = 0;
    Term _o_573 = 0;
    u32 _o_574 = 0;
    Term _o_575 = 0;
    u32 _o_576 = 0;
    Term _o_577 = 0;
    u32 _o_578 = 0;
    Term _o_579 = 0;
    if (_h_111 == 0) {
      _o_565 = 0;
      u32 _o_580 = 0;
      if (_h_124 == 0) {
        _o_580 = 0;
      } else {
        _o_580 = 1;
      }
      _o_566 = _h_112;
      _o_567 = _h_113;
      _o_568 = _h_114;
      _o_569 = _h_115;
      _o_570 = _h_116;
      _o_571 = _h_117;
      _o_572 = _h_118;
      _o_573 = _h_119;
      _o_574 = _h_120;
      _o_575 = _h_121;
      _o_576 = _h_122;
      _o_577 = _h_123;
      _o_578 = _o_580;
    } else {
      _o_565 = 1;
      u32 _o_581 = 0;
      if (_h_124 == 0) {
        _o_581 = 0;
      } else {
        _o_581 = 1;
      }
      _o_566 = _h_112;
      _o_567 = _h_113;
      _o_568 = _h_114;
      _o_569 = _h_115;
      _o_570 = _h_116;
      _o_571 = _h_117;
      _o_572 = _h_118;
      _o_573 = _h_119;
      _o_574 = _h_120;
      _o_575 = _h_121;
      _o_576 = _h_122;
      _o_577 = _h_123;
      _o_578 = _o_581;
      _o_579 = term_pak(CID_UNIT, 0);
    }
    if (!DEVICE && !seq && fid_nofk(FID_SEEDED_RESULT)) {
      u64 _t_61 = task_node(e, FID_SEEDED_RESULT, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = _o_565;
      e.mem[_t_61 + 1] = _o_566;
      e.mem[_t_61 + 2] = _o_567;
      e.mem[_t_61 + 3] = _o_568;
      e.mem[_t_61 + 4] = _o_569;
      e.mem[_t_61 + 5] = _o_570;
      e.mem[_t_61 + 6] = _o_571;
      e.mem[_t_61 + 7] = _o_572;
      e.mem[_t_61 + 8] = _o_573;
      e.mem[_t_61 + 9] = _o_574;
      e.mem[_t_61 + 10] = _o_575;
      e.mem[_t_61 + 11] = _o_576;
      e.mem[_t_61 + 12] = _o_577;
      e.mem[_t_61 + 13] = _o_578;
      e.mem[_t_61 + 14] = _o_579;
      e.mem[_t_61 + 15] = term_clo(FID_ONE_C950, _nd_5);
      return term_tsk(FID_SEEDED_RESULT, _t_61);
    }
    r0 = _o_565;
    r1 = _o_566;
    r2 = _o_567;
    r3 = _o_568;
    r4 = _o_569;
    r5 = _o_570;
    r6 = _o_571;
    r7 = _o_572;
    r8 = _o_573;
    r9 = _o_574;
    r10 = _o_575;
    r11 = _o_576;
    r12 = _o_577;
    r13 = _o_578;
    r14 = _o_579;
    r15 = term_clo(FID_ONE_C950, _nd_5);
    WL_JMP(FID_SEEDED_RESULT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_C950)
  {
    Term _depth_11 = r0;
    u32 _o_304 = r1;
    u32 _o_305 = r2;
    u32 _o_306 = r3;
    u32 _o_307 = r4;
    Term _x_2 = r5;
    WL_OPEN
    Term _fb_7[15];
    u64 _sp_7 = ctr_take(e, _x_2, 15, _fb_7);
    u32 _f_75 = _fb_7[0];
    u32 _f_76 = _fb_7[1];
    Term _f_77 = _fb_7[2];
    Term _f_78 = _fb_7[3];
    Term _f_79 = _fb_7[4];
    Term _f_80 = _fb_7[5];
    Term _f_81 = _fb_7[6];
    Term _f_82 = _fb_7[7];
    u32 _f_83 = _fb_7[8];
    Term _f_84 = _fb_7[9];
    u32 _f_85 = _fb_7[10];
    Term _f_86 = _fb_7[11];
    u32 _f_87 = _fb_7[12];
    Term _f_88 = _fb_7[13];
    Term _f_89 = _fb_7[14];
    spare_free(e, cls_fit(15), _sp_7);
    u32 _o_308 = 0;
    if (_f_87 == 0) {
      _o_308 = 0;
    } else {
      _o_308 = 1;
    }
    u32 _o_309 = 0;
    Term _o_310 = 0;
    if (_o_308 == 0) {
      _o_309 = 0;
    } else {
      _o_309 = 1;
      _o_310 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(6);
      STK(0) = _depth_11;
      STK(1) = _o_304;
      STK(2) = _o_305;
      STK(3) = _o_306;
      STK(4) = _o_307;
      STK(5) = FID_ONE_K951;
      WL_PUSHN(6);
    } else {
      u64 _t_16 = task_node(e, FID_ONE_K951, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _depth_11;
      e.mem[_t_16 + 1] = _o_304;
      e.mem[_t_16 + 2] = _o_305;
      e.mem[_t_16 + 3] = _o_306;
      e.mem[_t_16 + 4] = _o_307;
      WL_CONT = term_tsk(FID_ONE_K951, _t_16);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_FLAG)) {
      u64 _t_17 = task_node(e, FID_COMMANDS_INSERT_FLAG, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _f_75;
      e.mem[_t_17 + 1] = _f_76;
      e.mem[_t_17 + 2] = _f_77;
      e.mem[_t_17 + 3] = _f_78;
      e.mem[_t_17 + 4] = _f_79;
      e.mem[_t_17 + 5] = _f_80;
      e.mem[_t_17 + 6] = _f_81;
      e.mem[_t_17 + 7] = _f_82;
      e.mem[_t_17 + 8] = _f_83;
      e.mem[_t_17 + 9] = _f_84;
      e.mem[_t_17 + 10] = _f_85;
      e.mem[_t_17 + 11] = _f_86;
      e.mem[_t_17 + 12] = _o_309;
      e.mem[_t_17 + 13] = _o_310;
      e.mem[_t_17 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_17 + 15] = _o_304;
      e.mem[_t_17 + 16] = _o_305;
      e.mem[_t_17 + 17] = term_pak(CID_UNIT, 0);
      return term_tsk(FID_COMMANDS_INSERT_FLAG, _t_17);
    }
    r0 = _f_75;
    r1 = _f_76;
    r2 = _f_77;
    r3 = _f_78;
    r4 = _f_79;
    r5 = _f_80;
    r6 = _f_81;
    r7 = _f_82;
    r8 = _f_83;
    r9 = _f_84;
    r10 = _f_85;
    r11 = _f_86;
    r12 = _o_309;
    r13 = _o_310;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_304;
    r16 = _o_305;
    r17 = term_pak(CID_UNIT, 0);
    WL_JMP(FID_COMMANDS_INSERT_FLAG);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K951)
  {
    WL_POPN(5);
    Term _depth_12 = STK(0);
    u32 _o_311 = STK(1);
    u32 _o_312 = STK(2);
    u32 _o_313 = STK(3);
    u32 _o_314 = STK(4);
    u32 _h_127 = r0;
    u32 _h_128 = r1;
    u32 _h_129 = r2;
    Term _h_130 = r3;
    Term _h_131 = r4;
    Term _h_132 = r5;
    Term _h_133 = r6;
    Term _h_134 = r7;
    Term _h_135 = r8;
    u32 _h_136 = r9;
    Term _h_137 = r10;
    u32 _h_138 = r11;
    Term _h_139 = r12;
    u32 _h_140 = r13;
    Term _h_141 = r14;
    Term _h_142 = r15;
    Term _h_143 = r16;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_6 + 0] = _depth_12;
    e.mem[_nd_6 + 1] = _o_311;
    e.mem[_nd_6 + 2] = _o_312;
    e.mem[_nd_6 + 3] = _o_313;
    e.mem[_nd_6 + 4] = _o_314;
    u32 _o_548 = 0;
    u32 _o_549 = 0;
    u32 _o_550 = 0;
    Term _o_551 = 0;
    Term _o_552 = 0;
    Term _o_553 = 0;
    Term _o_554 = 0;
    Term _o_555 = 0;
    Term _o_556 = 0;
    u32 _o_557 = 0;
    Term _o_558 = 0;
    u32 _o_559 = 0;
    Term _o_560 = 0;
    u32 _o_561 = 0;
    Term _o_562 = 0;
    if (_h_127 == 0) {
      _o_548 = 0;
      u32 _o_563 = 0;
      if (_h_140 == 0) {
        _o_563 = 0;
      } else {
        _o_563 = 1;
      }
      _o_549 = _h_128;
      _o_550 = _h_129;
      _o_551 = _h_130;
      _o_552 = _h_131;
      _o_553 = _h_132;
      _o_554 = _h_133;
      _o_555 = _h_134;
      _o_556 = _h_135;
      _o_557 = _h_136;
      _o_558 = _h_137;
      _o_559 = _h_138;
      _o_560 = _h_139;
      _o_561 = _o_563;
    } else {
      _o_548 = 1;
      u32 _o_564 = 0;
      if (_h_140 == 0) {
        _o_564 = 0;
      } else {
        _o_564 = 1;
      }
      _o_549 = _h_128;
      _o_550 = _h_129;
      _o_551 = _h_130;
      _o_552 = _h_131;
      _o_553 = _h_132;
      _o_554 = _h_133;
      _o_555 = _h_134;
      _o_556 = _h_135;
      _o_557 = _h_136;
      _o_558 = _h_137;
      _o_559 = _h_138;
      _o_560 = _h_139;
      _o_561 = _o_564;
      _o_562 = _h_143;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SEEDED_RESULT)) {
      u64 _t_60 = task_node(e, FID_SEEDED_RESULT, WL_CONT, WL_IDX, 0);
      e.mem[_t_60 + 0] = _o_548;
      e.mem[_t_60 + 1] = _o_549;
      e.mem[_t_60 + 2] = _o_550;
      e.mem[_t_60 + 3] = _o_551;
      e.mem[_t_60 + 4] = _o_552;
      e.mem[_t_60 + 5] = _o_553;
      e.mem[_t_60 + 6] = _o_554;
      e.mem[_t_60 + 7] = _o_555;
      e.mem[_t_60 + 8] = _o_556;
      e.mem[_t_60 + 9] = _o_557;
      e.mem[_t_60 + 10] = _o_558;
      e.mem[_t_60 + 11] = _o_559;
      e.mem[_t_60 + 12] = _o_560;
      e.mem[_t_60 + 13] = _o_561;
      e.mem[_t_60 + 14] = _o_562;
      e.mem[_t_60 + 15] = term_clo(FID_ONE_C952, _nd_6);
      return term_tsk(FID_SEEDED_RESULT, _t_60);
    }
    r0 = _o_548;
    r1 = _o_549;
    r2 = _o_550;
    r3 = _o_551;
    r4 = _o_552;
    r5 = _o_553;
    r6 = _o_554;
    r7 = _o_555;
    r8 = _o_556;
    r9 = _o_557;
    r10 = _o_558;
    r11 = _o_559;
    r12 = _o_560;
    r13 = _o_561;
    r14 = _o_562;
    r15 = term_clo(FID_ONE_C952, _nd_6);
    WL_JMP(FID_SEEDED_RESULT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_C952)
  {
    Term _depth_13 = r0;
    u32 _o_315 = r1;
    u32 _o_316 = r2;
    u32 _o_317 = r3;
    u32 _o_318 = r4;
    Term _x_3 = r5;
    WL_OPEN
    Term _fb_8[15];
    u64 _sp_8 = ctr_take(e, _x_3, 15, _fb_8);
    u32 _f_90 = _fb_8[0];
    u32 _f_91 = _fb_8[1];
    Term _f_92 = _fb_8[2];
    Term _f_93 = _fb_8[3];
    Term _f_94 = _fb_8[4];
    Term _f_95 = _fb_8[5];
    Term _f_96 = _fb_8[6];
    Term _f_97 = _fb_8[7];
    u32 _f_98 = _fb_8[8];
    Term _f_99 = _fb_8[9];
    u32 _f_100 = _fb_8[10];
    Term _f_101 = _fb_8[11];
    u32 _f_102 = _fb_8[12];
    Term _f_103 = _fb_8[13];
    Term _f_104 = _fb_8[14];
    spare_free(e, cls_fit(15), _sp_8);
    u32 _o_319 = 0;
    if (_f_102 == 0) {
      _o_319 = 0;
    } else {
      _o_319 = 1;
    }
    if (seq) {
      WL_ROOM(19);
      STK(0) = _depth_13;
      STK(1) = _o_315;
      STK(2) = _o_316;
      STK(3) = _o_317;
      STK(4) = _o_318;
      STK(5) = _f_90;
      STK(6) = _f_91;
      STK(7) = _f_92;
      STK(8) = _f_93;
      STK(9) = _f_94;
      STK(10) = _f_95;
      STK(11) = _f_96;
      STK(12) = _f_97;
      STK(13) = _f_98;
      STK(14) = _f_99;
      STK(15) = _f_100;
      STK(16) = _f_101;
      STK(17) = _o_319;
      STK(18) = FID_ONE_K953;
      WL_PUSHN(19);
    } else {
      u64 _t_18 = task_node(e, FID_ONE_K953, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _depth_13;
      e.mem[_t_18 + 1] = _o_315;
      e.mem[_t_18 + 2] = _o_316;
      e.mem[_t_18 + 3] = _o_317;
      e.mem[_t_18 + 4] = _o_318;
      e.mem[_t_18 + 5] = _f_90;
      e.mem[_t_18 + 6] = _f_91;
      e.mem[_t_18 + 7] = _f_92;
      e.mem[_t_18 + 8] = _f_93;
      e.mem[_t_18 + 9] = _f_94;
      e.mem[_t_18 + 10] = _f_95;
      e.mem[_t_18 + 11] = _f_96;
      e.mem[_t_18 + 12] = _f_97;
      e.mem[_t_18 + 13] = _f_98;
      e.mem[_t_18 + 14] = _f_99;
      e.mem[_t_18 + 15] = _f_100;
      e.mem[_t_18 + 16] = _f_101;
      e.mem[_t_18 + 17] = _o_319;
      WL_CONT = term_tsk(FID_ONE_K953, _t_18);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
      u64 _t_19 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _depth_13;
      e.mem[_t_19 + 1] = 30ull;
      return term_tsk(FID_MAKE_SLOT, _t_19);
    }
    r0 = _depth_13;
    r1 = 30ull;
    WL_JMP(FID_MAKE_SLOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K953)
  {
    WL_POPN(18);
    Term _depth_14 = STK(0);
    u32 _o_320 = STK(1);
    u32 _o_321 = STK(2);
    u32 _o_322 = STK(3);
    u32 _o_323 = STK(4);
    u32 _f_105 = STK(5);
    u32 _f_106 = STK(6);
    Term _f_107 = STK(7);
    Term _f_108 = STK(8);
    Term _f_109 = STK(9);
    Term _f_110 = STK(10);
    Term _f_111 = STK(11);
    Term _f_112 = STK(12);
    u32 _f_113 = STK(13);
    Term _f_114 = STK(14);
    u32 _f_115 = STK(15);
    Term _f_116 = STK(16);
    u32 _o_324 = STK(17);
    Term _h_144 = r0;
    u32 _h_145 = r1;
    u32 _h_146 = r2;
    u32 _h_147 = r3;
    u32 _h_148 = r4;
    u32 _h_149 = r5;
    u32 _h_150 = r6;
    u32 _h_151 = r7;
    u32 _h_152 = r8;
    WL_OPEN
    u32 _o_325 = 0;
    Term _o_326 = 0;
    if (_o_324 == 0) {
      _o_325 = 0;
    } else {
      _o_325 = 1;
      _o_326 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_7 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_7 + 0] = rfc_seal(e, _h_144);
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_145);
    e.mem[_nd_7 + 2] = rfc_seal(e, _h_146);
    e.mem[_nd_7 + 3] = rfc_seal(e, _h_147);
    e.mem[_nd_7 + 4] = rfc_seal(e, _h_148);
    e.mem[_nd_7 + 5] = rfc_seal(e, _h_149);
    e.mem[_nd_7 + 6] = rfc_seal(e, _h_150);
    e.mem[_nd_7 + 7] = rfc_seal(e, _h_151);
    e.mem[_nd_7 + 8] = rfc_seal(e, _h_152);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _depth_14;
      STK(1) = _o_320;
      STK(2) = _o_321;
      STK(3) = _o_322;
      STK(4) = _o_323;
      STK(5) = FID_ONE_K954;
      WL_PUSHN(6);
    } else {
      u64 _t_20 = task_node(e, FID_ONE_K954, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _depth_14;
      e.mem[_t_20 + 1] = _o_320;
      e.mem[_t_20 + 2] = _o_321;
      e.mem[_t_20 + 3] = _o_322;
      e.mem[_t_20 + 4] = _o_323;
      WL_CONT = term_tsk(FID_ONE_K954, _t_20);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_MAIN)) {
      u64 _t_21 = task_node(e, FID_COMMANDS_INSERT_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _f_105;
      e.mem[_t_21 + 1] = _f_106;
      e.mem[_t_21 + 2] = _f_107;
      e.mem[_t_21 + 3] = _f_108;
      e.mem[_t_21 + 4] = _f_109;
      e.mem[_t_21 + 5] = _f_110;
      e.mem[_t_21 + 6] = _f_111;
      e.mem[_t_21 + 7] = _f_112;
      e.mem[_t_21 + 8] = _f_113;
      e.mem[_t_21 + 9] = _f_114;
      e.mem[_t_21 + 10] = _f_115;
      e.mem[_t_21 + 11] = _f_116;
      e.mem[_t_21 + 12] = _o_325;
      e.mem[_t_21 + 13] = _o_326;
      e.mem[_t_21 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_21 + 15] = _o_320;
      e.mem[_t_21 + 16] = _o_321;
      e.mem[_t_21 + 17] = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_7);
      return term_tsk(FID_COMMANDS_INSERT_MAIN, _t_21);
    }
    r0 = _f_105;
    r1 = _f_106;
    r2 = _f_107;
    r3 = _f_108;
    r4 = _f_109;
    r5 = _f_110;
    r6 = _f_111;
    r7 = _f_112;
    r8 = _f_113;
    r9 = _f_114;
    r10 = _f_115;
    r11 = _f_116;
    r12 = _o_325;
    r13 = _o_326;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_320;
    r16 = _o_321;
    r17 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_7);
    WL_JMP(FID_COMMANDS_INSERT_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K954)
  {
    WL_POPN(5);
    Term _depth_15 = STK(0);
    u32 _o_327 = STK(1);
    u32 _o_328 = STK(2);
    u32 _o_329 = STK(3);
    u32 _o_330 = STK(4);
    u32 _h_153 = r0;
    u32 _h_154 = r1;
    u32 _h_155 = r2;
    Term _h_156 = r3;
    Term _h_157 = r4;
    Term _h_158 = r5;
    Term _h_159 = r6;
    Term _h_160 = r7;
    Term _h_161 = r8;
    u32 _h_162 = r9;
    Term _h_163 = r10;
    u32 _h_164 = r11;
    Term _h_165 = r12;
    u32 _h_166 = r13;
    Term _h_167 = r14;
    Term _h_168 = r15;
    Term _h_169 = r16;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_8 + 0] = _depth_15;
    e.mem[_nd_8 + 1] = _o_327;
    e.mem[_nd_8 + 2] = _o_328;
    e.mem[_nd_8 + 3] = _o_329;
    e.mem[_nd_8 + 4] = _o_330;
    u32 _o_531 = 0;
    u32 _o_532 = 0;
    u32 _o_533 = 0;
    Term _o_534 = 0;
    Term _o_535 = 0;
    Term _o_536 = 0;
    Term _o_537 = 0;
    Term _o_538 = 0;
    Term _o_539 = 0;
    u32 _o_540 = 0;
    Term _o_541 = 0;
    u32 _o_542 = 0;
    Term _o_543 = 0;
    u32 _o_544 = 0;
    Term _o_545 = 0;
    if (_h_153 == 0) {
      _o_531 = 0;
      u32 _o_546 = 0;
      if (_h_166 == 0) {
        _o_546 = 0;
      } else {
        _o_546 = 1;
      }
      _o_532 = _h_154;
      _o_533 = _h_155;
      _o_534 = _h_156;
      _o_535 = _h_157;
      _o_536 = _h_158;
      _o_537 = _h_159;
      _o_538 = _h_160;
      _o_539 = _h_161;
      _o_540 = _h_162;
      _o_541 = _h_163;
      _o_542 = _h_164;
      _o_543 = _h_165;
      _o_544 = _o_546;
    } else {
      _o_531 = 1;
      u32 _o_547 = 0;
      if (_h_166 == 0) {
        _o_547 = 0;
      } else {
        _o_547 = 1;
      }
      _o_532 = _h_154;
      _o_533 = _h_155;
      _o_534 = _h_156;
      _o_535 = _h_157;
      _o_536 = _h_158;
      _o_537 = _h_159;
      _o_538 = _h_160;
      _o_539 = _h_161;
      _o_540 = _h_162;
      _o_541 = _h_163;
      _o_542 = _h_164;
      _o_543 = _h_165;
      _o_544 = _o_547;
      _o_545 = _h_169;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SEEDED_RESULT)) {
      u64 _t_59 = task_node(e, FID_SEEDED_RESULT, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = _o_531;
      e.mem[_t_59 + 1] = _o_532;
      e.mem[_t_59 + 2] = _o_533;
      e.mem[_t_59 + 3] = _o_534;
      e.mem[_t_59 + 4] = _o_535;
      e.mem[_t_59 + 5] = _o_536;
      e.mem[_t_59 + 6] = _o_537;
      e.mem[_t_59 + 7] = _o_538;
      e.mem[_t_59 + 8] = _o_539;
      e.mem[_t_59 + 9] = _o_540;
      e.mem[_t_59 + 10] = _o_541;
      e.mem[_t_59 + 11] = _o_542;
      e.mem[_t_59 + 12] = _o_543;
      e.mem[_t_59 + 13] = _o_544;
      e.mem[_t_59 + 14] = _o_545;
      e.mem[_t_59 + 15] = term_clo(FID_ONE_C955, _nd_8);
      return term_tsk(FID_SEEDED_RESULT, _t_59);
    }
    r0 = _o_531;
    r1 = _o_532;
    r2 = _o_533;
    r3 = _o_534;
    r4 = _o_535;
    r5 = _o_536;
    r6 = _o_537;
    r7 = _o_538;
    r8 = _o_539;
    r9 = _o_540;
    r10 = _o_541;
    r11 = _o_542;
    r12 = _o_543;
    r13 = _o_544;
    r14 = _o_545;
    r15 = term_clo(FID_ONE_C955, _nd_8);
    WL_JMP(FID_SEEDED_RESULT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_C955)
  {
    Term _depth_16 = r0;
    u32 _o_331 = r1;
    u32 _o_332 = r2;
    u32 _o_333 = r3;
    u32 _o_334 = r4;
    Term _x_4 = r5;
    WL_OPEN
    Term _fb_9[15];
    u64 _sp_9 = ctr_take(e, _x_4, 15, _fb_9);
    u32 _f_117 = _fb_9[0];
    u32 _f_118 = _fb_9[1];
    Term _f_119 = _fb_9[2];
    Term _f_120 = _fb_9[3];
    Term _f_121 = _fb_9[4];
    Term _f_122 = _fb_9[5];
    Term _f_123 = _fb_9[6];
    Term _f_124 = _fb_9[7];
    u32 _f_125 = _fb_9[8];
    Term _f_126 = _fb_9[9];
    u32 _f_127 = _fb_9[10];
    Term _f_128 = _fb_9[11];
    u32 _f_129 = _fb_9[12];
    Term _f_130 = _fb_9[13];
    Term _f_131 = _fb_9[14];
    spare_free(e, cls_fit(15), _sp_9);
    u32 _o_335 = 0;
    if (_f_129 == 0) {
      _o_335 = 0;
    } else {
      _o_335 = 1;
    }
    if (seq) {
      WL_ROOM(6);
      STK(0) = _depth_16;
      STK(1) = _o_331;
      STK(2) = _o_332;
      STK(3) = _o_333;
      STK(4) = _o_334;
      STK(5) = FID_ONE_K956;
      WL_PUSHN(6);
    } else {
      u64 _t_22 = task_node(e, FID_ONE_K956, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _depth_16;
      e.mem[_t_22 + 1] = _o_331;
      e.mem[_t_22 + 2] = _o_332;
      e.mem[_t_22 + 3] = _o_333;
      e.mem[_t_22 + 4] = _o_334;
      WL_CONT = term_tsk(FID_ONE_K956, _t_22);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_23 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _depth_16;
      e.mem[_t_23 + 1] = _f_117;
      e.mem[_t_23 + 2] = _f_118;
      e.mem[_t_23 + 3] = _f_119;
      e.mem[_t_23 + 4] = _f_120;
      e.mem[_t_23 + 5] = _f_121;
      e.mem[_t_23 + 6] = _f_122;
      e.mem[_t_23 + 7] = _f_123;
      e.mem[_t_23 + 8] = _f_124;
      e.mem[_t_23 + 9] = _f_125;
      e.mem[_t_23 + 10] = _f_126;
      e.mem[_t_23 + 11] = _f_127;
      e.mem[_t_23 + 12] = _f_128;
      e.mem[_t_23 + 13] = _o_335;
      return term_tsk(FID_SNAPSHOT, _t_23);
    }
    r0 = _depth_16;
    r1 = _f_117;
    r2 = _f_118;
    r3 = _f_119;
    r4 = _f_120;
    r5 = _f_121;
    r6 = _f_122;
    r7 = _f_123;
    r8 = _f_124;
    r9 = _f_125;
    r10 = _f_126;
    r11 = _f_127;
    r12 = _f_128;
    r13 = _o_335;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K956)
  {
    WL_POPN(5);
    Term _depth_17 = STK(0);
    u32 _o_336 = STK(1);
    u32 _o_337 = STK(2);
    u32 _o_338 = STK(3);
    u32 _o_339 = STK(4);
    u32 _h_170 = r0;
    u32 _h_171 = r1;
    Term _h_172 = r2;
    Term _h_173 = r3;
    Term _h_174 = r4;
    Term _h_175 = r5;
    Term _h_176 = r6;
    Term _h_177 = r7;
    u32 _h_178 = r8;
    Term _h_179 = r9;
    u32 _h_180 = r10;
    Term _h_181 = r11;
    u32 _h_182 = r12;
    Term _h_183 = r13;
    WL_OPEN
    u32 _o_340 = 0;
    Term _o_341 = 0;
    if (_h_182 == 0) {
      _o_340 = 0;
    } else {
      _o_340 = 1;
      _o_341 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(7);
      STK(0) = _depth_17;
      STK(1) = _o_336;
      STK(2) = _o_337;
      STK(3) = _h_183;
      STK(4) = _o_338;
      STK(5) = _o_339;
      STK(6) = FID_ONE_K957;
      WL_PUSHN(7);
    } else {
      u64 _t_24 = task_node(e, FID_ONE_K957, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _depth_17;
      e.mem[_t_24 + 1] = _o_336;
      e.mem[_t_24 + 2] = _o_337;
      e.mem[_t_24 + 3] = _h_183;
      e.mem[_t_24 + 4] = _o_338;
      e.mem[_t_24 + 5] = _o_339;
      WL_CONT = term_tsk(FID_ONE_K957, _t_24);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_FLAG)) {
      u64 _t_25 = task_node(e, FID_COMMANDS_INSERT_FLAG, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_170;
      e.mem[_t_25 + 1] = _h_171;
      e.mem[_t_25 + 2] = _h_172;
      e.mem[_t_25 + 3] = _h_173;
      e.mem[_t_25 + 4] = _h_174;
      e.mem[_t_25 + 5] = _h_175;
      e.mem[_t_25 + 6] = _h_176;
      e.mem[_t_25 + 7] = _h_177;
      e.mem[_t_25 + 8] = _h_178;
      e.mem[_t_25 + 9] = _h_179;
      e.mem[_t_25 + 10] = _h_180;
      e.mem[_t_25 + 11] = _h_181;
      e.mem[_t_25 + 12] = _o_340;
      e.mem[_t_25 + 13] = _o_341;
      e.mem[_t_25 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_25 + 15] = _o_338;
      e.mem[_t_25 + 16] = _o_339;
      e.mem[_t_25 + 17] = term_pak(CID_UNIT, 0);
      return term_tsk(FID_COMMANDS_INSERT_FLAG, _t_25);
    }
    r0 = _h_170;
    r1 = _h_171;
    r2 = _h_172;
    r3 = _h_173;
    r4 = _h_174;
    r5 = _h_175;
    r6 = _h_176;
    r7 = _h_177;
    r8 = _h_178;
    r9 = _h_179;
    r10 = _h_180;
    r11 = _h_181;
    r12 = _o_340;
    r13 = _o_341;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_338;
    r16 = _o_339;
    r17 = term_pak(CID_UNIT, 0);
    WL_JMP(FID_COMMANDS_INSERT_FLAG);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K957)
  {
    WL_POPN(6);
    Term _depth_18 = STK(0);
    u32 _o_342 = STK(1);
    u32 _o_343 = STK(2);
    Term _h_201 = STK(3);
    u32 _o_344 = STK(4);
    u32 _o_345 = STK(5);
    u32 _h_184 = r0;
    u32 _h_185 = r1;
    u32 _h_186 = r2;
    Term _h_187 = r3;
    Term _h_188 = r4;
    Term _h_189 = r5;
    Term _h_190 = r6;
    Term _h_191 = r7;
    Term _h_192 = r8;
    u32 _h_193 = r9;
    Term _h_194 = r10;
    u32 _h_195 = r11;
    Term _h_196 = r12;
    u32 _h_197 = r13;
    Term _h_198 = r14;
    Term _h_199 = r15;
    Term _h_200 = r16;
    WL_OPEN
    u32 _o_346 = 0;
    u32 _o_347 = 0;
    u32 _o_348 = 0;
    Term _o_349 = 0;
    Term _o_350 = 0;
    Term _o_351 = 0;
    Term _o_352 = 0;
    Term _o_353 = 0;
    Term _o_354 = 0;
    u32 _o_355 = 0;
    Term _o_356 = 0;
    u32 _o_357 = 0;
    Term _o_358 = 0;
    u32 _o_359 = 0;
    if (_h_184 == 0) {
      _o_346 = 0;
      u32 _o_360 = 0;
      if (_h_197 == 0) {
        _o_360 = 0;
      } else {
        _o_360 = 1;
      }
      _o_347 = _h_185;
      _o_348 = _h_186;
      _o_349 = _h_187;
      _o_350 = _h_188;
      _o_351 = _h_189;
      _o_352 = _h_190;
      _o_353 = _h_191;
      _o_354 = _h_192;
      _o_355 = _h_193;
      _o_356 = _h_194;
      _o_357 = _h_195;
      _o_358 = _h_196;
      _o_359 = _o_360;
    } else {
      _o_346 = 1;
      u32 _o_361 = 0;
      if (_h_197 == 0) {
        _o_361 = 0;
      } else {
        _o_361 = 1;
      }
      _o_347 = _h_185;
      _o_348 = _h_186;
      _o_349 = _h_187;
      _o_350 = _h_188;
      _o_351 = _h_189;
      _o_352 = _h_190;
      _o_353 = _h_191;
      _o_354 = _h_192;
      _o_355 = _h_193;
      _o_356 = _h_194;
      _o_357 = _h_195;
      _o_358 = _h_196;
      _o_359 = _o_361;
    }
    if (_o_346 == 1) {
      u32 _o_362 = 0;
      Term _o_363 = 0;
      if (_o_359 == 0) {
        _o_362 = 0;
      } else {
        _o_362 = 1;
        _o_363 = term_pak(CID_UNIT, 0);
      }
      if (seq) {
        WL_ROOM(7);
        STK(0) = _depth_18;
        STK(1) = _o_342;
        STK(2) = _o_343;
        STK(3) = _h_201;
        STK(4) = _o_344;
        STK(5) = _o_345;
        STK(6) = FID_ONE_K958;
        WL_PUSHN(7);
      } else {
        u64 _t_26 = task_node(e, FID_ONE_K958, WL_CONT, WL_IDX, 1);
        e.mem[_t_26 + 0] = _depth_18;
        e.mem[_t_26 + 1] = _o_342;
        e.mem[_t_26 + 2] = _o_343;
        e.mem[_t_26 + 3] = _h_201;
        e.mem[_t_26 + 4] = _o_344;
        e.mem[_t_26 + 5] = _o_345;
        WL_CONT = term_tsk(FID_ONE_K958, _t_26);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_REMOVE_MAIN)) {
        u64 _t_27 = task_node(e, FID_COMMANDS_REMOVE_MAIN, WL_CONT, WL_IDX, 0);
        e.mem[_t_27 + 0] = _o_347;
        e.mem[_t_27 + 1] = _o_348;
        e.mem[_t_27 + 2] = _o_349;
        e.mem[_t_27 + 3] = _o_350;
        e.mem[_t_27 + 4] = _o_351;
        e.mem[_t_27 + 5] = _o_352;
        e.mem[_t_27 + 6] = _o_353;
        e.mem[_t_27 + 7] = _o_354;
        e.mem[_t_27 + 8] = _o_355;
        e.mem[_t_27 + 9] = _o_356;
        e.mem[_t_27 + 10] = _o_357;
        e.mem[_t_27 + 11] = _o_358;
        e.mem[_t_27 + 12] = _o_362;
        e.mem[_t_27 + 13] = _o_363;
        e.mem[_t_27 + 14] = term_pak(CID_UNIT, 0);
        e.mem[_t_27 + 15] = _o_344;
        e.mem[_t_27 + 16] = _o_345;
        return term_tsk(FID_COMMANDS_REMOVE_MAIN, _t_27);
      }
      r0 = _o_347;
      r1 = _o_348;
      r2 = _o_349;
      r3 = _o_350;
      r4 = _o_351;
      r5 = _o_352;
      r6 = _o_353;
      r7 = _o_354;
      r8 = _o_355;
      r9 = _o_356;
      r10 = _o_357;
      r11 = _o_358;
      r12 = _o_362;
      r13 = _o_363;
      r14 = term_pak(CID_UNIT, 0);
      r15 = _o_344;
      r16 = _o_345;
      WL_JMP(FID_COMMANDS_REMOVE_MAIN);
    } else {
      term_sink(e, _h_201);
      term_sink(e, _o_349);
      term_sink(e, _o_350);
      term_sink(e, _o_351);
      term_sink(e, _o_352);
      term_sink(e, _o_353);
      term_sink(e, _o_354);
      term_sink(e, _o_358);
      r0 = term_ctr(CID_SCON, STAT_OFF + 84);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K958)
  {
    WL_POPN(6);
    Term _depth_19 = STK(0);
    u32 _o_364 = STK(1);
    u32 _o_365 = STK(2);
    Term _h_218 = STK(3);
    u32 _o_366 = STK(4);
    u32 _o_367 = STK(5);
    u32 _h_202 = r0;
    u32 _h_203 = r1;
    u32 _h_204 = r2;
    Term _h_205 = r3;
    Term _h_206 = r4;
    Term _h_207 = r5;
    Term _h_208 = r6;
    Term _h_209 = r7;
    Term _h_210 = r8;
    u32 _h_211 = r9;
    Term _h_212 = r10;
    u32 _h_213 = r11;
    Term _h_214 = r12;
    u32 _h_215 = r13;
    Term _h_216 = r14;
    Term _h_217 = r15;
    WL_OPEN
    u32 _o_368 = 0;
    u32 _o_369 = 0;
    u32 _o_370 = 0;
    Term _o_371 = 0;
    Term _o_372 = 0;
    Term _o_373 = 0;
    Term _o_374 = 0;
    Term _o_375 = 0;
    Term _o_376 = 0;
    u32 _o_377 = 0;
    Term _o_378 = 0;
    u32 _o_379 = 0;
    Term _o_380 = 0;
    u32 _o_381 = 0;
    if (_h_202 == 0) {
      _o_368 = 0;
      u32 _o_382 = 0;
      if (_h_215 == 0) {
        _o_382 = 0;
      } else {
        _o_382 = 1;
      }
      _o_369 = _h_203;
      _o_370 = _h_204;
      _o_371 = _h_205;
      _o_372 = _h_206;
      _o_373 = _h_207;
      _o_374 = _h_208;
      _o_375 = _h_209;
      _o_376 = _h_210;
      _o_377 = _h_211;
      _o_378 = _h_212;
      _o_379 = _h_213;
      _o_380 = _h_214;
      _o_381 = _o_382;
    } else {
      _o_368 = 1;
      u32 _o_383 = 0;
      if (_h_215 == 0) {
        _o_383 = 0;
      } else {
        _o_383 = 1;
      }
      _o_369 = _h_203;
      _o_370 = _h_204;
      _o_371 = _h_205;
      _o_372 = _h_206;
      _o_373 = _h_207;
      _o_374 = _h_208;
      _o_375 = _h_209;
      _o_376 = _h_210;
      _o_377 = _h_211;
      _o_378 = _h_212;
      _o_379 = _h_213;
      _o_380 = _h_214;
      _o_381 = _o_383;
    }
    if (_o_368 == 1) {
      u32 _o_384 = 0;
      Term _o_385 = 0;
      if (_o_381 == 0) {
        _o_384 = 0;
      } else {
        _o_384 = 1;
        _o_385 = term_pak(CID_UNIT, 0);
      }
      if (seq) {
        WL_ROOM(7);
        STK(0) = _depth_19;
        STK(1) = _o_364;
        STK(2) = _o_365;
        STK(3) = _h_218;
        STK(4) = _o_366;
        STK(5) = _o_367;
        STK(6) = FID_ONE_K959;
        WL_PUSHN(7);
      } else {
        u64 _t_28 = task_node(e, FID_ONE_K959, WL_CONT, WL_IDX, 1);
        e.mem[_t_28 + 0] = _depth_19;
        e.mem[_t_28 + 1] = _o_364;
        e.mem[_t_28 + 2] = _o_365;
        e.mem[_t_28 + 3] = _h_218;
        e.mem[_t_28 + 4] = _o_366;
        e.mem[_t_28 + 5] = _o_367;
        WL_CONT = term_tsk(FID_ONE_K959, _t_28);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_REMOVE_FLAG)) {
        u64 _t_29 = task_node(e, FID_COMMANDS_REMOVE_FLAG, WL_CONT, WL_IDX, 0);
        e.mem[_t_29 + 0] = _o_369;
        e.mem[_t_29 + 1] = _o_370;
        e.mem[_t_29 + 2] = _o_371;
        e.mem[_t_29 + 3] = _o_372;
        e.mem[_t_29 + 4] = _o_373;
        e.mem[_t_29 + 5] = _o_374;
        e.mem[_t_29 + 6] = _o_375;
        e.mem[_t_29 + 7] = _o_376;
        e.mem[_t_29 + 8] = _o_377;
        e.mem[_t_29 + 9] = _o_378;
        e.mem[_t_29 + 10] = _o_379;
        e.mem[_t_29 + 11] = _o_380;
        e.mem[_t_29 + 12] = _o_384;
        e.mem[_t_29 + 13] = _o_385;
        e.mem[_t_29 + 14] = term_pak(CID_UNIT, 0);
        e.mem[_t_29 + 15] = _o_366;
        e.mem[_t_29 + 16] = _o_367;
        return term_tsk(FID_COMMANDS_REMOVE_FLAG, _t_29);
      }
      r0 = _o_369;
      r1 = _o_370;
      r2 = _o_371;
      r3 = _o_372;
      r4 = _o_373;
      r5 = _o_374;
      r6 = _o_375;
      r7 = _o_376;
      r8 = _o_377;
      r9 = _o_378;
      r10 = _o_379;
      r11 = _o_380;
      r12 = _o_384;
      r13 = _o_385;
      r14 = term_pak(CID_UNIT, 0);
      r15 = _o_366;
      r16 = _o_367;
      WL_JMP(FID_COMMANDS_REMOVE_FLAG);
    } else {
      term_sink(e, _h_218);
      term_sink(e, _o_371);
      term_sink(e, _o_372);
      term_sink(e, _o_373);
      term_sink(e, _o_374);
      term_sink(e, _o_375);
      term_sink(e, _o_376);
      term_sink(e, _o_380);
      r0 = term_ctr(CID_SCON, STAT_OFF + 84);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K959)
  {
    WL_POPN(6);
    Term _depth_20 = STK(0);
    u32 _o_386 = STK(1);
    u32 _o_387 = STK(2);
    Term _h_235 = STK(3);
    u32 _o_388 = STK(4);
    u32 _o_389 = STK(5);
    u32 _h_219 = r0;
    u32 _h_220 = r1;
    u32 _h_221 = r2;
    Term _h_222 = r3;
    Term _h_223 = r4;
    Term _h_224 = r5;
    Term _h_225 = r6;
    Term _h_226 = r7;
    Term _h_227 = r8;
    u32 _h_228 = r9;
    Term _h_229 = r10;
    u32 _h_230 = r11;
    Term _h_231 = r12;
    u32 _h_232 = r13;
    Term _h_233 = r14;
    Term _h_234 = r15;
    WL_OPEN
    u32 _o_390 = 0;
    u32 _o_391 = 0;
    u32 _o_392 = 0;
    Term _o_393 = 0;
    Term _o_394 = 0;
    Term _o_395 = 0;
    Term _o_396 = 0;
    Term _o_397 = 0;
    Term _o_398 = 0;
    u32 _o_399 = 0;
    Term _o_400 = 0;
    u32 _o_401 = 0;
    Term _o_402 = 0;
    u32 _o_403 = 0;
    if (_h_219 == 0) {
      _o_390 = 0;
      u32 _o_404 = 0;
      if (_h_232 == 0) {
        _o_404 = 0;
      } else {
        _o_404 = 1;
      }
      _o_391 = _h_220;
      _o_392 = _h_221;
      _o_393 = _h_222;
      _o_394 = _h_223;
      _o_395 = _h_224;
      _o_396 = _h_225;
      _o_397 = _h_226;
      _o_398 = _h_227;
      _o_399 = _h_228;
      _o_400 = _h_229;
      _o_401 = _h_230;
      _o_402 = _h_231;
      _o_403 = _o_404;
    } else {
      _o_390 = 1;
      u32 _o_405 = 0;
      if (_h_232 == 0) {
        _o_405 = 0;
      } else {
        _o_405 = 1;
      }
      _o_391 = _h_220;
      _o_392 = _h_221;
      _o_393 = _h_222;
      _o_394 = _h_223;
      _o_395 = _h_224;
      _o_396 = _h_225;
      _o_397 = _h_226;
      _o_398 = _h_227;
      _o_399 = _h_228;
      _o_400 = _h_229;
      _o_401 = _h_230;
      _o_402 = _h_231;
      _o_403 = _o_405;
    }
    if (_o_390 == 1) {
      u32 _o_406 = 0;
      Term _o_407 = 0;
      if (_o_403 == 0) {
        _o_406 = 0;
      } else {
        _o_406 = 1;
        _o_407 = term_pak(CID_UNIT, 0);
      }
      if (seq) {
        WL_ROOM(7);
        STK(0) = _depth_20;
        STK(1) = _o_386;
        STK(2) = _o_387;
        STK(3) = _h_235;
        STK(4) = _o_388;
        STK(5) = _o_389;
        STK(6) = FID_ONE_K960;
        WL_PUSHN(7);
      } else {
        u64 _t_30 = task_node(e, FID_ONE_K960, WL_CONT, WL_IDX, 1);
        e.mem[_t_30 + 0] = _depth_20;
        e.mem[_t_30 + 1] = _o_386;
        e.mem[_t_30 + 2] = _o_387;
        e.mem[_t_30 + 3] = _h_235;
        e.mem[_t_30 + 4] = _o_388;
        e.mem[_t_30 + 5] = _o_389;
        WL_CONT = term_tsk(FID_ONE_K960, _t_30);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_DESPAWN)) {
        u64 _t_31 = task_node(e, FID_COMMANDS_DESPAWN, WL_CONT, WL_IDX, 0);
        e.mem[_t_31 + 0] = _o_391;
        e.mem[_t_31 + 1] = _o_392;
        e.mem[_t_31 + 2] = _o_393;
        e.mem[_t_31 + 3] = _o_394;
        e.mem[_t_31 + 4] = _o_395;
        e.mem[_t_31 + 5] = _o_396;
        e.mem[_t_31 + 6] = _o_397;
        e.mem[_t_31 + 7] = _o_398;
        e.mem[_t_31 + 8] = _o_399;
        e.mem[_t_31 + 9] = _o_400;
        e.mem[_t_31 + 10] = _o_401;
        e.mem[_t_31 + 11] = _o_402;
        e.mem[_t_31 + 12] = _o_406;
        e.mem[_t_31 + 13] = _o_407;
        e.mem[_t_31 + 14] = term_pak(CID_UNIT, 0);
        e.mem[_t_31 + 15] = _o_388;
        e.mem[_t_31 + 16] = _o_389;
        return term_tsk(FID_COMMANDS_DESPAWN, _t_31);
      }
      r0 = _o_391;
      r1 = _o_392;
      r2 = _o_393;
      r3 = _o_394;
      r4 = _o_395;
      r5 = _o_396;
      r6 = _o_397;
      r7 = _o_398;
      r8 = _o_399;
      r9 = _o_400;
      r10 = _o_401;
      r11 = _o_402;
      r12 = _o_406;
      r13 = _o_407;
      r14 = term_pak(CID_UNIT, 0);
      r15 = _o_388;
      r16 = _o_389;
      WL_JMP(FID_COMMANDS_DESPAWN);
    } else {
      term_sink(e, _h_235);
      term_sink(e, _o_393);
      term_sink(e, _o_394);
      term_sink(e, _o_395);
      term_sink(e, _o_396);
      term_sink(e, _o_397);
      term_sink(e, _o_398);
      term_sink(e, _o_402);
      r0 = term_ctr(CID_SCON, STAT_OFF + 84);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K960)
  {
    WL_POPN(6);
    Term _depth_21 = STK(0);
    u32 _o_408 = STK(1);
    u32 _o_409 = STK(2);
    Term _h_252 = STK(3);
    u32 _o_410 = STK(4);
    u32 _o_411 = STK(5);
    u32 _h_236 = r0;
    u32 _h_237 = r1;
    u32 _h_238 = r2;
    Term _h_239 = r3;
    Term _h_240 = r4;
    Term _h_241 = r5;
    Term _h_242 = r6;
    Term _h_243 = r7;
    Term _h_244 = r8;
    u32 _h_245 = r9;
    Term _h_246 = r10;
    u32 _h_247 = r11;
    Term _h_248 = r12;
    u32 _h_249 = r13;
    Term _h_250 = r14;
    Term _h_251 = r15;
    WL_OPEN
    u32 _o_412 = 0;
    u32 _o_413 = 0;
    u32 _o_414 = 0;
    Term _o_415 = 0;
    Term _o_416 = 0;
    Term _o_417 = 0;
    Term _o_418 = 0;
    Term _o_419 = 0;
    Term _o_420 = 0;
    u32 _o_421 = 0;
    Term _o_422 = 0;
    u32 _o_423 = 0;
    Term _o_424 = 0;
    u32 _o_425 = 0;
    if (_h_236 == 0) {
      _o_412 = 0;
      u32 _o_426 = 0;
      if (_h_249 == 0) {
        _o_426 = 0;
      } else {
        _o_426 = 1;
      }
      _o_413 = _h_237;
      _o_414 = _h_238;
      _o_415 = _h_239;
      _o_416 = _h_240;
      _o_417 = _h_241;
      _o_418 = _h_242;
      _o_419 = _h_243;
      _o_420 = _h_244;
      _o_421 = _h_245;
      _o_422 = _h_246;
      _o_423 = _h_247;
      _o_424 = _h_248;
      _o_425 = _o_426;
    } else {
      _o_412 = 1;
      u32 _o_427 = 0;
      if (_h_249 == 0) {
        _o_427 = 0;
      } else {
        _o_427 = 1;
      }
      _o_413 = _h_237;
      _o_414 = _h_238;
      _o_415 = _h_239;
      _o_416 = _h_240;
      _o_417 = _h_241;
      _o_418 = _h_242;
      _o_419 = _h_243;
      _o_420 = _h_244;
      _o_421 = _h_245;
      _o_422 = _h_246;
      _o_423 = _h_247;
      _o_424 = _h_248;
      _o_425 = _o_427;
    }
    if (_o_412 == 1) {
      if (seq) {
        WL_ROOM(20);
        STK(0) = _depth_21;
        STK(1) = _o_408;
        STK(2) = _o_409;
        STK(3) = _h_252;
        STK(4) = _o_410;
        STK(5) = _o_411;
        STK(6) = _o_413;
        STK(7) = _o_414;
        STK(8) = _o_415;
        STK(9) = _o_416;
        STK(10) = _o_417;
        STK(11) = _o_418;
        STK(12) = _o_419;
        STK(13) = _o_420;
        STK(14) = _o_421;
        STK(15) = _o_422;
        STK(16) = _o_423;
        STK(17) = _o_424;
        STK(18) = _o_425;
        STK(19) = FID_ONE_K961;
        WL_PUSHN(20);
      } else {
        u64 _t_32 = task_node(e, FID_ONE_K961, WL_CONT, WL_IDX, 1);
        e.mem[_t_32 + 0] = _depth_21;
        e.mem[_t_32 + 1] = _o_408;
        e.mem[_t_32 + 2] = _o_409;
        e.mem[_t_32 + 3] = _h_252;
        e.mem[_t_32 + 4] = _o_410;
        e.mem[_t_32 + 5] = _o_411;
        e.mem[_t_32 + 6] = _o_413;
        e.mem[_t_32 + 7] = _o_414;
        e.mem[_t_32 + 8] = _o_415;
        e.mem[_t_32 + 9] = _o_416;
        e.mem[_t_32 + 10] = _o_417;
        e.mem[_t_32 + 11] = _o_418;
        e.mem[_t_32 + 12] = _o_419;
        e.mem[_t_32 + 13] = _o_420;
        e.mem[_t_32 + 14] = _o_421;
        e.mem[_t_32 + 15] = _o_422;
        e.mem[_t_32 + 16] = _o_423;
        e.mem[_t_32 + 17] = _o_424;
        e.mem[_t_32 + 18] = _o_425;
        WL_CONT = term_tsk(FID_ONE_K961, _t_32);
        WL_IDX = 19;
      }
      if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
        u64 _t_33 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_33 + 0] = _depth_21;
        e.mem[_t_33 + 1] = 90ull;
        return term_tsk(FID_MAKE_SLOT, _t_33);
      }
      r0 = _depth_21;
      r1 = 90ull;
      WL_JMP(FID_MAKE_SLOT);
    } else {
      term_sink(e, _h_252);
      term_sink(e, _o_415);
      term_sink(e, _o_416);
      term_sink(e, _o_417);
      term_sink(e, _o_418);
      term_sink(e, _o_419);
      term_sink(e, _o_420);
      term_sink(e, _o_424);
      r0 = term_ctr(CID_SCON, STAT_OFF + 84);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K961)
  {
    WL_POPN(19);
    Term _depth_22 = STK(0);
    u32 _o_428 = STK(1);
    u32 _o_429 = STK(2);
    Term _h_262 = STK(3);
    u32 _o_430 = STK(4);
    u32 _o_431 = STK(5);
    u32 _o_432 = STK(6);
    u32 _o_433 = STK(7);
    Term _o_434 = STK(8);
    Term _o_435 = STK(9);
    Term _o_436 = STK(10);
    Term _o_437 = STK(11);
    Term _o_438 = STK(12);
    Term _o_439 = STK(13);
    u32 _o_440 = STK(14);
    Term _o_441 = STK(15);
    u32 _o_442 = STK(16);
    Term _o_443 = STK(17);
    u32 _o_444 = STK(18);
    Term _h_253 = r0;
    u32 _h_254 = r1;
    u32 _h_255 = r2;
    u32 _h_256 = r3;
    u32 _h_257 = r4;
    u32 _h_258 = r5;
    u32 _h_259 = r6;
    u32 _h_260 = r7;
    u32 _h_261 = r8;
    WL_OPEN
    u32 _o_445 = 0;
    Term _o_446 = 0;
    if (_o_444 == 0) {
      _o_445 = 0;
    } else {
      _o_445 = 1;
      _o_446 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_9 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_9 + 0] = rfc_seal(e, _h_253);
    e.mem[_nd_9 + 1] = rfc_seal(e, _h_254);
    e.mem[_nd_9 + 2] = rfc_seal(e, _h_255);
    e.mem[_nd_9 + 3] = rfc_seal(e, _h_256);
    e.mem[_nd_9 + 4] = rfc_seal(e, _h_257);
    e.mem[_nd_9 + 5] = rfc_seal(e, _h_258);
    e.mem[_nd_9 + 6] = rfc_seal(e, _h_259);
    e.mem[_nd_9 + 7] = rfc_seal(e, _h_260);
    e.mem[_nd_9 + 8] = rfc_seal(e, _h_261);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _depth_22;
      STK(1) = _o_428;
      STK(2) = _o_429;
      STK(3) = _h_262;
      STK(4) = FID_ONE_K962;
      WL_PUSHN(5);
    } else {
      u64 _t_34 = task_node(e, FID_ONE_K962, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _depth_22;
      e.mem[_t_34 + 1] = _o_428;
      e.mem[_t_34 + 2] = _o_429;
      e.mem[_t_34 + 3] = _h_262;
      WL_CONT = term_tsk(FID_ONE_K962, _t_34);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_MAIN)) {
      u64 _t_35 = task_node(e, FID_COMMANDS_INSERT_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _o_432;
      e.mem[_t_35 + 1] = _o_433;
      e.mem[_t_35 + 2] = _o_434;
      e.mem[_t_35 + 3] = _o_435;
      e.mem[_t_35 + 4] = _o_436;
      e.mem[_t_35 + 5] = _o_437;
      e.mem[_t_35 + 6] = _o_438;
      e.mem[_t_35 + 7] = _o_439;
      e.mem[_t_35 + 8] = _o_440;
      e.mem[_t_35 + 9] = _o_441;
      e.mem[_t_35 + 10] = _o_442;
      e.mem[_t_35 + 11] = _o_443;
      e.mem[_t_35 + 12] = _o_445;
      e.mem[_t_35 + 13] = _o_446;
      e.mem[_t_35 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_35 + 15] = _o_430;
      e.mem[_t_35 + 16] = _o_431;
      e.mem[_t_35 + 17] = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_9);
      return term_tsk(FID_COMMANDS_INSERT_MAIN, _t_35);
    }
    r0 = _o_432;
    r1 = _o_433;
    r2 = _o_434;
    r3 = _o_435;
    r4 = _o_436;
    r5 = _o_437;
    r6 = _o_438;
    r7 = _o_439;
    r8 = _o_440;
    r9 = _o_441;
    r10 = _o_442;
    r11 = _o_443;
    r12 = _o_445;
    r13 = _o_446;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_430;
    r16 = _o_431;
    r17 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_9);
    WL_JMP(FID_COMMANDS_INSERT_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K962)
  {
    WL_POPN(4);
    Term _depth_23 = STK(0);
    u32 _o_447 = STK(1);
    u32 _o_448 = STK(2);
    Term _h_280 = STK(3);
    u32 _h_263 = r0;
    u32 _h_264 = r1;
    u32 _h_265 = r2;
    Term _h_266 = r3;
    Term _h_267 = r4;
    Term _h_268 = r5;
    Term _h_269 = r6;
    Term _h_270 = r7;
    Term _h_271 = r8;
    u32 _h_272 = r9;
    Term _h_273 = r10;
    u32 _h_274 = r11;
    Term _h_275 = r12;
    u32 _h_276 = r13;
    Term _h_277 = r14;
    Term _h_278 = r15;
    Term _h_279 = r16;
    WL_OPEN
    u32 _o_449 = 0;
    u32 _o_450 = 0;
    u32 _o_451 = 0;
    Term _o_452 = 0;
    Term _o_453 = 0;
    Term _o_454 = 0;
    Term _o_455 = 0;
    Term _o_456 = 0;
    Term _o_457 = 0;
    u32 _o_458 = 0;
    Term _o_459 = 0;
    u32 _o_460 = 0;
    Term _o_461 = 0;
    u32 _o_462 = 0;
    Term _o_463 = 0;
    u32 _o_464 = 0;
    u32 _o_465 = 0;
    u32 _o_466 = 0;
    u32 _o_467 = 0;
    u32 _o_468 = 0;
    u32 _o_469 = 0;
    u32 _o_470 = 0;
    u32 _o_471 = 0;
    if (_h_263 == 0) {
      _o_449 = 0;
      u32 _o_472 = 0;
      if (_h_276 == 0) {
        _o_472 = 0;
      } else {
        _o_472 = 1;
      }
      _o_450 = _h_264;
      _o_451 = _h_265;
      _o_452 = _h_266;
      _o_453 = _h_267;
      _o_454 = _h_268;
      _o_455 = _h_269;
      _o_456 = _h_270;
      _o_457 = _h_271;
      _o_458 = _h_272;
      _o_459 = _h_273;
      _o_460 = _h_274;
      _o_461 = _h_275;
      _o_462 = _o_472;
    } else {
      _o_449 = 1;
      u32 _o_473 = 0;
      if (_h_276 == 0) {
        _o_473 = 0;
      } else {
        _o_473 = 1;
      }
      Term _fb_10[9];
      u64 _sp_10 = ctr_take(e, _h_279, 9, _fb_10);
      Term _f_132 = _fb_10[0];
      u32 _f_133 = _fb_10[1];
      u32 _f_134 = _fb_10[2];
      u32 _f_135 = _fb_10[3];
      u32 _f_136 = _fb_10[4];
      u32 _f_137 = _fb_10[5];
      u32 _f_138 = _fb_10[6];
      u32 _f_139 = _fb_10[7];
      u32 _f_140 = _fb_10[8];
      spare_free(e, cls_fit(9), _sp_10);
      _o_450 = _h_264;
      _o_451 = _h_265;
      _o_452 = _h_266;
      _o_453 = _h_267;
      _o_454 = _h_268;
      _o_455 = _h_269;
      _o_456 = _h_270;
      _o_457 = _h_271;
      _o_458 = _h_272;
      _o_459 = _h_273;
      _o_460 = _h_274;
      _o_461 = _h_275;
      _o_462 = _o_473;
      _o_463 = _f_132;
      _o_464 = _f_133;
      _o_465 = _f_134;
      _o_466 = _f_135;
      _o_467 = _f_136;
      _o_468 = _f_137;
      _o_469 = _f_138;
      _o_470 = _f_139;
      _o_471 = _f_140;
    }
    if (_o_449 == 1) {
      if (seq) {
        WL_ROOM(18);
        STK(0) = _depth_23;
        STK(1) = _o_447;
        STK(2) = _o_448;
        STK(3) = _h_280;
        STK(4) = _o_450;
        STK(5) = _o_451;
        STK(6) = _o_452;
        STK(7) = _o_453;
        STK(8) = _o_454;
        STK(9) = _o_455;
        STK(10) = _o_456;
        STK(11) = _o_457;
        STK(12) = _o_458;
        STK(13) = _o_459;
        STK(14) = _o_460;
        STK(15) = _o_461;
        STK(16) = _o_462;
        STK(17) = FID_ONE_K963;
        WL_PUSHN(18);
      } else {
        u64 _t_36 = task_node(e, FID_ONE_K963, WL_CONT, WL_IDX, 1);
        e.mem[_t_36 + 0] = _depth_23;
        e.mem[_t_36 + 1] = _o_447;
        e.mem[_t_36 + 2] = _o_448;
        e.mem[_t_36 + 3] = _h_280;
        e.mem[_t_36 + 4] = _o_450;
        e.mem[_t_36 + 5] = _o_451;
        e.mem[_t_36 + 6] = _o_452;
        e.mem[_t_36 + 7] = _o_453;
        e.mem[_t_36 + 8] = _o_454;
        e.mem[_t_36 + 9] = _o_455;
        e.mem[_t_36 + 10] = _o_456;
        e.mem[_t_36 + 11] = _o_457;
        e.mem[_t_36 + 12] = _o_458;
        e.mem[_t_36 + 13] = _o_459;
        e.mem[_t_36 + 14] = _o_460;
        e.mem[_t_36 + 15] = _o_461;
        e.mem[_t_36 + 16] = _o_462;
        WL_CONT = term_tsk(FID_ONE_K963, _t_36);
        WL_IDX = 17;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SLOT_TEXT)) {
        u64 _t_37 = task_node(e, FID_SLOT_TEXT, WL_CONT, WL_IDX, 0);
        e.mem[_t_37 + 0] = _depth_23;
        e.mem[_t_37 + 1] = _o_463;
        e.mem[_t_37 + 2] = _o_464;
        e.mem[_t_37 + 3] = _o_465;
        e.mem[_t_37 + 4] = _o_466;
        e.mem[_t_37 + 5] = _o_467;
        e.mem[_t_37 + 6] = _o_468;
        e.mem[_t_37 + 7] = _o_469;
        e.mem[_t_37 + 8] = _o_470;
        e.mem[_t_37 + 9] = _o_471;
        return term_tsk(FID_SLOT_TEXT, _t_37);
      }
      r0 = _depth_23;
      r1 = _o_463;
      r2 = _o_464;
      r3 = _o_465;
      r4 = _o_466;
      r5 = _o_467;
      r6 = _o_468;
      r7 = _o_469;
      r8 = _o_470;
      r9 = _o_471;
      WL_JMP(FID_SLOT_TEXT);
    } else {
      term_sink(e, _h_280);
      term_sink(e, _o_452);
      term_sink(e, _o_453);
      term_sink(e, _o_454);
      term_sink(e, _o_455);
      term_sink(e, _o_456);
      term_sink(e, _o_457);
      term_sink(e, _o_461);
      r0 = term_ctr(CID_SCON, STAT_OFF + 84);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K963)
  {
    WL_POPN(17);
    Term _depth_24 = STK(0);
    u32 _o_474 = STK(1);
    u32 _o_475 = STK(2);
    Term _h_291 = STK(3);
    u32 _o_476 = STK(4);
    u32 _o_477 = STK(5);
    Term _o_478 = STK(6);
    Term _o_479 = STK(7);
    Term _o_480 = STK(8);
    Term _o_481 = STK(9);
    Term _o_482 = STK(10);
    Term _o_483 = STK(11);
    u32 _o_484 = STK(12);
    Term _o_485 = STK(13);
    u32 _o_486 = STK(14);
    Term _o_487 = STK(15);
    u32 _o_488 = STK(16);
    Term _h_281 = r0;
    u32 _h_282 = r1;
    u32 _h_283 = r2;
    u32 _h_284 = r3;
    u32 _h_285 = r4;
    u32 _h_286 = r5;
    u32 _h_287 = r6;
    u32 _h_288 = r7;
    u32 _h_289 = r8;
    Term _h_290 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _depth_24;
      STK(1) = _o_474;
      STK(2) = _o_475;
      STK(3) = _h_291;
      STK(4) = _h_281;
      STK(5) = _h_282;
      STK(6) = _h_283;
      STK(7) = _h_284;
      STK(8) = _h_285;
      STK(9) = _h_286;
      STK(10) = _h_287;
      STK(11) = _h_288;
      STK(12) = _h_289;
      STK(13) = _h_290;
      STK(14) = FID_ONE_K964;
      WL_PUSHN(15);
    } else {
      u64 _t_38 = task_node(e, FID_ONE_K964, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _depth_24;
      e.mem[_t_38 + 1] = _o_474;
      e.mem[_t_38 + 2] = _o_475;
      e.mem[_t_38 + 3] = _h_291;
      e.mem[_t_38 + 4] = _h_281;
      e.mem[_t_38 + 5] = _h_282;
      e.mem[_t_38 + 6] = _h_283;
      e.mem[_t_38 + 7] = _h_284;
      e.mem[_t_38 + 8] = _h_285;
      e.mem[_t_38 + 9] = _h_286;
      e.mem[_t_38 + 10] = _h_287;
      e.mem[_t_38 + 11] = _h_288;
      e.mem[_t_38 + 12] = _h_289;
      e.mem[_t_38 + 13] = _h_290;
      WL_CONT = term_tsk(FID_ONE_K964, _t_38);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_39 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _depth_24;
      e.mem[_t_39 + 1] = _o_476;
      e.mem[_t_39 + 2] = _o_477;
      e.mem[_t_39 + 3] = _o_478;
      e.mem[_t_39 + 4] = _o_479;
      e.mem[_t_39 + 5] = _o_480;
      e.mem[_t_39 + 6] = _o_481;
      e.mem[_t_39 + 7] = _o_482;
      e.mem[_t_39 + 8] = _o_483;
      e.mem[_t_39 + 9] = _o_484;
      e.mem[_t_39 + 10] = _o_485;
      e.mem[_t_39 + 11] = _o_486;
      e.mem[_t_39 + 12] = _o_487;
      e.mem[_t_39 + 13] = _o_488;
      return term_tsk(FID_SNAPSHOT, _t_39);
    }
    r0 = _depth_24;
    r1 = _o_476;
    r2 = _o_477;
    r3 = _o_478;
    r4 = _o_479;
    r5 = _o_480;
    r6 = _o_481;
    r7 = _o_482;
    r8 = _o_483;
    r9 = _o_484;
    r10 = _o_485;
    r11 = _o_486;
    r12 = _o_487;
    r13 = _o_488;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K964)
  {
    WL_POPN(14);
    Term _depth_25 = STK(0);
    u32 _o_489 = STK(1);
    u32 _o_490 = STK(2);
    Term _h_306 = STK(3);
    Term _h_307 = STK(4);
    u32 _h_308 = STK(5);
    u32 _h_309 = STK(6);
    u32 _h_310 = STK(7);
    u32 _h_311 = STK(8);
    u32 _h_312 = STK(9);
    u32 _h_313 = STK(10);
    u32 _h_314 = STK(11);
    u32 _h_315 = STK(12);
    Term _h_316 = STK(13);
    u32 _h_292 = r0;
    u32 _h_293 = r1;
    Term _h_294 = r2;
    Term _h_295 = r3;
    Term _h_296 = r4;
    Term _h_297 = r5;
    Term _h_298 = r6;
    Term _h_299 = r7;
    u32 _h_300 = r8;
    Term _h_301 = r9;
    u32 _h_302 = r10;
    Term _h_303 = r11;
    u32 _h_304 = r12;
    Term _h_305 = r13;
    WL_OPEN
    term_sink(e, _h_307);
    _h_305 = term_keep(e, _h_305, 1);
    if (seq) {
      WL_ROOM(19);
      STK(0) = _depth_25;
      STK(1) = _o_489;
      STK(2) = _o_490;
      STK(3) = _h_316;
      STK(4) = _h_292;
      STK(5) = _h_293;
      STK(6) = _h_294;
      STK(7) = _h_295;
      STK(8) = _h_296;
      STK(9) = _h_297;
      STK(10) = _h_298;
      STK(11) = _h_299;
      STK(12) = _h_300;
      STK(13) = _h_301;
      STK(14) = _h_302;
      STK(15) = _h_303;
      STK(16) = _h_304;
      STK(17) = _h_305;
      STK(18) = FID_ONE_K965;
      WL_PUSHN(19);
    } else {
      u64 _t_40 = task_node(e, FID_ONE_K965, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _depth_25;
      e.mem[_t_40 + 1] = _o_489;
      e.mem[_t_40 + 2] = _o_490;
      e.mem[_t_40 + 3] = _h_316;
      e.mem[_t_40 + 4] = _h_292;
      e.mem[_t_40 + 5] = _h_293;
      e.mem[_t_40 + 6] = _h_294;
      e.mem[_t_40 + 7] = _h_295;
      e.mem[_t_40 + 8] = _h_296;
      e.mem[_t_40 + 9] = _h_297;
      e.mem[_t_40 + 10] = _h_298;
      e.mem[_t_40 + 11] = _h_299;
      e.mem[_t_40 + 12] = _h_300;
      e.mem[_t_40 + 13] = _h_301;
      e.mem[_t_40 + 14] = _h_302;
      e.mem[_t_40 + 15] = _h_303;
      e.mem[_t_40 + 16] = _h_304;
      e.mem[_t_40 + 17] = _h_305;
      WL_CONT = term_tsk(FID_ONE_K965, _t_40);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_41 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = _h_306;
      e.mem[_t_41 + 1] = _h_305;
      return term_tsk(FID_STRING_EQ, _t_41);
    }
    r0 = _h_306;
    r1 = _h_305;
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K965)
  {
    WL_POPN(18);
    Term _depth_26 = STK(0);
    u32 _o_491 = STK(1);
    u32 _o_492 = STK(2);
    Term _h_318 = STK(3);
    u32 _h_319 = STK(4);
    u32 _h_320 = STK(5);
    Term _h_321 = STK(6);
    Term _h_322 = STK(7);
    Term _h_323 = STK(8);
    Term _h_324 = STK(9);
    Term _h_325 = STK(10);
    Term _h_326 = STK(11);
    u32 _h_327 = STK(12);
    Term _h_328 = STK(13);
    u32 _h_329 = STK(14);
    Term _h_330 = STK(15);
    u32 _h_331 = STK(16);
    Term _h_332 = STK(17);
    u32 _h_317 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _depth_26;
      STK(1) = _o_491;
      STK(2) = _o_492;
      STK(3) = _h_318;
      STK(4) = _h_319;
      STK(5) = _h_320;
      STK(6) = _h_321;
      STK(7) = _h_322;
      STK(8) = _h_323;
      STK(9) = _h_324;
      STK(10) = _h_325;
      STK(11) = _h_326;
      STK(12) = _h_327;
      STK(13) = _h_328;
      STK(14) = _h_329;
      STK(15) = _h_330;
      STK(16) = _h_331;
      STK(17) = _h_317;
      STK(18) = FID_ONE_K966;
      WL_PUSHN(19);
    } else {
      u64 _t_42 = task_node(e, FID_ONE_K966, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _depth_26;
      e.mem[_t_42 + 1] = _o_491;
      e.mem[_t_42 + 2] = _o_492;
      e.mem[_t_42 + 3] = _h_318;
      e.mem[_t_42 + 4] = _h_319;
      e.mem[_t_42 + 5] = _h_320;
      e.mem[_t_42 + 6] = _h_321;
      e.mem[_t_42 + 7] = _h_322;
      e.mem[_t_42 + 8] = _h_323;
      e.mem[_t_42 + 9] = _h_324;
      e.mem[_t_42 + 10] = _h_325;
      e.mem[_t_42 + 11] = _h_326;
      e.mem[_t_42 + 12] = _h_327;
      e.mem[_t_42 + 13] = _h_328;
      e.mem[_t_42 + 14] = _h_329;
      e.mem[_t_42 + 15] = _h_330;
      e.mem[_t_42 + 16] = _h_331;
      e.mem[_t_42 + 17] = _h_317;
      WL_CONT = term_tsk(FID_ONE_K966, _t_42);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_43 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
      e.mem[_t_43 + 1] = _h_332;
      return term_tsk(FID_STRING_APPEND, _t_43);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 64);
    r1 = _h_332;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K966)
  {
    WL_POPN(18);
    Term _depth_27 = STK(0);
    u32 _o_493 = STK(1);
    u32 _o_494 = STK(2);
    Term _h_334 = STK(3);
    u32 _h_335 = STK(4);
    u32 _h_336 = STK(5);
    Term _h_337 = STK(6);
    Term _h_338 = STK(7);
    Term _h_339 = STK(8);
    Term _h_340 = STK(9);
    Term _h_341 = STK(10);
    Term _h_342 = STK(11);
    u32 _h_343 = STK(12);
    Term _h_344 = STK(13);
    u32 _h_345 = STK(14);
    Term _h_346 = STK(15);
    u32 _h_347 = STK(16);
    u32 _h_348 = STK(17);
    Term _h_333 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _depth_27;
      STK(1) = _o_493;
      STK(2) = _o_494;
      STK(3) = _h_335;
      STK(4) = _h_336;
      STK(5) = _h_337;
      STK(6) = _h_338;
      STK(7) = _h_339;
      STK(8) = _h_340;
      STK(9) = _h_341;
      STK(10) = _h_342;
      STK(11) = _h_343;
      STK(12) = _h_344;
      STK(13) = _h_345;
      STK(14) = _h_346;
      STK(15) = _h_347;
      STK(16) = _h_348;
      STK(17) = FID_ONE_K967;
      WL_PUSHN(18);
    } else {
      u64 _t_44 = task_node(e, FID_ONE_K967, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _depth_27;
      e.mem[_t_44 + 1] = _o_493;
      e.mem[_t_44 + 2] = _o_494;
      e.mem[_t_44 + 3] = _h_335;
      e.mem[_t_44 + 4] = _h_336;
      e.mem[_t_44 + 5] = _h_337;
      e.mem[_t_44 + 6] = _h_338;
      e.mem[_t_44 + 7] = _h_339;
      e.mem[_t_44 + 8] = _h_340;
      e.mem[_t_44 + 9] = _h_341;
      e.mem[_t_44 + 10] = _h_342;
      e.mem[_t_44 + 11] = _h_343;
      e.mem[_t_44 + 12] = _h_344;
      e.mem[_t_44 + 13] = _h_345;
      e.mem[_t_44 + 14] = _h_346;
      e.mem[_t_44 + 15] = _h_347;
      e.mem[_t_44 + 16] = _h_348;
      WL_CONT = term_tsk(FID_ONE_K967, _t_44);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_45 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _h_334;
      e.mem[_t_45 + 1] = _h_333;
      return term_tsk(FID_STRING_APPEND, _t_45);
    }
    r0 = _h_334;
    r1 = _h_333;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K967)
  {
    WL_POPN(17);
    Term _depth_28 = STK(0);
    u32 _o_495 = STK(1);
    u32 _o_496 = STK(2);
    u32 _h_350 = STK(3);
    u32 _h_351 = STK(4);
    Term _h_352 = STK(5);
    Term _h_353 = STK(6);
    Term _h_354 = STK(7);
    Term _h_355 = STK(8);
    Term _h_356 = STK(9);
    Term _h_357 = STK(10);
    u32 _h_358 = STK(11);
    Term _h_359 = STK(12);
    u32 _h_360 = STK(13);
    Term _h_361 = STK(14);
    u32 _h_362 = STK(15);
    u32 _h_363 = STK(16);
    Term _h_349 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _depth_28;
      STK(1) = _o_495;
      STK(2) = _o_496;
      STK(3) = _h_350;
      STK(4) = _h_351;
      STK(5) = _h_352;
      STK(6) = _h_353;
      STK(7) = _h_354;
      STK(8) = _h_355;
      STK(9) = _h_356;
      STK(10) = _h_357;
      STK(11) = _h_358;
      STK(12) = _h_359;
      STK(13) = _h_360;
      STK(14) = _h_361;
      STK(15) = _h_362;
      STK(16) = _h_363;
      STK(17) = FID_ONE_K968;
      WL_PUSHN(18);
    } else {
      u64 _t_46 = task_node(e, FID_ONE_K968, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _depth_28;
      e.mem[_t_46 + 1] = _o_495;
      e.mem[_t_46 + 2] = _o_496;
      e.mem[_t_46 + 3] = _h_350;
      e.mem[_t_46 + 4] = _h_351;
      e.mem[_t_46 + 5] = _h_352;
      e.mem[_t_46 + 6] = _h_353;
      e.mem[_t_46 + 7] = _h_354;
      e.mem[_t_46 + 8] = _h_355;
      e.mem[_t_46 + 9] = _h_356;
      e.mem[_t_46 + 10] = _h_357;
      e.mem[_t_46 + 11] = _h_358;
      e.mem[_t_46 + 12] = _h_359;
      e.mem[_t_46 + 13] = _h_360;
      e.mem[_t_46 + 14] = _h_361;
      e.mem[_t_46 + 15] = _h_362;
      e.mem[_t_46 + 16] = _h_363;
      WL_CONT = term_tsk(FID_ONE_K968, _t_46);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 64);
      e.mem[_t_47 + 1] = _h_349;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 64);
    r1 = _h_349;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K968)
  {
    WL_POPN(17);
    Term _depth_29 = STK(0);
    u32 _o_497 = STK(1);
    u32 _o_498 = STK(2);
    u32 _h_365 = STK(3);
    u32 _h_366 = STK(4);
    Term _h_367 = STK(5);
    Term _h_368 = STK(6);
    Term _h_369 = STK(7);
    Term _h_370 = STK(8);
    Term _h_371 = STK(9);
    Term _h_372 = STK(10);
    u32 _h_373 = STK(11);
    Term _h_374 = STK(12);
    u32 _h_375 = STK(13);
    Term _h_376 = STK(14);
    u32 _h_377 = STK(15);
    u32 _h_378 = STK(16);
    Term _h_364 = r0;
    WL_OPEN
    Term _v_220 = 0;
    Term _v_221 = 0;
    Term _o_499[1];
    if (spin_4(e, _o_499, _h_378) == 0) {
      return 0;
    }
    _v_221 = _o_499[0];
    _v_220 = _v_221;
    if (seq) {
      WL_ROOM(17);
      STK(0) = _depth_29;
      STK(1) = _o_497;
      STK(2) = _o_498;
      STK(3) = _h_365;
      STK(4) = _h_366;
      STK(5) = _h_367;
      STK(6) = _h_368;
      STK(7) = _h_369;
      STK(8) = _h_370;
      STK(9) = _h_371;
      STK(10) = _h_372;
      STK(11) = _h_373;
      STK(12) = _h_374;
      STK(13) = _h_375;
      STK(14) = _h_376;
      STK(15) = _h_377;
      STK(16) = FID_ONE_K969;
      WL_PUSHN(17);
    } else {
      u64 _t_48 = task_node(e, FID_ONE_K969, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _depth_29;
      e.mem[_t_48 + 1] = _o_497;
      e.mem[_t_48 + 2] = _o_498;
      e.mem[_t_48 + 3] = _h_365;
      e.mem[_t_48 + 4] = _h_366;
      e.mem[_t_48 + 5] = _h_367;
      e.mem[_t_48 + 6] = _h_368;
      e.mem[_t_48 + 7] = _h_369;
      e.mem[_t_48 + 8] = _h_370;
      e.mem[_t_48 + 9] = _h_371;
      e.mem[_t_48 + 10] = _h_372;
      e.mem[_t_48 + 11] = _h_373;
      e.mem[_t_48 + 12] = _h_374;
      e.mem[_t_48 + 13] = _h_375;
      e.mem[_t_48 + 14] = _h_376;
      e.mem[_t_48 + 15] = _h_377;
      WL_CONT = term_tsk(FID_ONE_K969, _t_48);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = _v_220;
      e.mem[_t_49 + 1] = _h_364;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = _v_220;
    r1 = _h_364;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K969)
  {
    WL_POPN(16);
    Term _depth_30 = STK(0);
    u32 _o_500 = STK(1);
    u32 _o_501 = STK(2);
    u32 _h_380 = STK(3);
    u32 _h_381 = STK(4);
    Term _h_382 = STK(5);
    Term _h_383 = STK(6);
    Term _h_384 = STK(7);
    Term _h_385 = STK(8);
    Term _h_386 = STK(9);
    Term _h_387 = STK(10);
    u32 _h_388 = STK(11);
    Term _h_389 = STK(12);
    u32 _h_390 = STK(13);
    Term _h_391 = STK(14);
    u32 _h_392 = STK(15);
    Term _h_379 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _depth_30;
      STK(1) = _o_500;
      STK(2) = _o_501;
      STK(3) = _h_379;
      STK(4) = _h_380;
      STK(5) = _h_381;
      STK(6) = _h_382;
      STK(7) = _h_383;
      STK(8) = _h_384;
      STK(9) = _h_385;
      STK(10) = _h_386;
      STK(11) = _h_387;
      STK(12) = _h_388;
      STK(13) = _h_389;
      STK(14) = _h_390;
      STK(15) = _h_391;
      STK(16) = _h_392;
      STK(17) = FID_ONE_K970;
      WL_PUSHN(18);
    } else {
      u64 _t_50 = task_node(e, FID_ONE_K970, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _depth_30;
      e.mem[_t_50 + 1] = _o_500;
      e.mem[_t_50 + 2] = _o_501;
      e.mem[_t_50 + 3] = _h_379;
      e.mem[_t_50 + 4] = _h_380;
      e.mem[_t_50 + 5] = _h_381;
      e.mem[_t_50 + 6] = _h_382;
      e.mem[_t_50 + 7] = _h_383;
      e.mem[_t_50 + 8] = _h_384;
      e.mem[_t_50 + 9] = _h_385;
      e.mem[_t_50 + 10] = _h_386;
      e.mem[_t_50 + 11] = _h_387;
      e.mem[_t_50 + 12] = _h_388;
      e.mem[_t_50 + 13] = _h_389;
      e.mem[_t_50 + 14] = _h_390;
      e.mem[_t_50 + 15] = _h_391;
      e.mem[_t_50 + 16] = _h_392;
      WL_CONT = term_tsk(FID_ONE_K970, _t_50);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MAKE_SLOT)) {
      u64 _t_51 = task_node(e, FID_MAKE_SLOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _depth_30;
      e.mem[_t_51 + 1] = 70ull;
      return term_tsk(FID_MAKE_SLOT, _t_51);
    }
    r0 = _depth_30;
    r1 = 70ull;
    WL_JMP(FID_MAKE_SLOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K970)
  {
    WL_POPN(17);
    Term _depth_31 = STK(0);
    u32 _o_502 = STK(1);
    u32 _o_503 = STK(2);
    Term _h_402 = STK(3);
    u32 _h_403 = STK(4);
    u32 _h_404 = STK(5);
    Term _h_405 = STK(6);
    Term _h_406 = STK(7);
    Term _h_407 = STK(8);
    Term _h_408 = STK(9);
    Term _h_409 = STK(10);
    Term _h_410 = STK(11);
    u32 _h_411 = STK(12);
    Term _h_412 = STK(13);
    u32 _h_413 = STK(14);
    Term _h_414 = STK(15);
    u32 _h_415 = STK(16);
    Term _h_393 = r0;
    u32 _h_394 = r1;
    u32 _h_395 = r2;
    u32 _h_396 = r3;
    u32 _h_397 = r4;
    u32 _h_398 = r5;
    u32 _h_399 = r6;
    u32 _h_400 = r7;
    u32 _h_401 = r8;
    WL_OPEN
    u32 _o_504 = 0;
    Term _o_505 = 0;
    if (_h_415 == 0) {
      _o_504 = 0;
    } else {
      _o_504 = 1;
      _o_505 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_10 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_10 + 0] = rfc_seal(e, _h_393);
    e.mem[_nd_10 + 1] = rfc_seal(e, _h_394);
    e.mem[_nd_10 + 2] = rfc_seal(e, _h_395);
    e.mem[_nd_10 + 3] = rfc_seal(e, _h_396);
    e.mem[_nd_10 + 4] = rfc_seal(e, _h_397);
    e.mem[_nd_10 + 5] = rfc_seal(e, _h_398);
    e.mem[_nd_10 + 6] = rfc_seal(e, _h_399);
    e.mem[_nd_10 + 7] = rfc_seal(e, _h_400);
    e.mem[_nd_10 + 8] = rfc_seal(e, _h_401);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _depth_31;
      STK(1) = _h_402;
      STK(2) = FID_ONE_K971;
      WL_PUSHN(3);
    } else {
      u64 _t_52 = task_node(e, FID_ONE_K971, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _depth_31;
      e.mem[_t_52 + 1] = _h_402;
      WL_CONT = term_tsk(FID_ONE_K971, _t_52);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_COMMANDS_INSERT_MAIN)) {
      u64 _t_53 = task_node(e, FID_COMMANDS_INSERT_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = _h_403;
      e.mem[_t_53 + 1] = _h_404;
      e.mem[_t_53 + 2] = _h_405;
      e.mem[_t_53 + 3] = _h_406;
      e.mem[_t_53 + 4] = _h_407;
      e.mem[_t_53 + 5] = _h_408;
      e.mem[_t_53 + 6] = _h_409;
      e.mem[_t_53 + 7] = _h_410;
      e.mem[_t_53 + 8] = _h_411;
      e.mem[_t_53 + 9] = _h_412;
      e.mem[_t_53 + 10] = _h_413;
      e.mem[_t_53 + 11] = _h_414;
      e.mem[_t_53 + 12] = _o_504;
      e.mem[_t_53 + 13] = _o_505;
      e.mem[_t_53 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_53 + 15] = _o_502;
      e.mem[_t_53 + 16] = _o_503;
      e.mem[_t_53 + 17] = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_10);
      return term_tsk(FID_COMMANDS_INSERT_MAIN, _t_53);
    }
    r0 = _h_403;
    r1 = _h_404;
    r2 = _h_405;
    r3 = _h_406;
    r4 = _h_407;
    r5 = _h_408;
    r6 = _h_409;
    r7 = _h_410;
    r8 = _h_411;
    r9 = _h_412;
    r10 = _h_413;
    r11 = _h_414;
    r12 = _o_504;
    r13 = _o_505;
    r14 = term_pak(CID_UNIT, 0);
    r15 = _o_502;
    r16 = _o_503;
    r17 = term_ctr(CID_CACHED_PAYLOAD_PROTOTYPEHEALTHMAINSLOT, _nd_10);
    WL_JMP(FID_COMMANDS_INSERT_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K971)
  {
    WL_POPN(2);
    Term _depth_32 = STK(0);
    Term _h_433 = STK(1);
    u32 _h_416 = r0;
    u32 _h_417 = r1;
    u32 _h_418 = r2;
    Term _h_419 = r3;
    Term _h_420 = r4;
    Term _h_421 = r5;
    Term _h_422 = r6;
    Term _h_423 = r7;
    Term _h_424 = r8;
    u32 _h_425 = r9;
    Term _h_426 = r10;
    u32 _h_427 = r11;
    Term _h_428 = r12;
    u32 _h_429 = r13;
    Term _h_430 = r14;
    Term _h_431 = r15;
    Term _h_432 = r16;
    WL_OPEN
    u32 _o_506 = 0;
    u32 _o_507 = 0;
    u32 _o_508 = 0;
    Term _o_509 = 0;
    Term _o_510 = 0;
    Term _o_511 = 0;
    Term _o_512 = 0;
    Term _o_513 = 0;
    Term _o_514 = 0;
    u32 _o_515 = 0;
    Term _o_516 = 0;
    u32 _o_517 = 0;
    Term _o_518 = 0;
    u32 _o_519 = 0;
    Term _o_520 = 0;
    u32 _o_521 = 0;
    u32 _o_522 = 0;
    u32 _o_523 = 0;
    u32 _o_524 = 0;
    u32 _o_525 = 0;
    u32 _o_526 = 0;
    u32 _o_527 = 0;
    u32 _o_528 = 0;
    if (_h_416 == 0) {
      _o_506 = 0;
      u32 _o_529 = 0;
      if (_h_429 == 0) {
        _o_529 = 0;
      } else {
        _o_529 = 1;
      }
      _o_507 = _h_417;
      _o_508 = _h_418;
      _o_509 = _h_419;
      _o_510 = _h_420;
      _o_511 = _h_421;
      _o_512 = _h_422;
      _o_513 = _h_423;
      _o_514 = _h_424;
      _o_515 = _h_425;
      _o_516 = _h_426;
      _o_517 = _h_427;
      _o_518 = _h_428;
      _o_519 = _o_529;
    } else {
      _o_506 = 1;
      u32 _o_530 = 0;
      if (_h_429 == 0) {
        _o_530 = 0;
      } else {
        _o_530 = 1;
      }
      Term _fb_11[9];
      u64 _sp_11 = ctr_take(e, _h_432, 9, _fb_11);
      Term _f_141 = _fb_11[0];
      u32 _f_142 = _fb_11[1];
      u32 _f_143 = _fb_11[2];
      u32 _f_144 = _fb_11[3];
      u32 _f_145 = _fb_11[4];
      u32 _f_146 = _fb_11[5];
      u32 _f_147 = _fb_11[6];
      u32 _f_148 = _fb_11[7];
      u32 _f_149 = _fb_11[8];
      spare_free(e, cls_fit(9), _sp_11);
      _o_507 = _h_417;
      _o_508 = _h_418;
      _o_509 = _h_419;
      _o_510 = _h_420;
      _o_511 = _h_421;
      _o_512 = _h_422;
      _o_513 = _h_423;
      _o_514 = _h_424;
      _o_515 = _h_425;
      _o_516 = _h_426;
      _o_517 = _h_427;
      _o_518 = _h_428;
      _o_519 = _o_530;
      _o_520 = _f_141;
      _o_521 = _f_142;
      _o_522 = _f_143;
      _o_523 = _f_144;
      _o_524 = _f_145;
      _o_525 = _f_146;
      _o_526 = _f_147;
      _o_527 = _f_148;
      _o_528 = _f_149;
    }
    if (_o_506 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_433;
        STK(1) = FID_ONE_K972;
        WL_PUSHN(2);
      } else {
        u64 _t_54 = task_node(e, FID_ONE_K972, WL_CONT, WL_IDX, 1);
        e.mem[_t_54 + 0] = _h_433;
        WL_CONT = term_tsk(FID_ONE_K972, _t_54);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
        u64 _t_55 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_55 + 0] = _depth_32;
        e.mem[_t_55 + 1] = _o_507;
        e.mem[_t_55 + 2] = _o_508;
        e.mem[_t_55 + 3] = _o_509;
        e.mem[_t_55 + 4] = _o_510;
        e.mem[_t_55 + 5] = _o_511;
        e.mem[_t_55 + 6] = _o_512;
        e.mem[_t_55 + 7] = _o_513;
        e.mem[_t_55 + 8] = _o_514;
        e.mem[_t_55 + 9] = _o_515;
        e.mem[_t_55 + 10] = _o_516;
        e.mem[_t_55 + 11] = _o_517;
        e.mem[_t_55 + 12] = _o_518;
        e.mem[_t_55 + 13] = _o_519;
        return term_tsk(FID_SNAPSHOT, _t_55);
      }
      r0 = _depth_32;
      r1 = _o_507;
      r2 = _o_508;
      r3 = _o_509;
      r4 = _o_510;
      r5 = _o_511;
      r6 = _o_512;
      r7 = _o_513;
      r8 = _o_514;
      r9 = _o_515;
      r10 = _o_516;
      r11 = _o_517;
      r12 = _o_518;
      r13 = _o_519;
      WL_JMP(FID_SNAPSHOT);
    } else {
      term_sink(e, _h_433);
      term_sink(e, _o_509);
      term_sink(e, _o_510);
      term_sink(e, _o_511);
      term_sink(e, _o_512);
      term_sink(e, _o_513);
      term_sink(e, _o_514);
      term_sink(e, _o_518);
      term_sink(e, _o_520);
      r0 = term_ctr(CID_SCON, STAT_OFF + 46);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K972)
  {
    WL_POPN(1);
    Term _h_448 = STK(0);
    u32 _h_434 = r0;
    u32 _h_435 = r1;
    Term _h_436 = r2;
    Term _h_437 = r3;
    Term _h_438 = r4;
    Term _h_439 = r5;
    Term _h_440 = r6;
    Term _h_441 = r7;
    u32 _h_442 = r8;
    Term _h_443 = r9;
    u32 _h_444 = r10;
    Term _h_445 = r11;
    u32 _h_446 = r12;
    Term _h_447 = r13;
    WL_OPEN
    term_sink(e, _h_436);
    term_sink(e, _h_437);
    term_sink(e, _h_438);
    term_sink(e, _h_439);
    term_sink(e, _h_440);
    term_sink(e, _h_441);
    term_sink(e, _h_445);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_448;
      STK(1) = FID_ONE_K973;
      WL_PUSHN(2);
    } else {
      u64 _t_56 = task_node(e, FID_ONE_K973, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_448;
      WL_CONT = term_tsk(FID_ONE_K973, _t_56);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = term_ctr(CID_SCON, STAT_OFF + 12);
      e.mem[_t_57 + 1] = _h_447;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 12);
    r1 = _h_447;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ONE_K973)
  {
    WL_POPN(1);
    Term _h_450 = STK(0);
    Term _h_449 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_58 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_58 + 0] = _h_450;
      e.mem[_t_58 + 1] = _h_449;
      return term_tsk(FID_STRING_APPEND, _t_58);
    }
    r0 = _h_450;
    r1 = _h_449;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C975, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C975, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C975)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K976;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K976, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K976, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K976)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K978;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K978, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K978, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ONE)) {
      u64 _t_1 = task_node(e, FID_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 0;
      return term_tsk(FID_ONE, _t_1);
    }
    r0 = 0;
    WL_JMP(FID_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K978)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_0;
    r0 = term_clo(FID_MAIN_C979, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C979)
  {
    Term _h_1 = r0;
    Term _x_0 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_28 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_28 + 1] = term_clo(FID_MAIN_C980, 0);
      e.mem[_t_28 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_28);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_MAIN_C980, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C980)
  {
    Term _x_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K981;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K981, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K981, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ONE)) {
      u64 _t_3 = task_node(e, FID_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = 1ull;
      return term_tsk(FID_ONE, _t_3);
    }
    r0 = 1ull;
    WL_JMP(FID_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K981)
  {
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _h_2;
    r0 = term_clo(FID_MAIN_C982, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C982)
  {
    Term _h_3 = r0;
    Term _x_2 = r1;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = _h_3;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_27 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_clo(FID_IO_PRINT, _nd_3);
      e.mem[_t_27 + 1] = term_clo(FID_MAIN_C983, 0);
      e.mem[_t_27 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_27);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_3);
    r1 = term_clo(FID_MAIN_C983, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C983)
  {
    Term _x_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K984;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K984, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K984, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ONE)) {
      u64 _t_5 = task_node(e, FID_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = 2ull;
      return term_tsk(FID_ONE, _t_5);
    }
    r0 = 2ull;
    WL_JMP(FID_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K984)
  {
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = _h_4;
    r0 = term_clo(FID_MAIN_C985, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C985)
  {
    Term _h_5 = r0;
    Term _x_4 = r1;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_5 + 0] = _h_5;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_26 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_26 + 0] = term_clo(FID_IO_PRINT, _nd_5);
      e.mem[_t_26 + 1] = term_clo(FID_MAIN_C986, 0);
      e.mem[_t_26 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_26);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_5);
    r1 = term_clo(FID_MAIN_C986, 0);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C986)
  {
    Term _x_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K987;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K987, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K987, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ONE)) {
      u64 _t_7 = task_node(e, FID_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = 3ull;
      return term_tsk(FID_ONE, _t_7);
    }
    r0 = 3ull;
    WL_JMP(FID_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K987)
  {
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_6;
    r0 = term_clo(FID_MAIN_C988, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C988)
  {
    Term _h_7 = r0;
    Term _x_6 = r1;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_7 + 0] = _h_7;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_25 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_clo(FID_IO_PRINT, _nd_7);
      e.mem[_t_25 + 1] = term_clo(FID_MAIN_C989, 0);
      e.mem[_t_25 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_25);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_7);
    r1 = term_clo(FID_MAIN_C989, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C989)
  {
    Term _x_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K990;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K990, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K990, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ONE)) {
      u64 _t_9 = task_node(e, FID_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = 4ull;
      return term_tsk(FID_ONE, _t_9);
    }
    r0 = 4ull;
    WL_JMP(FID_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K990)
  {
    Term _h_8 = r0;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_8 + 0] = _h_8;
    r0 = term_clo(FID_MAIN_C991, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C991)
  {
    Term _h_9 = r0;
    Term _x_8 = r1;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_9 + 0] = _h_9;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_24 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_24 + 0] = term_clo(FID_IO_PRINT, _nd_9);
      e.mem[_t_24 + 1] = term_clo(FID_MAIN_C992, 0);
      e.mem[_t_24 + 2] = _x_8;
      return term_tsk(FID_IO_BIND, _t_24);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_9);
    r1 = term_clo(FID_MAIN_C992, 0);
    r2 = _x_8;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C992)
  {
    Term _x_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K993;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K993, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K993, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TX_ONE)) {
      u64 _t_11 = task_node(e, FID_TX_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = 0;
      return term_tsk(FID_TX_ONE, _t_11);
    }
    r0 = 0;
    WL_JMP(FID_TX_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K993)
  {
    Term _h_10 = r0;
    WL_OPEN
    u64 _nd_10 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_10 + 0] = _h_10;
    r0 = term_clo(FID_MAIN_C994, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C994)
  {
    Term _h_11 = r0;
    Term _x_10 = r1;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_11 + 0] = _h_11;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_23 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_clo(FID_IO_PRINT, _nd_11);
      e.mem[_t_23 + 1] = term_clo(FID_MAIN_C995, 0);
      e.mem[_t_23 + 2] = _x_10;
      return term_tsk(FID_IO_BIND, _t_23);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_11);
    r1 = term_clo(FID_MAIN_C995, 0);
    r2 = _x_10;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C995)
  {
    Term _x_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K996;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K996, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K996, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TX_ONE)) {
      u64 _t_13 = task_node(e, FID_TX_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = 1ull;
      return term_tsk(FID_TX_ONE, _t_13);
    }
    r0 = 1ull;
    WL_JMP(FID_TX_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K996)
  {
    Term _h_12 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_12 + 0] = _h_12;
    r0 = term_clo(FID_MAIN_C997, _nd_12);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C997)
  {
    Term _h_13 = r0;
    Term _x_12 = r1;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_13 + 0] = _h_13;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_22 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = term_clo(FID_IO_PRINT, _nd_13);
      e.mem[_t_22 + 1] = term_clo(FID_MAIN_C998, 0);
      e.mem[_t_22 + 2] = _x_12;
      return term_tsk(FID_IO_BIND, _t_22);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_13);
    r1 = term_clo(FID_MAIN_C998, 0);
    r2 = _x_12;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C998)
  {
    Term _x_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K999;
      WL_PUSHN(1);
    } else {
      u64 _t_14 = task_node(e, FID_MAIN_K999, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K999, _t_14);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TX_ONE)) {
      u64 _t_15 = task_node(e, FID_TX_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = 2ull;
      return term_tsk(FID_TX_ONE, _t_15);
    }
    r0 = 2ull;
    WL_JMP(FID_TX_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K999)
  {
    Term _h_14 = r0;
    WL_OPEN
    u64 _nd_14 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_14 + 0] = _h_14;
    r0 = term_clo(FID_MAIN_C1000, _nd_14);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C1000)
  {
    Term _h_15 = r0;
    Term _x_14 = r1;
    WL_OPEN
    u64 _nd_15 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_15 + 0] = _h_15;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_21 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_clo(FID_IO_PRINT, _nd_15);
      e.mem[_t_21 + 1] = term_clo(FID_MAIN_C1001, 0);
      e.mem[_t_21 + 2] = _x_14;
      return term_tsk(FID_IO_BIND, _t_21);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_15);
    r1 = term_clo(FID_MAIN_C1001, 0);
    r2 = _x_14;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C1001)
  {
    Term _x_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K1002;
      WL_PUSHN(1);
    } else {
      u64 _t_16 = task_node(e, FID_MAIN_K1002, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K1002, _t_16);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TX_ONE)) {
      u64 _t_17 = task_node(e, FID_TX_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = 3ull;
      return term_tsk(FID_TX_ONE, _t_17);
    }
    r0 = 3ull;
    WL_JMP(FID_TX_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K1002)
  {
    Term _h_16 = r0;
    WL_OPEN
    u64 _nd_16 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_16 + 0] = _h_16;
    r0 = term_clo(FID_MAIN_C1003, _nd_16);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C1003)
  {
    Term _h_17 = r0;
    Term _x_16 = r1;
    WL_OPEN
    u64 _nd_17 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_17 + 0] = _h_17;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_20 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = term_clo(FID_IO_PRINT, _nd_17);
      e.mem[_t_20 + 1] = term_clo(FID_MAIN_C1004, 0);
      e.mem[_t_20 + 2] = _x_16;
      return term_tsk(FID_IO_BIND, _t_20);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_17);
    r1 = term_clo(FID_MAIN_C1004, 0);
    r2 = _x_16;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C1004)
  {
    Term _x_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K1005;
      WL_PUSHN(1);
    } else {
      u64 _t_18 = task_node(e, FID_MAIN_K1005, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K1005, _t_18);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TX_ONE)) {
      u64 _t_19 = task_node(e, FID_TX_ONE, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = 4ull;
      return term_tsk(FID_TX_ONE, _t_19);
    }
    r0 = 4ull;
    WL_JMP(FID_TX_ONE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K1005)
  {
    Term _h_18 = r0;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_18 + 0] = _h_18;
    r0 = term_clo(FID_IO_PRINT, _nd_18);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_3 = r0;
    Term _k_3 = r1;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = _text_3;
    e.mem[_nd_3 + 1] = _k_3;
    r0 = term_ctr(CID_IO_PRINT, _nd_3);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
