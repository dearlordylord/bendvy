let __handoff_active=0; const __handoff_route={"drain":0,"ready":0,"flatfold":0,"get":0,"ledger":0,"set":0,"setledger":0,"invoke":0,"taken":0,"returned":0};
process.on("exit",()=>console.log("BENDVY_HANDOFF_ROUTE "+JSON.stringify(__handoff_route)));
const __pool_token_0 = Object.freeze({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.VitalsToken"});
const __pool_token_1 = Object.freeze({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthLedgerToken"});
function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($pair$(false, 0)), run_clo((_x_1) => {
  return $pair$(true, 0);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $pair$(_fail_0, _kind_0) {
  if (_kind_0 == 0) {
    return run_clo((_x_0) => {
  return $IO$bind$(($health_pre$(($reference$(($health_owner$(8)))))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($original_finish$(_fail_0, _x_1)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$bind$(($candidate_pre$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_flatfold_health$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.Required"}, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1263$(($health_owner$(8)))), 0)))), run_clo((_x_5) => {
  return $direct_finish$(_fail_0, _x_5);
}), _x_4);
});
}), _x_2);
});
}), _x_0);
});
  } else {
    return (_x_6) => $IO$print$("unexpected-fixture-kind", _x_6);
  }
}

function $health_pre$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  return $health_commands_done$({$: "HealthCarry", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "pings": _pings_0, "marks": _marks_0, "value": _value_0}, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_commands_0)));
}

function $reference$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return $legacy_next$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_each$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.Required"}, _world_0)));
}

function $health_owner$(_scenario_0) {
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": 7, "next": 3, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": array_node([($health_main$(_scenario_0))], [{$: "Some", "value": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_new$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Vitals", "levels": ($quad$(900)), "reserve": 9, "class": 2}))}]), "aux": array_node([{$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Armor", "layers": ($quad$(110)), "grade": 3}}], [{$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Armor", "layers": ($quad$(190)), "grade": 3}}]), "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": array_node([true], [($second_live$(_scenario_0))]), "flags": array_node([{$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Tracked", "group": 8}}], [{$: "None"}]), "added": array_node([3], [5]), "changed": array_node([4], [6])}, "capacity": 2, "depth": 1, "high_water": ($case_high$(_scenario_0))}, "pending": {$: "Nil"}, "ledger": ($health_ledger$(_scenario_0)), "mode": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthOn"}}, "selected": ($health_selected$(_scenario_0)), "undo": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.LedgerInverse", "old": 77}, "tail": {$: "Nil"}}, "commands": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.RemoveFlag", "id": 1}, "tail": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Despawn", "id": 2}, "tail": {$: "Nil"}}}, "pings": {$: "Con", "head": 12, "tail": {$: "Con", "head": 11, "tail": {$: "Nil"}}}, "marks": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 2}, "tail": {$: "Nil"}}};
}

function $original_finish$(_fail_0, _owner_0) {
  if (!_fail_0) {
    return $health_post$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_commit$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_finish_success$(_owner_0)), 9)));
  } else {
    return $health_post$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_commit$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_finish_failure$(_owner_0)), 9)));
  }
}

function $candidate_pre$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _total_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$((__direct_tuple_helper_0(({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_marks_0))}), (_total_0))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$({$: "Tuple", "fst": ($candidate_pre_done$(_undo_0, _marks_0, _x_1)), "snd": _total_0}, _x_2);
});
}), _x_0);
});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_flatfold_health$1260$(_selection_0, _owner_0, _total_0) {
__handoff_active++; try { __handoff_route.flatfold++;

  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _t_1 = _t_0["rows"];
  const _columns_0 = _t_1["main"];
  const _aux_0 = _t_1["aux"];
  const _metadata_0 = _t_1["metadata"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _high_0 = _t_1["high_water"];
  const _pending_0 = _t_0["pending"];
  const _t_2 = _t_0["ledger"];
  if (_t_2.$ === "None") {
    const _mode_0 = _t_0["mode"];
    const _selected_0 = _owner_0["selected"];
    const _undo_0 = _owner_0["undo"];
    const _commands_0 = _owner_0["commands"];
    const _pings_0 = _owner_0["pings"];
    const _marks_0 = _owner_0["marks"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_original$1260$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_each$1260$(_selection_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0})));
  } else {
    const _ledger_0 = _t_2["value"];
    const _mode_1 = _t_0["mode"];
    const _selected_1 = _owner_0["selected"];
    const _undo_1 = _owner_0["undo"];
    const _commands_1 = _owner_0["commands"];
    const _pings_1 = _owner_0["pings"];
    const _marks_1 = _owner_0["marks"];
    return __direct_tuple_helper_1(_selection_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_1, _selected_1, _undo_1, _commands_1, _pings_1, _marks_1, _total_0, (_columns_0), (_columns_0.length));
  }

} finally { __handoff_active--; }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1263$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1261$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_pack$1261$(_marks_0))};
}

function $direct_finish$(_fail_0, _result_0) {
  if (!_fail_0) {
    const _owner_0 = _result_0["fst"];
    return $health_post$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_commit$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_finish_success$1260$(_owner_0)), 9)));
  } else {
    const _owner_1 = _result_0["fst"];
    return $health_post$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_commit$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_finish_failure$1260$(_owner_1)), 9)));
  }
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $health_commands_done$(_carry_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _views_0 = _result_0["snd"];
  return $health_commands_context$(_commands_0, _views_0, _carry_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands_head$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058command$1260$(_head_0)), ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_tail_0)));
  }
}

function $legacy_next$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _cursor_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pair_unpack$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_cursor_flatfold_health$1260$(_cursor_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1263$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})), 0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_return$(_namespace_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_ids$1260$(_selection_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})));
}

function $health_main$(_scenario_0) {
  if (_scenario_0 == 4) {
    return {$: "None"};
  } else {
    return {$: "Some", "value": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_new$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Vitals", "levels": ($quad$(10)), "reserve": 9, "class": 2}))};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_new$(_raw_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_result$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058vitals_get$(_raw_0)));
}

function $quad$(_n_0) {
  const _x_0 = array_new(2, _n_0);
  const _x_1 = ((_n_0 + 1) >>> 0);
  const _x_2 = (_x_0[1 % _x_0.length] = _x_1, _x_0);
  const _x_3 = ((_n_0 + 2) >>> 0);
  const _x_4 = (_x_2[2 % _x_2.length] = _x_3, _x_2);
  const _x_5 = ((_n_0 + 3) >>> 0);
  return (_x_4[3 % _x_4.length] = _x_5, _x_4);
}

function $second_live$(_scenario_0) {
  if (_scenario_0 == 7) {
    return true;
  } else if ((_scenario_0 & 1) == 1) {
    return false;
  } else if (_scenario_0 == 8) {
    return true;
  } else {
    return false;
  }
}

function $case_high$(_scenario_0) {
  if (_scenario_0 == 7) {
    return 1;
  } else {
    return 2;
  }
}

function $health_ledger$(_scenario_0) {
  if (_scenario_0 == 5) {
    return {$: "None"};
  } else {
    return {$: "Some", "value": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_new$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthLedger", "totals": ($quad$(100)), "epoch": 4}))};
  }
}

function $health_selected$(_scenario_0) {
  if (_scenario_0 == 1) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 8, "id": 1};
  } else if ((_scenario_0 & 3) == 1) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 1};
  } else if (_scenario_0 == 3) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 3};
  } else if ((_scenario_0 & 7) == 3) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 1};
  } else if (_scenario_0 == 7) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 2};
  } else if ((_scenario_0 & 7) == 7) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 1};
  } else if (_scenario_0 == 2) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 0};
  } else if ((_scenario_0 & 7) == 2) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 1};
  } else if (_scenario_0 == 6) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 2};
  } else if ((_scenario_0 & 7) == 6) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 1};
  } else if (_scenario_0 == 8) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 2};
  } else {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": 7, "id": 1};
  }
}

function $health_post$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _pings_0 = _result_0["snd"];
  return $health_post_view$(_pings_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world$1260$(_world_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_commit$(_result_0, _tick_0) {
  if (_result_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Committed") {
    const _world_0 = _result_0["world"];
    const _commands_0 = _result_0["commands"];
    const _pings_0 = _result_0["pings"];
    const _marks_0 = _result_0["marks"];
    return {$: "Tuple", "fst": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058publish$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_mark_all$(_marks_0, _world_0, _tick_0)), ($List$reverse$(_commands_0)))), "snd": _pings_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_finish_success$(_t_0) {
  const _world_0 = _t_0["world"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Committed", "world": _world_0, "commands": ($List$reverse$(_commands_0)), "pings": ($List$reverse$(_pings_0)), "marks": _marks_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_finish_failure$(_t_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_finish_failure$1263$(_t_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_values_0) {
  if (_values_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatEnd") {
    return {$: "Nil"};
  } else if (_values_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMain") {
    const _space_0 = _values_0["namespace"];
    const _id_0 = _values_0["id"];
    const _old_0 = _values_0["old"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.MainInverse", "handle": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, "old": _old_0}, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_tail_0))};
  } else if (_values_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatLedger") {
    const _old_1 = _values_0["old"];
    const _tail_1 = _values_0["tail"];
    return {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.LedgerInverse", "old": _old_1}, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_tail_1))};
  } else {
    const _space_1 = _values_0["namespace"];
    const _id_1 = _values_0["id"];
    const _main_old_0 = _values_0["main_old"];
    const _ledger_old_0 = _values_0["ledger_old"];
    const _tail_2 = _values_0["tail"];
    return {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.LedgerInverse", "old": _ledger_old_0}, "tail": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.MainInverse", "handle": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_1, "id": _id_1}, "old": _main_old_0}, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_tail_2))}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_values_0) {
  if (_values_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd") {
    return {$: "Nil"};
  } else {
    const _space_0 = _values_0["namespace"];
    const _id_0 = _values_0["id"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_tail_0))};
  }
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $candidate_pre_done$(_undo_0, _marks_0, _owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_original$1260$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _cursor_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_cursor_flatfold_health$1260$(_cursor_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, _total_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_shape$1260$(_selection_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _result_0) {
  const _columns_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_shape_chosen$1260$(_selection_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, (_capacity_0 <= _size_0), {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatEnd"};
  } else {
    const _t_0 = _values_0["head"];
    if (_t_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.MainInverse") {
      const _t_1 = _t_0["handle"];
      const _space_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _old_0 = _t_0["old"];
      const _tail_0 = _values_0["tail"];
      return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMain", "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1261$(_tail_0))};
    } else {
      const _old_1 = _t_0["old"];
      const _tail_1 = _values_0["tail"];
      return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatLedger", "old": _old_1, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1261$(_tail_1))};
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_pack$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd"};
  } else {
    const _t_0 = _values_0["head"];
    const _space_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _tail_0 = _values_0["tail"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_pack$1261$(_tail_0))};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_commit$1260$(_result_0, _tick_0) {
  if (_result_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatCommitted") {
    const _world_0 = _result_0["world"];
    const _commands_0 = _result_0["commands"];
    const _pings_0 = _result_0["pings"];
    const _marks_0 = _result_0["marks"];
    return {$: "Tuple", "fst": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058publish$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_all$1260$(_marks_0, _world_0, _tick_0)), ($List$reverse$(_commands_0)))), "snd": _pings_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_finish_success$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatCommitted", "world": _world_0, "commands": ($List$reverse$(_commands_0)), "pings": ($List$reverse$(_pings_0)), "marks": _marks_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_finish_failure$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _undo_0 = _owner_0["undo"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatReverted", "world": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unwind$1260$(_undo_0, _world_0))};
}

function $health_commands_context$(_commands_0, _views_0, _carry_0) {
  const _world_0 = _carry_0["world"];
  const _selected_0 = _carry_0["selected"];
  const _undo_0 = _carry_0["undo"];
  const _pings_0 = _carry_0["pings"];
  const _marks_0 = _carry_0["marks"];
  const _value_0 = _carry_0["value"];
  return $health_view_done$({$: "HealthInspect", "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "value": _value_0, "views": _views_0}, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world$1260$(_world_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands_head$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _value_0 = _head_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands_tail$(_owner_0, _value_0, _tail_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058command$1260$(_owner_0) {
  if (_owner_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _owner_0["id"];
    const _value_0 = _owner_0["bundle"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058bundle$1260$(_value_0)));
  } else if (_owner_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _owner_0["id"];
    const _value_1 = _owner_0["main"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058command_main$(_id_1, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_get$(_value_1)));
  } else if (_owner_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.InsertFlag") {
    const _id_2 = _owner_0["id"];
    const _value_2 = _owner_0["flag"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.InsertFlag", "id": _id_2, "flag": _value_2}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.FlagView", "id": _id_2, "flag": _value_2}};
  } else if (_owner_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.RemoveMain") {
    const _id_3 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.RemoveMain", "id": _id_3}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.RemoveMainView", "id": _id_3}};
  } else if (_owner_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.RemoveFlag") {
    const _id_4 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.RemoveFlag", "id": _id_4}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.RemoveFlagView", "id": _id_4}};
  } else {
    const _id_5 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Despawn", "id": _id_5}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.DespawnView", "id": _id_5}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pair_unpack$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$(_owner_0)), "snd": _value_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_cursor_flatfold_health$1260$(_cursor_0, _owner_0, _total_0) {
  const _namespace_0 = _cursor_0["namespace"];
  const _handles_0 = _cursor_0["ids"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_finish$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_cursor_flatfold_health_loop$1260$(_namespace_0, _handles_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_pack$(_owner_0, _total_0)))));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_return$(_namespace_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeIdCursor", "namespace": _namespace_0, "ids": _ids_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_ids$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_result$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _levels_0 = _t_0["levels"];
  const _rawreserve_0 = _t_0["reserve"];
  const _rawclass_0 = _t_0["class"];
  const _t_1 = _result_0["snd"];
  const _t_2 = _t_1["levels"];
  const _a_0 = _t_2["a"];
  const _b_0 = _t_2["b"];
  const _c_0 = _t_2["c"];
  const _d_0 = _t_2["d"];
  const _cachedreserve_0 = _t_1["reserve"];
  const _cachedclass_0 = _t_1["class"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cached-payload.PrototypeHealthMainSlot", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058vitals_get$(_owner_0) {
  const _array_0 = _owner_0["levels"];
  const _reserve_0 = _owner_0["reserve"];
  const _class_0 = _owner_0["class"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058vitals_observed$(_reserve_0, _class_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_new$(_raw_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_init$1263$(_raw_0);
}

function $health_post_view$(_pings_0, _result_0) {
  const _view_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_world$1261$(_view_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12616$(_pings_0));
  const _x_3 = (",\"world\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return (_x_5) => $IO$print$(("{\"phase\":\"post\",\"pings\":" + _x_4), _x_5);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world$1260$(_owner_0) {
  const _namespace_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["next"];
  const _owners_0 = _owner_0["rows"];
  const _pending_0 = _owner_0["pending"];
  const _ledger_0 = _owner_0["ledger"];
  const _mode_0 = _owner_0["mode"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world_rows$1260$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows$1260$(_owners_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_mark_all$(_marks_0, _world_0, _tick_0) {
  if (_marks_0.$ === "Nil") {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _t_1 = _t_0["metadata"];
    const _live_0 = _t_1["live"];
    const _flags_0 = _t_1["flags"];
    const _added_0 = _t_1["added"];
    const _changed_0 = _t_1["changed"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    const _namespace_1 = _world_0["namespace"];
    const _next_1 = _world_0["next"];
    const _t_2 = _world_0["rows"];
    const _main_1 = _t_2["main"];
    const _aux_1 = _t_2["aux"];
    const _t_3 = _t_2["metadata"];
    const _live_1 = _t_3["live"];
    const _flags_1 = _t_3["flags"];
    const _added_1 = _t_3["added"];
    const _changed_1 = _t_3["changed"];
    const _capacity_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _high_1 = _t_2["high_water"];
    const _pending_1 = _world_0["pending"];
    const _ledger_1 = _world_0["ledger"];
    const _mode_1 = _world_0["mode"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_loop$(_marks_0, _namespace_1, _next_1, _main_1, _aux_1, _flags_1, _added_1, {$: "Tuple", "fst": _live_1, "snd": _changed_1}, _capacity_1, _depth_1, _high_1, _pending_1, _ledger_1, _mode_1, _tick_0);
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_finish_failure$1263$(_t_0) {
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Reverted", "world": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058unwind$1263$(_undo_0, _world_0))};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_shape_chosen$1260$(_selection_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _valid_0, _world_0) {
  if (!_valid_0) {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_original$1260$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_each$1260$(_selection_0, _world_0)));
  } else {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_ready$1260$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_each$1260$(_selection_0, _world_0)));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_all$1260$(_marks_0, _world_0, _tick_0) {
  if (_marks_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd") {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _t_1 = _t_0["metadata"];
    const _live_0 = _t_1["live"];
    const _flags_0 = _t_1["flags"];
    const _added_0 = _t_1["added"];
    const _changed_0 = _t_1["changed"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    const _namespace_1 = _world_0["namespace"];
    const _next_1 = _world_0["next"];
    const _t_2 = _world_0["rows"];
    const _main_1 = _t_2["main"];
    const _aux_1 = _t_2["aux"];
    const _t_3 = _t_2["metadata"];
    const _live_1 = _t_3["live"];
    const _flags_1 = _t_3["flags"];
    const _added_1 = _t_3["added"];
    const _changed_1 = _t_3["changed"];
    const _capacity_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _high_1 = _t_2["high_water"];
    const _pending_1 = _world_0["pending"];
    const _ledger_1 = _world_0["ledger"];
    const _mode_1 = _world_0["mode"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_loop$1260$(_marks_0, _namespace_1, _next_1, _main_1, _aux_1, _flags_1, _added_1, {$: "Tuple", "fst": _live_1, "snd": _changed_1}, _capacity_1, _depth_1, _high_1, _pending_1, _ledger_1, _mode_1, _tick_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unwind$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatEnd") {
        return _world_0;
      } else if (_undo_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMain") {
        const _space_0 = _undo_0["namespace"];
        const _id_0 = _undo_0["id"];
        const _old_0 = _undo_0["old"];
        const _tail_0 = _undo_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_restore$(_world_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, _old_0));
        continue;
      } else if (_undo_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatLedger") {
        const _old_1 = _undo_0["old"];
        const _tail_1 = _undo_0["tail"];
        $0 = _tail_1;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_restore$(_world_0, _old_1));
        continue;
      } else {
        const _space_1 = _undo_0["namespace"];
        const _id_1 = _undo_0["id"];
        const _main_old_0 = _undo_0["main_old"];
        const _ledger_old_0 = _undo_0["ledger_old"];
        const _tail_2 = _undo_0["tail"];
        $0 = _tail_2;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_restore$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_restore$(_world_0, _ledger_old_0)), {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_1, "id": _id_1}, _main_old_0));
        continue;
      }
    }
  }
}

function $health_view_done$(_context_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $health_view_context$(_world_0, _view_0, _context_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands_tail$(_owner_0, _value_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _tail_0}, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _owner_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.SpawnView", "id": _id_0, "bundle": _value_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058bundle$1260$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058bundle_main$1260$(_aux_0, _flag_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1262$(_main_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058command_main$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.InsertMain", "id": _id_0, "main": _owner_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.MainView", "id": _id_0, "main": _value_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_get$(_owner_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cached-payload.PrototypeHealthMainSlot", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.VitalsView", "levels": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "reserve": _cachedreserve_0, "class": _cachedclass_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_marks_0))};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_finish$(_state_0) {
  const _ns_0 = _state_0["namespace"];
  const _next_0 = _state_0["next"];
  const _columns_0 = _state_0["columns"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _depth_0 = _state_0["depth"];
  const _high_0 = _state_0["high"];
  const _pending_0 = _state_0["pending"];
  const _t_0 = _state_0["ledger"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _totals_0 = _t_1["totals"];
    const _epoch_0 = _t_1["epoch"];
    const _cached_0 = _t_1["cached"];
    const _mode_0 = _state_0["mode"];
    const _selected_0 = _state_0["selected"];
    const _undo_0 = _state_0["undo"];
    const _commands_0 = _state_0["commands"];
    const _pings_0 = _state_0["pings"];
    const _marks_0 = _state_0["marks"];
    const _total_0 = _state_0["total"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cache.Cache", "raw": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthLedger", "totals": _totals_0, "epoch": _epoch_0}, "cached": _cached_0}}, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _total_0};
  } else {
    const _mode_1 = _state_0["mode"];
    const _selected_1 = _state_0["selected"];
    const _undo_1 = _state_0["undo"];
    const _commands_1 = _state_0["commands"];
    const _pings_1 = _state_0["pings"];
    const _marks_1 = _state_0["marks"];
    const _total_1 = _state_0["total"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_1}, "selected": _selected_1, "undo": _undo_1, "commands": _commands_1, "pings": _pings_1, "marks": _marks_1}, "snd": _total_1};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_cursor_flatfold_health_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _namespace_0 = $0;
      const _handles_0 = $1;
      const _state_0 = $2;
      if (_handles_0.$ === "Nil") {
        return _state_0;
      } else {
        const _handle_0 = _handles_0["head"];
        const _rest_0 = _handles_0["tail"];
        $0 = _namespace_0;
        $1 = _rest_0;
        $2 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_step$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _handle_0}, _state_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_pack$(_owner_0, _total_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _t_1 = _t_0["rows"];
  const _columns_0 = _t_1["main"];
  const _aux_0 = _t_1["aux"];
  const _metadata_0 = _t_1["metadata"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _high_0 = _t_1["high_water"];
  const _pending_0 = _t_0["pending"];
  const _t_2 = _t_0["ledger"];
  if (_t_2.$ === "Some") {
    const _t_3 = _t_2["value"];
    const _t_4 = _t_3["raw"];
    const _totals_0 = _t_4["totals"];
    const _epoch_0 = _t_4["epoch"];
    const _cached_0 = _t_3["cached"];
    const _mode_0 = _t_0["mode"];
    const _selected_0 = _owner_0["selected"];
    const _undo_0 = _owner_0["undo"];
    const _commands_0 = _owner_0["commands"];
    const _pings_0 = _owner_0["pings"];
    const _marks_0 = _owner_0["marks"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeJournalLedger", "totals": _totals_0, "epoch": _epoch_0, "cached": _cached_0}}, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0};
  } else {
    const _mode_1 = _t_0["mode"];
    const _selected_1 = _owner_0["selected"];
    const _undo_1 = _owner_0["undo"];
    const _commands_1 = _owner_0["commands"];
    const _pings_1 = _owner_0["pings"];
    const _marks_1 = _owner_0["marks"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_1, "selected": _selected_1, "undo": _undo_1, "commands": _commands_1, "pings": _pings_1, "marks": _marks_1, "total": _total_0};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observations_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_go$1260$(_high_0, _high_0, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058vitals_observed$(_reserve_0, _class_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Vitals", "levels": _array_0, "reserve": _reserve_0, "class": _class_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.VitalsView", "levels": _values_0, "reserve": _reserve_0, "class": _class_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058original_four$(_array_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_init$1263$(_raw_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_get$(_raw_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12616$(_values_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12616$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_world$1261$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _next_0 = _value_0["next"];
  const _rows_0 = _value_0["rows"];
  const _pending_0 = _value_0["pending"];
  const _ledger_0 = _value_0["ledger"];
  const _mode_0 = _value_0["mode"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"namespace\":", "tail": {$: "Con", "head": ($U32$show$(_namespace_0)), "tail": {$: "Con", "head": ",\"next\":", "tail": {$: "Con", "head": ($U32$show$(_next_0)), "tail": {$: "Con", "head": ",\"rows\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12613$(_rows_0)), "tail": {$: "Con", "head": ",\"pending\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12614$(_pending_0)), "tail": {$: "Con", "head": ",\"ledger\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_ledger_0)), "tail": {$: "Con", "head": ",\"mode\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_health_mode$(_mode_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world_rows$1260$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world_commands$1260$(_namespace_0, _next_0, _owners_0, _values_0, _ledger_0, _mode_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_pending_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows$1260$(_owners_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_start$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058rows_high_water$(_owners_0)));
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_loop$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) {
  for (;;) {
    {
      const _marks_0 = $0;
      const _namespace_0 = $1;
      const _next_0 = $2;
      const _main_0 = $3;
      const _aux_0 = $4;
      const _flags_0 = $5;
      const _added_0 = $6;
      const _transport_0 = $7;
      const _capacity_0 = $8;
      const _depth_0 = $9;
      const _high_0 = $10;
      const _pending_0 = $11;
      const _ledger_0 = $12;
      const _mode_0 = $13;
      const _tick_0 = $14;
      if (_marks_0.$ === "Nil") {
        const _live_0 = _transport_0["fst"];
        const _changed_0 = _transport_0["snd"];
        return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
      } else {
        const _t_0 = _marks_0["head"];
        const _foreign_0 = _t_0["namespace"];
        const _id_0 = _t_0["id"];
        const _rest_0 = _marks_0["tail"];
        const _live_1 = _transport_0["fst"];
        const _changed_1 = _transport_0["snd"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = _next_0;
        $3 = _main_0;
        $4 = _aux_0;
        $5 = _flags_0;
        $6 = _added_0;
        $7 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _live_1, _changed_1, _id_0, _tick_0));
        $8 = _capacity_0;
        $9 = _depth_0;
        $10 = _high_0;
        $11 = _pending_0;
        $12 = _ledger_0;
        $13 = _mode_0;
        $14 = _tick_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058unwind$1263$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _t_0 = _undo_0["head"];
        if (_t_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.MainInverse") {
          const _handle_0 = _t_0["handle"];
          const _old_0 = _t_0["old"];
          const _rest_0 = _undo_0["tail"];
          $0 = _rest_0;
          $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_restore$(_world_0, _handle_0, _old_0));
          continue;
        } else {
          const _old_1 = _t_0["old"];
          const _rest_1 = _undo_0["tail"];
          $0 = _rest_1;
          $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_restore$(_world_0, _old_1));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_ready$1260$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _batch_0) {
if(__handoff_active) __handoff_route["ready"]++;

  const _world_0 = _batch_0["world"];
  const _rows_0 = _batch_0["rows"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_finish$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_drain$1260$(_rows_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_pack$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, _total_0)))));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_world_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_loop$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) {
  for (;;) {
    {
      const _marks_0 = $0;
      const _namespace_0 = $1;
      const _next_0 = $2;
      const _main_0 = $3;
      const _aux_0 = $4;
      const _flags_0 = $5;
      const _added_0 = $6;
      const _transport_0 = $7;
      const _capacity_0 = $8;
      const _depth_0 = $9;
      const _high_0 = $10;
      const _pending_0 = $11;
      const _ledger_0 = $12;
      const _mode_0 = $13;
      const _tick_0 = $14;
      if (_marks_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd") {
        const _live_0 = _transport_0["fst"];
        const _changed_0 = _transport_0["snd"];
        return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
      } else {
        const _foreign_0 = _marks_0["namespace"];
        const _id_0 = _marks_0["id"];
        const _rest_0 = _marks_0["tail"];
        const _live_1 = _transport_0["fst"];
        const _changed_1 = _transport_0["snd"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = _next_0;
        $3 = _main_0;
        $4 = _aux_0;
        $5 = _flags_0;
        $6 = _added_0;
        $7 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _live_1, _changed_1, _id_0, _tick_0));
        $8 = _capacity_0;
        $9 = _depth_0;
        $10 = _high_0;
        $11 = _pending_0;
        $12 = _ledger_0;
        $13 = _mode_0;
        $14 = _tick_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_restore$(_world_0, _handle_0, _old_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_restore_main0$1263$(_world_0, _handle_0, _old_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_restore$(_world_0, _old_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_restore_ledger0$1263$(_world_0, _old_0);
}

function $health_view_context$(_world_0, _view_0, _context_0) {
  const _selected_0 = _context_0["selected"];
  const _undo_0 = _context_0["undo"];
  const _commands_0 = _context_0["commands"];
  const _pings_0 = _context_0["pings"];
  const _marks_0 = _context_0["marks"];
  const _value_0 = _context_0["value"];
  const _views_0 = _context_0["views"];
  return run_clo((_x_0) => {
  const _x_1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_world$1261$(_view_0));
  const _x_2 = (_x_1 + "}");
  const _x_3 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12611$(_marks_0));
  const _x_4 = (",\"world\":" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12616$(_pings_0));
  const _x_7 = (",\"marks\":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12614$(_views_0));
  const _x_10 = (",\"pings\":" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_string$(($undo_text$1260$(_undo_0))));
  const _x_13 = (",\"commands\":" + _x_11);
  const _x_14 = (_x_12 + _x_13);
  const _x_15 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_handle$(_selected_0));
  const _x_16 = (",\"undo\":" + _x_14);
  const _x_17 = (_x_15 + _x_16);
  const _x_18 = ($U32$show$(_value_0));
  const _x_19 = (",\"selected\":" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  return $IO$bind$((_x_21) => $IO$print$(("{\"phase\":\"pre\",\"value\":" + _x_20), _x_21), run_clo((_x_22) => {
  return run_clo((_x_23) => {
  return $IO$pure$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, _x_23);
});
}), _x_0);
});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058bundle_main$1260$(_aux_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_aux_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_get$(_owner_1)));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_step$1260$(_handle_0, _state_0) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _ns_0 = _state_0["namespace"];
  const _next_0 = _state_0["next"];
  const _columns_0 = _state_0["columns"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _depth_0 = _state_0["depth"];
  const _high_0 = _state_0["high"];
  const _pending_0 = _state_0["pending"];
  const _ledger_0 = _state_0["ledger"];
  const _mode_0 = _state_0["mode"];
  const _undo_0 = _state_0["undo"];
  const _commands_0 = _state_0["commands"];
  const _pings_0 = _state_0["pings"];
  const _marks_0 = _state_0["marks"];
  const _total_0 = _state_0["total"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_guard$1260$(($Bool$and$((_ns_0 === _space_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _id_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _metadata_0, _ledger_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_finish_forward$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 - 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058original_four$(_array_0) {
  return __direct_tuple_helper_2((_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_init_done$(_result_0) {
  const _raw_0 = _result_0["fst"];
  const _cached_0 = _result_0["snd"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_get$(_owner_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_observed$(_epoch_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(_values_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_chunks$(_values_0, "");
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12616$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($U32$show$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12613$(_values_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12613$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12614$(_values_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12614$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_ledger$(_value_1);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_health_mode$(_value_0) {
  if (_value_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthOn") {
    return "\"HealthOn\"";
  } else {
    return "\"HealthOff\"";
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world_commands$1260$(_namespace_0, _next_0, _rows_0, _rowViews_0, _ledger_0, _mode_0, _result_0) {
  const _pending_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _values_0, _mode_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_ledger_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_start$1260$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _high_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_go$1260$(_high_0, 1, {$: "Tuple", "fst": _owners_0, "snd": {$: "Nil"}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058rows_high_water$(_rows_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": _h_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(_valid_0, _live_0, _changed_0, _id_0, _tick_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_3(_changed_0, ((_id_0 - 1) >>> 0), _tick_0, (_live_0), (_live_0[_x_0 % _live_0.length]));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_drain$1260$($0, $1) {
if(__handoff_active) __handoff_route["drain"]++;

  for (;;) {
    {
      const _rows_0 = $0;
      const _state_0 = $1;
      if (_rows_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.ConcreteHealthHandoffNil") {
        return _state_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _ns_0 = _state_0["namespace"];
        const _next_0 = _state_0["next"];
        const _columns_0 = _state_0["columns"];
        const _aux_0 = _state_0["aux"];
        const _metadata_0 = _state_0["metadata"];
        const _capacity_0 = _state_0["capacity"];
        const _depth_0 = _state_0["depth"];
        const _high_0 = _state_0["high"];
        const _pending_0 = _state_0["pending"];
        const _t_0 = _state_0["ledger"];
        if (_t_0.$ === "Some") {
          const _ledger_0 = _t_0["value"];
          const _mode_0 = _state_0["mode"];
          const _undo_0 = _state_0["undo"];
          const _commands_0 = _state_0["commands"];
          const _pings_0 = _state_0["pings"];
          const _marks_0 = _state_0["marks"];
          const _total_0 = _state_0["total"];
          $0 = _rest_0;
          $1 = (__direct_tuple_helper_4((_columns_0), ({$: "Some", "value": _owner_0}), _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _ns_0, "id": _id_0}, _undo_0, _commands_0, _pings_0, _marks_0, _total_0));
          continue;
        } else {
          const _mode_1 = _state_0["mode"];
          const __1 = _state_0["selected"];
          const _undo_1 = _state_0["undo"];
          const _commands_1 = _state_0["commands"];
          const _pings_1 = _state_0["pings"];
          const _marks_1 = _state_0["marks"];
          const _total_1 = _state_0["total"];
          return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_recovered$1260$(_ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, {$: "None"}, _mode_1, __1, _undo_1, _commands_1, _pings_1, _marks_1, _total_1, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_recover$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.ConcreteHealthHandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, _columns_0)));
        }
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_world_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffBatch", "world": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "rows": _values_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_go$1260$(_high_0, _high_0, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.ConcreteHealthHandoffNil"}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_restore_main0$1263$(_world_0, _handle_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058discard_access$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_set_main0$1263$(_world_0, _handle_0, _value_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_restore_ledger0$1263$(_world_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058discard_optional$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1263$(_world_0, _value_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_handle$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"namespace\":", "tail": {$: "Con", "head": ($U32$show$(_namespace_0)), "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_string$(_value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "\"", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escape$(_value_0)), "tail": {$: "Con", "head": "\"", "tail": {$: "Nil"}}}});
}

function $undo_text$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _values_0["head"];
    if (_t_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.MainInverse") {
      const _h_0 = _t_0["handle"];
      const _old_0 = _t_0["old"];
      const _rest_0 = _values_0["tail"];
      const _x_0 = ($undo_text$1260$(_rest_0));
      const _x_1 = ($U32$show$(_old_0));
      const _x_2 = (";" + _x_0);
      const _x_3 = (_x_1 + _x_2);
      const _x_4 = ($health_handle$(_h_0));
      const _x_5 = (":" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      return ("M" + _x_6);
    } else {
      const _old_1 = _t_0["old"];
      const _rest_1 = _values_0["tail"];
      const _x_7 = ($undo_text$1260$(_rest_1));
      const _x_8 = ($U32$show$(_old_1));
      const _x_9 = (";" + _x_7);
      const _x_10 = (_x_8 + _x_9);
      return ("L:" + _x_10);
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list$12611$(_values_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12611$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Bundle", "main": _main_0, "aux": _aux_0, "flag": _flag_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.BundleView", "main": _value_0, "aux": _auxView_0, "flag": _flag_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058armor_get$(_owner_1)));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _value_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_guard$1260$(_valid_0, _id_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _metadata_0, _ledger_0) {
  if (_valid_0) {
    if (_ledger_0.$ === "Some") {
      const _ledger_1 = _ledger_0["value"];
      return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_live$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_live$(_metadata_0, ((_id_0 - 1) >>> 0))), _ledger_1, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _id_0);
    } else {
      return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0});
    }
  } else {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0});
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_finish_forward$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": _values_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_5(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, (_live_0), (_live_0[_x_0 % _live_0.length]));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return __direct_tuple_helper_6(_a_0, (_array_0), (_array_0[1 % _array_0.length]));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_observed$(_epoch_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthLedger", "totals": _array_0, "epoch": _epoch_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.LedgerView", "totals": _values_0, "epoch": _epoch_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return {$: "Con", "head": _value_0, "tail": _acc_0};
  } else {
    return {$: "Con", "head": _value_0, "tail": {$: "Con", "head": ",", "tail": _acc_0}};
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12613$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_row$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12614$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_pending$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"totals\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_totals_0)), "tail": {$: "Con", "head": ",\"epoch\":", "tail": {$: "Con", "head": ($U32$show$(_epoch_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _pendingViews_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.WorldView", "namespace": _namespace_0, "next": _next_0, "rows": _rowViews_0, "pending": ($List$reverse$(_pendingViews_0)), "ledger": _value_0, "mode": _mode_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_get$(_owner_1)));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_go$1260$($0, $1, $2) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _state_0 = $2;
      if (_remaining_0 === 0) {
        return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0);
      } else {
        const _remaining_1 = (_remaining_0 - 1);
        $0 = _remaining_1;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_advance$1260$(_id_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_live$(_changed_0, _index_0, _tick_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    return {$: "Tuple", "fst": _live_0, "snd": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_taken$1260$(_result_0, _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0) {
if(__handoff_active) __handoff_route["taken"]++;

  const _columns_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _levels_0 = _t_1["levels"];
    const _rawreserve_0 = _t_1["rawreserve"];
    const _rawclass_0 = _t_1["rawclass"];
    const _a_0 = _t_1["a"];
    const _b_0 = _t_1["b"];
    const _c_0 = _t_1["c"];
    const _d_0 = _t_1["d"];
    const _cachedreserve_0 = _t_1["cachedreserve"];
    const _cachedclass_0 = _t_1["cachedclass"];
    const _totals_0 = _ledger_0["totals"];
    const _epoch_0 = _ledger_0["epoch"];
    const _ledger_cached_0 = _ledger_0["cached"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_returned$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_invoke$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePackedHealthRowOwner", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0, "totals": _totals_0, "epoch": _epoch_0, "ledger_cached": _ledger_cached_0, "handle": _selected_0, "undo": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": _undo_0}, "marks": _marks_0})), _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0);
  } else {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0});
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_recovered$1260$(_ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _result_0) {
  const _columns_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_cursor_flatfold_health_loop$1260$(_ns_0, _ids_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_recover$(_rows_0, _columns_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_recover_go$(_rows_0, _columns_0, {$: "Nil"});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_finish_forward$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 - 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058discard_access$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_set_main0$1263$(_world_0, _handle_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_swap$(_x_0, _value_0);
}));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058discard_optional$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1263$(_world_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_swap$(_x_0, _value_0);
}));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escape$(_value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escape_tail$(_value_0, "");
}

function $health_handle$(_handle_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = ($U32$show$(_namespace_0));
  const _x_2 = ("/" + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$12611$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_handle$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058armor_get$(_owner_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058armor_get$(_owner_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_live$1260$(_result_0, _ledger_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _id_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0});
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_taken$1260$(array_rmw(_columns_0, _x_0, () => _x_1), _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return __direct_tuple_helper_7(_flags_0, _added_0, _changed_0, (_live_0), (_live_0[_index_0 % _live_0.length]));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback$1260$(_state_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback_done$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_finish$(_state_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_8(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, (_flags_0), (_flags_0[_x_0 % _flags_0.length]));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return __direct_tuple_helper_9(_a_0, _b_0, (_array_0), (_array_0[2 % _array_0.length]));
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_row$1261$(_value_0) {
  const _id_0 = _value_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1266$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1264$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1265$(_flag_0)), "tail": {$: "Con", "head": ",\"added\":", "tail": {$: "Con", "head": ($U32$show$(_added_0)), "tail": {$: "Con", "head": ",\"changed\":", "tail": {$: "Con", "head": ($U32$show$(_changed_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_pending$1261$(_value_0) {
  if (_value_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.SpawnView") {
    const _id_0 = _value_0["id"];
    const _bundle_0 = _value_0["bundle"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"SpawnView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": ",\"bundle\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_bundle$1261$(_bundle_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.MainView") {
    const _id_1 = _value_0["id"];
    const _main_0 = _value_0["main"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"MainView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_1)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_vitals$(_main_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.FlagView") {
    const _id_2 = _value_0["id"];
    const _flag_0 = _value_0["flag"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"FlagView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_2)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_tracked$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.RemoveMainView") {
    const _id_3 = _value_0["id"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"RemoveMainView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_3)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.RemoveFlagView") {
    const _id_4 = _value_0["id"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"RemoveFlagView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_4)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else {
    const _id_5 = _value_0["id"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"DespawnView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_5)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"a\":", "tail": {$: "Con", "head": ($U32$show$(_a_0)), "tail": {$: "Con", "head": ",\"b\":", "tail": {$: "Con", "head": ($U32$show$(_b_0)), "tail": {$: "Con", "head": ",\"c\":", "tail": {$: "Con", "head": ($U32$show$(_c_0)), "tail": {$: "Con", "head": ",\"d\":", "tail": {$: "Con", "head": ($U32$show$(_d_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_get$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0}, "snd": _cached_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return {$: "Tuple", "fst": _owners_0, "snd": ($List$reverse$(_values_0))};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_advance$1260$(_id_0, _state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_slot$1260$(_values_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058rows_extract$(_owners_0, _id_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_returned$(_result_0, _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0) {
if(__handoff_active) __handoff_route["returned"]++;

  const _t_0 = _result_0["fst"];
  const _levels_0 = _t_0["levels"];
  const _rawreserve_0 = _t_0["rawreserve"];
  const _rawclass_0 = _t_0["rawclass"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _cachedreserve_0 = _t_0["cachedreserve"];
  const _cachedclass_0 = _t_0["cachedclass"];
  const _totals_0 = _t_0["totals"];
  const _epoch_0 = _t_0["epoch"];
  const _ledger_cached_0 = _t_0["ledger_cached"];
  const _t_1 = _t_0["handle"];
  const _space_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _t_0["undo"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cached-payload.PrototypeHealthMainSlot", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}};
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeJournalLedger", "totals": _totals_0, "epoch": _epoch_0, "cached": _ledger_cached_0}}, "mode": _mode_0, "selected": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, "undo": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_flush$1261$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": ((_total_0 + _value_0) >>> 0)};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_invoke$1260$(_owner_0) {
if(__handoff_active) __handoff_route["invoke"]++;

  return $fixture_body$1261$(_owner_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_recover_go$($0, $1, $2) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _columns_0 = $1;
      const _ids_0 = $2;
      if (_rows_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.ConcreteHealthHandoffNil") {
        return {$: "Tuple", "fst": _columns_0, "snd": ($List$reverse$(_ids_0))};
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0);
        $2 = {$: "Con", "head": _id_0, "tail": _ids_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_finish_forward$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": _values_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_10(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, (_live_0), (_live_0[_x_0 % _live_0.length]));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_swap$(_owner_0, _value_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  return __direct_tuple_helper_11(_rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, (_levels_0), (_levels_0[0 % _levels_0.length]));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _t_0 = _world_0["ledger"];
  if (_t_0.$ === "None") {
    const _mode_0 = _world_0["mode"];
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    const _ledger_0 = _t_0["value"];
    const _mode_1 = _world_0["mode"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_1, _transform_0(_ledger_0));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_swap$(_owner_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_swap$1263$(_owner_0, _value_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escape_tail$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_push$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escaped_code$(($Char$to_u32$(_head_0)))), _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058armor_get$(_owner_0) {
  const _array_0 = _owner_0["layers"];
  const _grade_0 = _owner_0["grade"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058armor_observed$(_grade_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback_done$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _total_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_unpack$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_flatfold_health_converted$(($fixture_body$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$(_owner_0)))))), _total_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_selected$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return __direct_tuple_helper_12(_a_0, _b_0, _c_0, (_array_0), (_array_0[3 % _array_0.length]));
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1266$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_vitals$(_value_1);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1264$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_armor$(_value_1);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1265$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_tracked$(_value_1);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_bundle$1261$(_value_0) {
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"main\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1266$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1264$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1265$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_vitals$(_value_0) {
  const _levels_0 = _value_0["levels"];
  const _reserve_0 = _value_0["reserve"];
  const _class_0 = _value_0["class"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"levels\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_levels_0)), "tail": {$: "Con", "head": ",\"reserve\":", "tail": {$: "Con", "head": ($U32$show$(_reserve_0)), "tail": {$: "Con", "head": ",\"class\":", "tail": {$: "Con", "head": ($U32$show$(_class_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_tracked$(_value_0) {
  const _group_0 = _value_0["group"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"group\":", "tail": {$: "Con", "head": ($U32$show$(_group_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_slot$1260$(_values_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058row$1260$(_owner_0)));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_flush$1261$(_state_0) {
  const _t_0 = _state_0["pending"];
  if (!_t_0) {
    const _tail_0 = _state_0["tail"];
    return _tail_0;
  } else {
    const __3 = _state_0["namespace"];
    const __4 = _state_0["id"];
    const __5 = _state_0["old"];
    const _tail_1 = _state_0["tail"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMain", "namespace": __3, "id": __4, "old": __5, "tail": _tail_1};
  }
}

function $fixture_body$1261$(_owner_0) {
  return $retained_main$1261$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_get$(_owner_0, __pool_token_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_13(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, (_flags_0), (_flags_0[_x_0 % _flags_0.length]));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_swap_done$(_rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, _result_0) {
  const _levels_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cached-payload.PrototypeHealthMainSlot", "levels": (_levels_0[0 % _levels_0.length] = _value_0, _levels_0), "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}, "snd": _old_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "snd": {$: "Some", "value": _observation_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_swap$1263$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_swap_done$1263$(_cached_0, _value_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_swap$(_raw_0, _value_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escaped_code$(_code_0) {
  if (_code_0 == 34) {
    return "\\\"";
  } else if (_code_0 == 92) {
    return "\\\\";
  } else {
    const _9_0 = u32_to_word(_code_0)["head"];
    const _10_0 = u32_to_word(_code_0)["tail"];
    const _x_0 = word_to_u32({$: "WCon", "head": _9_0, "tail": _10_0});
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escaped_other$(word_to_u32({$: "WCon", "head": _9_0, "tail": _10_0}), (_x_0 < 32));
  }
}

function $Char$to_u32$(_c_0) {
  return _c_0.codePointAt(0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058armor_observed$(_grade_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Armor", "layers": _array_0, "grade": _grade_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.ArmorView", "layers": _values_0, "grade": _grade_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_unpack$(_result_0, _total_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["world"];
  const _ns_0 = _t_1["namespace"];
  const _next_0 = _t_1["next"];
  const _t_2 = _t_1["rows"];
  const _columns_0 = _t_2["main"];
  const _aux_0 = _t_2["aux"];
  const _metadata_0 = _t_2["metadata"];
  const _capacity_0 = _t_2["capacity"];
  const _depth_0 = _t_2["depth"];
  const _high_0 = _t_2["high_water"];
  const _pending_0 = _t_1["pending"];
  const _t_3 = _t_1["ledger"];
  if (_t_3.$ === "Some") {
    const _t_4 = _t_3["value"];
    const _t_5 = _t_4["raw"];
    const _totals_0 = _t_5["totals"];
    const _epoch_0 = _t_5["epoch"];
    const _cached_0 = _t_4["cached"];
    const _mode_0 = _t_1["mode"];
    const _selected_0 = _t_0["selected"];
    const _undo_0 = _t_0["undo"];
    const _commands_0 = _t_0["commands"];
    const _pings_0 = _t_0["pings"];
    const _marks_0 = _t_0["marks"];
    const _value_0 = _result_0["snd"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeJournalLedger", "totals": _totals_0, "epoch": _epoch_0, "cached": _cached_0}}, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": ((_total_0 + _value_0) >>> 0)};
  } else {
    const _mode_1 = _t_1["mode"];
    const _selected_1 = _t_0["selected"];
    const _undo_1 = _t_0["undo"];
    const _commands_1 = _t_0["commands"];
    const _pings_1 = _t_0["pings"];
    const _marks_1 = _t_0["marks"];
    const _value_1 = _result_0["snd"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_1, "selected": _selected_1, "undo": _undo_1, "commands": _commands_1, "pings": _pings_1, "marks": _marks_1, "total": ((_total_0 + _value_1) >>> 0)};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_flatfold_health_converted$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1263$(_owner_0)), "snd": _value_0};
}

function $fixture_body$1260$(_owner_0) {
  return $retained_main$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_read_main$(_owner_0, __pool_token_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_armor$(_value_0) {
  const _layers_0 = _value_0["layers"];
  const _grade_0 = _value_0["grade"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"layers\":", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_layers_0)), "tail": {$: "Con", "head": ",\"grade\":", "tail": {$: "Con", "head": ($U32$show$(_grade_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058rows_restore$(_owners_0, _owner_0)), "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058row$1260$(_owner_0) {
  const _id_0 = _owner_0["id"];
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  const _added_0 = _owner_0["added"];
  const _changed_0 = _owner_0["changed"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058row_main$1260$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1262$(_main_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $retained_main$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Found") {
    const _oldmain_0 = _t_0["value"];
    return $retained_ledger$1261$(_oldmain_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_ledger$(_owner_0, __pool_token_1)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 998};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_get$(_owner_0, _token_0) {
if(__handoff_active) __handoff_route["get"]++;

  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Found", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.VitalsView", "levels": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "reserve": _cachedreserve_0, "class": _cachedclass_0}}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_selected$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cache$058static_swap_done$1263$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_cached_0, _value_0))}, "snd": _old_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058health_ledger_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return __direct_tuple_helper_14(_epoch_0, _value_0, (_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_escaped_other$(_code_0, _control_0) {
  if (_control_0) {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "\\u00", "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_hex$((16 === 0 ? 0 : (_code_0 / 16) >>> 0))), "tail": {$: "Con", "head": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_hex$((16 === 0 ? _code_0 : _code_0 % 16))), "tail": {$: "Nil"}}}});
  } else {
    return (($Char$from_u32$(_code_0)) + "");
  }
}

function $retained_main$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Found") {
    const _oldmain_0 = _t_0["value"];
    return $retained_ledger$1260$(_oldmain_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_read_ledger$(_owner_0, __pool_token_1)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 998};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_read_main$(_t_0, _token_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_read_main$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_read$(_x_0, _x_1);
});
}), _t_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, array_rmw(_main_0, _x_0, () => _x_1));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058row_main$1260$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _value_0, _flag_0, _added_0, _changed_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_aux_0)));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return __direct_tuple_helper_15(_flags_0, _added_0, _changed_0, _index_0, (_live_0), (_live_0[_index_0 % _live_0.length]));
}

function $retained_ledger$1261$(_oldmain_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _oldledger_0 = _t_0["value"];
    return $retained_finish$1261$(_oldmain_0, _oldledger_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_setledger$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_setledger$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_set$(_owner_0, __pool_token_0, 30)), __pool_token_1, 200)), __pool_token_1, 300)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 999};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_ledger$(_owner_0, _token_0) {
if(__handoff_active) __handoff_route["ledger"]++;

  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Some", "value": _ledger_cached_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0);
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return __direct_tuple_helper_16(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, (_live_0), (_live_0[_index_0 % _live_0.length]));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.LedgerView", "totals": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0}, "epoch": _epoch_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_health_ledger_swap$(_epoch_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0}, "snd": _old_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047host$045render$058render_hex$(_value_0) {
  if (_value_0 == 0) {
    return "0";
  } else if ((_value_0 & 15) == 0) {
    return "?";
  } else if (_value_0 == 8) {
    return "8";
  } else if ((_value_0 & 15) == 8) {
    return "?";
  } else if (_value_0 == 4) {
    return "4";
  } else if ((_value_0 & 15) == 4) {
    return "?";
  } else if (_value_0 == 12) {
    return "c";
  } else if ((_value_0 & 15) == 12) {
    return "?";
  } else if (_value_0 == 2) {
    return "2";
  } else if ((_value_0 & 15) == 2) {
    return "?";
  } else if (_value_0 == 10) {
    return "a";
  } else if ((_value_0 & 15) == 10) {
    return "?";
  } else if (_value_0 == 6) {
    return "6";
  } else if ((_value_0 & 15) == 6) {
    return "?";
  } else if (_value_0 == 14) {
    return "e";
  } else if ((_value_0 & 15) == 14) {
    return "?";
  } else if (_value_0 == 1) {
    return "1";
  } else if ((_value_0 & 15) == 1) {
    return "?";
  } else if (_value_0 == 9) {
    return "9";
  } else if ((_value_0 & 15) == 9) {
    return "?";
  } else if (_value_0 == 5) {
    return "5";
  } else if ((_value_0 & 15) == 5) {
    return "?";
  } else if (_value_0 == 13) {
    return "d";
  } else if ((_value_0 & 15) == 13) {
    return "?";
  } else if (_value_0 == 3) {
    return "3";
  } else if ((_value_0 & 15) == 3) {
    return "?";
  } else if (_value_0 == 11) {
    return "b";
  } else if ((_value_0 & 15) == 11) {
    return "?";
  } else if (_value_0 == 7) {
    return "7";
  } else if ((_value_0 & 15) == 7) {
    return "?";
  } else if (_value_0 == 15) {
    return "f";
  } else {
    return "?";
  }
}

function $Char$from_u32$(_x_0) {
  return char_new(_x_0);
}

function $retained_ledger$1260$(_oldmain_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _oldledger_0 = _t_0["value"];
    return $retained_finish$1260$(_oldmain_0, _oldledger_0, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_set_ledger0$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_set_ledger0$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_set_main0$(_owner_0, __pool_token_0, 30)), __pool_token_1, 200)), __pool_token_1, 300)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 999};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_read_ledger$(_t_0, _token_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(run_clo((_x_0) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_read$(_x_0);
}), _t_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_read_main$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0)(_selected_0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_read$(_world_0, _handle_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_slot_vitals_get$(_x_0);
}));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": (_main_0[_x_0 % _main_0.length] = _x_1, _main_0), "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": _id_0, "tail": _values_0}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _mainView_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/observations.RowView", "id": _id_0, "main": _mainView_0, "aux": _auxView_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return __direct_tuple_helper_17(_live_0, _added_0, _changed_0, _index_0, _l_0, (_flags_0), (_flags_0[_index_0 % _flags_0.length]));
}

function $retained_finish$1261$(_main_0, _oldledger_0, _owner_0) {
  const _t_0 = _main_0["levels"];
  const _a_0 = _t_0["a"];
  const _t_1 = _oldledger_0["totals"];
  const _b_0 = _t_1["a"];
  return $retained_sum$1261$(_owner_0, ((_a_0 + _b_0) >>> 0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_setledger$(_owner_0, _token_0, _value_0) {
if(__handoff_active) __handoff_route["setledger"]++;

  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return __direct_tuple_helper_18(_levels_0, _rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _epoch_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_1, (_totals_0), (_totals_0[0 % _totals_0.length]), _owner_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_set$(_owner_0, _token_0, _value_0) {
if(__handoff_active) __handoff_route["set"]++;

  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  const _totals_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return __direct_tuple_helper_19(_totals_0, _epoch_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_1, (_levels_0), (_levels_0[0 % _levels_0.length]), _owner_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, array_rmw(_main_0, _x_0, () => _x_1));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $retained_finish$1260$(_main_0, _oldledger_0, _owner_0) {
  const _t_0 = _main_0["levels"];
  const _a_0 = _t_0["a"];
  const _t_1 = _oldledger_0["totals"];
  const _b_0 = _t_1["a"];
  return $retained_sum$1260$(_owner_0, ((_a_0 + _b_0) >>> 0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_set_ledger0$(_t_0, _token_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_write$(_x_0, _x_1);
});
}), _t_0, _value_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_set_main0$(_t_0, _token_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_set_main0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_write$(_x_0, _x_1, _x_2);
});
});
}), _t_0, _value_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_read$(_world_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_get$(_x_0);
}));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return __direct_tuple_helper_20(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, (_added_0), (_added_0[_index_0 % _added_0.length]));
}

function $retained_sum$1261$(_owner_0, _sum_0) {
  const _x_0 = (_sum_0 === 110);
  const _x_1 = (_sum_0 === 1200);
  return $retained_value$1261$(_owner_0, (_x_0 || _x_1));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_setledger_done$(_levels_0, _rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _epoch_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_0, _result_0, __packed_row_reuse_owner) {
  const _totals_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  const __packed_row_reuse_levels = (_levels_0);
const __packed_row_reuse_rawreserve = (_rawreserve_0);
const __packed_row_reuse_rawclass = (_rawclass_0);
const __packed_row_reuse_a = (_a_0);
const __packed_row_reuse_b = (_b_0);
const __packed_row_reuse_c = (_c_0);
const __packed_row_reuse_d = (_d_0);
const __packed_row_reuse_cachedreserve = (_cachedreserve_0);
const __packed_row_reuse_cachedclass = (_cachedclass_0);
const __packed_row_reuse_totals = (_totals_0[0 % _totals_0.length] = _value_0, _totals_0);
const __packed_row_reuse_epoch = (_epoch_0);
const __packed_row_reuse_ledger_cached = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_cached_0, _value_0));
const __packed_row_reuse_handle = (_handle_0);
const __packed_row_reuse_undo = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_ledger$1261$(_old_0, _undo_0));
const __packed_row_reuse_marks = (_marks_0);
__packed_row_reuse_owner["totals"] = __packed_row_reuse_totals;
__packed_row_reuse_owner["ledger_cached"] = __packed_row_reuse_ledger_cached;
__packed_row_reuse_owner["undo"] = __packed_row_reuse_undo;
return __packed_row_reuse_owner;
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_set_fused_done$(_totals_0, _epoch_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, _result_0, __packed_row_reuse_owner) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _levels_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  const __packed_row_reuse_levels = (_levels_0[0 % _levels_0.length] = _value_0, _levels_0);
const __packed_row_reuse_rawreserve = (_rawreserve_0);
const __packed_row_reuse_rawclass = (_rawclass_0);
const __packed_row_reuse_a = (_value_0);
const __packed_row_reuse_b = (_b_0);
const __packed_row_reuse_c = (_c_0);
const __packed_row_reuse_d = (_d_0);
const __packed_row_reuse_cachedreserve = (_cachedreserve_0);
const __packed_row_reuse_cachedclass = (_cachedclass_0);
const __packed_row_reuse_totals = (_totals_0);
const __packed_row_reuse_epoch = (_epoch_0);
const __packed_row_reuse_ledger_cached = (_ledger_cached_0);
const __packed_row_reuse_handle = ({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0});
const __packed_row_reuse_undo = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_main$1261$(_space_0, _id_0, _old_0, _undo_0));
const __packed_row_reuse_marks = ({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": _marks_0});
__packed_row_reuse_owner["levels"] = __packed_row_reuse_levels;
__packed_row_reuse_owner["a"] = __packed_row_reuse_a;
__packed_row_reuse_owner["handle"] = __packed_row_reuse_handle;
__packed_row_reuse_owner["undo"] = __packed_row_reuse_undo;
__packed_row_reuse_owner["marks"] = __packed_row_reuse_marks;
return __packed_row_reuse_owner;
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.ConcreteHealthHandoffCon", "id": _id_0, "owner": _owner_0, "rest": _values_0}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $retained_sum$1260$(_owner_0, _sum_0) {
  const _x_0 = (_sum_0 === 110);
  const _x_1 = (_sum_0 === 1200);
  return $retained_value$1260$(_owner_0, (_x_0 || _x_1));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_value_0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_write$(_world_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1263$(_world_0, _value_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058tx_set_main0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058record_main$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_selected_0)(_value_0));
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058prototype_packed_health_world_write$(_world_0, _handle_0, _value_0) {
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058storage_set_main0$1263$(_world_0, _handle_0, _value_0);
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return __direct_tuple_helper_21(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, (_changed_0), (_changed_0[_index_0 % _changed_0.length]));
}

function $retained_value$1261$(_owner_0, _valid_0) {
  if (_valid_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": 55};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 999};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_ledger$1261$(_old_0, _state_0) {
  const _t_0 = _state_0["pending"];
  if (!_t_0) {
    const _tail_0 = _state_0["tail"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatLedger", "old": _old_0, "tail": _tail_0}};
  } else {
    const __3 = _state_0["namespace"];
    const __4 = _state_0["id"];
    const __5 = _state_0["old"];
    const _tail_1 = _state_0["tail"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatPair", "namespace": __3, "id": __4, "main_old": __5, "ledger_old": _old_0, "tail": _tail_1}};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_main$1261$(_space_0, _id_0, _old_0, _state_0) {
  return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePendingUndo", "pending": true, "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_flush$1261$(_state_0))};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $retained_value$1260$(_owner_0, _valid_0) {
  if (_valid_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": 55};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 999};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _old_0 = _t_0["value"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.LedgerInverse", "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  } else {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047transaction$058record_main$(_handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Found") {
    const _old_0 = _t_0["value"];
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": {$: "Con", "head": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.MainInverse", "handle": _handle_0, "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": {$: "Con", "head": _handle_0, "tail": _marks_0}};
  } else {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Found", "value": _observation_0}};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);
// Private scalar receivers for exact direct Tuple edges only.

function __direct_tuple_helper_0(__direct_tuple_fst_0, __direct_tuple_snd_0) {
  const _t_0 = __direct_tuple_fst_0;
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = __direct_tuple_snd_0;
  return $health_commands_done$({$: "HealthCarry", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "pings": _pings_0, "marks": _marks_0, "value": _value_0}, ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_commands_0)));
}

function __direct_tuple_helper_1(_selection_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, __direct_tuple_fst_1, __direct_tuple_snd_1) {
  const _columns_0 = __direct_tuple_fst_1;
  const _size_0 = __direct_tuple_snd_1;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_handoff_health_shape_chosen$1260$(_selection_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, (_capacity_0 <= _size_0), {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0});
}

function __direct_tuple_helper_2(__direct_tuple_fst_2, __direct_tuple_snd_2) {
  const _array_0 = __direct_tuple_fst_2;
  const _a_0 = __direct_tuple_snd_2;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, {$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]});
}

function __direct_tuple_helper_3(_changed_0, _index_0, _tick_0, __direct_tuple_fst_3, __direct_tuple_snd_3) {
  const _live_0 = __direct_tuple_fst_3;
  const _t_0 = __direct_tuple_snd_3;
  if (!_t_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    return {$: "Tuple", "fst": _live_0, "snd": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)};
  }
}

function __direct_tuple_helper_4(__direct_tuple_fst_4, __direct_tuple_snd_4, _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0) {
if(__handoff_active) __handoff_route["taken"]++;

  const _columns_0 = __direct_tuple_fst_4;
  const _t_0 = __direct_tuple_snd_4;
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _levels_0 = _t_1["levels"];
    const _rawreserve_0 = _t_1["rawreserve"];
    const _rawclass_0 = _t_1["rawclass"];
    const _a_0 = _t_1["a"];
    const _b_0 = _t_1["b"];
    const _c_0 = _t_1["c"];
    const _d_0 = _t_1["d"];
    const _cachedreserve_0 = _t_1["cachedreserve"];
    const _cachedclass_0 = _t_1["cachedclass"];
    const _totals_0 = _ledger_0["totals"];
    const _epoch_0 = _ledger_0["epoch"];
    const _ledger_cached_0 = _ledger_0["cached"];
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_returned$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_invoke$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePackedHealthRowOwner", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0, "totals": _totals_0, "epoch": _epoch_0, "ledger_cached": _ledger_cached_0, "handle": _selected_0, "undo": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": _undo_0}, "marks": _marks_0})), _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0);
  } else {
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_packed_prototype_journalledger_health_fallback$1260$({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0});
  }
}

function __direct_tuple_helper_5(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __direct_tuple_fst_5, __direct_tuple_snd_5) {
  const _live_0 = __direct_tuple_fst_5;
  const _t_0 = __direct_tuple_snd_5;
  if (!_t_0) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, {$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]});
  }
}

function __direct_tuple_helper_6(_a_0, __direct_tuple_fst_6, __direct_tuple_snd_6) {
  const _array_0 = __direct_tuple_fst_6;
  const _b_0 = __direct_tuple_snd_6;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, {$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]});
}

function __direct_tuple_helper_7(_flags_0, _added_0, _changed_0, __direct_tuple_fst_7, __direct_tuple_snd_7) {
  const _live_0 = __direct_tuple_fst_7;
  const _value_0 = __direct_tuple_snd_7;
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function __direct_tuple_helper_8(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, __direct_tuple_fst_8, __direct_tuple_snd_8) {
  if (!_value_0) {
    const _flags_0 = __direct_tuple_fst_8;
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = __direct_tuple_fst_8;
    const _flag_0 = __direct_tuple_snd_8;
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_cursor_struct_idx_selected$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function __direct_tuple_helper_9(_a_0, _b_0, __direct_tuple_fst_9, __direct_tuple_snd_9) {
  const _array_0 = __direct_tuple_fst_9;
  const _c_0 = __direct_tuple_snd_9;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, {$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]});
}

function __direct_tuple_helper_10(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __direct_tuple_fst_10, __direct_tuple_snd_10) {
  const _live_0 = __direct_tuple_fst_10;
  const _t_0 = __direct_tuple_snd_10;
  if (!_t_0) {
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, {$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]});
  }
}

function __direct_tuple_helper_11(_rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, __direct_tuple_fst_11, __direct_tuple_snd_11) {
  const _levels_0 = __direct_tuple_fst_11;
  const _old_0 = __direct_tuple_snd_11;
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/cached-payload.PrototypeHealthMainSlot", "levels": (_levels_0[0 % _levels_0.length] = _value_0, _levels_0), "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}, "snd": _old_0};
}

function __direct_tuple_helper_12(_a_0, _b_0, _c_0, __direct_tuple_fst_12, __direct_tuple_snd_12) {
  const _array_0 = __direct_tuple_fst_12;
  const _d_0 = __direct_tuple_snd_12;
  return {$: "Tuple", "fst": _array_0, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function __direct_tuple_helper_13(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, __direct_tuple_fst_13, __direct_tuple_snd_13) {
  if (!_value_0) {
    const _flags_0 = __direct_tuple_fst_13;
    return {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/query.PrototypeConcreteHealthHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = __direct_tuple_fst_13;
    const _flag_0 = __direct_tuple_snd_13;
    return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058prototype_concrete_health_handoff_struct_idx_selected$1260$(($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function __direct_tuple_helper_14(_epoch_0, _value_0, __direct_tuple_fst_14, __direct_tuple_snd_14) {
  const _array_0 = __direct_tuple_fst_14;
  const _old_0 = __direct_tuple_snd_14;
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/types.HealthLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0}, "snd": _old_0};
}

function __direct_tuple_helper_15(_flags_0, _added_0, _changed_0, _index_0, __direct_tuple_fst_15, __direct_tuple_snd_15) {
  const _live_0 = __direct_tuple_fst_15;
  const _l_0 = __direct_tuple_snd_15;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function __direct_tuple_helper_16(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, __direct_tuple_fst_16, __direct_tuple_snd_16) {
  const _live_0 = __direct_tuple_fst_16;
  const _value_0 = __direct_tuple_snd_16;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function __direct_tuple_helper_17(_live_0, _added_0, _changed_0, _index_0, _l_0, __direct_tuple_fst_17, __direct_tuple_snd_17) {
  const _flags_0 = __direct_tuple_fst_17;
  const _f_0 = __direct_tuple_snd_17;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, {$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]});
}

function __direct_tuple_helper_18(_levels_0, _rawreserve_0, _rawclass_0, _a_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _epoch_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_0, __direct_tuple_fst_18, __direct_tuple_snd_18, __packed_row_reuse_owner) {
  const _totals_0 = __direct_tuple_fst_18;
  const _old_0 = __direct_tuple_snd_18;
  const __packed_row_reuse_levels = (_levels_0);
const __packed_row_reuse_rawreserve = (_rawreserve_0);
const __packed_row_reuse_rawclass = (_rawclass_0);
const __packed_row_reuse_a = (_a_0);
const __packed_row_reuse_b = (_b_0);
const __packed_row_reuse_c = (_c_0);
const __packed_row_reuse_d = (_d_0);
const __packed_row_reuse_cachedreserve = (_cachedreserve_0);
const __packed_row_reuse_cachedclass = (_cachedclass_0);
const __packed_row_reuse_totals = (_totals_0[0 % _totals_0.length] = _value_0, _totals_0);
const __packed_row_reuse_epoch = (_epoch_0);
const __packed_row_reuse_ledger_cached = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047cached$045payload$058health_ledger_patch$(_cached_0, _value_0));
const __packed_row_reuse_handle = (_handle_0);
const __packed_row_reuse_undo = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_ledger$1261$(_old_0, _undo_0));
const __packed_row_reuse_marks = (_marks_0);
__packed_row_reuse_owner["totals"] = __packed_row_reuse_totals;
__packed_row_reuse_owner["ledger_cached"] = __packed_row_reuse_ledger_cached;
__packed_row_reuse_owner["undo"] = __packed_row_reuse_undo;
return __packed_row_reuse_owner;
}

function __direct_tuple_helper_19(_totals_0, _epoch_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, __direct_tuple_fst_19, __direct_tuple_snd_19, __packed_row_reuse_owner) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _levels_0 = __direct_tuple_fst_19;
  const _old_0 = __direct_tuple_snd_19;
  const __packed_row_reuse_levels = (_levels_0[0 % _levels_0.length] = _value_0, _levels_0);
const __packed_row_reuse_rawreserve = (_rawreserve_0);
const __packed_row_reuse_rawclass = (_rawclass_0);
const __packed_row_reuse_a = (_value_0);
const __packed_row_reuse_b = (_b_0);
const __packed_row_reuse_c = (_c_0);
const __packed_row_reuse_d = (_d_0);
const __packed_row_reuse_cachedreserve = (_cachedreserve_0);
const __packed_row_reuse_cachedclass = (_cachedclass_0);
const __packed_row_reuse_totals = (_totals_0);
const __packed_row_reuse_epoch = (_epoch_0);
const __packed_row_reuse_ledger_cached = (_ledger_cached_0);
const __packed_row_reuse_handle = ({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0});
const __packed_row_reuse_undo = ($$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_pending_main$1261$(_space_0, _id_0, _old_0, _undo_0));
const __packed_row_reuse_marks = ({$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": _marks_0});
__packed_row_reuse_owner["levels"] = __packed_row_reuse_levels;
__packed_row_reuse_owner["a"] = __packed_row_reuse_a;
__packed_row_reuse_owner["handle"] = __packed_row_reuse_handle;
__packed_row_reuse_owner["undo"] = __packed_row_reuse_undo;
__packed_row_reuse_owner["marks"] = __packed_row_reuse_marks;
return __packed_row_reuse_owner;
}

function __direct_tuple_helper_20(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, __direct_tuple_fst_20, __direct_tuple_snd_20) {
  const _added_0 = __direct_tuple_fst_20;
  const _a_0 = __direct_tuple_snd_20;
  return $$$$047$$$047bendvy$045slot$045host$045concrete$045owner$045v3$047experiments$047s$045integrate$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]});
}

function __direct_tuple_helper_21(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, __direct_tuple_fst_21, __direct_tuple_snd_21) {
  const _changed_0 = __direct_tuple_fst_21;
  const _c_0 = __direct_tuple_snd_21;
  return {$: "Tuple", "fst": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../../bendvy-slot-host-concrete-owner-v3/experiments/s-integrate/storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}
