from pathlib import Path
import json,hashlib,copy
ROOT=Path('/workspace/formal-proofs/bendvy');OLD=Path('/tmp/bendvy38-pending-stock28-01/plan.json');OUT=Path('/tmp/bendvy38-generational-stock28-actual01');BOUND=Path('/tmp/bendvy38-reviewed-benchmark-boundary.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads(OLD.read_text());plan=copy.deepcopy(old);drift=[];changed={};allowed={str(ROOT/'benchmarks/run.py')}
assert sha(BOUND)=='a32c1e74a5862ee468f6b3e38a2d102e2ebe4ee8650a9f8e7ed810e3b617f050'
for p,h in old['pins'].items():
 try:actual=sha(p)
 except FileNotFoundError:drift.append({'path':p,'expected':h,'actual':'MISSING'});continue
 if actual==h:continue
 if p.startswith(str(ROOT/'src/ecs')+'/') or p in allowed:plan['pins'][p]=actual;changed[p]={'before':h,'after':actual}
 else:drift.append({'path':p,'expected':h,'actual':actual})
for p in list((ROOT/'src/ecs').glob('*.bend'))+list((ROOT/'benchmarks').glob('*.py')):
 k=str(p);actual=sha(p)
 if k in plan['pins']:assert plan['pins'][k]==actual
 else:plan['pins'][k]=actual
contract=json.loads((ROOT/'benchmarks/contract.json').read_text());assert contract==old['contract'];assert sha(ROOT/'benchmarks/contract.json')=='c0e13575f6e4d25ca8ca669936eef39c93a66b57ac1e4bfa42186f6f2d58bb6a'
manifest=Path('/tmp/bendvy38-generational-promoted-working.json');owned=json.loads(manifest.read_text());assert all(sha(x['path'])==x['sha256'] for x in owned)
first=Path('/tmp/bendvy38-generational-first-actual02/normal');prereq={}
for role in ['js','native']:
 d=first/role;r=json.loads((d/'receipt.json').read_text());assert r['status']=='COMPLETE_CONSUMER_DEVELOPMENT_PASS';assert len((d/'consumer.stdout').read_bytes())==23126 and sha(d/'consumer.stdout')=='133f44d1243fad5892d7b61132974c4f21b2b9b031e8a223d28268043c6ec6fb';assert not(d/'consumer.stderr').read_bytes()
 for p in d.iterdir():
  if p.is_file() and p.suffix not in ('.c','.js','.native'):prereq[str(p)]=sha(p)
OUT.mkdir(exist_ok=False);plan['scope']='Default unchanged #28 on integrated full-key candidate plus pre-clear validation. Candidate-only exact archived syntax adapter, same operations/rows/baseline/statistics/caps. Whole-process Workshop qualification only; not full-product timing or final #38/#57 acceptance.';plan['output']=str(OUT/'cohort');plan['argv']=[plan['output'] if a==old['output'] else a for a in old['argv']]
plan['provenance']['generationalIdentity']={'sourceBase':'95342180f','promotedWorkingManifest':str(manifest),'promotedWorkingManifestSHA256':sha(manifest),'adapterCommit':'49718116836c2a850742914c4fd7e695b3615fdc','liveExamplesCommit':'f8ffc4dc8855bb99190953c80f4dcadedc092a87','changedProjectPins':changed,'actualFirstPair':prereq,'scope':'First ordinary source-current full-key reuse/stale/foreign/affine-owner pair is semantic prerequisite; remaining feature gates separate. No tool/resource drift repinned.'}
for p,h in prereq.items():plan['pins'][p]=h
for p in [manifest,BOUND,Path(__file__)]:plan['pins'][str(p)]=sha(p)
plan['quietnessCondition']='Fresh allowed/exclusive CPU11 assessment immediately before launch, after current ordinary backend queue releases. No timing cohort while known CPU contention. Preserve all samples; no new tolerance.'
(OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');report={'status':'READY_FOR_REVIEW' if not drift else 'EXTERNAL_PIN_DRIFT','planSHA256':sha(OUT/'plan.json'),'pins':len(plan['pins']),'coreModules':len(list((ROOT/'src/ecs').glob('*.bend'))),'changedProjectInputs':len(changed),'unrepinnedDrift':drift,'newExecution':False,'quietnessAssessed':False};(OUT/'PREPARATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
