function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($consumer$058run$1260$()), "right": ($consumer$058run$1261$())};
}

function $consumer$058run$1260$() {
  return $consumer$058missing_done$1260$(run_loop($consumer$058created$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($state$058resource$1260$(false)))))));
}

function $consumer$058run$1261$() {
  return $consumer$058missing_done$1261$(run_loop($consumer$058created$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($state$058resource$1261$(false)))))));
}

function $consumer$058missing_done$1260$(_result_0) {
  const _factory_0 = _result_0["fst"];
  const _missing_0 = _result_0["snd"];
  return $consumer$058present_done$1260$(_missing_0, run_loop($consumer$058created$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, ($state$058resource$1260$(true)))))));
}

function $consumer$058created$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $consumer$058initial$1260$(_factory_0, ($dump$058world$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $state$058pending$1260$(_x_0);
}))))));
  } else {
    const _factory_1 = _result_0["factory"];
    return {$: "Tuple", "fst": _factory_1, "snd": {$: "consumer.Report", "initial": "create-refused", "optionalRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "optionalStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "optionalAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "optionalRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "requiredRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "requiredStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "requiredAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "requiredRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $state$058resource$1260$(_present_0) {
  if (!_present_0) {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}, "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": [0], "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($state$058pair$(27, 28)), "right": ($state$058pair$(901, 902))}}};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": ($state$058pair$(17, 18))}, "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": [0], "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($state$058pair$(27, 28)), "right": ($state$058pair$(901, 902))}}};
  }
}

function $consumer$058missing_done$1261$(_result_0) {
  const _factory_0 = _result_0["fst"];
  const _missing_0 = _result_0["snd"];
  return $consumer$058present_done$1261$(_missing_0, run_loop($consumer$058created$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(_factory_0, ($state$058resource$1261$(true)))))));
}

function $consumer$058created$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $consumer$058initial$1261$(_factory_0, ($dump$058world$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $state$058pending$1261$(_x_0);
}))))));
  } else {
    const _factory_1 = _result_0["factory"];
    return {$: "Tuple", "fst": _factory_1, "snd": {$: "consumer.Report", "initial": "create-refused", "optionalRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "optionalStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "optionalAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "optionalRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "requiredRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "requiredStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "requiredAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}, "requiredRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "create-refused", "right": {$: "None"}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $state$058resource$1261$(_present_0) {
  if (!_present_0) {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}, "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": [0], "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($state$058pair$(27, 28)), "right": ($state$058pair$(901, 902))}}};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": ($state$058pair$(17, 18))}, "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": [0], "right": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($state$058pair$(27, 28)), "right": ($state$058pair$(901, 902))}}};
  }
}

function $consumer$058present_done$1260$(_missing_0, _result_0) {
  const _present_0 = _result_0["snd"];
  return {$: "Con", "head": _missing_0, "tail": {$: "Con", "head": _present_0, "tail": {$: "Nil"}}};
}

function $consumer$058initial$1260$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return run_tail(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058optional_ready$1260$(_text_0, _x_0, _x_1);
});
}), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $consumer$058optional_failed$1260$(_text_0, _x_2, _x_3);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0)), true)), "OptionalPayload", "OptionalPayload")), _factory_0);
}

function $dump$058world$1260$(_world_0) {
  return $dump$058counted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $state$058pending$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": ((_clock_0 + 100) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($state$058store$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $state$058pair$(_first_0, _second_0) {
  return array_node([_first_0], [_second_0]);
}

function $consumer$058present_done$1261$(_missing_0, _result_0) {
  const _present_0 = _result_0["snd"];
  return {$: "Con", "head": _missing_0, "tail": {$: "Con", "head": _present_0, "tail": {$: "Nil"}}};
}

function $consumer$058initial$1261$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return run_tail(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1262$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058optional_ready$1261$(_text_0, _x_0, _x_1);
});
}), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $consumer$058optional_failed$1261$(_text_0, _x_2, _x_3);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1261$(_world_0)), true)), "OptionalPayload", "OptionalPayload")), _factory_0);
}

function $dump$058world$1261$(_world_0) {
  return $dump$058counted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $state$058pending$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": ((_clock_0 + 100) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($state$058store$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1260$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1260$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1260$(_world_0, _name_0)));
}

function $consumer$058optional_ready$1260$(_initial_0, _app_0, _factory_0) {
  return $consumer$058optional_registered$1260$(_factory_0, _initial_0, ($consumer$058snapshot$1261$(_app_0)));
}

function $consumer$058optional_failed$1260$(_initial_0, _app_0, _factory_0) {
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "consumer.Report", "initial": _initial_0, "optionalRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "optionalStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "optionalAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "optionalRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "requiredAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1260$(_app_0, _flag_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _flag_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $dump$058counted$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1260$(_count_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1263$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $state$058store$(_unit_0) {
  return $state$058pair$(31, 32);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1262$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1262$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1262$(_world_0, _name_0)));
}

function $consumer$058optional_ready$1261$(_initial_0, _app_0, _factory_0) {
  return $consumer$058optional_registered$1261$(_factory_0, _initial_0, ($consumer$058snapshot$1263$(_app_0)));
}

function $consumer$058optional_failed$1261$(_initial_0, _app_0, _factory_0) {
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "consumer.Report", "initial": _initial_0, "optionalRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "optionalStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "optionalAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "optionalRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "requiredAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1261$(_app_0, _flag_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _flag_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1261$(_world_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $dump$058counted$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1261$(_count_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1267$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1260$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, _result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1260$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1260$(_slot_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1260$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058optional_declaration$1260$()))))))))));
}

function $consumer$058optional_registered$1260$(_factory_0, _initial_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalRegistered_0 = _result_0["snd"];
  return $consumer$058optional_run$1260$(_factory_0, _initial_0, _optionalRegistered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1261$(_app_0, {$: "Unit"})));
}

function $consumer$058snapshot$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $consumer$058physical_returned$1261$(_owners_0, _recipe_0, _debug_0, ($dump$058world$1260$(_world_0)));
}

function $dump$058resourced$1260$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1260$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $dump$058tree$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1263$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1264$(($dump$058resource$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1262$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, _result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1262$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1262$(_slot_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1262$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1262$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058optional_declaration$1261$()))))))))));
}

function $consumer$058optional_registered$1261$(_factory_0, _initial_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalRegistered_0 = _result_0["snd"];
  return $consumer$058optional_run$1261$(_factory_0, _initial_0, _optionalRegistered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1263$(_app_0, {$: "Unit"})));
}

function $consumer$058snapshot$1263$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $consumer$058physical_returned$1263$(_owners_0, _recipe_0, _debug_0, ($dump$058world$1261$(_world_0)));
}

function $dump$058resourced$1261$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1261$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $dump$058tree$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1267$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1269$(($dump$058resource$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1260$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1260$(_world_0, _owners_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1260$(_slot_0, _owner_0) {
  const _registry_0 = _owner_0["registry"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1260$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058optional_declaration$1260$()))))), _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Defined", "world": _world_1, "owner": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Owner", "registry": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(_value_0) {
  const _clauses_0 = _value_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(_declaration_0) {
  const _ordinary_0 = _declaration_0["ordinary"];
  return _ordinary_0;
}

function $state$058optional_declaration$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058with$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058optional$1260$(run_clo((_x_0) => {
  return $state$058render$(_x_0);
}))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058write$1260$()));
}

function $consumer$058optional_run$1260$(_factory_0, _initial_0, _optionalRegistered_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalStatus_0 = _result_0["snd"];
  return $consumer$058optional_after$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, ($consumer$058snapshot$1261$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1261$(_app_0, _args_0) {
  const _world_0 = _app_0["world"];
  const _t_0 = _app_0["owners"];
  const _owners_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _token_0 = _t_1["token"];
  const _fields_0 = _t_1["fields"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1261$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1261$(_token_0, _fields_0)));
}

function $consumer$058physical_returned$1261$(_owners_0, _recipe_0, _debug_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _physical_0 = _result_0["snd"];
  return $consumer$058snap_returned$1261$(_physical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1261$({$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0})));
}

function $dump$058stored$1260$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058tree$1260$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1260$(($dump$058u32$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1260$(($dump$058tree$1260$(_b_0)), ($dump$058tree$1260$(_a_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resource$1260$(_value_0) {
  const _slot_0 = _value_0["left"];
  const _tail_0 = _value_0["right"];
  return $dump$058slot_returned$1260$(_tail_0, ($dump$058slot_view$1260$(_slot_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1262$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1262$(_world_0, _owners_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1262$(_slot_0, _owner_0) {
  const _registry_0 = _owner_0["registry"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1264$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058optional_declaration$1261$()))))), _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1262$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Defined", "world": _world_1, "owner": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Owner", "registry": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(_value_0) {
  const _clauses_0 = _value_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(_declaration_0) {
  const _ordinary_0 = _declaration_0["ordinary"];
  return _ordinary_0;
}

function $state$058optional_declaration$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058with$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058optional$1261$(run_clo((_x_0) => {
  return $state$058render$(_x_0);
}))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058write$1261$()));
}

function $consumer$058optional_run$1261$(_factory_0, _initial_0, _optionalRegistered_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalStatus_0 = _result_0["snd"];
  return $consumer$058optional_after$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, ($consumer$058snapshot$1263$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1263$(_app_0, _args_0) {
  const _world_0 = _app_0["world"];
  const _t_0 = _app_0["owners"];
  const _owners_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _token_0 = _t_1["token"];
  const _fields_0 = _t_1["fields"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1263$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1263$(_token_0, _fields_0)));
}

function $consumer$058physical_returned$1263$(_owners_0, _recipe_0, _debug_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _physical_0 = _result_0["snd"];
  return $consumer$058snap_returned$1263$(_physical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1263$({$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0})));
}

function $dump$058stored$1261$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resource$1261$(_value_0) {
  const _slot_0 = _value_0["left"];
  const _tail_0 = _value_0["right"];
  return $dump$058slot_returned$1261$(_tail_0, ($dump$058slot_view$1261$(_slot_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1260$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1260$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058with$1260$(_left_0, _right_0) {
  const _ordinary_0 = _left_0["ordinary"];
  const _required_0 = _left_0["required"];
  const _observe_0 = _left_0["observe"];
  const _render_0 = _left_0["render"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource-declaration.Declaration", "ordinary": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058pair$1260$(_ordinary_0, _right_0)), "required": _required_0, "observe": _observe_0, "render": _render_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058optional$1260$(_render_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058built$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058provided$1260$(_x_0);
}), _render_0);
}

function $state$058render$(_value_0) {
  if (_value_0.$ === "None") {
    return "Unavailable";
  } else {
    const _value_1 = _value_0["value"];
    return $List$show$1260$(_value_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058write$1260$() {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Write", "operation": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058write$1260$())}, "clauses": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(($state$058counter$1260$()))), "mode": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Write"}}, "tail": {$: "Nil"}}};
}

function $consumer$058optional_after$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalAfter_0 = _result_0["snd"];
  return $consumer$058optional_repeated$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, ($consumer$058snapshot$1261$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1261$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _slot_0 = _result_0["slot"];
  const _clauses_0 = _result_0["clauses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1261$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1261$(_token_0, _fields_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1261$(_fields_0);
}

function $consumer$058snap_returned$1261$(_physical_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _physical_0, "right": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1261$(_world_0, ($consumer$058fold1$1260$())(_owners_0));
  }
}

function $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1261$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058leaf$1260$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058u32$(_value_0) {
  return $dump$058u32_value$(_value_0);
}

function $dump$058tree_left$1260$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1260$(_a_0, _text_0, _b_0);
}

function $dump$058slot_returned$1260$(_tail_0, _result_0) {
  const _slot_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058resource_returned$1260$(_slot_0, ("payload=" + _text_0), ($dump$058tail_view$(_tail_0)));
}

function $dump$058slot_view$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing") {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}, "snd": "Missing"};
  } else {
    const _owner_0 = _value_0["owner"];
    return $dump$058slot_present$1260$(($dump$058tree$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1262$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1264$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058with$1261$(_left_0, _right_0) {
  const _ordinary_0 = _left_0["ordinary"];
  const _required_0 = _left_0["required"];
  const _observe_0 = _left_0["observe"];
  const _render_0 = _left_0["render"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource-declaration.Declaration", "ordinary": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058pair$1261$(_ordinary_0, _right_0)), "required": _required_0, "observe": _observe_0, "render": _render_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058optional$1261$(_render_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058built$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058provided$1261$(_x_0);
}), _render_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058write$1261$() {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Write", "operation": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058write$1261$())}, "clauses": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(($state$058counter$1261$()))), "mode": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Write"}}, "tail": {$: "Nil"}}};
}

function $consumer$058optional_after$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalAfter_0 = _result_0["snd"];
  return $consumer$058optional_repeated$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, ($consumer$058snapshot$1263$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1263$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _slot_0 = _result_0["slot"];
  const _clauses_0 = _result_0["clauses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1263$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, _args_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1263$(_token_0, _fields_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1263$(_fields_0);
}

function $consumer$058snap_returned$1263$(_physical_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _physical_0, "right": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1263$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1263$(_world_0, ($consumer$058fold1$1261$())(_owners_0));
  }
}

function $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1261$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058slot_returned$1261$(_tail_0, _result_0) {
  const _slot_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058resource_returned$1261$(_slot_0, ("payload=" + _text_0), ($dump$058tail_view$(_tail_0)));
}

function $dump$058slot_view$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing") {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}, "snd": "Missing"};
  } else {
    const _owner_0 = _value_0["owner"];
    return $dump$058slot_present$1261$(($dump$058tree$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058pair$1260$(_left_0, _right_0) {
  const _l_0 = _left_0["grant"];
  const _lc_0 = _left_0["clauses"];
  const _r_0 = _right_0["grant"];
  const _rc_0 = _right_0["clauses"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../../bendvy/src/ecs/capabilities.Bundle", "first": _l_0, "second": _r_0}, "clauses": ($List$append$(_lc_0, _rc_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058built$1260$(_required_0, _render_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource-declaration.Declaration", "ordinary": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Read", "operation": {$: "../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1260$(_x_0);
})}}, "clauses": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(($state$058payload$1260$()))), "mode": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read"}}, "tail": {$: "Nil"}}}, "required": _required_0, "observe": run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058observe$1260$(_x_1);
}), "render": _render_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058provided$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058write$1260$() {
  return {$: "../../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058tx_set$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $state$058counter$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1260$("CallbackCounter");
}

function $consumer$058optional_repeated$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalRepeated_0 = _result_0["snd"];
  return run_tail(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058required_ready$1260$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _x_0, _x_1);
});
}), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $consumer$058required_failed$1260$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _x_2, _x_3);
});
}), _app_0, "RequiredPayload", "RequiredPayload")), _factory_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1261$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _registry_0 = _t_0["fst"];
  const _status_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1261$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1263$(_slot_0, _clauses_0, _registry_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _output_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Succeeded", "output": _output_0}}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Failed", "error": _error_0}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "Tuple", "fst": _registry_1, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1261$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-system.Owner", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "slot": _slot_0, "clauses": _clauses_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1261$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1261$(_owners_0, _fields_0, ($consumer$058observe1$1260$())(_world_0));
}

function $consumer$058fold1$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1261$(_x_0);
});
}

function $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1262$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1260$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = (",store=" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = (",depth=" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = (",capacity=" + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (",live=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058tree$1261$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1261$(($dump$058boolean$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1261$(($dump$058tree$1261$(_b_0)), ($dump$058tree$1261$(_a_0)));
  }
}

function $dump$058u32_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $dump$058tree_join$1260$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $dump$058resource_returned$1260$(_slot_0, _previous_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("," + _text_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _slot_0, "right": _tail_0}, "snd": (_previous_0 + _x_0)};
}

function $dump$058tail_view$(_value_0) {
  const _counter_0 = _value_0["left"];
  const _siblings_0 = _value_0["right"];
  return $dump$058counter_returned$(_siblings_0, ($dump$058tree$1260$(_counter_0)));
}

function $dump$058slot_present$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": _owner_0}, "snd": ("Present(" + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058pair$1261$(_left_0, _right_0) {
  const _l_0 = _left_0["grant"];
  const _lc_0 = _left_0["clauses"];
  const _r_0 = _right_0["grant"];
  const _rc_0 = _right_0["clauses"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../../bendvy/src/ecs/capabilities.Bundle", "first": _l_0, "second": _r_0}, "clauses": ($List$append$(_lc_0, _rc_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058built$1261$(_required_0, _render_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource-declaration.Declaration", "ordinary": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Read", "operation": {$: "../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1262$(_x_0);
})}}, "clauses": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(($state$058payload$1261$()))), "mode": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read"}}, "tail": {$: "Nil"}}}, "required": _required_0, "observe": run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058observe$1261$(_x_1);
}), "render": _render_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058provided$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058write$1261$() {
  return {$: "../../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1263$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058tx_set$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $state$058counter$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1261$("CallbackCounter");
}

function $consumer$058optional_repeated$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _optionalRepeated_0 = _result_0["snd"];
  return run_tail(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1263$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058required_ready$1261$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _x_0, _x_1);
});
}), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $consumer$058required_failed$1261$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _x_2, _x_3);
});
}), _app_0, "RequiredPayload", "RequiredPayload")), _factory_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1263$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _registry_0 = _t_0["fst"];
  const _status_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1263$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1267$(_slot_0, _clauses_0, _registry_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1263$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _output_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Succeeded", "output": _output_0}}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Failed", "error": _error_0}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "Tuple", "fst": _registry_1, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1263$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-system.Owner", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "slot": _slot_0, "clauses": _clauses_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1263$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1263$(_owners_0, _fields_0, ($consumer$058observe1$1261$())(_world_0));
}

function $consumer$058fold1$1261$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1263$(_x_0);
});
}

function $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1262$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1260$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = (",store=" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = (",depth=" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = (",capacity=" + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (",live=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058resource_returned$1261$(_slot_0, _previous_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("," + _text_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _slot_0, "right": _tail_0}, "snd": (_previous_0 + _x_0)};
}

function $dump$058slot_present$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": _owner_0}, "snd": ("Present(" + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $state$058payload$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1260$("Payload");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0);
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058tx_set$1260$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058journaled$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace_world$1260$(_replacement_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1260$(_key_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-schema.Resource", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1261$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1261$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1261$(_world_0, _name_0)));
}

function $consumer$058required_ready$1260$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _app_0, _factory_0) {
  return $consumer$058required_registered$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, ($consumer$058snapshot$1260$(_app_0)));
}

function $consumer$058required_failed$1260$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _app_0, _factory_0) {
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "consumer.Report", "initial": _initial_0, "optionalRegistered": _optionalRegistered_0, "optionalStatus": _optionalStatus_0, "optionalAfter": _optionalAfter_0, "optionalRepeated": _optionalRepeated_0, "requiredRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "requiredAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1261$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}}, "recipe": _recipe_0, "debug": _debug_0}, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1263$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1261$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_fields_0)), "right": _view_0}}};
}

function $consumer$058observe1$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1261$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1261$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_x_0);
}), run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1260$(_x_1);
}), _owners_0);
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058leaf$1261$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058boolean$(_value_0) {
  return $dump$058boolean_value$(_value_0);
}

function $dump$058tree_left$1261$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1261$(_a_0, _text_0, _b_0);
}

function $dump$058counter_returned$(_siblings_0, _result_0) {
  const _counter_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tail_returned$(_counter_0, ("counter=" + _text_0), ($dump$058siblings_view$(_siblings_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1262$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1264$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $state$058payload$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1261$("Payload");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1264$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1263$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1265$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058tx_set$1261$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058journaled$1261$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace_world$1261$(_replacement_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1261$(_key_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-schema.Resource", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058register$1263$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1263$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1263$(_world_0, _name_0)));
}

function $consumer$058required_ready$1261$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _app_0, _factory_0) {
  return $consumer$058required_registered$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, ($consumer$058snapshot$1262$(_app_0)));
}

function $consumer$058required_failed$1261$(_initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _app_0, _factory_0) {
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "consumer.Report", "initial": _initial_0, "optionalRegistered": _optionalRegistered_0, "optionalStatus": _optionalStatus_0, "optionalAfter": _optionalAfter_0, "optionalRepeated": _optionalRepeated_0, "requiredRegistered": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredStatus": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}, "requiredAfter": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}, "requiredRepeated": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": "registration-refused", "right": {$: "None"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1263$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}}, "recipe": _recipe_0, "debug": _debug_0}, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1267$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1263$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1263$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1263$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_fields_0)), "right": _view_0}}};
}

function $consumer$058observe1$1261$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1263$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1263$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1261$(_x_0);
}), run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1262$(_x_1);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1260$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058project$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1261$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058journaled$1260$(_undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restore$1260$(_old_0, _x_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace_world$1260$(_replacement_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace$1260$(_replacement_0, _resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1261$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, _result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1261$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1261$(_slot_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1261$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058required_declaration$1260$()))))))))));
}

function $consumer$058required_registered$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _requiredRegistered_0 = _result_0["snd"];
  return $consumer$058required_run$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1260$(_app_0, {$: "Unit"})));
}

function $consumer$058snapshot$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $consumer$058physical_returned$1260$(_owners_0, _recipe_0, _debug_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1260$(_record_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1261$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1261$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_unit_0) {
  return {$: "Tuple", "fst": _unit_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1260$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $dump$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $dump$058tree_join$1261$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $dump$058tail_returned$(_counter_0, _previous_0, _result_0) {
  const _siblings_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("," + _text_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _counter_0, "right": _siblings_0}, "snd": (_previous_0 + _x_0)};
}

function $dump$058siblings_view$(_value_0) {
  const _sibling_0 = _value_0["left"];
  const _owners_0 = _value_0["right"];
  return $dump$058sibling_returned$(_owners_0, ($dump$058tree$1260$(_sibling_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1262$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1264$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058project$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1263$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1265$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058journaled$1261$(_undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restore$1261$(_old_0, _x_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace_world$1261$(_replacement_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace$1261$(_replacement_0, _resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058defined$1263$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, _result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1263$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1263$(_slot_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058define$1263$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1263$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058required_declaration$1261$()))))))))));
}

function $consumer$058required_registered$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _requiredRegistered_0 = _result_0["snd"];
  return $consumer$058required_run$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1262$(_app_0, {$: "Unit"})));
}

function $consumer$058snapshot$1262$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $consumer$058physical_returned$1262$(_owners_0, _recipe_0, _debug_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1263$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1261$(_record_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1263$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1263$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1263$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1261$(_unit_0) {
  return {$: "Tuple", "fst": _unit_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1262$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058project$1260$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058selected$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1262$(($state$058slot_lens$1260$())))(_resource_0));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1260$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1266$(($state$058counter_lens$1260$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restore$1260$(_old_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restored$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace_world$1260$(_old_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace$1260$(_replacement_0, _resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replacing$1260$(_replacement_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1266$(($state$058counter_lens$1260$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1261$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1261$(_world_0, _owners_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1261$(_slot_0, _owner_0) {
  const _registry_0 = _owner_0["registry"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1261$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058required_declaration$1260$()))))), _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Defined", "world": _world_1, "owner": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Owner", "registry": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $state$058required_declaration$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058with$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058required$1260$(run_clo((_x_0) => {
  return $state$058render$(_x_0);
}))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058write$1260$()));
}

function $consumer$058required_run$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _requiredStatus_0 = _result_0["snd"];
  return $consumer$058required_after$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, ($consumer$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1260$(_app_0, _args_0) {
  const _world_0 = _app_0["world"];
  const _t_0 = _app_0["owners"];
  const _owners_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _token_0 = _t_1["token"];
  const _fields_0 = _t_1["fields"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1260$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1260$(_token_0, _fields_0)));
}

function $consumer$058physical_returned$1260$(_owners_0, _recipe_0, _debug_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _physical_0 = _result_0["snd"];
  return $consumer$058snap_returned$1260$(_physical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1260$({$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1260$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _retained_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1260$(_kind_0, _access_0, _retained_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1261$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1261$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1261$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1261$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $dump$058sibling_returned$(_owners_0, _result_0) {
  const _sibling_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058owners_returned$(_sibling_0, ("sibling=" + _text_0), ($dump$058tree$1260$(_owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058project$1261$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058selected$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1269$(($state$058slot_lens$1261$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1261$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12612$(($state$058counter_lens$1261$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restore$1261$(_old_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restored$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace_world$1261$(_old_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replace$1261$(_replacement_0, _resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replacing$1261$(_replacement_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12612$(($state$058counter_lens$1261$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058extracted$1263$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1263$(_world_0, _owners_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$058field_owner$1263$(_slot_0, _owner_0) {
  const _registry_0 = _owner_0["registry"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1265$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058required_declaration$1261$()))))), _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058registered$1263$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Defined", "world": _world_1, "owner": {$: "../../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Owner", "registry": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $state$058required_declaration$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058with$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058required$1261$(run_clo((_x_0) => {
  return $state$058render$(_x_0);
}))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058write$1261$()));
}

function $consumer$058required_run$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _requiredStatus_0 = _result_0["snd"];
  return $consumer$058required_after$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, ($consumer$058snapshot$1262$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058run_latest$1262$(_app_0, _args_0) {
  const _world_0 = _app_0["world"];
  const _t_0 = _app_0["owners"];
  const _owners_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _token_0 = _t_1["token"];
  const _fields_0 = _t_1["fields"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1262$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1262$(_token_0, _fields_0)));
}

function $consumer$058physical_returned$1262$(_owners_0, _recipe_0, _debug_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _physical_0 = _result_0["snd"];
  return $consumer$058snap_returned$1262$(_physical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1262$({$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1263$({$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1261$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _retained_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1261$(_kind_0, _access_0, _retained_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1263$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1263$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1263$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1263$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058selected$1260$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(($state$058slot_lens$1260$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058viewed$1260$(_rest_0, ($state$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1262$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $state$058slot_lens$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1260$();
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1260$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _part_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1260$(_rest_0, ($state$058count$(_part_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1266$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $state$058counter_lens$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restored$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replacing$1260$(_replacement_0, _result_0) {
  const _rest_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1263$(($state$058counter_lens$1260$())))(_rest_0)(_replacement_0), "snd": _old_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1261$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1261$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058required$1260$(_render_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058built$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058required$1260$(_x_0);
}), _render_0);
}

function $consumer$058required_after$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _requiredAfter_0 = _result_0["snd"];
  return $consumer$058final$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, _requiredAfter_0, ($consumer$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1260$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _slot_0 = _result_0["slot"];
  const _clauses_0 = _result_0["clauses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1260$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1260$(_token_0, _fields_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1260$(_fields_0);
}

function $consumer$058snap_returned$1260$(_physical_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _physical_0, "right": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1260$(_world_0, ($consumer$058fold2$1260$())(_owners_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1260$(_kind_0, _access_0, _retained_0) {
  if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind") {
    return {$: "Nil"};
  } else if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.EventKind") {
    return _retained_0;
  } else {
    const _mode_0 = _kind_0["mode"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _access_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1261$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058observer$1260$(($state$058optional_declaration$1260$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1261$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1261$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $dump$058owners_returned$(_sibling_0, _previous_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (",owners=" + _text_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _sibling_0, "right": _owners_0}, "snd": (_previous_0 + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058selected$1261$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1267$(($state$058slot_lens$1261$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058viewed$1261$(_rest_0, ($state$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1269$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $state$058slot_lens$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1262$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1261$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _part_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1261$(_rest_0, ($state$058count$(_part_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12612$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $state$058counter_lens$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1263$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058restored$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058replacing$1261$(_replacement_0, _result_0) {
  const _rest_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12610$(($state$058counter_lens$1261$())))(_rest_0)(_replacement_0), "snd": _old_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1263$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1265$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058required$1261$(_render_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058built$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058required$1261$(_x_0);
}), _render_0);
}

function $consumer$058required_after$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _requiredAfter_0 = _result_0["snd"];
  return $consumer$058final$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, _requiredAfter_0, ($consumer$058snapshot$1262$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058restored$1262$(_world_0, _owners_0, _recipe_0, _debug_0, _args_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _slot_0 = _result_0["slot"];
  const _clauses_0 = _result_0["clauses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1262$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restore_component$1262$(_token_0, _fields_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1262$(_fields_0);
}

function $consumer$058snap_returned$1262$(_physical_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _physical_0, "right": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1262$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1262$(_world_0, ($consumer$058fold2$1261$())(_owners_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1263$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1263$({$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1261$(_kind_0, _access_0, _retained_0) {
  if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind") {
    return {$: "Nil"};
  } else if (_kind_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.EventKind") {
    return _retained_0;
  } else {
    const _mode_0 = _kind_0["mode"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1261$(_mode_0, _access_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1263$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1263$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058observer$1261$(($state$058optional_declaration$1261$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1263$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058viewed$1260$(_rest_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(($state$058slot_lens$1260$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": _owner_0}), "snd": {$: "Some", "value": _value_0}};
}

function $state$058view$(_array_0) {
  return $state$058array_first$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1260$(_rest_0, _result_0) {
  const _part_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1263$(($state$058counter_lens$1260$())))(_rest_0)(_part_0), "snd": _value_0};
}

function $state$058count$(_array_0) {
  return {$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1263$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058required$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1262$(_world_0);
}

function $consumer$058final$1260$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, _requiredAfter_0, _result_0) {
  const _requiredRepeated_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "consumer.Report", "initial": _initial_0, "optionalRegistered": _optionalRegistered_0, "optionalStatus": _optionalStatus_0, "optionalAfter": _optionalAfter_0, "optionalRepeated": _optionalRepeated_0, "requiredRegistered": _requiredRegistered_0, "requiredStatus": _requiredStatus_0, "requiredAfter": _requiredAfter_0, "requiredRepeated": _requiredRepeated_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1260$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _registry_0 = _t_0["fst"];
  const _status_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1260$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1262$(_slot_0, _clauses_0, _registry_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _output_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Succeeded", "output": _output_0}}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Failed", "error": _error_0}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "Tuple", "fst": _registry_1, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1260$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-system.Owner", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "slot": _slot_0, "clauses": _clauses_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1260$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1260$(_owners_0, _fields_0, ($consumer$058observe2$1260$())(_world_0));
}

function $consumer$058fold2$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _access_0) {
  if (_access_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _name_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": _name_0, "mode": _mode_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058presenter$1260$(($state$058optional_declaration$1260$())))(_value_0);
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058name$1260$(($state$058optional_declaration$1260$())));
  const _x_2 = ("=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _value_0, "rendered": {$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058observer$1260$(_declaration_0) {
  const _observe_0 = _declaration_0["observe"];
  return _observe_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1267$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058viewed$1261$(_rest_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1267$(($state$058slot_lens$1261$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": _owner_0}), "snd": {$: "Some", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1262$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1263$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1261$(_rest_0, _result_0) {
  const _part_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12610$(($state$058counter_lens$1261$())))(_rest_0)(_part_0), "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058left_lens$1263$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1264$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12610$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058required$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1266$(_world_0);
}

function $consumer$058final$1261$(_factory_0, _initial_0, _optionalRegistered_0, _optionalStatus_0, _optionalAfter_0, _optionalRepeated_0, _requiredRegistered_0, _requiredStatus_0, _requiredAfter_0, _result_0) {
  const _requiredRepeated_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "consumer.Report", "initial": _initial_0, "optionalRegistered": _optionalRegistered_0, "optionalStatus": _optionalStatus_0, "optionalAfter": _optionalAfter_0, "optionalRepeated": _optionalRepeated_0, "requiredRegistered": _requiredRegistered_0, "requiredStatus": _requiredStatus_0, "requiredAfter": _requiredAfter_0, "requiredRepeated": _requiredRepeated_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058returned$1262$(_owners_0, _recipe_0, _debug_0, _slot_0, _clauses_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _registry_0 = _t_0["fst"];
  const _status_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1262$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1266$(_slot_0, _clauses_0, _registry_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058completed$1262$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _output_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Succeeded", "output": _output_0}}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "Tuple", "fst": _registry_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Failed", "error": _error_0}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "Tuple", "fst": _registry_1, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058restored_registry$1262$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-system.Owner", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "slot": _slot_0, "clauses": _clauses_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1262$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1262$(_owners_0, _fields_0, ($consumer$058observe2$1261$())(_world_0));
}

function $consumer$058fold2$1261$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1262$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1261$(_mode_0, _access_0) {
  if (_access_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _name_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": _name_0, "mode": _mode_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1261$(_mode_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058presenter$1261$(($state$058optional_declaration$1261$())))(_value_0);
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058name$1261$(($state$058optional_declaration$1261$())));
  const _x_2 = ("=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _value_0, "rendered": {$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058observer$1261$(_declaration_0) {
  const _observe_0 = _declaration_0["observe"];
  return _observe_0;
}

function $state$058array_first$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _first_0 = _result_0["snd"];
  return $state$058array_second$(_first_0, {$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1260$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1260$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1261$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1261$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1262$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1262$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058availability$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1260$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}}, "recipe": _recipe_0, "debug": _debug_0}, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1262$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1260$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_fields_0)), "right": _view_0}}};
}

function $consumer$058observe2$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1260$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1260$(($consumer$058fold1$1260$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1261$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, ($consumer$058runner1$1260$())(_world_0)(_args_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058name$1260$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058names$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(_declaration_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058presenter$1260$(_declaration_0) {
  const _render_0 = _declaration_0["render"];
  return _render_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1263$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1263$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1263$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1264$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1264$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1265$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1266$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058availability$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045optional$045resource$045run$058repacked$1262$(_world_0, _owners_0, _recipe_0, _debug_0, _status_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}}, "recipe": _recipe_0, "debug": _debug_0}, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1266$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1262$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1262$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1262$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_fields_0)), "right": _view_0}}};
}

function $consumer$058observe2$1261$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1262$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1262$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1262$(($consumer$058fold1$1261$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1263$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1263$(_registry_0, ($consumer$058runner1$1261$())(_world_0)(_args_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058name$1261$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058names$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(_declaration_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058presenter$1261$(_declaration_0) {
  const _render_0 = _declaration_0["render"];
  return _render_0;
}

function $state$058array_second$(_first_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _second_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _second_0, "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1260$(_rest_0, _part_0) {
  const _outerRest_0 = _rest_0["fst"];
  const _innerRest_0 = _rest_0["snd"];
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1260$())))(_outerRest_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1260$())))(_innerRest_0)(_part_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1261$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058right_lens$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1262$(_rest_0, _part_0) {
  const _outerRest_0 = _rest_0["fst"];
  const _innerRest_0 = _rest_0["snd"];
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058right_lens$1260$())))(_outerRest_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1261$())))(_innerRest_0)(_part_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058availability$1260$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058slot_available$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1262$(($state$058slot_lens$1260$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1260$(($consumer$058observe1$1260$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1260$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1260$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1261$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058runner1$1260$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1261$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058names$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _t_1 = _clauses_0["tail"];
    if (_t_1.$ === "Nil") {
      return _name_0;
    } else {
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058names$1260$(_t_1));
      const _x_1 = ("," + _x_0);
      return (_name_0 + _x_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1263$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1263$(_rest_0, _part_0) {
  const _outerRest_0 = _rest_0["fst"];
  const _innerRest_0 = _rest_0["snd"];
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1261$())))(_outerRest_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1263$())))(_innerRest_0)(_part_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1264$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12610$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058right_lens$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1265$(_rest_0, _part_0) {
  const _outerRest_0 = _rest_0["fst"];
  const _innerRest_0 = _rest_0["snd"];
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12612$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058right_lens$1261$())))(_outerRest_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1261$())))(_innerRest_0)(_part_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058availability$1261$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058slot_available$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1269$(($state$058slot_lens$1261$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1262$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1262$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1262$(($consumer$058observe1$1261$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1262$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1262$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1263$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058runner1$1261$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1263$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058names$1261$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _t_1 = _clauses_0["tail"];
    if (_t_1.$ === "Nil") {
      return _name_0;
    } else {
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058names$1261$(_t_1));
      const _x_1 = ("," + _x_0);
      return (_name_0 + _x_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1260$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _middle_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1260$())))(_middle_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1261$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1260$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_take$1260$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_put$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1261$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1262$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1260$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1260$({$: "../../../../../../../bendvy/src/ecs/owner-product.Left"}, _x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1260$({$: "../../../../../../../bendvy/src/ecs/owner-product.Left"}, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1261$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _middle_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1261$())))(_middle_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1264$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058right_lens$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1262$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1265$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1266$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1261$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1261$({$: "../../../../../../../bendvy/src/ecs/owner-product.Left"}, _x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1261$({$: "../../../../../../../bendvy/src/ecs/owner-product.Left"}, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058slot_available$1260$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(($state$058slot_lens$1260$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}), "snd": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(($state$058payload$1260$()))), "tail": {$: "Nil"}}};
  } else {
    const _owner_0 = _t_0["owner"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(($state$058slot_lens$1260$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": _owner_0}), "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1260$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1260$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1260$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1261$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1261$(_args_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058preflight$1260$(($state$058optional_declaration$1260$()), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1263$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _middle_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1263$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1263$())))(_middle_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1268$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1261$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_take$1261$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_put$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1268$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1269$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1263$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1262$({$: "../../../../../../../bendvy/src/ecs/owner-product.Left"}, _x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1262$({$: "../../../../../../../bendvy/src/ecs/owner-product.Left"}, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1264$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _middle_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1264$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1261$())))(_middle_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12610$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058right_lens$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1265$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12612$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$058slot_available$1261$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1267$(($state$058slot_lens$1261$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Missing"}), "snd": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(($state$058payload$1261$()))), "tail": {$: "Nil"}}};
  } else {
    const _owner_0 = _t_0["owner"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1267$(($state$058slot_lens$1261$())))(_rest_0)({$: "../../../../../../../bendvy/src/ecs/ordinary-optional-resource.Present", "owner": _owner_0}), "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1262$({$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1262$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1262$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1262$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1262$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1263$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1263$(_args_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058preflight$1261$(($state$058optional_declaration$1261$()), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1260$(_outer_0, _observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _part_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _outer_0, "snd": _inner_0}, "snd": _part_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1260$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_take$1260$(_value_0) {
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_put$1260$(_rest_0, _value_0) {
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1260$(_path_0, _owner_0) {
  if (_path_0.$ === "../../../../../../../bendvy/src/ecs/owner-product.Left") {
    const _left_0 = _owner_0["left"];
    const _right_0 = _owner_0["right"];
    return {$: "Tuple", "fst": _right_0, "snd": _left_0};
  } else {
    const _left_1 = _owner_0["left"];
    const _right_1 = _owner_0["right"];
    return {$: "Tuple", "fst": _left_1, "snd": _right_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1260$(_path_0, _rest_0, _part_0) {
  if (_path_0.$ === "../../../../../../../bendvy/src/ecs/owner-product.Left") {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _part_0, "right": _rest_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _rest_0, "right": _part_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1261$(_outer_0, _observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _part_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _outer_0, "snd": _inner_0}, "snd": _part_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1263$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1262$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1262$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1261$(_path_0, _owner_0) {
  if (_path_0.$ === "../../../../../../../bendvy/src/ecs/owner-product.Left") {
    const _left_0 = _owner_0["left"];
    const _right_0 = _owner_0["right"];
    return {$: "Tuple", "fst": _right_0, "snd": _left_0};
  } else {
    const _left_1 = _owner_0["left"];
    const _right_1 = _owner_0["right"];
    return {$: "Tuple", "fst": _left_1, "snd": _right_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1261$(_path_0, _rest_0, _part_0) {
  if (_path_0.$ === "../../../../../../../bendvy/src/ecs/owner-product.Left") {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _part_0, "right": _rest_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _rest_0, "right": _part_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1260$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058observer$1260$(($state$058required_declaration$1260$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1260$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1261$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1261$(_world_0, _args_0);
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": _t_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058preflight$1260$(_declaration_0, _world_0) {
  const _required_0 = _declaration_0["required"];
  return run_tail(_required_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1263$(_outer_0, _observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _part_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _outer_0, "snd": _inner_0}, "snd": _part_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1267$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_take$1261$(_value_0) {
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole_put$1261$(_rest_0, _value_0) {
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1262$(_path_0, _owner_0) {
  if (_path_0.$ === "../../../../../../../bendvy/src/ecs/owner-product.Left") {
    const _left_0 = _owner_0["left"];
    const _right_0 = _owner_0["right"];
    return {$: "Tuple", "fst": _right_0, "snd": _left_0};
  } else {
    const _left_1 = _owner_0["left"];
    const _right_1 = _owner_0["right"];
    return {$: "Tuple", "fst": _left_1, "snd": _right_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1262$(_path_0, _rest_0, _part_0) {
  if (_path_0.$ === "../../../../../../../bendvy/src/ecs/owner-product.Left") {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _part_0, "right": _rest_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _rest_0, "right": _part_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1264$(_outer_0, _observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _part_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _outer_0, "snd": _inner_0}, "snd": _part_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058compose$1265$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1265$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1264$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1262$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1262$({$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1262$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_observe$1262$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058observer$1261$(($state$058required_declaration$1261$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1262$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1263$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1263$(_world_0, _args_0);
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": _t_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058preflight$1261$(_declaration_0, _world_0) {
  const _required_0 = _declaration_0["required"];
  return run_tail(_required_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1262$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1261$(_rest_0, _part_0) {
  const _outerRest_0 = _rest_0["fst"];
  const _innerRest_0 = _rest_0["snd"];
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1260$())))(_outerRest_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1262$())))(_innerRest_0)(_part_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058presenter$1260$(($state$058required_declaration$1260$())))(_value_0);
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058name$1260$(($state$058required_declaration$1260$())));
  const _x_2 = ("=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _value_0, "rendered": {$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1261$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_take$1265$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058composed_put$1264$(_rest_0, _part_0) {
  const _outerRest_0 = _rest_0["fst"];
  const _innerRest_0 = _rest_0["snd"];
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$045binding$058whole$1261$())))(_outerRest_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1264$())))(_innerRest_0)(_part_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045observation$058resource_returned$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058presenter$1261$(($state$058required_declaration$1261$())))(_value_0);
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058name$1261$(($state$058required_declaration$1261$())));
  const _x_2 = ("=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _value_0, "rendered": {$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1263$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1263$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1262$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _middle_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1262$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1262$())))(_middle_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1264$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1262$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1260$({$: "../../../../../../../bendvy/src/ecs/owner-product.Right"}, _x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1260$({$: "../../../../../../../bendvy/src/ecs/owner-product.Right"}, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($consumer$058runner2$1260$())(_world_0)(_args_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _output_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1260$(_output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0) {
  return $state$058body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058inward$1265$(_observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _middle_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1265$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1264$())))(_middle_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$12611$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058lens$1264$() {
  return {$: "../../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058take$1262$({$: "../../../../../../../bendvy/src/ecs/owner-product.Right"}, _x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put$1262$({$: "../../../../../../../bendvy/src/ecs/owner-product.Right"}, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1262$(_registry_0, ($consumer$058runner2$1261$())(_world_0)(_args_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _output_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1261$(_output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1263$(_args_0, _ctx_0) {
  return $state$058body$1263$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1262$(_outer_0, _observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _part_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _outer_0, "snd": _inner_0}, "snd": _part_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1265$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058runner2$1260$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1260$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1260$(_output_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $state$058body$1261$(_args_0, _owner_0) {
  return $state$058read$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1261$(_owner_0)));
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058joined$1265$(_outer_0, _observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _part_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _outer_0, "snd": _inner_0}, "snd": _part_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$12611$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058runner2$1261$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1262$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1261$(_output_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $state$058body$1263$(_args_0, _owner_0) {
  return $state$058read$1263$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1263$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1260$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1260$(_args_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058preflight$1260$(($state$058required_declaration$1260$()), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $state$058read$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $state$058counted$1261$(_value_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1261$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058first$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058optional_declaration$1260$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058runner$1262$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1262$(_args_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058preflight$1261$(($state$058required_declaration$1261$()), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $state$058read$1263$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $state$058counted$1263$(_value_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1263$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1263$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058first$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058optional_declaration$1261$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1260$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1260$(_world_0, _args_0);
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": _t_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $state$058counted$1261$(_value_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1261$(_owner_0, [((_n_0 + 1) >>> 0)])), "snd": {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1261$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058optional_declaration$1260$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1260$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058first$1260$(_cap_0) {
  const _a_0 = _cap_0["first"];
  return _a_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(_value_0) {
  const _grant_0 = _value_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045system$058preflighted$1262$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1262$(_world_0, _args_0);
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": _t_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $state$058counted$1263$(_value_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1263$(_owner_0, [((_n_0 + 1) >>> 0)])), "snd": {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1263$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058optional_declaration$1261$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1261$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058first$1261$(_cap_0) {
  const _a_0 = _cap_0["first"];
  return _a_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(_value_0) {
  const _grant_0 = _value_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1260$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1261$(_owner_0, _replacement_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058optional_declaration$1260$())))))))))(_owner_0), _replacement_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get_field$1260$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1260$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1260$(_cap_0) {
  const _b_0 = _cap_0["second"];
  return _b_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1262$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1262$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1263$(_owner_0, _replacement_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058optional_declaration$1261$())))))))))(_owner_0), _replacement_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get_field$1261$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1261$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1261$(_cap_0) {
  const _b_0 = _cap_0["second"];
  return _b_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0) {
  return $state$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set_field$1260$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1262$(_args_0, _ctx_0) {
  return $state$058body$1262$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set_field$1261$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $state$058body$1260$(_args_0, _owner_0) {
  return $state$058read$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $state$058body$1262$(_args_0, _owner_0) {
  return $state$058read$1262$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1262$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $state$058read$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $state$058counted$1260$(_value_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058first$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058required_declaration$1260$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $state$058read$1262$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $state$058counted$1262$(_value_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1262$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1262$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058first$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058required_declaration$1261$()))))))))), _owner_0);
}

function $state$058counted$1260$(_value_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1260$(_owner_0, [((_n_0 + 1) >>> 0)])), "snd": {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058required_declaration$1260$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $state$058counted$1262$(_value_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1262$(_owner_0, [((_n_0 + 1) >>> 0)])), "snd": {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get$1262$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058get_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058required_declaration$1261$()))))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1260$(_owner_0, _replacement_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1260$(($state$058required_declaration$1260$())))))))))(_owner_0), _replacement_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set$1262$(_owner_0, _replacement_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058set_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058second$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045optional$045resource$045declaration$058ordinary$1261$(($state$058required_declaration$1261$())))))))))(_owner_0), _replacement_0);
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,1,0,0,2,0,0,11,1,339,7,1,2,1,0,0,1,2,0,2,1,0,26,1,11,7,1,1,3,0,9,0,0,51,1,52,7,254,10,52,16,52,22,282,30,254,33,282,41,282,4,7,0,1,4,0,2,0,0,51,1,63,7,0,2,5,0,0,0,6,0,1,0,1,76,7,0,1,7,0,2,0,0,87,1,196,7,1,2,8,0,0,1,9,0,2,1,0,102,1,87,7,1,1,10,0,7,0,0,123,1,123,2,51,3,124,4,123,5,51,6,139,0,7,1,2,11,0,0,1,12,0,2,1,0,51,1,124,7,1,2,13,0,0,1,14,0,2,1,0,154,1,139,7,1,1,15,0,2,0,0,51,1,165,7,0,7,16,0,0,0,17,0,0,0,18,0,0,0,19,0,0,0,20,0,0,0,21,0,0,0,22,0,0,0,7,0,1,23,0,2,0,0,207,2,124,7,0,1,24,0,2,0,0,218,0,225,7,0,1,25,0,0,0,7,0,2,26,0,0,0,27,0,1,0,1,238,7,1,2,28,0,0,1,29,0,2,1,0,253,1,238,0,7,0,3,30,0,1,0,1,225,31,0,1,0,1,273,32,0,0,0,7,0,1,33,0,1,0,0,124,7,0,1,34,0,2,0,0,51,1,293,7,0,2,35,0,0,0,36,0,1,0,1,306,7,0,1,37,0,2,0,0,87,1,317,7,0,1,38,0,2,0,0,328,4,124,7,0,1,39,0,2,0,0,207,2,225,7,1,2,40,0,0,1,41,0,2,1,0,354,1,339,7,1,1,42,0,9,0,0,51,1,379,7,254,10,379,16,379,22,487,30,254,33,487,41,487,7,0,1,43,0,2,0,0,51,1,390,7,0,2,44,0,0,0,45,0,1,0,1,403,7,0,1,46,0,2,0,0,414,1,476,7,1,2,47,0,0,1,48,0,2,1,0,429,1,414,7,1,1,49,0,7,0,0,123,1,123,2,51,3,124,4,123,5,51,6,450,7,1,2,50,0,0,1,51,0,2,1,0,465,1,450,7,1,1,52,0,2,0,0,51,1,165,7,0,1,53,0,2,0,0,207,2,124,7,0,1,54,0,2,0,0,51,1,498,7,0,2,55,0,0,0,56,0,1,0,1,511,7,0,1,57,0,2,0,0,414,1,522,7,0,1,58,0,2,0,0,533,4,124,7,0,1,59,0,2,0,0,207,2,225],["../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","consumer.Report","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","None","Some","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding","Nil","Con","Nil","Con","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Write","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Optional","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.With","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Without","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Added","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Changed","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Unit","None","Some","Nil","Con","../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Succeeded","../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.Failed","../../../../../../../bendvy/src/ecs/ordinary-app-optional-resource-run.RegistrationRejected","../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","None","Some","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","consumer.Report","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","None","Some","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding","Nil","Con","../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","None","Some","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product"]]);