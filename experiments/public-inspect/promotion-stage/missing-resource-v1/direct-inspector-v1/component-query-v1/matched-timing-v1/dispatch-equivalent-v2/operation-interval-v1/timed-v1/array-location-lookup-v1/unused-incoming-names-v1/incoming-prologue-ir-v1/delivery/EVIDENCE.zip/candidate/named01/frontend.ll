; ModuleID = '/workspace/formal-proofs/bendvy-worktrees/observable-query-boundaries/experiments/public-inspect/promotion-stage/missing-resource-v1/direct-inspector-v1/component-query-v1/matched-timing-v1/dispatch-equivalent-v2/operation-interval-v1/timed-v1/array-location-lookup-v1/unused-incoming-names-v1/incoming-prologue-ir-v1/named.c'
source_filename = "/workspace/formal-proofs/bendvy-worktrees/observable-query-boundaries/experiments/public-inspect/promotion-stage/missing-resource-v1/direct-inspector-v1/component-query-v1/matched-timing-v1/dispatch-equivalent-v2/operation-interval-v1/timed-v1/array-location-lookup-v1/unused-incoming-names-v1/incoming-prologue-ir-v1/named.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

%struct.Env = type { ptr, ptr }

@__const.main.mem = private unnamed_addr constant [2 x i64] [i64 11, i64 13], align 8
@.str = private unnamed_addr constant [9 x i8] c"PASS ABI\00", align 1

; Function Attrs: nounwind uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [2 x i64], align 8
  %3 = alloca ptr, align 8
  %4 = alloca %struct.Env, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.lifetime.start.p0(i64 16, ptr %2) #5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 @__const.main.mem, i64 16, i1 false)
  call void @llvm.lifetime.start.p0(i64 8, ptr %3) #5
  %7 = getelementptr inbounds [2 x i64], ptr %2, i64 0, i64 0
  store ptr %7, ptr %3, align 8, !tbaa !6
  call void @llvm.lifetime.start.p0(i64 16, ptr %4) #5
  %8 = getelementptr inbounds %struct.Env, ptr %4, i32 0, i32 0
  %9 = getelementptr inbounds [2 x i64], ptr %2, i64 0, i64 0
  store ptr %9, ptr %8, align 8, !tbaa !10
  %10 = getelementptr inbounds %struct.Env, ptr %4, i32 0, i32 1
  %11 = getelementptr inbounds [2 x i64], ptr %2, i64 0, i64 0
  store ptr %11, ptr %10, align 8, !tbaa !12
  call void @llvm.lifetime.start.p0(i64 8, ptr %5) #5
  store ptr @direct, ptr %5, align 8, !tbaa !6
  %12 = load ptr, ptr %3, align 8, !tbaa !6
  %13 = load [2 x i64], ptr %4, align 8
  %14 = call preserve_nonecc i64 @direct([2 x i64] %13, ptr noundef %12, i32 noundef 0, i32 noundef 0, i64 noundef 3, i64 noundef 5, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0)
  %15 = icmp ne i64 %14, 8
  br i1 %15, label %16, label %17

16:                                               ; preds = %0
  store i32 1, ptr %1, align 4
  store i32 1, ptr %6, align 4
  br label %38

17:                                               ; preds = %0
  %18 = load ptr, ptr %5, align 8, !tbaa !6
  %19 = load ptr, ptr %3, align 8, !tbaa !6
  %20 = load [2 x i64], ptr %4, align 8
  %21 = call preserve_nonecc i64 %18([2 x i64] %20, ptr noundef %19, i32 noundef 0, i32 noundef 0, i64 noundef 3, i64 noundef 5, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0)
  %22 = icmp ne i64 %21, 8
  br i1 %22, label %23, label %24

23:                                               ; preds = %17
  store i32 2, ptr %1, align 4
  store i32 1, ptr %6, align 4
  br label %38

24:                                               ; preds = %17
  %25 = load ptr, ptr %3, align 8, !tbaa !6
  %26 = load [2 x i64], ptr %4, align 8
  %27 = call preserve_nonecc i64 @bridge([2 x i64] %26, ptr noundef %25, i32 noundef 0, i32 noundef 0, i64 noundef 3, i64 noundef 5, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0)
  %28 = icmp ne i64 %27, 8
  br i1 %28, label %29, label %30

29:                                               ; preds = %24
  store i32 3, ptr %1, align 4
  store i32 1, ptr %6, align 4
  br label %38

30:                                               ; preds = %24
  %31 = load ptr, ptr %3, align 8, !tbaa !6
  %32 = load [2 x i64], ptr %4, align 8
  %33 = call preserve_nonecc i64 @frame([2 x i64] %32, ptr noundef %31, i32 noundef 0, i32 noundef 0, i64 noundef 3, i64 noundef 5, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0)
  %34 = icmp ne i64 %33, 27
  br i1 %34, label %35, label %36

35:                                               ; preds = %30
  store i32 4, ptr %1, align 4
  store i32 1, ptr %6, align 4
  br label %38

36:                                               ; preds = %30
  %37 = call i32 @puts(ptr noundef @.str)
  store i32 0, ptr %1, align 4
  store i32 1, ptr %6, align 4
  br label %38

38:                                               ; preds = %36, %35, %29, %23, %16
  call void @llvm.lifetime.end.p0(i64 8, ptr %5) #5
  call void @llvm.lifetime.end.p0(i64 16, ptr %4) #5
  call void @llvm.lifetime.end.p0(i64 8, ptr %3) #5
  call void @llvm.lifetime.end.p0(i64 16, ptr %2) #5
  %39 = load i32, ptr %1, align 4
  ret i32 %39
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal preserve_nonecc i64 @direct([2 x i64] %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i64 noundef %4, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45) #3 {
  %47 = alloca %struct.Env, align 8
  %48 = alloca ptr, align 8
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i64, align 8
  %52 = alloca i64, align 8
  %53 = alloca i64, align 8
  %54 = alloca i64, align 8
  %55 = alloca i64, align 8
  %56 = alloca i64, align 8
  %57 = alloca i64, align 8
  %58 = alloca i64, align 8
  %59 = alloca i64, align 8
  %60 = alloca i64, align 8
  %61 = alloca i64, align 8
  %62 = alloca i64, align 8
  %63 = alloca i64, align 8
  %64 = alloca i64, align 8
  %65 = alloca i64, align 8
  %66 = alloca i64, align 8
  %67 = alloca i64, align 8
  %68 = alloca i64, align 8
  %69 = alloca i64, align 8
  %70 = alloca i64, align 8
  %71 = alloca i64, align 8
  %72 = alloca i64, align 8
  %73 = alloca i64, align 8
  %74 = alloca i64, align 8
  %75 = alloca i64, align 8
  %76 = alloca i64, align 8
  %77 = alloca i64, align 8
  %78 = alloca i64, align 8
  %79 = alloca i64, align 8
  %80 = alloca i64, align 8
  %81 = alloca i64, align 8
  %82 = alloca i64, align 8
  %83 = alloca i64, align 8
  %84 = alloca i64, align 8
  %85 = alloca i64, align 8
  %86 = alloca i64, align 8
  %87 = alloca i64, align 8
  %88 = alloca i64, align 8
  %89 = alloca i64, align 8
  %90 = alloca i64, align 8
  %91 = alloca i64, align 8
  %92 = alloca i64, align 8
  %93 = alloca i64, align 8
  %94 = alloca i64, align 8
  %95 = alloca i64, align 8
  store [2 x i64] %0, ptr %47, align 8
  store ptr %1, ptr %48, align 8, !tbaa !6
  store i32 %2, ptr %49, align 4, !tbaa !13
  store i32 %3, ptr %50, align 4, !tbaa !13
  store i64 %4, ptr %51, align 8, !tbaa !15
  store i64 %5, ptr %52, align 8, !tbaa !15
  store i64 %6, ptr %53, align 8, !tbaa !15
  store i64 %7, ptr %54, align 8, !tbaa !15
  store i64 %8, ptr %55, align 8, !tbaa !15
  store i64 %9, ptr %56, align 8, !tbaa !15
  store i64 %10, ptr %57, align 8, !tbaa !15
  store i64 %11, ptr %58, align 8, !tbaa !15
  store i64 %12, ptr %59, align 8, !tbaa !15
  store i64 %13, ptr %60, align 8, !tbaa !15
  store i64 %14, ptr %61, align 8, !tbaa !15
  store i64 %15, ptr %62, align 8, !tbaa !15
  store i64 %16, ptr %63, align 8, !tbaa !15
  store i64 %17, ptr %64, align 8, !tbaa !15
  store i64 %18, ptr %65, align 8, !tbaa !15
  store i64 %19, ptr %66, align 8, !tbaa !15
  store i64 %20, ptr %67, align 8, !tbaa !15
  store i64 %21, ptr %68, align 8, !tbaa !15
  store i64 %22, ptr %69, align 8, !tbaa !15
  store i64 %23, ptr %70, align 8, !tbaa !15
  store i64 %24, ptr %71, align 8, !tbaa !15
  store i64 %25, ptr %72, align 8, !tbaa !15
  store i64 %26, ptr %73, align 8, !tbaa !15
  store i64 %27, ptr %74, align 8, !tbaa !15
  store i64 %28, ptr %75, align 8, !tbaa !15
  store i64 %29, ptr %76, align 8, !tbaa !15
  store i64 %30, ptr %77, align 8, !tbaa !15
  store i64 %31, ptr %78, align 8, !tbaa !15
  store i64 %32, ptr %79, align 8, !tbaa !15
  store i64 %33, ptr %80, align 8, !tbaa !15
  store i64 %34, ptr %81, align 8, !tbaa !15
  store i64 %35, ptr %82, align 8, !tbaa !15
  store i64 %36, ptr %83, align 8, !tbaa !15
  store i64 %37, ptr %84, align 8, !tbaa !15
  store i64 %38, ptr %85, align 8, !tbaa !15
  store i64 %39, ptr %86, align 8, !tbaa !15
  store i64 %40, ptr %87, align 8, !tbaa !15
  store i64 %41, ptr %88, align 8, !tbaa !15
  store i64 %42, ptr %89, align 8, !tbaa !15
  store i64 %43, ptr %90, align 8, !tbaa !15
  store i64 %44, ptr %91, align 8, !tbaa !15
  store i64 %45, ptr %92, align 8, !tbaa !15
  call void @llvm.lifetime.start.p0(i64 8, ptr %93) #5
  %96 = load i64, ptr %51, align 8, !tbaa !15
  store i64 %96, ptr %93, align 8, !tbaa !15
  call void @llvm.lifetime.start.p0(i64 8, ptr %94) #5
  %97 = load i64, ptr %52, align 8, !tbaa !15
  store i64 %97, ptr %94, align 8, !tbaa !15
  call void @llvm.lifetime.start.p0(i64 8, ptr %95) #5
  %98 = load i64, ptr %93, align 8, !tbaa !15
  %99 = load i64, ptr %94, align 8, !tbaa !15
  %100 = add i64 %98, %99
  store i64 %100, ptr %95, align 8, !tbaa !15
  %101 = load i64, ptr %95, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(i64 8, ptr %95) #5
  call void @llvm.lifetime.end.p0(i64 8, ptr %94) #5
  call void @llvm.lifetime.end.p0(i64 8, ptr %93) #5
  ret i64 %101
}

; Function Attrs: noinline nounwind uwtable
define internal preserve_nonecc i64 @bridge([2 x i64] %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i64 noundef %4, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45) #3 {
  %47 = alloca %struct.Env, align 8
  %48 = alloca ptr, align 8
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i64, align 8
  %52 = alloca i64, align 8
  %53 = alloca i64, align 8
  %54 = alloca i64, align 8
  %55 = alloca i64, align 8
  %56 = alloca i64, align 8
  %57 = alloca i64, align 8
  %58 = alloca i64, align 8
  %59 = alloca i64, align 8
  %60 = alloca i64, align 8
  %61 = alloca i64, align 8
  %62 = alloca i64, align 8
  %63 = alloca i64, align 8
  %64 = alloca i64, align 8
  %65 = alloca i64, align 8
  %66 = alloca i64, align 8
  %67 = alloca i64, align 8
  %68 = alloca i64, align 8
  %69 = alloca i64, align 8
  %70 = alloca i64, align 8
  %71 = alloca i64, align 8
  %72 = alloca i64, align 8
  %73 = alloca i64, align 8
  %74 = alloca i64, align 8
  %75 = alloca i64, align 8
  %76 = alloca i64, align 8
  %77 = alloca i64, align 8
  %78 = alloca i64, align 8
  %79 = alloca i64, align 8
  %80 = alloca i64, align 8
  %81 = alloca i64, align 8
  %82 = alloca i64, align 8
  %83 = alloca i64, align 8
  %84 = alloca i64, align 8
  %85 = alloca i64, align 8
  %86 = alloca i64, align 8
  %87 = alloca i64, align 8
  %88 = alloca i64, align 8
  %89 = alloca i64, align 8
  %90 = alloca i64, align 8
  %91 = alloca i64, align 8
  %92 = alloca i64, align 8
  store [2 x i64] %0, ptr %47, align 8
  store ptr %1, ptr %48, align 8, !tbaa !6
  store i32 %2, ptr %49, align 4, !tbaa !13
  store i32 %3, ptr %50, align 4, !tbaa !13
  store i64 %4, ptr %51, align 8, !tbaa !15
  store i64 %5, ptr %52, align 8, !tbaa !15
  store i64 %6, ptr %53, align 8, !tbaa !15
  store i64 %7, ptr %54, align 8, !tbaa !15
  store i64 %8, ptr %55, align 8, !tbaa !15
  store i64 %9, ptr %56, align 8, !tbaa !15
  store i64 %10, ptr %57, align 8, !tbaa !15
  store i64 %11, ptr %58, align 8, !tbaa !15
  store i64 %12, ptr %59, align 8, !tbaa !15
  store i64 %13, ptr %60, align 8, !tbaa !15
  store i64 %14, ptr %61, align 8, !tbaa !15
  store i64 %15, ptr %62, align 8, !tbaa !15
  store i64 %16, ptr %63, align 8, !tbaa !15
  store i64 %17, ptr %64, align 8, !tbaa !15
  store i64 %18, ptr %65, align 8, !tbaa !15
  store i64 %19, ptr %66, align 8, !tbaa !15
  store i64 %20, ptr %67, align 8, !tbaa !15
  store i64 %21, ptr %68, align 8, !tbaa !15
  store i64 %22, ptr %69, align 8, !tbaa !15
  store i64 %23, ptr %70, align 8, !tbaa !15
  store i64 %24, ptr %71, align 8, !tbaa !15
  store i64 %25, ptr %72, align 8, !tbaa !15
  store i64 %26, ptr %73, align 8, !tbaa !15
  store i64 %27, ptr %74, align 8, !tbaa !15
  store i64 %28, ptr %75, align 8, !tbaa !15
  store i64 %29, ptr %76, align 8, !tbaa !15
  store i64 %30, ptr %77, align 8, !tbaa !15
  store i64 %31, ptr %78, align 8, !tbaa !15
  store i64 %32, ptr %79, align 8, !tbaa !15
  store i64 %33, ptr %80, align 8, !tbaa !15
  store i64 %34, ptr %81, align 8, !tbaa !15
  store i64 %35, ptr %82, align 8, !tbaa !15
  store i64 %36, ptr %83, align 8, !tbaa !15
  store i64 %37, ptr %84, align 8, !tbaa !15
  store i64 %38, ptr %85, align 8, !tbaa !15
  store i64 %39, ptr %86, align 8, !tbaa !15
  store i64 %40, ptr %87, align 8, !tbaa !15
  store i64 %41, ptr %88, align 8, !tbaa !15
  store i64 %42, ptr %89, align 8, !tbaa !15
  store i64 %43, ptr %90, align 8, !tbaa !15
  store i64 %44, ptr %91, align 8, !tbaa !15
  store i64 %45, ptr %92, align 8, !tbaa !15
  %93 = load ptr, ptr %48, align 8, !tbaa !6
  %94 = load i32, ptr %49, align 4, !tbaa !13
  %95 = load i32, ptr %50, align 4, !tbaa !13
  %96 = load i64, ptr %51, align 8, !tbaa !15
  %97 = load i64, ptr %52, align 8, !tbaa !15
  %98 = load i64, ptr %53, align 8, !tbaa !15
  %99 = load i64, ptr %54, align 8, !tbaa !15
  %100 = load i64, ptr %55, align 8, !tbaa !15
  %101 = load i64, ptr %56, align 8, !tbaa !15
  %102 = load i64, ptr %57, align 8, !tbaa !15
  %103 = load i64, ptr %58, align 8, !tbaa !15
  %104 = load i64, ptr %59, align 8, !tbaa !15
  %105 = load i64, ptr %60, align 8, !tbaa !15
  %106 = load i64, ptr %61, align 8, !tbaa !15
  %107 = load i64, ptr %62, align 8, !tbaa !15
  %108 = load i64, ptr %63, align 8, !tbaa !15
  %109 = load i64, ptr %64, align 8, !tbaa !15
  %110 = load i64, ptr %65, align 8, !tbaa !15
  %111 = load i64, ptr %66, align 8, !tbaa !15
  %112 = load i64, ptr %67, align 8, !tbaa !15
  %113 = load i64, ptr %68, align 8, !tbaa !15
  %114 = load i64, ptr %69, align 8, !tbaa !15
  %115 = load i64, ptr %70, align 8, !tbaa !15
  %116 = load i64, ptr %71, align 8, !tbaa !15
  %117 = load i64, ptr %72, align 8, !tbaa !15
  %118 = load i64, ptr %73, align 8, !tbaa !15
  %119 = load i64, ptr %74, align 8, !tbaa !15
  %120 = load i64, ptr %75, align 8, !tbaa !15
  %121 = load i64, ptr %76, align 8, !tbaa !15
  %122 = load i64, ptr %77, align 8, !tbaa !15
  %123 = load i64, ptr %78, align 8, !tbaa !15
  %124 = load i64, ptr %79, align 8, !tbaa !15
  %125 = load i64, ptr %80, align 8, !tbaa !15
  %126 = load i64, ptr %81, align 8, !tbaa !15
  %127 = load i64, ptr %82, align 8, !tbaa !15
  %128 = load i64, ptr %83, align 8, !tbaa !15
  %129 = load i64, ptr %84, align 8, !tbaa !15
  %130 = load i64, ptr %85, align 8, !tbaa !15
  %131 = load i64, ptr %86, align 8, !tbaa !15
  %132 = load i64, ptr %87, align 8, !tbaa !15
  %133 = load i64, ptr %88, align 8, !tbaa !15
  %134 = load i64, ptr %89, align 8, !tbaa !15
  %135 = load i64, ptr %90, align 8, !tbaa !15
  %136 = load i64, ptr %91, align 8, !tbaa !15
  %137 = load i64, ptr %92, align 8, !tbaa !15
  %138 = load [2 x i64], ptr %47, align 8
  %139 = musttail call preserve_nonecc i64 @direct([2 x i64] %138, ptr noundef %93, i32 noundef %94, i32 noundef %95, i64 noundef %96, i64 noundef %97, i64 noundef %98, i64 noundef %99, i64 noundef %100, i64 noundef %101, i64 noundef %102, i64 noundef %103, i64 noundef %104, i64 noundef %105, i64 noundef %106, i64 noundef %107, i64 noundef %108, i64 noundef %109, i64 noundef %110, i64 noundef %111, i64 noundef %112, i64 noundef %113, i64 noundef %114, i64 noundef %115, i64 noundef %116, i64 noundef %117, i64 noundef %118, i64 noundef %119, i64 noundef %120, i64 noundef %121, i64 noundef %122, i64 noundef %123, i64 noundef %124, i64 noundef %125, i64 noundef %126, i64 noundef %127, i64 noundef %128, i64 noundef %129, i64 noundef %130, i64 noundef %131, i64 noundef %132, i64 noundef %133, i64 noundef %134, i64 noundef %135, i64 noundef %136, i64 noundef %137)
  ret i64 %139

140:                                              ; No predecessors!
  ret i64 undef
}

; Function Attrs: noinline nounwind uwtable
define internal preserve_nonecc i64 @frame([2 x i64] %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i64 noundef %4, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45) #3 {
  %47 = alloca %struct.Env, align 8
  %48 = alloca ptr, align 8
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i64, align 8
  %52 = alloca i64, align 8
  %53 = alloca i64, align 8
  %54 = alloca i64, align 8
  %55 = alloca i64, align 8
  %56 = alloca i64, align 8
  %57 = alloca i64, align 8
  %58 = alloca i64, align 8
  %59 = alloca i64, align 8
  %60 = alloca i64, align 8
  %61 = alloca i64, align 8
  %62 = alloca i64, align 8
  %63 = alloca i64, align 8
  %64 = alloca i64, align 8
  %65 = alloca i64, align 8
  %66 = alloca i64, align 8
  %67 = alloca i64, align 8
  %68 = alloca i64, align 8
  %69 = alloca i64, align 8
  %70 = alloca i64, align 8
  %71 = alloca i64, align 8
  %72 = alloca i64, align 8
  %73 = alloca i64, align 8
  %74 = alloca i64, align 8
  %75 = alloca i64, align 8
  %76 = alloca i64, align 8
  %77 = alloca i64, align 8
  %78 = alloca i64, align 8
  %79 = alloca i64, align 8
  %80 = alloca i64, align 8
  %81 = alloca i64, align 8
  %82 = alloca i64, align 8
  %83 = alloca i64, align 8
  %84 = alloca i64, align 8
  %85 = alloca i64, align 8
  %86 = alloca i64, align 8
  %87 = alloca i64, align 8
  %88 = alloca i64, align 8
  %89 = alloca i64, align 8
  %90 = alloca i64, align 8
  %91 = alloca i64, align 8
  %92 = alloca i64, align 8
  %93 = alloca i64, align 8
  %94 = alloca i64, align 8
  %95 = alloca i64, align 8
  %96 = alloca i64, align 8
  store [2 x i64] %0, ptr %47, align 8
  store ptr %1, ptr %48, align 8, !tbaa !6
  store i32 %2, ptr %49, align 4, !tbaa !13
  store i32 %3, ptr %50, align 4, !tbaa !13
  store i64 %4, ptr %51, align 8, !tbaa !15
  store i64 %5, ptr %52, align 8, !tbaa !15
  store i64 %6, ptr %53, align 8, !tbaa !15
  store i64 %7, ptr %54, align 8, !tbaa !15
  store i64 %8, ptr %55, align 8, !tbaa !15
  store i64 %9, ptr %56, align 8, !tbaa !15
  store i64 %10, ptr %57, align 8, !tbaa !15
  store i64 %11, ptr %58, align 8, !tbaa !15
  store i64 %12, ptr %59, align 8, !tbaa !15
  store i64 %13, ptr %60, align 8, !tbaa !15
  store i64 %14, ptr %61, align 8, !tbaa !15
  store i64 %15, ptr %62, align 8, !tbaa !15
  store i64 %16, ptr %63, align 8, !tbaa !15
  store i64 %17, ptr %64, align 8, !tbaa !15
  store i64 %18, ptr %65, align 8, !tbaa !15
  store i64 %19, ptr %66, align 8, !tbaa !15
  store i64 %20, ptr %67, align 8, !tbaa !15
  store i64 %21, ptr %68, align 8, !tbaa !15
  store i64 %22, ptr %69, align 8, !tbaa !15
  store i64 %23, ptr %70, align 8, !tbaa !15
  store i64 %24, ptr %71, align 8, !tbaa !15
  store i64 %25, ptr %72, align 8, !tbaa !15
  store i64 %26, ptr %73, align 8, !tbaa !15
  store i64 %27, ptr %74, align 8, !tbaa !15
  store i64 %28, ptr %75, align 8, !tbaa !15
  store i64 %29, ptr %76, align 8, !tbaa !15
  store i64 %30, ptr %77, align 8, !tbaa !15
  store i64 %31, ptr %78, align 8, !tbaa !15
  store i64 %32, ptr %79, align 8, !tbaa !15
  store i64 %33, ptr %80, align 8, !tbaa !15
  store i64 %34, ptr %81, align 8, !tbaa !15
  store i64 %35, ptr %82, align 8, !tbaa !15
  store i64 %36, ptr %83, align 8, !tbaa !15
  store i64 %37, ptr %84, align 8, !tbaa !15
  store i64 %38, ptr %85, align 8, !tbaa !15
  store i64 %39, ptr %86, align 8, !tbaa !15
  store i64 %40, ptr %87, align 8, !tbaa !15
  store i64 %41, ptr %88, align 8, !tbaa !15
  store i64 %42, ptr %89, align 8, !tbaa !15
  store i64 %43, ptr %90, align 8, !tbaa !15
  store i64 %44, ptr %91, align 8, !tbaa !15
  store i64 %45, ptr %92, align 8, !tbaa !15
  call void @llvm.lifetime.start.p0(i64 8, ptr %93) #5
  %97 = load ptr, ptr %48, align 8, !tbaa !6
  %98 = getelementptr inbounds i64, ptr %97, i64 0
  %99 = load i64, ptr %98, align 8, !tbaa !15
  store i64 %99, ptr %93, align 8, !tbaa !15
  call void @llvm.lifetime.start.p0(i64 8, ptr %94) #5
  %100 = load ptr, ptr %48, align 8, !tbaa !6
  %101 = getelementptr inbounds i64, ptr %100, i64 1
  %102 = load i64, ptr %101, align 8, !tbaa !15
  store i64 %102, ptr %94, align 8, !tbaa !15
  call void @llvm.lifetime.start.p0(i64 8, ptr %95) #5
  %103 = load i64, ptr %51, align 8, !tbaa !15
  store i64 %103, ptr %95, align 8, !tbaa !15
  %104 = load ptr, ptr %48, align 8, !tbaa !6
  %105 = getelementptr inbounds i64, ptr %104, i64 2
  store ptr %105, ptr %48, align 8, !tbaa !6
  call void @llvm.lifetime.start.p0(i64 8, ptr %96) #5
  %106 = load i64, ptr %93, align 8, !tbaa !15
  %107 = load i64, ptr %94, align 8, !tbaa !15
  %108 = add i64 %106, %107
  %109 = load i64, ptr %95, align 8, !tbaa !15
  %110 = add i64 %108, %109
  store i64 %110, ptr %96, align 8, !tbaa !15
  %111 = load i64, ptr %96, align 8, !tbaa !15
  call void @llvm.lifetime.end.p0(i64 8, ptr %96) #5
  call void @llvm.lifetime.end.p0(i64 8, ptr %95) #5
  call void @llvm.lifetime.end.p0(i64 8, ptr %94) #5
  call void @llvm.lifetime.end.p0(i64 8, ptr %93) #5
  ret i64 %111
}

declare i32 @puts(ptr noundef) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

attributes #0 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noinline nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #4 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Debian clang version 19.1.7 (3~deb12u1)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"any pointer", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!11, !7, i64 0}
!11 = !{!"", !7, i64 0, !7, i64 8}
!12 = !{!11, !7, i64 8}
!13 = !{!14, !14, i64 0}
!14 = !{!"int", !8, i64 0}
!15 = !{!16, !16, i64 0}
!16 = !{!"long", !8, i64 0}
