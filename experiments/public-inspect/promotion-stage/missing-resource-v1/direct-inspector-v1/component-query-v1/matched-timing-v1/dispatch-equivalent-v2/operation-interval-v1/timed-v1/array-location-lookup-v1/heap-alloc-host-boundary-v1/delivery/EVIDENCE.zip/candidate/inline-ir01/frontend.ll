; ModuleID = '/workspace/formal-proofs/bendvy-worktrees/observable-query-boundaries/experiments/public-inspect/promotion-stage/missing-resource-v1/direct-inspector-v1/component-query-v1/matched-timing-v1/dispatch-equivalent-v2/operation-interval-v1/timed-v1/array-location-lookup-v1/heap-alloc-host-boundary-v1/inline.c'
source_filename = "/workspace/formal-proofs/bendvy-worktrees/observable-query-boundaries/experiments/public-inspect/promotion-stage/missing-resource-v1/direct-inspector-v1/component-query-v1/matched-timing-v1/dispatch-equivalent-v2/operation-interval-v1/timed-v1/array-location-lookup-v1/heap-alloc-host-boundary-v1/inline.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

@requested_class = internal global i32 2, align 4
@fixed_entry = internal global ptr @case_fixed, align 8
@miss_calls = internal unnamed_addr global i32 0, align 4
@.str = private unnamed_addr constant [23 x i8] c"hot %llu %llu %llu %u\0A\00", align 1
@dynamic_entry = internal global ptr @case_dynamic, align 8
@miss_cls = internal unnamed_addr global i32 0, align 4
@miss_mem = internal unnamed_addr global ptr null, align 8
@miss_alc = internal unnamed_addr global ptr null, align 8
@.str.1 = private unnamed_addr constant [24 x i8] c"miss %llu %llu %llu %u\0A\00", align 1

; Function Attrs: nounwind uwtable
define dso_local range(i32 0, 3) i32 @main() local_unnamed_addr #0 {
  %1 = alloca [64 x i64], align 8
  %2 = alloca [96 x i64], align 8
  %3 = alloca [64 x i64], align 8
  %4 = alloca [96 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 512, ptr nonnull %1) #8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(512) %1, i8 0, i64 512, i1 false)
  call void @llvm.lifetime.start.p0(i64 768, ptr nonnull %2) #8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(768) %2, i8 0, i64 768, i1 false)
  call void @llvm.lifetime.start.p0(i64 512, ptr nonnull %3) #8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(512) %3, i8 0, i64 512, i1 false)
  call void @llvm.lifetime.start.p0(i64 768, ptr nonnull %4) #8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(768) %4, i8 0, i64 768, i1 false)
  %5 = load volatile i32, ptr @requested_class, align 4, !tbaa !6
  %6 = zext i32 %5 to i64
  %7 = getelementptr inbounds i8, ptr %1, i64 64
  store i64 9, ptr %7, align 8, !tbaa !10
  %8 = getelementptr inbounds i8, ptr %3, i64 64
  store i64 9, ptr %8, align 8, !tbaa !10
  %9 = getelementptr inbounds i8, ptr %2, i64 16
  store i64 8, ptr %9, align 8, !tbaa !10
  %10 = getelementptr inbounds i8, ptr %2, i64 272
  store i64 16, ptr %10, align 8, !tbaa !10
  %11 = getelementptr inbounds i8, ptr %4, i64 16
  store i64 9, ptr %11, align 8, !tbaa !10
  %12 = getelementptr inbounds i8, ptr %4, i64 272
  store i64 12, ptr %12, align 8, !tbaa !10
  %13 = load volatile ptr, ptr @fixed_entry, align 8, !tbaa !12
  %14 = ptrtoint ptr %1 to i64
  %15 = insertvalue [2 x i64] poison, i64 %14, 0
  %16 = ptrtoint ptr %2 to i64
  %17 = insertvalue [2 x i64] %15, i64 %16, 1
  %18 = call preserve_nonecc i64 %13([2 x i64] %17, ptr noundef nonnull %1, i32 noundef 0, i32 noundef 0, i64 noundef %6, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0) #8
  %19 = icmp ne i64 %18, 8
  %20 = load i32, ptr @miss_calls, align 4
  %21 = icmp ne i32 %20, 0
  %22 = select i1 %19, i1 true, i1 %21
  br i1 %22, label %58, label %23

23:                                               ; preds = %0
  %24 = call i32 @bcmp(ptr noundef nonnull dereferenceable(512) %1, ptr noundef nonnull dereferenceable(512) %3, i64 512)
  %25 = icmp eq i32 %24, 0
  br i1 %25, label %26, label %58

26:                                               ; preds = %23
  %27 = call i32 @bcmp(ptr noundef nonnull dereferenceable(768) %2, ptr noundef nonnull dereferenceable(768) %4, i64 768)
  %28 = icmp eq i32 %27, 0
  br i1 %28, label %29, label %58

29:                                               ; preds = %26
  %30 = load i64, ptr %9, align 8, !tbaa !10
  %31 = load i64, ptr %10, align 8, !tbaa !10
  %32 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef 8, i64 noundef %30, i64 noundef %31, i32 noundef 0)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(768) %2, i8 0, i64 768, i1 false)
  %33 = load volatile ptr, ptr @dynamic_entry, align 8, !tbaa !12
  %34 = call preserve_nonecc i64 %33([2 x i64] %17, ptr noundef nonnull %1, i32 noundef 0, i32 noundef 0, i64 noundef %6, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0, i64 noundef 0) #8
  %35 = icmp ne i64 %34, 8
  %36 = load i32, ptr @miss_calls, align 4
  %37 = icmp ne i32 %36, 1
  %38 = select i1 %35, i1 true, i1 %37
  %39 = load i32, ptr @miss_cls, align 4
  %40 = icmp ne i32 %39, 2
  %41 = select i1 %38, i1 true, i1 %40
  %42 = load ptr, ptr @miss_mem, align 8
  %43 = icmp ne ptr %42, %1
  %44 = select i1 %41, i1 true, i1 %43
  %45 = load ptr, ptr @miss_alc, align 8
  %46 = icmp ne ptr %45, %2
  %47 = select i1 %44, i1 true, i1 %46
  br i1 %47, label %58, label %48

48:                                               ; preds = %29
  %49 = call i32 @bcmp(ptr noundef nonnull dereferenceable(512) %1, ptr noundef nonnull dereferenceable(512) %3, i64 512)
  %50 = icmp eq i32 %49, 0
  br i1 %50, label %51, label %58

51:                                               ; preds = %48
  %52 = call i32 @bcmp(ptr noundef nonnull dereferenceable(768) %2, ptr noundef nonnull dereferenceable(768) %4, i64 768)
  %53 = icmp eq i32 %52, 0
  br i1 %53, label %54, label %58

54:                                               ; preds = %51
  %55 = load i64, ptr %9, align 8, !tbaa !10
  %56 = load i64, ptr %10, align 8, !tbaa !10
  %57 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef 8, i64 noundef %55, i64 noundef %56, i32 noundef 1)
  br label %58

58:                                               ; preds = %54, %51, %48, %29, %0, %23, %26
  %59 = phi i32 [ 1, %26 ], [ 1, %23 ], [ 1, %0 ], [ 0, %54 ], [ 2, %51 ], [ 2, %48 ], [ 2, %29 ]
  call void @llvm.lifetime.end.p0(i64 768, ptr nonnull %4) #8
  call void @llvm.lifetime.end.p0(i64 512, ptr nonnull %3) #8
  call void @llvm.lifetime.end.p0(i64 768, ptr nonnull %2) #8
  call void @llvm.lifetime.end.p0(i64 512, ptr nonnull %1) #8
  ret i32 %59
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define internal preserve_nonecc range(i64 1, 0) i64 @case_fixed([2 x i64] %0, ptr nocapture noundef readnone %1, i32 noundef %2, i32 %3, i64 %4, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45) #4 {
  %47 = extractvalue [2 x i64] %0, 1
  %48 = inttoptr i64 %47 to ptr
  %49 = getelementptr inbounds i8, ptr %48, i64 16
  %50 = load i64, ptr %49, align 8, !tbaa !10
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %60, label %52

52:                                               ; preds = %46
  %53 = extractvalue [2 x i64] %0, 0
  %54 = inttoptr i64 %53 to ptr
  %55 = getelementptr inbounds i64, ptr %54, i64 %50
  %56 = load i64, ptr %55, align 8, !tbaa !10
  store i64 %56, ptr %49, align 8, !tbaa !10
  %57 = getelementptr inbounds i8, ptr %48, i64 272
  %58 = load i64, ptr %57, align 8, !tbaa !10
  %59 = add i64 %58, -4
  store i64 %59, ptr %57, align 8, !tbaa !10
  br label %61

60:                                               ; preds = %46
  tail call preserve_mostcc void @heap_alloc_miss([2 x i64] %0, i32 noundef 2) #9
  br label %61

61:                                               ; preds = %52, %60
  %62 = phi i64 [ %50, %52 ], [ 8, %60 ]
  %63 = musttail call preserve_nonecc i64 @finish([2 x i64] %0, ptr noundef %1, i32 noundef %2, i32 noundef 1, i64 noundef %62, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45)
  ret i64 %63
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define internal preserve_nonecc range(i64 1, 0) i64 @finish([2 x i64] %0, ptr nocapture noundef readnone %1, i32 noundef %2, i32 noundef %3, i64 noundef returned %4, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45) unnamed_addr #5 {
  ret i64 %4
}

; Function Attrs: cold mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, argmem: write, inaccessiblemem: none) uwtable
define internal preserve_mostcc void @heap_alloc_miss([2 x i64] %0, i32 noundef %1) unnamed_addr #6 {
  %3 = extractvalue [2 x i64] %0, 0
  %4 = inttoptr i64 %3 to ptr
  %5 = extractvalue [2 x i64] %0, 1
  %6 = inttoptr i64 %5 to ptr
  %7 = load i32, ptr @miss_calls, align 4, !tbaa !6
  %8 = add i32 %7, 1
  store i32 %8, ptr @miss_calls, align 4, !tbaa !6
  store i32 %1, ptr @miss_cls, align 4, !tbaa !6
  store ptr %4, ptr @miss_mem, align 8, !tbaa !12
  store ptr %6, ptr @miss_alc, align 8, !tbaa !12
  %9 = zext i32 %1 to i64
  %10 = getelementptr inbounds i64, ptr %6, i64 %9
  store i64 9, ptr %10, align 8, !tbaa !10
  %11 = add i32 %1, 32
  %12 = zext i32 %11 to i64
  %13 = getelementptr inbounds i64, ptr %6, i64 %12
  store i64 12, ptr %13, align 8, !tbaa !10
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define internal preserve_nonecc range(i64 1, 0) i64 @case_dynamic([2 x i64] %0, ptr nocapture noundef readnone %1, i32 noundef %2, i32 %3, i64 noundef %4, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45) #4 {
  %47 = extractvalue [2 x i64] %0, 1
  %48 = inttoptr i64 %47 to ptr
  %49 = and i64 %4, 4294967295
  %50 = getelementptr inbounds i64, ptr %48, i64 %49
  %51 = load i64, ptr %50, align 8, !tbaa !10
  %52 = icmp eq i64 %51, 0
  br i1 %52, label %64, label %53

53:                                               ; preds = %46
  %54 = extractvalue [2 x i64] %0, 0
  %55 = inttoptr i64 %54 to ptr
  %56 = getelementptr inbounds i64, ptr %55, i64 %51
  %57 = load i64, ptr %56, align 8, !tbaa !10
  store i64 %57, ptr %50, align 8, !tbaa !10
  %58 = shl nsw i64 -1, %49
  %59 = add i64 %4, 32
  %60 = and i64 %59, 4294967295
  %61 = getelementptr inbounds i64, ptr %48, i64 %60
  %62 = load i64, ptr %61, align 8, !tbaa !10
  %63 = add i64 %62, %58
  store i64 %63, ptr %61, align 8, !tbaa !10
  br label %66

64:                                               ; preds = %46
  %65 = trunc i64 %4 to i32
  tail call preserve_mostcc void @heap_alloc_miss([2 x i64] %0, i32 noundef %65) #9
  br label %66

66:                                               ; preds = %53, %64
  %67 = phi i64 [ %51, %53 ], [ 8, %64 ]
  %68 = musttail call preserve_nonecc i64 @finish([2 x i64] %0, ptr noundef %1, i32 noundef %2, i32 noundef 1, i64 noundef %67, i64 noundef %5, i64 noundef %6, i64 noundef %7, i64 noundef %8, i64 noundef %9, i64 noundef %10, i64 noundef %11, i64 noundef %12, i64 noundef %13, i64 noundef %14, i64 noundef %15, i64 noundef %16, i64 noundef %17, i64 noundef %18, i64 noundef %19, i64 noundef %20, i64 noundef %21, i64 noundef %22, i64 noundef %23, i64 noundef %24, i64 noundef %25, i64 noundef %26, i64 noundef %27, i64 noundef %28, i64 noundef %29, i64 noundef %30, i64 noundef %31, i64 noundef %32, i64 noundef %33, i64 noundef %34, i64 noundef %35, i64 noundef %36, i64 noundef %37, i64 noundef %38, i64 noundef %39, i64 noundef %40, i64 noundef %41, i64 noundef %42, i64 noundef %43, i64 noundef %44, i64 noundef %45)
  ret i64 %68
}

; Function Attrs: nofree nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr nocapture, ptr nocapture, i64) local_unnamed_addr #7

attributes #0 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #4 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #5 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #6 = { cold mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(readwrite, argmem: write, inaccessiblemem: none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #7 = { nofree nounwind willreturn memory(argmem: read) }
attributes #8 = { nounwind }
attributes #9 = { cold }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Debian clang version 19.1.7 (3~deb12u1)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!11, !11, i64 0}
!11 = !{!"long", !8, i64 0}
!12 = !{!13, !13, i64 0}
!13 = !{!"any pointer", !8, i64 0}
