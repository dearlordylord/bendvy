"""Isolate a successful child followed by a failed caller postguard.

The broader caller controls live in controls.py.source. This case specifically
checks the boundary where child exit and raw-log publication succeed, but the
postguard fails before the caller can return an accepted result.
"""

import ast
import hashlib
import json
import sys
import tempfile
import types
from pathlib import Path

ROOT = Path("/workspace/formal-proofs/bendvy")
sys.path.insert(0, str(ROOT / "scripts"))
from evidence_boundary import ReceiptBoundary

HERE = Path(__file__).resolve().parent
CALLER_SOURCE = HERE / "execute.py.source"
source_tree = ast.parse(CALLER_SOURCE.read_text())
capturing_harness = next(
    node
    for node in ast.walk(source_tree)
    if isinstance(node, ast.ClassDef) and node.name == "CapturingHarness"
)


class FakeHarness:
    def __init__(self, output: Path, fail_postguard: bool = False):
        self.output = output
        self.receipt = {"status": "INCOMPLETE", "commands": [], "logs": {}}
        self.guard_calls = 0
        self.fail_postguard = fail_postguard

    def guard(self):
        self.guard_calls += 1
        # CapturingHarness calls once before execution and ReceiptBoundary calls
        # again after successful raw-log publication.
        if self.fail_postguard and self.guard_calls == 2:
            raise ValueError("injected successful-child postguard failure")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_subject(result):
    namespace = {
        "execute": types.SimpleNamespace(Harness=FakeHarness),
        "runner": types.SimpleNamespace(execute_result=lambda *args, **kwargs: result),
        "ReceiptBoundary": ReceiptBoundary,
        "hashlib": hashlib,
        "sha": sha256,
    }
    module = ast.Module(body=[capturing_harness], type_ignores=[])
    exec(compile(module, str(CALLER_SOURCE), "exec"), namespace)
    return namespace["CapturingHarness"]


def main() -> None:
    result = {
        "exit": 0,
        "failure": None,
        "stdout": b"child completed\x00stdout\n",
        "stderr": b"child completed stderr\n",
    }
    with tempfile.TemporaryDirectory(prefix="bendvy54-postguard-control-") as temporary:
        output = Path(temporary)
        harness = build_subject(result)(output, fail_postguard=True)

        try:
            harness.run("postguard", ["stub-child"], 5)
        except ValueError as error:
            assert str(error) == "injected successful-child postguard failure"
        else:
            raise AssertionError("successful child with failed postguard was accepted")

        assert harness.guard_calls == 2
        receipt = json.loads((output / "receipt.json").read_text())
        assert receipt["status"] == "INCOMPLETE"
        assert len(receipt["commands"]) == 1
        command = receipt["commands"][0]
        assert command["exit"] == 0 and command["failure"] is None
        assert len(receipt["guardFailures"]) == 1
        guard_failure = receipt["guardFailures"][0]
        assert guard_failure["guard"] == "harness inputs/artifacts/logs"
        assert "injected successful-child postguard failure" in guard_failure["error"]

        for stream in ("stdout", "stderr"):
            raw = result[stream]
            artifact = output / f"postguard.{stream}"
            published = command[stream]
            assert artifact.read_bytes() == raw
            assert published["published"] is True
            assert published["bytes"] == len(raw)
            assert published["sha256"] == hashlib.sha256(raw).hexdigest()
            assert "unpublishedHex" not in published
            assert receipt["logs"][artifact.name] == sha256(artifact)

        print(
            json.dumps(
                {
                    "status": "POSTGUARD_FAILURE_CONTROL_PASS",
                    "callerSourceSHA256": sha256(CALLER_SOURCE),
                    "childExit": command["exit"],
                    "receiptStatus": receipt["status"],
                    "rawStreamsPublished": True,
                    "postguard": guard_failure,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
