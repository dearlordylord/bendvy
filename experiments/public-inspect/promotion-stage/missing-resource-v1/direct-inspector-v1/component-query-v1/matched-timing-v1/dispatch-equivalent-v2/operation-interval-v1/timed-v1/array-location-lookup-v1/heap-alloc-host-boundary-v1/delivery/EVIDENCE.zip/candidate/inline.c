#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint64_t Term;
typedef uint64_t u64;
typedef uint32_t u32;
typedef struct { u64* mem; u64* alc; } Env;
#define INLINE static inline
#define FAR static __attribute__((noinline))
#define OUTLINE static __attribute__((noinline, cold, preserve_most))
#define DEVICE 0
#define NCLS_ALL 32
#define LANE_STEP 1
#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
static u32 miss_calls, miss_cls;
static u64* miss_mem;
static u64* miss_alc;
// Recording fallback only: the production miss body remains untouched.
OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  ++miss_calls; miss_cls=cls; miss_mem=e.mem; miss_alc=e.alc;
  ALC_AT(e, cls)=9; ALC_LEN(e, cls)=12; return 8;
}
INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}
#define CASE static __attribute__((noinline, preserve_none)) Term
typedef Term (__attribute__((preserve_none)) *WlFn)(Env e, Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35, Term r36, Term r37, Term r38, Term r39, Term r40);
CASE finish(Env e, Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35, Term r36, Term r37, Term r38, Term r39, Term r40) { return r0; }
CASE case_fixed(Env e, Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35, Term r36, Term r37, Term r38, Term r39, Term r40) { r0=heap_alloc(e, 2); rn=1; __attribute__((musttail)) return finish(e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40); }
CASE case_dynamic(Env e, Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35, Term r36, Term r37, Term r38, Term r39, Term r40) { r0=heap_alloc(e, (u32)r0); rn=1; __attribute__((musttail)) return finish(e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40); }
static volatile WlFn fixed_entry=case_fixed, dynamic_entry=case_dynamic;
static volatile u32 requested_class=2;
int main(void) {
  u64 mem[64]={0}, alc[96]={0}, expected_mem[64]={0}, expected_alc[96]={0};
  Env e={mem,alc}; Term* sp=mem; Term requested=requested_class;
  mem[8]=9; expected_mem[8]=9; alc[2]=8; alc[34]=16;
  expected_alc[2]=9; expected_alc[34]=12;
  Term hot=fixed_entry(e, sp, 0, 0, requested, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  if(hot!=8 || miss_calls!=0 || memcmp(mem,expected_mem,sizeof mem) || memcmp(alc,expected_alc,sizeof alc)) return 1;
  printf("hot %llu %llu %llu %u\n",(unsigned long long)hot,(unsigned long long)alc[2],(unsigned long long)alc[34],miss_calls);
  memset(alc,0,sizeof alc);
  Term miss=dynamic_entry(e, sp, 0, 0, requested, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  if(miss!=8 || miss_calls!=1 || miss_cls!=2 || miss_mem!=mem || miss_alc!=alc || memcmp(mem,expected_mem,sizeof mem) || memcmp(alc,expected_alc,sizeof alc)) return 2;
  printf("miss %llu %llu %llu %u\n",(unsigned long long)miss,(unsigned long long)alc[2],(unsigned long long)alc[34],miss_calls);
  return 0;
}
