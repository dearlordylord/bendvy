function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return {$: "Tuple", "fst": ($consumer$058run$1260$()), "snd": ($consumer$058run$1261$())};
}

function $consumer$058run$1260$() {
  return $consumer$058created$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($consumer$058resources$1260$()))));
}

function $consumer$058run$1261$() {
  return $consumer$058created$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($consumer$058resources$1261$()))));
}

function $consumer$058created$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $consumer$058step0$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $consumer$058pending$1260$(_x_0);
}))), {$: "Nil"});
  } else {
    return {$: "Con", "head": "CreateRejected", "tail": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $consumer$058resources$1260$() {
  return {$: "state.Resources", "owned": array_node([11], [12]), "flow": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": 7, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": 11, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": 12, "skipSame": true}, "previous": {$: "Some", "value": 10}, "changed": false}, "ran": 0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$()), 1, 0)), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$())};
}

function $consumer$058created$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $consumer$058step0$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $consumer$058pending$1261$(_x_0);
}))), {$: "Nil"});
  } else {
    return {$: "Con", "head": "CreateRejected", "tail": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $consumer$058resources$1261$() {
  return {$: "state.Resources", "owned": array_node([11], [12]), "flow": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": 7, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": 11, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": 12, "skipSame": true}, "previous": {$: "Some", "value": 10}, "changed": false}, "ran": 0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$()), 1, 0)), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$())};
}

function $consumer$058step0$1260$(_world_0, _previous_0) {
  return $consumer$058returned0$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $consumer$058pending$1260$(_world_0) {
  return $consumer$058clocked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($consumer$058store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $consumer$058step0$1261$(_world_0, _previous_0) {
  return $consumer$058returned0$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $consumer$058pending$1261$(_world_0) {
  return $consumer$058clocked$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($consumer$058store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $consumer$058returned0$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step1$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("before:" + _text_0), "tail": {$: "Nil"}})));
}

function $dump$058world$1260$(_world_0) {
  return $dump$058counted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $consumer$058clocked$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058store$1260$(__0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1260$({$: "state.Components", "cells": array_node([31], [32])});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $consumer$058returned0$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step1$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("before:" + _text_0), "tail": {$: "Nil"}})));
}

function $dump$058world$1261$(_world_0) {
  return $dump$058counted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0)));
}

function $consumer$058clocked$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058store$1261$(__0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1261$({$: "state.Components", "cells": array_node([31], [32])});
}

function $consumer$058step1$1260$(_world_0, _previous_0) {
  return $consumer$058returned1$1260$(_previous_0, ($consumer$058queue$1260$(_world_0, false)));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $dump$058counted$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1260$(_count_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1260$(_components_0) {
  return {$: "../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $consumer$058step1$1261$(_world_0, _previous_0) {
  return $consumer$058returned1$1261$(_previous_0, ($consumer$058queue$1261$(_world_0, false)));
}

function $dump$058counted$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1261$(_count_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1262$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1261$(_components_0) {
  return {$: "../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $consumer$058returned1$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step2$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-queued:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058queue$1260$(_world_0, _skip_0) {
  return $consumer$058queued$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058queue$1260$(_world_0, {$: "../../../../../../bendvy/src/ecs/machine.Set", "value": 7, "skipSame": _skip_0}, {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $dump$058resourced$1260$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1260$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $dump$058store$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($dump$058resources$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $consumer$058returned1$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step2$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-queued:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058queue$1261$(_world_0, _skip_0) {
  return $consumer$058queued$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058queue$1261$(_world_0, {$: "../../../../../../bendvy/src/ecs/machine.Set", "value": 7, "skipSame": _skip_0}, {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $dump$058resourced$1261$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1261$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $dump$058store$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1262$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1262$(($dump$058resources$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $consumer$058step2$1260$(_world_0, _previous_0) {
  return $consumer$058returned2$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058queued$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "Tuple", "fst": _world_0, "snd": "Success"};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _world_0, "snd": ("Failure:" + _error_0)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058queue$1260$(_world_0, _request_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)), _request_0)), _outcome_0);
}

function $dump$058stored$1260$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058store$1260$(_value_0) {
  const _owner_0 = _value_0["components"];
  const _relations_0 = _value_0["graph"];
  return $dump$058store_done$1260$(_relations_0, ($dump$058components$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $dump$058resource_done$1260$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($dump$058tree$1261$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $consumer$058step2$1261$(_world_0, _previous_0) {
  return $consumer$058returned2$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058queued$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "Tuple", "fst": _world_0, "snd": "Success"};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _world_0, "snd": ("Failure:" + _error_0)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058queue$1261$(_world_0, _request_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0)), _request_0)), _outcome_0);
}

function $dump$058stored$1261$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058store$1261$(_value_0) {
  const _owner_0 = _value_0["components"];
  const _relations_0 = _value_0["graph"];
  return $dump$058store_done$1261$(_relations_0, ($dump$058components$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resources$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $dump$058resource_done$1261$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($dump$058tree$1261$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $consumer$058returned2$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step3$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-queued-world:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$())))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1260$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058store_done$1260$(_relations_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($dump$058graph$1260$(_relations_0));
  const _x_1 = (";graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _relations_0}, "snd": (_text_0 + _x_1)};
}

function $dump$058components$1260$(_value_0) {
  const _cells_0 = _value_0["cells"];
  return $dump$058component_done$1260$(($dump$058tree$1261$(_cells_0)));
}

function $dump$058resource_done$1260$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _result_0) {
  const _owned_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($dump$058stream$(_levelStream_0));
  const _x_1 = ($dump$058stream$(_flowStream_0));
  const _x_2 = (";" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ran_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058slot$1261$(_level_0));
  const _x_8 = (";ran=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058slot$1260$(_flow_0));
  const _x_11 = (";" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";" + _x_12);
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": (_text_0 + _x_13)};
}

function $dump$058tree$1261$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1261$(($dump$058u32$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1261$(($dump$058tree$1261$(_b_0)), ($dump$058tree$1261$(_a_0)));
  }
}

function $consumer$058returned2$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step3$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-queued-world:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$())))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1260$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058store_done$1261$(_relations_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($dump$058graph$1261$(_relations_0));
  const _x_1 = (";graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _relations_0}, "snd": (_text_0 + _x_1)};
}

function $dump$058components$1261$(_value_0) {
  const _cells_0 = _value_0["cells"];
  return $dump$058component_done$1261$(($dump$058tree$1261$(_cells_0)));
}

function $dump$058resource_done$1261$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _result_0) {
  const _owned_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($dump$058stream$(_levelStream_0));
  const _x_1 = ($dump$058stream$(_flowStream_0));
  const _x_2 = (";" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ran_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058slot$1263$(_level_0));
  const _x_8 = (";ran=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058slot$1262$(_flow_0));
  const _x_11 = (";" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";" + _x_12);
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": (_text_0 + _x_13)};
}

function $consumer$058step3$1260$(_world_0, _previous_0) {
  return $consumer$058returned3$1260$(_previous_0, ($consumer$058marker$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(_x_1, _x_2);
});
})};
}

function $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1268$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1265$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = ("," + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("," + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = ("," + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058tree$1260$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1260$(($dump$058boolean$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1260$(($dump$058tree$1260$(_b_0)), ($dump$058tree$1260$(_a_0)));
  }
}

function $dump$058graph$1260$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($List$show$12610$(_inverses_0));
  const _x_1 = ($List$show$1269$(_edges_0));
  const _x_2 = (";" + _x_0);
  return (_x_1 + _x_2);
}

function $dump$058component_done$1260$(_result_0) {
  const _cells_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "state.Components", "cells": _cells_0}, "snd": _text_0};
}

function $dump$058slot$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058slot$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $dump$058stream$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _start_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_start_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($Nat$show$(_dropped_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1262$(_positions_0));
  const _x_6 = ("," + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($List$show$1261$(_batches_0));
  const _x_9 = ("," + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("stream(" + _x_10);
}

function $dump$058leaf$1261$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058u32$(_value_0) {
  return $dump$058u32_value$(_value_0);
}

function $dump$058tree_left$1261$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1261$(_a_0, _text_0, _b_0);
}

function $consumer$058step3$1261$(_world_0, _previous_0) {
  return $consumer$058returned3$1261$(_previous_0, ($consumer$058marker$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_x_1, _x_2);
});
})};
}

function $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1268$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$12611$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = ("," + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("," + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = ("," + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058graph$1261$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($List$show$12615$(_inverses_0));
  const _x_1 = ($List$show$12614$(_edges_0));
  const _x_2 = (";" + _x_0);
  return (_x_1 + _x_2);
}

function $dump$058component_done$1261$(_result_0) {
  const _cells_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "state.Components", "cells": _cells_0}, "snd": _text_0};
}

function $dump$058slot$1262$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058slot$1263$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $consumer$058returned3$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step4$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-marker:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058marker$1260$(_world_0) {
  return $consumer$058captured$1260$(($consumer$058take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1260$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1260$({$: "../../../../../../bendvy/src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($consumer$058declaration$1260$())))}, _frame_0, _input_0);
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058leaf$1260$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058boolean$(_value_0) {
  return $dump$058boolean_value$(_value_0);
}

function $dump$058tree_left$1260$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1260$(_a_0, _text_0, _b_0);
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058pending$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_value_1));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("next(" + _x_4);
  }
}

function $dump$058previous$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058batch$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058position$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058u32_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $dump$058tree_join$1261$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $consumer$058returned3$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step4$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-marker:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058marker$1261$(_world_0) {
  return $consumer$058captured$1261$(($consumer$058take$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1261$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1261$({$: "../../../../../../bendvy/src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(($consumer$058declaration$1261$())))}, _frame_0, _input_0);
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1261$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058step4$1260$(_world_0, _previous_0) {
  return $consumer$058returned4$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058captured$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _slot_0 = _result_0["snd"];
  return $consumer$058applied$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run$1260$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": {$: "Nil"}, "enter": {$: "Nil"}}, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1260$(_slot_0)))));
}

function $consumer$058take$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1260$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1260$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(_declaration_0) {
  if (_declaration_0.$ === "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $consumer$058declaration$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$("Flow", {$: "Con", "head": 7, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}});
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $dump$058notice$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    const _x_0 = ($U32$show$(_value_1));
    return ("user:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    const _value_2 = _value_0["failure"];
    const _x_1 = ($dump$058failure$1260$(_value_2));
    return ("relationFailed:" + _x_1);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_0));
    return ("componentRemoved:" + _x_2);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_3 = ($List$show$1266$(_frames_0));
    return ("cleanupPaused:" + _x_3);
  }
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1263$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $dump$058tree_join$1260$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $dump$058edge$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1260$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058inverse$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($List$show$1264$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1260$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $dump$058batch$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _items_0 = _value_0["values"];
  const _x_0 = ($List$show$1260$(_items_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058batch$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058position$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058step4$1261$(_world_0, _previous_0) {
  return $consumer$058returned4$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058captured$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _slot_0 = _result_0["snd"];
  return $consumer$058applied$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run$1261$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": {$: "Nil"}, "enter": {$: "Nil"}}, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1261$(_slot_0)))));
}

function $consumer$058take$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1261$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1261$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1261$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(_declaration_0) {
  if (_declaration_0.$ === "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $consumer$058declaration$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$("Flow", {$: "Con", "head": 7, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}});
}

function $dump$058notice$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    const _x_0 = ($U32$show$(_value_1));
    return ("user:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    const _value_2 = _value_0["failure"];
    const _x_1 = ($dump$058failure$1261$(_value_2));
    return ("relationFailed:" + _x_1);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_0));
    return ("componentRemoved:" + _x_2);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_3 = ($List$show$12612$(_frames_0));
    return ("cleanupPaused:" + _x_3);
  }
}

function $List$show$go$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1261$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058edge$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1261$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058inverse$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($List$show$1264$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1261$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058returned4$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step5$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-before-inspect:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058applied$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Completed") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": _world_0, "snd": "Completed"};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _world_1, "snd": ("Stopped:" + _error_0)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run$1260$(_owners_0, _world_0, _captured_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058taken$1260$(_owners_0, ($consumer$058take$1260$(_world_0)), _captured_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($state$058flow$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1260$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../../../bendvy/src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1260$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1260$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$(_name_0, _values_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $dump$058failure$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _op_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($dump$058relation_error$(_error_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_source_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058operation$(_op_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058descriptor$1260$(_relation_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1263$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $dump$058descriptor$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($dump$058relation_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverseName_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058transition$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058returned4$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step5$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-before-inspect:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058applied$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Completed") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": _world_0, "snd": "Completed"};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _world_1, "snd": ("Stopped:" + _error_0)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run$1261$(_owners_0, _world_0, _captured_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058taken$1261$(_owners_0, ($consumer$058take$1261$(_world_0)), _captured_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($state$058flow$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1261$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../../../bendvy/src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1261$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1261$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$(_name_0, _values_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $dump$058failure$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _op_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($dump$058relation_error$(_error_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_source_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058operation$(_op_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058descriptor$1261$(_relation_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1261$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058descriptor$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($dump$058relation_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverseName_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $consumer$058step5$1260$(_world_0, _previous_0) {
  return $consumer$058returned5$1260$(_previous_0, ($consumer$058inspect$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058taken$1260$(_owners_0, _observed_0, _captured_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepared$1260$(_owners_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepare$1260$(_slot_0, _captured_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0) {
  if (_pending_0.$ === "../../../../../../bendvy/src/ecs/machine.NoPending") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $state$058flow$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1260$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $dump$058operation$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.Relate") {
    return "relate";
  } else {
    return "reorderChildren";
  }
}

function $dump$058relation_error$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.MissingEntity") {
    const _source_0 = _value_0["source"];
    const _x_0 = ($U32$show$(_source_0));
    return ("missingEntity:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.MissingTargetEntity") {
    const _source_1 = _value_0["source"];
    const _target_0 = _value_0["target"];
    const _relation_0 = _value_0["relation"];
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (":" + _relation_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_1));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("missingTarget:" + _x_6);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.SelfRelationNotAllowed") {
    const _source_2 = _value_0["source"];
    const _relation_1 = _value_0["relation"];
    const _x_7 = ($U32$show$(_source_2));
    const _x_8 = (":" + _relation_1);
    const _x_9 = (_x_7 + _x_8);
    return ("selfRelation:" + _x_9);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.HierarchyCycle") {
    const _source_3 = _value_0["source"];
    const _target_1 = _value_0["target"];
    const _relation_2 = _value_0["relation"];
    const _x_10 = ($U32$show$(_target_1));
    const _x_11 = (":" + _relation_2);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_source_3));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("hierarchyCycle:" + _x_15);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.MissingChildEntity") {
    const _source_4 = _value_0["source"];
    const _child_0 = _value_0["child"];
    const _relation_3 = _value_0["relation"];
    const _x_16 = ($U32$show$(_child_0));
    const _x_17 = (":" + _relation_3);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($U32$show$(_source_4));
    const _x_20 = (":" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    return ("missingChild:" + _x_21);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.DuplicateChild") {
    const _source_5 = _value_0["source"];
    const _child_1 = _value_0["child"];
    const _relation_4 = _value_0["relation"];
    const _x_22 = ($U32$show$(_child_1));
    const _x_23 = (":" + _relation_4);
    const _x_24 = (_x_22 + _x_23);
    const _x_25 = ($U32$show$(_source_5));
    const _x_26 = (":" + _x_24);
    const _x_27 = (_x_25 + _x_26);
    return ("duplicateChild:" + _x_27);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.ChildNotRelatedToParent") {
    const _source_6 = _value_0["source"];
    const _child_2 = _value_0["child"];
    const _relation_5 = _value_0["relation"];
    const _x_28 = ($U32$show$(_child_2));
    const _x_29 = (":" + _relation_5);
    const _x_30 = (_x_28 + _x_29);
    const _x_31 = ($U32$show$(_source_6));
    const _x_32 = (":" + _x_30);
    const _x_33 = (_x_31 + _x_32);
    return ("childNotRelated:" + _x_33);
  } else {
    const _source_7 = _value_0["source"];
    const _relation_6 = _value_0["relation"];
    const _x_34 = ($U32$show$(_source_7));
    const _x_35 = (":" + _relation_6);
    const _x_36 = (_x_34 + _x_35);
    return ("childSetMismatch:" + _x_36);
  }
}

function $dump$058cleanup$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_1 = ($List$show$1267$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _relation_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_5 = ($List$show$1264$(_children_0));
    const _x_6 = ($List$show$1267$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($dump$058descriptor$1260$(_relation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _value_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1263$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $dump$058relation_kind$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return "ordinary";
  } else {
    return "hierarchy";
  }
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058transition$(_value_0) {
  const _a_0 = _value_0["from"];
  const _b_0 = _value_0["to"];
  const _x_0 = ($U32$show$(_b_0));
  const _x_1 = ($U32$show$(_a_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058transition$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058step5$1261$(_world_0, _previous_0) {
  return $consumer$058returned5$1261$(_previous_0, ($consumer$058inspect$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058taken$1261$(_owners_0, _observed_0, _captured_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepared$1261$(_owners_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepare$1261$(_slot_0, _captured_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $state$058flow$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1261$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $dump$058cleanup$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_1 = ($List$show$12613$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _relation_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_5 = ($List$show$1264$(_children_0));
    const _x_6 = ($List$show$12613$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($dump$058descriptor$1261$(_relation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _value_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1261$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058returned5$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step6$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058inspect$1260$(_world_0) {
  return $consumer$058inspected$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$({$: "../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1260$(_world_0, 65536)), "cursor": 19})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepared$1260$(_owners_0, _world_0, _prepared_0) {
  const _exit_0 = _owners_0["exit"];
  const _transition_0 = _owners_0["transition"];
  const _enter_0 = _owners_0["enter"];
  if (_prepared_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Idle") {
    const _slot_0 = _prepared_0["slot"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Completed", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($consumer$058put$1260$(_world_0, _slot_0))};
  } else {
    const _slot_1 = _prepared_0["slot"];
    const _t_0 = _prepared_0["transition"];
    const _from_0 = _t_0["from"];
    const _to_0 = _t_0["to"];
    const _skipSame_0 = _prepared_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_exit$1260$(_transition_0, _enter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1260$(_exit_0, ($consumer$058put$1260$(_world_0, _slot_1)), {$: "../../../../../../bendvy/src/ecs/machine-handlers.Exit"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepare$1260$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1260$({$: "../../../../../../bendvy/src/ecs/machine.Missing"}))};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const __3 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1260$({$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": __3}))};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058choose$1260$(($Bool$and$(_skipSame_0, (_current_0 === _value_0))), _current_0, _value_0, _previous_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1260$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058returned5$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step6$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058inspect$1261$(_world_0) {
  return $consumer$058inspected$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$({$: "../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1261$(_world_0, 65536)), "cursor": 19})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepared$1261$(_owners_0, _world_0, _prepared_0) {
  const _exit_0 = _owners_0["exit"];
  const _transition_0 = _owners_0["transition"];
  const _enter_0 = _owners_0["enter"];
  if (_prepared_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Idle") {
    const _slot_0 = _prepared_0["slot"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Completed", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($consumer$058put$1261$(_world_0, _slot_0))};
  } else {
    const _slot_1 = _prepared_0["slot"];
    const _t_0 = _prepared_0["transition"];
    const _from_0 = _t_0["from"];
    const _to_0 = _t_0["to"];
    const _skipSame_0 = _prepared_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_exit$1261$(_transition_0, _enter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1261$(_exit_0, ($consumer$058put$1261$(_world_0, _slot_1)), {$: "../../../../../../bendvy/src/ecs/machine-handlers.Exit"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepare$1261$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1261$({$: "../../../../../../bendvy/src/ecs/machine.Missing"}))};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const __3 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1261$({$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": __3}))};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058choose$1261$(($Bool$and$(_skipSame_0, (_current_0 === _value_0))), _current_0, _value_0, _previous_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1261$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $List$show$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058step6$1260$(_world_0, _previous_0) {
  return $consumer$058returned6$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058inspected$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["runtime"];
  const _world_0 = _t_1["world"];
  const _namespace_0 = _t_1["namespace"];
  const _batches_0 = _t_1["batches"];
  const _positions_0 = _t_1["positions"];
  const _nextReader_0 = _t_1["nextReader"];
  const _tick_0 = _t_1["tick"];
  const _start_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _dropped_0 = _t_1["droppedThrough"];
  const _cursor_0 = _t_0["cursor"];
  const _t_2 = _result_0["snd"];
  const _stream_0 = _t_2["stream"];
  const _x_0 = ($dump$058stream$(_stream_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($Nat$show$(_dropped_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Nat$show$(_capacity_0));
  const _x_6 = (",dropped=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_boundary_0));
  const _x_9 = (",capacity=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(_start_0));
  const _x_12 = (",boundary=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_tick_0));
  const _x_15 = (",start=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($U32$show$(_nextReader_0));
  const _x_18 = (",tick=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($List$show$1262$(_positions_0));
  const _x_21 = (",nextReader=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($Nat$show$(($List$length$(_batches_0))));
  const _x_24 = (",positions=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_namespace_0));
  const _x_27 = (",batches=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_cursor_0));
  const _x_30 = (",namespace=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  return {$: "Tuple", "fst": _world_0, "snd": ("inspect(cursor=" + _x_31)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058inspect$1260$()))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1260$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $consumer$058put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_exit$1260$(_transition_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Failed") {
    const _exit_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058requeued$1260$(($consumer$058take$1260$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Exit"}, "error": _error_0};
  } else {
    const _exit_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_transition$1260$(_exit_1, _enter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1260$(_transition_0, _world_1, {$: "../../../../../../bendvy/src/ecs/machine-handlers.Transition"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1260$(_entries_0, _world_0, _phase_0, _from_0, _to_0, _error_0) {
  if (_entries_0.$ === "Nil") {
    if (_error_0.$ === "Some") {
      const _error_1 = _error_0["value"];
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Failed", "entries": {$: "Nil"}, "world": _world_0, "error": _error_1};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Complete", "entries": {$: "Nil"}, "world": _world_0};
    }
  } else {
    const _t_0 = _entries_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    if (_error_0.$ === "Some") {
      const _error_2 = _error_0["value"];
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, "tail": _rest_0}, "world": _world_0, "error": _error_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_result$1260$(_ordinal_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, {$: "../../../../../../bendvy/src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0})), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1260$(_rest_0, _x_0, _phase_0, _from_0, _to_0, _x_1);
});
}));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058choose$1260$(_skip_0, _current_0, _value_0, _previous_0, _skipSame_0) {
  if (_skip_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": false}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Ready", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": false}, "transition": {$: "../../../../../../bendvy/src/ecs/machine.Transition", "from": _current_0, "to": _value_0}, "skipSame": _skipSame_0};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($consumer$058put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1260$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058step6$1261$(_world_0, _previous_0) {
  return $consumer$058returned6$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058inspected$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["runtime"];
  const _world_0 = _t_1["world"];
  const _namespace_0 = _t_1["namespace"];
  const _batches_0 = _t_1["batches"];
  const _positions_0 = _t_1["positions"];
  const _nextReader_0 = _t_1["nextReader"];
  const _tick_0 = _t_1["tick"];
  const _start_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _dropped_0 = _t_1["droppedThrough"];
  const _cursor_0 = _t_0["cursor"];
  const _t_2 = _result_0["snd"];
  const _stream_0 = _t_2["stream"];
  const _x_0 = ($dump$058stream$(_stream_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($Nat$show$(_dropped_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Nat$show$(_capacity_0));
  const _x_6 = (",dropped=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_boundary_0));
  const _x_9 = (",capacity=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(_start_0));
  const _x_12 = (",boundary=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_tick_0));
  const _x_15 = (",start=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($U32$show$(_nextReader_0));
  const _x_18 = (",tick=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($List$show$1262$(_positions_0));
  const _x_21 = (",nextReader=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($Nat$show$(($List$length$(_batches_0))));
  const _x_24 = (",positions=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_namespace_0));
  const _x_27 = (",batches=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_cursor_0));
  const _x_30 = (",namespace=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  return {$: "Tuple", "fst": _world_0, "snd": ("inspect(cursor=" + _x_31)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058inspect$1261$()))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1261$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $consumer$058put$1261$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_exit$1261$(_transition_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Failed") {
    const _exit_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058requeued$1261$(($consumer$058take$1261$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Exit"}, "error": _error_0};
  } else {
    const _exit_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_transition$1261$(_exit_1, _enter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1261$(_transition_0, _world_1, {$: "../../../../../../bendvy/src/ecs/machine-handlers.Transition"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1261$(_entries_0, _world_0, _phase_0, _from_0, _to_0, _error_0) {
  if (_entries_0.$ === "Nil") {
    if (_error_0.$ === "Some") {
      const _error_1 = _error_0["value"];
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Failed", "entries": {$: "Nil"}, "world": _world_0, "error": _error_1};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Complete", "entries": {$: "Nil"}, "world": _world_0};
    }
  } else {
    const _t_0 = _entries_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    if (_error_0.$ === "Some") {
      const _error_2 = _error_0["value"];
      return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, "tail": _rest_0}, "world": _world_0, "error": _error_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_result$1261$(_ordinal_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, {$: "../../../../../../bendvy/src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0})), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1261$(_rest_0, _x_0, _phase_0, _from_0, _to_0, _x_1);
});
}));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058choose$1261$(_skip_0, _current_0, _value_0, _previous_0, _skipSame_0) {
  if (_skip_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Idle", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": false}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Ready", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": false}, "transition": {$: "../../../../../../bendvy/src/ecs/machine.Transition", "from": _current_0, "to": _value_0}, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($consumer$058put_resource$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1261$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058returned6$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step7$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-after-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058inspect$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058read$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058requeued$1260$(_observed_0, _to_0, _skipSame_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $consumer$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_slot_0, _to_0, _skipSame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_transition$1260$(_exit_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Failed") {
    const _transition_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058requeued$1260$(($consumer$058take$1260$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Transition"}, "error": _error_0};
  } else {
    const _transition_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_enter$1260$(_exit_0, _transition_1, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1260$(_enter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058published$1260$(($consumer$058take$1260$(_world_1)), _from_0, _to_0)), {$: "../../../../../../bendvy/src/ecs/machine-handlers.Enter"}, _from_0, _to_0, {$: "None"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_result$1260$(_ordinal_0, _observed_0, _next_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _observed_0["registry"];
    const _outcome_0 = _observed_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_outcome$1260$(_ordinal_0, _registry_0, _outcome_0, _next_0);
  } else {
    const _registry_1 = _observed_0["registry"];
    const _world_0 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_1}, _next_0(_world_0)({$: "Some", "value": "HandlerRegistrationRejected"}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $consumer$058put_resource$1260$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "flow": _slot_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1260$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $consumer$058returned6$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step7$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-after-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058inspect$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058read$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058requeued$1261$(_observed_0, _to_0, _skipSame_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $consumer$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_slot_0, _to_0, _skipSame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_transition$1261$(_exit_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Failed") {
    const _transition_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058requeued$1261$(($consumer$058take$1261$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Transition"}, "error": _error_0};
  } else {
    const _transition_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_enter$1261$(_exit_0, _transition_1, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058run_phase$1261$(_enter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058published$1261$(($consumer$058take$1261$(_world_1)), _from_0, _to_0)), {$: "../../../../../../bendvy/src/ecs/machine-handlers.Enter"}, _from_0, _to_0, {$: "None"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_result$1261$(_ordinal_0, _observed_0, _next_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _observed_0["registry"];
    const _outcome_0 = _observed_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_outcome$1261$(_ordinal_0, _registry_0, _outcome_0, _next_0);
  } else {
    const _registry_1 = _observed_0["registry"];
    const _world_0 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_1}, _next_0(_world_0)({$: "Some", "value": "HandlerRegistrationRejected"}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $consumer$058put_resource$1261$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "flow": _slot_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1261$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $consumer$058step7$1260$(_world_0, _previous_0) {
  return $consumer$058returned7$1260$(_previous_0, ($consumer$058inspect$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058read$1260$(_frame_0) {
  const _runtime_0 = _frame_0["runtime"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058from_runtime$1260$(_cursor_0, _runtime_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_enter$1260$(_exit_0, _transition_0, _observed_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Complete") {
    const _enter_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Completed", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": _world_0};
  } else {
    const _enter_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_1}, "world": _world_1, "phase": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Enter"}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058published$1260$(_observed_0, _from_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $consumer$058publish$1260$(($consumer$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058committed$1260$(_slot_0, _from_0, _to_0)))), {$: "../../../../../../bendvy/src/ecs/machine.Transition", "from": _from_0, "to": _to_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_outcome$1260$(_ordinal_0, _registry_0, _outcome_0, _next_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_0)({$: "Some", "value": _error_0}));
  } else {
    const _world_1 = _outcome_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_1)({$: "None"}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1260$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Complete") {
    const _entries_0 = _tail_0["entries"];
    const _world_0 = _tail_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Complete", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "world": _world_0};
  } else {
    const _entries_1 = _tail_0["entries"];
    const _world_1 = _tail_0["world"];
    const _error_0 = _tail_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": _head_0, "tail": _entries_1}, "world": _world_1, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0) {
  if (_pending_0.$ === "../../../../../../bendvy/src/ecs/machine.Queued") {
    const _prior_0 = _pending_0["value"];
    const _t_0 = _pending_0["skipSame"];
    if (!_t_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058forced_pending$1260$((_prior_0 === _value_0), _prior_0, _value_0);
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
    }
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
  }
}

function $consumer$058step7$1261$(_world_0, _previous_0) {
  return $consumer$058returned7$1261$(_previous_0, ($consumer$058inspect$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058read$1261$(_frame_0) {
  const _runtime_0 = _frame_0["runtime"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058from_runtime$1261$(_cursor_0, _runtime_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058after_enter$1261$(_exit_0, _transition_0, _observed_0) {
  if (_observed_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Complete") {
    const _enter_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Completed", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": _world_0};
  } else {
    const _enter_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_1}, "world": _world_1, "phase": {$: "../../../../../../bendvy/src/ecs/machine-handlers.Enter"}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058published$1261$(_observed_0, _from_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $consumer$058publish$1261$(($consumer$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058committed$1261$(_slot_0, _from_0, _to_0)))), {$: "../../../../../../bendvy/src/ecs/machine.Transition", "from": _from_0, "to": _to_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058entry_outcome$1261$(_ordinal_0, _registry_0, _outcome_0, _next_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_0)({$: "Some", "value": _error_0}));
  } else {
    const _world_1 = _outcome_0["world"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../../../../../../bendvy/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_1)({$: "None"}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058prepend$1261$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../bendvy/src/ecs/machine-handlers.Complete") {
    const _entries_0 = _tail_0["entries"];
    const _world_0 = _tail_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Complete", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "world": _world_0};
  } else {
    const _entries_1 = _tail_0["entries"];
    const _world_1 = _tail_0["world"];
    const _error_0 = _tail_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": _head_0, "tail": _entries_1}, "world": _world_1, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $consumer$058returned7$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step8$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-second:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058from_runtime$1260$(_cursor_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058joined$1260$(_cursor_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0)));
}

function $consumer$058publish$1260$(_world_0, _event_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _ran_0 = _t_0["ran"];
  const _stream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, 1, _event_0)), "levelStream": _levelStream_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058committed$1260$(_slot_0, _from_0, _to_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _to_0, "pending": _pending_0, "previous": {$: "Some", "value": _from_0}, "changed": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058forced_pending$1260$(_same_0, _prior_0, _value_0) {
  if (_same_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _prior_0, "skipSame": false};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
  }
}

function $consumer$058returned7$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step8$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-second:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058from_runtime$1261$(_cursor_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058joined$1261$(_cursor_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1263$(_world_0)));
}

function $consumer$058publish$1261$(_world_0, _event_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _ran_0 = _t_0["ran"];
  const _stream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, 1, _event_0)), "levelStream": _levelStream_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045handlers$058committed$1261$(_slot_0, _from_0, _to_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _to_0, "pending": _pending_0, "previous": {$: "Some", "value": _from_0}, "changed": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $consumer$058step8$1260$(_world_0, _previous_0) {
  return $consumer$058returned8$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058joined$1260$(_cursor_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stream_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": {$: "../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "cursor": _cursor_0}, "snd": {$: "../../../../../../bendvy/src/ecs/inspector-transition-projection.TransitionLog", "stream": _stream_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(($consumer$058log$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $consumer$058step8$1261$(_world_0, _previous_0) {
  return $consumer$058returned8$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045transition$045projection$058joined$1261$(_cursor_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stream_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": {$: "../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "cursor": _cursor_0}, "snd": {$: "../../../../../../bendvy/src/ecs/inspector-transition-projection.TransitionLog", "stream": _stream_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1263$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1263$(($consumer$058log$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $consumer$058returned8$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step9$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-after-second:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058log$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _stream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _stream_0, "levelStream": _levelStream_0}, "snd": _stream_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $consumer$058returned8$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step9$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("false-after-second:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058log$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _stream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _stream_0, "levelStream": _levelStream_0}, "snd": _stream_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $consumer$058step9$1260$(_world_0, _previous_0) {
  return $consumer$058returned9$1260$(_previous_0, ($consumer$058queue$1260$(_world_0, true)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $consumer$058step9$1261$(_world_0, _previous_0) {
  return $consumer$058returned9$1261$(_previous_0, ($consumer$058queue$1261$(_world_0, true)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $consumer$058returned9$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step10$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-queued:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($consumer$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $consumer$058returned9$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step10$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-queued:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, ($consumer$058runner$1261$(_world_0, _args_0)));
  }
}

function $consumer$058step10$1260$(_world_0, _previous_0) {
  return $consumer$058returned10$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058runner$1260$(_world_0, __0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $consumer$058step10$1261$(_world_0, _previous_0) {
  return $consumer$058returned10$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058runner$1261$(_world_0, __0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
}

function $consumer$058returned10$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step11$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-queued-world:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $consumer$058returned10$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step11$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-queued-world:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058step11$1260$(_world_0, _previous_0) {
  return $consumer$058returned11$1260$(_previous_0, ($consumer$058marker$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $consumer$058step11$1261$(_world_0, _previous_0) {
  return $consumer$058returned11$1261$(_previous_0, ($consumer$058marker$1261$(_world_0)));
}

function $consumer$058returned11$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step12$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-marker:" + _text_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $consumer$058returned11$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step12$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-marker:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058step12$1260$(_world_0, _previous_0) {
  return $consumer$058returned12$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $consumer$058step12$1261$(_world_0, _previous_0) {
  return $consumer$058returned12$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058returned12$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step13$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-before-inspect:" + _text_0), "tail": {$: "Nil"}})));
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $consumer$058returned12$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step13$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-before-inspect:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058step13$1260$(_world_0, _previous_0) {
  return $consumer$058returned13$1260$(_previous_0, ($consumer$058inspect$1260$(_world_0)));
}

function $consumer$058step13$1261$(_world_0, _previous_0) {
  return $consumer$058returned13$1261$(_previous_0, ($consumer$058inspect$1261$(_world_0)));
}

function $consumer$058returned13$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step14$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058returned13$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step14$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058step14$1260$(_world_0, _previous_0) {
  return $consumer$058returned14$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058step14$1261$(_world_0, _previous_0) {
  return $consumer$058returned14$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058returned14$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step15$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-after-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058returned14$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step15$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-after-first:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058step15$1260$(_world_0, _previous_0) {
  return $consumer$058returned15$1260$(_previous_0, ($consumer$058inspect$1260$(_world_0)));
}

function $consumer$058step15$1261$(_world_0, _previous_0) {
  return $consumer$058returned15$1261$(_previous_0, ($consumer$058inspect$1261$(_world_0)));
}

function $consumer$058returned15$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step16$1260$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-second:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058returned15$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058step16$1261$(_world_0, ($List$append$(_previous_0, {$: "Con", "head": ("true-second:" + _text_0), "tail": {$: "Nil"}})));
}

function $consumer$058step16$1260$(_world_0, _previous_0) {
  return $consumer$058returned16$1260$(_previous_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058step16$1261$(_world_0, _previous_0) {
  return $consumer$058returned16$1261$(_previous_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058returned16$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058operational_returned$1260$(($List$append$(_previous_0, {$: "Con", "head": ("true-after-second:" + _text_0), "tail": {$: "Nil"}})), ($consumer$058operational$1260$(_world_0)));
}

function $consumer$058returned16$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058operational_returned$1261$(($List$append$(_previous_0, {$: "Con", "head": ("true-after-second:" + _text_0), "tail": {$: "Nil"}})), ($consumer$058operational$1261$(_world_0)));
}

function $consumer$058operational_returned$1260$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058final_world$1260$(($List$append$(_previous_0, {$: "Con", "head": ("operational:" + _text_0), "tail": {$: "Nil"}})), ($dump$058world$1260$(_world_0)));
}

function $consumer$058operational$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($consumer$058operational_resource$1260$(_ns_0, _resources_0)), _ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $consumer$058operational_returned$1261$(_previous_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $consumer$058final_world$1261$(($List$append$(_previous_0, {$: "Con", "head": ("operational:" + _text_0), "tail": {$: "Nil"}})), ($dump$058world$1261$(_world_0)));
}

function $consumer$058operational$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1262$(($consumer$058operational_resource$1261$(_ns_0, _resources_0)), _ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $consumer$058final_world$1260$(_previous_0, _result_0) {
  const _text_0 = _result_0["snd"];
  return $List$append$(_previous_0, {$: "Con", "head": ("after-operational:" + _text_0), "tail": {$: "Nil"}});
}

function $consumer$058operational_resource$1260$(_namespace_0, _resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _stream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $consumer$058operational_opened$1260$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open$1260$({$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": 1}, _stream_0, _namespace_0, 1)));
}

function $consumer$058final_world$1261$(_previous_0, _result_0) {
  const _text_0 = _result_0["snd"];
  return $List$append$(_previous_0, {$: "Con", "head": ("after-operational:" + _text_0), "tail": {$: "Nil"}});
}

function $consumer$058operational_resource$1261$(_namespace_0, _resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _stream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $consumer$058operational_opened$1261$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open$1261$({$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": 1}, _stream_0, _namespace_0, 1)));
}

function $consumer$058operational_opened$1260$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/machine-stream.Opened") {
    const _reader_0 = _result_0["reader"];
    const _stream_0 = _result_0["stream"];
    const _t_0 = _result_0["reading"];
    const _values_0 = _t_0["values"];
    const _lagged_0 = _t_0["lagged"];
    const _x_0 = ($Bool$show$(_lagged_0));
    const _x_1 = ($List$show$1260$(_values_0));
    const _x_2 = (":lagged=" + _x_0);
    return $consumer$058operational_finished$1260$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, (_x_1 + _x_2), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058finish$1260$(_reader_0, _stream_0, 1, true)));
  } else {
    const _stream_1 = _result_0["stream"];
    return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _stream_1, "levelStream": _levelStream_0}, "snd": "ReaderRefused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open$1260$(_reader_0, _stream_0, _namespace_0, _tick_0) {
  const _owner_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open_checked$1260$((_owner_0 === _namespace_0), {$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _owner_0, "id": _id_0}, _stream_0, _tick_0);
}

function $consumer$058operational_opened$1261$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/machine-stream.Opened") {
    const _reader_0 = _result_0["reader"];
    const _stream_0 = _result_0["stream"];
    const _t_0 = _result_0["reading"];
    const _values_0 = _t_0["values"];
    const _lagged_0 = _t_0["lagged"];
    const _x_0 = ($Bool$show$(_lagged_0));
    const _x_1 = ($List$show$1260$(_values_0));
    const _x_2 = (":lagged=" + _x_0);
    return $consumer$058operational_finished$1261$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, (_x_1 + _x_2), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058finish$1261$(_reader_0, _stream_0, 1, true)));
  } else {
    const _stream_1 = _result_0["stream"];
    return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _stream_1, "levelStream": _levelStream_0}, "snd": "ReaderRefused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open$1261$(_reader_0, _stream_0, _namespace_0, _tick_0) {
  const _owner_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open_checked$1261$((_owner_0 === _namespace_0), {$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _owner_0, "id": _id_0}, _stream_0, _tick_0);
}

function $consumer$058operational_finished$1260$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, _text_0, _result_0) {
  const _stream_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _stream_0, "levelStream": _levelStream_0}, "snd": _text_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058finish$1260$(_reader_0, _stream_0, _tick_0, _success_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open_checked$1260$(_allowed_0, _reader_0, _stream_0, _tick_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine-stream.ReaderRefused", "reader": _reader_0, "stream": _stream_0};
  } else {
    const _namespace_0 = _reader_0["namespace"];
    const _id_0 = _reader_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/machine-stream.Opened", "reader": {$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "stream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0)), "reading": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0))};
  }
}

function $consumer$058operational_finished$1261$(_owned_0, _flow_0, _level_0, _ran_0, _levelStream_0, _text_0, _result_0) {
  const _stream_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _stream_0, "levelStream": _levelStream_0}, "snd": _text_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058finish$1261$(_reader_0, _stream_0, _tick_0, _success_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058open_checked$1261$(_allowed_0, _reader_0, _stream_0, _tick_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine-stream.ReaderRefused", "reader": _reader_0, "stream": _stream_0};
  } else {
    const _namespace_0 = _reader_0["namespace"];
    const _id_0 = _reader_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/machine-stream.Opened", "reader": {$: "../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "stream": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0)), "reading": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe_position$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe_position$1260$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../bendvy/src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,1,0,0,2,2,0,11,1,11,7,1,2,1,0,0,1,2,0,2,1,0,26,1,27,4,7,1,2,3,0,0,1,4,0,2,1,0,26,1,27],["Tuple","Nil","Con","Nil","Con"]]);