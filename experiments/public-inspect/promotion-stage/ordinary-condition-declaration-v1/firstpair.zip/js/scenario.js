function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return {$: "Tuple", "fst": ($alpha$047consumer$058run$()), "snd": ($beta$047consumer$058run$())};
}

function $alpha$047consumer$058run$() {
  return $alpha$047consumer$058created$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($alpha$047state$058initial_resources$()))));
}

function $beta$047consumer$058run$() {
  return $beta$047consumer$058created$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($beta$047state$058initial_resources$()))));
}

function $alpha$047consumer$058created$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _t_0 = _result_0["factory"];
    const _factory_0 = _t_0["nextNamespace"];
    const _world_0 = _result_0["world"];
    return $alpha$047consumer$058reserved1$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $alpha$047state$058initial_resources$() {
  return {$: "alpha/state.Resources", "clock": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": array_node([11], [12])}, "machine": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": 3, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "inventory": array_node([81], [82]), "sibling": array_node([71], [72]), "barriers": 0};
}

function $beta$047consumer$058created$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _t_0 = _result_0["factory"];
    const _factory_0 = _t_0["nextNamespace"];
    const _world_0 = _result_0["world"];
    return $beta$047consumer$058reserved1$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $beta$047state$058initial_resources$() {
  return {$: "beta/state.Resources", "clock": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": array_node([11], [12])}, "machine": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": 3, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "inventory": array_node([81], [82]), "sibling": array_node([71], [72]), "barriers": 0};
}

function $alpha$047consumer$058reserved1$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $alpha$047consumer$058first_activated$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return $alpha$047consumer$058first_activated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($alpha$047state$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $beta$047consumer$058reserved1$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $beta$047consumer$058first_activated$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return $beta$047consumer$058first_activated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($beta$047state$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $alpha$047consumer$058first_activated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058reserved2$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $alpha$047state$058empty$(_unit_0) {
  return {$: "alpha/state.Store", "first": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$()), "second": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$()), "sibling": array_node([91], [92])};
}

function $beta$047consumer$058first_activated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058reserved2$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $beta$047state$058empty$(_unit_0) {
  return {$: "beta/state.Store", "first": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$()), "second": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$()), "sibling": array_node([91], [92])};
}

function $alpha$047consumer$058reserved2$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $alpha$047consumer$058second_activated$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return $alpha$047consumer$058second_activated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $beta$047consumer$058reserved2$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $beta$047consumer$058second_activated$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return $beta$047consumer$058second_activated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $alpha$047consumer$058second_activated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058reserved3$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $beta$047consumer$058second_activated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058reserved3$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $alpha$047consumer$058reserved3$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $alpha$047consumer$058third_activated$(_factory_0, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return $alpha$047consumer$058third_deactivated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
  }
}

function $beta$047consumer$058reserved3$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $beta$047consumer$058third_activated$(_factory_0, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return $beta$047consumer$058third_deactivated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
  }
}

function $alpha$047consumer$058third_activated$(_factory_0, _handle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058third_deactivated$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0)));
}

function $alpha$047consumer$058third_deactivated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058reserved4$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $beta$047consumer$058third_activated$(_factory_0, _handle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058third_deactivated$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0)));
}

function $beta$047consumer$058third_deactivated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058reserved4$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $alpha$047consumer$058reserved4$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058activated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $beta$047consumer$058reserved4$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058activated$(_factory_0, {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}});
}

function $alpha$047consumer$058activated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058seeded$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $alpha$047consumer$058seed$(_x_0);
}), _world_0)));
}

function $beta$047consumer$058activated$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058seeded$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1265$(run_clo((_x_0) => {
  return $beta$047consumer$058seed$(_x_0);
}), _world_0)));
}

function $alpha$047consumer$058seeded$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $alpha$047consumer$058constructed$(_factory_0, run_loop($alpha$047base$045application$058construct$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $alpha$047consumer$058barrier$(_x_0);
}))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $alpha$047consumer$058seed$(_store_0) {
  return {$: "Tuple", "fst": ($alpha$047consumer$058seed_second$(($alpha$047consumer$058seed_second$(($alpha$047consumer$058seed_first$(($alpha$047consumer$058seed_first$(_store_0, 1, 11)), 3, 33)), 2, 22)), 4, 44)), "snd": {$: "Unit"}};
}

function $beta$047consumer$058seeded$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $beta$047consumer$058constructed$(_factory_0, run_loop($beta$047base$045application$058construct$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $beta$047consumer$058barrier$(_x_0);
}))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1265$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1269$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $beta$047consumer$058seed$(_store_0) {
  return {$: "Tuple", "fst": ($beta$047consumer$058seed_second$(($beta$047consumer$058seed_second$(($beta$047consumer$058seed_first$(($beta$047consumer$058seed_first$(_store_0, 1, 11)), 3, 33)), 2, 22)), 4, 44)), "snd": {$: "Unit"}};
}

function $alpha$047consumer$058constructed$(_factory_0, _result_0) {
  if (_result_0.$ === "alpha/base-application.Ready") {
    const _app_0 = _result_0["app"];
    return $alpha$047consumer$058attached$(_factory_0, ($alpha$047application$058attach$(($alpha$047base$045application$058publish$(_app_0)))));
  } else if (_result_0.$ === "alpha/base-application.ServiceRejected") {
    return {$: "None"};
  } else if (_result_0.$ === "alpha/base-application.ComponentRejected") {
    return {$: "None"};
  } else {
    return {$: "None"};
  }
}

function $alpha$047base$045application$058construct$(_world_0) {
  return $alpha$047bindings$058service$1260$(run_clo((_x_0) => {
  return $alpha$047base$045application$058component_registered$(_x_0);
}), run_clo((_x_1) => {
  return $alpha$047base$045application$058service_rejected$(_x_1);
}), ($alpha$047bindings$058machine$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $alpha$047consumer$058barrier$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _id_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _clock_0 = _t_0["clock"];
  const _mode_0 = _t_0["machine"];
  const _inventory_0 = _t_0["inventory"];
  const _sibling_0 = _t_0["sibling"];
  const _count_0 = _t_0["barriers"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _sys_0 = _world_0["nextSystemId"];
  const _tick_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _id_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "alpha/state.Resources", "clock": _clock_0, "machine": _mode_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": ((_count_0 + 1) >>> 0)}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _sys_0, "clock": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $alpha$047consumer$058seed_second$(_store_0, _id_0, _value_0) {
  const _a_0 = _store_0["first"];
  const _b_0 = _store_0["second"];
  const _c_0 = _store_0["sibling"];
  return $alpha$047consumer$058swapped_second$({$: "alpha/state.Rest", "column": _a_0, "sibling": _c_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_b_0, _id_0)), _id_0, {$: "Some", "value": [_value_0]})));
}

function $alpha$047consumer$058seed_first$(_store_0, _id_0, _value_0) {
  const _a_0 = _store_0["first"];
  const _b_0 = _store_0["second"];
  const _c_0 = _store_0["sibling"];
  return $alpha$047consumer$058swapped_first$({$: "alpha/state.Rest", "column": _b_0, "sibling": _c_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_a_0, _id_0)), _id_0, {$: "Some", "value": [_value_0]})));
}

function $beta$047consumer$058constructed$(_factory_0, _result_0) {
  if (_result_0.$ === "beta/base-application.Ready") {
    const _app_0 = _result_0["app"];
    return $beta$047consumer$058attached$(_factory_0, ($beta$047application$058attach$(($beta$047base$045application$058publish$(_app_0)))));
  } else if (_result_0.$ === "beta/base-application.ServiceRejected") {
    return {$: "None"};
  } else if (_result_0.$ === "beta/base-application.ComponentRejected") {
    return {$: "None"};
  } else {
    return {$: "None"};
  }
}

function $beta$047base$045application$058construct$(_world_0) {
  return $beta$047bindings$058service$1260$(run_clo((_x_0) => {
  return $beta$047base$045application$058component_registered$(_x_0);
}), run_clo((_x_1) => {
  return $beta$047base$045application$058service_rejected$(_x_1);
}), ($beta$047bindings$058machine$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1261$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $beta$047consumer$058barrier$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _id_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _clock_0 = _t_0["clock"];
  const _mode_0 = _t_0["machine"];
  const _inventory_0 = _t_0["inventory"];
  const _sibling_0 = _t_0["sibling"];
  const _count_0 = _t_0["barriers"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _sys_0 = _world_0["nextSystemId"];
  const _tick_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _id_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "beta/state.Resources", "clock": _clock_0, "machine": _mode_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": ((_count_0 + 1) >>> 0)}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _sys_0, "clock": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $beta$047consumer$058seed_second$(_store_0, _id_0, _value_0) {
  const _a_0 = _store_0["first"];
  const _b_0 = _store_0["second"];
  const _c_0 = _store_0["sibling"];
  return $beta$047consumer$058swapped_second$({$: "beta/state.Rest", "column": _a_0, "sibling": _c_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_b_0, _id_0)), _id_0, {$: "Some", "value": [_value_0]})));
}

function $beta$047consumer$058seed_first$(_store_0, _id_0, _value_0) {
  const _a_0 = _store_0["first"];
  const _b_0 = _store_0["second"];
  const _c_0 = _store_0["sibling"];
  return $beta$047consumer$058swapped_first$({$: "beta/state.Rest", "column": _b_0, "sibling": _c_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_a_0, _id_0)), _id_0, {$: "Some", "value": [_value_0]})));
}

function $alpha$047consumer$058attached$(_factory_0, _result_0) {
  if (_result_0.$ === "alpha/application.Attached") {
    const _app_0 = _result_0["app"];
    return {$: "Some", "value": ($alpha$047consumer$058enabled$(_factory_0, ($alpha$047consumer$058checkpoint$(_app_0, true))))};
  } else {
    return {$: "None"};
  }
}

function $alpha$047application$058attach$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return $alpha$047application$058identified$(_schema_0, _family_0, _tick_0, _recipe_0, _debug_0, _world_0, ($alpha$047dispatch$058identified$(_owners_0)));
}

function $alpha$047base$045application$058publish$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return $alpha$047base$045application$058emitted$(_schema_0, _owners_0, _recipe_0, _debug_0, _family_0, nat_chk(_tick_0 + 1), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058emit_first$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058emit_first$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": {$: "alpha/state.FirstEvent", "value": 7}, "tail": {$: "Nil"}}, "second": {$: "Nil"}})), {$: "../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Nil"}, "second": {$: "Con", "head": {$: "alpha/state.SecondEvent", "value": true}, "tail": {$: "Nil"}}})), {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $alpha$047bindings$058service$1260$(_done_0, _failed_0, _app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058install$1260$(_done_0, _failed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1260$()), "ClockSystem", _app_0);
}

function $alpha$047base$045application$058component_registered$(_app_0) {
  return $alpha$047bindings$058component$1260$(run_clo((_x_0) => {
  return $alpha$047base$045application$058resource_registered$(_x_0);
}), run_clo((_x_1) => {
  return $alpha$047base$045application$058component_rejected$(_x_1);
}), _app_0);
}

function $alpha$047base$045application$058service_rejected$(_app_0) {
  return {$: "alpha/base-application.ServiceRejected", "app": _app_0};
}

function $alpha$047bindings$058machine$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058install$1260$(_app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $alpha$047consumer$058swapped_second$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return $alpha$047state$058second_put$(_rest_0, _column_0);
  } else {
    const _column_1 = _result_0["column"];
    return $alpha$047state$058second_put$(_rest_0, _column_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $alpha$047consumer$058swapped_first$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return $alpha$047state$058first_put$(_rest_0, _column_0);
  } else {
    const _column_1 = _result_0["column"];
    return $alpha$047state$058first_put$(_rest_0, _column_1);
  }
}

function $beta$047consumer$058attached$(_factory_0, _result_0) {
  if (_result_0.$ === "beta/application.Attached") {
    const _app_0 = _result_0["app"];
    return {$: "Some", "value": ($beta$047consumer$058enabled$(_factory_0, ($beta$047consumer$058checkpoint$(_app_0, true))))};
  } else {
    return {$: "None"};
  }
}

function $beta$047application$058attach$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return $beta$047application$058identified$(_schema_0, _family_0, _tick_0, _recipe_0, _debug_0, _world_0, ($beta$047dispatch$058identified$(_owners_0)));
}

function $beta$047base$045application$058publish$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return $beta$047base$045application$058emitted$(_schema_0, _owners_0, _recipe_0, _debug_0, _family_0, nat_chk(_tick_0 + 1), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058emit_first$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058emit_first$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1263$(_world_0)), {$: "../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": {$: "beta/state.FirstEvent", "value": 7}, "tail": {$: "Nil"}}, "second": {$: "Nil"}})), {$: "../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Nil"}, "second": {$: "Con", "head": {$: "beta/state.SecondEvent", "value": true}, "tail": {$: "Nil"}}})), {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $beta$047bindings$058service$1260$(_done_0, _failed_0, _app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058install$1261$(_done_0, _failed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1261$()), "ClockSystem", _app_0);
}

function $beta$047base$045application$058component_registered$(_app_0) {
  return $beta$047bindings$058component$1260$(run_clo((_x_0) => {
  return $beta$047base$045application$058resource_registered$(_x_0);
}), run_clo((_x_1) => {
  return $beta$047base$045application$058component_rejected$(_x_1);
}), _app_0);
}

function $beta$047base$045application$058service_rejected$(_app_0) {
  return {$: "beta/base-application.ServiceRejected", "app": _app_0};
}

function $beta$047bindings$058machine$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058install$1261$(_app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1261$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $beta$047consumer$058swapped_second$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return $beta$047state$058second_put$(_rest_0, _column_0);
  } else {
    const _column_1 = _result_0["column"];
    return $beta$047state$058second_put$(_rest_0, _column_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $beta$047consumer$058swapped_first$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return $beta$047state$058first_put$(_rest_0, _column_0);
  } else {
    const _column_1 = _result_0["column"];
    return $beta$047state$058first_put$(_rest_0, _column_1);
  }
}

function $alpha$047consumer$058enabled$(_factory_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $alpha$047consumer$058repeated$(_factory_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}}, ($alpha$047consumer$058checkpoint$(_app_0, true)));
}

function $alpha$047consumer$058checkpoint$(_app_0, _flag_0) {
  return $alpha$047consumer$058observed$(($alpha$047application$058snapshot$(($alpha$047application$058enabled$(_app_0, _flag_0)))));
}

function $alpha$047application$058identified$(_schema_0, _family_0, _tick_0, _recipe_0, _debug_0, _world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _sid_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _cid_0 = _t_1["fst"];
  const _rid_0 = _t_1["snd"];
  return $alpha$047application$058attached$(_family_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attach$1260$({$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "Composed", ($alpha$047application$058ids$(_sid_0, _cid_0, _rid_0)))));
}

function $alpha$047dispatch$058identified$(_owners_0) {
  const _t_0 = _owners_0["fst"];
  const _t_1 = _t_0["fst"];
  const _unit_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _t_3 = _t_2["registry"];
  const _namespace_0 = _t_3["namespace"];
  const _id_0 = _t_3["id"];
  const _name_0 = _t_3["name"];
  const _access_0 = _t_3["access"];
  const _cursor_0 = _t_3["cursor"];
  const _setup_0 = _t_2["setup"];
  const _component_0 = _t_0["snd"];
  const _resource_0 = _owners_0["snd"];
  return $alpha$047dispatch$058identified_component$(_unit_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "setup": _setup_0}, _id_0, _resource_0, ($alpha$047dispatch$058record_id$1261$(_component_0)));
}

function $alpha$047base$045application$058emitted$(_schema_0, _owners_0, _recipe_0, _debug_0, _family_0, _tick_0, _result_0) {
  const _world_0 = _result_0["world"];
  return $alpha$047base$045application$058synchronized$(_schema_0, _owners_0, _recipe_0, _debug_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize$1260$(_world_0, _family_0, _tick_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058emit_first$1260$(_tx_0, _event_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058emit$1260$(_tx_0, {$: "../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}, "second": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058install$1260$(_done_0, _failed_0, _setup_0, _name_0, _app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058defined$1260$(_done_0, _failed_0, _setup_0, _owners_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058define$1260$(_world_0, _name_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Setup", "entries": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1260$(($alpha$047state$058clock_declaration$()))), "tail": {$: "Nil"}}};
}

function $alpha$047bindings$058component$1260$(_done_0, _failed_0, _app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058register$1260$(_done_0, _failed_0, _app_0, "FirstRead", ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(($alpha$047state$058first_binding$()))))));
}

function $alpha$047base$045application$058resource_registered$(_app_0) {
  return $alpha$047bindings$058resource$1260$(run_clo((_x_0) => {
  return $alpha$047base$045application$058constructed$(_x_0);
}), run_clo((_x_1) => {
  return $alpha$047base$045application$058resource_rejected$(_x_1);
}), _app_0);
}

function $alpha$047base$045application$058component_rejected$(_app_0) {
  return {$: "alpha/base-application.ComponentRejected", "app": _app_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058install$1260$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058attach$1260$(_app_0);
}

function $alpha$047state$058second_put$(_rest_0, _column_0) {
  const _first_0 = _rest_0["column"];
  const _sibling_0 = _rest_0["sibling"];
  return {$: "alpha/state.Store", "first": _first_0, "second": _column_0, "sibling": _sibling_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $alpha$047state$058first_put$(_rest_0, _column_0) {
  const _second_0 = _rest_0["column"];
  const _sibling_0 = _rest_0["sibling"];
  return {$: "alpha/state.Store", "first": _column_0, "second": _second_0, "sibling": _sibling_0};
}

function $beta$047consumer$058enabled$(_factory_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $beta$047consumer$058repeated$(_factory_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}}, ($beta$047consumer$058checkpoint$(_app_0, true)));
}

function $beta$047consumer$058checkpoint$(_app_0, _flag_0) {
  return $beta$047consumer$058observed$(($beta$047application$058snapshot$(($beta$047application$058enabled$(_app_0, _flag_0)))));
}

function $beta$047application$058identified$(_schema_0, _family_0, _tick_0, _recipe_0, _debug_0, _world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _sid_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _cid_0 = _t_1["fst"];
  const _rid_0 = _t_1["snd"];
  return $beta$047application$058attached$(_family_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attach$1261$({$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "Composed", ($beta$047application$058ids$(_sid_0, _cid_0, _rid_0)))));
}

function $beta$047dispatch$058identified$(_owners_0) {
  const _t_0 = _owners_0["fst"];
  const _t_1 = _t_0["fst"];
  const _unit_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _t_3 = _t_2["registry"];
  const _namespace_0 = _t_3["namespace"];
  const _id_0 = _t_3["id"];
  const _name_0 = _t_3["name"];
  const _access_0 = _t_3["access"];
  const _cursor_0 = _t_3["cursor"];
  const _setup_0 = _t_2["setup"];
  const _component_0 = _t_0["snd"];
  const _resource_0 = _owners_0["snd"];
  return $beta$047dispatch$058identified_component$(_unit_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "setup": _setup_0}, _id_0, _resource_0, ($beta$047dispatch$058record_id$1261$(_component_0)));
}

function $beta$047base$045application$058emitted$(_schema_0, _owners_0, _recipe_0, _debug_0, _family_0, _tick_0, _result_0) {
  const _world_0 = _result_0["world"];
  return $beta$047base$045application$058synchronized$(_schema_0, _owners_0, _recipe_0, _debug_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize$1261$(_world_0, _family_0, _tick_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1263$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1263$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058emit_first$1261$(_tx_0, _event_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058emit$1261$(_tx_0, {$: "../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}, "second": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1263$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058install$1261$(_done_0, _failed_0, _setup_0, _name_0, _app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058defined$1261$(_done_0, _failed_0, _setup_0, _owners_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058define$1261$(_world_0, _name_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Setup", "entries": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1261$(($beta$047state$058clock_declaration$()))), "tail": {$: "Nil"}}};
}

function $beta$047bindings$058component$1260$(_done_0, _failed_0, _app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058register$1261$(_done_0, _failed_0, _app_0, "FirstRead", ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1262$(($beta$047state$058first_binding$()))))));
}

function $beta$047base$045application$058resource_registered$(_app_0) {
  return $beta$047bindings$058resource$1260$(run_clo((_x_0) => {
  return $beta$047base$045application$058constructed$(_x_0);
}), run_clo((_x_1) => {
  return $beta$047base$045application$058resource_rejected$(_x_1);
}), _app_0);
}

function $beta$047base$045application$058component_rejected$(_app_0) {
  return {$: "beta/base-application.ComponentRejected", "app": _app_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058install$1261$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058attach$1261$(_app_0);
}

function $beta$047state$058second_put$(_rest_0, _column_0) {
  const _first_0 = _rest_0["column"];
  const _sibling_0 = _rest_0["sibling"];
  return {$: "beta/state.Store", "first": _first_0, "second": _column_0, "sibling": _sibling_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $beta$047state$058first_put$(_rest_0, _column_0) {
  const _second_0 = _rest_0["column"];
  const _sibling_0 = _rest_0["sibling"];
  return {$: "beta/state.Store", "first": _column_0, "second": _second_0, "sibling": _sibling_0};
}

function $alpha$047consumer$058repeated$(_factory_0, _before_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $alpha$047consumer$058disabled$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), ($alpha$047consumer$058checkpoint$(_app_0, false)));
}

function $alpha$047consumer$058observed$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["scheduled"];
  const _t_2 = _t_1["scheduled"];
  const _t_3 = _t_2["app"];
  const _schema_0 = _t_3["schema"];
  const _t_4 = _t_3["app"];
  const _world_0 = _t_4["world"];
  const _owners_0 = _t_4["owners"];
  const _recipe_0 = _t_4["recipe"];
  const _debug_0 = _t_4["debug"];
  const _plan_0 = _t_2["plan"];
  const _namespace_0 = _t_2["namespace"];
  const _name_0 = _t_2["name"];
  const _steps_0 = _t_2["steps"];
  const _needs_0 = _t_2["needs"];
  const _program_0 = _t_1["program"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _view_0 = _result_0["snd"];
  return $alpha$047consumer$058folded$(_program_0, _view_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _schema_0, {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, _recipe_0, _debug_0, ($alpha$047bindings$058fold4$())(_owners_0));
}

function $alpha$047application$058snapshot$(_value_0) {
  const _scheduled_0 = _value_0["scheduled"];
  const _family_0 = _value_0["family"];
  const _tick_0 = _value_0["tick"];
  return $alpha$047application$058observed$(_family_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058snapshot$1260$(_scheduled_0)));
}

function $alpha$047application$058enabled$(_value_0, _flag_0) {
  const _scheduled_0 = _value_0["scheduled"];
  const _family_0 = _value_0["family"];
  const _tick_0 = _value_0["tick"];
  return {$: "alpha/application.Application", "scheduled": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058enabled$1260$(_scheduled_0, _flag_0)), "family": _family_0, "tick": _tick_0};
}

function $alpha$047application$058attached$(_family_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid") {
    const _t_0 = _result_0["app"];
    const _schema_0 = _t_0["schema"];
    const _t_1 = _t_0["app"];
    const _world_0 = _t_1["world"];
    const _owners_0 = _t_1["owners"];
    const _recipe_0 = _t_1["recipe"];
    const _debug_0 = _t_1["debug"];
    return {$: "alpha/application.Invalid", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}};
  } else {
    const _scheduled_0 = _result_0["app"];
    return {$: "alpha/application.Attached", "app": {$: "alpha/application.Application", "scheduled": _scheduled_0, "family": _family_0, "tick": _tick_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attach$1260$(_app_0, _name_0, _ids_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058prepared$1260$(_app_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058materialize$1260$(($alpha$047application$058program$()), _ids_0)));
}

function $alpha$047application$058ids$(_sid_0, _cid_0, _rid_0) {
  return {$: "alpha/application.Ids", "service": _sid_0, "component": _cid_0, "resource": _rid_0};
}

function $alpha$047dispatch$058identified_component$(_unit_0, _service_0, _sid_0, _resource_0, _result_0) {
  const _component_0 = _result_0["fst"];
  const _cid_0 = _result_0["snd"];
  return $alpha$047dispatch$058identified_resource$(_unit_0, _service_0, _sid_0, _component_0, _cid_0, ($alpha$047dispatch$058record_id$1260$(_resource_0)));
}

function $alpha$047dispatch$058record_id$1261$(_record_0) {
  const _token_0 = _record_0["token"];
  const _t_0 = _record_0["fields"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _slot_0 = _t_0["slot"];
  const _clauses_0 = _t_0["clauses"];
  const _kind_0 = _t_0["kind"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}}, "snd": _id_0};
}

function $alpha$047base$045application$058synchronized$(_schema_0, _owners_0, _recipe_0, _debug_0, _tick_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _family_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize$1260$(_world_0, _state_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize_world$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058defined$1260$(_done_0, _failed_0, _setup_0, _owners_0, _recipe_0, _debug_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1262$(_world_1, _owners_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": _registry_0, "setup": _setup_0}, _debug_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058define$1260$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1262$(_world_0, _name_0, {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1260$(($alpha$047state$058clock_declaration$()))), "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return {$: "../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Service"}, "key": _key_0, "name": _key_0};
}

function $alpha$047state$058clock_declaration$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1260$(1, "Clock");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058register$1260$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058defined$1260$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_define$1260$(_world_0, _name_0, _slot_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(_binding_0) {
  const _identity_0 = _binding_0["identity"];
  return _identity_0;
}

function $alpha$047state$058first_binding$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$("First")));
}

function $alpha$047bindings$058resource$1260$(_done_0, _failed_0, _app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058register$1260$(_done_0, _failed_0, _app_0, "InventoryRead", ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(($alpha$047state$058inventory_identity$()))));
}

function $alpha$047base$045application$058constructed$(_app_0) {
  return {$: "alpha/base-application.Ready", "app": ($alpha$047base$045application$058started$(_app_0))};
}

function $alpha$047base$045application$058resource_rejected$(_app_0) {
  return {$: "alpha/base-application.ResourceRejected", "app": _app_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058attach$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _debug_0 = _app_0["debug"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $beta$047consumer$058repeated$(_factory_0, _before_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $beta$047consumer$058disabled$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), ($beta$047consumer$058checkpoint$(_app_0, false)));
}

function $beta$047consumer$058observed$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["scheduled"];
  const _t_2 = _t_1["scheduled"];
  const _t_3 = _t_2["app"];
  const _schema_0 = _t_3["schema"];
  const _t_4 = _t_3["app"];
  const _world_0 = _t_4["world"];
  const _owners_0 = _t_4["owners"];
  const _recipe_0 = _t_4["recipe"];
  const _debug_0 = _t_4["debug"];
  const _plan_0 = _t_2["plan"];
  const _namespace_0 = _t_2["namespace"];
  const _name_0 = _t_2["name"];
  const _steps_0 = _t_2["steps"];
  const _needs_0 = _t_2["needs"];
  const _program_0 = _t_1["program"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _view_0 = _result_0["snd"];
  return $beta$047consumer$058folded$(_program_0, _view_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _schema_0, {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, _recipe_0, _debug_0, ($beta$047bindings$058fold4$())(_owners_0));
}

function $beta$047application$058snapshot$(_value_0) {
  const _scheduled_0 = _value_0["scheduled"];
  const _family_0 = _value_0["family"];
  const _tick_0 = _value_0["tick"];
  return $beta$047application$058observed$(_family_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058snapshot$1261$(_scheduled_0)));
}

function $beta$047application$058enabled$(_value_0, _flag_0) {
  const _scheduled_0 = _value_0["scheduled"];
  const _family_0 = _value_0["family"];
  const _tick_0 = _value_0["tick"];
  return {$: "beta/application.Application", "scheduled": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058enabled$1261$(_scheduled_0, _flag_0)), "family": _family_0, "tick": _tick_0};
}

function $beta$047application$058attached$(_family_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid") {
    const _t_0 = _result_0["app"];
    const _schema_0 = _t_0["schema"];
    const _t_1 = _t_0["app"];
    const _world_0 = _t_1["world"];
    const _owners_0 = _t_1["owners"];
    const _recipe_0 = _t_1["recipe"];
    const _debug_0 = _t_1["debug"];
    return {$: "beta/application.Invalid", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}};
  } else {
    const _scheduled_0 = _result_0["app"];
    return {$: "beta/application.Attached", "app": {$: "beta/application.Application", "scheduled": _scheduled_0, "family": _family_0, "tick": _tick_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attach$1261$(_app_0, _name_0, _ids_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058prepared$1261$(_app_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058materialize$1261$(($beta$047application$058program$()), _ids_0)));
}

function $beta$047application$058ids$(_sid_0, _cid_0, _rid_0) {
  return {$: "beta/application.Ids", "service": _sid_0, "component": _cid_0, "resource": _rid_0};
}

function $beta$047dispatch$058identified_component$(_unit_0, _service_0, _sid_0, _resource_0, _result_0) {
  const _component_0 = _result_0["fst"];
  const _cid_0 = _result_0["snd"];
  return $beta$047dispatch$058identified_resource$(_unit_0, _service_0, _sid_0, _component_0, _cid_0, ($beta$047dispatch$058record_id$1260$(_resource_0)));
}

function $beta$047dispatch$058record_id$1261$(_record_0) {
  const _token_0 = _record_0["token"];
  const _t_0 = _record_0["fields"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _slot_0 = _t_0["slot"];
  const _clauses_0 = _t_0["clauses"];
  const _kind_0 = _t_0["kind"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}}, "snd": _id_0};
}

function $beta$047base$045application$058synchronized$(_schema_0, _owners_0, _recipe_0, _debug_0, _tick_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _family_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize$1261$(_world_0, _state_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize_world$1261$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1263$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1263$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058emit$1261$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058defined$1261$(_done_0, _failed_0, _setup_0, _owners_0, _recipe_0, _debug_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1265$(_world_1, _owners_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": _registry_0, "setup": _setup_0}, _debug_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058define$1261$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1265$(_world_0, _name_0, {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1261$(($beta$047state$058clock_declaration$()))), "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  return {$: "../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Service"}, "key": _key_0, "name": _key_0};
}

function $beta$047state$058clock_declaration$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1261$(1, "Clock");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058register$1261$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058defined$1261$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_define$1261$(_world_0, _name_0, _slot_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1262$(_binding_0) {
  const _identity_0 = _binding_0["identity"];
  return _identity_0;
}

function $beta$047state$058first_binding$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1262$("First")));
}

function $beta$047bindings$058resource$1260$(_done_0, _failed_0, _app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058register$1261$(_done_0, _failed_0, _app_0, "InventoryRead", ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(($beta$047state$058inventory_identity$()))));
}

function $beta$047base$045application$058constructed$(_app_0) {
  return {$: "beta/base-application.Ready", "app": ($beta$047base$045application$058started$(_app_0))};
}

function $beta$047base$045application$058resource_rejected$(_app_0) {
  return {$: "beta/base-application.ResourceRejected", "app": _app_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058attach$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _debug_0 = _app_0["debug"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $alpha$047consumer$058disabled$(_factory_0, _before_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $alpha$047consumer$058executed$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), ($alpha$047application$058run$(_app_0)));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $alpha$047consumer$058folded$(_program_0, _description_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _schema_0, _runtime_0, _recipe_0, _debug_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $alpha$047consumer$058physical_returned$(_program_0, _description_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _fields_0, _schema_0, _owners_0, _recipe_0, _debug_0, ($alpha$047physical$058runtime$(_runtime_0)));
}

function $alpha$047bindings$058fold4$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1262$(_x_0);
});
}

function $alpha$047application$058observed$(_family_0, _tick_0, _result_0) {
  const _scheduled_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "alpha/application.Application", "scheduled": _scheduled_0, "family": _family_0, "tick": _tick_0}, "snd": _view_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058snapshot$1260$(_app_0) {
  const _scheduled_0 = _app_0["scheduled"];
  const _program_0 = _app_0["program"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058observed$1260$(_program_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058snapshot$1260$(_scheduled_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058enabled$1260$(_app_0, _flag_0) {
  const _scheduled_0 = _app_0["scheduled"];
  const _program_0 = _app_0["program"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058enabled$1260$(_scheduled_0, _flag_0)), "program": _program_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058prepared$1260$(_app_0, _name_0, _program_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058validated$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058valid$1260$(_program_0)), _app_0, _name_0, _program_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058materialize$1260$(_declaration_0, _ids_0) {
  const _width_0 = _declaration_0["width"];
  const _build_0 = _declaration_0["build"];
  const _names_0 = _declaration_0["names"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built$1260$(_width_0, _names_0, _build_0(_ids_0));
}

function $alpha$047application$058program$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058phase$1260$("Queries", {$: "Nil"})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1260$({$: "Nil"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1260$("RunComponents")))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1261$({$: "Nil"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1261$("SkipResources")))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1262$({$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1260$(($alpha$047state$058clock_declaration$()))), "tail": {$: "Nil"}}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1260$("RunService")))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058barrier$1260$({$: "Nil"})));
}

function $alpha$047dispatch$058identified_resource$(_unit_0, _service_0, _sid_0, _component_0, _cid_0, _result_0) {
  const _resource_0 = _result_0["fst"];
  const _rid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": _unit_0, "snd": _service_0}, "snd": _component_0}, "snd": _resource_0}, "snd": {$: "Tuple", "fst": _sid_0, "snd": {$: "Tuple", "fst": _cid_0, "snd": _rid_0}}};
}

function $alpha$047dispatch$058record_id$1260$(_record_0) {
  const _token_0 = _record_0["token"];
  const _t_0 = _record_0["fields"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _slot_0 = _t_0["slot"];
  const _clauses_0 = _t_0["clauses"];
  const _kind_0 = _t_0["kind"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize_world$1260$(_state_0, _tick_0, _observed_0) {
  const _family_0 = _state_0["family"];
  const _owners_0 = _state_0["owners"];
  const _journal_0 = _state_0["journal"];
  const _frameStart_0 = _state_0["frameStart"];
  const _world_0 = _observed_0["fst"];
  const _records_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_records_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1263$(_journal_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1264$(_published_0));
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": ($alpha$047event$045setup$058sync$())(_family_0)(_tick_0)(_published_0), "owners": _owners_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1263$((0 < _x_0), _journal_0, _tick_0, _published_0)), "frameStart": _frameStart_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1262$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1260$(_id_0, _key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Declaration", "id": _id_0, "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058defined$1260$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058extracted$1260$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_define$1260$(_world_0, _name_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_registered$1260$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(($alpha$047operations$058component_query$()))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058access$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(($alpha$047operations$058component_query$()))))))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1260$(_identity_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-component-binding.Binding", "identity": _identity_0, "family": {$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058register$1260$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058defined$1260$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058define$1260$(_world_0, _name_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $alpha$047state$058inventory_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1260$("Inventory");
}

function $alpha$047base$045application$058started$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058start$1260$(($alpha$047event$045setup$058provision$()), array_node([31], [32]), 2, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058attached$1260$(($alpha$047base$045application$058schema$()), _value_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $beta$047consumer$058disabled$(_factory_0, _before_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $beta$047consumer$058executed$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), ($beta$047application$058run$(_app_0)));
}

function $beta$047consumer$058folded$(_program_0, _description_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _schema_0, _runtime_0, _recipe_0, _debug_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $beta$047consumer$058physical_returned$(_program_0, _description_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _fields_0, _schema_0, _owners_0, _recipe_0, _debug_0, ($beta$047physical$058runtime$(_runtime_0)));
}

function $beta$047bindings$058fold4$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1265$(_x_0);
});
}

function $beta$047application$058observed$(_family_0, _tick_0, _result_0) {
  const _scheduled_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "beta/application.Application", "scheduled": _scheduled_0, "family": _family_0, "tick": _tick_0}, "snd": _view_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058snapshot$1261$(_app_0) {
  const _scheduled_0 = _app_0["scheduled"];
  const _program_0 = _app_0["program"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058observed$1261$(_program_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058snapshot$1261$(_scheduled_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058enabled$1261$(_app_0, _flag_0) {
  const _scheduled_0 = _app_0["scheduled"];
  const _program_0 = _app_0["program"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058enabled$1261$(_scheduled_0, _flag_0)), "program": _program_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058prepared$1261$(_app_0, _name_0, _program_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058validated$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058valid$1261$(_program_0)), _app_0, _name_0, _program_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058materialize$1261$(_declaration_0, _ids_0) {
  const _width_0 = _declaration_0["width"];
  const _build_0 = _declaration_0["build"];
  const _names_0 = _declaration_0["names"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built$1261$(_width_0, _names_0, _build_0(_ids_0));
}

function $beta$047application$058program$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058phase$1261$("Queries", {$: "Nil"})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1263$({$: "Nil"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1262$("RunComponents")))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1264$({$: "Nil"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1263$("SkipResources")))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1265$({$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1261$(($beta$047state$058clock_declaration$()))), "tail": {$: "Nil"}}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1262$("RunService")))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058barrier$1261$({$: "Nil"})));
}

function $beta$047dispatch$058identified_resource$(_unit_0, _service_0, _sid_0, _component_0, _cid_0, _result_0) {
  const _resource_0 = _result_0["fst"];
  const _rid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": _unit_0, "snd": _service_0}, "snd": _component_0}, "snd": _resource_0}, "snd": {$: "Tuple", "fst": _sid_0, "snd": {$: "Tuple", "fst": _cid_0, "snd": _rid_0}}};
}

function $beta$047dispatch$058record_id$1260$(_record_0) {
  const _token_0 = _record_0["token"];
  const _t_0 = _record_0["fields"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _slot_0 = _t_0["slot"];
  const _clauses_0 = _t_0["clauses"];
  const _kind_0 = _t_0["kind"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058synchronize_world$1261$(_state_0, _tick_0, _observed_0) {
  const _family_0 = _state_0["family"];
  const _owners_0 = _state_0["owners"];
  const _journal_0 = _state_0["journal"];
  const _frameStart_0 = _state_0["frameStart"];
  const _world_0 = _observed_0["fst"];
  const _records_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_records_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1267$(_journal_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1269$(_published_0));
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": ($beta$047event$045setup$058sync$())(_family_0)(_tick_0)(_published_0), "owners": _owners_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1267$((0 < _x_0), _journal_0, _tick_0, _published_0)), "frameStart": _frameStart_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1263$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1265$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1265$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1261$(_id_0, _key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Declaration", "id": _id_0, "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058defined$1261$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058extracted$1261$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component$1261$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_define$1261$(_world_0, _name_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_registered$1261$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1261$(($beta$047operations$058component_query$()))))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1264$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058access$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1261$(($beta$047operations$058component_query$()))))))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1262$(_identity_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-component-binding.Binding", "identity": _identity_0, "family": {$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(_identity_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1262$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058register$1261$(_done_0, _failed_0, _app_0, _name_0, _slot_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058defined$1261$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058define$1261$(_world_0, _name_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $beta$047state$058inventory_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1261$("Inventory");
}

function $beta$047base$045application$058started$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058start$1261$(($beta$047event$045setup$058provision$()), array_node([31], [32]), 2, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058attached$1261$(($beta$047base$045application$058schema$()), _value_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $alpha$047consumer$058executed$(_factory_0, _before_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _completion_0 = _result_0["snd"];
  return $alpha$047consumer$058post_enabled$(_factory_0, _before_0, _completion_0, ($alpha$047consumer$058checkpoint$(_app_0, true)));
}

function $alpha$047application$058run$(_value_0) {
  const _scheduled_0 = _value_0["scheduled"];
  const _family_0 = _value_0["family"];
  const _tick_0 = _value_0["tick"];
  return $alpha$047application$058completed$(_family_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058run$1260$(_scheduled_0)));
}

function $alpha$047consumer$058physical_returned$(_program_0, _description_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _fields_0, _schema_0, _owners_0, _recipe_0, _debug_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "alpha/application.Application", "scheduled": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "program": _program_0}, "family": _family_0, "tick": _tick_0}, "snd": {$: "alpha/consumer.Checkpoint", "description": _description_0, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0, "fields": _fields_0, "physical": _text_0}};
}

function $alpha$047physical$058runtime$(_value_0) {
  const _w_0 = _value_0["world"];
  const _f_0 = _value_0["family"];
  const _t_0 = _value_0["tick"];
  return $alpha$047physical$058runtime_join$(_t_0, ($alpha$047physical$058world$(_w_0)), ($alpha$047physical$058family$(_f_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1262$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1262$(($alpha$047bindings$058fold3$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1261$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058observed$1260$(_program_0, _result_0) {
  const _scheduled_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}, "snd": {$: "Some", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058described$1260$(_program_0, _view_0))}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058snapshot$1260$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058returned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058enabled$1260$(_value_0, _flag_0) {
  const _app_0 = _value_0["app"];
  const _plan_0 = _value_0["plan"];
  const _namespace_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _needs_0 = _value_0["needs"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058enabled$1260$(_app_0, _flag_0)), "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058validated$1260$(_valid_0, _app_0, _name_0, _program_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid", "app": _app_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attached$1260$(_program_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058attach$1260$(_app_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058plan$1260$(_program_0)))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058valid$1260$(_entries_0) {
  const _width_0 = _entries_0["width"];
  const _plan_0 = _entries_0["plan"];
  const _names_0 = _entries_0["names"];
  return $Bool$and$(($Nat$is_eq$(_width_0, ($List$length$(_names_0)))), ($Bool$and$(($Nat$is_le$(_width_0, 4294967296)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1260$(_plan_0, _width_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built$1260$(_width_0, _names_0, _result_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Entries", "width": _width_0, "plan": _result_0, "names": _names_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1260$(_first_0, _second_0) {
  const _leftWidth_0 = _first_0["width"];
  const _leftBuild_0 = _first_0["build"];
  const _leftNames_0 = _first_0["names"];
  const _leftEval_0 = _first_0["evaluate"];
  const _rightWidth_0 = _second_0["width"];
  const _rightBuild_0 = _second_0["build"];
  const _rightNames_0 = _second_0["names"];
  const _rightEval_0 = _second_0["evaluate"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": nat_chk(_leftWidth_0 + _rightWidth_0), "build": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built_pair$1260$(_leftBuild_0, _rightBuild_0, _leftWidth_0, _x_0);
}), "names": ($List$append$(_leftNames_0, _rightNames_0)), "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluated_pair$1260$(_leftEval_0, _rightEval_0, _leftWidth_0, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058phase$1260$(_name_0, _requirements_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 0, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": _name_0}, "requirements": _requirements_0};
}), "names": {$: "Nil"}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return {$: "Tuple", "fst": _x_1, "snd": false};
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1260$(_requirements_0, _leaf_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 1, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": ($alpha$047application$058component_id$(_x_0)), "condition": 0}, "requirements": _requirements_0};
}), "names": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1260$(_leaf_0)), "tail": {$: "Nil"}}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $alpha$047application$058always$(_x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1260$(_name_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Declaration", "name": _name_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1261$(_requirements_0, _leaf_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 1, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": ($alpha$047application$058resource_id$(_x_0)), "condition": 0}, "requirements": _requirements_0};
}), "names": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1261$(_leaf_0)), "tail": {$: "Nil"}}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $alpha$047application$058never$(_x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1261$(_name_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Declaration", "name": _name_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1262$(_requirements_0, _leaf_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 1, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": ($alpha$047application$058service_id$(_x_0)), "condition": 0}, "requirements": _requirements_0};
}), "names": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1260$(_leaf_0)), "tail": {$: "Nil"}}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $alpha$047application$058always$(_x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1260$(_value_0) {
  const _id_0 = _value_0["id"];
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Service", "id": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058barrier$1260$(_requirements_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 0, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Barrier"}, "requirements": _requirements_0};
}), "names": {$: "Nil"}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return {$: "Tuple", "fst": _x_1, "snd": false};
});
})};
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1263$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1263$(_batches_0, 0);
}

function $alpha$047event$045setup$058sync$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1261$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1263$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1264$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1264$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1264$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058extracted$1260$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1261$(_world_0, _owners_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component$1260$(_owner_0) {
  const _registry_0 = _owner_0["registry"];
  const _slot_0 = _owner_0["slot"];
  const _clauses_0 = _owner_0["clauses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component_registry$1260$(_slot_0, _clauses_0, _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_registered$1260$(_slot_0, _clauses_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-system.Defined", "world": _world_1, "owner": {$: "../../../../../../bendvy/src/ecs/ordinary-system.Owner", "registry": _registry_0, "slot": _slot_0, "clauses": _clauses_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(_declaration_0) {
  const _clauses_0 = _declaration_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(_declaration_0) {
  const _operational_0 = _declaration_0["operational"];
  return _operational_0;
}

function $alpha$047operations$058component_query$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058read$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058access$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058access$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058defined$1260$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058extracted$1260$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058field_owner$1260$(_slot_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058define$1260$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058registered$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1260$(($alpha$047operations$058resource_declaration$()))))))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1260$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Resource", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058start$1260$(_provision_0, _events_0, _capacity_0, _value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["app"];
  const _world_0 = _t_0["world"];
  const _owners_0 = _t_0["owners"];
  const _recipe_0 = _t_0["recipe"];
  const _debug_0 = _t_0["debug"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058setup$1261$(_world_0, _provision_0, _events_0, _capacity_0)), "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0};
}

function $alpha$047event$045setup$058provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1261$(($alpha$047event$045setup$058pair_provision$()), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1262$("Source.UnusedEvent")))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058attached$1260$(_schema_0, _app_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0};
}

function $alpha$047base$045application$058schema$() {
  return $alpha$047base$045application$058extracted$(($alpha$047state$058provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $beta$047consumer$058executed$(_factory_0, _before_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _completion_0 = _result_0["snd"];
  return $beta$047consumer$058post_enabled$(_factory_0, _before_0, _completion_0, ($beta$047consumer$058checkpoint$(_app_0, true)));
}

function $beta$047application$058run$(_value_0) {
  const _scheduled_0 = _value_0["scheduled"];
  const _family_0 = _value_0["family"];
  const _tick_0 = _value_0["tick"];
  return $beta$047application$058completed$(_family_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058run$1261$(_scheduled_0)));
}

function $beta$047consumer$058physical_returned$(_program_0, _description_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _fields_0, _schema_0, _owners_0, _recipe_0, _debug_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "beta/application.Application", "scheduled": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "program": _program_0}, "family": _family_0, "tick": _tick_0}, "snd": {$: "beta/consumer.Checkpoint", "description": _description_0, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0, "fields": _fields_0, "physical": _text_0}};
}

function $beta$047physical$058runtime$(_value_0) {
  const _w_0 = _value_0["world"];
  const _f_0 = _value_0["family"];
  const _t_0 = _value_0["tick"];
  return $beta$047physical$058runtime_join$(_t_0, ($beta$047physical$058world$(_w_0)), ($beta$047physical$058family$(_f_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1265$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1265$(($beta$047bindings$058fold3$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1263$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058observed$1261$(_program_0, _result_0) {
  const _scheduled_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}, "snd": {$: "Some", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058described$1261$(_program_0, _view_0))}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058snapshot$1261$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058returned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058snapshot$1261$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058enabled$1261$(_value_0, _flag_0) {
  const _app_0 = _value_0["app"];
  const _plan_0 = _value_0["plan"];
  const _namespace_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _needs_0 = _value_0["needs"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058enabled$1261$(_app_0, _flag_0)), "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058validated$1261$(_valid_0, _app_0, _name_0, _program_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid", "app": _app_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attached$1261$(_program_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058attach$1261$(_app_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058plan$1261$(_program_0)))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058valid$1261$(_entries_0) {
  const _width_0 = _entries_0["width"];
  const _plan_0 = _entries_0["plan"];
  const _names_0 = _entries_0["names"];
  return $Bool$and$(($Nat$is_eq$(_width_0, ($List$length$(_names_0)))), ($Bool$and$(($Nat$is_le$(_width_0, 4294967296)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1261$(_plan_0, _width_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built$1261$(_width_0, _names_0, _result_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Entries", "width": _width_0, "plan": _result_0, "names": _names_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058sequence$1261$(_first_0, _second_0) {
  const _leftWidth_0 = _first_0["width"];
  const _leftBuild_0 = _first_0["build"];
  const _leftNames_0 = _first_0["names"];
  const _leftEval_0 = _first_0["evaluate"];
  const _rightWidth_0 = _second_0["width"];
  const _rightBuild_0 = _second_0["build"];
  const _rightNames_0 = _second_0["names"];
  const _rightEval_0 = _second_0["evaluate"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": nat_chk(_leftWidth_0 + _rightWidth_0), "build": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built_pair$1261$(_leftBuild_0, _rightBuild_0, _leftWidth_0, _x_0);
}), "names": ($List$append$(_leftNames_0, _rightNames_0)), "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluated_pair$1261$(_leftEval_0, _rightEval_0, _leftWidth_0, _x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058phase$1261$(_name_0, _requirements_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 0, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": _name_0}, "requirements": _requirements_0};
}), "names": {$: "Nil"}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return {$: "Tuple", "fst": _x_1, "snd": false};
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1263$(_requirements_0, _leaf_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 1, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": ($beta$047application$058component_id$(_x_0)), "condition": 0}, "requirements": _requirements_0};
}), "names": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1262$(_leaf_0)), "tail": {$: "Nil"}}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $beta$047application$058always$(_x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1262$(_name_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Declaration", "name": _name_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1264$(_requirements_0, _leaf_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 1, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": ($beta$047application$058resource_id$(_x_0)), "condition": 0}, "requirements": _requirements_0};
}), "names": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1263$(_leaf_0)), "tail": {$: "Nil"}}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $beta$047application$058never$(_x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058named$1263$(_name_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Declaration", "name": _name_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058system$1265$(_requirements_0, _leaf_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 1, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": ($beta$047application$058service_id$(_x_0)), "condition": 0}, "requirements": _requirements_0};
}), "names": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1262$(_leaf_0)), "tail": {$: "Nil"}}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $beta$047application$058always$(_x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1261$(_value_0) {
  const _id_0 = _value_0["id"];
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Service", "id": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058barrier$1261$(_requirements_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-condition-declaration.Program", "width": 0, "build": run_clo((_x_0) => {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Barrier"}, "requirements": _requirements_0};
}), "names": {$: "Nil"}, "evaluate": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return {$: "Tuple", "fst": _x_1, "snd": false};
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1267$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1267$(_batches_0, 0);
}

function $beta$047event$045setup$058sync$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1263$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1267$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1268$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1269$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1269$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1265$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045component$058extracted$1261$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1264$(_world_0, _owners_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component$1261$(_owner_0) {
  const _registry_0 = _owner_0["registry"];
  const _slot_0 = _owner_0["slot"];
  const _clauses_0 = _owner_0["clauses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component_registry$1261$(_slot_0, _clauses_0, _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_registered$1261$(_slot_0, _clauses_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-system.Defined", "world": _world_1, "owner": {$: "../../../../../../bendvy/src/ecs/ordinary-system.Owner", "registry": _registry_0, "slot": _slot_0, "clauses": _clauses_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058clauses$1261$(_declaration_0) {
  const _clauses_0 = _declaration_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1261$(_declaration_0) {
  const _operational_0 = _declaration_0["operational"];
  return _operational_0;
}

function $beta$047operations$058component_query$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058read$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1264$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058access$1261$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058access$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058defined$1261$(_done_0, _failed_0, _owners_0, _recipe_0, _debug_0, _slot_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected") {
    const _world_0 = _result_0["world"];
    return run_tail(_failed_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0});
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058extracted$1261$(_done_0, _failed_0, _world_1, _owners_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058field_owner$1261$(_slot_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058define$1261$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058registered$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1263$(_world_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1261$(($beta$047operations$058resource_declaration$()))))))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource$1261$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Resource", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058start$1261$(_provision_0, _events_0, _capacity_0, _value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["app"];
  const _world_0 = _t_0["world"];
  const _owners_0 = _t_0["owners"];
  const _recipe_0 = _t_0["recipe"];
  const _debug_0 = _t_0["debug"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058setup$1263$(_world_0, _provision_0, _events_0, _capacity_0)), "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0};
}

function $beta$047event$045setup$058provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1263$(($beta$047event$045setup$058pair_provision$()), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1265$("Source.UnusedEvent")))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058attached$1261$(_schema_0, _app_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0};
}

function $beta$047base$045application$058schema$() {
  return $beta$047base$045application$058extracted$(($beta$047state$058provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $alpha$047consumer$058post_enabled$(_factory_0, _before_0, _completion_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $alpha$047consumer$058post_repeated$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), _completion_0, ($alpha$047consumer$058checkpoint$(_app_0, true)));
}

function $alpha$047application$058completed$(_family_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished") {
    const _scheduled_0 = _result_0["app"];
    const _observations_0 = _result_0["observations"];
    return {$: "Tuple", "fst": {$: "alpha/application.Application", "scheduled": _scheduled_0, "family": _family_0, "tick": _tick_0}, "snd": {$: "alpha/application.Finished", "observations": _observations_0}};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed") {
    const _scheduled_1 = _result_0["app"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "Tuple", "fst": {$: "alpha/application.Application", "scheduled": _scheduled_1, "family": _family_0, "tick": _tick_0}, "snd": {$: "alpha/application.Failed", "error": _error_0, "observations": _observations_1}};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Missing") {
    const _scheduled_2 = _result_0["app"];
    const _requirements_0 = _result_0["requirements"];
    return {$: "Tuple", "fst": {$: "alpha/application.Application", "scheduled": _scheduled_2, "family": _family_0, "tick": _tick_0}, "snd": {$: "alpha/application.Missing", "requirements": _requirements_0}};
  } else {
    const _scheduled_3 = _result_0["app"];
    return {$: "Tuple", "fst": {$: "alpha/application.Application", "scheduled": _scheduled_3, "family": _family_0, "tick": _tick_0}, "snd": {$: "alpha/application.Rejected"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058run$1260$(_app_0) {
  const _scheduled_0 = _app_0["scheduled"];
  const _program_0 = _app_0["program"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058executed$1260$(_program_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058run$1261$(_scheduled_0)));
}

function $alpha$047physical$058runtime_join$(_tick_0, _world_0, _family_0) {
  const _world_1 = _world_0["fst"];
  const _a_0 = _world_0["snd"];
  const _family_1 = _family_0["fst"];
  const _b_0 = _family_0["snd"];
  const _x_0 = ($Nat$show$(_tick_0));
  const _x_1 = (";tick=" + _x_0);
  const _x_2 = (_b_0 + _x_1);
  const _x_3 = (";" + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_1, "family": _family_1, "tick": _tick_0}, "snd": (_a_0 + _x_3)};
}

function $alpha$047physical$058world$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["nextId"];
  const _high_0 = _value_0["highWater"];
  const _live_0 = _value_0["live"];
  const _cap_0 = _value_0["capacity"];
  const _depth_0 = _value_0["depth"];
  const _store_0 = _value_0["store"];
  const _resource_0 = _value_0["resource"];
  const _events_0 = _value_0["events"];
  const _pending_0 = _value_0["pending"];
  const _regs_0 = _value_0["registrations"];
  const _sys_0 = _value_0["nextSystemId"];
  const _clock_0 = _value_0["clock"];
  return $alpha$047physical$058world_join$(_ns_0, _id_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _sys_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_live_0)), ($alpha$047physical$058observe_store$(_store_0)), ($alpha$047physical$058resources$(_resource_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1260$(_pending_0)));
}

function $alpha$047physical$058family$(_value_0) {
  const _family_0 = _value_0["family"];
  const _owners_0 = _value_0["owners"];
  const _journal_0 = _value_0["journal"];
  const _start_0 = _value_0["frameStart"];
  return $alpha$047physical$058family_join$(_journal_0, _start_0, ($alpha$047physical$058metadata$(_family_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1262$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1262$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $alpha$047bindings$058fold3$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1261$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1261$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058described$1260$(_program_0, _description_0) {
  const _original_0 = _description_0["original"];
  const _items_0 = _description_0["placements"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Description", "schedule": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Description", "original": _original_0, "placements": _items_0}, "conditions": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058placements$1260$(_items_0, _program_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058returned$1260$(_result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _app_0, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": _app_0, "snd": {$: "Some", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058described$1260$(_view_0))}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058snapshot$1260$(_value_0) {
  const _app_0 = _value_0["app"];
  const _plan_0 = _value_0["plan"];
  const _namespace_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _needs_0 = _value_0["needs"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058observed$1260$(_plan_0, _namespace_0, _name_0, _steps_0, _needs_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058enabled$1260$(_value_0, _flag_0) {
  const _schema_0 = _value_0["schema"];
  const _app_0 = _value_0["app"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1260$(_app_0, _flag_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attached$1260$(_program_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Attached") {
    const _scheduled_0 = _result_0["app"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Attached", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}};
  } else {
    const _app_0 = _result_0["app"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid", "app": _app_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058attach$1260$(_app_0, _name_0, _plan_0) {
  const _schema_0 = _app_0["schema"];
  const _t_0 = _app_0["app"];
  const _world_0 = _t_0["world"];
  const _owners_0 = _t_0["owners"];
  const _recipe_0 = _t_0["recipe"];
  const _debug_0 = _t_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058cataloged$1260$(_schema_0, _owners_0, _recipe_0, _debug_0, _plan_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058catalog$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058plan$1260$(_entries_0) {
  const _plan_0 = _entries_0["plan"];
  return _plan_0;
}

function $Nat$is_eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(cmp_new(_a_0, _b_0));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1260$(_plan_0, _width_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return true;
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _t_0 = _plan_0["step"];
    if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.System") {
      const _slot_0 = _t_0["condition"];
      return (_slot_0 < _width_0);
    } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
      return true;
    } else {
      return true;
    }
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1260$(_left_0, _width_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1260$(_right_0, _width_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built_pair$1260$(_first_0, _second_0, _offset_0, _ids_0) {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Sequence", "left": _first_0(_ids_0), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1260$(_second_0(_ids_0), (_offset_0 >>> 0)))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluated_pair$1260$(_left_0, _right_0, _offset_0, _world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058selected$1260$((_slot_0 < _offset_0), _left_0, _right_0, _world_0, _slot_0, _offset_0);
}

function $alpha$047application$058component_id$(_ids_0) {
  const _component_0 = _ids_0["component"];
  return _component_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1260$(_leaf_0) {
  const _name_0 = _leaf_0["name"];
  return _name_0;
}

function $alpha$047application$058always$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $alpha$047application$058resource_id$(_ids_0) {
  const _resource_0 = _ids_0["resource"];
  return _resource_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1261$(_leaf_0) {
  const _name_0 = _leaf_0["name"];
  return _name_0;
}

function $alpha$047application$058never$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": false};
}

function $alpha$047application$058service_id$(_ids_0) {
  const _service_0 = _ids_0["service"];
  return _service_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1263$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1264$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1261$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1261$(_family_0, _tick_0, _records_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1264$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1264$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1264$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1261$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component_registry$1260$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058read$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-query-observable.Declaration", "operational": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058read$1260$()), "inspection": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045selections$058inspect_slot$1260$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058extracted$1260$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1260$(_world_0, _owners_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058field_owner$1260$(_slot_0, _owner_0) {
  const _registry_0 = _owner_0["registry"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1260$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1260$(($alpha$047operations$058resource_declaration$()))))), _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058registered$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Defined", "world": _world_1, "owner": {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Owner", "registry": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(_value_0) {
  const _clauses_0 = _value_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1260$(_declaration_0) {
  const _ordinary_0 = _declaration_0["ordinary"];
  return _ordinary_0;
}

function $alpha$047operations$058resource_declaration$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058read$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058setup$1261$(_world_0, _provision_0, _owners_0, _capacity_0) {
  const _domains_0 = _provision_0["domains"];
  return {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": ($alpha$047event$045setup$058make$())(_domains_0)(_capacity_0), "owners": _owners_0, "journal": {$: "Nil"}, "frameStart": 0}, "tick": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1261$(_first_0, _second_0) {
  const _first_1 = _first_0["domains"];
  const _second_1 = _second_0["domains"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Domains", "first": _first_1, "second": _second_1}};
}

function $alpha$047event$045setup$058pair_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$("Signal")))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1261$("Signal")))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1262$(_domain_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1262$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $alpha$047base$045application$058extracted$(_value_0) {
  const _t_0 = _value_0["ordinary"];
  const _schema_0 = _t_0["schema"];
  return _schema_0;
}

function $alpha$047state$058provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058with_resource_constructed$1260$(($alpha$047state$058resource_extension$()), ($alpha$047state$058component_provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $beta$047consumer$058post_enabled$(_factory_0, _before_0, _completion_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $beta$047consumer$058post_repeated$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), _completion_0, ($beta$047consumer$058checkpoint$(_app_0, true)));
}

function $beta$047application$058completed$(_family_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished") {
    const _scheduled_0 = _result_0["app"];
    const _observations_0 = _result_0["observations"];
    return {$: "Tuple", "fst": {$: "beta/application.Application", "scheduled": _scheduled_0, "family": _family_0, "tick": _tick_0}, "snd": {$: "beta/application.Finished", "observations": _observations_0}};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed") {
    const _scheduled_1 = _result_0["app"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "Tuple", "fst": {$: "beta/application.Application", "scheduled": _scheduled_1, "family": _family_0, "tick": _tick_0}, "snd": {$: "beta/application.Failed", "error": _error_0, "observations": _observations_1}};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Missing") {
    const _scheduled_2 = _result_0["app"];
    const _requirements_0 = _result_0["requirements"];
    return {$: "Tuple", "fst": {$: "beta/application.Application", "scheduled": _scheduled_2, "family": _family_0, "tick": _tick_0}, "snd": {$: "beta/application.Missing", "requirements": _requirements_0}};
  } else {
    const _scheduled_3 = _result_0["app"];
    return {$: "Tuple", "fst": {$: "beta/application.Application", "scheduled": _scheduled_3, "family": _family_0, "tick": _tick_0}, "snd": {$: "beta/application.Rejected"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058run$1261$(_app_0) {
  const _scheduled_0 = _app_0["scheduled"];
  const _program_0 = _app_0["program"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058executed$1261$(_program_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058run$1263$(_scheduled_0)));
}

function $beta$047physical$058runtime_join$(_tick_0, _world_0, _family_0) {
  const _world_1 = _world_0["fst"];
  const _a_0 = _world_0["snd"];
  const _family_1 = _family_0["fst"];
  const _b_0 = _family_0["snd"];
  const _x_0 = ($Nat$show$(_tick_0));
  const _x_1 = (";tick=" + _x_0);
  const _x_2 = (_b_0 + _x_1);
  const _x_3 = (";" + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_1, "family": _family_1, "tick": _tick_0}, "snd": (_a_0 + _x_3)};
}

function $beta$047physical$058world$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["nextId"];
  const _high_0 = _value_0["highWater"];
  const _live_0 = _value_0["live"];
  const _cap_0 = _value_0["capacity"];
  const _depth_0 = _value_0["depth"];
  const _store_0 = _value_0["store"];
  const _resource_0 = _value_0["resource"];
  const _events_0 = _value_0["events"];
  const _pending_0 = _value_0["pending"];
  const _regs_0 = _value_0["registrations"];
  const _sys_0 = _value_0["nextSystemId"];
  const _clock_0 = _value_0["clock"];
  return $beta$047physical$058world_join$(_ns_0, _id_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _sys_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_live_0)), ($beta$047physical$058observe_store$(_store_0)), ($beta$047physical$058resources$(_resource_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1261$(_pending_0)));
}

function $beta$047physical$058family$(_value_0) {
  const _family_0 = _value_0["family"];
  const _owners_0 = _value_0["owners"];
  const _journal_0 = _value_0["journal"];
  const _start_0 = _value_0["frameStart"];
  return $beta$047physical$058family_join$(_journal_0, _start_0, ($beta$047physical$058metadata$(_family_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1265$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1265$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $beta$047bindings$058fold3$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1264$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1263$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058described$1261$(_program_0, _description_0) {
  const _original_0 = _description_0["original"];
  const _items_0 = _description_0["placements"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Description", "schedule": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Description", "original": _original_0, "placements": _items_0}, "conditions": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058placements$1261$(_items_0, _program_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058returned$1261$(_result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _app_0, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": _app_0, "snd": {$: "Some", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058described$1261$(_view_0))}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058snapshot$1261$(_value_0) {
  const _app_0 = _value_0["app"];
  const _plan_0 = _value_0["plan"];
  const _namespace_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _needs_0 = _value_0["needs"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058observed$1261$(_plan_0, _namespace_0, _name_0, _steps_0, _needs_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058snapshot$1261$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058enabled$1261$(_value_0, _flag_0) {
  const _schema_0 = _value_0["schema"];
  const _app_0 = _value_0["app"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1261$(_app_0, _flag_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058attached$1261$(_program_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Attached") {
    const _scheduled_0 = _result_0["app"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Attached", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}};
  } else {
    const _app_0 = _result_0["app"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid", "app": _app_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058attach$1261$(_app_0, _name_0, _plan_0) {
  const _schema_0 = _app_0["schema"];
  const _t_0 = _app_0["app"];
  const _world_0 = _t_0["world"];
  const _owners_0 = _t_0["owners"];
  const _recipe_0 = _t_0["recipe"];
  const _debug_0 = _t_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058cataloged$1261$(_schema_0, _owners_0, _recipe_0, _debug_0, _plan_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058catalog$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058plan$1261$(_entries_0) {
  const _plan_0 = _entries_0["plan"];
  return _plan_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1261$(_plan_0, _width_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return true;
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _t_0 = _plan_0["step"];
    if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.System") {
      const _slot_0 = _t_0["condition"];
      return (_slot_0 < _width_0);
    } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
      return true;
    } else {
      return true;
    }
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1261$(_left_0, _width_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058slots$1261$(_right_0, _width_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058built_pair$1261$(_first_0, _second_0, _offset_0, _ids_0) {
  return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Sequence", "left": _first_0(_ids_0), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1261$(_second_0(_ids_0), (_offset_0 >>> 0)))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluated_pair$1261$(_left_0, _right_0, _offset_0, _world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058selected$1261$((_slot_0 < _offset_0), _left_0, _right_0, _world_0, _slot_0, _offset_0);
}

function $beta$047application$058component_id$(_ids_0) {
  const _component_0 = _ids_0["component"];
  return _component_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1262$(_leaf_0) {
  const _name_0 = _leaf_0["name"];
  return _name_0;
}

function $beta$047application$058always$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $beta$047application$058resource_id$(_ids_0) {
  const _resource_0 = _ids_0["resource"];
  return _resource_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058leaf_name$1263$(_leaf_0) {
  const _name_0 = _leaf_0["name"];
  return _name_0;
}

function $beta$047application$058never$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": false};
}

function $beta$047application$058service_id$(_ids_0) {
  const _service_0 = _ids_0["service"];
  return _service_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1267$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1269$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1263$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1263$(_family_0, _tick_0, _records_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1268$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1268$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1269$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1265$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1264$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058component_registry$1261$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058read$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-query-observable.Declaration", "operational": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058read$1261$()), "inspection": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045selections$058inspect_slot$1261$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1264$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058extracted$1261$(_done_0, _failed_0, _world_0, _owners_0, _debug_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return run_tail(_done_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1263$(_world_0, _owners_0, {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, _debug_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$058field_owner$1261$(_slot_0, _owner_0) {
  const _registry_0 = _owner_0["registry"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1261$(_slot_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1261$(($beta$047operations$058resource_declaration$()))))), _registry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058registered$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Rejected", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Defined", "world": _world_1, "owner": {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Owner", "registry": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058access$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(_value_0) {
  const _clauses_0 = _value_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1261$(_declaration_0) {
  const _ordinary_0 = _declaration_0["ordinary"];
  return _ordinary_0;
}

function $beta$047operations$058resource_declaration$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058read$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058setup$1263$(_world_0, _provision_0, _owners_0, _capacity_0) {
  const _domains_0 = _provision_0["domains"];
  return {$: "../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": ($beta$047event$045setup$058make$())(_domains_0)(_capacity_0), "owners": _owners_0, "journal": {$: "Nil"}, "frameStart": 0}, "tick": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1263$(_first_0, _second_0) {
  const _first_1 = _first_0["domains"];
  const _second_1 = _second_0["domains"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Domains", "first": _first_1, "second": _second_1}};
}

function $beta$047event$045setup$058pair_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1263$("Signal")))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1264$("Signal")))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1265$(_domain_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1265$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $beta$047base$045application$058extracted$(_value_0) {
  const _t_0 = _value_0["ordinary"];
  const _schema_0 = _t_0["schema"];
  return _schema_0;
}

function $beta$047state$058provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058with_resource_constructed$1261$(($beta$047state$058resource_extension$()), ($beta$047state$058component_provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $alpha$047consumer$058post_repeated$(_factory_0, _before_0, _completion_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $alpha$047consumer$058final$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), _completion_0, ($alpha$047consumer$058checkpoint$(_app_0, false)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058executed$1260$(_program_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished") {
    const _scheduled_0 = _result_0["app"];
    const _observations_0 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}, "observations": _observations_0};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed") {
    const _scheduled_1 = _result_0["app"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_1, "program": _program_0}, "error": _error_0, "observations": _observations_1};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Rejected") {
    const _scheduled_2 = _result_0["app"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Rejected", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_2, "program": _program_0}};
  } else {
    const _scheduled_3 = _result_0["app"];
    const _requirements_0 = _result_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Missing", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_3, "program": _program_0}, "requirements": _requirements_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058run$1261$(_value_0) {
  const _t_0 = _value_0["app"];
  const _schema_0 = _t_0["schema"];
  const _t_1 = _t_0["app"];
  const _world_0 = _t_1["world"];
  const _owners_0 = _t_1["owners"];
  const _recipe_0 = _t_1["recipe"];
  const _debug_0 = _t_1["debug"];
  const _plan_0 = _value_0["plan"];
  const _namespace_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _needs_0 = _value_0["needs"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058provisioned$1260$(_schema_0, _recipe_0, _debug_0, _plan_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run$1261$({$: "../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, "requirements": _needs_0}, _world_0)));
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $alpha$047physical$058world_join$(_ns_0, _id_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _sys_0, _clock_0, _live_0, _store_0, _resources_0, _pending_0) {
  const _live_1 = _live_0["fst"];
  const _a_0 = _live_0["snd"];
  const _store_1 = _store_0["fst"];
  const _b_0 = _store_0["snd"];
  const _resource_0 = _resources_0["fst"];
  const _c_0 = _resources_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _n_0 = _pending_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_sys_0));
  const _x_3 = (";clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$12615$(_regs_0));
  const _x_6 = (";nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_n_0));
  const _x_9 = (";registrations=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$12614$(_events_0));
  const _x_12 = (";pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (";events=" + _x_13);
  const _x_15 = (_c_0 + _x_14);
  const _x_16 = (";" + _x_15);
  const _x_17 = (_b_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = (";" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_cap_0));
  const _x_22 = (";depth=" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = (";capacity=" + _x_23);
  const _x_25 = (_a_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";live=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_id_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _id_0, "highWater": _high_0, "live": _live_1, "capacity": _cap_0, "depth": _depth_0, "store": _store_1, "resource": _resource_0, "events": _events_0, "pending": _pending_1, "registrations": _regs_0, "nextSystemId": _sys_0, "clock": _clock_0}, "snd": ("world{" + _x_34)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_value_0);
}

function $alpha$047physical$058observe_store$(_value_0) {
  const _a_0 = _value_0["first"];
  const _b_0 = _value_0["second"];
  const _c_0 = _value_0["sibling"];
  return $alpha$047physical$058stores_join$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058column$1260$(_a_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058column$1260$(_b_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_c_0)));
}

function $alpha$047physical$058resources$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _mode_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return $alpha$047physical$058resources_join$(_mode_0, _barriers_0, ($alpha$047physical$058service$(_clock_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_inventory_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_sibling_0)));
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks_join$1260$(_head_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1260$(_rest_0)));
  }
}

function $alpha$047physical$058family_join$(_journal_0, _start_0, _metadata_0, _owners_0) {
  const _family_0 = _metadata_0["fst"];
  const _m_0 = _metadata_0["snd"];
  const _owners_1 = _owners_0["fst"];
  const _o_0 = _owners_0["snd"];
  const _x_0 = ($Nat$show$(_start_0));
  const _x_1 = ($List$show$12613$(_journal_0));
  const _x_2 = (";frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (";journal=" + _x_3);
  const _x_5 = (_o_0 + _x_4);
  const _x_6 = (";eventOwners=" + _x_5);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_1, "journal": _journal_0, "frameStart": _start_0}, "snd": (_m_0 + _x_6)};
}

function $alpha$047physical$058metadata$(_value_0) {
  const _t_0 = _value_0["left"];
  const _a_0 = _t_0["left"];
  const _b_0 = _t_0["right"];
  const _c_0 = _value_0["right"];
  const _x_0 = ($alpha$047physical$058stream$1262$(_c_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($alpha$047physical$058stream$1261$(_b_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($alpha$047physical$058stream$1260$(_a_0));
  const _x_6 = (";" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _a_0, "right": _b_0}, "right": _c_0}, "snd": ("family{" + _x_7)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1262$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1262$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1261$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1261$(($alpha$047bindings$058fold2$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1260$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058placements$1260$(_items_0, _program_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _first_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058added$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058condition_placement$1260$(_program_0, _first_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058placements$1260$(_rest_0, _program_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058described$1260$(_description_0) {
  const _t_0 = _description_0["application"];
  const __0 = _t_0["schema"];
  const _t_1 = _t_0["registered"];
  const _bindings_0 = _t_1["left"];
  const __1 = _t_1["right"];
  const _namespace_0 = _description_0["namespace"];
  const __2 = _description_0["name"];
  const _steps_0 = _description_0["steps"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Description", "original": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Description", "application": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Description", "schema": __0, "registered": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _bindings_0, "right": __1}}, "namespace": _namespace_0, "name": __2, "steps": _steps_0}, "placements": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058placed$1260$(_steps_0, _namespace_0, _bindings_0, 0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058observed$1260$(_plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": _app_0, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": _app_0, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "snd": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Description", "application": _view_0, "namespace": _namespace_0, "name": _name_0, "steps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1260$(_plan_0))}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058snapshot$1260$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _app_0 = _value_0["app"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058observed$1260$(_schema_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1260$(_app_0, _flag_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _flag_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058cataloged$1260$(_schema_0, _owners_0, _recipe_0, _debug_0, _plan_0, _name_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _namespace_0 = _t_0["fst"];
  const _known_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058built$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _plan_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, _known_0, _owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058catalog$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "Tuple", "fst": _namespace_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058ids$(_registrations_0))}};
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1260$(_plan_0, _offset_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Empty"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _t_0 = _plan_0["step"];
    if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.System") {
      const _id_0 = _t_0["id"];
      const _slot_0 = _t_0["condition"];
      const _requirements_0 = _plan_0["requirements"];
      return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": _id_0, "condition": ((_slot_0 + _offset_0) >>> 0)}, "requirements": _requirements_0};
    } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
      const _name_0 = _t_0["name"];
      const _requirements_1 = _plan_0["requirements"];
      return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": _name_0}, "requirements": _requirements_1};
    } else {
      const _requirements_2 = _plan_0["requirements"];
      return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Barrier"}, "requirements": _requirements_2};
    }
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Sequence", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1260$(_left_0, _offset_0)), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1260$(_right_0, _offset_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058selected$1260$(_chosen_0, _left_0, _right_0, _world_0, _slot_0, _offset_0) {
  if (_chosen_0) {
    return run_tail(_left_0(_world_0), _slot_0);
  } else {
    const _x_0 = (_offset_0 >>> 0);
    return run_tail(_right_0(_world_0), ((_slot_0 - _x_0) >>> 0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1261$(_family_0, _tick_0, _records_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($alpha$047event$045setup$058sync_pair$())(_first_0)(_tick_0)(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1261$(_records_0))), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1262$(_second_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1261$(_records_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1264$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058read$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Declaration", "grant": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_family$1260$()), "select": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1260$(_x_0);
}), "clauses": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(($alpha$047state$058first_binding$()))))), "mode": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045selections$058inspect_slot$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_slot$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1260$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1260$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058read$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-resource-field-declaration.Declaration", "ordinary": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read$1260$()), "observe": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_x_0);
}), "render": run_clo((_x_1) => {
  return $U32$show$(_x_1);
})};
}

function $alpha$047event$045setup$058make$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1261$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1260$(_first_0, _second_0) {
  const _first_1 = _first_0["domains"];
  const _second_1 = _second_0["domains"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Domains", "first": _first_1, "second": _second_1}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1260$(_domain_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1261$(_domain_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1261$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058with_resource_constructed$1260$(_extension_0, _base_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058resource_schema$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_constructed$1260$(_extension_0)), _base_0);
}

function $alpha$047state$058resource_extension$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058constructed$1260$({$: "../../../../../../bendvy/src/ecs/decode-data.Integer"});
}

function $alpha$047state$058component_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058append$1260$(($alpha$047state$058first_provision$()), ($alpha$047state$058second_provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $beta$047consumer$058post_repeated$(_factory_0, _before_0, _completion_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $beta$047consumer$058final$(_factory_0, ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), _completion_0, ($beta$047consumer$058checkpoint$(_app_0, false)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058executed$1261$(_program_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished") {
    const _scheduled_0 = _result_0["app"];
    const _observations_0 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_0, "program": _program_0}, "observations": _observations_0};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed") {
    const _scheduled_1 = _result_0["app"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_1, "program": _program_0}, "error": _error_0, "observations": _observations_1};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Rejected") {
    const _scheduled_2 = _result_0["app"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Rejected", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_2, "program": _program_0}};
  } else {
    const _scheduled_3 = _result_0["app"];
    const _requirements_0 = _result_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Missing", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Application", "scheduled": _scheduled_3, "program": _program_0}, "requirements": _requirements_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058run$1263$(_value_0) {
  const _t_0 = _value_0["app"];
  const _schema_0 = _t_0["schema"];
  const _t_1 = _t_0["app"];
  const _world_0 = _t_1["world"];
  const _owners_0 = _t_1["owners"];
  const _recipe_0 = _t_1["recipe"];
  const _debug_0 = _t_1["debug"];
  const _plan_0 = _value_0["plan"];
  const _namespace_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _needs_0 = _value_0["needs"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058provisioned$1261$(_schema_0, _recipe_0, _debug_0, _plan_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run$1263$({$: "../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, "requirements": _needs_0}, _world_0)));
}

function $beta$047physical$058world_join$(_ns_0, _id_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _sys_0, _clock_0, _live_0, _store_0, _resources_0, _pending_0) {
  const _live_1 = _live_0["fst"];
  const _a_0 = _live_0["snd"];
  const _store_1 = _store_0["fst"];
  const _b_0 = _store_0["snd"];
  const _resource_0 = _resources_0["fst"];
  const _c_0 = _resources_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _n_0 = _pending_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_sys_0));
  const _x_3 = (";clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$12615$(_regs_0));
  const _x_6 = (";nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_n_0));
  const _x_9 = (";registrations=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$12627$(_events_0));
  const _x_12 = (";pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (";events=" + _x_13);
  const _x_15 = (_c_0 + _x_14);
  const _x_16 = (";" + _x_15);
  const _x_17 = (_b_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = (";" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_cap_0));
  const _x_22 = (";depth=" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = (";capacity=" + _x_23);
  const _x_25 = (_a_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";live=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_id_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _id_0, "highWater": _high_0, "live": _live_1, "capacity": _cap_0, "depth": _depth_0, "store": _store_1, "resource": _resource_0, "events": _events_0, "pending": _pending_1, "registrations": _regs_0, "nextSystemId": _sys_0, "clock": _clock_0}, "snd": ("world{" + _x_34)};
}

function $beta$047physical$058observe_store$(_value_0) {
  const _a_0 = _value_0["first"];
  const _b_0 = _value_0["second"];
  const _c_0 = _value_0["sibling"];
  return $beta$047physical$058stores_join$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058column$1261$(_a_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058column$1261$(_b_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_c_0)));
}

function $beta$047physical$058resources$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _mode_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return $beta$047physical$058resources_join$(_mode_0, _barriers_0, ($beta$047physical$058service$(_clock_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_inventory_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_sibling_0)));
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks_join$1261$(_head_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1261$(_rest_0)));
  }
}

function $beta$047physical$058family_join$(_journal_0, _start_0, _metadata_0, _owners_0) {
  const _family_0 = _metadata_0["fst"];
  const _m_0 = _metadata_0["snd"];
  const _owners_1 = _owners_0["fst"];
  const _o_0 = _owners_0["snd"];
  const _x_0 = ($Nat$show$(_start_0));
  const _x_1 = ($List$show$12626$(_journal_0));
  const _x_2 = (";frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (";journal=" + _x_3);
  const _x_5 = (_o_0 + _x_4);
  const _x_6 = (";eventOwners=" + _x_5);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_1, "journal": _journal_0, "frameStart": _start_0}, "snd": (_m_0 + _x_6)};
}

function $beta$047physical$058metadata$(_value_0) {
  const _t_0 = _value_0["left"];
  const _a_0 = _t_0["left"];
  const _b_0 = _t_0["right"];
  const _c_0 = _value_0["right"];
  const _x_0 = ($beta$047physical$058stream$1262$(_c_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($beta$047physical$058stream$1261$(_b_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($beta$047physical$058stream$1260$(_a_0));
  const _x_6 = (";" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _a_0, "right": _b_0}, "right": _c_0}, "snd": ("family{" + _x_7)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1265$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1265$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1264$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1264$(($beta$047bindings$058fold2$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1262$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058placements$1261$(_items_0, _program_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _first_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058added$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058condition_placement$1261$(_program_0, _first_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058placements$1261$(_rest_0, _program_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058described$1261$(_description_0) {
  const _t_0 = _description_0["application"];
  const __0 = _t_0["schema"];
  const _t_1 = _t_0["registered"];
  const _bindings_0 = _t_1["left"];
  const __1 = _t_1["right"];
  const _namespace_0 = _description_0["namespace"];
  const __2 = _description_0["name"];
  const _steps_0 = _description_0["steps"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Description", "original": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Description", "application": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Description", "schema": __0, "registered": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _bindings_0, "right": __1}}, "namespace": _namespace_0, "name": __2, "steps": _steps_0}, "placements": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058placed$1261$(_steps_0, _namespace_0, _bindings_0, 0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058observed$1261$(_plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": _app_0, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": _app_0, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "snd": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Description", "application": _view_0, "namespace": _namespace_0, "name": _name_0, "steps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1261$(_plan_0))}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058snapshot$1261$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _app_0 = _value_0["app"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058observed$1261$(_schema_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1261$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058enabled$1261$(_app_0, _flag_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _flag_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058cataloged$1261$(_schema_0, _owners_0, _recipe_0, _debug_0, _plan_0, _name_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _namespace_0 = _t_0["fst"];
  const _known_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058built$1261$(_schema_0, _world_0, _recipe_0, _debug_0, _plan_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1261$(_namespace_0, _name_0, _plan_0, _known_0, _owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058catalog$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "Tuple", "fst": _namespace_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058ids$(_registrations_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1261$(_plan_0, _offset_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Empty"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _t_0 = _plan_0["step"];
    if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.System") {
      const _id_0 = _t_0["id"];
      const _slot_0 = _t_0["condition"];
      const _requirements_0 = _plan_0["requirements"];
      return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": _id_0, "condition": ((_slot_0 + _offset_0) >>> 0)}, "requirements": _requirements_0};
    } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
      const _name_0 = _t_0["name"];
      const _requirements_1 = _plan_0["requirements"];
      return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": _name_0}, "requirements": _requirements_1};
    } else {
      const _requirements_2 = _plan_0["requirements"];
      return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../bendvy/src/ecs/schedule.Barrier"}, "requirements": _requirements_2};
    }
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Sequence", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1261$(_left_0, _offset_0)), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058shifted$1261$(_right_0, _offset_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058selected$1261$(_chosen_0, _left_0, _right_0, _world_0, _slot_0, _offset_0) {
  if (_chosen_0) {
    return run_tail(_left_0(_world_0), _slot_0);
  } else {
    const _x_0 = (_offset_0 >>> 0);
    return run_tail(_right_0(_world_0), ((_slot_0 - _x_0) >>> 0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1263$(_family_0, _tick_0, _records_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($beta$047event$045setup$058sync_pair$())(_first_0)(_tick_0)(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1263$(_records_0))), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1265$(_second_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1263$(_records_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1268$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058read$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Declaration", "grant": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_family$1261$()), "select": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1261$(_x_0);
}), "clauses": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1262$(($beta$047state$058first_binding$()))))), "mode": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045selections$058inspect_slot$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_slot$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1264$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1264$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058appended$1263$(_world_0, _owners_0, _leaf_0, _debug_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _leaf_0}, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045fields$058field_registry$1261$(_slot_0, _clauses_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058read$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-resource-field-declaration.Declaration", "ordinary": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read$1261$()), "observe": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_x_0);
}), "render": run_clo((_x_1) => {
  return $U32$show$(_x_1);
})};
}

function $beta$047event$045setup$058make$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1263$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1262$(_first_0, _second_0) {
  const _first_1 = _first_0["domains"];
  const _second_1 = _second_0["domains"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Domains", "first": _first_1, "second": _second_1}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1263$(_domain_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1263$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1264$(_domain_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1264$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058with_resource_constructed$1261$(_extension_0, _base_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058resource_schema$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_constructed$1261$(_extension_0)), _base_0);
}

function $beta$047state$058resource_extension$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058constructed$1261$({$: "../../../../../../bendvy/src/ecs/decode-data.Integer"});
}

function $beta$047state$058component_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058append$1261$(($beta$047state$058first_provision$()), ($beta$047state$058second_provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $alpha$047consumer$058final$(_factory_0, _before_0, _completion_0, _result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "alpha/consumer.Report", "factory": _factory_0, "checkpoints": ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), "completion": _completion_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058provisioned$1260$(_schema_0, _recipe_0, _debug_0, _plan_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Missing") {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["schedule"];
    const _namespace_0 = _t_1["namespace"];
    const _name_0 = _t_1["name"];
    const _steps_0 = _t_1["steps"];
    const _owners_0 = _t_1["owners"];
    const _needs_0 = _t_0["requirements"];
    const _world_0 = _result_0["world"];
    const _missing_0 = _result_0["missing"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Missing", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "requirements": _missing_0};
  } else {
    const _result_1 = _result_0["result"];
    const _needs_1 = _result_0["requirements"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058executed$1260$(_schema_0, _recipe_0, _debug_0, _plan_0, _needs_1, _result_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run$1261$(_schedule_0, _world_0) {
  const _schedule_1 = _schedule_0["schedule"];
  const _needs_0 = _schedule_0["requirements"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_available$1261$(($alpha$047dispatch$058provision$(_world_0)), _schedule_1, _needs_0);
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058publication$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058registration$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1261$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_value$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1261$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_right_0)));
  }
}

function $alpha$047physical$058stores_join$(_a_0, _b_0, _c_0) {
  const _a_1 = _a_0["fst"];
  const _x_0 = _a_0["snd"];
  const _b_1 = _b_0["fst"];
  const _y_0 = _b_0["snd"];
  const _c_1 = _c_0["fst"];
  const _z_0 = _c_0["snd"];
  const _x_1 = (_z_0 + "}");
  const _x_2 = (";sibling=" + _x_1);
  const _x_3 = (_y_0 + _x_2);
  const _x_4 = (";" + _x_3);
  const _x_5 = (_x_0 + _x_4);
  return {$: "Tuple", "fst": {$: "alpha/state.Store", "first": _a_1, "second": _b_1, "sibling": _c_1}, "snd": ("store{" + _x_5)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058column$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _value_0["values"];
    const _stamps_0 = _value_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058plain_column$1260$(_stamps_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_values_0)));
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _state_0 = _value_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_column$1260$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed$1260$(_state_0)));
  } else {
    return {$: "Tuple", "fst": _value_0, "snd": "UNSUPPORTED_PREPARED_COLUMN"};
  }
}

function $alpha$047physical$058resources_join$(_mode_0, _barriers_0, _clock_0, _inventory_0, _sibling_0) {
  const _clock_1 = _clock_0["fst"];
  const _a_0 = _clock_0["snd"];
  const _inventory_1 = _inventory_0["fst"];
  const _b_0 = _inventory_0["snd"];
  const _sibling_1 = _sibling_0["fst"];
  const _c_0 = _sibling_0["snd"];
  const _x_0 = ($U32$show$(_barriers_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (";barriers=" + _x_1);
  const _x_3 = (_c_0 + _x_2);
  const _x_4 = (";sibling=" + _x_3);
  const _x_5 = (_b_0 + _x_4);
  const _x_6 = ($alpha$047physical$058machine$(_mode_0));
  const _x_7 = (";inventory=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = (";machine=" + _x_8);
  const _x_10 = (_a_0 + _x_9);
  return {$: "Tuple", "fst": {$: "alpha/state.Resources", "clock": _clock_1, "machine": _mode_0, "inventory": _inventory_1, "sibling": _sibling_1, "barriers": _barriers_0}, "snd": ("resources{" + _x_10)};
}

function $alpha$047physical$058service$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"}, "snd": "Missing"};
  } else {
    const _owner_0 = _value_0["owner"];
    return $alpha$047physical$058slot_ready$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks_join$1260$(_head_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $List$show$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1263$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $alpha$047physical$058stream$1260$(_value_0) {
  const _t_0 = _value_0["domain"];
  const _key_0 = _t_0["key"];
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _nextReader_0 = _value_0["nextReader"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = ($Nat$show$(_capacity_0));
  const _x_2 = (";dropped=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_boundary_0));
  const _x_5 = (";capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_frameStart_0));
  const _x_8 = (";boundary=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_nextReader_0));
  const _x_11 = (";frameStart=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$12610$(_positions_0));
  const _x_14 = (";nextReader=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$1269$(_batches_0));
  const _x_17 = (";positions=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";batches=" + _x_18);
  return (_key_0 + _x_19);
}

function $alpha$047physical$058stream$1261$(_value_0) {
  const _t_0 = _value_0["domain"];
  const _key_0 = _t_0["key"];
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _nextReader_0 = _value_0["nextReader"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = ($Nat$show$(_capacity_0));
  const _x_2 = (";dropped=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_boundary_0));
  const _x_5 = (";capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_frameStart_0));
  const _x_8 = (";boundary=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_nextReader_0));
  const _x_11 = (";frameStart=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$12610$(_positions_0));
  const _x_14 = (";nextReader=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$12611$(_batches_0));
  const _x_17 = (";positions=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";batches=" + _x_18);
  return (_key_0 + _x_19);
}

function $alpha$047physical$058stream$1262$(_value_0) {
  const _t_0 = _value_0["domain"];
  const _key_0 = _t_0["key"];
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _nextReader_0 = _value_0["nextReader"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = ($Nat$show$(_capacity_0));
  const _x_2 = (";dropped=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_boundary_0));
  const _x_5 = (";capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_frameStart_0));
  const _x_8 = (";boundary=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_nextReader_0));
  const _x_11 = (";frameStart=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$12610$(_positions_0));
  const _x_14 = (";nextReader=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$12612$(_batches_0));
  const _x_17 = (";positions=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";batches=" + _x_18);
  return (_key_0 + _x_19);
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1260$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_value$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1260$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1262$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1261$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1261$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $alpha$047bindings$058fold2$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1260$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058added$(_first_0, _rest_0) {
  if (_first_0.$ === "None") {
    return _rest_0;
  } else {
    const _view_0 = _first_0["value"];
    return {$: "Con", "head": _view_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058condition_placement$1260$(_program_0, _placement_0) {
  if (_placement_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.System") {
    const _position_0 = _placement_0["position"];
    const _slot_0 = _placement_0["condition"];
    return {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.ConditionPlacement", "position": _position_0, "slot": _slot_0, "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058condition_name$1260$(_program_0, _slot_0))}};
  } else if (_placement_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Phase") {
    return {$: "None"};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058placed$1260$(_steps_0, _namespace_0, _bindings_0, _position_0) {
  if (_steps_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _first_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058step$1260$(_namespace_0, _bindings_0, _position_0, _first_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058placed$1260$(_rest_0, _namespace_0, _bindings_0, nat_chk(_position_0 + 1)))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    const _needs_0 = _plan_0["requirements"];
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.PlannedStep", "step": _step_0, "requirements": _needs_0}, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058observed$1260$(_schema_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0}, "snd": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Description", "schema": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058entries$1260$(_schema_0)), "registered": _view_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1260$(_world_0, ($alpha$047bindings$058fold4$())(_owners_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058built$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _plan_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}};
  } else {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["schedule"];
    const _namespace_0 = _t_1["namespace"];
    const _name_0 = _t_1["name"];
    const _steps_0 = _t_1["steps"];
    const _owners_1 = _t_1["owners"];
    const _needs_0 = _t_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Attached", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_1, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0)), _catalog_0, _owners_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058ids$(_registrations_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _registrations_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _registrations_0["tail"];
    return {$: "Con", "head": _id_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058ids$(_rest_0))};
  }
}

function $alpha$047event$045setup$058sync_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1260$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1261$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1262$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1262$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1261$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_family$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1260$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1260$({$: "../../../../../../bendvy/src/ecs/compose.Required"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_slot$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matches$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_read$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Read", "operation": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058read$1260$())}, "clauses": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(($alpha$047state$058inventory_identity$()))), "mode": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1261$(_domains_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1261$(_domains_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058resource_schema$1260$(_schema_0, _base_0) {
  const _added_0 = _schema_0["entries"];
  const _t_0 = _base_0["ordinary"];
  const _t_1 = _t_0["schema"];
  const _entries_0 = _t_1["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": ($List$append$(_entries_0, _added_0))}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_constructed$1260$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1261$(($alpha$047state$058resource_identity$())));
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Classified", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Resource"}, "key": _key_0, "name": _key_0, "persistence": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Constructed"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058constructed$1260$(_codec_0) {
  return {$: "../../../../../../bendvy/src/ecs/persistence-declaration.Constructed", "codec": _codec_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058append$1260$(_left_0, _right_0) {
  const _t_0 = _left_0["ordinary"];
  const _t_1 = _t_0["schema"];
  const _left_1 = _t_1["entries"];
  const _t_2 = _right_0["ordinary"];
  const _t_3 = _t_2["schema"];
  const _right_1 = _t_3["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": ($List$append$(_left_1, _right_1))}}};
}

function $alpha$047state$058first_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_plain$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058plain$1260$()));
}

function $alpha$047state$058second_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_transient$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058transient$1260$()));
}

function $beta$047consumer$058final$(_factory_0, _before_0, _completion_0, _result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "beta/consumer.Report", "factory": _factory_0, "checkpoints": ($List$append$(_before_0, {$: "Con", "head": _view_0, "tail": {$: "Nil"}})), "completion": _completion_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058provisioned$1261$(_schema_0, _recipe_0, _debug_0, _plan_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Missing") {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["schedule"];
    const _namespace_0 = _t_1["namespace"];
    const _name_0 = _t_1["name"];
    const _steps_0 = _t_1["steps"];
    const _owners_0 = _t_1["owners"];
    const _needs_0 = _t_0["requirements"];
    const _world_0 = _result_0["world"];
    const _missing_0 = _result_0["missing"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Missing", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "requirements": _missing_0};
  } else {
    const _result_1 = _result_0["result"];
    const _needs_1 = _result_0["requirements"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058executed$1261$(_schema_0, _recipe_0, _debug_0, _plan_0, _needs_1, _result_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run$1263$(_schedule_0, _world_0) {
  const _schedule_1 = _schedule_0["schedule"];
  const _needs_0 = _schedule_0["requirements"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_available$1263$(($beta$047dispatch$058provision$(_world_0)), _schedule_1, _needs_0);
}

function $List$show$12627$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058publication$(_h_0));
    const _x_1 = ($List$show$go$12626$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $beta$047physical$058stores_join$(_a_0, _b_0, _c_0) {
  const _a_1 = _a_0["fst"];
  const _x_0 = _a_0["snd"];
  const _b_1 = _b_0["fst"];
  const _y_0 = _b_0["snd"];
  const _c_1 = _c_0["fst"];
  const _z_0 = _c_0["snd"];
  const _x_1 = (_z_0 + "}");
  const _x_2 = (";sibling=" + _x_1);
  const _x_3 = (_y_0 + _x_2);
  const _x_4 = (";" + _x_3);
  const _x_5 = (_x_0 + _x_4);
  return {$: "Tuple", "fst": {$: "beta/state.Store", "first": _a_1, "second": _b_1, "sibling": _c_1}, "snd": ("store{" + _x_5)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058column$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _value_0["values"];
    const _stamps_0 = _value_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058plain_column$1261$(_stamps_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_values_0)));
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _state_0 = _value_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_column$1261$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed$1261$(_state_0)));
  } else {
    return {$: "Tuple", "fst": _value_0, "snd": "UNSUPPORTED_PREPARED_COLUMN"};
  }
}

function $beta$047physical$058resources_join$(_mode_0, _barriers_0, _clock_0, _inventory_0, _sibling_0) {
  const _clock_1 = _clock_0["fst"];
  const _a_0 = _clock_0["snd"];
  const _inventory_1 = _inventory_0["fst"];
  const _b_0 = _inventory_0["snd"];
  const _sibling_1 = _sibling_0["fst"];
  const _c_0 = _sibling_0["snd"];
  const _x_0 = ($U32$show$(_barriers_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (";barriers=" + _x_1);
  const _x_3 = (_c_0 + _x_2);
  const _x_4 = (";sibling=" + _x_3);
  const _x_5 = (_b_0 + _x_4);
  const _x_6 = ($beta$047physical$058machine$(_mode_0));
  const _x_7 = (";inventory=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = (";machine=" + _x_8);
  const _x_10 = (_a_0 + _x_9);
  return {$: "Tuple", "fst": {$: "beta/state.Resources", "clock": _clock_1, "machine": _mode_0, "inventory": _inventory_1, "sibling": _sibling_1, "barriers": _barriers_0}, "snd": ("resources{" + _x_10)};
}

function $beta$047physical$058service$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"}, "snd": "Missing"};
  } else {
    const _owner_0 = _value_0["owner"];
    return $beta$047physical$058slot_ready$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks_join$1261$(_head_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $List$show$12626$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1263$(_h_0));
    const _x_1 = ($List$show$go$12627$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $beta$047physical$058stream$1260$(_value_0) {
  const _t_0 = _value_0["domain"];
  const _key_0 = _t_0["key"];
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _nextReader_0 = _value_0["nextReader"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = ($Nat$show$(_capacity_0));
  const _x_2 = (";dropped=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_boundary_0));
  const _x_5 = (";capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_frameStart_0));
  const _x_8 = (";boundary=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_nextReader_0));
  const _x_11 = (";frameStart=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$12623$(_positions_0));
  const _x_14 = (";nextReader=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$12622$(_batches_0));
  const _x_17 = (";positions=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";batches=" + _x_18);
  return (_key_0 + _x_19);
}

function $beta$047physical$058stream$1261$(_value_0) {
  const _t_0 = _value_0["domain"];
  const _key_0 = _t_0["key"];
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _nextReader_0 = _value_0["nextReader"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = ($Nat$show$(_capacity_0));
  const _x_2 = (";dropped=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_boundary_0));
  const _x_5 = (";capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_frameStart_0));
  const _x_8 = (";boundary=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_nextReader_0));
  const _x_11 = (";frameStart=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$12623$(_positions_0));
  const _x_14 = (";nextReader=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$12624$(_batches_0));
  const _x_17 = (";positions=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";batches=" + _x_18);
  return (_key_0 + _x_19);
}

function $beta$047physical$058stream$1262$(_value_0) {
  const _t_0 = _value_0["domain"];
  const _key_0 = _t_0["key"];
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _nextReader_0 = _value_0["nextReader"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = ($Nat$show$(_capacity_0));
  const _x_2 = (";dropped=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_boundary_0));
  const _x_5 = (";capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_frameStart_0));
  const _x_8 = (";boundary=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_nextReader_0));
  const _x_11 = (";frameStart=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$12623$(_positions_0));
  const _x_14 = (";nextReader=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$12625$(_batches_0));
  const _x_17 = (";positions=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";batches=" + _x_18);
  return (_key_0 + _x_19);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1265$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1264$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1264$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $beta$047bindings$058fold2$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1263$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058observed$1262$(_record_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": {$: "Con", "head": _fields_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045condition$045schedule$058condition_placement$1261$(_program_0, _placement_0) {
  if (_placement_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.System") {
    const _position_0 = _placement_0["position"];
    const _slot_0 = _placement_0["condition"];
    return {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.ConditionPlacement", "position": _position_0, "slot": _slot_0, "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058condition_name$1261$(_program_0, _slot_0))}};
  } else if (_placement_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Phase") {
    return {$: "None"};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058placed$1261$(_steps_0, _namespace_0, _bindings_0, _position_0) {
  if (_steps_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _first_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058step$1261$(_namespace_0, _bindings_0, _position_0, _first_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058placed$1261$(_rest_0, _namespace_0, _bindings_0, nat_chk(_position_0 + 1)))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1261$(_plan_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    const _needs_0 = _plan_0["requirements"];
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.PlannedStep", "step": _step_0, "requirements": _needs_0}, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1261$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058planned$1261$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058observed$1261$(_schema_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0}, "snd": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Description", "schema": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058entries$1261$(_schema_0)), "registered": _view_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1261$(_world_0, ($beta$047bindings$058fold4$())(_owners_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058built$1261$(_schema_0, _world_0, _recipe_0, _debug_0, _plan_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Invalid", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}};
  } else {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["schedule"];
    const _namespace_0 = _t_1["namespace"];
    const _name_0 = _t_1["name"];
    const _steps_0 = _t_1["steps"];
    const _owners_1 = _t_1["owners"];
    const _needs_0 = _t_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Attached", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_1, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1261$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1261$(_plan_0)), _catalog_0, _owners_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1261$(_plan_0)))));
}

function $beta$047event$045setup$058sync_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1262$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1263$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1263$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1265$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1265$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1263$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1263$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_family$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1261$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1261$({$: "../../../../../../bendvy/src/ecs/compose.Required"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_slot$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matches$1261$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_read$1261$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1264$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Declaration", "grant": {$: "../../../../../../bendvy/src/ecs/ordinary-resource-field-system.Read", "operation": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058read$1261$())}, "clauses": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(($beta$047state$058inventory_identity$()))), "mode": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1263$(_domains_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1263$(_domains_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058resource_schema$1261$(_schema_0, _base_0) {
  const _added_0 = _schema_0["entries"];
  const _t_0 = _base_0["ordinary"];
  const _t_1 = _t_0["schema"];
  const _entries_0 = _t_1["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": ($List$append$(_entries_0, _added_0))}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_constructed$1261$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1263$(($beta$047state$058resource_identity$())));
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Classified", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Resource"}, "key": _key_0, "name": _key_0, "persistence": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Constructed"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058constructed$1261$(_codec_0) {
  return {$: "../../../../../../bendvy/src/ecs/persistence-declaration.Constructed", "codec": _codec_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058append$1261$(_left_0, _right_0) {
  const _t_0 = _left_0["ordinary"];
  const _t_1 = _t_0["schema"];
  const _left_1 = _t_1["entries"];
  const _t_2 = _right_0["ordinary"];
  const _t_3 = _t_2["schema"];
  const _right_1 = _t_3["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": ($List$append$(_left_1, _right_1))}}};
}

function $beta$047state$058first_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_plain$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058plain$1261$()));
}

function $beta$047state$058second_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_transient$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058transient$1261$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058executed$1260$(_schema_0, _recipe_0, _debug_0, _plan_0, _needs_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _namespace_0 = _t_0["namespace"];
    const _name_0 = _t_0["name"];
    const _steps_0 = _t_0["steps"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "observations": _observations_0};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _namespace_1 = _t_1["namespace"];
    const _name_1 = _t_1["name"];
    const _steps_1 = _t_1["steps"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_1, "owners": _owners_1, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_1, "name": _name_1, "steps": _steps_1, "needs": _needs_0}, "error": _error_0, "observations": _observations_1};
  } else {
    const _t_2 = _result_0["schedule"];
    const _namespace_2 = _t_2["namespace"];
    const _name_2 = _t_2["name"];
    const _steps_2 = _t_2["steps"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Rejected", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_2, "owners": _owners_2, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_2, "name": _name_2, "steps": _steps_2, "needs": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_available$1261$(_observed_0, _schedule_0, _needs_0) {
  const _world_0 = _observed_0["fst"];
  const _available_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_checked$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0)), _schedule_0, _world_0, _needs_0);
}

function $alpha$047dispatch$058provision$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provision$1260$(_world_0);
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $alpha$047physical$058publication$(_value_0) {
  const _pairs_0 = _value_0["first"];
  const _unusedValues_0 = _value_0["second"];
  const _x_0 = ($List$show$1268$(_unusedValues_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($List$show$1267$(_pairs_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("Publication(" + _x_4);
}

function $List$show$go$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058publication$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1262$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058registration$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1261$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_value$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_data$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1261$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058plain_column$1260$(_stamps_0, _observed_0) {
  const _values_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1261$(_stamps_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (";stamps=" + _x_1);
  const _x_3 = (_text_0 + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ("Column{values=" + _x_3)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1262$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058optional$1260$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1262$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_column$1260$(_observed_0) {
  const _state_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "}");
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _state_0}, "snd": ("Indexed{" + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
    const _state_0 = _value_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_state$1260$(_state_0);
  } else {
    const _inner_0 = _value_0["inner"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed$1260$(_inner_0)));
  }
}

function $alpha$047physical$058machine$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "Missing";
  } else {
    const _current_0 = _value_0["current"];
    const _pending_0 = _value_0["pending"];
    const _previous_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = ($alpha$047physical$058previous_text$(_previous_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($alpha$047physical$058next$(_pending_0));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_current_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $alpha$047physical$058slot_ready$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0}, "snd": ("Ready:" + _text_0)};
}

function $alpha$047physical$058batch$1263$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12614$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1263$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058position$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1262$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1260$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_value$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_data$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1260$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1261$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1261$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1260$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1260$(($alpha$047bindings$058fold1$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058fields$1260$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058condition_name$1260$(_entries_0, _slot_0) {
  const _names_0 = _entries_0["names"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058lookup$(_names_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058step$1260$(_namespace_0, _bindings_0, _position_0, _planned_0) {
  const _t_0 = _planned_0["step"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.System") {
    const _id_0 = _t_0["id"];
    const _condition_0 = _t_0["condition"];
    const _requirements_0 = _planned_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.System", "position": _position_0, "namespace": _namespace_0, "id": _id_0, "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058binding_name$1260$(_namespace_0, _id_0, _bindings_0)), "condition": _condition_0, "requirements": _requirements_0};
  } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
    const _name_0 = _t_0["name"];
    const _requirements_1 = _planned_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Phase", "position": _position_0, "name": _name_0, "requirements": _requirements_1};
  } else {
    const _requirements_2 = _planned_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Barrier", "position": _position_0, "requirements": _requirements_2};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058entries$1260$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return _entries_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1260$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1260$(_owners_0, _fields_0, ($alpha$047bindings$058observe4$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1260$(_built_0, _needs_0) {
  if (_built_0.$ === "../../../../../../bendvy/src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Built", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1260$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1260$(_family_0, _tick_0, _records_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _first_0 = _t_0["first"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1262$(_first_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1262$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1262$(_values_0));
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1262$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _second_0 = _t_0["second"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1263$(_second_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1260$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(($alpha$047state$058first_binding$())))))}, _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matches$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matched$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058slot_mode$({$: "../../../../../../bendvy/src/ecs/inspector-query-families.Required"})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_presence$1260$(_frame_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_read$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058family$1260$(($alpha$047state$058first_binding$()))), _world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058read$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1260$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1260$(($alpha$047state$058inventory_lens$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1261$(_domains_0, _capacity_0) {
  const _first_0 = _domains_0["first"];
  const _second_0 = _domains_0["second"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($alpha$047event$045setup$058make_pair$())(_first_0)(_capacity_0), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1262$(_second_0, _capacity_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1261$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $alpha$047state$058resource_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1260$(($alpha$047state$058inventory_identity$()))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_plain$1260$(_extension_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_plain$1260$(_extension_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058plain$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/persistence-declaration.Plain"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_transient$1260$(_extension_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_transient$1260$(_extension_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058transient$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/persistence-declaration.Transient"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$058executed$1261$(_schema_0, _recipe_0, _debug_0, _plan_0, _needs_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _namespace_0 = _t_0["namespace"];
    const _name_0 = _t_0["name"];
    const _steps_0 = _t_0["steps"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Finished", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "observations": _observations_0};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _namespace_1 = _t_1["namespace"];
    const _name_1 = _t_1["name"];
    const _steps_1 = _t_1["steps"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Failed", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_1, "owners": _owners_1, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_1, "name": _name_1, "steps": _steps_1, "needs": _needs_0}, "error": _error_0, "observations": _observations_1};
  } else {
    const _t_2 = _result_0["schedule"];
    const _namespace_2 = _t_2["namespace"];
    const _name_2 = _t_2["name"];
    const _steps_2 = _t_2["steps"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Rejected", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_2, "owners": _owners_2, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_2, "name": _name_2, "steps": _steps_2, "needs": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_available$1263$(_observed_0, _schedule_0, _needs_0) {
  const _world_0 = _observed_0["fst"];
  const _available_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_checked$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1261$(_needs_0, _available_0)), _schedule_0, _world_0, _needs_0);
}

function $beta$047dispatch$058provision$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provision$1261$(_world_0);
}

function $beta$047physical$058publication$(_value_0) {
  const _pairs_0 = _value_0["first"];
  const _unusedValues_0 = _value_0["second"];
  const _x_0 = ($List$show$12621$(_unusedValues_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($List$show$12620$(_pairs_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("Publication(" + _x_4);
}

function $List$show$go$12626$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058publication$(_h_0));
    const _x_1 = ($List$show$go$12626$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058plain_column$1261$(_stamps_0, _observed_0) {
  const _values_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1261$(_stamps_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (";stamps=" + _x_1);
  const _x_3 = (_text_0 + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ("Column{values=" + _x_3)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_column$1261$(_observed_0) {
  const _state_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "}");
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _state_0}, "snd": ("Indexed{" + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
    const _state_0 = _value_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_state$1261$(_state_0);
  } else {
    const _inner_0 = _value_0["inner"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed$1261$(_inner_0)));
  }
}

function $beta$047physical$058machine$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "Missing";
  } else {
    const _current_0 = _value_0["current"];
    const _pending_0 = _value_0["pending"];
    const _previous_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = ($beta$047physical$058previous_text$(_previous_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($beta$047physical$058next$(_pending_0));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_current_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $beta$047physical$058slot_ready$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0}, "snd": ("Ready:" + _text_0)};
}

function $beta$047physical$058batch$1263$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12627$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12627$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1263$(_h_0));
    const _x_1 = ($List$show$go$12627$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$12622$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$12622$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12623$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058position$(_h_0));
    const _x_1 = ($List$show$go$12623$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12624$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12624$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12625$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1262$(_h_0));
    const _x_1 = ($List$show$go$12625$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1264$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1264$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058fold_pair$1263$(_owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1263$(($beta$047bindings$058fold1$()), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058fields$1261$(_x_0);
}), _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058condition_name$1261$(_entries_0, _slot_0) {
  const _names_0 = _entries_0["names"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058lookup$(_names_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058step$1261$(_namespace_0, _bindings_0, _position_0, _planned_0) {
  const _t_0 = _planned_0["step"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.System") {
    const _id_0 = _t_0["id"];
    const _condition_0 = _t_0["condition"];
    const _requirements_0 = _planned_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.System", "position": _position_0, "namespace": _namespace_0, "id": _id_0, "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058binding_name$1261$(_namespace_0, _id_0, _bindings_0)), "condition": _condition_0, "requirements": _requirements_0};
  } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
    const _name_0 = _t_0["name"];
    const _requirements_1 = _planned_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Phase", "position": _position_0, "name": _name_0, "requirements": _requirements_1};
  } else {
    const _requirements_2 = _planned_0["requirements"];
    return {$: "../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Barrier", "position": _position_0, "requirements": _requirements_2};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058entries$1261$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return _entries_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1261$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1261$(_owners_0, _fields_0, ($beta$047bindings$058observe4$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1261$(_built_0, _needs_0) {
  if (_built_0.$ === "../../../../../../bendvy/src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Built", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1261$(_plan_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1261$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1261$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1261$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1261$(_plan_0) {
  if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1261$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1261$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1262$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1262$(_family_0, _tick_0, _records_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1263$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _first_0 = _t_0["first"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1266$(_first_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1265$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1267$(_values_0));
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1266$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1263$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _second_0 = _t_0["second"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1267$(_second_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1261$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1262$(($beta$047state$058first_binding$())))))}, _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1261$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matches$1261$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matched$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058slot_mode$({$: "../../../../../../bendvy/src/ecs/inspector-query-families.Required"})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_presence$1261$(_frame_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_read$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1263$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058family$1262$(($beta$047state$058first_binding$()))), _world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058read$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058project$1261$(_resource_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1261$(($beta$047state$058inventory_lens$())))(_resource_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1263$(_domains_0, _capacity_0) {
  const _first_0 = _domains_0["first"];
  const _second_0 = _domains_0["second"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($beta$047event$045setup$058make_pair$())(_first_0)(_capacity_0), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1265$(_second_0, _capacity_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1263$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $beta$047state$058resource_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058resource_key$1261$(($beta$047state$058inventory_identity$()))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_plain$1261$(_extension_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_plain$1261$(_extension_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058plain$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/persistence-declaration.Plain"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_transient$1261$(_extension_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_transient$1261$(_extension_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058transient$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/persistence-declaration.Transient"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_checked$1261$(_missing_0, _schedule_0, _world_0, _needs_0) {
  if (_missing_0.$ === "Con") {
    const _first_0 = _missing_0["head"];
    const _rest_0 = _missing_0["tail"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Missing", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "missing": {$: "Con", "head": _first_0, "tail": _rest_0}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Executed", "result": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0)), "requirements": _needs_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_next$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_available_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_rest_0, _available_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provision$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provisioned$1260$(($alpha$047bindings$058scan$())(_world_0));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058pair$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058unused$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1262$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_data$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058entry$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1262$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058optional$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _owner_0 = _value_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058optional_done$1260$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1262$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_state$1260$(_value_0) {
  const _values_0 = _value_0["values"];
  const _meta_0 = _value_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_join$1260$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_values_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058metadata$(_meta_0)));
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_wrap$1260$(_observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryWrapped", "inner": _inner_0}, "snd": ("wrapped(" + _x_0)};
}

function $alpha$047physical$058next$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "NoPending";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = ($U32$show$(_value_1));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("Queued:" + _x_3);
  }
}

function $alpha$047physical$058previous_text$(_value_0) {
  if (_value_0.$ === "None") {
    return "None";
  } else {
    const _value_1 = _value_0["value"];
    const _x_0 = ($U32$show$(_value_1));
    return ("Some:" + _x_0);
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $alpha$047physical$058batch$1260$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$1265$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $alpha$047physical$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058position$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $alpha$047physical$058batch$1261$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$1266$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $alpha$047physical$058batch$1262$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$1268$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058batch$1262$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_data$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1261$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1260$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1260$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $alpha$047bindings$058fold1$() {
  return $alpha$047bindings$058fold0$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058fields$1260$(_owner_0) {
  const _t_0 = _owner_0["registry"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _setup_0 = _owner_0["setup"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "setup": _setup_0}, "snd": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1260$(($alpha$047state$058clock_declaration$()))), "clauses": {$: "Nil"}, "kind": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058lookup$($0, $1) {
  for (;;) {
    {
      const _names_0 = $0;
      const _index_0 = $1;
      if (_names_0.$ === "Nil") {
        return {$: "None"};
      } else {
        const _first_0 = _names_0["head"];
        const __0 = _names_0["tail"];
        if (_index_0 === 0) {
          return {$: "Some", "value": _first_0};
        } else {
          const _prior_0 = (_index_0 - 1);
          $0 = __0;
          $1 = _prior_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058binding_name$1260$(_namespace_0, _id_0, _bindings_0) {
  if (_bindings_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _bindings_0["head"];
    const _otherNamespace_0 = _t_0["namespace"];
    const _otherId_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _bindings_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058selected$(($Bool$and$((_namespace_0 === _otherNamespace_0), (_id_0 === _otherId_0))), _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058binding_name$1260$(_namespace_0, _id_0, _rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1260$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_fields_0)), "right": _view_0}}};
}

function $alpha$047bindings$058observe4$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1263$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Built", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_seen_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1260$(_family_0, _tick_0, _records_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1260$(_first_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1260$(_records_0)))), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1261$(_second_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1260$(_records_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1262$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1262$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1263$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1262$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1262$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1263$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Required") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Present") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matched$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058slot_mode$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/inspector-query-families.Required") {
    return {$: "../../../../../../bendvy/src/ecs/compose.Required"};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/compose.Optional"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_presence$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)), _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058family$1260$(_binding_0) {
  const _family_0 = _binding_0["family"];
  return _family_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1260$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _part_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1260$(_rest_0, ($alpha$047state$058view$(_part_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1260$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $alpha$047state$058inventory_lens$() {
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $alpha$047state$058inventory_take$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $alpha$047state$058inventory_put$(_x_1, _x_2);
});
})};
}

function $alpha$047event$045setup$058make_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1260$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1262$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1262$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1261$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1260$(_schema_0) {
  const _entries_0 = _schema_0["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": _entries_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_plain$1260$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(($alpha$047state$058first_binding$())))));
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Classified", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": _key_0, "name": _key_0, "persistence": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Plain"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1261$(_schema_0) {
  const _entries_0 = _schema_0["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": _entries_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_transient$1260$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1261$(($alpha$047state$058second_binding$())))));
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Classified", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": _key_0, "name": _key_0, "persistence": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Transient"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_checked$1263$(_missing_0, _schedule_0, _world_0, _needs_0) {
  if (_missing_0.$ === "Con") {
    const _first_0 = _missing_0["head"];
    const _rest_0 = _missing_0["tail"];
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Missing", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "missing": {$: "Con", "head": _first_0, "tail": _rest_0}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/schedule-provision.Executed", "result": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1263$(_schedule_0, _world_0)), "requirements": _needs_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1261$(_needs_0, _available_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_next$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1261$(_available_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1261$(_rest_0, _available_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provision$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provisioned$1261$(($beta$047bindings$058scan$())(_world_0));
}

function $List$show$12620$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058pair$(_h_0));
    const _x_1 = ($List$show$go$12620$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12621$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058unused$(_h_0));
    const _x_1 = ($List$show$go$12621$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_state$1261$(_value_0) {
  const _values_0 = _value_0["values"];
  const _meta_0 = _value_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_join$1261$(($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1262$(_values_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058metadata$(_meta_0)));
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_wrap$1261$(_observed_0) {
  const _inner_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryWrapped", "inner": _inner_0}, "snd": ("wrapped(" + _x_0)};
}

function $beta$047physical$058next$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "NoPending";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = ($U32$show$(_value_1));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("Queued:" + _x_3);
  }
}

function $beta$047physical$058previous_text$(_value_0) {
  if (_value_0.$ === "None") {
    return "None";
  } else {
    const _value_1 = _value_0["value"];
    const _x_0 = ($U32$show$(_value_1));
    return ("Some:" + _x_0);
  }
}

function $beta$047physical$058batch$1260$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12618$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12622$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$12622$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $beta$047physical$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12623$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058position$(_h_0));
    const _x_1 = ($List$show$go$12623$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $beta$047physical$058batch$1261$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12619$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12624$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12624$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $beta$047physical$058batch$1262$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12621$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12625$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058batch$1262$(_h_0));
    const _x_1 = ($List$show$go$12625$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1264$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058pair$1263$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1263$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $beta$047bindings$058fold1$() {
  return $beta$047bindings$058fold0$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058fields$1261$(_owner_0) {
  const _t_0 = _owner_0["registry"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _setup_0 = _owner_0["setup"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "setup": _setup_0}, "snd": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1261$(($beta$047state$058clock_declaration$()))), "clauses": {$: "Nil"}, "kind": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058binding_name$1261$(_namespace_0, _id_0, _bindings_0) {
  if (_bindings_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _bindings_0["head"];
    const _otherNamespace_0 = _t_0["namespace"];
    const _otherId_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _bindings_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058selected$(($Bool$and$((_namespace_0 === _otherNamespace_0), (_id_0 === _otherId_0))), _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058binding_name$1261$(_namespace_0, _id_0, _rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1261$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_fields_0)), "right": _view_0}}};
}

function $beta$047bindings$058observe4$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1267$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1261$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Built", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1261$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1261$(_seen_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1261$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1262$(_family_0, _tick_0, _records_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1263$(_first_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1262$(_records_0)))), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1264$(_second_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1262$(_records_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1266$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1266$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1267$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1267$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1267$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1267$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1261$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_matched$1261$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_presence$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1262$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)), _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1263$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058family$1262$(_binding_0) {
  const _family_0 = _binding_0["family"];
  return _family_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_get$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058taken$1261$(_result_0) {
  const _rest_0 = _result_0["fst"];
  const _part_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1261$(_rest_0, ($beta$047state$058view$(_part_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058get_field$1261$(_value_0) {
  const _get_0 = _value_0["take"];
  return _get_0;
}

function $beta$047state$058inventory_lens$() {
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Lens", "take": run_clo((_x_0) => {
  return $beta$047state$058inventory_take$(_x_0);
}), "put": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $beta$047state$058inventory_put$(_x_1, _x_2);
});
})};
}

function $beta$047event$045setup$058make_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1262$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1265$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1265$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1263$(_key_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1262$(_schema_0) {
  const _entries_0 = _schema_0["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": _entries_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_plain$1261$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1262$(($beta$047state$058first_binding$())))));
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Classified", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": _key_0, "name": _key_0, "persistence": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Plain"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045binding$045provision$058component_schema$1263$(_schema_0) {
  const _entries_0 = _schema_0["entries"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema-dump.Provision", "ordinary": {$: "../../../../../../bendvy/src/ecs/ordinary-schema-provision.Provision", "schema": {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": _entries_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058component_transient$1261$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1263$(($beta$047state$058second_binding$())))));
  return {$: "../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Classified", "kind": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": _key_0, "name": _key_0, "persistence": {$: "../../../../../../bendvy/src/ecs/schema-fragments.Transient"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_next$1260$(_present_0, _item_0, _next_0) {
  if (!_present_0) {
    return {$: "Con", "head": _item_0, "tail": _next_0};
  } else {
    return _next_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1260$(_head_0, _item_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provisioned$1260$(_value_0) {
  const _world_0 = _value_0["fst"];
  const _statuses_0 = _value_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1260$(_statuses_0))};
}

function $alpha$047bindings$058scan$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1260$(($alpha$047state$058clock_declaration$()), _x_0);
});
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $alpha$047physical$058pair$(_value_0) {
  const _firstValues_0 = _value_0["first"];
  const _secondValues_0 = _value_0["second"];
  const _x_0 = ($List$show$1266$(_secondValues_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($List$show$1265$(_firstValues_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("Pair(" + _x_4);
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058pair$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $alpha$047physical$058unused$(_value_0) {
  const _value_1 = _value_0["value"];
  const _x_0 = ($U32$show$(_value_1));
  return ("Unused:" + _x_0);
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058unused$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1262$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058entry$(_value_0) {
  const _id_0 = _value_0["id"];
  const _value_1 = _value_0["stamp"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058stamp$(_value_1));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058entry$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058optional_done$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": ("some(" + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_join$1260$(_observedValues_0, _observedMeta_0) {
  const _values_0 = _observedValues_0["fst"];
  const _sv_0 = _observedValues_0["snd"];
  const _metadata_0 = _observedMeta_0["fst"];
  const _sm_0 = _observedMeta_0["snd"];
  const _x_0 = (_sm_0 + "})");
  const _x_1 = (";metadata={" + _x_0);
  const _x_2 = (_sv_0 + _x_1);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}, "snd": ("owned(values=" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058metadata$(_value_0) {
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  const _capacity_0 = _value_0["capacity"];
  const _depth_0 = _value_0["depth"];
  const _exceptional_0 = _value_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058metadata_join$(_capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_added_0)), ($$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_changed_0)));
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058first$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058second$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1260$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1260$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $alpha$047bindings$058fold0$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schedule$045description$058selected$(_same_0, _name_0, _next_0) {
  if (!_same_0) {
    return _next_0;
  } else {
    return {$: "Some", "value": _name_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1260$(_record_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1263$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1263$(($alpha$047bindings$058observe3$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1260$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1260$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1260$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1261$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1261$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1263$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1263$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1262$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Required") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Present") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/component.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_world$1260$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1260$(_id_0, ($alpha$047state$058first_take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1260$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1260$(_rest_0, _result_0) {
  const _part_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(($alpha$047state$058inventory_lens$())))(_rest_0)(_part_0), "snd": _value_0};
}

function $alpha$047state$058view$(_value_0) {
  return {$: "Tuple", fst: _value_0, snd: _value_0[0 % _value_0.length]};
}

function $alpha$047state$058inventory_take$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _machine_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "alpha/state.InventoryRest", "clock": _clock_0, "machine": _machine_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _inventory_0};
}

function $alpha$047state$058inventory_put$(_rest_0, _inventory_0) {
  const _clock_0 = _rest_0["clock"];
  const _machine_0 = _rest_0["machine"];
  const _sibling_0 = _rest_0["sibling"];
  const _barriers_0 = _rest_0["barriers"];
  return {$: "alpha/state.Resources", "clock": _clock_0, "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1260$(_domains_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1260$(_domains_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1262$(_domain_0, _capacity_0) {
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1261$(_binding_0) {
  const _identity_0 = _binding_0["identity"];
  return _identity_0;
}

function $alpha$047state$058second_binding$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$("Second")));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1263$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1263$(_schedule_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_next$1261$(_present_0, _item_0, _next_0) {
  if (!_present_0) {
    return {$: "Con", "head": _item_0, "tail": _next_0};
  } else {
    return _next_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1261$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1261$(_head_0, _item_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1261$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provisioned$1261$(_value_0) {
  const _world_0 = _value_0["fst"];
  const _statuses_0 = _value_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1261$(_statuses_0))};
}

function $beta$047bindings$058scan$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1261$(($beta$047state$058clock_declaration$()), _x_0);
});
}

function $beta$047physical$058pair$(_value_0) {
  const _firstValues_0 = _value_0["first"];
  const _secondValues_0 = _value_0["second"];
  const _x_0 = ($List$show$12619$(_secondValues_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($List$show$12618$(_firstValues_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("Pair(" + _x_4);
}

function $List$show$go$12620$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058pair$(_h_0));
    const _x_1 = ($List$show$go$12620$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $beta$047physical$058unused$(_value_0) {
  const _value_1 = _value_0["value"];
  const _x_0 = ($U32$show$(_value_1));
  return ("Unused:" + _x_0);
}

function $List$show$go$12621$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058unused$(_h_0));
    const _x_1 = ($List$show$go$12621$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058indexed_join$1261$(_observedValues_0, _observedMeta_0) {
  const _values_0 = _observedValues_0["fst"];
  const _sv_0 = _observedValues_0["snd"];
  const _metadata_0 = _observedMeta_0["fst"];
  const _sm_0 = _observedMeta_0["snd"];
  const _x_0 = (_sm_0 + "})");
  const _x_1 = (";metadata={" + _x_0);
  const _x_2 = (_sv_0 + _x_1);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}, "snd": ("owned(values=" + _x_2)};
}

function $List$show$12618$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058first$(_h_0));
    const _x_1 = ($List$show$go$12618$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12619$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058second$(_h_0));
    const _x_1 = ($List$show$go$12619$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058first$1263$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1263$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $beta$047bindings$058fold0$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1261$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1261$(_record_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1267$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1267$(($beta$047bindings$058observe3$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1261$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1263$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1263$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1262$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1262$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1264$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1264$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1262$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1262$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1267$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1267$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1267$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045families$058inspect_joined$1262$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_allowed$1261$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/component.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_world$1261$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1261$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1262$(_id_0, ($beta$047state$058first_take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058get_join$1261$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$045field$058viewed$1261$(_rest_0, _result_0) {
  const _part_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1261$(($beta$047state$058inventory_lens$())))(_rest_0)(_part_0), "snd": _value_0};
}

function $beta$047state$058view$(_value_0) {
  return {$: "Tuple", fst: _value_0, snd: _value_0[0 % _value_0.length]};
}

function $beta$047state$058inventory_take$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _machine_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "beta/state.InventoryRest", "clock": _clock_0, "machine": _machine_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _inventory_0};
}

function $beta$047state$058inventory_put$(_rest_0, _inventory_0) {
  const _clock_0 = _rest_0["clock"];
  const _machine_0 = _rest_0["machine"];
  const _sibling_0 = _rest_0["sibling"];
  const _barriers_0 = _rest_0["barriers"];
  return {$: "beta/state.Resources", "clock": _clock_0, "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1262$(_domains_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1262$(_domains_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1265$(_domain_0, _capacity_0) {
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058identity$1263$(_binding_0) {
  const _identity_0 = _binding_0["identity"];
  return _identity_0;
}

function $beta$047state$058second_binding$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1262$("Second")));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1260$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1260$(_statuses_0) {
  if (_statuses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _statuses_0["head"];
    const _id_0 = _t_0["id"];
    const _provided_0 = _t_0["provided"];
    const _rest_0 = _statuses_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available_next$1260$(_provided_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1260$(_declaration_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1260$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1260$(_declaration_0, ($alpha$047state$058clock_take$(_resource_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058stamp$(_value_0) {
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058metadata_join$(_capacity_0, _depth_0, _exceptional_0, _observedAdded_0, _observedChanged_0) {
  const _added_0 = _observedAdded_0["fst"];
  const _sa_0 = _observedAdded_0["snd"];
  const _changed_0 = _observedChanged_0["fst"];
  const _sc_0 = _observedChanged_0["snd"];
  const _x_0 = ($List$show$1261$(_exceptional_0));
  const _x_1 = ($Nat$show$(_depth_0));
  const _x_2 = (";exceptional=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_capacity_0));
  const _x_5 = (";depth=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = (";capacity=" + _x_6);
  const _x_8 = (_sc_0 + _x_7);
  const _x_9 = (";changed=" + _x_8);
  const _x_10 = (_sa_0 + _x_9);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ("added=" + _x_10)};
}

function $alpha$047physical$058first$(_value_0) {
  const _value_1 = _value_0["value"];
  const _x_0 = ($U32$show$(_value_1));
  return ("First:" + _x_0);
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058first$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $alpha$047physical$058second$(_value_0) {
  const _value_1 = _value_0["value"];
  const _x_0 = ($Bool$show$(_value_1));
  return ("Second:" + _x_0);
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($alpha$047physical$058second$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1260$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_unit_0) {
  return {$: "Tuple", "fst": _unit_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1260$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _retained_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1260$(_kind_0, _access_0, _retained_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1263$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_observe$1260$(_world_0)));
}

function $alpha$047bindings$058observe3$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1262$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1260$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_values_0));
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _first_0 = _t_0["first"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1260$(_first_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1261$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_values_0));
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1261$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _second_0 = _t_0["second"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1261$(_second_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1261$(_id_0, ($alpha$047state$058first_take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1262$(_column_0, _id_0)));
}

function $alpha$047state$058first_take$(_store_0) {
  const _first_0 = _store_0["first"];
  const _second_0 = _store_0["second"];
  const _sibling_0 = _store_0["sibling"];
  return {$: "Tuple", "fst": {$: "alpha/state.Rest", "column": _second_0, "sibling": _sibling_0}, "snd": _first_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1260$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1260$(_domains_0, _capacity_0) {
  const _first_0 = _domains_0["first"];
  const _second_0 = _domains_0["second"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1260$(_first_0, _capacity_0)), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1261$(_second_0, _capacity_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1261$(_identity_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-component-binding.Binding", "identity": _identity_0, "family": {$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1263$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1263$(_schedule_0, _world_0, _actual_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1261$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1261$(_statuses_0) {
  if (_statuses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _statuses_0["head"];
    const _id_0 = _t_0["id"];
    const _provided_0 = _t_0["provided"];
    const _rest_0 = _statuses_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available_next$1261$(_provided_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1261$(_declaration_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1261$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1261$(_declaration_0, ($beta$047state$058clock_take$(_resource_0)))));
}

function $beta$047physical$058first$(_value_0) {
  const _value_1 = _value_0["value"];
  const _x_0 = ($U32$show$(_value_1));
  return ("First:" + _x_0);
}

function $List$show$go$12618$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058first$(_h_0));
    const _x_1 = ($List$show$go$12618$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $beta$047physical$058second$(_value_0) {
  const _value_1 = _value_0["value"];
  const _x_0 = ($Bool$show$(_value_1));
  return ("Second:" + _x_0);
}

function $List$show$go$12619$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($beta$047physical$058second$(_h_0));
    const _x_1 = ($List$show$go$12619$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058second$1263$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1261$(_unit_0) {
  return {$: "Tuple", "fst": _unit_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1261$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _retained_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1261$(_kind_0, _access_0, _retained_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1267$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1267$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_observe$1261$(_world_0)));
}

function $beta$047bindings$058observe3$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1266$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1263$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1265$(_values_0));
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1264$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1262$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _first_0 = _t_0["first"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1264$(_first_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1264$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1266$(_values_0));
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1265$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1262$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _second_0 = _t_0["second"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1265$(_second_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1267$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_world$1261$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1263$(_id_0, ($beta$047state$058first_take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1262$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1265$(_column_0, _id_0)));
}

function $beta$047state$058first_take$(_store_0) {
  const _first_0 = _store_0["first"];
  const _second_0 = _store_0["second"];
  const _sibling_0 = _store_0["sibling"];
  return {$: "Tuple", "fst": {$: "beta/state.Rest", "column": _second_0, "sibling": _sibling_0}, "snd": _first_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047owner$045product$058put_field$1261$(_value_0) {
  const _put_0 = _value_0["put"];
  return _put_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1262$(_domains_0, _capacity_0) {
  const _first_0 = _domains_0["first"];
  const _second_0 = _domains_0["second"];
  return {$: "../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1263$(_first_0, _capacity_0)), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1264$(_second_0, _capacity_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045component$045binding$058bind$1263$(_identity_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-component-binding.Binding", "identity": _identity_0, "family": {$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(_identity_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available_next$1260$(_provided_0, _id_0, _rest_0) {
  if (!_provided_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule-provision.Service", "id": _id_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1260$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, _value_0) {
  const _resource_0 = _value_0["fst"];
  const _status_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "Con", "head": _status_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1260$(_declaration_0, _value_0) {
  const _id_0 = _declaration_0["id"];
  const _key_0 = _declaration_0["key"];
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": ($alpha$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"})), "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": false}};
  } else {
    const _owner_0 = _t_0["owner"];
    return {$: "Tuple", "fst": ($alpha$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0})), "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": true}};
  }
}

function $alpha$047state$058clock_take$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _machine_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "alpha/state.ClockRest", "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1260$(_kind_0, _access_0, _retained_0) {
  if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind") {
    return {$: "Nil"};
  } else if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.EventKind") {
    return _retained_0;
  } else {
    const _mode_0 = _kind_0["mode"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _access_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1263$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_returned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058observer$1260$(($alpha$047operations$058resource_declaration$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1262$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1262$(($alpha$047bindings$058observe2$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1260$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1261$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1261$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($alpha$047state$058first_put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1260$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1260$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1261$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1261$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1263$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1263$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available_next$1261$(_provided_0, _id_0, _rest_0) {
  if (!_provided_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule-provision.Service", "id": _id_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1261$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, _value_0) {
  const _resource_0 = _value_0["fst"];
  const _status_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "Con", "head": _status_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1261$(_declaration_0, _value_0) {
  const _id_0 = _declaration_0["id"];
  const _key_0 = _declaration_0["key"];
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": ($beta$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"})), "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": false}};
  } else {
    const _owner_0 = _t_0["owner"];
    return {$: "Tuple", "fst": ($beta$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0})), "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": true}};
  }
}

function $beta$047state$058clock_take$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _machine_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "beta/state.ClockRest", "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1261$(_kind_0, _access_0, _retained_0) {
  if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind") {
    return {$: "Nil"};
  } else if (_kind_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.EventKind") {
    return _retained_0;
  } else {
    const _mode_0 = _kind_0["mode"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1261$(_mode_0, _access_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1267$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_returned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058observer$1261$(($beta$047operations$058resource_declaration$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1266$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1266$(($beta$047bindings$058observe2$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1264$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1265$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1265$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1265$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1264$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1265$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1266$(_batches_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1266$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1266$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1265$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1263$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1263$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($beta$047state$058first_put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1265$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1265$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1265$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1265$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1265$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1263$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1263$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1264$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1264$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1261$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1261$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $alpha$047state$058clock_put$(_rest_0, _clock_0) {
  const _machine_0 = _rest_0["machine"];
  const _inventory_0 = _rest_0["inventory"];
  const _sibling_0 = _rest_0["sibling"];
  const _barriers_0 = _rest_0["barriers"];
  return {$: "alpha/state.Resources", "clock": _clock_0, "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _access_0) {
  if (_access_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _name_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": _name_0, "mode": _mode_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_returned$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058presenter$1260$(($alpha$047operations$058resource_declaration$())))(_value_0);
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058name$1260$(($alpha$047operations$058resource_declaration$())));
  const _x_2 = ("=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _value_0, "rendered": {$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058observer$1260$(_declaration_0) {
  const _observe_0 = _declaration_0["observe"];
  return _observe_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1262$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$058component_observe$1260$(_world_0)));
}

function $alpha$047bindings$058observe2$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1261$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($alpha$047state$058first_put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1261$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../bendvy/src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../../../bendvy/src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1260$(_domain_0, _capacity_0) {
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1261$(_domain_0, _capacity_0) {
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1263$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1263$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $beta$047state$058clock_put$(_rest_0, _clock_0) {
  const _machine_0 = _rest_0["machine"];
  const _inventory_0 = _rest_0["inventory"];
  const _sibling_0 = _rest_0["sibling"];
  const _barriers_0 = _rest_0["barriers"];
  return {$: "beta/state.Resources", "clock": _clock_0, "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1261$(_mode_0, _access_0) {
  if (_access_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _name_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": _name_0, "mode": _mode_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1261$(_mode_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045observation$058resource_returned$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058presenter$1261$(($beta$047operations$058resource_declaration$())))(_value_0);
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058name$1261$(($beta$047operations$058resource_declaration$())));
  const _x_2 = ("=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _value_0, "rendered": {$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058observer$1261$(_declaration_0) {
  const _observe_0 = _declaration_0["observe"];
  return _observe_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1266$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1266$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$058component_observe$1261$(_world_0)));
}

function $beta$047bindings$058observe2$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1265$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1265$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1265$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1265$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1266$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1266$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1266$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($beta$047state$058first_put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1261$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1265$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1265$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1265$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1265$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1265$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1265$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1265$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1265$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1263$(_domain_0, _capacity_0) {
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1264$(_domain_0, _capacity_0) {
  return {$: "../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../../bendvy/src/ecs/schedule.Finished", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1261$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluator$1260$(($alpha$047application$058program$())))(_world_0)(_slot_0), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058name$1260$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058names$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1260$(_declaration_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058presenter$1260$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058renderer$1260$(_declaration_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1262$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$058component_observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058append_previous$1260$({$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1261$(($alpha$047bindings$058observe1$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../bendvy/src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../../../bendvy/src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../../bendvy/src/ecs/schedule.Finished", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1261$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1263$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluator$1261$(($beta$047application$058program$())))(_world_0)(_slot_0), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058name$1261$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058names$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1261$(_declaration_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058presenter$1261$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058renderer$1261$(_declaration_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1266$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$058component_observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058append_previous$1261$({$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1265$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1265$(($beta$047bindings$058observe1$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1265$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1266$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1265$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1265$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1265$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1265$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1265$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1265$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1265$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1265$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1265$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1265$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluator$1260$(_program_0) {
  const _evaluate_0 = _program_0["evaluate"];
  return _evaluate_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058names$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _clauses_0["head"];
    const _key_0 = _t_0["name"];
    const _t_1 = _clauses_0["tail"];
    if (_t_1.$ === "Nil") {
      return _key_0;
    } else {
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058names$1260$(_t_1));
      const _x_1 = ("," + _x_0);
      return (_key_0 + _x_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058renderer$1260$(_declaration_0) {
  const _render_0 = _declaration_0["render"];
  return _render_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058append_previous$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _previous_0 = _t_0["rows"];
  const _summaries_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058appended$1260$(_previous_0, _summaries_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058lowered$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1260$({$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": 0})))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1261$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observe$1260$(_world_0)));
}

function $alpha$047bindings$058observe1$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observation$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, ($alpha$047state$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($alpha$047state$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($alpha$047state$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1261$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045condition$045declaration$058evaluator$1261$(_program_0) {
  const _evaluate_0 = _program_0["evaluate"];
  return _evaluate_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058names$1261$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _clauses_0["head"];
    const _key_0 = _t_0["name"];
    const _t_1 = _clauses_0["tail"];
    if (_t_1.$ === "Nil") {
      return _key_0;
    } else {
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058names$1261$(_t_1));
      const _x_1 = ("," + _x_0);
      return (_key_0 + _x_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058renderer$1261$(_declaration_0) {
  const _render_0 = _declaration_0["render"];
  return _render_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058append_previous$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _previous_0 = _t_0["rows"];
  const _summaries_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058appended$1261$(_previous_0, _summaries_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058lowered$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1261$({$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": 0})))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1265$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1265$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observe$1261$(_world_0)));
}

function $beta$047bindings$058observe1$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observation$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1265$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1265$(_values_0, _stamps_0, _id_0, ($beta$047state$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1265$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1265$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($beta$047state$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1265$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1265$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1265$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1265$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1265$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1265$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1265$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($beta$047state$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1265$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1265$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1265$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($alpha$047dispatch$058dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058appended$1260$(_previous_0, _summaries_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _previous_0, "right": _rows_0}, "rendered": ($List$append$(_summaries_0, {$: "Con", "head": ($List$show$1264$(_rows_0)), "tail": {$: "Nil"}}))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058lowered$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": _rows_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspect_query$1260$()))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1261$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observed$1260$(($alpha$047bindings$058scan$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observation$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1262$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1262$(($alpha$047state$058view$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($alpha$047state$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, ($alpha$047state$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($alpha$047state$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, ($beta$047dispatch$058dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058appended$1261$(_previous_0, _summaries_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _previous_0, "right": _rows_0}, "rendered": ($List$append$(_summaries_0, {$: "Con", "head": ($List$show$12617$(_rows_0)), "tail": {$: "Nil"}}))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058lowered$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": _rows_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1261$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspect_query$1261$()))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1265$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observed$1261$(($beta$047bindings$058scan$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observation$1261$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1264$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1265$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1265$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1265$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1265$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1265$(($beta$047state$058view$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1265$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1265$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($beta$047state$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1265$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1265$(_id_0, _values_0, _metadata_0, ($beta$047state$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1265$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1265$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1265$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($beta$047state$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $alpha$047dispatch$058dispatch$(_owners_0, _world_0, _id_0) {
  return $alpha$047dispatch$058routed$(_world_0, _id_0, ($alpha$047dispatch$058identified$(_owners_0)));
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058render_row$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspect_query$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observed$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _provided_0 = _result_0["snd"];
  const _x_0 = ($List$show$1263$(_provided_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058requirement_text$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058required$1260$())));
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.View", "provided": _provided_0, "required": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058required$1260$()), "tail": {$: "Nil"}}}, "rendered": {$: "Con", "head": ("services=" + _x_0), "tail": {$: "Con", "head": ("requires=" + _x_1), "tail": {$: "Nil"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1260$(($alpha$047bindings$058observe0$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1262$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1262$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $beta$047dispatch$058dispatch$(_owners_0, _world_0, _id_0) {
  return $beta$047dispatch$058routed$(_world_0, _id_0, ($beta$047dispatch$058identified$(_owners_0)));
}

function $List$show$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058render_row$1261$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1261$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspect_query$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058observed$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _provided_0 = _result_0["snd"];
  const _x_0 = ($List$show$12616$(_provided_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058requirement_text$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058required$1261$())));
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.View", "provided": _provided_0, "required": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058required$1261$()), "tail": {$: "Nil"}}}, "rendered": {$: "Con", "head": ("services=" + _x_0), "tail": {$: "Con", "head": ("requires=" + _x_1), "tail": {$: "Nil"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1264$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1264$(($beta$047bindings$058observe0$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1263$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058present$1260$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1265$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1265$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1265$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1265$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1265$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1265$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1265$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1265$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/schedule.Failed", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $alpha$047dispatch$058routed$(_world_0, _id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["fst"];
  const _t_2 = _t_1["fst"];
  const _unit_0 = _t_2["fst"];
  const _service_0 = _t_2["snd"];
  const _component_0 = _t_1["snd"];
  const _resource_0 = _t_0["snd"];
  const _t_3 = _result_0["snd"];
  const _sid_0 = _t_3["fst"];
  const _t_4 = _t_3["snd"];
  const _cid_0 = _t_4["fst"];
  const _rid_0 = _t_4["snd"];
  return $alpha$047dispatch$058selected_service$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _cid_0, _rid_0, (_id_0 === _sid_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058render_row$1260$(_row_0) {
  const _t_0 = _row_0["entity"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _data_0 = _row_0["data"];
  const _x_0 = ($alpha$047operations$058component_text$(_data_0));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_namespace_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058render_row$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058required$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1260$(($alpha$047state$058clock_declaration$()));
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058provided_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058requirement_text$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Service") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("Service:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
    const _id_1 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("Resource:" + _x_1);
  } else {
    const _id_2 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_2));
    return ("Component:" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1260$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observe$1260$(_world_0)));
}

function $alpha$047bindings$058observe0$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1262$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/schedule.Failed", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $beta$047dispatch$058routed$(_world_0, _id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["fst"];
  const _t_2 = _t_1["fst"];
  const _unit_0 = _t_2["fst"];
  const _service_0 = _t_2["snd"];
  const _component_0 = _t_1["snd"];
  const _resource_0 = _t_0["snd"];
  const _t_3 = _result_0["snd"];
  const _sid_0 = _t_3["fst"];
  const _t_4 = _t_3["snd"];
  const _cid_0 = _t_4["fst"];
  const _rid_0 = _t_4["snd"];
  return $beta$047dispatch$058selected_service$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _cid_0, _rid_0, (_id_0 === _sid_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058render_row$1261$(_row_0) {
  const _t_0 = _row_0["entity"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _data_0 = _row_0["data"];
  const _x_0 = ($beta$047operations$058component_text$(_data_0));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_namespace_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045observation$045data$058render_row$1261$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1261$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058required$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1261$(($beta$047state$058clock_declaration$()));
}

function $List$show$12616$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058provided_text$1261$(_h_0));
    const _x_1 = ($List$show$go$12616$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058requirement_text$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Service") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("Service:" + _x_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
    const _id_1 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("Resource:" + _x_1);
  } else {
    const _id_2 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_2));
    return ("Component:" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1264$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1264$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observe$1261$(_world_0)));
}

function $beta$047bindings$058observe0$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1261$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1263$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1263$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1265$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1265$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1265$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1265$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $alpha$047dispatch$058selected_service$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _cid_0, _rid_0, _selected_0) {
  if (_selected_0) {
    return $alpha$047dispatch$058service_completed$(_component_0, _resource_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058run$1260$(_service_0, _world_0)));
  } else {
    return $alpha$047dispatch$058selected_component$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _rid_0, (_id_0 === _cid_0));
  }
}

function $alpha$047operations$058component_text$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
    return "Absent";
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.MissingEntity") {
    return "MissingEntity";
  } else {
    const _value_1 = _value_0["value"];
    const _x_0 = ($U32$show$(_value_1));
    return ("Present:" + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058provided_text$1260$(_value_0) {
  const _id_0 = _value_0["id"];
  const _key_0 = _value_0["key"];
  const _ready_0 = _value_0["provided"];
  const _x_0 = ($Bool$show$(_ready_0));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058provided_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1260$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058presented$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058get$1260$({$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": 0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $beta$047dispatch$058selected_service$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _cid_0, _rid_0, _selected_0) {
  if (_selected_0) {
    return $beta$047dispatch$058service_completed$(_component_0, _resource_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058run$1261$(_service_0, _world_0)));
  } else {
    return $beta$047dispatch$058selected_component$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _rid_0, (_id_0 === _cid_0));
  }
}

function $beta$047operations$058component_text$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
    return "Absent";
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.MissingEntity") {
    return "MissingEntity";
  } else {
    const _value_1 = _value_0["value"];
    const _x_0 = ($U32$show$(_value_1));
    return ("Present:" + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1261$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_world$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1261$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058provided_text$1261$(_value_0) {
  const _id_0 = _value_0["id"];
  const _key_0 = _value_0["key"];
  const _ready_0 = _value_0["provided"];
  const _x_0 = ($Bool$show$(_ready_0));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$12616$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058provided_text$1261$(_h_0));
    const _x_1 = ($List$show$go$12616$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1264$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058presented$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058get$1261$({$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": 0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1263$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $alpha$047dispatch$058service_completed$(_component_0, _resource_0, _result_0) {
  const _service_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Unit"}, "snd": _service_0}, "snd": _component_0}, "snd": _resource_0}, "snd": ($alpha$047dispatch$058service_out$(_outcome_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058run$1260$(_owner_0, _world_0) {
  const _registry_0 = _owner_0["registry"];
  const _setup_0 = _owner_0["setup"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058dispatched$1260$(_setup_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, {$: "Unit"})));
}

function $alpha$047dispatch$058selected_component$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _rid_0, _selected_0) {
  if (_selected_0) {
    return $alpha$047dispatch$058component_completed$({$: "Tuple", "fst": _unit_0, "snd": _service_0}, _resource_0, ($alpha$047dispatch$058run_component$(_component_0, _world_0)));
  } else {
    return $alpha$047dispatch$058selected_resource$(_unit_0, _service_0, _component_0, _resource_0, _world_0, (_id_0 === _rid_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_world$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_world$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058presented$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058current_text$1260$(_view_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($alpha$047state$058mode$())));
  const _x_2 = (":" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _view_0, "rendered": ($List$append$({$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058vocabulary_description$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($alpha$047state$058mode$()))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058values$1260$(($alpha$047state$058mode$())))))))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058get$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_owner_0);
}

function $beta$047dispatch$058service_completed$(_component_0, _resource_0, _result_0) {
  const _service_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Unit"}, "snd": _service_0}, "snd": _component_0}, "snd": _resource_0}, "snd": ($beta$047dispatch$058service_out$(_outcome_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058run$1261$(_owner_0, _world_0) {
  const _registry_0 = _owner_0["registry"];
  const _setup_0 = _owner_0["setup"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058dispatched$1261$(_setup_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1265$(_registry_0, _world_0, {$: "Unit"})));
}

function $beta$047dispatch$058selected_component$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _id_0, _rid_0, _selected_0) {
  if (_selected_0) {
    return $beta$047dispatch$058component_completed$({$: "Tuple", "fst": _unit_0, "snd": _service_0}, _resource_0, ($beta$047dispatch$058run_component$(_component_0, _world_0)));
  } else {
    return $beta$047dispatch$058selected_resource$(_unit_0, _service_0, _component_0, _resource_0, _world_0, (_id_0 === _rid_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1261$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1261$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_world$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles$1261$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_world$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058presented$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058current_text$1261$(_view_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(($beta$047state$058mode$())));
  const _x_2 = (":" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": _view_0, "rendered": ($List$append$({$: "Con", "head": (_x_1 + _x_2), "tail": {$: "Nil"}}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058vocabulary_description$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(($beta$047state$058mode$()))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058values$1261$(($beta$047state$058mode$())))))))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058get$1261$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$(_owner_0);
}

function $alpha$047dispatch$058service_out$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "alpha/dispatch.ServiceFailed"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058dispatched$1260$(_setup_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": _registry_0, "setup": _setup_0}, "snd": _outcome_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": _registry_1, "setup": _setup_0}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "Unit"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $alpha$047dispatch$058component_completed$(_service_0, _resource_0, _result_0) {
  const _component_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": _service_0, "snd": _component_0}, "snd": _resource_0}, "snd": _outcome_0};
}

function $alpha$047dispatch$058run_component$(_record_0, _world_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return $alpha$047dispatch$058component_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1260$(_token_0, _fields_0, _world_0, {$: "Tuple", "fst": {$: "Unit"}, "snd": 0})));
}

function $alpha$047dispatch$058selected_resource$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _selected_0) {
  if (_selected_0) {
    return $alpha$047dispatch$058resource_completed$({$: "Tuple", "fst": {$: "Tuple", "fst": _unit_0, "snd": _service_0}, "snd": _component_0}, ($alpha$047dispatch$058run_resource$(_resource_0, _world_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": _unit_0, "snd": _service_0}, "snd": _component_0}, "snd": _resource_0}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "alpha/dispatch.UnknownSystem"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($alpha$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($alpha$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(_declaration_0) {
  if (_declaration_0.$ === "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $alpha$047state$058mode$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$("Mode", {$: "Con", "head": 3, "tail": {$: "Con", "head": 4, "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058current_text$1260$(_view_0) {
  if (_view_0.$ === "../../../../../../bendvy/src/ecs/machine.Unavailable") {
    return "Unavailable";
  } else {
    const _value_0 = _view_0["value"];
    const _x_0 = ($U32$show$(_value_0));
    return ("Current:" + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058vocabulary_description$1260$(_name_0, _value_0) {
  if (_value_0.$ === "None") {
    return {$: "Nil"};
  } else {
    const _values_0 = _value_0["value"];
    const _x_0 = ($List$show$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058vocabulary_text$1260$(_values_0))));
    const _x_1 = (":Vocabulary=" + _x_0);
    return {$: "Con", "head": (_name_0 + _x_1), "tail": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058values$1260$(_declaration_0) {
  if (_declaration_0.$ === "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration") {
    return {$: "None"};
  } else {
    const _values_0 = _declaration_0["values"];
    return {$: "Some", "value": _values_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1260$()))), _ctx_0);
}

function $beta$047dispatch$058service_out$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "beta/dispatch.ServiceFailed"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$045registration$058dispatched$1261$(_setup_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": _registry_0, "setup": _setup_0}, "snd": _outcome_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-service-registration.Owner", "registry": _registry_1, "setup": _setup_0}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "Unit"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1265$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0)));
}

function $beta$047dispatch$058component_completed$(_service_0, _resource_0, _result_0) {
  const _component_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": _service_0, "snd": _component_0}, "snd": _resource_0}, "snd": _outcome_0};
}

function $beta$047dispatch$058run_component$(_record_0, _world_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return $beta$047dispatch$058component_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1262$(_token_0, _fields_0, _world_0, {$: "Tuple", "fst": {$: "Unit"}, "snd": 0})));
}

function $beta$047dispatch$058selected_resource$(_unit_0, _service_0, _component_0, _resource_0, _world_0, _selected_0) {
  if (_selected_0) {
    return $beta$047dispatch$058resource_completed$({$: "Tuple", "fst": {$: "Tuple", "fst": _unit_0, "snd": _service_0}, "snd": _component_0}, ($beta$047dispatch$058run_resource$(_resource_0, _world_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "Tuple", "fst": _unit_0, "snd": _service_0}, "snd": _component_0}, "snd": _resource_0}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "beta/dispatch.UnknownSystem"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1261$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1261$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1261$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1261$(($beta$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1261$(($beta$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(_declaration_0) {
  if (_declaration_0.$ === "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $beta$047state$058mode$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$("Mode", {$: "Con", "head": 3, "tail": {$: "Con", "head": 4, "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058current_text$1261$(_view_0) {
  if (_view_0.$ === "../../../../../../bendvy/src/ecs/machine.Unavailable") {
    return "Unavailable";
  } else {
    const _value_0 = _view_0["value"];
    const _x_0 = ($U32$show$(_value_0));
    return ("Current:" + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058values$1261$(_declaration_0) {
  if (_declaration_0.$ === "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration") {
    return {$: "None"};
  } else {
    const _values_0 = _declaration_0["values"];
    return {$: "Some", "value": _values_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1261$()))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1262$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1262$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $alpha$047dispatch$058component_returned$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed") {
    const _token_0 = _result_0["token"];
    const _fields_0 = _result_0["fields"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": ($alpha$047dispatch$058component_out$(_outcome_0))};
  } else {
    const _token_1 = _result_0["token"];
    const _fields_1 = _result_0["fields"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_1, "fields": _fields_1}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "alpha/dispatch.UnknownSystem"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1260$(_token_0, _fields_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1260$(_fields_0, _world_0, _args_0);
}

function $alpha$047dispatch$058resource_completed$(_owners_0, _result_0) {
  const _resource_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": _resource_0}, "snd": _outcome_0};
}

function $alpha$047dispatch$058run_resource$(_record_0, _world_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return $alpha$047dispatch$058resource_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1261$(_token_0, _fields_0, _world_0, {$: "Unit"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($alpha$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(_declaration_0) {
  const _inspection_0 = _declaration_0["inspection"];
  return _inspection_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($alpha$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$(_name_0, _values_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058vocabulary_text$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": ($U32$show$(_value_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045machine$058vocabulary_text$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058provide$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1265$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1265$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1265$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $beta$047dispatch$058component_returned$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed") {
    const _token_0 = _result_0["token"];
    const _fields_0 = _result_0["fields"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": ($beta$047dispatch$058component_out$(_outcome_0))};
  } else {
    const _token_1 = _result_0["token"];
    const _fields_1 = _result_0["fields"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_1, "fields": _fields_1}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "beta/dispatch.UnknownSystem"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1262$(_token_0, _fields_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1262$(_fields_0, _world_0, _args_0);
}

function $beta$047dispatch$058resource_completed$(_owners_0, _result_0) {
  const _resource_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": _resource_0}, "snd": _outcome_0};
}

function $beta$047dispatch$058run_resource$(_record_0, _world_0) {
  const _token_0 = _record_0["token"];
  const _fields_0 = _record_0["fields"];
  return $beta$047dispatch$058resource_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1263$(_token_0, _fields_0, _world_0, {$: "Unit"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1261$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1261$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1261$(($beta$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1261$(_declaration_0) {
  const _inspection_0 = _declaration_0["inspection"];
  return _inspection_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_handles_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1261$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045world$058inspect_valid_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058inspection$1261$(($beta$047operations$058component_query$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$(_name_0, _values_0) {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058provide$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1262$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $alpha$047dispatch$058component_out$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "alpha/dispatch.ComponentFailed", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1260$(_fields_0, _world_0, _args_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1260$(_slot_0, _clauses_0, _kind_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0)));
}

function $alpha$047dispatch$058resource_returned$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed") {
    const _token_0 = _result_0["token"];
    const _fields_0 = _result_0["fields"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": ($alpha$047dispatch$058resource_out$(_outcome_0))};
  } else {
    const _token_1 = _result_0["token"];
    const _fields_1 = _result_0["fields"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_1, "fields": _fields_1}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "alpha/dispatch.UnknownSystem"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1261$(_token_0, _fields_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1261$(_fields_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058provide$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058current$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1265$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1265$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1265$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0);
}

function $beta$047dispatch$058component_out$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "beta/dispatch.ComponentFailed", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1262$(_fields_0, _world_0, _args_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1262$(_slot_0, _clauses_0, _kind_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1263$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0)));
}

function $beta$047dispatch$058resource_returned$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed") {
    const _token_0 = _result_0["token"];
    const _fields_0 = _result_0["fields"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_0, "fields": _fields_0}, "snd": ($beta$047dispatch$058resource_out$(_outcome_0))};
  } else {
    const _token_1 = _result_0["token"];
    const _fields_1 = _result_0["fields"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-records.Record", "token": _token_1, "fields": _fields_1}, "snd": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "beta/dispatch.UnknownSystem"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058run$1263$(_token_0, _fields_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1263$(_fields_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1261$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1261$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1261$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1261$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058provide$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058current$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1262$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1260$(_slot_0, _clauses_0, _kind_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1260$(_outcome_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1260$(_slot_0, _clauses_0, _kind_0, _registry_0)));
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1260$(_world_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1260$(_slot_0, _clauses_0, _kind_0, _registry_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $alpha$047dispatch$058resource_out$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "alpha/dispatch.ResourceFailed"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1261$(_fields_0, _world_0, _args_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1261$(_slot_0, _clauses_0, _kind_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058current$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058projected$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1265$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1265$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1265$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1262$(_slot_0, _clauses_0, _kind_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1262$(_outcome_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1262$(_slot_0, _clauses_0, _kind_0, _registry_0)));
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1262$(_world_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1262$(_slot_0, _clauses_0, _kind_0, _registry_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
}

function $beta$047dispatch$058resource_out$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "beta/dispatch.ResourceFailed"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058restored$1263$(_fields_0, _world_0, _args_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _clauses_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1263$(_slot_0, _clauses_0, _kind_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1264$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058current$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058projected$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1262$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1262$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1260$(_outcome_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed", "token": _token_0, "fields": _fields_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1260$(_slot_0, _clauses_0, _kind_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1260$(_world_0, _args_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.RegistrationRejected", "token": _token_0, "fields": _fields_0, "world": _world_0, "args": _args_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1261$(_slot_0, _clauses_0, _kind_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1261$(_outcome_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1261$(_slot_0, _clauses_0, _kind_0, _registry_0)));
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1261$(_world_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1261$(_slot_0, _clauses_0, _kind_0, _registry_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058projected$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($alpha$047state$058machine_take$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1265$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1265$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1262$(_outcome_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed", "token": _token_0, "fields": _fields_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1262$(_slot_0, _clauses_0, _kind_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1262$(_world_0, _args_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.RegistrationRejected", "token": _token_0, "fields": _fields_0, "world": _world_0, "args": _args_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1263$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1263$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058captured$1263$(_slot_0, _clauses_0, _kind_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1263$(_outcome_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1263$(_slot_0, _clauses_0, _kind_0, _registry_0)));
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1263$(_world_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1263$(_slot_0, _clauses_0, _kind_0, _registry_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1264$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1264$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058projected$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($beta$047state$058machine_take$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1261$(_outcome_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed", "token": _token_0, "fields": _fields_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1261$(_slot_0, _clauses_0, _kind_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1261$(_world_0, _args_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.RegistrationRejected", "token": _token_0, "fields": _fields_0, "world": _world_0, "args": _args_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $alpha$047state$058machine_take$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _machine_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "alpha/state.Resources", "clock": _clock_0, "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _machine_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1265$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1263$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058completed$1263$(_outcome_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.Completed", "token": _token_0, "fields": _fields_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058returned$1263$(_slot_0, _clauses_0, _kind_0, _registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Token"}, "snd": {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": _clauses_0, "kind": _kind_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045registration$045run$058rejected$1263$(_world_0, _args_0, _result_0) {
  const _token_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/ordinary-app-registration-run.RegistrationRejected", "token": _token_0, "fields": _fields_0, "world": _world_0, "args": _args_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1264$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1264$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1264$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1264$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $beta$047state$058machine_take$(_value_0) {
  const _clock_0 = _value_0["clock"];
  const _machine_0 = _value_0["machine"];
  const _inventory_0 = _value_0["inventory"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "beta/state.Resources", "clock": _clock_0, "machine": _machine_0, "inventory": _inventory_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _machine_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1262$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1265$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1263$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1264$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1264$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1264$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1264$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058runner$1260$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_called$1260$(($alpha$047state$058clock_take$(_resource_0)))), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1265$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058runner$1261$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_called$1261$(($beta$047state$058clock_take$(_resource_0)))), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1263$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1263$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1264$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1264$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1264$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1264$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_called$1260$(_value_0) {
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return $alpha$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"});
  } else {
    const _owner_0 = _t_0["owner"];
    return $alpha$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": ($alpha$047state$058clock_call$(_owner_0))});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_called$1261$(_value_0) {
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return $beta$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"});
  } else {
    const _owner_0 = _t_0["owner"];
    return $beta$047state$058clock_put$(_rest_0, {$: "../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": ($beta$047state$058clock_call$(_owner_0))});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1264$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1264$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $alpha$047state$058clock_call$(_owner_0) {
  return $alpha$047state$058incremented$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $beta$047state$058clock_call$(_owner_0) {
  return $beta$047state$058incremented$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1263$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1264$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $alpha$047state$058incremented$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_value_0 + 1) >>> 0);
  return (_owner_0[0 % _owner_0.length] = _x_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_runner$1260$(_world_0, _args_0) {
  const _args_1 = _args_0["fst"];
  const _cursor_0 = _args_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058each_since$1260$(_args_1, _world_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1260$(_world_0, _args_0)));
  }
}

function $beta$047state$058incremented$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_value_0 + 1) >>> 0);
  return (_owner_0[0 % _owner_0.length] = _x_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_runner$1261$(_world_0, _args_0) {
  const _args_1 = _args_0["fst"];
  const _cursor_0 = _args_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058completed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058each_since$1261$(_args_1, _world_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1264$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058completed$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058each_since$1260$(_args_0, _world_0, _cursor_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058reserved$1260$(_args_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1260$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058completed$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058each_since$1261$(_args_0, _world_0, _cursor_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058reserved$1261$(_args_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1264$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058runner$1261$(_world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1262$(_world_0)))));
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058reserved$1260$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finished$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058run_handles$1260$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _output_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1260$(_output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0) {
  return $alpha$047operations$058resource_body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058reserved$1261$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finished$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058run_handles$1261$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1262$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058finished$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _output_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1261$(_output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1263$(_tx_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0) {
  return $beta$047operations$058resource_body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1262$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finished$1260$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finish_returned$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _result_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058run_handles$1260$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected$1260$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058run_handles$1260$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_select$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_plan$1260$())))({$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1260$(_output_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $alpha$047operations$058resource_body$1260$(__0, _owner_0) {
  return $alpha$047operations$058resource_completed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finished$1261$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finish_returned$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1262$(_tx_0, _result_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058run_handles$1261$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected$1261$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058run_handles$1261$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_select$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_plan$1261$())))({$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045system$058returned$1261$(_output_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $beta$047operations$058resource_body$1260$(__0, _owner_0) {
  return $beta$047operations$058resource_completed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finish_returned$1260$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected$1260$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058body_returned$1260$(_next_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_select$1260$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_plan$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/compose.Plan", "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(($alpha$047operations$058component_query$()))))), "select": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058selector$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(($alpha$047operations$058component_query$())))))};
}

function $alpha$047operations$058resource_completed$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1260$(($alpha$047operations$058resource_declaration$()))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058finish_returned$1261$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1262$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1262$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected$1261$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058body_returned$1261$(_next_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1261$(_args_0, {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_select$1261$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_plan$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/compose.Plan", "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1261$(($beta$047operations$058component_query$()))))), "select": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058selector$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045observable$058operational$1261$(($beta$047operations$058component_query$())))))};
}

function $beta$047operations$058resource_completed$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_value$1261$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045resource$045field$045declaration$058ordinary$1261$(($beta$047operations$058resource_declaration$()))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058body_returned$1260$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058completed$1260$(_next_0, _tx_0, _value_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $alpha$047operations$058component_body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058grant$1260$(_declaration_0) {
  const _grant_0 = _declaration_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058selector$1260$(_declaration_0) {
  const _select_0 = _declaration_0["select"];
  return _select_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1260$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1260$(_value_0) {
  const _grant_0 = _value_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1262$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1262$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058body_returned$1261$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058completed$1261$(_next_0, _tx_0, _value_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1261$(_args_0, _ctx_0) {
  return $beta$047operations$058component_body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058grant$1261$(_declaration_0) {
  const _grant_0 = _declaration_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045query$045declaration$058selector$1261$(_declaration_0) {
  const _select_0 = _declaration_0["select"];
  return _select_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058read_field$1261$(_cap_0) {
  const _operation_0 = _cap_0["operation"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1263$(_operation_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045resource$045field$045system$058grant$1261$(_value_0) {
  const _grant_0 = _value_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058completed$1260$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058prepend$1260$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0) {
  if (_internal_0.$ === "Some") {
    const _error_0 = _internal_0["value"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": {$: "../../../../../../bendvy/src/ecs/compose.AccessError", "error": _error_0}};
  } else {
    if (_user_0.$ === "../../../../../../bendvy/src/ecs/transaction.Failure") {
      const _error_1 = _user_0["error"];
      return {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": {$: "../../../../../../bendvy/src/ecs/compose.UserError", "error": _error_1}};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/transaction.Success"};
    }
  }
}

function $alpha$047operations$058component_body$1260$(__0, _owner_0) {
  return $alpha$047operations$058component_completed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1262$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058completed$1261$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058prepend$1261$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $beta$047operations$058component_body$1260$(__0, _owner_0) {
  return $beta$047operations$058component_completed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058prepend$1260$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $alpha$047operations$058component_completed$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_caps$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_plan$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058prepend$1261$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $beta$047operations$058component_completed$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_caps$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045system$058observable_plan$1261$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_caps$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058plan_caps$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,1,0,0,2,2,0,11,8,947,7,0,2,1,0,0,0,2,0,1,0,1,24,7,0,1,3,0,3,0,0,37,1,38,2,825,0,7,1,2,4,0,0,1,5,0,2,1,0,53,1,38,7,1,1,6,0,8,0,0,76,15,703,16,37,17,200,18,726,19,460,20,762,21,200,7,0,2,7,0,0,0,8,0,1,0,1,89,7,0,1,9,0,2,0,0,100,13,675,7,0,1,10,0,2,0,0,111,12,609,7,0,1,11,0,4,0,0,126,9,37,10,200,11,562,7,0,1,12,0,2,0,0,137,1,216,7,1,2,13,0,0,1,14,0,2,1,0,152,1,137,7,1,2,15,0,3,0,0,177,1,200,2,200,16,0,4,0,0,177,1,200,2,200,3,201,7,0,5,17,0,0,0,18,0,0,0,19,0,0,0,20,0,0,0,21,0,0,0,4,7,0,3,22,0,0,0,23,0,0,0,24,0,0,0,7,0,1,25,0,2,0,0,227,1,335,7,1,2,26,0,0,1,27,0,2,1,0,242,1,227,7,1,1,28,0,7,0,0,37,1,37,2,200,3,263,4,37,5,200,6,278,7,1,2,29,0,0,1,30,0,2,1,0,200,1,263,7,1,2,31,0,0,1,32,0,2,1,0,293,1,278,7,1,1,33,0,2,0,0,200,1,304,7,0,7,34,0,0,0,35,0,0,0,36,0,0,0,37,0,0,0,38,0,0,0,39,0,0,0,40,0,0,0,7,0,1,41,0,2,0,0,346,6,263,7,0,1,42,0,2,0,0,357,5,37,7,0,1,43,0,2,0,0,368,4,496,7,0,1,44,0,2,0,0,379,2,410,7,0,1,45,0,2,0,0,390,0,397,7,0,1,46,0,0,0,7,0,2,47,0,0,0,48,0,1,0,1,37,7,0,1,49,0,2,0,0,421,1,460,7,1,2,50,0,0,1,51,0,2,1,0,436,1,421,7,1,1,52,0,3,0,0,37,1,200,2,449,7,0,2,53,0,0,0,54,0,0,0,7,1,2,55,0,0,1,56,0,2,1,0,475,1,460,7,1,3,57,0,1,0,0,37,58,0,1,0,0,37,59,0,1,0,0,37,7,0,1,60,0,2,0,0,390,0,507,7,1,2,61,0,0,1,62,0,2,1,0,522,1,507,7,1,1,63,0,2,0,0,533,2,544,7,0,1,64,0,2,0,0,37,1,37,7,1,3,65,0,1,0,0,561,66,0,0,0,67,0,0,0,0,7,1,2,68,0,0,1,69,0,2,1,0,577,1,562,7,1,1,70,0,2,0,0,588,3,460,7,0,3,71,0,2,0,1,37,2,37,72,0,1,0,1,200,73,0,0,0,7,1,2,74,0,0,1,75,0,2,1,0,624,1,609,7,1,3,76,0,6,0,0,661,1,37,2,37,3,662,5,37,6,460,77,0,3,0,0,661,1,200,2,460,78,0,2,0,0,661,1,460,2,7,0,2,79,0,0,0,80,0,1,0,1,200,7,1,2,81,0,0,1,82,0,2,1,0,690,1,675,7,1,1,83,0,3,0,0,661,1,37,2,662,7,1,3,84,0,0,0,85,0,2,0,0,588,3,460,86,0,2,0,0,703,1,703,7,1,2,87,0,0,1,88,0,2,1,0,741,1,726,7,1,3,89,0,2,0,0,37,1,37,90,0,1,0,0,200,91,0,0,0,7,1,2,92,0,0,1,93,0,2,1,0,777,1,762,7,1,1,94,0,8,0,0,37,1,37,2,200,3,263,4,37,5,200,6,278,7,800,7,0,5,95,0,0,0,96,0,1,0,1,304,97,0,0,0,98,0,0,0,99,0,0,0,7,0,4,100,0,1,0,1,852,101,0,2,0,1,892,4,852,102,0,1,0,1,460,103,0,0,0,7,1,2,104,0,0,1,105,0,2,1,0,867,1,852,7,1,4,106,0,1,0,0,200,107,0,1,0,0,37,108,0,1,0,0,37,109,0,0,0,7,0,4,110,0,1,0,1,913,111,0,0,0,112,0,0,0,113,0,0,0,7,0,2,114,0,1,0,1,390,115,0,1,0,1,928,7,0,4,116,0,0,0,117,0,0,0,118,0,0,0,119,0,0,0,7,0,2,120,0,0,0,121,0,1,0,1,960,7,0,1,122,0,3,0,0,37,1,973,2,1515,7,1,2,123,0,0,1,124,0,2,1,0,988,1,973,7,1,1,125,0,8,0,0,1011,15,1454,16,37,17,200,18,726,19,1292,20,1477,21,200,7,0,2,126,0,0,0,127,0,1,0,1,1024,7,0,1,128,0,2,0,0,1035,13,675,7,0,1,129,0,2,0,0,1046,12,1402,7,0,1,130,0,4,0,0,1061,9,37,10,200,11,1376,7,0,1,131,0,2,0,0,1072,1,1112,7,1,2,132,0,0,1,133,0,2,1,0,1087,1,1072,7,1,2,134,0,3,0,0,177,1,200,2,200,135,0,4,0,0,177,1,200,2,200,3,201,7,0,1,136,0,2,0,0,1123,1,1185,7,1,2,137,0,0,1,138,0,2,1,0,1138,1,1123,7,1,1,139,0,7,0,0,37,1,37,2,200,3,263,4,37,5,200,6,1159,7,1,2,140,0,0,1,141,0,2,1,0,1174,1,1159,7,1,1,142,0,2,0,0,200,1,304,7,0,1,143,0,2,0,0,1196,6,263,7,0,1,144,0,2,0,0,1207,5,37,7,0,1,145,0,2,0,0,1218,4,1328,7,0,1,146,0,2,0,0,1229,2,1253,7,0,1,147,0,2,0,0,390,0,1240,7,0,2,148,0,0,0,149,0,1,0,1,37,7,0,1,150,0,2,0,0,1264,1,1292,7,1,2,151,0,0,1,152,0,2,1,0,1279,1,1264,7,1,1,153,0,3,0,0,37,1,200,2,449,7,1,2,154,0,0,1,155,0,2,1,0,1307,1,1292,7,1,3,156,0,1,0,0,37,157,0,1,0,0,37,158,0,1,0,0,37,7,0,1,159,0,2,0,0,390,0,1339,7,1,2,160,0,0,1,161,0,2,1,0,1354,1,1339,7,1,1,162,0,2,0,0,1365,2,544,7,0,1,163,0,2,0,0,37,1,37,7,1,2,164,0,0,1,165,0,2,1,0,1391,1,1376,7,1,1,166,0,2,0,0,588,3,1292,7,1,2,167,0,0,1,168,0,2,1,0,1417,1,1402,7,1,3,169,0,6,0,0,661,1,37,2,37,3,662,5,37,6,1292,170,0,3,0,0,661,1,200,2,1292,171,0,2,0,0,661,1,1292,7,1,3,172,0,0,0,173,0,2,0,0,588,3,1292,174,0,2,0,0,1454,1,1454,7,1,2,175,0,0,1,176,0,2,1,0,1492,1,1477,7,1,1,177,0,8,0,0,37,1,37,2,200,3,263,4,37,5,200,6,1159,7,800,7,0,4,178,0,1,0,1,852,179,0,2,0,1,1542,4,852,180,0,1,0,1,1292,181,0,0,0,7,0,4,182,0,1,0,1,913,183,0,0,0,184,0,0,0,185,0,0,0],["Tuple","None","Some","alpha/consumer.Report","Nil","Con","alpha/consumer.Checkpoint","None","Some","../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Description","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Description","../../../../../../bendvy/src/ecs/ordinary-app-schedule.Description","../../../../../../bendvy/src/ecs/ordinary-app-schema.Description","Nil","Con","../../../../../../bendvy/src/ecs/schema-fragments.Entry","../../../../../../bendvy/src/ecs/schema-fragments.Classified","../../../../../../bendvy/src/ecs/schema-fragments.Component","../../../../../../bendvy/src/ecs/schema-fragments.Resource","../../../../../../bendvy/src/ecs/schema-fragments.Event","../../../../../../bendvy/src/ecs/schema-fragments.Relation","../../../../../../bendvy/src/ecs/schema-fragments.Service","../../../../../../bendvy/src/ecs/schema-fragments.Plain","../../../../../../bendvy/src/ecs/schema-fragments.Transient","../../../../../../bendvy/src/ecs/schema-fragments.Constructed","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding","Nil","Con","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Write","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Optional","../../../../../../bendvy/src/ecs/ordinary-query-declaration.With","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Without","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Added","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Changed","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Unit","../../../../../../bendvy/src/ecs/machine.Unavailable","../../../../../../bendvy/src/ecs/machine.Current","../../../../../../bendvy/src/ecs/ordinary-app-service-registration.View","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status","False","True","Nil","Con","../../../../../../bendvy/src/ecs/schedule-provision.Component","../../../../../../bendvy/src/ecs/schedule-provision.Resource","../../../../../../bendvy/src/ecs/schedule-provision.Service","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow","../../../../../../bendvy/src/ecs/world.Handle","../../../../../../bendvy/src/ecs/component.Found","../../../../../../bendvy/src/ecs/component.ComponentAbsent","../../../../../../bendvy/src/ecs/component.MissingEntity","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-schedule.PlannedStep","../../../../../../bendvy/src/ecs/schedule.System","../../../../../../bendvy/src/ecs/schedule.Phase","../../../../../../bendvy/src/ecs/schedule.Barrier","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.System","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Phase","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Barrier","None","Some","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.ConditionPlacement","../../../../../../bendvy/src/ecs/schedule-provision.Empty","../../../../../../bendvy/src/ecs/schedule-provision.Entry","../../../../../../bendvy/src/ecs/schedule-provision.Sequence","Nil","Con","../../../../../../bendvy/src/ecs/schedule.System","../../../../../../bendvy/src/ecs/schedule.Phase","../../../../../../bendvy/src/ecs/schedule.Barrier","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ResourceKind","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.EventKind","alpha/application.Finished","alpha/application.Failed","alpha/application.Missing","alpha/application.Rejected","Nil","Con","../../../../../../bendvy/src/ecs/schedule.Entered","../../../../../../bendvy/src/ecs/schedule.Ran","../../../../../../bendvy/src/ecs/schedule.Skipped","../../../../../../bendvy/src/ecs/schedule.Applied","alpha/dispatch.ComponentFailed","alpha/dispatch.ResourceFailed","alpha/dispatch.ServiceFailed","alpha/dispatch.UnknownSystem","../../../../../../bendvy/src/ecs/compose.UserError","../../../../../../bendvy/src/ecs/compose.AccessError","../../../../../../bendvy/src/ecs/world.MissingEntity","../../../../../../bendvy/src/ecs/world.CapacityExceeded","../../../../../../bendvy/src/ecs/world.NamespaceExhausted","../../../../../../bendvy/src/ecs/world.SystemIdExhausted","None","Some","beta/consumer.Report","Nil","Con","beta/consumer.Checkpoint","None","Some","../../../../../../bendvy/src/ecs/ordinary-app-condition-schedule.Description","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Description","../../../../../../bendvy/src/ecs/ordinary-app-schedule.Description","../../../../../../bendvy/src/ecs/ordinary-app-schema.Description","Nil","Con","../../../../../../bendvy/src/ecs/schema-fragments.Entry","../../../../../../bendvy/src/ecs/schema-fragments.Classified","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","../../../../../../bendvy/src/ecs/machine.Unavailable","../../../../../../bendvy/src/ecs/machine.Current","../../../../../../bendvy/src/ecs/ordinary-app-service-registration.View","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status","Nil","Con","../../../../../../bendvy/src/ecs/schedule-provision.Component","../../../../../../bendvy/src/ecs/schedule-provision.Resource","../../../../../../bendvy/src/ecs/schedule-provision.Service","../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow","../../../../../../bendvy/src/ecs/world.Handle","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-schedule.PlannedStep","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.System","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Phase","../../../../../../bendvy/src/ecs/ordinary-app-schedule-description.Barrier","../../../../../../bendvy/src/ecs/schedule-provision.Empty","../../../../../../bendvy/src/ecs/schedule-provision.Entry","../../../../../../bendvy/src/ecs/schedule-provision.Sequence","Nil","Con","../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.Fields","beta/application.Finished","beta/application.Failed","beta/application.Missing","beta/application.Rejected","beta/dispatch.ComponentFailed","beta/dispatch.ResourceFailed","beta/dispatch.ServiceFailed","beta/dispatch.UnknownSystem"]]);