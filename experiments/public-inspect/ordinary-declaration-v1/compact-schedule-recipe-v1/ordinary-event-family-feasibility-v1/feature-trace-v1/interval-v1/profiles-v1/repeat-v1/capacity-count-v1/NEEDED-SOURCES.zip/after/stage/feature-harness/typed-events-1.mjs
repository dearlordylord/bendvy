import '../qualified-regular/interval-v1/reference.mjs';
