from pathlib import Path
import re,types,json,hashlib,fcntl
root=Path('/workspace/formal-proofs/bendvy-worktrees/ordinary-custom-store-v1');owned=root/'experiments/public-inspect/ordinary-declaration-v1/ordinary-composed-debug-v1/mixed-notice-v1';entry=owned.parent/'registered-mixed-readers-v1/affected-v1/other-v2/entry.bend'
helper=root/'scripts/task_runner.py';capturepath=Path('/workspace/formal-proofs/bendvy/experiments/public-inspect/ordinary-declaration-v1/canonical-adoption-v1/detached-v2/check-source.py')
def load(path):
 m=types.ModuleType('capture');m.__file__=str(path);exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
capture=load(capturepath);runner=load(helper);seen=set()
def visit(p):
 p=p.resolve()
 if p in seen:return
 seen.add(p)
 for t in re.findall(r'^import\s+(\S+)',p.read_text(),re.M):
  if t!='Base':visit(p.parent/t)
visit(entry);out=Path('/tmp/bendvy-composed-registered-mixed-affected-other-v2-source01');sources=sorted(seen)+[helper,capturepath,Path(__file__),Path('/home/node/.bend/bin/bend-2.0.35'),Path('/home/node/.bend/bend2/base.bend')]
with open('/tmp/bendvy-parity-heavy.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);pins=capture.prepare_attempt(out,sources)
 try:
  result=capture.capture(out,['/usr/bin/taskset','-c','11','/home/node/.bend/bin/bend-2.0.35',str(entry),'--check-only'],runner.execute_result);print(result.get('exit'),result.get('failure'),flush=True)
 finally:(out/'post.json').write_text(json.dumps({'unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items())})+'\n')
(out/'CLOSURE.json').write_text(json.dumps([str(p) for p in sorted(seen)],indent=2)+'\n')
