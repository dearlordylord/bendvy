function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $consumer$058run$();
}

function $consumer$058run$() {
  return $consumer$058created$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), array_node([81], [82]))));
}

function $consumer$058created$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world.Created") {
    const _t_0 = _result_0["factory"];
    const _factory_0 = _t_0["nextNamespace"];
    const _world_0 = _result_0["world"];
    return $consumer$058reserved$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $consumer$058reserved$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $consumer$058activated$(_factory_0, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($state$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $consumer$058activated$(_factory_0, _handle_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _activation_0 = _returned_0["snd"];
  return $consumer$058register_detached$(_factory_0, _handle_0, _activation_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(($event$045setup$058setup$(_world_0, array_node([31], [32]))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $state$058empty$(_unit_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": array_node([11], [12]), "graph": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $consumer$058register_detached$(_factory_0, _handle_0, _activation_0, _detached_0) {
  const _runtime_0 = _detached_0["fst"];
  const _held_0 = _detached_0["snd"];
  return $consumer$058registered$(_factory_0, _handle_0, _activation_0, _held_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058register$1260$(_runtime_0, {$: "Con", "head": ($state$058parent$()), "tail": {$: "Nil"}}, "ParentFailures")));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _t_0 = _runtime_0["family"];
  const _typed_0 = _t_0["typed"];
  const _t_1 = _t_0["failures"];
  const _domains_0 = _t_1["domains"];
  const _positions_0 = _t_1["positions"];
  const _tick_0 = _t_1["tick"];
  const _frameStart_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _typedTick_0 = _runtime_0["tick"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": {$: "Tuple", "fst": _typed_0, "snd": _typedTick_0}};
}

function $event$045setup$058setup$(_world_0, _owners_0) {
  return $event$045setup$058setup_provision$(_world_0, _owners_0, ($event$045setup$058provision$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $consumer$058registered$(_factory_0, _handle_0, _activation_0, _held_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    return $consumer$058queue_before$(_factory_0, _handle_0, _activation_0, ($consumer$058checkpoint$({$: "consumer.State", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, _runtime_0)), "reader": _reader_0, "args": array_node([101], [102]), "checkpoints": {$: "Nil"}, "deliveries": {$: "Nil"}}, true)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058register$1260$(_runtime_0, _declarations_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058register$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058keys$1260$(_declarations_0)), _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058accesses$1260$(_declarations_0)));
}

function $state$058parent$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1260$({$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Hierarchy"}});
}

function $event$045setup$058setup_provision$(_world_0, _owners_0, _value_0) {
  const _domains_0 = _value_0["domains"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058start$1260$(_world_0, ($event$045setup$058make$())(_domains_0)(2), _owners_0);
}

function $event$045setup$058provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1261$(($event$045setup$058pair_provision$()), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1262$("Source.UnusedEvent")))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $consumer$058queue_before$(_factory_0, _handle_0, _activation_0, _state_0) {
  const _t_0 = _state_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return $consumer$058queued_before$(_factory_0, _handle_0, _activation_0, _family_0, _reader_0, _args_0, _before_0, _deliveries_0, ($operations$058queue_self$(_world_0, _handle_0)));
}

function $consumer$058checkpoint$(_state_0, _flag_0) {
  const _runtime_0 = _state_0["runtime"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return $consumer$058described$(_reader_0, _args_0, _before_0, _deliveries_0, ($common$058snapshot$(($common$058enabled$(($common$058attach$(_runtime_0)), _flag_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, _runtime_0) {
  const _typed_0 = _held_0["fst"];
  const _typedTick_0 = _held_0["snd"];
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}}, "tick": _typedTick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058register$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058registered_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058keys$1260$(_declarations_0) {
  if (_declarations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _declaration_0 = _declarations_0["head"];
    const _rest_0 = _declarations_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058key$1260$(_declaration_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058keys$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058accesses$1260$(_declarations_0) {
  if (_declarations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _declaration_0 = _declarations_0["head"];
    const _rest_0 = _declarations_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058access$1260$(_declaration_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058accesses$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1260$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-reader.Declaration", "descriptor": _descriptor_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058start$1260$(_world_0, _family_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058started$1260$({$: "../../../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": {$: "Nil"}, "frameStart": 0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0)));
}

function $event$045setup$058make$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1261$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1261$(_first_0, _second_0) {
  const _first_1 = _first_0["domains"];
  const _second_1 = _second_0["domains"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Domains", "first": _first_1, "second": _second_1}};
}

function $event$045setup$058pair_provision$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$("Signal")))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1261$("Signal")))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1262$(_domain_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1262$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $consumer$058queued_before$(_factory_0, _handle_0, _activation_0, _family_0, _reader_0, _args_0, _before_0, _deliveries_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _queued_0 = _returned_0["snd"];
  return $consumer$058synchronized_before$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, ($event$045setup$058synchronize$(($operations$058publish_before$(_world_0)), _family_0, 1)));
}

function $operations$058queue_self$(_world_0, _handle_0) {
  return $operations$058queued$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058queue_relate$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)), ($state$058descriptor$()), _handle_0, _handle_0)));
}

function $consumer$058described$(_reader_0, _args_0, _before_0, _deliveries_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _description_0 = _result_0["snd"];
  return $consumer$058inventoried$(_description_0, _reader_0, _args_0, _before_0, _deliveries_0, ($common$058inventory$(_app_0)));
}

function $common$058snapshot$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058snapshot$1260$(_value_0);
}

function $common$058enabled$(_value_0, _flag_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058enabled$1260$(_value_0, _flag_0);
}

function $common$058attach$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _state_0 = _runtime_0["family"];
  const _tick_0 = _runtime_0["tick"];
  return $common$058from_registered$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058install$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058registered_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.RegistrationFailed", "runtime": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Registered", "runtime": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058key$1260$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _id_0 = _t_0["key"];
  return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058access$1260$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _name_0 = _t_0["name"];
  return $String$concat$({$: "Con", "head": _name_0, "tail": {$: "Con", "head": ":read", "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058started$1260$(_typed_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}}, "tick": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1261$(_domains_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1261$(_domains_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058branch$1260$(_first_0, _second_0) {
  const _first_1 = _first_0["domains"];
  const _second_1 = _second_0["domains"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Domains", "first": _first_1, "second": _second_1}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1260$(_domain_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf$1261$(_domain_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-family.Provision", "domains": _domain_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045declaration$058domain$1261$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $consumer$058synchronized_before$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _state_0 = _returned_0["snd"];
  return $consumer$058barrier$(_factory_0, _handle_0, _activation_0, _queued_0, ($consumer$058checkpoint$({$: "consumer.State", "runtime": {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": 1}, "reader": _reader_0, "args": _args_0, "checkpoints": _before_0, "deliveries": _deliveries_0}, true)));
}

function $event$045setup$058synchronize$(_world_0, _state_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058synchronize$1260$(_world_0, _state_0, _tick_0);
}

function $operations$058publish_before$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": ($operations$058publication_first$(7)), "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": 1}, "tail": {$: "Con", "head": ($operations$058publication_second$(true)), "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused", "frames": {$: "Nil"}}, "tail": {$: "Nil"}}}}});
}

function $operations$058queued$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $operations$058queued_finished$(_status_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $state$058descriptor$() {
  return $state$058parent_descriptor$(($state$058parent$()));
}

function $consumer$058inventoried$(_description_0, _reader_0, _args_0, _before_0, _deliveries_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _inventory_0 = _result_0["snd"];
  return $consumer$058observed$(_description_0, _inventory_0, _before_0, _deliveries_0, ($physical$058runtime$(($common$058detach$(_app_0)))), ($consumer$058reader_view$(_reader_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_args_0)));
}

function $common$058inventory$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045notice$045runtime$058inventory$1260$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058snapshot$1260$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058with_previous$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058snapshot$1260$(_x_0);
}), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058enabled$1260$(_value_0, _flag_0) {
  const _schema_0 = _value_0["schema"];
  const _runtime_0 = _value_0["runtime"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": _runtime_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _flag_0};
}

function $common$058from_registered$(_state_0, _tick_0, _value_0) {
  const _world_0 = _value_0["world"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": {$: "../../../../../../../../bendvy/src/ecs/ordinary-schema.Schema", "entries": {$: "Nil"}}, "runtime": {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058install$1260$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented_install$1260$(_app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $String$concat$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($String$concat$(_t_0));
    return (_h_0 + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1261$(_domains_0, _capacity_0) {
  const _first_0 = _domains_0["first"];
  const _second_0 = _domains_0["second"];
  return {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($event$045setup$058make_pair$())(_first_0)(_capacity_0), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1262$(_second_0, _capacity_0))};
}

function $consumer$058barrier$(_factory_0, _handle_0, _activation_0, _queued_0, _state_0) {
  const _runtime_0 = _state_0["runtime"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return $consumer$058barrier_detached$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058synchronize$1260$(_world_0, _state_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058synchronized$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $operations$058publication_first$(_value_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": {$: "../../../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": {$: "state.FirstEvent", "value": _value_0}, "tail": {$: "Nil"}}, "second": {$: "Nil"}}, "tail": {$: "Nil"}}, "second": {$: "Nil"}}};
}

function $operations$058publication_second$(_value_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": {$: "../../../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-publication.Publication", "first": {$: "Nil"}, "second": {$: "Con", "head": {$: "state.SecondEvent", "value": _value_0}, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}, "second": {$: "Nil"}}};
}

function $operations$058queued_finished$(_status_0, _result_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $state$058parent_descriptor$(_value_0) {
  const _descriptor_0 = _value_0["descriptor"];
  return _descriptor_0;
}

function $consumer$058observed$(_description_0, _inventory_0, _before_0, _deliveries_0, _runtime_0, _reader_0, _args_0) {
  const _runtime_1 = _runtime_0["fst"];
  const _physical_0 = _runtime_0["snd"];
  const _reader_1 = _reader_0["fst"];
  const _readerView_0 = _reader_0["snd"];
  const _args_1 = _args_0["fst"];
  const _argsText_0 = _args_0["snd"];
  return {$: "consumer.State", "runtime": _runtime_1, "reader": _reader_1, "args": _args_1, "checkpoints": ($List$append$(_before_0, {$: "Con", "head": {$: "consumer.Checkpoint", "description": _description_0, "inventory": _inventory_0, "physical": _physical_0, "reader": _readerView_0, "args": _argsText_0}, "tail": {$: "Nil"}})), "deliveries": _deliveries_0};
}

function $physical$058runtime$(_value_0) {
  const _w_0 = _value_0["world"];
  const _t_0 = _value_0["family"];
  const _t_1 = _t_0["typed"];
  const _t_2 = _t_1["family"];
  const _t_3 = _t_2["left"];
  const _first_0 = _t_3["left"];
  const _second_0 = _t_3["right"];
  const _unused_0 = _t_2["right"];
  const _owners_0 = _t_1["owners"];
  const _journal_0 = _t_1["journal"];
  const _frameStart_0 = _t_1["frameStart"];
  const _failures_0 = _t_0["failures"];
  const _tick_0 = _value_0["tick"];
  return $physical$058observed$(_first_0, _second_0, _unused_0, _owners_0, _journal_0, _frameStart_0, _failures_0, _tick_0, ($physical$058world$(_w_0)));
}

function $common$058detach$(_value_0) {
  const _runtime_0 = _value_0["runtime"];
  return _runtime_0;
}

function $consumer$058reader_view$(_value_0) {
  const _t_0 = _value_0["registry"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _keys_0 = _value_0["keys"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Reader", "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "keys": _keys_0}, "snd": {$: "consumer.ReaderView", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "keys": _keys_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045notice$045runtime$058inventory$1260$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _runtime_0 = _value_0["runtime"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045notice$045runtime$058inventoried$1260$(_schema_0, _owners_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058inventory_enabled$1260$(_debug_0, _runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058with_previous$1260$(_action_0, _value_0) {
  const _schema_0 = _value_0["schema"];
  const _t_0 = _value_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _tick_0 = _t_0["tick"];
  const _owners_0 = _value_0["owners"];
  const _recipe_0 = _value_0["recipe"];
  const _debug_0 = _value_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058returned$1260$(_family_0, _tick_0, _action_0({$: "../../../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058snapshot$1260$(_value_0) {
  const _schema_0 = _value_0["schema"];
  const _app_0 = _value_0["app"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058observed$1260$(_schema_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented_install$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _debug_0 = _app_0["debug"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $event$045setup$058make_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1260$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1262$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1262$(_domain_0, _capacity_0);
}

function $consumer$058barrier_detached$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, _detached_0) {
  const _runtime_0 = _detached_0["fst"];
  const _held_0 = _detached_0["snd"];
  return $consumer$058read_failures$(_factory_0, _handle_0, _activation_0, _queued_0, ($consumer$058checkpoint$({$: "consumer.State", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058barrier$1260$(_runtime_0)))), "reader": _reader_0, "args": _args_0, "checkpoints": _before_0, "deliveries": _deliveries_0}, true)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058synchronized$1260$(_state_0, _tick_0, _observed_0) {
  const _t_0 = _state_0["typed"];
  const _family_0 = _t_0["family"];
  const _owners_0 = _t_0["owners"];
  const _journal_0 = _t_0["journal"];
  const _frameStart_0 = _t_0["frameStart"];
  const _failures_0 = _state_0["failures"];
  const _world_0 = _observed_0["fst"];
  const _records_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058originals$1260$(_records_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1263$(_journal_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1264$(_published_0));
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": ($event$045setup$058sync$())(_family_0)(_tick_0)(_published_0), "owners": _owners_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1263$((0 < _x_0), _journal_0, _tick_0, _published_0)), "frameStart": _frameStart_0}, "failures": _failures_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Queued"}};
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $physical$058observed$(_first_0, _second_0, _unused_0, _owners_0, _journal_0, _frameStart_0, _failures_0, _tick_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _view_0 = _returned_0["snd"];
  return $physical$058owner_returned$(_world_0, _view_0, _first_0, _second_0, _unused_0, _journal_0, _frameStart_0, _failures_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owners_0)));
}

function $physical$058world$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _nextId_0 = _value_0["nextId"];
  const _highWater_0 = _value_0["highWater"];
  const _live_0 = _value_0["live"];
  const _capacity_0 = _value_0["capacity"];
  const _depth_0 = _value_0["depth"];
  const _components_0 = _value_0["store"];
  const _resources_0 = _value_0["resource"];
  const _events_0 = _value_0["events"];
  const _pending_0 = _value_0["pending"];
  const _registrations_0 = _value_0["registrations"];
  const _nextSystemId_0 = _value_0["nextSystemId"];
  const _clock_0 = _value_0["clock"];
  return $physical$058world_returned$(_namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_live_0)), ($physical$058store$(_components_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_resources_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1260$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_value$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045notice$045runtime$058inventoried$1260$(_schema_0, _owners_0, _recipe_0, _debug_0, _returned_0) {
  const _runtime_0 = _returned_0["fst"];
  const _names_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": _runtime_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}, "snd": _names_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058inventory_enabled$1260$(_enabled_0, _runtime_0) {
  if (!_enabled_0) {
    return {$: "Tuple", "fst": _runtime_0, "snd": {$: "None"}};
  } else {
    const _world_0 = _runtime_0["world"];
    const _t_0 = _runtime_0["family"];
    const _t_1 = _t_0["typed"];
    const _family_0 = _t_1["family"];
    const _owners_0 = _t_1["owners"];
    const _journal_0 = _t_1["journal"];
    const _frameStart_0 = _t_1["frameStart"];
    const _failures_0 = _t_0["failures"];
    const _tick_0 = _runtime_0["tick"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058inventoried$1260$(_world_0, _owners_0, _journal_0, _frameStart_0, _failures_0, _tick_0, ($event$045setup$058inventory$())(_family_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045event$045family$045runtime$058returned$1260$(_family_0, _tick_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _schema_0 = _t_0["schema"];
  const _t_1 = _t_0["app"];
  const _world_0 = _t_1["world"];
  const _owners_0 = _t_1["owners"];
  const _recipe_0 = _t_1["recipe"];
  const _debug_0 = _t_1["debug"];
  const _output_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-event-family-runtime.Application", "schema": _schema_0, "runtime": {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _family_0, "tick": _tick_0}, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}, "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045schema$058observed$1260$(_schema_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0}, "snd": {$: "None"}};
  } else {
    const _view_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": _app_0}, "snd": {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-schema.Description", "schema": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058entries$1260$(_schema_0)), "registered": _view_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058snapshot$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _recipe_0 = _app_0["recipe"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_owners_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_make$1260$(_domains_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1260$(_domains_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1262$(_domain_0, _capacity_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $consumer$058read_failures$(_factory_0, _handle_0, _activation_0, _queued_0, _state_0) {
  const _runtime_0 = _state_0["runtime"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return $consumer$058read_detached$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058barrier$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058barrier_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058barrier$1260$(_world_0, _domains_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058originals$1260$($0) {
  for (;;) {
    {
      const _records_0 = $0;
      if (_records_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _records_0["head"];
        if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.Original") {
          const _event_0 = _t_0["event"];
          const _rest_0 = _records_0["tail"];
          return {$: "Con", "head": _event_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058originals$1260$(_rest_0))};
        } else if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
          const _rest_1 = _records_0["tail"];
          $0 = _rest_1;
          continue;
        } else if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
          const _rest_2 = _records_0["tail"];
          $0 = _rest_2;
          continue;
        } else {
          const _rest_3 = _records_0["tail"];
          $0 = _rest_3;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1263$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1263$(_batches_0, 0);
}

function $event$045setup$058sync$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1261$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1263$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1264$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1264$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1264$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $physical$058owner_returned$(_world_0, _worldView_0, _first_0, _second_0, _unused_0, _journal_0, _frameStart_0, _failures_0, _tick_0, _observed_0) {
  const _owners_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _first_0, "right": _second_0}, "right": _unused_0}, "owners": _owners_0, "journal": _journal_0, "frameStart": _frameStart_0}, "failures": _failures_0}, "tick": _tick_0}, "snd": {$: "physical.View", "world": _worldView_0, "first": _first_0, "second": _second_0, "unused": _unused_0, "owners": _text_0, "journal": _journal_0, "frameStart": _frameStart_0, "failures": _failures_0, "typedTick": _tick_0}};
}

function $physical$058world_returned$(_namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _live_0, _components_0, _resources_0, _pending_0) {
  const _live_1 = _live_0["fst"];
  const _liveText_0 = _live_0["snd"];
  const _store_0 = _components_0["fst"];
  const _t_0 = _components_0["snd"];
  const _componentText_0 = _t_0["fst"];
  const _graph_0 = _t_0["snd"];
  const _resources_1 = _resources_0["fst"];
  const _resourceText_0 = _resources_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _count_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_1, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_1, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "physical.WorldView", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _liveText_0, "capacity": _capacity_0, "depth": _depth_0, "components": _componentText_0, "graph": _graph_0, "resources": _resourceText_0, "events": _events_0, "pending": _count_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_value_0);
}

function $physical$058store$(_value_0) {
  const _components_0 = _value_0["components"];
  const _graph_0 = _value_0["graph"];
  return $physical$058store_returned$(_graph_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_components_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks_join$1260$(_head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1260$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_value$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_data$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1260$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058inventoried$1260$(_world_0, _owners_0, _journal_0, _frameStart_0, _failures_0, _tick_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _names_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": _journal_0, "frameStart": _frameStart_0}, "failures": _failures_0}, "tick": _tick_0}, "snd": {$: "Some", "value": _names_0}};
}

function $event$045setup$058inventory$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory$1261$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045schema$058entries$1260$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return _entries_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058folded$1260$(_world_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1260$(_owners_0, _fields_0, ($common$058observe$())(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_unit_0) {
  return {$: "Tuple", "fst": _unit_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_make$1260$(_domains_0, _capacity_0) {
  const _first_0 = _domains_0["first"];
  const _second_0 = _domains_0["second"];
  return {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1260$(_first_0, _capacity_0)), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1261$(_second_0, _capacity_0))};
}

function $consumer$058read_detached$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, _detached_0) {
  const _runtime_0 = _detached_0["fst"];
  const _held_0 = _detached_0["snd"];
  return $consumer$058read_completed$(_factory_0, _handle_0, _activation_0, _queued_0, _held_0, _before_0, _deliveries_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run$1260$(_runtime_0, _reader_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058barrier_join$1260$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058barrier$1260$(_world_0, _domains_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058opened$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)), _domains_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1263$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1264$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1261$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1261$(_family_0, _tick_0, _records_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1264$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1264$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1264$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_value$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_right_0)));
  }
}

function $physical$058store_returned$(_graph_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": {$: "Tuple", "fst": _text_0, "snd": _graph_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058callbacks_join$1260$(_head_0, _observed_0) {
  const _rest_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_data$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory$1261$(_family_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory_join$1261$(($event$045setup$058inventory_pair$())(_first_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_inventory$1262$(_second_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058observed$1260$(_owners_0, _fields_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_fields_0)), "right": _view_0}}};
}

function $common$058observe$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1260$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1260$(_domain_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_make$1261$(_domain_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1261$(_domain_0, _capacity_0);
}

function $consumer$058read_completed$(_factory_0, _handle_0, _activation_0, _queued_0, _held_0, _before_0, _deliveries_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Succeeded") {
    const _t_1 = _t_0["output"];
    const _args_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": ($consumer$058publish_after$(_factory_0, _handle_0, _activation_0, _queued_0, ($consumer$058checkpoint$({$: "consumer.State", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, _runtime_0)), "reader": _reader_0, "args": _args_0, "checkpoints": _before_0, "deliveries": ($List$append$(_deliveries_0, {$: "Con", "head": _readings_0, "tail": {$: "Nil"}}))}, true))))};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run$1260$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run_identified$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0)), _keys_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058opened$1260$(_advanced_0, _domains_0) {
  const _t_0 = _advanced_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058drain$1260$(($List$reverse$(_pending_0)), {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/barrier.BarrierState", "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1261$(_family_0, _tick_0, _records_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($event$045setup$058sync_pair$())(_first_0)(_tick_0)(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1261$(_records_0))), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1262$(_second_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1261$(_records_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1264$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1261$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_value$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_data$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1261$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory_join$1261$(_first_0, _second_0) {
  const _first_1 = _first_0["fst"];
  const _firstNames_0 = _first_0["snd"];
  const _second_1 = _second_0["fst"];
  const _secondNames_0 = _second_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _first_1, "right": _second_1}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_firstNames_0, _secondNames_0))};
}

function $event$045setup$058inventory_pair$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory$1260$(_x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_inventory$1262$(_stream_0) {
  const _retained_0 = _stream_0;
  return {$: "Tuple", "fst": _retained_0, "snd": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058inventory$1262$(_retained_0)), "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1260$(_record_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058bindings$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observe_pair$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1260$(_domain_0, _capacity_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058provision$1261$(_domain_0, _capacity_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $consumer$058publish_after$(_factory_0, _handle_0, _activation_0, _queued_0, _state_0) {
  const _t_0 = _state_0["runtime"];
  const _world_0 = _t_0["world"];
  const _family_0 = _t_0["family"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return $consumer$058synchronized_after$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, 2, ($event$045setup$058synchronize$(($operations$058pending$(($operations$058publish_after$(_world_0)))), _family_0, 2)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run_identified$1260$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)), {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Input", "readings": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058position_or$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058drain$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058command_collected$1260$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $event$045setup$058sync_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1260$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1261$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1262$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1262$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1261$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_data$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory$1260$(_family_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_inventory$1260$(_first_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_inventory$1261$(_second_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058inventory$1262$(_stream_0) {
  const _t_0 = _stream_0["domain"];
  const _key_0 = _t_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058binding$1260$(_fields_0) {
  const _namespace_0 = _fields_0["namespace"];
  const _id_0 = _fields_0["id"];
  const _name_0 = _fields_0["name"];
  const _access_0 = _fields_0["access"];
  const _cursor_0 = _fields_0["cursor"];
  const _slot_0 = _fields_0["slot"];
  const _retained_0 = _fields_0["clauses"];
  const _kind_0 = _fields_0["kind"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "slot": _slot_0, "clauses": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1260$(_kind_0, _access_0, _retained_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_left$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["rows"];
  const _text_0 = _t_0["rendered"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1260$(_value_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058observe$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty_observe$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "Unit"}, "rendered": {$: "Nil"}}};
}

function $consumer$058synchronized_after$(_factory_0, _handle_0, _activation_0, _queued_0, _reader_0, _args_0, _before_0, _deliveries_0, _tick_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _state_0 = _returned_0["snd"];
  return $consumer$058final_frames$(_factory_0, _handle_0, _activation_0, _queued_0, ($consumer$058checkpoint$({$: "consumer.State", "runtime": {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "reader": _reader_0, "args": _args_0, "checkpoints": _before_0, "deliveries": _deliveries_0}, true)));
}

function $operations$058pending$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $operations$058noop$(_x_0);
}));
}

function $operations$058publish_after$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": ($operations$058publication_first$(8)), "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": 2}, "tail": {$: "Con", "head": ($operations$058publication_second$(false)), "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused", "frames": {$: "Nil"}}, "tail": {$: "Nil"}}}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058outcome$1260$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1260$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058command_collected$1260$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058collected$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_command_0(_world_0), _tick_0, _domains_0)), _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_sync$1260$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1260$(_family_0, _tick_0, _records_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _first_0 = _t_0["first"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1262$(_first_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1262$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1262$(_values_0));
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1262$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _second_0 = _t_0["second"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1263$(_second_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_inventory_join$1260$(_first_0, _second_0) {
  const _first_1 = _first_0["fst"];
  const _firstNames_0 = _first_0["snd"];
  const _second_1 = _second_0["fst"];
  const _secondNames_0 = _second_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _first_1, "right": _second_1}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_firstNames_0, _secondNames_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_inventory$1260$(_stream_0) {
  const _retained_0 = _stream_0;
  return {$: "Tuple", "fst": _retained_0, "snd": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058inventory$1260$(_retained_0)), "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_inventory$1261$(_stream_0) {
  const _retained_0 = _stream_0;
  return {$: "Tuple", "fst": _retained_0, "snd": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058inventory$1261$(_retained_0)), "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058clauses$1260$(_kind_0, _access_0, _retained_0) {
  if (_kind_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ComponentKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.FieldKind") {
    return _retained_0;
  } else if (_kind_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.ServiceKind") {
    return {$: "Nil"};
  } else if (_kind_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-app-registration-fields.EventKind") {
    return _retained_0;
  } else {
    const _mode_0 = _kind_0["mode"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _access_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045recipe$058observation_right$1260$(_left_0, _leftText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _right_0 = _t_0["rows"];
  const _rightText_0 = _t_0["rendered"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product", "left": _left_0, "right": _right_0}, "rendered": ($List$append$(_leftText_0, _rightText_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1260$({$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": 0})));
}

function $consumer$058final_frames$(_factory_0, _handle_0, _activation_0, _queued_0, _state_0) {
  return $consumer$058finish$(_factory_0, _handle_0, _activation_0, _queued_0, ($consumer$058checkpoint$(($consumer$058failure_framed$(($consumer$058checkpoint$(($consumer$058failure_framed$(($consumer$058checkpoint$(($consumer$058framed$(($consumer$058checkpoint$(($consumer$058framed$(($consumer$058checkpoint$(($consumer$058checkpoint$(_state_0, true)), false)))), true)))), true)))), true)))), true)));
}

function $operations$058noop$(_world_0) {
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058outcome$1260$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047barrier$058collected$1260$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0)), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_sync$1260$(_family_0, _tick_0, _records_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1260$(_first_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1260$(_records_0)))), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1261$(_second_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1260$(_records_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1262$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1262$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1263$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1262$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1262$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1263$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058inventory$1260$(_stream_0) {
  const _t_0 = _stream_0["domain"];
  const _key_0 = _t_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058inventory$1261$(_stream_0) {
  const _t_0 = _stream_0["domain"];
  const _key_0 = _t_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _access_0) {
  if (_access_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _name_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause", "name": _name_0, "mode": _mode_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045description$058resource_clauses$1260$(_mode_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation", "rows": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-relation.View", "descriptor": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058descriptor$1260$(($state$058parent$()))), "rows": _rows_0}, "rendered": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058descriptor_text$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058descriptor$1260$(($state$058parent$()))))), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058rendered$1260$(_rows_0))}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1260$()))), _owner_0);
}

function $consumer$058finish$(_factory_0, _handle_0, _activation_0, _queued_0, _state_0) {
  const _checkpoints_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return {$: "consumer.Report", "factory": _factory_0, "handle": _handle_0, "activation": _activation_0, "queued": _queued_0, "checkpoints": _checkpoints_0, "deliveries": _deliveries_0};
}

function $consumer$058failure_framed$(_state_0) {
  const _runtime_0 = _state_0["runtime"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return {$: "consumer.State", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058frame_failures$1260$(_runtime_0)), "reader": _reader_0, "args": _args_0, "checkpoints": _before_0, "deliveries": _deliveries_0};
}

function $consumer$058framed$(_state_0) {
  const _runtime_0 = _state_0["runtime"];
  const _reader_0 = _state_0["reader"];
  const _args_0 = _state_0["args"];
  const _before_0 = _state_0["checkpoints"];
  const _deliveries_0 = _state_0["deliveries"];
  return {$: "consumer.State", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058frame$1260$(_runtime_0)), "reader": _reader_0, "args": _args_0, "checkpoints": _before_0, "deliveries": _deliveries_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _error_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), "tick": _clock_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Failed", "error": _error_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), _id_0, _clock_0, false)), _clock_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$(_items_0, {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1260$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1260$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_sync$1261$(_stream_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1261$(_stream_0, _tick_0, _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1263$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1263$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1262$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058descriptor$1260$(_declaration_0) {
  const _value_0 = _declaration_0["descriptor"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058descriptor_text$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _tag_0 = _value_0["kind"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058kind$(_tag_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ("|kind=" + _x_1);
  const _x_3 = (_inverseName_0 + _x_2);
  const _x_4 = ("|inverse=" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_key_0));
  const _x_7 = ("|name=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  return ("Relation{key=" + _x_8);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058rendered$1260$(_rows_0) {
  if (_rows_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _first_0 = _rows_0["head"];
    const _rest_0 = _rows_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_first_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058rendered$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058frame_failures$1260$(_runtime_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_framed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _t_0 = _runtime_0["family"];
  const _t_1 = _t_0["typed"];
  const _family_0 = _t_1["family"];
  const _owners_0 = _t_1["owners"];
  const _journal_0 = _t_1["journal"];
  const _failures_0 = _t_0["failures"];
  const _tick_0 = _runtime_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058framed$1260$(_owners_0, _failures_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retention$1260$(_journal_0, ($event$045setup$058frame$())(_family_0)(_tick_0))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1260$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/readings.KeyReading", "key": _key_0, "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$({$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_replace$1261$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(($operations$058classify$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1260$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_values_0));
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058first_values_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _first_0 = _t_0["first"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1260$(_first_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058append$1261$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_values_0));
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1261$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058second_values_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _reversed_0 = $1;
      if (_items_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _t_0 = _items_0["head"];
        const _second_0 = _t_0["second"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1261$(_second_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058kind$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return "Ordinary";
  } else {
    return "Hierarchy";
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_value_0) {
  const _entity_0 = _value_0["entity"];
  const _t_0 = _value_0["data"];
  const _cells_0 = _t_0["right"];
  const _x_0 = ($List$show$1263$(_cells_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_entity_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_framed$1260$(_detached_0) {
  const _runtime_0 = _detached_0["fst"];
  const _held_0 = _detached_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058frame$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058framed$1260$(_owners_0, _failures_0, _tick_0, _observed_0, _returned_0) {
  const _world_0 = _observed_0["fst"];
  const _notices_0 = _observed_0["snd"];
  const _family_0 = _returned_0["family"];
  const _journal_0 = _returned_0["journal"];
  const _slots_0 = _returned_0["slots"];
  return {$: "../../../../../../../../bendvy/src/ecs/event-family-routing.Runtime", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_notices_0, _slots_0)))), "family": {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../bendvy/src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": _journal_0, "frameStart": _tick_0}, "failures": _failures_0}, "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retention$1260$(_journal_0, _family_0) {
  if (_journal_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.Retention", "family": _family_0, "journal": {$: "Nil"}, "slots": {$: "Nil"}};
  } else {
    const _t_0 = _journal_0["head"];
    const _tick_0 = _t_0["tick"];
    const _records_0 = _t_0["values"];
    const _rest_0 = _journal_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_batch_head$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retention$1260$(_rest_0, _x_0);
}), _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_records$1260$(_records_0, _family_0, _tick_0)));
  }
}

function $event$045setup$058frame$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_frame$1261$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_replace$1261$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $operations$058classify$(_notice_0) {
  if (_notice_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _id_0 = _t_1["key"];
    return {$: "Some", "value": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1260$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1261$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058prepend_values$1261$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _reversed_0 = $1;
      if (_values_0.$ === "Nil") {
        return _reversed_0;
      } else {
        const _head_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _reversed_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = ($U32$show$(_ns_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058trim$1260$(_domains_0, _positions_0, _frameStart_0, _capacity_0)), "positions": _positions_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$($0, $1) {
  for (;;) {
    {
      const _notices_0 = $0;
      const _slots_0 = $1;
      if (_notices_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _notices_0["head"];
        if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.Original") {
          const _rest_0 = _notices_0["tail"];
          if (_slots_0.$ === "Nil") {
            $0 = _rest_0;
            $1 = {$: "Nil"};
            continue;
          } else {
            const _head_0 = _slots_0["head"];
            const _tail_0 = _slots_0["tail"];
            return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058original_notices$1260$(_head_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_0, _tail_0)));
          }
        } else if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
          const _failure_0 = _t_0["failure"];
          const _rest_1 = _notices_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed", "failure": _failure_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_1, _slots_0))};
        } else if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
          const _id_0 = _t_0["id"];
          const _rest_2 = _notices_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": _id_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_2, _slots_0))};
        } else {
          const _frames_0 = _t_0["frames"];
          const _rest_3 = _notices_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused", "frames": _frames_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_3, _slots_0))};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_batch_head$1260$(_rest_0, _tick_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _t_0 = _returned_0["snd"];
  const _records_0 = _t_0["fst"];
  const _slots_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_batch_join$1260$(_tick_0, _records_0, _slots_0, _rest_0(_family_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_records$1260$(_records_0, _family_0, _tick_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Tuple", "fst": _family_0, "snd": {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}}};
  } else {
    const _head_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_record_head$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_records$1260$(_rest_0, _x_0, _tick_0);
}), ($event$045setup$058retain$())(_family_0)(_tick_0)({$: "Con", "head": _head_0, "tail": {$: "Nil"}}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_frame$1261$(_family_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_frame$1261$(_family_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _direction_0 = _value_0["end"];
  const _value_1 = _value_0["value"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058relation_value$1260$(_value_1));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058end$(_direction_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058trim$1260$(_domains_0, _positions_0, _fallback_0, _capacity_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _domain_0 = _domains_0["head"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058trim$1260$(_rest_0, _positions_0, _fallback_0, _capacity_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058original_notices$1260$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": _head_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058original_notices$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_batch_join$1260$(_tick_0, _records_0, _slots_0, _returned_0) {
  const _family_0 = _returned_0["family"];
  const _journal_0 = _returned_0["journal"];
  const _tail_0 = _returned_0["slots"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1264$(_records_0));
  return {$: "../../../../../../../../bendvy/src/ecs/event-notice-runtime.Retention", "family": _family_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058kept_batch$1260$((0 < _x_0), _tick_0, _records_0, _journal_0)), "slots": ($List$append$(_slots_0, _tail_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_record_head$1260$(_rest_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _head_0 = _returned_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_record$1260$(_head_0, _rest_0(_family_0));
}

function $event$045setup$058retain$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain$1261$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_frame$1261$(_family_0, _tick_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($event$045setup$058frame_pair$())(_first_0)(_tick_0), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_frame$1262$(_second_0, _tick_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058end$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing") {
    return "Outgoing";
  } else {
    return "Incoming";
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058relation_value$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Missing") {
    return "Missing";
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Target") {
    const _target_0 = _value_0["handle"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_target_0));
    return ("Target:" + _x_0);
  } else {
    const _targets_0 = _value_0["handles"];
    const _x_1 = ($List$show$1264$(_targets_0));
    return ("Sources:" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0) {
  const _key_0 = _domain_0["key"];
  const _queue_0 = _domain_0["queue"];
  const _ids_0 = _domain_0["readers"];
  return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim$1260$(_queue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058boundary$(_positions_0, _ids_0, _fallback_0)), _capacity_0)), "readers": _ids_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045family$045runtime$058kept_batch$1260$(_keep_0, _tick_0, _records_0, _journal_0) {
  if (!_keep_0) {
    return _journal_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _records_0}, "tail": _journal_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045notice$045runtime$058retained_record$1260$(_head_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _t_0 = _returned_0["snd"];
  const _records_0 = _t_0["fst"];
  const _slots_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _family_0, "snd": {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1265$(_head_0, _records_0)), "snd": {$: "Con", "head": _head_0, "tail": _slots_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain$1261$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_loop$1261$(_records_0, _family_0, _tick_0);
}

function $event$045setup$058frame_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_frame$1260$(_x_0, _x_1);
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_frame$1262$(_stream_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058frame$1262$(_stream_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($operations$058runner$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim$1260$(_queue_0, _boundary_0, _capacity_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_loop$1260$(nat_chk(_size_0 + 1), {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058boundary$($0, $1, $2) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _ids_0 = $1;
      const _acc_0 = $2;
      if (_positions_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _id_0 = _t_0["id"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = _ids_0;
        $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058select_boundary$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _id_0)), _cursor_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1265$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1265$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_loop$1261$(_records_0, _family_0, _tick_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Tuple", "fst": _family_0, "snd": {$: "Nil"}};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_acc$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one$1261$(_tick_0, _record_0, _family_0)), _tick_0, {$: "Nil"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058node_frame$1260$(_family_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_frame$1260$(_family_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058frame$1262$(_stream_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058trimmed$1262$(_domain_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _capacity_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1262$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1262$(_batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), _capacity_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $operations$058runner$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _args_0 = _input_0["args"];
  return {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _args_0, "snd": _readings_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_loop$1260$(_fuel_0, _queue_0, _boundary_0, _capacity_0) {
  if (_fuel_0 === 0) {
    return _queue_0;
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_normalized$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058normalize$1260$(_queue_0)), _boundary_0, _capacity_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_loop$1260$(_rest_0, _x_0, _boundary_0, _capacity_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047domains$058select_boundary$(_registered_0, _cursor_0, _boundary_0) {
  if (!_registered_0) {
    return _boundary_0;
  } else {
    return (_cursor_0 < _boundary_0 ? _cursor_0 : _boundary_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1265$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _records_0 = $0;
      const _returned_0 = $1;
      const _tick_0 = $2;
      const _reversed_0 = $3;
      if (_records_0.$ === "Nil") {
        const _family_0 = _returned_0["fst"];
        const _record_0 = _returned_0["snd"];
        return {$: "Tuple", "fst": _family_0, "snd": ($List$reverse$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_join$1261$(_record_0, _reversed_0))))};
      } else {
        const _head_0 = _records_0["head"];
        const _rest_0 = _records_0["tail"];
        const _family_1 = _returned_0["fst"];
        const _record_1 = _returned_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one$1261$(_tick_0, _head_0, _family_1));
        $2 = _tick_0;
        $3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_join$1261$(_record_1, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one$1261$(_tick_0, _record_0, _family_0) {
  const _a_0 = _record_0["first"];
  const _b_0 = _record_0["second"];
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one_children$1261$(($event$045setup$058retain_pair$())(_first_0)(_tick_0)(_a_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retain$1262$(_second_0, _tick_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_frame$1260$(_family_0, _tick_0) {
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_frame$1260$(_first_0, _tick_0)), "right": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_frame$1261$(_second_0, _tick_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058trimmed$1262$(_domain_0, _positions_0, _nextReader_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1262$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1262$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1262$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1262$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1262$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_normalized$1260$(_queue_0, _boundary_0, _capacity_0, _ih_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_1 = _t_0["head"];
    const _tick_0 = _t_1["tick"];
    const _count_0 = _t_1["count"];
    const _items_0 = _t_1["values"];
    const _rest_0 = _t_0["tail"];
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    const _x_0 = ($Nat$is_le$(_tick_0, _boundary_0));
    const _x_1 = (_capacity_0 < _size_1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_step$1260$((_x_0 || _x_1), _tick_0, _count_0, _items_0, _rest_0, _back_1, _size_1, _dropped_1, _ih_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058normalize$1260$(_queue_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": ($List$reverse$(_back_0)), "back": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": _t_0, "back": _back_1, "size": _size_1, "dropped": _dropped_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_join$1261$(_record_0, _rest_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_head$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058nonempty_record$1261$(_record_0)), _record_0, _rest_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one_children$1261$(_first_0, _second_0) {
  const _first_1 = _first_0["fst"];
  const _firstValues_0 = _first_0["snd"];
  const _second_1 = _second_0["fst"];
  const _secondValues_0 = _second_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _first_1, "right": _second_1}, "snd": {$: "../../../../../../../../bendvy/src/ecs/event-publication.Publication", "first": _firstValues_0, "second": _secondValues_0}};
}

function $event$045setup$058retain_pair$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain$1260$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retain$1262$(_stream_0, _tick_0, _values_0) {
  const _retained_0 = _stream_0;
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retained$1262$(_retained_0, ($Nat$is_le$(_tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058dropped$1262$(_retained_0)))), _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_frame$1260$(_stream_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058frame$1260$(_stream_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_frame$1261$(_stream_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058frame$1261$(_stream_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1262$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1262$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1262$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1262$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1262$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1260$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1260$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047internal$047relation$045failures$047queue$058trim_step$1260$(_remove_0, _tick_0, _count_0, _items_0, _rest_0, _back_0, _size_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _rest_0}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, {$: "../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue", "front": _rest_0, "back": _back_0, "size": (_size_0 < _count_0 ? 0 : _size_0 - _count_0), "dropped": (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0)});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_head$1261$(_keep_0, _record_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _record_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058nonempty_record$1261$(_record_0) {
  const _first_0 = _record_0["first"];
  const _second_0 = _record_0["second"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1263$(_first_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1262$(_second_0));
  const _x_2 = nat_chk(_x_0 + _x_1);
  return (0 < _x_2);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain$1260$(_family_0, _tick_0, _records_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_loop$1260$(_records_0, _family_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retained$1262$(_stream_0, _remove_0, _values_0) {
  if (!_remove_0) {
    return {$: "Tuple", "fst": _stream_0, "snd": _values_0};
  } else {
    return {$: "Tuple", "fst": _stream_0, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058dropped$1262$(_stream_0) {
  const _value_0 = _stream_0["dropped"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058frame$1260$(_stream_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058trimmed$1260$(_domain_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _capacity_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), _capacity_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058frame$1261$(_stream_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058trimmed$1261$(_domain_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _capacity_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1261$(_batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), _capacity_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1262$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1262$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1262$(_batches_0, 0);
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1260$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1263$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1263$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_loop$1260$(_records_0, _family_0, _tick_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Tuple", "fst": _family_0, "snd": {$: "Nil"}};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_acc$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one$1260$(_tick_0, _record_0, _family_0)), _tick_0, {$: "Nil"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058trimmed$1260$(_domain_0, _positions_0, _nextReader_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1260$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1260$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1260$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058trimmed$1261$(_domain_0, _positions_0, _nextReader_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../../../../../../../../bendvy/src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1261$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1261$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1261$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1261$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1261$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1262$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1262$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1263$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058pair_retain_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _records_0 = $0;
      const _returned_0 = $1;
      const _tick_0 = $2;
      const _reversed_0 = $3;
      if (_records_0.$ === "Nil") {
        const _family_0 = _returned_0["fst"];
        const _record_0 = _returned_0["snd"];
        return {$: "Tuple", "fst": _family_0, "snd": ($List$reverse$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_join$1260$(_record_0, _reversed_0))))};
      } else {
        const _head_0 = _records_0["head"];
        const _rest_0 = _records_0["tail"];
        const _family_1 = _returned_0["fst"];
        const _record_1 = _returned_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one$1260$(_tick_0, _head_0, _family_1));
        $2 = _tick_0;
        $3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_join$1260$(_record_1, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one$1260$(_tick_0, _record_0, _family_0) {
  const _a_0 = _record_0["first"];
  const _b_0 = _record_0["second"];
  const _first_0 = _family_0["left"];
  const _second_0 = _family_0["right"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one_children$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retain$1260$(_first_0, _tick_0, _a_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retain$1261$(_second_0, _tick_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1260$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1260$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1260$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1260$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1261$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1261$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1261$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1261$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1261$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1260$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058spec$1260$(($state$058parent$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1260$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058spec$1260$(($state$058parent$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_join$1260$(_record_0, _rest_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_head$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058nonempty_record$1260$(_record_0)), _record_0, _rest_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058retained_one_children$1260$(_first_0, _second_0) {
  const _first_1 = _first_0["fst"];
  const _firstValues_0 = _first_0["snd"];
  const _second_1 = _second_0["fst"];
  const _secondValues_0 = _second_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/owner-product.Owner", "left": _first_1, "right": _second_1}, "snd": {$: "../../../../../../../../bendvy/src/ecs/event-publication.Publication", "first": _firstValues_0, "second": _secondValues_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retain$1260$(_stream_0, _tick_0, _values_0) {
  const _retained_0 = _stream_0;
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retained$1260$(_retained_0, ($Nat$is_le$(_tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058dropped$1260$(_retained_0)))), _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retain$1261$(_stream_0, _tick_0, _values_0) {
  const _retained_0 = _stream_0;
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retained$1261$(_retained_0, ($Nat$is_le$(_tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058dropped$1261$(_retained_0)))), _values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1260$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1261$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1261$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1261$(_batches_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _handle_0, _component_0) {
  const _items_0 = _spec_0["requirements"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058requirements$1260$(_items_0, _graph_0, _namespace_0, _id_0, true, {$: "Nil"})), {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _component_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058spec$1260$(_declaration_0) {
  const _value_0 = _declaration_0["descriptor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058declared_spec$1260$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058retained_head$1260$(_keep_0, _record_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _record_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045publication$058nonempty_record$1260$(_record_0) {
  const _first_0 = _record_0["first"];
  const _second_0 = _record_0["second"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_first_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_second_0));
  const _x_2 = nat_chk(_x_0 + _x_1);
  return (0 < _x_2);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retained$1260$(_stream_0, _remove_0, _values_0) {
  if (!_remove_0) {
    return {$: "Tuple", "fst": _stream_0, "snd": _values_0};
  } else {
    return {$: "Tuple", "fst": _stream_0, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058dropped$1260$(_stream_0) {
  const _value_0 = _stream_0["dropped"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045event$045family$058leaf_retained$1261$(_stream_0, _remove_0, _values_0) {
  if (!_remove_0) {
    return {$: "Tuple", "fst": _stream_0, "snd": _values_0};
  } else {
    return {$: "Tuple", "fst": _stream_0, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045stream$058dropped$1261$(_stream_0) {
  const _value_0 = _stream_0["dropped"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows_result$1260$(_observed_0, _handle_0, _component_0) {
  const _selected_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _selected_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Row", "entity": _handle_0, "cells": _cells_0, "component": _component_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058requirements$1260$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _graph_0 = $1;
      const _namespace_0 = $2;
      const _id_0 = $3;
      const _selected_0 = $4;
      const _acc_0 = $5;
      if (_remaining_0.$ === "Nil") {
        return {$: "Tuple", "fst": _selected_0, "snd": ($List$reverse$(_acc_0))};
      } else {
        const _t_0 = _remaining_0["head"];
        const _key_0 = _t_0["key"];
        const _descriptor_0 = _t_0["descriptor"];
        const _end_0 = _t_0["end"];
        const _mode_0 = _t_0["mode"];
        const _project_0 = _t_0["project"];
        const _rest_0 = _remaining_0["tail"];
        const _observed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058value$1260$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0));
        $0 = _rest_0;
        $1 = _graph_0;
        $2 = _namespace_0;
        $3 = _id_0;
        $4 = ($Bool$and$(_selected_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047query$058selection_aux$1260$(_mode_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058presence$1260$(_observed_0))))));
        $5 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058add_cell$1260$(_project_0, _key_0, _end_0, _observed_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058declared_spec$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _tag_0 = _value_0["kind"];
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_relation$1260$(_name_0, {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": _key_0, "name": _name_0, "inverseName": _inverseName_0, "kind": _tag_0})), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_related$1260$(_inverseName_0, {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": _key_0, "name": _name_0, "inverseName": _inverseName_0, "kind": _tag_0})), "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058value$1260$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0) {
  if (_end_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058outgoing_value$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058incoming_value$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047query$058selection_aux$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/query.Required") {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/query.Present") {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/query.Absent") {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058presence$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent"};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/component.Found", "value": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058add_cell$1260$(_project_0, _key_0, _end_0, _value_0, _cells_0) {
  if (!_project_0) {
    return _cells_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Cell", "key": _key_0, "end": _end_0, "value": _value_0}, "tail": _cells_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_relation$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_related$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058outgoing_value$1260$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Missing"};
  } else {
    const _id_0 = _value_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Target", "handle": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058incoming_value$1260$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Missing"};
  } else {
    const _first_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Sources", "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058handles_acc$1260$({$: "Con", "head": _first_0, "tail": _rest_0}, _namespace_0, {$: "Nil"}))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058handles_acc$1260$($0, $1, $2) {
  for (;;) {
    {
      const _ids_0 = $0;
      const _namespace_0 = $1;
      const _acc_0 = $2;
      if (_ids_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _id_0 = _ids_0["head"];
        const _rest_0 = _ids_0["tail"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,2,0,0,0,0,1,0,1,0,1,13,7,0,1,2,0,6,0,0,32,1,33,3,44,5,76,6,87,7,1544,0,7,0,1,3,0,2,0,0,32,1,32,7,0,2,4,0,0,0,5,0,1,0,1,57,7,0,4,6,0,0,0,7,0,0,0,8,0,0,0,9,0,0,0,7,0,2,10,0,0,0,11,0,0,0,7,1,2,12,0,0,1,13,0,2,1,0,102,1,87,7,1,1,14,0,5,0,0,119,9,546,11,559,60,1501,66,206,7,0,2,15,0,0,0,16,0,1,0,1,132,7,0,1,17,0,2,0,0,143,1,222,7,1,2,18,0,0,1,19,0,2,1,0,158,1,143,7,1,2,20,0,3,0,0,183,1,206,2,206,21,0,4,0,0,183,1,206,2,206,3,207,7,0,5,22,0,0,0,23,0,0,0,24,0,0,0,25,0,0,0,26,0,0,0,4,7,0,3,27,0,0,0,28,0,0,0,29,0,0,0,7,0,1,30,0,2,0,0,233,1,341,7,1,2,31,0,0,1,32,0,2,1,0,248,1,233,7,1,1,33,0,7,0,0,32,1,32,2,206,3,269,4,32,5,206,6,284,7,1,2,34,0,0,1,35,0,2,1,0,206,1,269,7,1,2,36,0,0,1,37,0,2,1,0,299,1,284,7,1,1,38,0,2,0,0,206,1,310,7,0,7,39,0,0,0,40,0,0,0,41,0,0,0,42,0,0,0,43,0,0,0,44,0,0,0,45,0,0,0,7,0,1,46,0,2,0,0,352,5,269,7,0,1,47,0,2,0,0,363,0,370,7,0,1,48,0,0,0,7,0,1,49,0,2,0,0,381,4,407,7,0,1,50,0,4,0,0,32,1,206,2,206,3,396,7,0,2,51,0,0,0,52,0,0,0,7,1,2,53,0,0,1,54,0,2,1,0,422,1,407,7,1,1,55,0,2,0,0,433,2,444,7,0,1,56,0,2,0,0,32,1,32,7,1,1,57,0,2,0,0,455,1,462,7,1,1,58,0,0,0,7,1,2,59,0,0,1,60,0,2,1,0,477,1,462,7,1,1,61,0,3,0,0,206,1,490,2,501,7,0,2,62,0,0,0,63,0,0,0,7,0,3,64,0,0,0,65,0,1,0,1,433,66,0,1,0,1,520,7,1,2,67,0,0,1,68,0,2,1,0,535,1,520,7,1,1,69,0,2,0,0,32,1,32,7,0,2,70,0,0,0,71,0,1,0,1,269,7,0,1,72,0,9,0,0,584,15,1091,23,1177,31,1235,39,206,40,1293,41,619,42,1360,48,619,7,0,1,73,0,14,0,0,32,1,32,2,32,3,206,4,32,5,619,6,206,7,620,9,206,10,718,11,619,12,1063,13,32,14,32,2,7,0,1,74,0,2,0,0,631,1,674,7,1,2,75,0,0,1,76,0,2,1,0,646,1,631,7,1,1,77,0,3,0,0,659,4,32,5,32,7,0,1,78,0,4,0,0,32,1,206,2,206,3,396,7,1,2,79,0,0,1,80,0,2,1,0,689,1,674,7,1,1,81,0,3,0,0,659,4,32,5,702,7,1,2,82,0,0,1,83,0,2,1,0,717,1,702,0,7,1,2,84,0,0,1,85,0,2,1,0,733,1,718,7,1,4,86,0,1,0,0,760,87,0,1,0,0,880,88,0,1,0,0,32,89,0,1,0,0,983,7,1,1,90,0,2,0,0,771,1,856,7,1,2,91,0,0,1,92,0,2,1,0,786,1,771,7,1,1,93,0,2,0,0,797,1,821,7,1,2,94,0,0,1,95,0,2,1,0,812,1,797,7,1,1,96,0,1,0,0,32,7,1,2,97,0,0,1,98,0,2,1,0,836,1,821,7,1,1,99,0,1,0,0,845,7,0,2,100,0,0,0,101,0,0,0,7,1,2,102,0,0,1,103,0,2,1,0,871,1,856,7,1,1,104,0,1,0,0,32,7,0,1,105,0,5,0,0,659,4,897,5,32,6,32,7,908,7,0,2,106,0,0,0,107,0,0,0,7,0,8,108,0,1,0,1,32,109,0,3,0,1,32,2,32,3,206,110,0,2,0,1,32,2,206,111,0,3,0,1,32,2,32,3,206,112,0,3,0,1,32,2,32,3,206,113,0,3,0,1,32,2,32,3,206,114,0,3,0,1,32,2,32,3,206,115,0,2,0,1,32,2,206,7,1,2,116,0,0,1,117,0,2,1,0,998,1,983,7,1,4,118,0,1,0,0,32,119,0,2,0,0,32,1,1033,120,0,4,0,0,32,1,659,5,1033,6,702,121,0,1,0,0,32,7,1,2,122,0,0,1,123,0,2,1,0,1048,1,1033,7,1,1,124,0,4,0,0,32,1,206,2,206,3,396,7,1,2,125,0,0,1,126,0,2,1,0,1078,1,1063,7,1,1,127,0,3,0,0,32,1,206,2,269,7,0,1,128,0,8,0,0,1114,1,1123,2,1149,3,32,4,619,5,619,6,619,7,619,7,0,1,129,0,1,0,0,206,7,1,2,130,0,0,1,131,0,2,1,0,1138,1,1123,7,1,1,132,0,2,0,0,619,1,797,7,1,2,133,0,0,1,134,0,2,1,0,1164,1,1149,7,1,1,135,0,3,0,0,32,1,619,2,619,7,0,1,136,0,8,0,0,1200,1,1209,2,1149,3,32,4,619,5,619,6,619,7,619,7,0,1,137,0,1,0,0,206,7,1,2,138,0,0,1,139,0,2,1,0,1224,1,1209,7,1,1,140,0,2,0,0,619,1,821,7,0,1,141,0,8,0,0,1258,1,1267,2,1149,3,32,4,619,5,619,6,619,7,619,7,0,1,142,0,1,0,0,206,7,1,2,143,0,0,1,144,0,2,1,0,1282,1,1267,7,1,1,145,0,2,0,0,619,1,856,7,1,2,146,0,0,1,147,0,2,1,0,1308,1,1293,7,1,1,148,0,2,0,0,619,1,1319,7,1,2,149,0,0,1,150,0,2,1,0,1334,1,1319,7,1,1,151,0,2,0,0,1345,1,856,7,1,2,152,0,0,1,153,0,2,1,0,786,1,1345,7,0,1,154,0,6,0,0,1379,1,1149,2,619,3,619,4,619,5,619,7,1,2,155,0,0,1,156,0,2,1,0,1394,1,1379,7,1,1,157,0,3,0,0,1407,1,1416,5,702,7,0,1,158,0,1,0,0,32,7,0,1,159,0,4,0,0,1431,1,1431,2,619,3,619,7,1,2,160,0,0,1,161,0,2,1,0,1446,1,1431,7,1,1,162,0,3,0,0,619,1,619,2,1459,7,1,2,163,0,0,1,164,0,2,1,0,1474,1,1459,7,1,4,165,0,1,0,0,1334,166,0,1,0,0,880,167,0,1,0,0,32,168,0,1,0,0,983,7,0,1,169,0,6,0,0,32,1,32,2,206,3,269,4,32,5,1520,7,1,2,170,0,0,1,171,0,2,1,0,1535,1,1520,7,1,1,172,0,1,0,0,32,7,1,2,173,0,0,1,174,0,2,1,0,1559,1,1544,7,1,2,175,0,0,1,176,0,2,1,0,1574,1,1559,7,1,1,177,0,3,0,0,1407,1,718,2,845],["None","Some","consumer.Report","../../../../../../../../bendvy/src/ecs/world.Handle","../../../../../../../../bendvy/src/ecs/world.Accepted","../../../../../../../../bendvy/src/ecs/world.Rejected","../../../../../../../../bendvy/src/ecs/world.MissingEntity","../../../../../../../../bendvy/src/ecs/world.CapacityExceeded","../../../../../../../../bendvy/src/ecs/world.NamespaceExhausted","../../../../../../../../bendvy/src/ecs/world.SystemIdExhausted","../../../../../../../../bendvy/src/ecs/relation-commands.Queued","../../../../../../../../bendvy/src/ecs/relation-commands.MissingEntity","Nil","Con","consumer.Checkpoint","None","Some","../../../../../../../../bendvy/src/ecs/ordinary-app-schema.Description","Nil","Con","../../../../../../../../bendvy/src/ecs/schema-fragments.Entry","../../../../../../../../bendvy/src/ecs/schema-fragments.Classified","../../../../../../../../bendvy/src/ecs/schema-fragments.Component","../../../../../../../../bendvy/src/ecs/schema-fragments.Resource","../../../../../../../../bendvy/src/ecs/schema-fragments.Event","../../../../../../../../bendvy/src/ecs/schema-fragments.Relation","../../../../../../../../bendvy/src/ecs/schema-fragments.Service","../../../../../../../../bendvy/src/ecs/schema-fragments.Plain","../../../../../../../../bendvy/src/ecs/schema-fragments.Transient","../../../../../../../../bendvy/src/ecs/schema-fragments.Constructed","../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Nil","Con","../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Binding","Nil","Con","Nil","Con","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Clause","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Read","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Write","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Optional","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.With","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Without","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Added","../../../../../../../../bendvy/src/ecs/ordinary-query-declaration.Changed","../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Observation","../../../../../../../../bendvy/src/ecs/ordinary-app-observation-data.Product","Unit","../../../../../../../../bendvy/src/ecs/ordinary-app-relation.View","../../../../../../../../bendvy/src/ecs/relation-types.Descriptor","../../../../../../../../bendvy/src/ecs/relation-types.Ordinary","../../../../../../../../bendvy/src/ecs/relation-types.Hierarchy","Nil","Con","../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow","../../../../../../../../bendvy/src/ecs/world.Handle","../../../../../../../../bendvy/src/ecs/inspector-query-projection.Product","Unit","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-query.Cell","../../../../../../../../bendvy/src/ecs/relation-query.Outgoing","../../../../../../../../bendvy/src/ecs/relation-query.Incoming","../../../../../../../../bendvy/src/ecs/relation-query.Missing","../../../../../../../../bendvy/src/ecs/relation-query.Target","../../../../../../../../bendvy/src/ecs/relation-query.Sources","Nil","Con","../../../../../../../../bendvy/src/ecs/world.Handle","None","Some","physical.View","physical.WorldView","../../../../../../../../bendvy/src/ecs/relation-types.Graph","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-types.Edge","../../../../../../../../bendvy/src/ecs/relation-types.Descriptor","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-types.Inverse","Nil","Con","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-commands.Original","../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed","../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved","../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused","../../../../../../../../bendvy/src/ecs/event-publication.Publication","Nil","Con","../../../../../../../../bendvy/src/ecs/event-publication.Publication","Nil","Con","state.FirstEvent","Nil","Con","state.SecondEvent","False","True","Nil","Con","state.UnusedEvent","../../../../../../../../bendvy/src/ecs/relation-types.Failure","../../../../../../../../bendvy/src/ecs/relation-types.Relate","../../../../../../../../bendvy/src/ecs/relation-types.ReorderChildren","../../../../../../../../bendvy/src/ecs/relation-types.MissingEntity","../../../../../../../../bendvy/src/ecs/relation-types.MissingTargetEntity","../../../../../../../../bendvy/src/ecs/relation-types.SelfRelationNotAllowed","../../../../../../../../bendvy/src/ecs/relation-types.HierarchyCycle","../../../../../../../../bendvy/src/ecs/relation-types.MissingChildEntity","../../../../../../../../bendvy/src/ecs/relation-types.DuplicateChild","../../../../../../../../bendvy/src/ecs/relation-types.ChildNotRelatedToParent","../../../../../../../../bendvy/src/ecs/relation-types.ChildSetMismatch","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-types.CleanupEnter","../../../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors","../../../../../../../../bendvy/src/ecs/relation-types.CleanupChildren","../../../../../../../../bendvy/src/ecs/relation-types.CleanupFinish","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-types.Descriptor","Nil","Con","../../../../../../../../bendvy/src/ecs/world.RegistrationMeta","../../../../../../../../bendvy/src/ecs/event-stream.Stream","../../../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain","Nil","Con","../../../../../../../../bendvy/src/ecs/event-runtime.Batch","Nil","Con","../../../../../../../../bendvy/src/ecs/event-runtime.Position","../../../../../../../../bendvy/src/ecs/event-stream.Stream","../../../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain","Nil","Con","../../../../../../../../bendvy/src/ecs/event-runtime.Batch","../../../../../../../../bendvy/src/ecs/event-stream.Stream","../../../../../../../../bendvy/src/ecs/ordinary-event-declaration.Domain","Nil","Con","../../../../../../../../bendvy/src/ecs/event-runtime.Batch","Nil","Con","../../../../../../../../bendvy/src/ecs/event-runtime.Batch","Nil","Con","../../../../../../../../bendvy/src/ecs/event-publication.Publication","Nil","Con","../../../../../../../../bendvy/src/ecs/event-notice-runtime.Failures","Nil","Con","../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.Domain","../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.DeclaredKey","../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Queue","Nil","Con","../../../../../../../../bendvy/src/ecs/internal/relation-failures/queue.Batch","Nil","Con","../../../../../../../../bendvy/src/ecs/relation-commands.Original","../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed","../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved","../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused","consumer.ReaderView","Nil","Con","../../../../../../../../bendvy/src/ecs/internal/relation-failures/domains.DeclaredKey","Nil","Con","Nil","Con","../../../../../../../../bendvy/src/ecs/internal/relation-failures/readings.KeyReading"]]);