function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $consumer$058main$();
}

function $consumer$058main$() {
  return $consumer$058created$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($consumer$058resources$()))));
}

function $consumer$058created$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/world.CreateRejected") {
    return {$: "Con", "head": "create-rejected", "tail": {$: "Nil"}};
  } else {
    const _factory_1 = _value_0["factory"];
    const _world_0 = _value_0["world"];
    return $consumer$058installed$(_factory_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058install$1260$(($consumer$058setup$()), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $consumer$058barrier$(_x_0);
}))), "service-call")));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $consumer$058resources$() {
  return {$: "consumer.Resources", "active": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": array_node([11], [12])}, "unused": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": array_node([21], [22])}, "held": {$: "None"}, "sibling": array_node([91], [92]), "barriers": 0};
}

function $consumer$058installed$(_factory_0, _value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-service.InstallRejected") {
    return {$: "Con", "head": "install-rejected", "tail": {$: "Nil"}};
  } else {
    const _app_0 = _value_0["app"];
    return $consumer$058stage0$(_factory_0, {$: "Nil"}, _app_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058install$1260$(_setup_0, _world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058registered$1260$(_setup_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1260$(($consumer$058active$()))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058define$1260$(_world_0, _name_0)));
}

function $consumer$058setup$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058append$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1260$()), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1261$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $consumer$058barrier$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _active_0 = _t_0["active"];
  const _unused_0 = _t_0["unused"];
  const _held_0 = _t_0["held"];
  const _sibling_0 = _t_0["sibling"];
  const _barriers_0 = _t_0["barriers"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "consumer.Resources", "active": _active_0, "unused": _unused_0, "held": _held_0, "sibling": _sibling_0, "barriers": ((_barriers_0 + 1) >>> 0)}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($consumer$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $consumer$058stage0$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage1_captured$(_factory_0, _log_0, ($consumer$058capture$("disabled", _app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058registered$1260$(_setup_0, _requirement_0, _result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.InstallRejected", "world": _world_0, "setup": _setup_0, "owner": {$: "None"}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058planned$1260$(_setup_0, _world_1, {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _ns_0, _id_0, {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Sequence", "left": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../../bendvy/src/ecs/schedule.Barrier"}, "requirements": {$: "Nil"}}, "right": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../../bendvy/src/ecs/schedule.System", "id": _id_0, "condition": 0}, "requirements": {$: "Con", "head": _requirement_0, "tail": {$: "Nil"}}}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058requirement$1260$(_value_0) {
  const _id_0 = _value_0["id"];
  return {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Service", "id": _id_0};
}

function $consumer$058active$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1260$(1, "Clock");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058define$1260$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1260$(($consumer$058active$()))), "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058append$1260$(_a_0, _b_0) {
  const _a_1 = _a_0["entries"];
  const _b_1 = _b_0["entries"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Setup", "entries": ($List$append$(_a_1, _b_1))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1260$() {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Setup", "entries": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1260$(($consumer$058active$()))), "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058single$1261$() {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Setup", "entries": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1261$(($consumer$058unused$()))), "tail": {$: "Nil"}}};
}

function $consumer$058empty$(__0) {
  return {$: "Unit"};
}

function $consumer$058stage1_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage1$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058capture$(_label_0, _app_0) {
  return $consumer$058captured$(_label_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058snapshot$1260$(_app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058planned$1260$(_setup_0, _world_0, _owner_0, _ns_0, _id_0, _plan_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058built$1260$(_setup_0, _plan_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1260$(_ns_0, "service-schedule", _plan_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}}, _owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1260$(_id_0, _key_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Declaration", "id": _id_0, "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058key$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return {$: "../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../bendvy/src/ecs/schema-fragments.Service"}, "key": _key_0, "name": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058entry$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  return {$: "../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../bendvy/src/ecs/schema-fragments.Service"}, "key": _key_0, "name": _key_0};
}

function $consumer$058unused$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1261$(2, "Unused");
}

function $consumer$058stage1$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage2_captured$(_factory_0, _log_0, ($consumer$058capture$("enabled", ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058enabled$1260$(_app_0, true)))));
}

function $consumer$058captured$(_label_0, _value_0) {
  const _t_0 = _value_0["fst"];
  const _setup_0 = _t_0["setup"];
  const _plan_0 = _t_0["plan"];
  const _scheduled_0 = _t_0["scheduled"];
  const _world_0 = _t_0["world"];
  const _flag_0 = _t_0["debug"];
  const _view_0 = _value_0["snd"];
  return $consumer$058checkpoint_restored$(_label_0, _view_0, _setup_0, _plan_0, _flag_0, _scheduled_0, ($consumer$058physical$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058snapshot$1260$(_app_0) {
  const _setup_0 = _app_0["setup"];
  const _plan_0 = _app_0["plan"];
  const _scheduled_0 = _app_0["scheduled"];
  const _world_0 = _app_0["world"];
  const _t_0 = _app_0["debug"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": _scheduled_0, "world": _world_0, "debug": false}, "snd": {$: "None"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058described$1260$(_setup_0, _plan_0, _scheduled_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_pair$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058built$1260$(_setup_0, _plan_0, _world_0, _result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Invalid") {
    const _owner_0 = _result_0["owners"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.InstallRejected", "world": _world_0, "setup": _setup_0, "owner": {$: "Some", "value": _owner_0}};
  } else {
    const _scheduled_0 = _result_0["schedule"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Installed", "app": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": _scheduled_0, "world": _world_0, "debug": false}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0)), _catalog_0, _owners_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058declare$1261$(_id_0, _key_0) {
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Declaration", "id": _id_0, "key": _key_0};
}

function $consumer$058stage2_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage2$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058enabled$1260$(_app_0, _flag_0) {
  const _setup_0 = _app_0["setup"];
  const _plan_0 = _app_0["plan"];
  const _scheduled_0 = _app_0["scheduled"];
  const _world_0 = _app_0["world"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": _scheduled_0, "world": _world_0, "debug": _flag_0};
}

function $consumer$058checkpoint_restored$(_label_0, _view_0, _setup_0, _plan_0, _flag_0, _scheduled_0, _value_0) {
  const _t_0 = _scheduled_0["schedule"];
  const _ns_0 = _t_0["namespace"];
  const _name_0 = _t_0["name"];
  const _steps_0 = _t_0["steps"];
  const _t_1 = _t_0["owners"];
  const _registryNs_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _registryName_0 = _t_1["name"];
  const _access_0 = _t_1["access"];
  const _cursor_0 = _t_1["cursor"];
  const _needs_0 = _scheduled_0["requirements"];
  const _world_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  const _x_0 = ($Bool$show$(_flag_0));
  const _x_1 = ("}|" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($List$show$1266$(_needs_0));
  const _x_4 = (";debug=" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = ($List$show$1268$(_steps_0));
  const _x_7 = (";needs=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_cursor_0));
  const _x_10 = (";steps=" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($List$show$1267$(_access_0));
  const _x_13 = (":" + _x_11);
  const _x_14 = (_x_12 + _x_13);
  const _x_15 = (":" + _x_14);
  const _x_16 = (_registryName_0 + _x_15);
  const _x_17 = ($U32$show$(_id_0));
  const _x_18 = (":" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($U32$show$(_registryNs_0));
  const _x_21 = (":" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = (";registry=" + _x_22);
  const _x_24 = (_name_0 + _x_23);
  const _x_25 = ($U32$show$(_ns_0));
  const _x_26 = (":" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058text$1260$(_view_0));
  const _x_29 = ("|scheduled{" + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ("|" + _x_30);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _ns_0, "name": _name_0, "steps": _steps_0, "owners": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _registryNs_0, "id": _id_0, "name": _registryName_0, "access": _access_0, "cursor": _cursor_0}}, "requirements": _needs_0}, "world": _world_0, "debug": _flag_0}, "snd": (_label_0 + _x_31)};
}

function $consumer$058physical$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _queue_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $consumer$058world_join$(_ns_0, _next_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _system_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_live_0)), ($consumer$058resource_text$(_resource_0)), ($consumer$058pending$(_queue_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058described$1260$(_setup_0, _plan_0, _scheduled_0, _observed_0) {
  const _entries_0 = _setup_0["entries"];
  const _t_0 = _scheduled_0["schedule"];
  const _ns_0 = _t_0["namespace"];
  const _scheduleName_0 = _t_0["name"];
  const _steps_0 = _t_0["steps"];
  const _t_1 = _t_0["owners"];
  const _registryNs_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _name_0 = _t_1["name"];
  const _access_0 = _t_1["access"];
  const _cursor_0 = _t_1["cursor"];
  const _needs_0 = _scheduled_0["requirements"];
  const _world_0 = _observed_0["fst"];
  const _statuses_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Setup", "entries": _entries_0}, "plan": _plan_0, "scheduled": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _ns_0, "name": _scheduleName_0, "steps": _steps_0, "owners": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _registryNs_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "requirements": _needs_0}, "world": _world_0, "debug": true}, "snd": {$: "Some", "value": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Inventory", "entries": _entries_0, "services": _statuses_0, "required": _needs_0, "namespace": _registryNs_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0, "steps": _steps_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_pair$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_next$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1261$(($consumer$058active$()), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1260$(_built_0, _needs_0) {
  if (_built_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Built", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $consumer$058stage2$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage3_captured$(_factory_0, _log_0, ($consumer$058capture$("repeat", _app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058text$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "debug=None";
  } else {
    const _t_0 = _value_0["value"];
    const _entries_0 = _t_0["entries"];
    const _statuses_0 = _t_0["services"];
    const _required_0 = _t_0["required"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    const _steps_0 = _t_0["steps"];
    const _x_0 = ($List$show$1268$(_steps_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = (";steps=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($List$show$1267$(_access_0));
    const _x_6 = (":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = (":" + _x_7);
    const _x_9 = (_name_0 + _x_8);
    const _x_10 = ($U32$show$(_id_0));
    const _x_11 = (":" + _x_9);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_ns_0));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    const _x_16 = ($List$show$1266$(_required_0));
    const _x_17 = (";registry=" + _x_15);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($List$show$1265$(_statuses_0));
    const _x_20 = (";required=" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    const _x_22 = ($List$show$1264$(_entries_0));
    const _x_23 = (";services=" + _x_21);
    const _x_24 = (_x_22 + _x_23);
    return ("debug{entries=" + _x_24);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1267$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058step_text$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058requirement_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $consumer$058world_join$(_ns_0, _next_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _system_0, _clock_0, _live_0, _resource_0, _queue_0) {
  const _live_1 = _live_0["fst"];
  const _l_0 = _live_0["snd"];
  const _resource_1 = _resource_0["fst"];
  const _r_0 = _resource_0["snd"];
  const _queue_1 = _queue_0["fst"];
  const _n_0 = _queue_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_system_0));
  const _x_3 = (";clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1263$(_regs_0));
  const _x_6 = (";nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_n_0));
  const _x_9 = (";registrations=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1262$(_events_0));
  const _x_12 = (";pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (";events=" + _x_13);
  const _x_15 = (_r_0 + _x_14);
  const _x_16 = ($Nat$show$(_depth_0));
  const _x_17 = (";store=Unit;" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_cap_0));
  const _x_20 = (";depth=" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = (";capacity=" + _x_21);
  const _x_23 = (_l_0 + _x_22);
  const _x_24 = ($U32$show$(_high_0));
  const _x_25 = (";live=" + _x_23);
  const _x_26 = (_x_24 + _x_25);
  const _x_27 = ($U32$show$(_next_0));
  const _x_28 = (";high=" + _x_26);
  const _x_29 = (_x_27 + _x_28);
  const _x_30 = ($U32$show$(_ns_0));
  const _x_31 = (";next=" + _x_29);
  const _x_32 = (_x_30 + _x_31);
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_1, "capacity": _cap_0, "depth": _depth_0, "store": {$: "Unit"}, "resource": _resource_1, "events": _events_0, "pending": _queue_1, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": ("world{" + _x_32)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_array$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_value_0);
}

function $consumer$058resource_text$(_value_0) {
  const _a_0 = _value_0["active"];
  const _b_0 = _value_0["unused"];
  const _h_0 = _value_0["held"];
  const _s_0 = _value_0["sibling"];
  const _n_0 = _value_0["barriers"];
  return $consumer$058resource_join$(($consumer$058slot_text$(_a_0)), ($consumer$058slot_text$(_b_0)), ($consumer$058held_text$(_h_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_s_0)), _n_0);
}

function $consumer$058pending$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $consumer$058pending_join$(_head_0, ($consumer$058pending$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_next$1260$(_value_0) {
  const _world_0 = _value_0["fst"];
  const _statuses_0 = _value_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_join$1260$(_statuses_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1260$(($consumer$058unused$()), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1261$(_declaration_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1260$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1261$(_declaration_0, ($consumer$058active_take$(_resource_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/schedule.Built", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_seen_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $consumer$058stage3_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage3$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058entry_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058status_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1267$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058step_text$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Barrier") {
    return "barrier";
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Phase") {
    const _name_0 = _value_0["name"];
    return ("phase:" + _name_0);
  } else {
    const _id_0 = _value_0["id"];
    const _condition_0 = _value_0["condition"];
    const _x_0 = ($U32$show$(_condition_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("system:" + _x_3);
  }
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058step_text$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058requirement_text$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Service") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("service:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Component") {
    const _id_1 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("component:" + _x_1);
  } else {
    const _id_2 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_2));
    return ("resource:" + _x_2);
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058requirement_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058registration$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_value$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1261$(_right_0)));
  }
}

function $consumer$058resource_join$(_a_0, _b_0, _h_0, _s_0, _barriers_0) {
  const _a_1 = _a_0["fst"];
  const _x_0 = _a_0["snd"];
  const _b_1 = _b_0["fst"];
  const _y_0 = _b_0["snd"];
  const _h_1 = _h_0["fst"];
  const _z_0 = _h_0["snd"];
  const _s_1 = _s_0["fst"];
  const _t_0 = _s_0["snd"];
  const _x_1 = ($U32$show$(_barriers_0));
  const _x_2 = (_x_1 + "}");
  const _x_3 = (";barriers=" + _x_2);
  const _x_4 = (_t_0 + _x_3);
  const _x_5 = (";sibling=" + _x_4);
  const _x_6 = (_z_0 + _x_5);
  const _x_7 = (";held=" + _x_6);
  const _x_8 = (_y_0 + _x_7);
  const _x_9 = (";unused=" + _x_8);
  const _x_10 = (_x_0 + _x_9);
  return {$: "Tuple", "fst": {$: "consumer.Resources", "active": _a_1, "unused": _b_1, "held": _h_1, "sibling": _s_1, "barriers": _barriers_0}, "snd": ("resources{active=" + _x_10)};
}

function $consumer$058slot_text$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"}, "snd": "Missing"};
  } else {
    const _owner_0 = _value_0["owner"];
    return $consumer$058slot_restored$(($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owner_0)));
  }
}

function $consumer$058held_text$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "None"};
  } else {
    const _owner_0 = _value_0["value"];
    return $consumer$058held_restored$(($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_array$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_value_0);
}

function $consumer$058pending_join$(_head_0, _value_0) {
  const _rest_0 = _value_0["fst"];
  const _n_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_n_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_join$1260$(_first_0, _second_0) {
  const _world_0 = _second_0["fst"];
  const _statuses_0 = _second_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($List$append$(_first_0, _statuses_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_observed$1260$(_declaration_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1260$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1260$(_declaration_0, ($consumer$058unused_take$(_resource_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058world_restored$1260$(_ns_0, _next_0, _high_0, _live_0, _cap_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, _value_0) {
  const _resource_0 = _value_0["fst"];
  const _status_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "Con", "head": _status_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1261$(_declaration_0, _value_0) {
  const _id_0 = _declaration_0["id"];
  const _key_0 = _declaration_0["key"];
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": ($consumer$058active_put$(_rest_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"})), "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": false}};
  } else {
    const _owner_0 = _t_0["owner"];
    return {$: "Tuple", "fst": ($consumer$058active_put$(_rest_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0})), "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": true}};
  }
}

function $consumer$058active_take$(_value_0) {
  const _active_0 = _value_0["active"];
  const _unused_0 = _value_0["unused"];
  const _held_0 = _value_0["held"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "consumer.ActiveRest", "unused": _unused_0, "held": _held_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _active_0};
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1260$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1260$(_head_0, _item_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $consumer$058stage3$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage4_captured$(_factory_0, _log_0, ($consumer$058run_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058run$1260$(_app_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058entry_text$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schema-fragments.Entry") {
    const _t_0 = _value_0["kind"];
    if (_t_0.$ === "../../../../../../../bendvy/src/ecs/schema-fragments.Service") {
      const _key_0 = _value_0["key"];
      const _name_0 = _value_0["name"];
      const _x_0 = (_name_0 + ")");
      const _x_1 = ("," + _x_0);
      const _x_2 = (_key_0 + _x_1);
      return ("Service(" + _x_2);
    } else {
      return "nonservice";
    }
  } else {
    return "nonservice";
  }
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058entry_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058status_text$1260$(_value_0) {
  const _id_0 = _value_0["id"];
  const _key_0 = _value_0["key"];
  const _provided_0 = _value_0["provided"];
  const _x_0 = ($Bool$show$(_provided_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_key_0 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = ("," + _x_3);
  const _x_6 = (_x_4 + _x_5);
  return ("service(" + _x_6);
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058status_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058registration$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1261$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_value$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_data$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1261$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $consumer$058slot_restored$(_value_0) {
  const _owner_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0}, "snd": ("Ready(" + _x_0)};
}

function $consumer$058held_restored$(_value_0) {
  const _owner_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": ("Some(" + _x_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_value$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058array$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_observed$1260$(_declaration_0, _value_0) {
  const _id_0 = _declaration_0["id"];
  const _key_0 = _declaration_0["key"];
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return {$: "Tuple", "fst": ($consumer$058unused_put$(_rest_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"})), "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": false}};
  } else {
    const _owner_0 = _t_0["owner"];
    return {$: "Tuple", "fst": ($consumer$058unused_put$(_rest_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0})), "snd": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Status", "id": _id_0, "key": _key_0, "provided": true}};
  }
}

function $consumer$058unused_take$(_value_0) {
  const _active_0 = _value_0["active"];
  const _unused_0 = _value_0["unused"];
  const _held_0 = _value_0["held"];
  const _sibling_0 = _value_0["sibling"];
  const _barriers_0 = _value_0["barriers"];
  return {$: "Tuple", "fst": {$: "consumer.UnusedRest", "active": _active_0, "held": _held_0, "sibling": _sibling_0, "barriers": _barriers_0}, "snd": _unused_0};
}

function $consumer$058active_put$(_rest_0, _active_0) {
  const _unused_0 = _rest_0["unused"];
  const _held_0 = _rest_0["held"];
  const _sibling_0 = _rest_0["sibling"];
  const _barriers_0 = _rest_0["barriers"];
  return {$: "consumer.Resources", "active": _active_0, "unused": _unused_0, "held": _held_0, "sibling": _sibling_0, "barriers": _barriers_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1260$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

function $consumer$058stage4_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage4$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058run_returned$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-service.Finished") {
    const _app_0 = _value_0["app"];
    const _observations_0 = _value_0["observations"];
    const _x_0 = ($List$show$1269$(_observations_0));
    return {$: "Tuple", "fst": _app_0, "snd": ("Finished:" + _x_0)};
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-service.Failed") {
    const _app_1 = _value_0["app"];
    const _observations_1 = _value_0["observations"];
    const _x_1 = ($List$show$1269$(_observations_1));
    return {$: "Tuple", "fst": _app_1, "snd": ("Failed:" + _x_1)};
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-app-service.Rejected") {
    const _app_2 = _value_0["app"];
    return {$: "Tuple", "fst": _app_2, "snd": "Rejected"};
  } else {
    const _app_3 = _value_0["app"];
    const _missing_0 = _value_0["missing"];
    const _x_2 = ($List$show$1266$(_missing_0));
    return {$: "Tuple", "fst": _app_3, "snd": ("Missing:" + _x_2)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058run$1260$(_app_0) {
  const _setup_0 = _app_0["setup"];
  const _plan_0 = _app_0["plan"];
  const _scheduled_0 = _app_0["scheduled"];
  const _world_0 = _app_0["world"];
  const _debug_0 = _app_0["debug"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058provisioned$1260$(_setup_0, _plan_0, _debug_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run$1260$(_scheduled_0, _world_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1261$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058bool_data$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058leaf$1260$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_value$(_value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_data$(_value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058node_join$1260$(_leftObserved_0, _rightObserved_0) {
  const _left_0 = _leftObserved_0["fst"];
  const _text_0 = _leftObserved_0["snd"];
  const _right_0 = _rightObserved_0["fst"];
  const _other_0 = _rightObserved_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("node(" + _x_2)};
}

function $consumer$058unused_put$(_rest_0, _unused_0) {
  const _active_0 = _rest_0["active"];
  const _held_0 = _rest_0["held"];
  const _sibling_0 = _rest_0["sibling"];
  const _barriers_0 = _rest_0["barriers"];
  return {$: "consumer.Resources", "active": _active_0, "unused": _unused_0, "held": _held_0, "sibling": _sibling_0, "barriers": _barriers_0};
}

function $consumer$058stage4$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage5_captured$(_factory_0, _log_0, ($consumer$058capture$("after-run", _app_0)));
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058observation$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058provisioned$1260$(_setup_0, _plan_0, _debug_0, _value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule-provision.Missing") {
    const _scheduled_0 = _value_0["schedule"];
    const _world_0 = _value_0["world"];
    const _missing_0 = _value_0["missing"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Missing", "app": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": _scheduled_0, "world": _world_0, "debug": _debug_0}, "missing": _missing_0};
  } else {
    const _value_1 = _value_0["result"];
    const _needs_0 = _value_0["requirements"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058executed$1260$(_setup_0, _plan_0, _debug_0, _needs_0, _value_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run$1260$(_schedule_0, _world_0) {
  const _schedule_1 = _schedule_0["schedule"];
  const _needs_0 = _schedule_0["requirements"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_available$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provision$1260$(_world_0)), _schedule_1, _needs_0);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1261$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045schedule$045debug$045v1$047experiments$047public$045inspect$047ordinary$045declaration$045v1$047compact$045schedule$045recipe$045v1$047ordinary$045schema$045debug$045v1$047refusal$045preservation$045v1$047public$045successor$047consumer$047owner$045observer$058u32_data$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $consumer$058stage5_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage5$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058observation$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Entered") {
    const _name_0 = _value_0["name"];
    return ("Entered:" + _name_0);
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Ran") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("Ran:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Skipped") {
    const _id_1 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("Skipped:" + _x_1);
  } else {
    return "Applied";
  }
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058observation$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058executed$1260$(_setup_0, _plan_0, _debug_0, _needs_0, _value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Finished") {
    const _schedule_0 = _value_0["schedule"];
    const _world_0 = _value_0["world"];
    const _observations_0 = _value_0["observations"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Finished", "app": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "debug": _debug_0}, "observations": _observations_0};
  } else if (_value_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Failed") {
    const _schedule_1 = _value_0["schedule"];
    const _world_1 = _value_0["world"];
    const _error_0 = _value_0["error"];
    const _observations_1 = _value_0["observations"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Failed", "app": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_1, "requirements": _needs_0}, "world": _world_1, "debug": _debug_0}, "error": _error_0, "observations": _observations_1};
  } else {
    const _schedule_2 = _value_0["schedule"];
    const _world_2 = _value_0["world"];
    return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Rejected", "app": {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_2, "requirements": _needs_0}, "world": _world_2, "debug": _debug_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_available$1260$(_observed_0, _schedule_0, _needs_0) {
  const _world_0 = _observed_0["fst"];
  const _available_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0)), _schedule_0, _world_0, _needs_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provision$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provisioned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058scan_pair$1260$(_world_0)));
}

function $consumer$058stage5$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage6_captured$(_factory_0, _log_0, ($consumer$058capture$("missing-before", ($consumer$058remove$(_app_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058run_checked$1260$(_missing_0, _schedule_0, _world_0, _needs_0) {
  if (_missing_0.$ === "Con") {
    const _first_0 = _missing_0["head"];
    const _rest_0 = _missing_0["tail"];
    return {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Missing", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "missing": {$: "Con", "head": _first_0, "tail": _rest_0}};
  } else {
    return {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Executed", "result": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0)), "requirements": _needs_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_next$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_available_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_rest_0, _available_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058provisioned$1260$(_value_0) {
  const _world_0 = _value_0["fst"];
  const _statuses_0 = _value_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1260$(_statuses_0))};
}

function $consumer$058stage6_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage6$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058remove$(_app_0) {
  const _setup_0 = _app_0["setup"];
  const _plan_0 = _app_0["plan"];
  const _scheduled_0 = _app_0["scheduled"];
  const _world_0 = _app_0["world"];
  const _flag_0 = _app_0["debug"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": _scheduled_0, "world": ($consumer$058remove_world$(_world_0)), "debug": _flag_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058missing_next$1260$(_present_0, _item_0, _next_0) {
  if (!_present_0) {
    return {$: "Con", "head": _item_0, "tail": _next_0};
  } else {
    return _next_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1260$(_statuses_0) {
  if (_statuses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _statuses_0["head"];
    const _id_0 = _t_0["id"];
    const _provided_0 = _t_0["provided"];
    const _rest_0 = _statuses_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available_next$1260$(_provided_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available$1260$(_rest_0)));
  }
}

function $consumer$058stage6$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage7_captured$(_factory_0, _log_0, ($consumer$058run_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058run$1260$(_app_0)))));
}

function $consumer$058remove_world$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$({$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": ($consumer$058remove_resource$(_resource_0)), "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, run_clo((_x_0) => {
  return $consumer$058barrier$(_x_0);
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058available_next$1260$(_provided_0, _id_0, _rest_0) {
  if (!_provided_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/schedule-provision.Service", "id": _id_0}, "tail": _rest_0};
  }
}

function $consumer$058stage7_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage7$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058remove_resource$(_value_0) {
  const _t_0 = _value_0["active"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready") {
    const _owner_0 = _t_0["owner"];
    const _unused_0 = _value_0["unused"];
    const _t_1 = _value_0["held"];
    if (_t_1.$ === "None") {
      const _sibling_0 = _value_0["sibling"];
      const _barriers_0 = _value_0["barriers"];
      return {$: "consumer.Resources", "active": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"}, "unused": _unused_0, "held": {$: "Some", "value": _owner_0}, "sibling": _sibling_0, "barriers": _barriers_0};
    } else {
      const _sibling_1 = _value_0["sibling"];
      const _barriers_1 = _value_0["barriers"];
      return {$: "consumer.Resources", "active": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0}, "unused": _unused_0, "held": _t_1, "sibling": _sibling_1, "barriers": _barriers_1};
    }
  } else {
    const _unused_1 = _value_0["unused"];
    const _13_0 = _value_0["held"];
    const _sibling_2 = _value_0["sibling"];
    const _barriers_2 = _value_0["barriers"];
    return {$: "consumer.Resources", "active": _t_0, "unused": _unused_1, "held": _13_0, "sibling": _sibling_2, "barriers": _barriers_2};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $consumer$058stage7$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage8_captured$(_factory_0, _log_0, ($consumer$058capture$("missing-after", _app_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $consumer$058stage8_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage8$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../../../bendvy/src/ecs/schedule.Finished", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058condition$1260$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $consumer$058stage8$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage9_captured$(_factory_0, _log_0, ($consumer$058run_returned$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058run$1260$(($consumer$058restore$(_app_0)))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058condition$1260$(_world_0, __0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $consumer$058stage9_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage9$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058restore$(_app_0) {
  const _setup_0 = _app_0["setup"];
  const _plan_0 = _app_0["plan"];
  const _scheduled_0 = _app_0["scheduled"];
  const _world_0 = _app_0["world"];
  const _flag_0 = _app_0["debug"];
  return {$: "../../../../../../../bendvy/src/ecs/ordinary-app-service.Application", "setup": _setup_0, "plan": _plan_0, "scheduled": _scheduled_0, "world": ($consumer$058restore_world$(_world_0)), "debug": _flag_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058dispatch$1260$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $consumer$058stage9$(_factory_0, _log_0, _app_0) {
  return $consumer$058stage10_captured$(_factory_0, _log_0, ($consumer$058capture$("after-retry", _app_0)));
}

function $consumer$058restore_world$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": ($consumer$058restore_resource$(_resource_0)), "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058dispatch$1260$(_owner_0, _world_0, __0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058dispatched$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_owner_0, _world_0, {$: "Unit"})));
}

function $consumer$058stage10_captured$(_factory_0, _log_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return $consumer$058stage10$(_factory_0, ($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), _app_0);
}

function $consumer$058restore_resource$(_value_0) {
  const _t_0 = _value_0["active"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    const _unused_0 = _value_0["unused"];
    const _t_1 = _value_0["held"];
    if (_t_1.$ === "Some") {
      const _owner_0 = _t_1["value"];
      const _sibling_0 = _value_0["sibling"];
      const _barriers_0 = _value_0["barriers"];
      return {$: "consumer.Resources", "active": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": _owner_0}, "unused": _unused_0, "held": {$: "None"}, "sibling": _sibling_0, "barriers": _barriers_0};
    } else {
      const _sibling_1 = _value_0["sibling"];
      const _barriers_1 = _value_0["barriers"];
      return {$: "consumer.Resources", "active": {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"}, "unused": _unused_0, "held": _t_1, "sibling": _sibling_1, "barriers": _barriers_1};
    }
  } else {
    const _unused_1 = _value_0["unused"];
    const _13_0 = _value_0["held"];
    const _sibling_2 = _value_0["sibling"];
    const _barriers_2 = _value_0["barriers"];
    return {$: "consumer.Resources", "active": _t_0, "unused": _unused_1, "held": _13_0, "sibling": _sibling_2, "barriers": _barriers_2};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/schedule.Failed", "schedule": {$: "../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058dispatched$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../bendvy/src/ecs/system.Completed") {
    const _owner_0 = _value_0["registry"];
    const _outcome_0 = _value_0["outcome"];
    return {$: "Tuple", "fst": _owner_0, "snd": _outcome_0};
  } else {
    const _owner_1 = _value_0["registry"];
    const _world_0 = _value_0["world"];
    return {$: "Tuple", "fst": _owner_1, "snd": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "Unit"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $consumer$058stage10$(_factory_0, _log_0, _app_0) {
  return $consumer$058finished$(_factory_0, _log_0, ($consumer$058capture$("disabled-final", ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045service$058enabled$1260$(_app_0, false)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $consumer$058finished$(_factory_0, _log_0, _value_0) {
  const _next_0 = _factory_0["nextNamespace"];
  const _text_0 = _value_0["snd"];
  const _x_0 = ($U32$show$(_next_0));
  return $List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Con", "head": ("factory=" + _x_0), "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058runner$1260$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../bendvy/src/ecs/system.Succeeded", "world": {$: "../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_called$1260$(($consumer$058active_take$(_resource_0)))), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045service$045declaration$058slot_called$1260$(_value_0) {
  const _rest_0 = _value_0["fst"];
  const _t_0 = _value_0["snd"];
  if (_t_0.$ === "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing") {
    return $consumer$058active_put$(_rest_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Missing"});
  } else {
    const _owner_0 = _t_0["owner"];
    return $consumer$058active_put$(_rest_0, {$: "../../../../../../../bendvy/src/ecs/ordinary-service-declaration.Ready", "owner": ($consumer$058call$(_owner_0))});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $consumer$058call$(_owner_0) {
  return $consumer$058called$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $consumer$058called$(_value_0) {
  const _owner_0 = _value_0["fst"];
  const _n_0 = _value_0["snd"];
  const _x_0 = ((_n_0 + 1) >>> 0);
  return (_owner_0[0 % _owner_0.length] = _x_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,1,2,0,0,0,1,1,0,2,1,0,15,1,0,4],["Nil","Con"]]);