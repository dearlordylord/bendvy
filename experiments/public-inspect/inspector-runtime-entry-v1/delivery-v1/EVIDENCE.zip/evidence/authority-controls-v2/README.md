# Current runtime-entry authority controls

This v2 slice changes only the explicit IR import in v1's six Bend sources to the qualified ordinary-input-v2 entry stage. `SOURCE-JOIN.json` binds both source versions, the stage module and the exact reversible import mapping. V1 remains unchanged.

The positive check typechecks canonical `I.read_resource` through the owner-restoring lift and actual `IR.run` call, with generic component/resource owners of arbitrary `Type` and a concrete pair of separate `Array<U32>` owners. Four negative checks reject a same-U32 concrete undeclared grant under opaque H, a Garden instance at a Workshop run, ValueRead supplied as ValueWrite, and recovery of opaque H as the concrete runtime. Full intended diagnostics, exact closure and checker/tool hashes are retained in `CHECKS.json` and `checks/`.

All five commands used the existing pinned development wrapper on CPU3 with its unchanged 5-second cap. The positive exited 0; each negative exited 1 for its intended mismatch. These checks execute no backend or ECS consumer and establish no universal proof or runtime owner-preservation/foreign-world claim. Trusted closed capability factories remain outside the opaque-body confinement boundary. No laws, contracts, runner or dependency were added.
