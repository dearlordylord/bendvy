# inspector-runtime-entry-v1 independent oracle

This leaf contains a source-derived complete stdout oracle for the frozen
ordinary runtime-entry consumer. `main.bend` creates two nominal SchemaA
worlds and two nominal SchemaB worlds. Each pair has a primary and foreign
handle with the same local id but different host namespaces. The event reader
is registered and warmed before the four Inspector calls, remains live through
the calls, and is run once afterward.

`expected.stdout` is the complete UTF-8 output for both `IO.print` calls,
including the explicit newline in `main.finish` and the additional newline
appended by `Base.IO.print`. `expected.stdout.gz` is deterministic gzip with
mtime zero and original filename `expected.stdout`.

The model is independent: it reads no backend output and has no runtime-output
inputs. `SOURCE-BASIS.json` pins the 22-file Bend closure, the two namespace
sidecars, the prototype root dependency, the candidate core for provenance, and
Base. `CHECKS.json` records only deterministic source-model regeneration and
hash checks. The finite oracle does not establish TS parity, universal runtime
refinement, Native execution, compiler adoption, or performance.
