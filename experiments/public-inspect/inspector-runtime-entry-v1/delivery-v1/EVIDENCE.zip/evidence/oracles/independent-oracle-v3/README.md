# inspector-runtime-entry-v3 independent oracle

This leaf preserves `independent-oracle-v1` and `independent-oracle-v2` and
adds the source-derived batch formatter correction.  `Base.List.show` already
emits `[` and `]` (the pinned Base source, lines 2226-2240), while
`consumer.batch_text` adds literal brackets around that result.  A singleton
batch therefore renders `2:[[original:77]]`; `runtime_fields_text` then wraps
that Batch in its own outer `List.show` list.

The v2 `|final-runtime{...}` correction remains included.  The model reads no
backend output, historical stdout, or candidate output.  Expected bytes are a
finite source oracle only and make no TS parity, universal refinement,
compiler adoption, Native qualification, or performance claim.
