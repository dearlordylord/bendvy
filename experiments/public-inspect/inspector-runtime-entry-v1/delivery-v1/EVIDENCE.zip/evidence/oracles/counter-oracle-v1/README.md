# inspector-runtime-entry counter-oracle-v1

This is a source-derived finite falsification control for the frozen
`reached-clock-mutant-v1` stage.  The stage changes exactly one call in
`IR.advance_runtime`: `W.advance_clock` becomes `W.clock`; the consumer import
is rebound to that copied core and `main.bend` remains byte-identical.

The source model preserves the normal v3 formatter corrections.  Because the
mutant no longer advances the World clock after successful IR calls, Fresh and
Active-repeat return `Active(0,0)`, both successful call intervals are `0->0`,
Fresh-reject registers at `0`, and the final world clock remains `0`.  Event
runtime tick, batches, reader cursor, and formatting remain otherwise
unchanged.

No mutant backend output or historical stdout was consulted.  The normal v1,
v2, and v3 oracles remain preserved.  This artifact is a finite source-level
counterexample control and makes no backend, refinement, adoption, Native, or
performance claim.
