# inspector-runtime-entry-v2 independent oracle

This leaf preserves `independent-oracle-v1` and provides a source-derived
formatter successor for the frozen ordinary runtime-entry consumer.  The
semantic trace and all four worlds are unchanged.  The correction follows the
actual consumer formatter: `final_snapshot` appends `"|final-"` before
`runtime_fields_text`, whose own prefix is `"runtime{"`; therefore each final
suffix is `|final-runtime{...}`.

`expected.stdout` is the complete UTF-8 output for both `IO.print` calls,
including the explicit newline in `main.finish` and the additional newline
appended by `Base.IO.print`.  `expected.stdout.gz` is deterministic gzip with
mtime zero and original filename `expected.stdout`.

The model reads no backend output, historical stdout, or candidate output.
`SOURCE-BASIS.json` retains the v1 frozen source inventory and records the
formatter audit plus the preserved predecessor.  This finite source oracle
makes no TS parity, universal refinement, compiler adoption, Native
qualification, or performance claim.
