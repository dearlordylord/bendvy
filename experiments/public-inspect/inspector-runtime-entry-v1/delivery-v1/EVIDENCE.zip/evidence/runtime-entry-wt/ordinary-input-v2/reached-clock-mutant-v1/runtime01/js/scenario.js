function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// Shared across independently emitted modules in the same host JS realm.
// This registry is trusted host infrastructure, not gameplay authority.
const bendvy_namespace_slot = Symbol.for("bendvy.world.namespace.v1");
if (!Object.prototype.hasOwnProperty.call(globalThis, bendvy_namespace_slot)) {
  Object.defineProperty(globalThis, bendvy_namespace_slot, {
    value: { next: 1 }, writable: false, configurable: false, enumerable: false
  });
}
function bendvy_namespace_fresh() {
  const state = globalThis[bendvy_namespace_slot];
  if (state.next >= 0xffffffff) return 0;
  return state.next++;
}
io_eff("../../../../../../../../../../../bendvy/src/ecs/world-namespace.fresh", bendvy_namespace_fresh);

})();

(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["../../../../../../../../../../../bendvy/src/ecs/world-namespace.fresh","IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1261$(array_new(2, 77))), run_clo((_x_1) => {
  return $second$(_x_1);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1261$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058with_namespace$1261$(_x_2, _resource_0);
}), _x_0);
});
}

function $second$(_a_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1261$(array_new(2, 77))), run_clo((_x_1) => {
  return $third$(_a_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045namespace$058fresh$(_k_0) {
  return { $: "$FFI", run: $0eff["../../../../../../../../../../../bendvy/src/ecs/world-namespace.fresh"].run, need: $0eff["../../../../../../../../../../../bendvy/src/ecs/world-namespace.fresh"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058with_namespace$1261$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058convert$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $third$(_a_0, _af_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1260$(array_new(2, 77))), run_clo((_x_1) => {
  return $fourth$(_a_0, _af_0, _x_1);
}), _x_0);
});
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058convert$1261$(_created_0) {
  if (_created_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($consumer$058empty_store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1260$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058with_namespace$1260$(_x_2, _resource_0);
}), _x_0);
});
}

function $fourth$(_a_0, _af_0, _b_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1260$(array_new(2, 77))), run_clo((_x_1) => {
  return $finish$(_a_0, _af_0, _b_0, _x_1);
}), _x_0);
});
}

function $consumer$058empty_store$1261$(__0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1261$({$: "Unit"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058with_namespace$1260$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058convert$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $finish$(_a_0, _af_0, _b_0, _bf_0) {
  const _x_0 = ($consumer$058pair$1261$(_b_0, _bf_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ($consumer$058pair$1260$(_a_0, _af_0));
  const _x_3 = ("\nschema-b=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return (_x_5) => $IO$print$(("schema-a=" + _x_4), _x_5);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1261$(_components_0) {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058convert$1260$(_created_0) {
  if (_created_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($consumer$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $consumer$058pair$1260$(_primary_0, _foreign_0) {
  return $consumer$058pair_text$1260$(($consumer$058prepared$1260$(_primary_0)), ($consumer$058prepared$1260$(_foreign_0)));
}

function $consumer$058pair$1261$(_primary_0, _foreign_0) {
  return $consumer$058pair_text$1261$(($consumer$058prepared$1261$(_primary_0)), ($consumer$058prepared$1261$(_foreign_0)));
}

function $consumer$058empty_store$1260$(__0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1260$({$: "Unit"});
}

function $consumer$058pair_text$1260$(_primary_0, _foreign_0) {
  if (_primary_0.$ === "consumer.Ready") {
    const _world_0 = _primary_0["world"];
    const _handle_0 = _primary_0["handle"];
    return $consumer$058pair_foreign$1260$(_world_0, _handle_0, _foreign_0);
  } else {
    return "setup-refused";
  }
}

function $consumer$058prepared$1260$(_created_0) {
  if (_created_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world-io.Created") {
    const _world_0 = _created_0["world"];
    return $consumer$058reserved$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    return {$: "consumer.Refused"};
  }
}

function $consumer$058pair_text$1261$(_primary_0, _foreign_0) {
  if (_primary_0.$ === "consumer.Ready") {
    const _world_0 = _primary_0["world"];
    const _handle_0 = _primary_0["handle"];
    return $consumer$058pair_foreign$1261$(_world_0, _handle_0, _foreign_0);
  } else {
    return "setup-refused";
  }
}

function $consumer$058prepared$1261$(_created_0) {
  if (_created_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world-io.Created") {
    const _world_0 = _created_0["world"];
    return $consumer$058reserved$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    return {$: "consumer.Refused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058empty$1260$(_components_0) {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $consumer$058pair_foreign$1260$(_primaryWorld_0, _primaryHandle_0, _foreign_0) {
  if (_foreign_0.$ === "consumer.Ready") {
    const _world_0 = _foreign_0["world"];
    const _handle_0 = _foreign_0["handle"];
    return $consumer$058pair_ready$1260$(_primaryWorld_0, _primaryHandle_0, _world_0, _handle_0);
  } else {
    return "setup-refused";
  }
}

function $consumer$058reserved$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $consumer$058activated$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return {$: "consumer.Refused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $consumer$058pair_foreign$1261$(_primaryWorld_0, _primaryHandle_0, _foreign_0) {
  if (_foreign_0.$ === "consumer.Ready") {
    const _world_0 = _foreign_0["world"];
    const _handle_0 = _foreign_0["handle"];
    return $consumer$058pair_ready$1261$(_primaryWorld_0, _primaryHandle_0, _world_0, _handle_0);
  } else {
    return "setup-refused";
  }
}

function $consumer$058reserved$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $consumer$058activated$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return {$: "consumer.Refused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $consumer$058pair_ready$1260$(_world_0, _handle_0, _foreignWorld_0, _foreign_0) {
  return $consumer$058pair_handles$1260$(_handle_0, _foreignWorld_0, _foreign_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _foreign_0)));
}

function $consumer$058activated$1260$(_handle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.Accepted") {
    return {$: "consumer.Ready", "world": _world_0, "handle": _handle_0};
  } else {
    return {$: "consumer.Refused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $consumer$058pair_ready$1261$(_world_0, _handle_0, _foreignWorld_0, _foreign_0) {
  return $consumer$058pair_handles$1261$(_handle_0, _foreignWorld_0, _foreign_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _foreign_0)));
}

function $consumer$058activated$1261$(_handle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.Accepted") {
    return {$: "consumer.Ready", "world": _world_0, "handle": _handle_0};
  } else {
    return {$: "consumer.Refused"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $consumer$058pair_handles$1260$(_handle_0, _foreignWorld_0, _foreign_0, _checked_0) {
  const _checkedWorld_0 = _checked_0["fst"];
  const _valid_0 = _checked_0["snd"];
  return $consumer$058pair_handle_fields$1260$(_checkedWorld_0, _handle_0, _foreignWorld_0, _foreign_0, _valid_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $consumer$058pair_handles$1261$(_handle_0, _foreignWorld_0, _foreign_0, _checked_0) {
  const _checkedWorld_0 = _checked_0["fst"];
  const _valid_0 = _checked_0["snd"];
  return $consumer$058pair_handle_fields$1261$(_checkedWorld_0, _handle_0, _foreignWorld_0, _foreign_0, _valid_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $consumer$058pair_handle_fields$1260$(_world_0, _handle_0, _foreignWorld_0, _foreign_0, _valid_0) {
  const _handleNamespace_0 = _handle_0["namespace"];
  const _handleId_0 = _handle_0["id"];
  const _foreignNamespace_0 = _foreign_0["namespace"];
  const _foreignId_0 = _foreign_0["id"];
  return $consumer$058pair_identity$1260$(_world_0, _handleNamespace_0, _handleId_0, _foreignWorld_0, _foreignNamespace_0, _foreignId_0, {$: "../../../../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _foreignNamespace_0, "id": _foreignId_0}, _valid_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $consumer$058pair_handle_fields$1261$(_world_0, _handle_0, _foreignWorld_0, _foreign_0, _valid_0) {
  const _handleNamespace_0 = _handle_0["namespace"];
  const _handleId_0 = _handle_0["id"];
  const _foreignNamespace_0 = _foreign_0["namespace"];
  const _foreignId_0 = _foreign_0["id"];
  return $consumer$058pair_identity$1261$(_world_0, _handleNamespace_0, _handleId_0, _foreignWorld_0, _foreignNamespace_0, _foreignId_0, {$: "../../../../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _foreignNamespace_0, "id": _foreignId_0}, _valid_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $consumer$058pair_identity$1260$(_world_0, _handleNamespace_0, _handleId_0, _foreignWorld_0, _foreignNamespace_0, _foreignId_0, _foreign_0, _valid_0) {
  const _x_0 = ($Bool$show$(_valid_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Bool$show$((_handleNamespace_0 === _foreignNamespace_0)));
  const _x_3 = (";valid-in-primary=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Bool$show$((_handleId_0 === _foreignId_0)));
  const _x_6 = (";same-world=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_foreignId_0));
  const _x_9 = (";same-id=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($U32$show$(_foreignNamespace_0));
  const _x_12 = (":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($U32$show$(_handleId_0));
  const _x_15 = (";foreign=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($U32$show$(_handleNamespace_0));
  const _x_18 = (":" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _names_0 = ("identity{primary=" + _x_19);
  const _x_20 = ($consumer$058run_from_event$1260$(($consumer$058event_state$1260$(_world_0)), _foreign_0));
  const _x_21 = ($consumer$058clock_text$1260$(_foreignWorld_0));
  const _x_22 = ("|" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("|foreign-world=" + _x_23);
  return (_names_0 + _x_24);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $consumer$058pair_identity$1261$(_world_0, _handleNamespace_0, _handleId_0, _foreignWorld_0, _foreignNamespace_0, _foreignId_0, _foreign_0, _valid_0) {
  const _x_0 = ($Bool$show$(_valid_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Bool$show$((_handleNamespace_0 === _foreignNamespace_0)));
  const _x_3 = (";valid-in-primary=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Bool$show$((_handleId_0 === _foreignId_0)));
  const _x_6 = (";same-world=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_foreignId_0));
  const _x_9 = (";same-id=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($U32$show$(_foreignNamespace_0));
  const _x_12 = (":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($U32$show$(_handleId_0));
  const _x_15 = (";foreign=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($U32$show$(_handleNamespace_0));
  const _x_18 = (":" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _names_0 = ("identity{primary=" + _x_19);
  const _x_20 = ($consumer$058run_from_event$1261$(($consumer$058event_state$1261$(_world_0)), _foreign_0));
  const _x_21 = ($consumer$058clock_text$1261$(_foreignWorld_0));
  const _x_22 = ("|" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("|foreign-world=" + _x_23);
  return (_names_0 + _x_24);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $consumer$058clock_text$1260$(_world_0) {
  return $consumer$058clock_text_observed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $consumer$058run_from_event$1260$(_setup_0, _foreign_0) {
  if (_setup_0.$ === "consumer.ReaderReady") {
    const _runtime_0 = _setup_0["runtime"];
    const _reader_0 = _setup_0["reader"];
    const _registry_0 = _setup_0["registry"];
    const _warm_0 = _setup_0["warm"];
    return $consumer$058run_ready_calls$1260$(($consumer$058run_calls$1260$(_runtime_0, _foreign_0)), _reader_0, _registry_0, _warm_0);
  } else {
    const _runtime_1 = _setup_0["runtime"];
    const _warm_1 = _setup_0["warm"];
    return $consumer$058run_refused_calls$1260$(($consumer$058run_calls$1260$(_runtime_1, _foreign_0)), _warm_1);
  }
}

function $consumer$058event_state$1260$(_world_0) {
  return $consumer$058event_registered$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058register$1260$(($consumer$058make_runtime$1260$(_world_0)), "inspector-runtime-reader", {$: "Con", "head": "events:read", "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $consumer$058clock_text$1261$(_world_0) {
  return $consumer$058clock_text_observed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $consumer$058run_from_event$1261$(_setup_0, _foreign_0) {
  if (_setup_0.$ === "consumer.ReaderReady") {
    const _runtime_0 = _setup_0["runtime"];
    const _reader_0 = _setup_0["reader"];
    const _registry_0 = _setup_0["registry"];
    const _warm_0 = _setup_0["warm"];
    return $consumer$058run_ready_calls$1261$(($consumer$058run_calls$1261$(_runtime_0, _foreign_0)), _reader_0, _registry_0, _warm_0);
  } else {
    const _runtime_1 = _setup_0["runtime"];
    const _warm_1 = _setup_0["warm"];
    return $consumer$058run_refused_calls$1261$(($consumer$058run_calls$1261$(_runtime_1, _foreign_0)), _warm_1);
  }
}

function $consumer$058event_state$1261$(_world_0) {
  return $consumer$058event_registered$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058register$1261$(($consumer$058make_runtime$1261$(_world_0)), "inspector-runtime-reader", {$: "Con", "head": "events:read", "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $consumer$058clock_text_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $consumer$058world_fields_text$1260$(_world_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $consumer$058run_ready_calls$1260$(_calls_0, _reader_0, _registry_0, _warm_0) {
  const _runtime_0 = _calls_0["runtime"];
  const _instance_0 = _calls_0["instance"];
  const _report_0 = _calls_0["report"];
  return $consumer$058event_read_done$1260$(_report_0, ($consumer$058instance_text$1260$(_instance_0)), _warm_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, {$: "consumer.ReaderArgs"})));
}

function $consumer$058run_calls$1260$(_runtime_0, _foreign_0) {
  const _first_0 = ($consumer$058first_progress$1260$(_foreign_0, ($consumer$058runtime_clock$1260$(_runtime_0))));
  return $consumer$058completed_calls$1260$(($consumer$058fresh_reject_progress$1260$(_foreign_0, ($consumer$058third_progress$1260$(_foreign_0, ($consumer$058second_progress$1260$(_foreign_0, _first_0)))))));
}

function $consumer$058run_refused_calls$1260$(_calls_0, _warm_0) {
  const _runtime_0 = _calls_0["runtime"];
  const _instance_0 = _calls_0["instance"];
  const _report_0 = _calls_0["report"];
  return $consumer$058event_reader_refused$1260$(_runtime_0, _report_0, ($consumer$058instance_text$1260$(_instance_0)), _warm_0);
}

function $consumer$058event_registered$1260$(_registered_0) {
  if (_registered_0.$ === "../../../../../../../../../../../bendvy/src/ecs/event-runtime.RegisterFailed") {
    const _runtime_0 = _registered_0["runtime"];
    return {$: "consumer.ReaderRefused", "runtime": _runtime_0, "warm": {$: "consumer.WarmReport", "registered": false, "count": 0, "lagged": true, "succeeded": false}};
  } else {
    const _runtime_1 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    const _registry_0 = _registered_0["registry"];
    return $consumer$058event_warmed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run$1260$(_runtime_1, _reader_0, _registry_0, {$: "consumer.ReaderArgs"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058register$1260$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058make_runtime$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1260$(_world_0, 16);
}

function $consumer$058clock_text_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $consumer$058world_fields_text$1261$(_world_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $consumer$058run_ready_calls$1261$(_calls_0, _reader_0, _registry_0, _warm_0) {
  const _runtime_0 = _calls_0["runtime"];
  const _instance_0 = _calls_0["instance"];
  const _report_0 = _calls_0["report"];
  return $consumer$058event_read_done$1261$(_report_0, ($consumer$058instance_text$1261$(_instance_0)), _warm_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run$1261$(_runtime_0, _reader_0, _registry_0, {$: "consumer.ReaderArgs"})));
}

function $consumer$058run_calls$1261$(_runtime_0, _foreign_0) {
  const _first_0 = ($consumer$058first_progress$1261$(_foreign_0, ($consumer$058runtime_clock$1261$(_runtime_0))));
  return $consumer$058completed_calls$1261$(($consumer$058fresh_reject_progress$1261$(_foreign_0, ($consumer$058third_progress$1261$(_foreign_0, ($consumer$058second_progress$1261$(_foreign_0, _first_0)))))));
}

function $consumer$058run_refused_calls$1261$(_calls_0, _warm_0) {
  const _runtime_0 = _calls_0["runtime"];
  const _instance_0 = _calls_0["instance"];
  const _report_0 = _calls_0["report"];
  return $consumer$058event_reader_refused$1261$(_runtime_0, _report_0, ($consumer$058instance_text$1261$(_instance_0)), _warm_0);
}

function $consumer$058event_registered$1261$(_registered_0) {
  if (_registered_0.$ === "../../../../../../../../../../../bendvy/src/ecs/event-runtime.RegisterFailed") {
    const _runtime_0 = _registered_0["runtime"];
    return {$: "consumer.ReaderRefused", "runtime": _runtime_0, "warm": {$: "consumer.WarmReport", "registered": false, "count": 0, "lagged": true, "succeeded": false}};
  } else {
    const _runtime_1 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    const _registry_0 = _registered_0["registry"];
    return $consumer$058event_warmed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run$1261$(_runtime_1, _reader_0, _registry_0, {$: "consumer.ReaderArgs"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058register$1261$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058make_runtime$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1261$(_world_0, 16);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $consumer$058world_fields_text$1260$(_world_0, _clock_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _worldClock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(_worldClock_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_clock_0));
  const _x_3 = (";world-clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_nextSystemId_0));
  const _x_6 = (";clock=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(($List$length$(_registrations_0))));
  const _x_9 = (";next-system=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(($consumer$058pending_count$1260$(_pending_0))));
  const _x_12 = (";registrations=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($List$show$1262$(_events_0));
  const _x_15 = (";pending=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($List$show$1261$(($consumer$058u32_data$(($Array$to_list$1261$(_resource_0))))));
  const _x_18 = (";events=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($consumer$058store_text$1260$(_store_0));
  const _x_21 = (";resource=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($Nat$show$(_depth_0));
  const _x_24 = (";store=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_capacity_0));
  const _x_27 = (";depth=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($List$show$1260$(($consumer$058bool_data$(($Array$to_list$1260$(_live_0))))));
  const _x_30 = (";capacity=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_highWater_0));
  const _x_33 = (";live=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  const _x_35 = ($U32$show$(_nextId_0));
  const _x_36 = (";high=" + _x_34);
  const _x_37 = (_x_35 + _x_36);
  const _x_38 = ($U32$show$(_namespace_0));
  const _x_39 = (";next=" + _x_37);
  const _x_40 = (_x_38 + _x_39);
  return ("world{namespace=" + _x_40);
}

function $consumer$058event_read_done$1260$(_report_0, _instance_0, _warm_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Succeeded") {
    const _output_0 = _t_0["output"];
    return $consumer$058event_read_succeeded$1260$(_runtime_0, _report_0, _instance_0, _warm_0, _output_0);
  } else {
    return $consumer$058event_read_failed$1260$(_runtime_0, _report_0, _instance_0, _warm_0);
  }
}

function $consumer$058instance_text$1260$(_instance_0) {
  if (_instance_0.$ === "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return "fresh";
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("active(" + _x_4);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0)), _args_0);
}

function $consumer$058first_progress$1260$(_foreign_0, _runtime_0) {
  const _runtime_1 = _runtime_0["fst"];
  const _before_0 = _runtime_0["snd"];
  return $consumer$058progress_result$1260$("fresh", _before_0, "", ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1260$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, {$: "consumer.Args", "target": _foreign_0, "reject": false}, _runtime_1)));
}

function $consumer$058runtime_clock$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _droppedThrough_0 = _runtime_0["droppedThrough"];
  return $consumer$058clocked_runtime$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _droppedThrough_0);
}

function $consumer$058completed_calls$1260$(_progress_0) {
  const _runtime_0 = _progress_0["runtime"];
  const _instance_0 = _progress_0["instance"];
  const _report_0 = _progress_0["report"];
  return {$: "consumer.CallResult", "runtime": _runtime_0, "instance": _instance_0, "report": _report_0};
}

function $consumer$058fresh_reject_progress$1260$(_foreign_0, _progress_0) {
  const _runtime_0 = _progress_0["runtime"];
  const _report_0 = _progress_0["report"];
  return $consumer$058fresh_reject_result$1260$(_foreign_0, _report_0, ($consumer$058runtime_clock$1260$(_runtime_0)));
}

function $consumer$058third_progress$1260$(_foreign_0, _first_0) {
  const _runtime_0 = _first_0["runtime"];
  const _instance_0 = _first_0["instance"];
  const _report_0 = _first_0["report"];
  return $consumer$058third_result$1260$(_foreign_0, _report_0, _instance_0, ($consumer$058runtime_clock$1260$(_runtime_0)));
}

function $consumer$058second_progress$1260$(_foreign_0, _first_0) {
  const _runtime_0 = _first_0["runtime"];
  const _instance_0 = _first_0["instance"];
  const _report_0 = _first_0["report"];
  return $consumer$058second_result$1260$(_foreign_0, _report_0, _instance_0, ($consumer$058runtime_clock$1260$(_runtime_0)));
}

function $consumer$058event_reader_refused$1260$(_runtime_0, _report_0, _instance_0, _warm_0) {
  return $consumer$058finish_snapshot$1260$(_runtime_0, _report_0, _instance_0, ($consumer$058event_report_after_read$(_warm_0, 0, true, false)));
}

function $consumer$058event_warmed$1260$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _registry_0 = _result_0["registry"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Succeeded") {
    const _output_0 = _t_0["output"];
    return $consumer$058event_after_warm$1260$(_output_0, true, _runtime_0, _reader_0, _registry_0);
  } else {
    return $consumer$058event_after_warm$1260$({$: "consumer.ReaderOutput", "notices": 0, "lagged": true}, false, _runtime_0, _reader_0, _registry_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_result$1260$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1260$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $consumer$058world_fields_text$1261$(_world_0, _clock_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _worldClock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(_worldClock_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_clock_0));
  const _x_3 = (";world-clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_nextSystemId_0));
  const _x_6 = (";clock=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(($List$length$(_registrations_0))));
  const _x_9 = (";next-system=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(($consumer$058pending_count$1261$(_pending_0))));
  const _x_12 = (";registrations=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($List$show$1266$(_events_0));
  const _x_15 = (";pending=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($List$show$1261$(($consumer$058u32_data$(($Array$to_list$1261$(_resource_0))))));
  const _x_18 = (";events=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($consumer$058store_text$1261$(_store_0));
  const _x_21 = (";resource=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($Nat$show$(_depth_0));
  const _x_24 = (";store=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_capacity_0));
  const _x_27 = (";depth=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($List$show$1260$(($consumer$058bool_data$(($Array$to_list$1260$(_live_0))))));
  const _x_30 = (";capacity=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_highWater_0));
  const _x_33 = (";live=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  const _x_35 = ($U32$show$(_nextId_0));
  const _x_36 = (";high=" + _x_34);
  const _x_37 = (_x_35 + _x_36);
  const _x_38 = ($U32$show$(_namespace_0));
  const _x_39 = (";next=" + _x_37);
  const _x_40 = (_x_38 + _x_39);
  return ("world{namespace=" + _x_40);
}

function $consumer$058event_read_done$1261$(_report_0, _instance_0, _warm_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Succeeded") {
    const _output_0 = _t_0["output"];
    return $consumer$058event_read_succeeded$1261$(_runtime_0, _report_0, _instance_0, _warm_0, _output_0);
  } else {
    return $consumer$058event_read_failed$1261$(_runtime_0, _report_0, _instance_0, _warm_0);
  }
}

function $consumer$058instance_text$1261$(_instance_0) {
  if (_instance_0.$ === "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return "fresh";
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("active(" + _x_4);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run$1261$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identified$1261$(_runtime_0, _reader_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1261$(_registry_0)), _args_0);
}

function $consumer$058first_progress$1261$(_foreign_0, _runtime_0) {
  const _runtime_1 = _runtime_0["fst"];
  const _before_0 = _runtime_0["snd"];
  return $consumer$058progress_result$1261$("fresh", _before_0, "", ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, {$: "consumer.Args", "target": _foreign_0, "reject": false}, _runtime_1)));
}

function $consumer$058runtime_clock$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _droppedThrough_0 = _runtime_0["droppedThrough"];
  return $consumer$058clocked_runtime$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _droppedThrough_0);
}

function $consumer$058completed_calls$1261$(_progress_0) {
  const _runtime_0 = _progress_0["runtime"];
  const _instance_0 = _progress_0["instance"];
  const _report_0 = _progress_0["report"];
  return {$: "consumer.CallResult", "runtime": _runtime_0, "instance": _instance_0, "report": _report_0};
}

function $consumer$058fresh_reject_progress$1261$(_foreign_0, _progress_0) {
  const _runtime_0 = _progress_0["runtime"];
  const _report_0 = _progress_0["report"];
  return $consumer$058fresh_reject_result$1261$(_foreign_0, _report_0, ($consumer$058runtime_clock$1261$(_runtime_0)));
}

function $consumer$058third_progress$1261$(_foreign_0, _first_0) {
  const _runtime_0 = _first_0["runtime"];
  const _instance_0 = _first_0["instance"];
  const _report_0 = _first_0["report"];
  return $consumer$058third_result$1261$(_foreign_0, _report_0, _instance_0, ($consumer$058runtime_clock$1261$(_runtime_0)));
}

function $consumer$058second_progress$1261$(_foreign_0, _first_0) {
  const _runtime_0 = _first_0["runtime"];
  const _instance_0 = _first_0["instance"];
  const _report_0 = _first_0["report"];
  return $consumer$058second_result$1261$(_foreign_0, _report_0, _instance_0, ($consumer$058runtime_clock$1261$(_runtime_0)));
}

function $consumer$058event_reader_refused$1261$(_runtime_0, _report_0, _instance_0, _warm_0) {
  return $consumer$058finish_snapshot$1261$(_runtime_0, _report_0, _instance_0, ($consumer$058event_report_after_read$(_warm_0, 0, true, false)));
}

function $consumer$058event_warmed$1261$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _registry_0 = _result_0["registry"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Succeeded") {
    const _output_0 = _t_0["output"];
    return $consumer$058event_after_warm$1261$(_output_0, true, _runtime_0, _reader_0, _registry_0);
  } else {
    return $consumer$058event_after_warm$1261$({$: "consumer.ReaderOutput", "notices": 0, "lagged": true}, false, _runtime_0, _reader_0, _registry_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_result$1261$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_identity$1261$(_world_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1261$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start$1261$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($Bool$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058bool_data$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": _head_0, "tail": ($consumer$058bool_data$(_rest_0))};
  }
}

function $Array$to_list$1260$(_a_0) {
  return $Array$to_list$go$1260$(_a_0, {$: "Nil"});
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $consumer$058store_text$1260$(_store_0) {
  const _graph_0 = _store_0["graph"];
  return $consumer$058graph_text$1260$(_graph_0);
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058u32_data$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": _head_0, "tail": ($consumer$058u32_data$(_rest_0))};
  }
}

function $Array$to_list$1261$(_a_0) {
  return $Array$to_list$go$1261$(_a_0, {$: "Nil"});
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058notice_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058pending_count$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($consumer$058pending_count$1260$(_rest_0));
    return nat_chk(1 + _x_0);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $consumer$058event_read_succeeded$1260$(_runtime_0, _report_0, _instance_0, _warm_0, _output_0) {
  const _readCount_0 = _output_0["notices"];
  const _readLagged_0 = _output_0["lagged"];
  return $consumer$058finish_snapshot$1260$(_runtime_0, _report_0, _instance_0, ($consumer$058event_report_after_read$(_warm_0, _readCount_0, _readLagged_0, true)));
}

function $consumer$058event_read_failed$1260$(_runtime_0, _report_0, _instance_0, _warm_0) {
  return $consumer$058finish_snapshot$1260$(_runtime_0, _report_0, _instance_0, ($consumer$058event_report_after_read$(_warm_0, 0, true, false)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $consumer$058progress_result$1260$(_phase_0, _before_0, _prefix_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _instance_0 = _result_0["instance"];
  const _result_1 = _result_0["result"];
  return $consumer$058progress_clocked$1260$(_phase_0, _before_0, _prefix_0, ($consumer$058outcome_text$(_result_1)), _instance_0, ($consumer$058runtime_clock$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1260$(_instance_0, _args_0, _runtime_0) {
  if (_instance_0.$ === "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058begin_fresh$1260$(_args_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_runtime$1260$(_runtime_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058invoked$1260$(_args_0, _cursor_0, _registeredAt_0, _runtime_0);
  }
}

function $consumer$058clocked_runtime$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _droppedThrough_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _droppedThrough_0}, "snd": _clock_0};
}

function $consumer$058fresh_reject_result$1260$(_foreign_0, _prefix_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _before_0 = _observed_0["snd"];
  return $consumer$058progress_result$1260$("fresh-reject", _before_0, _prefix_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1260$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, {$: "consumer.Args", "target": _foreign_0, "reject": true}, _runtime_0)));
}

function $consumer$058third_result$1260$(_foreign_0, _prefix_0, _instance_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _before_0 = _observed_0["snd"];
  return $consumer$058progress_result$1260$("repeat", _before_0, _prefix_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1260$(_instance_0, {$: "consumer.Args", "target": _foreign_0, "reject": false}, _runtime_0)));
}

function $consumer$058second_result$1260$(_foreign_0, _prefix_0, _instance_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _before_0 = _observed_0["snd"];
  return $consumer$058progress_result$1260$("reject", _before_0, _prefix_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1260$(_instance_0, {$: "consumer.Args", "target": _foreign_0, "reject": true}, _runtime_0)));
}

function $consumer$058finish_snapshot$1260$(_runtime_0, _report_0, _instance_0, _events_0) {
  return $consumer$058final_snapshot$1260$(_report_0, _instance_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect$1260$(_runtime_0)));
}

function $consumer$058event_report_after_read$(_warm_0, _readCount_0, _readLagged_0, _readSucceeded_0) {
  const _registered_0 = _warm_0["registered"];
  const _warmCount_0 = _warm_0["count"];
  const _warmLagged_0 = _warm_0["lagged"];
  const _warmSucceeded_0 = _warm_0["succeeded"];
  return {$: "consumer.EventReport", "registered": _registered_0, "warmCount": _warmCount_0, "warmLagged": _warmLagged_0, "warmSucceeded": _warmSucceeded_0, "readCount": _readCount_0, "readLagged": _readLagged_0, "readSucceeded": _readSucceeded_0};
}

function $consumer$058event_after_warm$1260$(_output_0, _succeeded_0, _runtime_0, _reader_0, _registry_0) {
  return $consumer$058event_after_publish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world$1260$(run_clo((_x_0) => {
  return $consumer$058publish_pending$1260$(_x_0);
}), _runtime_0)), _reader_0, _registry_0, _output_0, _succeeded_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Registered", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $consumer$058store_text$1261$(_store_0) {
  const _graph_0 = _store_0["graph"];
  return $consumer$058graph_text$1261$(_graph_0);
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058notice_text$1261$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058pending_count$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($consumer$058pending_count$1261$(_rest_0));
    return nat_chk(1 + _x_0);
  }
}

function $consumer$058event_read_succeeded$1261$(_runtime_0, _report_0, _instance_0, _warm_0, _output_0) {
  const _readCount_0 = _output_0["notices"];
  const _readLagged_0 = _output_0["lagged"];
  return $consumer$058finish_snapshot$1261$(_runtime_0, _report_0, _instance_0, ($consumer$058event_report_after_read$(_warm_0, _readCount_0, _readLagged_0, true)));
}

function $consumer$058event_read_failed$1261$(_runtime_0, _report_0, _instance_0, _warm_0) {
  return $consumer$058finish_snapshot$1261$(_runtime_0, _report_0, _instance_0, ($consumer$058event_report_after_read$(_warm_0, 0, true, false)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identified$1261$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identity$1261$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $consumer$058progress_result$1261$(_phase_0, _before_0, _prefix_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _instance_0 = _result_0["instance"];
  const _result_1 = _result_0["result"];
  return $consumer$058progress_clocked$1261$(_phase_0, _before_0, _prefix_0, ($consumer$058outcome_text$(_result_1)), _instance_0, ($consumer$058runtime_clock$1261$(_runtime_0)));
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1261$(_instance_0, _args_0, _runtime_0) {
  if (_instance_0.$ === "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058begin_fresh$1261$(_args_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_runtime$1261$(_runtime_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058invoked$1261$(_args_0, _cursor_0, _registeredAt_0, _runtime_0);
  }
}

function $consumer$058clocked_runtime$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _droppedThrough_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _droppedThrough_0}, "snd": _clock_0};
}

function $consumer$058fresh_reject_result$1261$(_foreign_0, _prefix_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _before_0 = _observed_0["snd"];
  return $consumer$058progress_result$1261$("fresh-reject", _before_0, _prefix_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, {$: "consumer.Args", "target": _foreign_0, "reject": true}, _runtime_0)));
}

function $consumer$058third_result$1261$(_foreign_0, _prefix_0, _instance_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _before_0 = _observed_0["snd"];
  return $consumer$058progress_result$1261$("repeat", _before_0, _prefix_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1261$(_instance_0, {$: "consumer.Args", "target": _foreign_0, "reject": false}, _runtime_0)));
}

function $consumer$058second_result$1261$(_foreign_0, _prefix_0, _instance_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _before_0 = _observed_0["snd"];
  return $consumer$058progress_result$1261$("reject", _before_0, _prefix_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058run$1261$(_instance_0, {$: "consumer.Args", "target": _foreign_0, "reject": true}, _runtime_0)));
}

function $consumer$058finish_snapshot$1261$(_runtime_0, _report_0, _instance_0, _events_0) {
  return $consumer$058final_snapshot$1261$(_report_0, _instance_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect$1261$(_runtime_0)));
}

function $consumer$058event_after_warm$1261$(_output_0, _succeeded_0, _runtime_0, _reader_0, _registry_0) {
  return $consumer$058event_after_publish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world$1261$(run_clo((_x_0) => {
  return $consumer$058publish_pending$1261$(_x_0);
}), _runtime_0)), _reader_0, _registry_0, _output_0, _succeeded_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058registered_identity$1261$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Registered", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($Bool$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $Array$to_list$go$1260$($0, $1) {
  for (;;) {
    {
      const _a_0 = $0;
      const _acc_0 = $1;
      if (_a_0.length === 1) {
        const _x_0 = _a_0[0];
        return {$: "Con", "head": _x_0, "tail": _acc_0};
      } else {
        const _xs_0 = _a_0.slice(0, _a_0.length >> 1);
        const _ys_0 = _a_0.slice(_a_0.length >> 1);
        $0 = _xs_0;
        $1 = ($Array$to_list$go$1260$(_ys_0, _acc_0));
        continue;
      }
    }
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $consumer$058graph_text$1260$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _x_0 = ($Nat$show$(($List$length$(_inverses_0))));
  const _x_1 = ($Nat$show$(($List$length$(_edges_0))));
  const _x_2 = (",inverses=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("edges=" + _x_3);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $Array$to_list$go$1261$($0, $1) {
  for (;;) {
    {
      const _a_0 = $0;
      const _acc_0 = $1;
      if (_a_0.length === 1) {
        const _x_0 = _a_0[0];
        return {$: "Con", "head": _x_0, "tail": _acc_0};
      } else {
        const _xs_0 = _a_0.slice(0, _a_0.length >> 1);
        const _ys_0 = _a_0.slice(_a_0.length >> 1);
        $0 = _xs_0;
        $1 = ($Array$to_list$go$1261$(_ys_0, _acc_0));
        continue;
      }
    }
  }
}

function $consumer$058notice_text$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _event_0 = _value_0["event"];
    const _x_0 = ($U32$show$(_event_0));
    return ("original:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    return "relation-failed";
  } else if (_value_0.$ === "../../../../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("component-removed:" + _x_1);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_2 = ($Nat$show$(($List$length$(_frames_0))));
    return ("cleanup-paused:" + _x_2);
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058notice_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_checked$1260$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058progress_clocked$1260$(_phase_0, _before_0, _prefix_0, _value_0, _instance_0, _observed_0) {
  return $consumer$058progress_clocked_join$1260$(_phase_0, _before_0, _prefix_0, _value_0, _observed_0, ($consumer$058render_instance$1260$(_instance_0)));
}

function $consumer$058outcome_text$(_observation_0) {
  if (_observation_0.$ === "Done") {
    const _t_0 = _observation_0["value"];
    const _resourceSize_0 = _t_0["resourceSize"];
    const _targetValid_0 = _t_0["targetValid"];
    const _x_0 = ($Bool$show$(_targetValid_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($Nat$show$(_resourceSize_0));
    const _x_3 = (",foreign-valid=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("done(size=" + _x_4);
  } else {
    const _t_1 = _observation_0["error"];
    return "failed(explicit)";
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058begin_fresh$1260$(_args_0, _runtime_0) {
  const _runtime_1 = _runtime_0["fst"];
  const _registeredAt_0 = _runtime_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058invoked$1260$(_args_0, 0, _registeredAt_0, _runtime_1);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_runtime$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058invoked$1260$(_args_0, _cursor_0, _registeredAt_0, _runtime_0) {
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058finished$1260$(_cursor_0, _registeredAt_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../../../../../../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": _runtime_0, "cursor": _cursor_0})));
}

function $consumer$058final_snapshot$1260$(_report_0, _instance_0, _events_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _visible_0 = _t_0["visible"];
  const _retained_0 = _t_0["retained"];
  const _readers_0 = _t_0["readers"];
  const _snapshotTick_0 = _t_0["tick"];
  const _snapshotBoundary_0 = _t_0["boundary"];
  const _x_0 = ($consumer$058runtime_fields_text$1260$(_runtime_0));
  const _x_1 = ("|final-" + _x_0);
  const _x_2 = (_instance_0 + _x_1);
  const _x_3 = ($Nat$show$(_snapshotBoundary_0));
  const _x_4 = ("}|final-instance=" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = ($Nat$show$(_snapshotTick_0));
  const _x_7 = (";boundary=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($List$show$1263$(_readers_0));
  const _x_10 = (";tick=" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($List$show$1262$(_retained_0));
  const _x_13 = (";readers=" + _x_11);
  const _x_14 = (_x_12 + _x_13);
  const _x_15 = ($List$show$1262$(_visible_0));
  const _x_16 = (";retained=" + _x_14);
  const _x_17 = (_x_15 + _x_16);
  const _x_18 = ($consumer$058event_report_text$(_events_0));
  const _x_19 = ("|snapshot{visible=" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ("|" + _x_20);
  return (_report_0 + _x_21);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect_values$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058event_after_publish$1260$(_observed_0, _reader_0, _registry_0, _output_0, _succeeded_0) {
  const _runtime_0 = _observed_0["fst"];
  return $consumer$058event_ready$1260$(_runtime_0, _reader_0, _registry_0, _output_0, _succeeded_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world_result$1260$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058publish_pending$1260$(_world_0) {
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(($consumer$058queue_clock_advance$1260$(_world_0)), {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": 77}, "tail": {$: "Nil"}})), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $consumer$058graph_text$1261$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _x_0 = ($Nat$show$(($List$length$(_inverses_0))));
  const _x_1 = ($Nat$show$(($List$length$(_edges_0))));
  const _x_2 = (",inverses=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("edges=" + _x_3);
}

function $consumer$058notice_text$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _event_0 = _value_0["event"];
    const _x_0 = ($U32$show$(_event_0));
    return ("original:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    return "relation-failed";
  } else if (_value_0.$ === "../../../../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("component-removed:" + _x_1);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_2 = ($Nat$show$(($List$length$(_frames_0))));
    return ("cleanup-paused:" + _x_2);
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058notice_text$1261$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_identity$1261$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_checked$1261$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058progress_clocked$1261$(_phase_0, _before_0, _prefix_0, _value_0, _instance_0, _observed_0) {
  return $consumer$058progress_clocked_join$1261$(_phase_0, _before_0, _prefix_0, _value_0, _observed_0, ($consumer$058render_instance$1261$(_instance_0)));
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058begin_fresh$1261$(_args_0, _runtime_0) {
  const _runtime_1 = _runtime_0["fst"];
  const _registeredAt_0 = _runtime_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058invoked$1261$(_args_0, 0, _registeredAt_0, _runtime_1);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_runtime$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058invoked$1261$(_args_0, _cursor_0, _registeredAt_0, _runtime_0) {
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058finished$1261$(_cursor_0, _registeredAt_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1261$(_args_0, {$: "../../../../../../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": _runtime_0, "cursor": _cursor_0})));
}

function $consumer$058final_snapshot$1261$(_report_0, _instance_0, _events_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _visible_0 = _t_0["visible"];
  const _retained_0 = _t_0["retained"];
  const _readers_0 = _t_0["readers"];
  const _snapshotTick_0 = _t_0["tick"];
  const _snapshotBoundary_0 = _t_0["boundary"];
  const _x_0 = ($consumer$058runtime_fields_text$1261$(_runtime_0));
  const _x_1 = ("|final-" + _x_0);
  const _x_2 = (_instance_0 + _x_1);
  const _x_3 = ($Nat$show$(_snapshotBoundary_0));
  const _x_4 = ("}|final-instance=" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = ($Nat$show$(_snapshotTick_0));
  const _x_7 = (";boundary=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($List$show$1263$(_readers_0));
  const _x_10 = (";tick=" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($List$show$1266$(_retained_0));
  const _x_13 = (";readers=" + _x_11);
  const _x_14 = (_x_12 + _x_13);
  const _x_15 = ($List$show$1266$(_visible_0));
  const _x_16 = (";retained=" + _x_14);
  const _x_17 = (_x_15 + _x_16);
  const _x_18 = ($consumer$058event_report_text$(_events_0));
  const _x_19 = ("|snapshot{visible=" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ("|" + _x_20);
  return (_report_0 + _x_21);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect_values$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058event_after_publish$1261$(_observed_0, _reader_0, _registry_0, _output_0, _succeeded_0) {
  const _runtime_0 = _observed_0["fst"];
  return $consumer$058event_ready$1261$(_runtime_0, _reader_0, _registry_0, _output_0, _succeeded_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world_result$1261$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058publish_pending$1261$(_world_0) {
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(($consumer$058queue_clock_advance$1261$(_world_0)), {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": 77}, "tail": {$: "Nil"}})), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_checked$1260$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_position$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $consumer$058progress_clocked_join$1260$(_phase_0, _before_0, _prefix_0, _value_0, _observed_0, _rendered_0) {
  const _runtime_0 = _observed_0["fst"];
  const _after_0 = _observed_0["snd"];
  const _instance_0 = _rendered_0["instance"];
  const _text_0 = _rendered_0["text"];
  const _x_0 = ($U32$show$(_after_0));
  const _x_1 = ($U32$show$(_before_0));
  const _x_2 = ("->" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (";clock=" + _x_3);
  const _x_5 = (_text_0 + _x_4);
  const _x_6 = (";instance=" + _x_5);
  const _x_7 = (_value_0 + _x_6);
  const _x_8 = ("=" + _x_7);
  const _x_9 = (_phase_0 + _x_8);
  const _x_10 = ("|" + _x_9);
  return {$: "consumer.Progress", "runtime": _runtime_0, "instance": _instance_0, "report": (_prefix_0 + _x_10)};
}

function $consumer$058render_instance$1260$(_instance_0) {
  if (_instance_0.$ === "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return {$: "consumer.RenderedInstance", "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, "text": "fresh"};
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return {$: "consumer.RenderedInstance", "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "text": ("active(" + _x_4)};
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_join$1260$(_clocked_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _clocked_0["fst"];
  const _registeredAt_0 = _clocked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _registeredAt_0};
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058finished$1260$(_cursor_0, _registeredAt_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _runtime_0 = _t_0["runtime"];
  const _t_1 = _observed_0["snd"];
  if (_t_1.$ === "Fail") {
    const _error_0 = _t_1["error"];
    return {$: "../../../src/ecs/inspector-runtime.RunResult", "runtime": _runtime_0, "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _t_1["value"];
    return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058succeeded$1260$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058advance_runtime$1260$(_runtime_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $consumer$058probe_body$1260$(_args_0, _ctx_0);
}

function $consumer$058event_report_text$(_report_0) {
  const _registered_0 = _report_0["registered"];
  const _warmCount_0 = _report_0["warmCount"];
  const _warmLagged_0 = _report_0["warmLagged"];
  const _warmSucceeded_0 = _report_0["warmSucceeded"];
  const _readCount_0 = _report_0["readCount"];
  const _readLagged_0 = _report_0["readLagged"];
  const _readSucceeded_0 = _report_0["readSucceeded"];
  const _x_0 = ($Bool$show$(_readSucceeded_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Bool$show$(_readLagged_0));
  const _x_3 = ("/" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Nat$show$(_readCount_0));
  const _x_6 = ("/" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Bool$show$(_warmSucceeded_0));
  const _x_9 = (";read=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Bool$show$(_warmLagged_0));
  const _x_12 = ("/" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_warmCount_0));
  const _x_15 = ("/" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($Bool$show$(_registered_0));
  const _x_18 = (";warm=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  return ("event-reader{registered=" + _x_19);
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058reader_status_text$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058runtime_fields_text$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _droppedThrough_0 = _runtime_0["droppedThrough"];
  const _x_0 = ($consumer$058clock_text$1260$(_world_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_droppedThrough_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Nat$show$(_capacity_0));
  const _x_6 = (";dropped=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_boundary_0));
  const _x_9 = (";capacity=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(_frameStart_0));
  const _x_12 = (";boundary=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_tick_0));
  const _x_15 = (";frame-start=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($U32$show$(_nextReader_0));
  const _x_18 = (";tick=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($List$show$1265$(_positions_0));
  const _x_21 = (";next-reader=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($List$show$1264$(_batches_0));
  const _x_24 = (";positions=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_namespace_0));
  const _x_27 = (";batches=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  return ("runtime{namespace=" + _x_28);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect_values$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _retained_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Snapshot", "visible": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _boundary_0)), "retained": _retained_0, "readers": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_statuses$1260$(($List$reverse$(_positions_0)), _batches_0, _dropped_0)), "tick": _tick_0, "boundary": _boundary_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $consumer$058event_ready$1260$(_runtime_0, _reader_0, _registry_0, _output_0, _succeeded_0) {
  const _count_0 = _output_0["notices"];
  const _lagged_0 = _output_0["lagged"];
  return {$: "consumer.ReaderReady", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "warm": {$: "consumer.WarmReport", "registered": true, "count": _count_0, "lagged": _lagged_0, "succeeded": _succeeded_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world_result$1260$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $consumer$058queue_clock_advance$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $consumer$058advanced_world$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_x_0)));
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_checked$1261$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_position$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $consumer$058progress_clocked_join$1261$(_phase_0, _before_0, _prefix_0, _value_0, _observed_0, _rendered_0) {
  const _runtime_0 = _observed_0["fst"];
  const _after_0 = _observed_0["snd"];
  const _instance_0 = _rendered_0["instance"];
  const _text_0 = _rendered_0["text"];
  const _x_0 = ($U32$show$(_after_0));
  const _x_1 = ($U32$show$(_before_0));
  const _x_2 = ("->" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (";clock=" + _x_3);
  const _x_5 = (_text_0 + _x_4);
  const _x_6 = (";instance=" + _x_5);
  const _x_7 = (_value_0 + _x_6);
  const _x_8 = ("=" + _x_7);
  const _x_9 = (_phase_0 + _x_8);
  const _x_10 = ("|" + _x_9);
  return {$: "consumer.Progress", "runtime": _runtime_0, "instance": _instance_0, "report": (_prefix_0 + _x_10)};
}

function $consumer$058render_instance$1261$(_instance_0) {
  if (_instance_0.$ === "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return {$: "consumer.RenderedInstance", "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, "text": "fresh"};
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return {$: "consumer.RenderedInstance", "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "text": ("active(" + _x_4)};
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058fresh_join$1261$(_clocked_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _clocked_0["fst"];
  const _registeredAt_0 = _clocked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _registeredAt_0};
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058finished$1261$(_cursor_0, _registeredAt_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _runtime_0 = _t_0["runtime"];
  const _t_1 = _observed_0["snd"];
  if (_t_1.$ === "Fail") {
    const _error_0 = _t_1["error"];
    return {$: "../../../src/ecs/inspector-runtime.RunResult", "runtime": _runtime_0, "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _t_1["value"];
    return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058succeeded$1261$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058advance_runtime$1261$(_runtime_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1261$(_args_0, _ctx_0) {
  return $consumer$058probe_body$1261$(_args_0, _ctx_0);
}

function $consumer$058runtime_fields_text$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _droppedThrough_0 = _runtime_0["droppedThrough"];
  const _x_0 = ($consumer$058clock_text$1261$(_world_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_droppedThrough_0));
  const _x_3 = (";" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Nat$show$(_capacity_0));
  const _x_6 = (";dropped=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_boundary_0));
  const _x_9 = (";capacity=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(_frameStart_0));
  const _x_12 = (";boundary=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_tick_0));
  const _x_15 = (";frame-start=" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($U32$show$(_nextReader_0));
  const _x_18 = (";tick=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($List$show$1265$(_positions_0));
  const _x_21 = (";next-reader=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($List$show$1267$(_batches_0));
  const _x_24 = (";positions=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_namespace_0));
  const _x_27 = (";batches=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  return ("runtime{namespace=" + _x_28);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058inspect_values$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _retained_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Snapshot", "visible": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _boundary_0)), "retained": _retained_0, "readers": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_statuses$1261$(($List$reverse$(_positions_0)), _batches_0, _dropped_0)), "tick": _tick_0, "boundary": _boundary_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $consumer$058event_ready$1261$(_runtime_0, _reader_0, _registry_0, _output_0, _succeeded_0) {
  const _count_0 = _output_0["notices"];
  const _lagged_0 = _output_0["lagged"];
  return {$: "consumer.ReaderReady", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "warm": {$: "consumer.WarmReport", "registered": true, "count": _count_0, "lagged": _lagged_0, "succeeded": _succeeded_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058with_world_result$1261$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $consumer$058queue_clock_advance$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $consumer$058advanced_world$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_x_0)));
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_position$1260$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058succeeded$1260$(_registeredAt_0, _value_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../src/ecs/inspector-runtime.RunResult", "runtime": _runtime_0, "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058advance_runtime$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058bumped_runtime$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058probe_body$1260$(_args_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request$1260$(_owner_0, _args_0);
}

function $consumer$058reader_status_text$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registeredAt_0 = _value_0["registeredAt"];
  const _unread_0 = _value_0["unread"];
  const _lagged_0 = _value_0["lagged"];
  const _x_0 = ($Bool$show$(_lagged_0));
  const _x_1 = ($Nat$show$(_unread_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_registeredAt_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_cursor_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_id_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058reader_status_text$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058batch_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058position_text$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_statuses$1260$(_positions_0, _batches_0, _dropped_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_status$1260$(_position_0, _batches_0, _dropped_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_statuses$1260$(_rest_0, _batches_0, _dropped_0))};
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_values$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1260$(_batches_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_published_0));
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $consumer$058advanced_world$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_position$1261$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_reading$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_reading$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1261$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058succeeded$1261$(_registeredAt_0, _value_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../src/ecs/inspector-runtime.RunResult", "runtime": _runtime_0, "instance": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058advance_runtime$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058bumped_runtime$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058probe_body$1261$(_args_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request$1261$(_owner_0, _args_0);
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058batch_text$1261$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1261$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_statuses$1261$(_positions_0, _batches_0, _dropped_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_status$1261$(_position_0, _batches_0, _dropped_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_statuses$1261$(_rest_0, _batches_0, _dropped_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_values$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1261$(_batches_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_published_0));
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1261$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $consumer$058advanced_world$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_reading$1260$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_registered_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058bumped_runtime$1260$(_advanced_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _advanced_0["fst"];
  const _cursor_0 = _advanced_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _cursor_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request_field$1260$(($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058plan_caps$1260$(($consumer$058plan$1260$())))))(_ctx_0), _value_0);
}

function $consumer$058batch_text$1260$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$1262$(_values_0));
  const _x_1 = (_x_0 + "]");
  const _x_2 = ($U32$show$((_tick_0 >>> 0)));
  const _x_3 = (":[" + _x_1);
  return (_x_2 + _x_3);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058batch_text$1260$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058position_text$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registeredAt_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registeredAt_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058position_text$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_status$1260$(_position_0, _batches_0, _dropped_0) {
  const _id_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.ReaderStatus", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0, "unread": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)))), "lagged": (_x_0 < _dropped_0)};
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_reading$1261$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_registered_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1261$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058bumped_runtime$1261$(_advanced_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _advanced_0["fst"];
  const _cursor_0 = _advanced_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _cursor_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request_field$1261$(($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058plan_caps$1261$(($consumer$058plan$1261$())))))(_ctx_0), _value_0);
}

function $consumer$058batch_text$1261$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$1266$(_values_0));
  const _x_1 = (_x_0 + "]");
  const _x_2 = ($U32$show$((_tick_0 >>> 0)));
  const _x_3 = (":[" + _x_1);
  return (_x_2 + _x_3);
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058batch_text$1261$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1261$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reader_status$1261$(_position_0, _batches_0, _dropped_0) {
  const _id_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.ReaderStatus", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0, "unread": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0)))), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1261$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1261$(_batches_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_checked$1261$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1263$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_registered_result$1260$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reject_input$1260$(_args_0, {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request_field$1260$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058plan_caps$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $consumer$058plan$1260$() {
  return {$: "../../../src/ecs/inspector-runtime.Plan", "caps": ($consumer$058request_caps$1260$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_registered_result$1261$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reject_input$1261$(_args_0, {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_outcome$1261$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058request_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058plan_caps$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $consumer$058plan$1261$() {
  return {$: "../../../src/ecs/inspector-runtime.Plan", "caps": ($consumer$058request_caps$1261$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1263$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1263$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reject_input$1260$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../../../../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1260$(_world_1)), _namespace_0, _batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $consumer$058request_caps$1260$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058request_read$1260$(_x_1, _x_0);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reject_input$1261$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058run_outcome$1261$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../../../../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Ran", "runtime": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058events_view$1261$(_world_1)), _namespace_0, _batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $consumer$058request_caps$1261$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058request_read$1261$(_x_1, _x_0);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $consumer$058request_read$1260$(_args_0, _owner_0) {
  const _target_0 = _args_0["target"];
  const _reject_0 = _args_0["reject"];
  return $consumer$058read_done$1260$(_target_0, _reject_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_lookup$1260$()), run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $consumer$058request_read$1261$(_args_0, _owner_0) {
  const _target_0 = _args_0["target"];
  const _reject_0 = _args_0["reject"];
  return $consumer$058read_done$1261$(_target_0, _reject_0, ($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_lookup$1261$()), run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1262$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $consumer$058read_done$1260$(_target_0, _reject_0, _cap_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _size_0 = _observed_0["snd"];
  return $consumer$058accessed$1260$(_target_0, _size_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1260$(_cap_0))(_owner_0)(_target_0), _reject_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_lookup$1260$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Lookup", "get": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_frame$1260$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_read$1260$()))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $consumer$058read_done$1261$(_target_0, _reject_0, _cap_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _size_0 = _observed_0["snd"];
  return $consumer$058accessed$1261$(_target_0, _size_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1262$(_cap_0))(_owner_0)(_target_0), _reject_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_lookup$1261$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Lookup", "get": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_frame$1261$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1262$(($$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_read$1261$()))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $consumer$058accessed$1260$(_target_0, _size_0, _observed_0, _reject_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["access"];
  if (_t_1.$ === "../../../../../../../../../../../bendvy/src/ecs/component.Found") {
    const _valid_0 = _t_1["value"];
    if (!_reject_0) {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "consumer.Observation", "resourceSize": _size_0, "targetValid": _valid_0}}};
    } else {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "consumer.ExplicitRefusal"}}};
    }
  } else if (_t_1.$ === "../../../../../../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
    if (!_reject_0) {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "consumer.Observation", "resourceSize": _size_0, "targetValid": false}}};
    } else {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "consumer.ExplicitRefusal"}}};
    }
  } else {
    if (!_reject_0) {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "consumer.Observation", "resourceSize": _size_0, "targetValid": false}}};
    } else {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "consumer.ExplicitRefusal"}}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_frame$1260$(_frame_0, _target_0) {
  const _runtime_0 = _frame_0["runtime"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_runtime$1260$(_cursor_0, _runtime_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_read$1260$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_frame$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $consumer$058accessed$1261$(_target_0, _size_0, _observed_0, _reject_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["access"];
  if (_t_1.$ === "../../../../../../../../../../../bendvy/src/ecs/component.Found") {
    const _valid_0 = _t_1["value"];
    if (!_reject_0) {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "consumer.Observation", "resourceSize": _size_0, "targetValid": _valid_0}}};
    } else {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "consumer.ExplicitRefusal"}}};
    }
  } else if (_t_1.$ === "../../../../../../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
    if (!_reject_0) {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "consumer.Observation", "resourceSize": _size_0, "targetValid": false}}};
    } else {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "consumer.ExplicitRefusal"}}};
    }
  } else {
    if (!_reject_0) {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "consumer.Observation", "resourceSize": _size_0, "targetValid": false}}};
    } else {
      return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "consumer.ExplicitRefusal"}}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_frame$1261$(_frame_0, _target_0) {
  const _runtime_0 = _frame_0["runtime"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_runtime$1261$(_cursor_0, _runtime_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lift_world_read$1261$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_frame$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($consumer$058event_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_runtime$1260$(_cursor_0, _runtime_0, _target_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_lookup$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup$1260$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, _target_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_frame$1260$(_frame_0) {
  const _runtime_0 = _frame_0["runtime"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_runtime$1260$(_cursor_0, _runtime_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, ($consumer$058event_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058lookup_runtime$1261$(_cursor_0, _runtime_0, _target_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_lookup$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, _target_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_frame$1261$(_frame_0) {
  const _runtime_0 = _frame_0["runtime"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_runtime$1261$(_cursor_0, _runtime_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058event_runner$1260$(_world_0, _input_0) {
  const _values_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "consumer.ReaderOutput", "notices": ($consumer$058notice_count$1260$(_values_0)), "lagged": _lagged_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_lookup$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _cursor_0 = _t_0["cursor"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup$1260$(_ctx_0, _target_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Lookup", "get": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058lookup_live$1260$(_x_0, _x_1);
});
})}))(_ctx_0), _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_runtime$1260$(_cursor_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_read$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $consumer$058event_runner$1261$(_world_0, _input_0) {
  const _values_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  return {$: "../../../../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "consumer.ReaderOutput", "notices": ($consumer$058notice_count$1261$(_values_0)), "lagged": _lagged_0}};
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_lookup$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _cursor_0 = _t_0["cursor"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup$1261$(_ctx_0, _target_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1263$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Lookup", "get": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $consumer$058lookup_live$1261$(_x_0, _x_1);
});
})}))(_ctx_0), _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058read_runtime$1261$(_cursor_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_read$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1263$({$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $consumer$058notice_count$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($consumer$058notice_count$1260$(_rest_0));
    return nat_chk(1 + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $consumer$058lookup_live$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $consumer$058lookup_result$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_read$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _cursor_0 = _t_0["cursor"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058read_resource$1260$()))), _ctx_0);
}

function $consumer$058notice_count$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($consumer$058notice_count$1261$(_rest_0));
    return nat_chk(1 + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058lookup_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $consumer$058lookup_live$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $consumer$058lookup_result$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047src$047ecs$047inspector$045runtime$058restored_read$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _cursor_0 = _t_0["cursor"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector-stream-frame.Frame", "runtime": {$: "../../../../../../../../../../../bendvy/src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058read_resource$1261$()))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $consumer$058lookup_result$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _valid_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Value", "access": {$: "../../../../../../../../../../../bendvy/src/ecs/component.Found", "value": _valid_0}, "added": false, "changed": false}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058read_resource$1260$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_get$1260$(_x_0);
})};
}

function $consumer$058lookup_result$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _valid_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Value", "access": {$: "../../../../../../../../../../../bendvy/src/ecs/component.Found", "value": _valid_0}, "added": false, "changed": false}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058read_resource$1261$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_get$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_get$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_join$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_get$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_join$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_join$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($consumer$058resource_size$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058resource_join$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(($consumer$058resource_size$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058resource_size$(_owner_0) {
  return $consumer$058resource_size_join$({$: "Tuple", fst: _owner_0, snd: _owner_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058resource_size_join$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _size_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": _size_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);