
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_REPORTED 13
#define CID_BUILDREJECTED 14
#define CID_CREATEREJECTED 15
#define CID_REPORT 16
#define CID_SNAPSHOT 17
#define CID_NIL 18
#define CID_CON 19
#define CID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_FULLCELL 20
#define CID__________________________________BENDVY_SRC_ECS_WORLD_REGISTRATIONMETA 21
#define CID_APP_DESCRIPTION 22
#define CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_ENTRY 23
#define CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_COMPONENT 24
#define CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_RESOURCE 25
#define CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_EVENT 26
#define CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_RELATION 27
#define CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_SERVICE 28
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_SYSTEM 29
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PHASE 30
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_BARRIER 31
#define CID_APP_ENTRY 32
#define CID____DECLARATION_CLAUSE 33
#define CID____DECLARATION_READ 34
#define CID____DECLARATION_WRITE 35
#define CID____DECLARATION_OPTIONAL 36
#define CID____DECLARATION_WITH 37
#define CID____DECLARATION_WITHOUT 38
#define CID____DECLARATION_ADDED 39
#define CID____DECLARATION_CHANGED 40
#define CID_RESOURCE_CONTROL_DELIVERED 41
#define CID_RESOURCE_CONTROL_BUILDREJECTED 42
#define CID_RESOURCE_CONTROL_CREATEREJECTED 43
#define CID_CHR 44
#define CID_RESOURCE_CONTROL_RESOURCESCHEMA 45
#define CID__________________________________BENDVY_SRC_ECS_WORLD_FACTORY 46
#define CID__________________________________BENDVY_SRC_ECS_WORLD_WORLD 47
#define CID_APP_APPLICATION 48
#define CID__________________________________BENDVY_SRC_ECS_WORLD_CREATED 49
#define CID__________________________________BENDVY_SRC_ECS_WORLD_CREATEREJECTED 50
#define CID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SNAPSHOT_PERSISTENCE_GATE_V1_BASIC_WORLD_V1_PUBLIC_ADOPTION_V1_CORE_PROMOTION_V1_LIBRARY_ORDINARY_SCHEMA_SCHEMA 51
#define CID_APP_ENABLED 52
#define CID_APP_DISABLED 53
#define CID_APP_BINDING 54
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_PROVISIONED 55
#define CID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SNAPSHOT_PERSISTENCE_GATE_V1_BASIC_WORLD_V1_PUBLIC_ADOPTION_V1_CORE_PROMOTION_V1_LIBRARY_ORDINARY_SCHEMA_RESOURCE 56
#define CID_APP_BUILT 57
#define CID_APP_INVALID 58
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_EMPTY 59
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_ENTRY 60
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_SEQUENCE 61
#define CID_APP_OWNERS 62
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_SCHEDULE 63
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_COMPONENT 64
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_RESOURCE 65
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_SERVICE 66
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILT 67
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_INVALID 68
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILT 69
#define CID__________________________________BENDVY_SRC_ECS_SCHEDULE_INVALID 70
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0 0
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K2 1
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS 2
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS_K6 3
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0 4
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K10 5
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K11 6
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID 7
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K13 8
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K14 9
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K15 10
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0 11
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K22 12
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K23 13
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0 14
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0 15
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K26 16
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K27 17
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0 18
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0_K29 19
#define FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0 20
#define FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K34 21
#define FID____SCENARIO_OBSERVATION_BITS 22
#define FID____SCENARIO_OBSERVATION_BITS_C37 23
#define FID____SCENARIO_OBSERVATION_BITS_K38 24
#define FID____SCENARIO_OBSERVATION_BITS_K39 25
#define FID_LIST_APPEND 26
#define FID_LIST_APPEND_K42 27
#define FID_APP_IDS_0 28
#define FID_APP_IDS_0_K45 29
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0 30
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K47 31
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K48 32
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K49 33
#define FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K50 34
#define FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT 35
#define FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_C55 36
#define FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K56 37
#define FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K57 38
#define FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0 39
#define FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K61 40
#define FID_APP_ENTRIES_0 41
#define FID_APP_ENTRIES_0_K65 42
#define FID_APP_BUILD_0 43
#define FID_APP_BUILD_0_K74 44
#define FID_APP_BUILD_0_K75 45
#define FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0 46
#define FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K83 47
#define FID_APP_DESCRIBE_0 48
#define FID_APP_DESCRIBE_0_K88 49
#define FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW 50
#define FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW_K99 51
#define FID_SNAPSHOT 52
#define FID_SNAPSHOT_K104 53
#define FID_SNAPSHOT_K105 54
#define FID_SNAPSHOT_K106 55
#define FID_RESOURCE_CONTROL_MAIN 56
#define FID_RESOURCE_CONTROL_MAIN_K113 57
#define FID_RESOURCE_CONTROL_MAIN_K114 58
#define FID_MAIN 59
#define FID_MAIN_K124 60
#define FID_MAIN_K125 61
#define FID_MAIN_K126 62
#define FID_MAIN_K127 63
#define FID_MAIN_K128 64
#define FID_MAIN_K129 65
#define FID_MAIN_K130 66
#define FID_MAIN_K131 67
#define FID_IO_EMIT 68
#define FID_CLO_APPLY 69
#define FID_EXIT 70
#define FID_ENTER 71
CONSTV u8 FID_T[][3] = { { 3, 0, 2 }, { 5, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 3, 0, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 1, 0, 2 }, { 3, 2, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 4, 0, 2 }, { 5, 1, 2 }, { 5, 4, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 12, 0, 2 }, { 13, 2, 2 }, { 1, 0, 2 }, { 6, 1, 2 }, { 7, 0, 2 }, { 7, 1, 2 }, { 8, 5, 2 }, { 12, 0, 2 }, { 14, 3, 2 }, { 7, 0, 2 }, { 7, 1, 2 }, { 1, 0, 2 }, { 3, 2, 2 }, { 12, 0, 2 }, { 14, 14, 2 }, { 15, 13, 2 }, { 16, 2, 2 }, { 0, 0, 2 }, { 21, 8, 2 }, { 26, 13, 2 }, { 0, 0, 2 }, { 27, 27, 2 }, { 39, 25, 2 }, { 45, 13, 2 }, { 51, 13, 2 }, { 34, 1, 2 }, { 47, 25, 2 }, { 26, 25, 2 }, { 4, 3, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 28, 0 }, { 14, 0 }, { 3, 0 }, { 28, 0 }, { 13, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 3, 1 }, { 5, 1 }, { 3, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 1, 1 }, { 0, 1 }, { 5, 1 }, { 2, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 26, 1 }, { 13, 1 }, { 2, 1 }, { 1, 1 }, { 0, 1 }, { 1, 1 }, { 13, 1 }, { 8, 1 }, { 14, 0 }, { 2, 0 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 6, 1 }, { 5, 1 }, { 1, 1 }, { 8, 1 }, { 1, 1 }, { 0, 1 }, { 4, 1 }, { 2, 1 }, { 6, 0 }, { 4, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 5, 1 }, { 1, 1 }, { 4, 1 }, { 1, 1 } };
#define STAT_LEN 32

#define WL_RESW 29
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25; (V)[26] = r26; (V)[27] = r27; (V)[28] = r28;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25]; r26 = (V)[26]; r27 = (V)[27]; r28 = (V)[28];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28

#define WL_TABLE WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K2) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS_K6) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K10) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K11) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K13) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K14) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K15) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K22) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K23) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K26) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K27) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0_K29) WL_X(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0) WL_X(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K34) WL_X(FID____SCENARIO_OBSERVATION_BITS) WL_X(FID____SCENARIO_OBSERVATION_BITS_C37) WL_X(FID____SCENARIO_OBSERVATION_BITS_K38) WL_X(FID____SCENARIO_OBSERVATION_BITS_K39) WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K42) WL_X(FID_APP_IDS_0) WL_X(FID_APP_IDS_0_K45) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K47) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K48) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K49) WL_X(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K50) WL_X(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT) WL_X(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_C55) WL_X(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K56) WL_X(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K57) WL_X(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0) WL_X(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K61) WL_X(FID_APP_ENTRIES_0) WL_X(FID_APP_ENTRIES_0_K65) WL_X(FID_APP_BUILD_0) WL_X(FID_APP_BUILD_0_K74) WL_X(FID_APP_BUILD_0_K75) WL_X(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0) WL_X(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K83) WL_X(FID_APP_DESCRIBE_0) WL_X(FID_APP_DESCRIBE_0_K88) WL_X(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW) WL_X(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW_K99) WL_X(FID_SNAPSHOT) WL_X(FID_SNAPSHOT_K104) WL_X(FID_SNAPSHOT_K105) WL_X(FID_SNAPSHOT_K106) WL_X(FID_RESOURCE_CONTROL_MAIN) WL_X(FID_RESOURCE_CONTROL_MAIN_K113) WL_X(FID_RESOURCE_CONTROL_MAIN_K114) WL_X(FID_MAIN) WL_X(FID_MAIN_K124) WL_X(FID_MAIN_K125) WL_X(FID_MAIN_K126) WL_X(FID_MAIN_K127) WL_X(FID_MAIN_K128) WL_X(FID_MAIN_K129) WL_X(FID_MAIN_K130) WL_X(FID_MAIN_K131) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 1
#define BLK_SHR 1

#if !DEVICE

static const u32 SHOW_DESC[] = { 7, 0, 3, 0, CID_REPORTED, 1, 0, 1, 25, 1, CID_BUILDREJECTED, 2, 0, 1, 40, 2, 41, 2, CID_CREATEREJECTED, 2, 0, 1, 40, 2, 108, 7, 0, 1, 3, CID_REPORT, 4, 0, 0, 40, 1, 41, 14, 41, 27, 201, 0, 7, 0, 1, 4, CID_SNAPSHOT, 13, 0, 0, 40, 1, 40, 2, 40, 3, 40, 4, 74, 5, 75, 6, 101, 6, 108, 8, 135, 9, 40, 10, 157, 11, 40, 12, 40, 2, 7, 1, 2, 5, CID_NIL, 0, 1, 6, CID_CON, 2, 1, 0, 90, 1, 75, 7, 1, 2, 7, CID_FALSE, 0, 0, 8, CID_TRUE, 0, 0, 7, 0, 1, 9, CID_UNIT, 0, 0, 7, 0, 1, 10, CID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_FULLCELL, 2, 0, 0, 74, 1, 119, 7, 1, 2, 11, CID_NIL, 0, 1, 12, CID_CON, 2, 1, 0, 134, 1, 119, 0, 7, 1, 2, 13, CID_NIL, 0, 1, 14, CID_CON, 2, 1, 0, 150, 1, 135, 7, 1, 1, 15, CID_UNIT, 0, 0, 7, 1, 2, 16, CID_NIL, 0, 1, 17, CID_CON, 2, 1, 0, 172, 1, 157, 7, 1, 1, 18, CID__________________________________BENDVY_SRC_ECS_WORLD_REGISTRATIONMETA, 3, 0, 0, 40, 1, 185, 2, 186, 4, 7, 1, 2, 19, CID_NIL, 0, 1, 20, CID_CON, 2, 1, 0, 185, 1, 186, 7, 1, 2, 21, CID_NIL, 0, 1, 22, CID_CON, 2, 1, 0, 216, 1, 201, 7, 1, 2, 23, CID_NONE, 0, 0, 24, CID_SOME, 1, 0, 0, 229, 7, 1, 1, 25, CID_APP_DESCRIPTION, 5, 0, 0, 246, 1, 40, 2, 185, 3, 297, 4, 333, 7, 1, 2, 26, CID_NIL, 0, 1, 27, CID_CON, 2, 1, 0, 261, 1, 246, 7, 1, 1, 28, CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_ENTRY, 3, 0, 0, 274, 1, 185, 2, 185, 7, 0, 5, 29, CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_COMPONENT, 0, 0, 30, CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_RESOURCE, 0, 0, 31, CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_EVENT, 0, 0, 32, CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_RELATION, 0, 0, 33, CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_SERVICE, 0, 0, 7, 1, 2, 34, CID_NIL, 0, 1, 35, CID_CON, 2, 1, 0, 312, 1, 297, 7, 1, 3, 36, CID__________________________________BENDVY_SRC_ECS_SCHEDULE_SYSTEM, 2, 0, 0, 40, 1, 40, 37, CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PHASE, 1, 0, 0, 185, 38, CID__________________________________BENDVY_SRC_ECS_SCHEDULE_BARRIER, 0, 0, 7, 1, 2, 39, CID_NIL, 0, 1, 40, CID_CON, 2, 1, 0, 348, 1, 333, 7, 1, 1, 41, CID_APP_ENTRY, 5, 0, 0, 40, 1, 185, 2, 186, 3, 185, 4, 365, 7, 1, 2, 42, CID_NIL, 0, 1, 43, CID_CON, 2, 1, 0, 380, 1, 365, 7, 1, 1, 44, CID____DECLARATION_CLAUSE, 2, 0, 0, 185, 1, 391, 7, 0, 7, 45, CID____DECLARATION_READ, 0, 0, 46, CID____DECLARATION_WRITE, 0, 0, 47, CID____DECLARATION_OPTIONAL, 0, 0, 48, CID____DECLARATION_WITH, 0, 0, 49, CID____DECLARATION_WITHOUT, 0, 0, 50, CID____DECLARATION_ADDED, 0, 0, 51, CID____DECLARATION_CHANGED, 0, 0 };

static const char* SHOW_NAMES[] = { "Reported", "BuildRejected", "CreateRejected", "Report", "Snapshot", "Nil", "Con", "False", "True", "Unit", "../../../../../../../../../../../bendvy/experiments/public-simulation/bend-v1/owner-view.FullCell", "Nil", "Con", "Nil", "Con", "Unit", "Nil", "Con", "../../../../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "Nil", "Con", "Nil", "Con", "None", "Some", "app.Description", "Nil", "Con", "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Component", "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Resource", "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Event", "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Relation", "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Service", "Nil", "Con", "../../../../../../../../../../../bendvy/src/ecs/schedule.System", "../../../../../../../../../../../bendvy/src/ecs/schedule.Phase", "../../../../../../../../../../../bendvy/src/ecs/schedule.Barrier", "Nil", "Con", "app.Entry", "Nil", "Con", "../declaration.Clause", "../declaration.Read", "../declaration.Write", "../declaration.Optional", "../declaration.With", "../declaration.Without", "../declaration.Added", "../declaration.Changed" };

#endif

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 115ull, term_pak(CID_SNIL, 0), 103ull, term_ctr(CID_SCON, STAT_OFF + 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 2), 105ull, term_ctr(CID_SCON, STAT_OFF + 4), 116ull, term_ctr(CID_SCON, STAT_OFF + 6), 116ull, term_ctr(CID_SCON, STAT_OFF + 8), 101ull, term_ctr(CID_SCON, STAT_OFF + 10), 83ull, term_ctr(CID_SCON, STAT_OFF + 12), 101ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 16), 97ull, term_ctr(CID_SCON, STAT_OFF + 18), 100ull, term_ctr(CID_SCON, STAT_OFF + 20), 112ull, term_ctr(CID_SCON, STAT_OFF + 22), 85ull, term_ctr(CID_SCON, STAT_OFF + 24), 1, term_ctr(CID_SCON, STAT_OFF + 26), 0, term_pak(CID_NIL, 0) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _a_0 = r0;
  u32 _a_1 = r1;
  u32 _b_0 = r2;
  u32 _b_1 = r3;
  WL_SPIN
    if (_a_0 == 0) {
      if (_b_0 == 0) {
        _v_2 = U32_BIN(_a_1, ==, _b_1);
      } else {
        _v_2 = 0;
      }
    } else if (_a_0 == 1) {
      if (_b_0 == 1) {
        _v_2 = U32_BIN(_a_1, ==, _b_1);
      } else {
        _v_2 = 0;
      }
    } else {
      if (_b_0 == 2) {
        _v_2 = U32_BIN(_a_1, ==, _b_1);
      } else {
        _v_2 = 0;
      }
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_1 = 0;
  u32 _present_0 = r0;
  u32 _item_0 = r1;
  u32 _item_1 = r2;
  Term _rest_0 = r3;
  WL_SPIN
    if (_present_0 == 1) {
      _v_1 = _rest_0;
    } else {
      Term _b_1 = 0;
      if (_item_0 == 0) {
        _b_1 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_COMPONENT, _item_1);
      } else if (_item_0 == 1) {
        _b_1 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_RESOURCE, _item_1);
      } else {
        _b_1 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_SERVICE, _item_1);
      }
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _b_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _rest_0);
      _v_1 = term_ctr(CID_CON, _nd_1);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_3 = 1;
    } else {
      _v_3 = 0;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _a_0 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_5 = 0;
    } else {
      _v_5 = _b_1;
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_2 = 0;
  Term _v_3 = 0;
  u32 _value_0 = r0;
  Term _got_3 = r1;
  Term _got_4 = r2;
  WL_SPIN
    Term _b_0 = 0;
    if (_value_0 == 0) {
      _b_0 = term_pak(CID_FALSE, 0);
    } else {
      _b_0 = term_pak(CID_TRUE, 0);
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _got_4);
    _v_2 = _got_3;
    _v_3 = term_ctr(CID_CON, _nd_0);
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  u32 _allowed_0 = r0;
  u32 _namespace_2 = r1;
  Term _name_2 = r2;
  Term _steps_2 = r3;
  WL_SPIN
    if (_allowed_0 == 0) {
      term_sink(e, _name_2);
      term_sink(e, _steps_2);
      _v_4 = 1;
      _v_5 = 0;
      _v_6 = 0;
      _v_7 = 0;
    } else {
      _v_4 = 0;
      _v_5 = _namespace_2;
      _v_6 = _name_2;
      _v_7 = _steps_2;
    }
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_2 = 0;
  Term _v_3 = 0;
  u32 _value_0 = r0;
  Term _observed_3 = r1;
  Term _observed_4 = r2;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _value_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _observed_4);
    _v_2 = _observed_3;
    _v_3 = term_ctr(CID_CON, _nd_0);
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  u32 _v_3 = 0;
  Term _command_0 = r0;
  Term _counted_0 = r1;
  u32 _counted_1 = r2;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _command_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _counted_0);
    _v_2 = term_ctr(CID_CON, _nd_0);
    _v_3 = U32_BIN(_counted_1, +, 1ull);
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  u32 _built_0 = r0;
  u32 _built_1 = r1;
  Term _built_2 = r2;
  Term _built_3 = r3;
  Term _needs_0 = r4;
  WL_SPIN
    if (_built_0 == 1) {
      term_sink(e, _needs_0);
      _v_5 = 1;
      _v_6 = 0;
      _v_7 = 0;
      _v_8 = 0;
      _v_9 = 0;
    } else {
      _v_5 = 0;
      _v_6 = _built_1;
      _v_7 = _built_2;
      _v_8 = _built_3;
      _v_9 = _needs_0;
    }
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _namespace_0 = r0;
  u32 _nextId_0 = r1;
  u32 _highWater_0 = r2;
  Term _live_0 = r3;
  u32 _capacity_0 = r4;
  Term _depth_0 = r5;
  Term _resource_0 = r6;
  Term _events_0 = r7;
  Term _registrations_0 = r8;
  u32 _nextSystemId_0 = r9;
  u32 _clock_0 = r10;
  Term _counted_0 = r11;
  u32 _counted_1 = r12;
  WL_SPIN
    _v_13 = _namespace_0;
    _v_14 = _nextId_0;
    _v_15 = _highWater_0;
    _v_16 = _live_0;
    _v_17 = _capacity_0;
    _v_18 = _depth_0;
    _v_19 = _resource_0;
    _v_20 = _events_0;
    _v_21 = _counted_0;
    _v_22 = _registrations_0;
    _v_23 = _nextSystemId_0;
    _v_24 = _clock_0;
    _v_25 = _counted_1;
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  o[5] = _v_18;
  o[6] = _v_19;
  o[7] = _v_20;
  o[8] = _v_21;
  o[9] = _v_22;
  o[10] = _v_23;
  o[11] = _v_24;
  o[12] = _v_25;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _resourceView_4 = r0;
  Term _resourceView_5 = r1;
  u32 _pendingCount_0 = r2;
  u32 _namespace_0 = r3;
  u32 _nextId_0 = r4;
  u32 _highWater_0 = r5;
  u32 _capacity_0 = r6;
  Term _depth_0 = r7;
  Term _resource_0 = r8;
  Term _events_0 = r9;
  Term _pending_0 = r10;
  Term _registrations_0 = r11;
  u32 _nextSystemId_0 = r12;
  u32 _clock_0 = r13;
  Term _got_25 = r14;
  Term _got_26 = r15;
  WL_SPIN
    _events_0 = term_keep(e, _events_0, 1);
    _registrations_0 = term_keep(e, _registrations_0, 1);
    _v_25 = _namespace_0;
    _v_26 = _nextId_0;
    _v_27 = _highWater_0;
    _v_28 = _got_25;
    _v_29 = _capacity_0;
    _v_30 = _depth_0;
    _v_31 = _resource_0;
    _v_32 = _events_0;
    _v_33 = _pending_0;
    _v_34 = _registrations_0;
    _v_35 = _nextSystemId_0;
    _v_36 = _clock_0;
    _v_37 = _namespace_0;
    _v_38 = _nextId_0;
    _v_39 = _highWater_0;
    _v_40 = _capacity_0;
    _v_41 = _depth_0;
    _v_42 = _got_26;
    _v_43 = _resourceView_4;
    _v_44 = _resourceView_5;
    _v_45 = _events_0;
    _v_46 = _pendingCount_0;
    _v_47 = _registrations_0;
    _v_48 = _nextSystemId_0;
    _v_49 = _clock_0;
  break;
  }
  o[0] = _v_25;
  o[1] = _v_26;
  o[2] = _v_27;
  o[3] = _v_28;
  o[4] = _v_29;
  o[5] = _v_30;
  o[6] = _v_31;
  o[7] = _v_32;
  o[8] = _v_33;
  o[9] = _v_34;
  o[10] = _v_35;
  o[11] = _v_36;
  o[12] = _v_37;
  o[13] = _v_38;
  o[14] = _v_39;
  o[15] = _v_40;
  o[16] = _v_41;
  o[17] = _v_42;
  o[18] = _v_43;
  o[19] = _v_44;
  o[20] = _v_45;
  o[21] = _v_46;
  o[22] = _v_47;
  o[23] = _v_48;
  o[24] = _v_49;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _factory_3 = r0;
  WL_SPIN
    _v_2 = _factory_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, Term r6, u64 q6, Term r7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, u32 r26, Term r27, Term r28, u64 q28, Term r29, u64 q29, Term r30, u64 q30, Term r31, u64 q31, u32 r32, u32 r33, u32 r34, u32 r35, u32 r36, u32 r37, Term r38, Term r39, u64 q39, Term r40, Term r41, u64 q41, Term r42, u64 q42, u32 r43, Term r44, u64 q44, u32 r45, u32 r46) {
  u32 wpoll = 0;
  Term h6 = r6;
  Term h8 = r8;
  Term h9 = r9;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h25 = r25;
  Term h28 = r28;
  Term h29 = r29;
  Term h30 = r30;
  Term h31 = r31;
  Term h39 = r39;
  Term h41 = r41;
  Term h42 = r42;
  Term h44 = r44;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  u32 _v_43 = 0;
  Term _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  u32 _next_0 = r0;
  u32 _before_39 = r1;
  u32 _before_40 = r2;
  u32 _before_41 = r3;
  u32 _before_42 = r4;
  Term _before_43 = r5;
  Term _before_44 = r6;
  Term _before_45 = r7;
  Term _before_46 = r8;
  Term _before_47 = r9;
  u32 _before_48 = r10;
  Term _before_49 = r11;
  u32 _before_50 = r12;
  u32 _before_51 = r13;
  Term _app_0 = r14;
  u32 _app_1 = r15;
  Term _app_2 = r16;
  u32 _app_3 = r17;
  Term _app_4 = r18;
  Term _app_5 = r19;
  Term _app_6 = r20;
  Term _descriptions_1 = r21;
  u32 _got_27 = r22;
  u32 _got_28 = r23;
  u32 _got_29 = r24;
  Term _got_30 = r25;
  u32 _got_31 = r26;
  Term _got_32 = r27;
  Term _got_33 = r28;
  Term _got_34 = r29;
  Term _got_35 = r30;
  Term _got_36 = r31;
  u32 _got_37 = r32;
  u32 _got_38 = r33;
  u32 _got_39 = r34;
  u32 _got_40 = r35;
  u32 _got_41 = r36;
  u32 _got_42 = r37;
  Term _got_43 = r38;
  Term _got_44 = r39;
  Term _got_45 = r40;
  Term _got_46 = r41;
  Term _got_47 = r42;
  u32 _got_48 = r43;
  Term _got_49 = r44;
  u32 _got_50 = r45;
  u32 _got_51 = r46;
  WL_SPIN
    term_sink(e, _app_0);
    term_sink(e, _app_2);
    term_sink(e, _app_4);
    term_sink(e, _app_5);
    term_sink(e, _app_6);
    term_sink(e, _got_30);
    term_sink(e, _got_33);
    term_sink(e, _got_34);
    term_sink(e, _got_35);
    term_sink(e, _got_36);
    _v_32 = 0;
    _v_33 = _next_0;
    _v_34 = _before_39;
    _v_35 = _before_40;
    _v_36 = _before_41;
    _v_37 = _before_42;
    _v_38 = _before_43;
    _v_39 = _before_44;
    _v_40 = _before_45;
    _v_41 = _before_46;
    _v_42 = _before_47;
    _v_43 = _before_48;
    _v_44 = _before_49;
    _v_45 = _before_50;
    _v_46 = _before_51;
    _v_47 = _got_39;
    _v_48 = _got_40;
    _v_49 = _got_41;
    _v_50 = _got_42;
    _v_51 = _got_43;
    _v_52 = _got_44;
    _v_53 = _got_45;
    _v_54 = _got_46;
    _v_55 = _got_47;
    _v_56 = _got_48;
    _v_57 = _got_49;
    _v_58 = _got_50;
    _v_59 = _got_51;
    _v_60 = _descriptions_1;
  break;
  }
  o[0] = _v_32;
  o[1] = _v_33;
  o[2] = _v_34;
  o[3] = _v_35;
  o[4] = _v_36;
  o[5] = _v_37;
  o[6] = _v_38;
  o[7] = _v_39;
  o[8] = _v_40;
  o[9] = _v_41;
  o[10] = _v_42;
  o[11] = _v_43;
  o[12] = _v_44;
  o[13] = _v_45;
  o[14] = _v_46;
  o[15] = _v_47;
  o[16] = _v_48;
  o[17] = _v_49;
  o[18] = _v_50;
  o[19] = _v_51;
  o[20] = _v_52;
  o[21] = _v_53;
  o[22] = _v_54;
  o[23] = _v_55;
  o[24] = _v_56;
  o[25] = _v_57;
  o[26] = _v_58;
  o[27] = _v_59;
  o[28] = _v_60;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_8 = 0;
  Term _v_9 = 0;
  u32 _v_10 = 0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _schema_0 = r0;
  u32 _debug_0 = r1;
  Term _bindings_0 = r2;
  u32 _result_0 = r3;
  u32 _result_1 = r4;
  Term _result_2 = r5;
  Term _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _schema_0);
      term_sink(e, _bindings_0);
      _v_8 = 1;
      _v_9 = 0;
      _v_10 = 0;
      _v_11 = 0;
      _v_12 = 0;
      _v_13 = 0;
      _v_14 = 0;
      _v_15 = 0;
    } else {
      _v_8 = 0;
      _v_9 = _schema_0;
      _v_10 = _debug_0;
      _v_11 = _bindings_0;
      _v_12 = _result_1;
      _v_13 = _result_2;
      _v_14 = _result_3;
      _v_15 = _result_4;
    }
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, Term r18, u64 q18, Term r19, u64 q19, u32 r20, Term r21, u64 q21, u32 r22, Term r23, u64 q23, Term r24, u64 q24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term h18 = r18;
  Term h19 = r19;
  Term h21 = r21;
  Term h23 = r23;
  Term h24 = r24;
  Term h25 = r25;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  u32 _factory_2 = r0;
  u32 _world_24 = r1;
  u32 _world_25 = r2;
  u32 _world_26 = r3;
  Term _world_27 = r4;
  u32 _world_28 = r5;
  Term _world_29 = r6;
  Term _world_30 = r7;
  Term _world_31 = r8;
  Term _world_32 = r9;
  Term _world_33 = r10;
  u32 _world_34 = r11;
  u32 _world_35 = r12;
  Term _got_0 = r13;
  u32 _got_1 = r14;
  Term _got_2 = r15;
  u32 _got_3 = r16;
  Term _got_4 = r17;
  Term _got_5 = r18;
  Term _got_6 = r19;
  u32 _got_7 = r20;
  Term _got_8 = r21;
  u32 _got_9 = r22;
  Term _got_10 = r23;
  Term _got_11 = r24;
  Term _got_12 = r25;
  WL_SPIN
    _v_27 = 0;
    _v_28 = _factory_2;
    _v_29 = _world_24;
    _v_30 = _world_25;
    _v_31 = _world_26;
    _v_32 = _world_27;
    _v_33 = _world_28;
    _v_34 = _world_29;
    _v_35 = _world_30;
    _v_36 = _world_31;
    _v_37 = _world_32;
    _v_38 = _world_33;
    _v_39 = _world_34;
    _v_40 = _world_35;
    _v_41 = _got_0;
    _v_42 = _got_1;
    _v_43 = _got_2;
    _v_44 = _got_3;
    _v_45 = _got_4;
    _v_46 = _got_5;
    _v_47 = _got_6;
    _v_48 = _got_7;
    _v_49 = _got_8;
    _v_50 = _got_9;
    _v_51 = _got_10;
    _v_52 = _got_11;
    _v_53 = _got_12;
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  o[5] = _v_32;
  o[6] = _v_33;
  o[7] = _v_34;
  o[8] = _v_35;
  o[9] = _v_36;
  o[10] = _v_37;
  o[11] = _v_38;
  o[12] = _v_39;
  o[13] = _v_40;
  o[14] = _v_41;
  o[15] = _v_42;
  o[16] = _v_43;
  o[17] = _v_44;
  o[18] = _v_45;
  o[19] = _v_46;
  o[20] = _v_47;
  o[21] = _v_48;
  o[22] = _v_49;
  o[23] = _v_50;
  o[24] = _v_51;
  o[25] = _v_52;
  o[26] = _v_53;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_3 = 0;
  Term _v_4 = 0;
  Term _v_5 = 0;
  Term _length_0 = r0;
  Term _observed_3 = r1;
  Term _observed_4 = r2;
  WL_SPIN
    _v_3 = _observed_3;
    _v_4 = _length_0;
    _v_5 = _observed_4;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, u64 q0, Term r1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h6 = r6;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  u32 _namespace_0 = r3;
  u32 _nextId_0 = r4;
  u32 _highWater_0 = r5;
  Term _live_0 = r6;
  u32 _capacity_0 = r7;
  Term _depth_0 = r8;
  Term _events_0 = r9;
  Term _pending_0 = r10;
  Term _registrations_0 = r11;
  u32 _nextSystemId_0 = r12;
  u32 _clock_0 = r13;
  WL_SPIN
    _v_14 = _namespace_0;
    _v_15 = _nextId_0;
    _v_16 = _highWater_0;
    _v_17 = _live_0;
    _v_18 = _capacity_0;
    _v_19 = _depth_0;
    _v_20 = _observed_0;
    _v_21 = _events_0;
    _v_22 = _pending_0;
    _v_23 = _registrations_0;
    _v_24 = _nextSystemId_0;
    _v_25 = _clock_0;
    _v_26 = _observed_1;
    _v_27 = _observed_2;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _catalog_0 = r0;
  WL_SPIN
    _v_2 = _catalog_0;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _app_0 = r0;
  u32 _app_1 = r1;
  Term _app_2 = r2;
  u32 _app_3 = r3;
  Term _app_4 = r4;
  Term _app_5 = r5;
  Term _app_6 = r6;
  WL_SPIN
    _v_14 = _app_0;
    _v_15 = 1;
    _v_16 = _app_2;
    _v_17 = _app_3;
    _v_18 = _app_4;
    _v_19 = _app_5;
    _v_20 = _app_6;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  Term _resource_1 = r2;
  WL_SPIN
    if (_available_0 == 0) {
      _v_14 = 1;
      _v_15 = _namespace_0;
      _v_16 = _resource_1;
      _v_17 = 0;
      _v_18 = 0;
      _v_19 = 0;
      _v_20 = 0;
      _v_21 = 0;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
      _v_26 = 0;
      _v_27 = 0;
    } else {
      Term _fv_0[1];
      _fv_0[0] = 0;
      _v_14 = 0;
      _v_15 = U32_BIN(_namespace_0, +, 1ull);
      _v_16 = _namespace_0;
      _v_17 = 1ull;
      _v_18 = 0ull;
      _v_19 = blk_new(e, 0, 0, 0, 1, _fv_0);
      _v_20 = 1ull;
      _v_21 = 0;
      _v_22 = _resource_1;
      _v_23 = term_pak(CID_NIL, 0);
      _v_24 = term_pak(CID_NIL, 0);
      _v_25 = term_pak(CID_NIL, 0);
      _v_26 = 1ull;
      _v_27 = 0ull;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  u32 _namespace_0 = r0;
  u32 _debug_0 = r1;
  Term _schema_1 = r2;
  WL_SPIN
    _v_10 = _schema_1;
    _v_11 = _debug_0;
    _v_12 = _namespace_0;
    _v_13 = term_pak(CID_NIL, 0);
    _v_14 = 1;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, Term r17, Term r18, u64 q18, Term r19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, Term r23, u64 q23, u32 r24, u32 r25) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h18 = r18;
  Term h20 = r20;
  Term h21 = r21;
  Term h23 = r23;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  Term _v_78 = 0;
  Term _v_79 = 0;
  u32 _v_80 = 0;
  u32 _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  Term _v_95 = 0;
  Term _v_96 = 0;
  Term _v_97 = 0;
  Term _v_98 = 0;
  Term _v_99 = 0;
  u32 _v_100 = 0;
  Term _v_101 = 0;
  u32 _v_102 = 0;
  u32 _v_103 = 0;
  Term _v_104 = 0;
  u32 _next_0 = r0;
  u32 _got_0 = r1;
  u32 _got_1 = r2;
  u32 _got_2 = r3;
  Term _got_3 = r4;
  u32 _got_4 = r5;
  Term _got_5 = r6;
  Term _got_6 = r7;
  Term _got_7 = r8;
  Term _got_8 = r9;
  Term _got_9 = r10;
  u32 _got_10 = r11;
  u32 _got_11 = r12;
  u32 _got_12 = r13;
  u32 _got_13 = r14;
  u32 _got_14 = r15;
  u32 _got_15 = r16;
  Term _got_16 = r17;
  Term _got_17 = r18;
  Term _got_18 = r19;
  Term _got_19 = r20;
  Term _got_20 = r21;
  u32 _got_21 = r22;
  Term _got_22 = r23;
  u32 _got_23 = r24;
  u32 _got_24 = r25;
  WL_SPIN
    term_sink(e, _got_3);
    term_sink(e, _got_6);
    term_sink(e, _got_7);
    term_sink(e, _got_8);
    term_sink(e, _got_9);
    _v_76 = 1;
    _v_77 = _next_0;
    _v_78 = _got_12;
    _v_79 = _got_13;
    _v_80 = _got_14;
    _v_81 = _got_15;
    _v_82 = _got_16;
    _v_83 = _got_17;
    _v_84 = _got_18;
    _v_85 = _got_19;
    _v_86 = _got_20;
    _v_87 = _got_21;
    _v_88 = _got_22;
    _v_89 = _got_23;
    _v_90 = _got_24;
    _v_91 = 0;
    _v_92 = 0;
    _v_93 = 0;
    _v_94 = 0;
    _v_95 = 0;
    _v_96 = 0;
    _v_97 = 0;
    _v_98 = 0;
    _v_99 = 0;
    _v_100 = 0;
    _v_101 = 0;
    _v_102 = 0;
    _v_103 = 0;
    _v_104 = 0;
  break;
  }
  o[0] = _v_76;
  o[1] = _v_77;
  o[2] = _v_78;
  o[3] = _v_79;
  o[4] = _v_80;
  o[5] = _v_81;
  o[6] = _v_82;
  o[7] = _v_83;
  o[8] = _v_84;
  o[9] = _v_85;
  o[10] = _v_86;
  o[11] = _v_87;
  o[12] = _v_88;
  o[13] = _v_89;
  o[14] = _v_90;
  o[15] = _v_91;
  o[16] = _v_92;
  o[17] = _v_93;
  o[18] = _v_94;
  o[19] = _v_95;
  o[20] = _v_96;
  o[21] = _v_97;
  o[22] = _v_98;
  o[23] = _v_99;
  o[24] = _v_100;
  o[25] = _v_101;
  o[26] = _v_102;
  o[27] = _v_103;
  o[28] = _v_104;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  Term _v_138 = 0;
  Term _v_139 = 0;
  u32 _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  Term _v_143 = 0;
  Term _v_144 = 0;
  Term _v_145 = 0;
  Term _v_146 = 0;
  u32 _v_147 = 0;
  Term _v_148 = 0;
  u32 _v_149 = 0;
  u32 _v_150 = 0;
  u32 _v_151 = 0;
  u32 _v_152 = 0;
  u32 _v_153 = 0;
  u32 _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  Term _v_157 = 0;
  Term _v_158 = 0;
  Term _v_159 = 0;
  u32 _v_160 = 0;
  Term _v_161 = 0;
  u32 _v_162 = 0;
  u32 _v_163 = 0;
  Term _v_164 = 0;
  u32 _next_1 = r0;
  Term _got_25 = r1;
  Term _got_26 = r2;
  Term _got_27 = r3;
  WL_SPIN
    term_sink(e, _got_25);
    _v_136 = 2;
    _v_137 = _next_1;
    _v_138 = _got_26;
    _v_139 = _got_27;
    _v_140 = 0;
    _v_141 = 0;
    _v_142 = 0;
    _v_143 = 0;
    _v_144 = 0;
    _v_145 = 0;
    _v_146 = 0;
    _v_147 = 0;
    _v_148 = 0;
    _v_149 = 0;
    _v_150 = 0;
    _v_151 = 0;
    _v_152 = 0;
    _v_153 = 0;
    _v_154 = 0;
    _v_155 = 0;
    _v_156 = 0;
    _v_157 = 0;
    _v_158 = 0;
    _v_159 = 0;
    _v_160 = 0;
    _v_161 = 0;
    _v_162 = 0;
    _v_163 = 0;
    _v_164 = 0;
  break;
  }
  o[0] = _v_136;
  o[1] = _v_137;
  o[2] = _v_138;
  o[3] = _v_139;
  o[4] = _v_140;
  o[5] = _v_141;
  o[6] = _v_142;
  o[7] = _v_143;
  o[8] = _v_144;
  o[9] = _v_145;
  o[10] = _v_146;
  o[11] = _v_147;
  o[12] = _v_148;
  o[13] = _v_149;
  o[14] = _v_150;
  o[15] = _v_151;
  o[16] = _v_152;
  o[17] = _v_153;
  o[18] = _v_154;
  o[19] = _v_155;
  o[20] = _v_156;
  o[21] = _v_157;
  o[22] = _v_158;
  o[23] = _v_159;
  o[24] = _v_160;
  o[25] = _v_161;
  o[26] = _v_162;
  o[27] = _v_163;
  o[28] = _v_164;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0)
  {
    Term _items_0 = r0;
    u32 _item_0 = r1;
    u32 _item_1 = r2;
    WL_OPEN
    WL_SPIN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _items_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      if (term_aux(_f_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_COMPONENT) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_RESOURCE) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      }
      if (seq) {
        WL_ROOM(5);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _item_0;
        STK(3) = _item_1;
        STK(4) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K2;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K2, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _item_0;
        e.mem[_t_0 + 3] = _item_1;
        WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K2, _t_0);
        WL_IDX = 4;
      }
      r0 = _f_1;
      r1 = _item_0;
      r2 = _item_1;
      _items_0 = r0;
      _item_0 = r1;
      _item_1 = r2;
      WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K2)
  {
    WL_POPN(4);
    u32 _o_2 = STK(0);
    u32 _o_3 = STK(1);
    u32 _item_2 = STK(2);
    u32 _item_3 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_4[1];
    if (spin_0(e, _o_4, _o_2, _o_3, _item_2, _item_3) == 0) {
      return 0;
    }
    _v_1 = _o_4[0];
    _v_0 = _v_1;
    r0 = ((_v_0) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS)
  {
    Term _ids_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_ids_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _ids_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _id_0;
        STK(2) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS_K6;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS_K6, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS_K6, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _id_0;
      _ids_0 = r0;
      _id_0 = r1;
      WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS_K6)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _id_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_f_2, ==, _id_1)) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0)
  {
    Term _items_0 = r0;
    Term _seen_0 = r1;
    WL_OPEN
    if (term_aux(_items_0) == CID_NIL) {
      term_sink(e, _seen_0);
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      if (term_aux(_f_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_COMPONENT) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_RESOURCE) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _f_1;
        STK(3) = _seen_0;
        STK(4) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K10;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K10, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _f_1;
        e.mem[_t_0 + 3] = _seen_0;
        WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K10, _t_0);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0)) {
        u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _seen_0;
        e.mem[_t_1 + 1] = _o_0;
        e.mem[_t_1 + 2] = _o_1;
        return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0, _t_1);
      }
      r0 = _seen_0;
      r1 = _o_0;
      r2 = _o_1;
      WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K10)
  {
    WL_POPN(4);
    u32 _o_2 = STK(0);
    u32 _o_3 = STK(1);
    Term _f_2 = STK(2);
    Term _seen_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    Term _b_0 = 0;
    if (_o_2 == 0) {
      _b_0 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_COMPONENT, _o_3);
    } else if (_o_2 == 1) {
      _b_0 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_RESOURCE, _o_3);
    } else {
      _b_0 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_SERVICE, _o_3);
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _seen_1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _o_2;
      STK(1) = _o_3;
      STK(2) = _h_0;
      STK(3) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K11;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K11, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_2;
      e.mem[_t_2 + 1] = _o_3;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K11, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0)) {
      u64 _t_3 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, _t_3);
    }
    r0 = _f_2;
    r1 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K11)
  {
    WL_POPN(3);
    u32 _o_4 = STK(0);
    u32 _o_5 = STK(1);
    u32 _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_6[1];
    if (spin_1(e, _o_6, _h_2, _o_4, _o_5, _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_6[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID)
  {
    Term _steps_0 = r0;
    Term _catalog_0 = r1;
    Term _seen_0 = r2;
    WL_OPEN
    WL_SPIN
    if (term_aux(_steps_0) == CID_NIL) {
      term_sink(e, _catalog_0);
      term_sink(e, _seen_0);
      r0 = 1;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (term_aux(_f_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_SYSTEM) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PHASE) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else {
        _o_0 = 2;
      }
      if (_o_0 == 1) {
        term_sink(e, _o_1);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_1;
        r1 = _catalog_0;
        r2 = _seen_0;
        _steps_0 = r0;
        _catalog_0 = r1;
        _seen_0 = r2;
        WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_1;
        r1 = _catalog_0;
        r2 = _seen_0;
        _steps_0 = r0;
        _catalog_0 = r1;
        _seen_0 = r2;
        WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID);
      } else {
        _catalog_0 = term_keep(e, _catalog_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(5);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _catalog_0;
          STK(3) = _seen_0;
          STK(4) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K13;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K13, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _f_1;
          e.mem[_t_0 + 2] = _catalog_0;
          e.mem[_t_0 + 3] = _seen_0;
          WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K13, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS)) {
          u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _catalog_0;
          e.mem[_t_1 + 1] = _o_1;
          return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS, _t_1);
        }
        r0 = _catalog_0;
        r1 = _o_1;
        WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K13)
  {
    WL_POPN(4);
    u32 _o_3 = STK(0);
    Term _f_5 = STK(1);
    Term _catalog_1 = STK(2);
    Term _seen_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    _seen_1 = term_keep(e, _seen_1, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _o_3;
      STK(1) = _f_5;
      STK(2) = _catalog_1;
      STK(3) = _seen_1;
      STK(4) = _h_0;
      STK(5) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K14;
      WL_PUSHN(6);
    } else {
      u64 _t_2 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K14, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_3;
      e.mem[_t_2 + 1] = _f_5;
      e.mem[_t_2 + 2] = _catalog_1;
      e.mem[_t_2 + 3] = _seen_1;
      e.mem[_t_2 + 4] = _h_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K14, _t_2);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS)) {
      u64 _t_3 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _seen_1;
      e.mem[_t_3 + 1] = _o_3;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS, _t_3);
    }
    r0 = _seen_1;
    r1 = _o_3;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_CONTAINS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K14)
  {
    WL_POPN(5);
    u32 _o_4 = STK(0);
    Term _f_6 = STK(1);
    Term _catalog_2 = STK(2);
    Term _seen_2 = STK(3);
    u32 _h_2 = STK(4);
    u32 _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _o_4);
    e.mem[_nd_0 + 1] = rfc_seal(e, _seen_2);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K15;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K15, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K15, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID)) {
      u64 _t_5 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = _catalog_2;
      e.mem[_t_5 + 2] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID, _t_5);
    }
    r0 = _f_6;
    r1 = _catalog_2;
    r2 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID_K15)
  {
    WL_POPN(2);
    u32 _h_4 = STK(0);
    u32 _h_5 = STK(1);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _o_5[1];
    if (spin_2(e, _o_5, _h_5) == 0) {
      return 0;
    }
    _v_2 = _o_5[0];
    _v_1 = _v_2;
    u32 _v_4 = 0;
    Term _o_6[1];
    if (spin_3(e, _o_6, _v_1, _h_3) == 0) {
      return 0;
    }
    _v_4 = _o_6[0];
    _v_0 = _v_4;
    u32 _v_6 = 0;
    Term _o_7[1];
    if (spin_3(e, _o_7, _h_4, _v_0) == 0) {
      return 0;
    }
    _v_6 = _o_7[0];
    r0 = _v_6;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0)
  {
    Term _plan_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_plan_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_EMPTY) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else if (term_aux(_plan_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_ENTRY) {
      Term _fb_0[4];
      u64 _sp_0 = ctr_take(e, _plan_0, 4, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _f_2 = _fb_0[2];
      Term _f_3 = _fb_0[3];
      term_sink(e, _f_1);
      spare_free(e, cls_fit(4), _sp_0);
      r0 = _f_3;
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _plan_0, 2, _fb_1);
      Term _f_4 = _fb_1[0];
      Term _f_5 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_5;
        STK(1) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K22;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K22, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_5;
        WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K22, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_4;
      _plan_0 = r0;
      WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K22)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K23;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K23, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K23, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0)) {
      u64 _t_2 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, _t_2);
    }
    r0 = _f_6;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K23)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_2;
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0)
  {
    Term _items_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0)) {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _items_0;
      e.mem[_t_0 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, _t_0);
    }
    r0 = _items_0;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0)
  {
    Term _plan_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_plan_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_EMPTY) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else if (term_aux(_plan_0) == CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_ENTRY) {
      Term _fb_0[4];
      u64 _sp_0 = ctr_take(e, _plan_0, 4, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _f_2 = _fb_0[2];
      Term _f_3 = _fb_0[3];
      term_sink(e, _f_3);
      Term _b_0 = 0;
      if (_f_0 == 0) {
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_1);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_2);
        _b_0 = term_ctr(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_SYSTEM, _nd_0);
      } else if (_f_0 == 1) {
        u64 _nd_1 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_1);
        _b_0 = term_ctr(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PHASE, _nd_1);
      } else {
        _b_0 = term_pak(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_BARRIER, 0);
      }
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      spare_free(e, cls_fit(4), _sp_0);
      r0 = term_ctr(CID_CON, _nd_2);
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _plan_0, 2, _fb_1);
      Term _f_4 = _fb_1[0];
      Term _f_5 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_5;
        STK(1) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K26;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K26, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_5;
        WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K26, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_4;
      _plan_0 = r0;
      WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K26)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K27;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K27, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K27, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0)) {
      u64 _t_2 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, _t_2);
    }
    r0 = _f_6;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K27)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_2;
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0)
  {
    u32 _namespace_0 = r0;
    Term _name_0 = r1;
    Term _steps_0 = r2;
    Term _catalog_0 = r3;
    WL_OPEN
    _steps_0 = term_keep(e, _steps_0, 1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _namespace_0;
      STK(1) = _name_0;
      STK(2) = _steps_0;
      STK(3) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0_K29;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0_K29, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      e.mem[_t_0 + 1] = _name_0;
      e.mem[_t_0 + 2] = _steps_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0_K29, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _steps_0;
      e.mem[_t_1 + 1] = _catalog_0;
      e.mem[_t_1 + 2] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID, _t_1);
    }
    r0 = _steps_0;
    r1 = _catalog_0;
    r2 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0_K29)
  {
    WL_POPN(3);
    u32 _namespace_1 = STK(0);
    Term _name_1 = STK(1);
    Term _steps_1 = STK(2);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    if (spin_5(e, _o_0, _h_0, _namespace_1, _name_1, blk_loc(e.mem, _name_1), _steps_1, blk_loc(e.mem, _steps_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0)
  {
    Term _commands_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_commands_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = 0ull;
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K34;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K34, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K34, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _commands_0 = r0;
      WL_AGAIN(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K34)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[2];
    if (spin_7(e, _o_0, _f_2, blk_loc(e.mem, _f_2), _h_0, blk_loc(e.mem, _h_0), _h_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____SCENARIO_OBSERVATION_BITS)
  {
    Term _count_0 = r0;
    u32 _id_0 = r1;
    Term _live_0 = r2;
    WL_OPEN
    if (_count_0 == 0) {
      r0 = _live_0;
      r1 = term_pak(CID_NIL, 0);
      WL_RETN(2);
    } else {
      Term _rest_0 = (_count_0 - 1);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _rest_0;
      e.mem[_nd_0 + 1] = _id_0;
      Term _at_0 = blk_loc(e.mem, _live_0);
      Term _at_1 = blk_at(_live_0, _id_0, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      Term _next_0 = term_clo(FID____SCENARIO_OBSERVATION_BITS_C37, _nd_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _c_0;
        STK(1) = FID____SCENARIO_OBSERVATION_BITS_K39;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID____SCENARIO_OBSERVATION_BITS_K39, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _c_0;
        WL_CONT = term_tsk(FID____SCENARIO_OBSERVATION_BITS_K39, _t_2);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _next_0;
        e.mem[_t_3 + 1] = _live_0;
        return term_tsk(FID_CLO_APPLY, _t_3);
      }
      r0 = _next_0;
      r1 = _live_0;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID____SCENARIO_OBSERVATION_BITS_C37)
  {
    Term _rest_1 = r0;
    u32 _id_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID____SCENARIO_OBSERVATION_BITS_K38;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID____SCENARIO_OBSERVATION_BITS_K38, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID____SCENARIO_OBSERVATION_BITS_K38, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID____SCENARIO_OBSERVATION_BITS)) {
      u64 _t_1 = task_node(e, FID____SCENARIO_OBSERVATION_BITS, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _rest_1;
      e.mem[_t_1 + 1] = U32_BIN(_id_1, +, 1ull);
      e.mem[_t_1 + 2] = _x_0;
      return term_tsk(FID____SCENARIO_OBSERVATION_BITS, _t_1);
    }
    r0 = _rest_1;
    r1 = U32_BIN(_id_1, +, 1ull);
    r2 = _x_0;
    WL_JMP(FID____SCENARIO_OBSERVATION_BITS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____SCENARIO_OBSERVATION_BITS_K38)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____SCENARIO_OBSERVATION_BITS_K39)
  {
    WL_POPN(1);
    u32 _c_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[2];
    if (spin_4(e, _o_0, _c_1, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K42;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K42, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K42, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K42)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_IDS_0)
  {
    Term _bindings_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_bindings_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _bindings_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      u32 _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      Term _f_5 = e.mem[_sp_1 + 3];
      Term _f_6 = e.mem[_sp_1 + 4];
      Term _f_7 = e.mem[_sp_1 + 5];
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_3;
        STK(1) = FID_APP_IDS_0_K45;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_APP_IDS_0_K45, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        WL_CONT = term_tsk(FID_APP_IDS_0_K45, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _bindings_0 = r0;
      WL_AGAIN(FID_APP_IDS_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_IDS_0_K45)
  {
    WL_POPN(1);
    u32 _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_8);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0)
  {
    u32 _namespace_0 = r0;
    Term _name_0 = r1;
    Term _plan_0 = r2;
    Term _catalog_0 = r3;
    WL_OPEN
    _plan_0 = term_keep(e, _plan_0, 1);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _namespace_0;
      STK(1) = _name_0;
      STK(2) = _plan_0;
      STK(3) = _catalog_0;
      STK(4) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K47;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K47, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      e.mem[_t_0 + 1] = _name_0;
      e.mem[_t_0 + 2] = _plan_0;
      e.mem[_t_0 + 3] = _catalog_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K47, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _plan_0;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, _t_1);
    }
    r0 = _plan_0;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K47)
  {
    WL_POPN(4);
    u32 _namespace_1 = STK(0);
    Term _name_1 = STK(1);
    Term _plan_1 = STK(2);
    Term _catalog_1 = STK(3);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _plan_1;
      STK(1) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K48;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K48, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _plan_1;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K48, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0)) {
      u64 _t_3 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _namespace_1;
      e.mem[_t_3 + 1] = _name_1;
      e.mem[_t_3 + 2] = _h_0;
      e.mem[_t_3 + 3] = _catalog_1;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0, _t_3);
    }
    r0 = _namespace_1;
    r1 = _name_1;
    r2 = _h_0;
    r3 = _catalog_1;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_BUILD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K48)
  {
    WL_POPN(1);
    Term _plan_2 = STK(0);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_1;
      STK(1) = _h_2;
      STK(2) = _h_3;
      STK(3) = _h_4;
      STK(4) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K49;
      WL_PUSHN(5);
    } else {
      u64 _t_4 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K49, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_1;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_3;
      e.mem[_t_4 + 3] = _h_4;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K49, _t_4);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0)) {
      u64 _t_5 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _plan_2;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, _t_5);
    }
    r0 = _plan_2;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K49)
  {
    WL_POPN(4);
    u32 _h_6 = STK(0);
    u32 _h_7 = STK(1);
    Term _h_8 = STK(2);
    Term _h_9 = STK(3);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_6;
      STK(1) = _h_7;
      STK(2) = _h_8;
      STK(3) = _h_9;
      STK(4) = FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K50;
      WL_PUSHN(5);
    } else {
      u64 _t_6 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K50, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_6;
      e.mem[_t_6 + 1] = _h_7;
      e.mem[_t_6 + 2] = _h_8;
      e.mem[_t_6 + 3] = _h_9;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K50, _t_6);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0)) {
      u64 _t_7 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_5;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0, _t_7);
    }
    r0 = _h_5;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K50)
  {
    WL_POPN(4);
    u32 _h_11 = STK(0);
    u32 _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    Term _h_10 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[5];
    if (spin_8(e, _o_0, _h_11, _h_12, _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_10, blk_loc(e.mem, _h_10)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT)
  {
    Term _count_0 = r0;
    u32 _index_0 = r1;
    Term _owner_0 = r2;
    WL_OPEN
    if (_count_0 == 0) {
      r0 = _owner_0;
      r1 = term_pak(CID_NIL, 0);
      WL_RETN(2);
    } else {
      Term _rest_0 = (_count_0 - 1);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _rest_0;
      e.mem[_nd_0 + 1] = _index_0;
      Term _at_0 = blk_loc(e.mem, _owner_0);
      Term _at_1 = blk_at(_owner_0, _index_0, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      Term _next_0 = term_clo(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_C55, _nd_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _c_0;
        STK(1) = FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K57;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K57, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _c_0;
        WL_CONT = term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K57, _t_2);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _next_0;
        e.mem[_t_3 + 1] = _owner_0;
        return term_tsk(FID_CLO_APPLY, _t_3);
      }
      r0 = _next_0;
      r1 = _owner_0;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_C55)
  {
    Term _rest_1 = r0;
    u32 _index_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K56;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K56, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K56, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _rest_1;
      e.mem[_t_1 + 1] = U32_BIN(_index_1, +, 1ull);
      e.mem[_t_1 + 2] = _x_0;
      return term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT, _t_1);
    }
    r0 = _rest_1;
    r1 = U32_BIN(_index_1, +, 1ull);
    r2 = _x_0;
    WL_JMP(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K56)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT_K57)
  {
    WL_POPN(1);
    u32 _c_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[2];
    if (spin_6(e, _o_0, _c_1, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_9;
      STK(9) = _world_10;
      STK(10) = _world_11;
      STK(11) = FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K61;
      WL_PUSHN(12);
    } else {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K61, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_9;
      e.mem[_t_0 + 9] = _world_10;
      e.mem[_t_0 + 10] = _world_11;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K61, _t_0);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_8;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0, _t_1);
    }
    r0 = _world_8;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K61)
  {
    WL_POPN(11);
    u32 _world_12 = STK(0);
    u32 _world_13 = STK(1);
    u32 _world_14 = STK(2);
    Term _world_15 = STK(3);
    u32 _world_16 = STK(4);
    Term _world_17 = STK(5);
    Term _world_18 = STK(6);
    Term _world_19 = STK(7);
    Term _world_20 = STK(8);
    u32 _world_21 = STK(9);
    u32 _world_22 = STK(10);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _o_0[13];
    if (spin_9(e, _o_0, _world_12, _world_13, _world_14, _world_15, blk_loc(e.mem, _world_15), _world_16, _world_17, _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, _world_22, _h_0, blk_loc(e.mem, _h_0), _h_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_ENTRIES_0)
  {
    Term _bindings_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_bindings_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _bindings_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      Term _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(6);
        STK(0) = _f_3;
        STK(1) = _f_4;
        STK(2) = _f_5;
        STK(3) = _f_6;
        STK(4) = _f_7;
        STK(5) = FID_APP_ENTRIES_0_K65;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_APP_ENTRIES_0_K65, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        e.mem[_t_0 + 1] = _f_4;
        e.mem[_t_0 + 2] = _f_5;
        e.mem[_t_0 + 3] = _f_6;
        e.mem[_t_0 + 4] = _f_7;
        WL_CONT = term_tsk(FID_APP_ENTRIES_0_K65, _t_0);
        WL_IDX = 5;
      }
      r0 = _f_1;
      _bindings_0 = r0;
      WL_AGAIN(FID_APP_ENTRIES_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_ENTRIES_0_K65)
  {
    WL_POPN(5);
    u32 _f_8 = STK(0);
    Term _f_9 = STK(1);
    Term _f_10 = STK(2);
    Term _f_11 = STK(3);
    Term _f_12 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_8);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_9);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_12);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_APP_ENTRY, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_BUILD_0)
  {
    Term _name_0 = r0;
    Term _plan_0 = r1;
    Term _collected_0 = r2;
    u32 _collected_1 = r3;
    u32 _collected_2 = r4;
    Term _collected_3 = r5;
    u32 _collected_4 = r6;
    WL_OPEN
    if (_collected_4 == 0) {
      term_sink(e, _name_0);
      term_sink(e, _plan_0);
      term_sink(e, _collected_0);
      term_sink(e, _collected_3);
      r0 = 1;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      WL_RETN(8);
    } else {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _name_0;
        STK(1) = _plan_0;
        STK(2) = _collected_0;
        STK(3) = _collected_1;
        STK(4) = _collected_2;
        STK(5) = _collected_3;
        STK(6) = FID_APP_BUILD_0_K74;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID_APP_BUILD_0_K74, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _name_0;
        e.mem[_t_0 + 1] = _plan_0;
        e.mem[_t_0 + 2] = _collected_0;
        e.mem[_t_0 + 3] = _collected_1;
        e.mem[_t_0 + 4] = _collected_2;
        e.mem[_t_0 + 5] = _collected_3;
        WL_CONT = term_tsk(FID_APP_BUILD_0_K74, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_APP_IDS_0)) {
        u64 _t_1 = task_node(e, FID_APP_IDS_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _collected_3;
        return term_tsk(FID_APP_IDS_0, _t_1);
      }
      r0 = _collected_3;
      WL_JMP(FID_APP_IDS_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_BUILD_0_K74)
  {
    WL_POPN(6);
    Term _name_1 = STK(0);
    Term _plan_1 = STK(1);
    Term _collected_5 = STK(2);
    u32 _collected_6 = STK(3);
    u32 _collected_7 = STK(4);
    Term _collected_8 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _collected_5;
      STK(1) = _collected_6;
      STK(2) = _collected_8;
      STK(3) = FID_APP_BUILD_0_K75;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_APP_BUILD_0_K75, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _collected_5;
      e.mem[_t_2 + 1] = _collected_6;
      e.mem[_t_2 + 2] = _collected_8;
      WL_CONT = term_tsk(FID_APP_BUILD_0_K75, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0)) {
      u64 _t_3 = task_node(e, FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _collected_7;
      e.mem[_t_3 + 1] = _name_1;
      e.mem[_t_3 + 2] = _plan_1;
      e.mem[_t_3 + 3] = _h_0;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0, _t_3);
    }
    r0 = _collected_7;
    r1 = _name_1;
    r2 = _plan_1;
    r3 = _h_0;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_BUILD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_BUILD_0_K75)
  {
    WL_POPN(3);
    Term _collected_9 = STK(0);
    u32 _collected_10 = STK(1);
    Term _collected_11 = STK(2);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    Term _h_5 = r4;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[8];
    if (spin_13(e, _o_0, _collected_9, blk_loc(e.mem, _collected_9), _collected_10, _collected_11, blk_loc(e.mem, _collected_11), _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    WL_RETN(8);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_7;
      STK(7) = _world_8;
      STK(8) = _world_9;
      STK(9) = _world_10;
      STK(10) = _world_11;
      STK(11) = FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K83;
      WL_PUSHN(12);
    } else {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K83, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_7;
      e.mem[_t_0 + 7] = _world_8;
      e.mem[_t_0 + 8] = _world_9;
      e.mem[_t_0 + 9] = _world_10;
      e.mem[_t_0 + 10] = _world_11;
      WL_CONT = term_tsk(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K83, _t_0);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_6;
      return term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW, _t_1);
    }
    r0 = _world_6;
    WL_JMP(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K83)
  {
    WL_POPN(11);
    u32 _world_12 = STK(0);
    u32 _world_13 = STK(1);
    u32 _world_14 = STK(2);
    Term _world_15 = STK(3);
    u32 _world_16 = STK(4);
    Term _world_17 = STK(5);
    Term _world_18 = STK(6);
    Term _world_19 = STK(7);
    Term _world_20 = STK(8);
    u32 _world_21 = STK(9);
    u32 _world_22 = STK(10);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _o_0[14];
    if (spin_17(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2), _world_12, _world_13, _world_14, _world_15, blk_loc(e.mem, _world_15), _world_16, _world_17, _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, _world_22) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_DESCRIBE_0)
  {
    Term _app_0 = r0;
    u32 _app_1 = r1;
    Term _app_2 = r2;
    u32 _app_3 = r3;
    Term _app_4 = r4;
    Term _app_5 = r5;
    Term _app_6 = r6;
    WL_OPEN
    if (_app_1 == 1) {
      r0 = _app_0;
      r1 = 1;
      r2 = _app_2;
      r3 = _app_3;
      r4 = _app_4;
      r5 = _app_5;
      r6 = _app_6;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      WL_RETN(13);
    } else {
      _app_2 = term_keep(e, _app_2, 1);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _app_0;
        STK(1) = _app_2;
        STK(2) = _app_3;
        STK(3) = _app_4;
        STK(4) = _app_5;
        STK(5) = _app_6;
        STK(6) = FID_APP_DESCRIBE_0_K88;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID_APP_DESCRIBE_0_K88, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _app_0;
        e.mem[_t_0 + 1] = _app_2;
        e.mem[_t_0 + 2] = _app_3;
        e.mem[_t_0 + 3] = _app_4;
        e.mem[_t_0 + 4] = _app_5;
        e.mem[_t_0 + 5] = _app_6;
        WL_CONT = term_tsk(FID_APP_DESCRIBE_0_K88, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_APP_ENTRIES_0)) {
        u64 _t_1 = task_node(e, FID_APP_ENTRIES_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _app_2;
        return term_tsk(FID_APP_ENTRIES_0, _t_1);
      }
      r0 = _app_2;
      WL_JMP(FID_APP_ENTRIES_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_APP_DESCRIBE_0_K88)
  {
    WL_POPN(6);
    Term _app_7 = STK(0);
    Term _app_8 = STK(1);
    u32 _app_9 = STK(2);
    Term _app_10 = STK(3);
    Term _app_11 = STK(4);
    Term _app_12 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    _app_7 = term_keep(e, _app_7, 1);
    _app_10 = term_keep(e, _app_10, 1);
    _app_11 = term_keep(e, _app_11, 1);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_18(e, _o_0, _app_7, blk_loc(e.mem, _app_7)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    r0 = _app_7;
    r1 = 0;
    r2 = _app_8;
    r3 = _app_9;
    r4 = _app_10;
    r5 = _app_11;
    r6 = _app_12;
    r7 = 1;
    r8 = _v_0;
    r9 = _app_9;
    r10 = _app_10;
    r11 = _app_11;
    r12 = _h_0;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW)
  {
    Term _owner_0 = r0;
    WL_OPEN
    u32 _s_0 = (1ull << (blk_cls(_owner_0) - 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _s_0;
      STK(1) = FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW_K99;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW_K99, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _s_0;
      WL_CONT = term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW_K99, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = ((u64)_s_0);
      e.mem[_t_1 + 1] = 0ull;
      e.mem[_t_1 + 2] = _owner_0;
      return term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT, _t_1);
    }
    r0 = ((u64)_s_0);
    r1 = 0ull;
    r2 = _owner_0;
    WL_JMP(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_COLLECT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW_K99)
  {
    WL_POPN(1);
    u32 _s_1 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _o_0[3];
    if (spin_16(e, _o_0, ((u64)_s_1), _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SNAPSHOT_K104;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_SNAPSHOT_K104, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SNAPSHOT_K104, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0)) {
      u64 _t_1 = task_node(e, FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K104)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_12;
      STK(1) = _h_13;
      STK(2) = FID_SNAPSHOT_K105;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_SNAPSHOT_K105, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_12;
      e.mem[_t_2 + 1] = _h_13;
      WL_CONT = term_tsk(FID_SNAPSHOT_K105, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0)) {
      u64 _t_3 = task_node(e, FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      return term_tsk(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    WL_JMP(FID__________________________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K105)
  {
    WL_POPN(2);
    Term _h_27 = STK(0);
    Term _h_28 = STK(1);
    u32 _h_14 = r0;
    u32 _h_15 = r1;
    u32 _h_16 = r2;
    Term _h_17 = r3;
    u32 _h_18 = r4;
    Term _h_19 = r5;
    Term _h_20 = r6;
    Term _h_21 = r7;
    Term _h_22 = r8;
    Term _h_23 = r9;
    u32 _h_24 = r10;
    u32 _h_25 = r11;
    u32 _h_26 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_27;
      STK(1) = _h_28;
      STK(2) = _h_14;
      STK(3) = _h_15;
      STK(4) = _h_16;
      STK(5) = _h_18;
      STK(6) = _h_19;
      STK(7) = _h_20;
      STK(8) = _h_21;
      STK(9) = _h_22;
      STK(10) = _h_23;
      STK(11) = _h_24;
      STK(12) = _h_25;
      STK(13) = _h_26;
      STK(14) = FID_SNAPSHOT_K106;
      WL_PUSHN(15);
    } else {
      u64 _t_4 = task_node(e, FID_SNAPSHOT_K106, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_27;
      e.mem[_t_4 + 1] = _h_28;
      e.mem[_t_4 + 2] = _h_14;
      e.mem[_t_4 + 3] = _h_15;
      e.mem[_t_4 + 4] = _h_16;
      e.mem[_t_4 + 5] = _h_18;
      e.mem[_t_4 + 6] = _h_19;
      e.mem[_t_4 + 7] = _h_20;
      e.mem[_t_4 + 8] = _h_21;
      e.mem[_t_4 + 9] = _h_22;
      e.mem[_t_4 + 10] = _h_23;
      e.mem[_t_4 + 11] = _h_24;
      e.mem[_t_4 + 12] = _h_25;
      e.mem[_t_4 + 13] = _h_26;
      WL_CONT = term_tsk(FID_SNAPSHOT_K106, _t_4);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID____SCENARIO_OBSERVATION_BITS)) {
      u64 _t_5 = task_node(e, FID____SCENARIO_OBSERVATION_BITS, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = ((u64)_h_18);
      e.mem[_t_5 + 1] = 0ull;
      e.mem[_t_5 + 2] = _h_17;
      return term_tsk(FID____SCENARIO_OBSERVATION_BITS, _t_5);
    }
    r0 = ((u64)_h_18);
    r1 = 0ull;
    r2 = _h_17;
    WL_JMP(FID____SCENARIO_OBSERVATION_BITS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K106)
  {
    WL_POPN(14);
    Term _h_31 = STK(0);
    Term _h_32 = STK(1);
    u32 _h_33 = STK(2);
    u32 _h_34 = STK(3);
    u32 _h_35 = STK(4);
    u32 _h_36 = STK(5);
    Term _h_37 = STK(6);
    Term _h_38 = STK(7);
    Term _h_39 = STK(8);
    Term _h_40 = STK(9);
    Term _h_41 = STK(10);
    u32 _h_42 = STK(11);
    u32 _h_43 = STK(12);
    u32 _h_44 = STK(13);
    Term _h_29 = r0;
    Term _h_30 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _o_0[25];
    if (spin_10(e, _o_0, _h_31, _h_32, blk_loc(e.mem, _h_32), _h_44, _h_33, _h_34, _h_35, _h_36, _h_37, _h_38, blk_loc(e.mem, _h_38), _h_39, blk_loc(e.mem, _h_39), _h_40, blk_loc(e.mem, _h_40), _h_41, blk_loc(e.mem, _h_41), _h_42, _h_43, _h_29, blk_loc(e.mem, _h_29), _h_30, blk_loc(e.mem, _h_30)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    _v_19 = _o_0[19];
    _v_20 = _o_0[20];
    _v_21 = _o_0[21];
    _v_22 = _o_0[22];
    _v_23 = _o_0[23];
    _v_24 = _o_0[24];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    r24 = _v_24;
    WL_RETN(25);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESOURCE_CONTROL_MAIN)
  {
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 17ull;
    Term _a_0 = blk_new(e, 0, 1ull, 0, 1, _fv_0);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[14];
    if (spin_20(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_14 = _o_0[0];
    _v_15 = _o_0[1];
    _v_16 = _o_0[2];
    _v_17 = _o_0[3];
    _v_18 = _o_0[4];
    _v_19 = _o_0[5];
    _v_20 = _o_0[6];
    _v_21 = _o_0[7];
    _v_22 = _o_0[8];
    _v_23 = _o_0[9];
    _v_24 = _o_0[10];
    _v_25 = _o_0[11];
    _v_26 = _o_0[12];
    _v_27 = _o_0[13];
    _v_0 = _v_14;
    _v_1 = _v_15;
    _v_2 = _v_16;
    _v_3 = _v_17;
    _v_4 = _v_18;
    _v_5 = _v_19;
    _v_6 = _v_20;
    _v_7 = _v_21;
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    if (_v_0 == 1) {
      r0 = 2;
      r1 = _v_1;
      r2 = _v_2;
      r3 = 0;
      r4 = 0;
      r5 = 0;
      r6 = 0;
      r7 = 0;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      r26 = 0;
      WL_RETN(27);
    } else {
      Term _key_0 = term_ctr(CID_SCON, STAT_OFF + 14);
      _key_0 = term_keep(e, _key_0, 1);
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, 1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _key_0);
      e.mem[_nd_0 + 2] = rfc_seal(e, _key_0);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________________________________BENDVY_SRC_ECS_SCHEMA_FRAGMENTS_ENTRY, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      Term _schema_0 = term_ctr(CID_CON, _nd_1);
      Term _v_28 = 0;
      u32 _v_29 = 0;
      u32 _v_30 = 0;
      Term _v_31 = 0;
      u32 _v_32 = 0;
      Term _v_33 = 0;
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      Term _o_1[5];
      if (spin_21(e, _o_1, 1ull, 0, _schema_0, blk_loc(e.mem, _schema_0)) == 0) {
        return 0;
      }
      _v_33 = _o_1[0];
      _v_34 = _o_1[1];
      _v_35 = _o_1[2];
      _v_36 = _o_1[3];
      _v_37 = _o_1[4];
      _v_28 = _v_33;
      _v_29 = _v_34;
      _v_30 = _v_35;
      _v_31 = _v_36;
      _v_32 = _v_37;
      if (seq) {
        WL_ROOM(14);
        STK(0) = _v_1;
        STK(1) = _v_2;
        STK(2) = _v_3;
        STK(3) = _v_4;
        STK(4) = _v_5;
        STK(5) = _v_6;
        STK(6) = _v_7;
        STK(7) = _v_8;
        STK(8) = _v_9;
        STK(9) = _v_10;
        STK(10) = _v_11;
        STK(11) = _v_12;
        STK(12) = _v_13;
        STK(13) = FID_RESOURCE_CONTROL_MAIN_K113;
        WL_PUSHN(14);
      } else {
        u64 _t_0 = task_node(e, FID_RESOURCE_CONTROL_MAIN_K113, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _v_1;
        e.mem[_t_0 + 1] = _v_2;
        e.mem[_t_0 + 2] = _v_3;
        e.mem[_t_0 + 3] = _v_4;
        e.mem[_t_0 + 4] = _v_5;
        e.mem[_t_0 + 5] = _v_6;
        e.mem[_t_0 + 6] = _v_7;
        e.mem[_t_0 + 7] = _v_8;
        e.mem[_t_0 + 8] = _v_9;
        e.mem[_t_0 + 9] = _v_10;
        e.mem[_t_0 + 10] = _v_11;
        e.mem[_t_0 + 11] = _v_12;
        e.mem[_t_0 + 12] = _v_13;
        WL_CONT = term_tsk(FID_RESOURCE_CONTROL_MAIN_K113, _t_0);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_APP_BUILD_0)) {
        u64 _t_1 = task_node(e, FID_APP_BUILD_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 26);
        e.mem[_t_1 + 1] = term_ctr(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_ENTRY, STAT_OFF + 28);
        e.mem[_t_1 + 2] = _v_28;
        e.mem[_t_1 + 3] = _v_29;
        e.mem[_t_1 + 4] = _v_30;
        e.mem[_t_1 + 5] = _v_31;
        e.mem[_t_1 + 6] = _v_32;
        return term_tsk(FID_APP_BUILD_0, _t_1);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 26);
      r1 = term_ctr(CID__________________________________BENDVY_SRC_ECS_SCHEDULE_PROVISION_ENTRY, STAT_OFF + 28);
      r2 = _v_28;
      r3 = _v_29;
      r4 = _v_30;
      r5 = _v_31;
      r6 = _v_32;
      WL_JMP(FID_APP_BUILD_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESOURCE_CONTROL_MAIN_K113)
  {
    WL_POPN(13);
    u32 _v_38 = STK(0);
    u32 _v_39 = STK(1);
    u32 _v_40 = STK(2);
    u32 _v_41 = STK(3);
    Term _v_42 = STK(4);
    u32 _v_43 = STK(5);
    Term _v_44 = STK(6);
    Term _v_45 = STK(7);
    Term _v_46 = STK(8);
    Term _v_47 = STK(9);
    Term _v_48 = STK(10);
    u32 _v_49 = STK(11);
    u32 _v_50 = STK(12);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    WL_OPEN
    if (_h_0 == 1) {
      r0 = 1;
      r1 = _v_38;
      r2 = _v_39;
      r3 = _v_40;
      r4 = _v_41;
      r5 = _v_42;
      r6 = _v_43;
      r7 = _v_44;
      r8 = _v_45;
      r9 = _v_46;
      r10 = _v_47;
      r11 = _v_48;
      r12 = _v_49;
      r13 = _v_50;
      r14 = 0;
      r15 = 0;
      r16 = 0;
      r17 = 0;
      r18 = 0;
      r19 = 0;
      r20 = 0;
      r21 = 0;
      r22 = 0;
      r23 = 0;
      r24 = 0;
      r25 = 0;
      r26 = 0;
      WL_RETN(27);
    } else {
      if (seq) {
        WL_ROOM(14);
        STK(0) = _v_38;
        STK(1) = _v_39;
        STK(2) = _v_40;
        STK(3) = _v_41;
        STK(4) = _v_42;
        STK(5) = _v_43;
        STK(6) = _v_44;
        STK(7) = _v_45;
        STK(8) = _v_46;
        STK(9) = _v_47;
        STK(10) = _v_48;
        STK(11) = _v_49;
        STK(12) = _v_50;
        STK(13) = FID_RESOURCE_CONTROL_MAIN_K114;
        WL_PUSHN(14);
      } else {
        u64 _t_2 = task_node(e, FID_RESOURCE_CONTROL_MAIN_K114, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _v_38;
        e.mem[_t_2 + 1] = _v_39;
        e.mem[_t_2 + 2] = _v_40;
        e.mem[_t_2 + 3] = _v_41;
        e.mem[_t_2 + 4] = _v_42;
        e.mem[_t_2 + 5] = _v_43;
        e.mem[_t_2 + 6] = _v_44;
        e.mem[_t_2 + 7] = _v_45;
        e.mem[_t_2 + 8] = _v_46;
        e.mem[_t_2 + 9] = _v_47;
        e.mem[_t_2 + 10] = _v_48;
        e.mem[_t_2 + 11] = _v_49;
        e.mem[_t_2 + 12] = _v_50;
        WL_CONT = term_tsk(FID_RESOURCE_CONTROL_MAIN_K114, _t_2);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_APP_DESCRIBE_0)) {
        u64 _t_3 = task_node(e, FID_APP_DESCRIBE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_1;
        e.mem[_t_3 + 1] = _h_2;
        e.mem[_t_3 + 2] = _h_3;
        e.mem[_t_3 + 3] = _h_4;
        e.mem[_t_3 + 4] = _h_5;
        e.mem[_t_3 + 5] = _h_6;
        e.mem[_t_3 + 6] = _h_7;
        return term_tsk(FID_APP_DESCRIBE_0, _t_3);
      }
      r0 = _h_1;
      r1 = _h_2;
      r2 = _h_3;
      r3 = _h_4;
      r4 = _h_5;
      r5 = _h_6;
      r6 = _h_7;
      WL_JMP(FID_APP_DESCRIBE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RESOURCE_CONTROL_MAIN_K114)
  {
    WL_POPN(13);
    u32 _v_51 = STK(0);
    u32 _v_52 = STK(1);
    u32 _v_53 = STK(2);
    u32 _v_54 = STK(3);
    Term _v_55 = STK(4);
    u32 _v_56 = STK(5);
    Term _v_57 = STK(6);
    Term _v_58 = STK(7);
    Term _v_59 = STK(8);
    Term _v_60 = STK(9);
    Term _v_61 = STK(10);
    u32 _v_62 = STK(11);
    u32 _v_63 = STK(12);
    Term _h_8 = r0;
    u32 _h_9 = r1;
    Term _h_10 = r2;
    u32 _h_11 = r3;
    Term _h_12 = r4;
    Term _h_13 = r5;
    Term _h_14 = r6;
    u32 _h_15 = r7;
    Term _h_16 = r8;
    u32 _h_17 = r9;
    Term _h_18 = r10;
    Term _h_19 = r11;
    Term _h_20 = r12;
    WL_OPEN
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    Term _v_80 = 0;
    u32 _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    Term _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    Term _o_2[27];
    if (spin_14(e, _o_2, _v_51, _v_52, _v_53, _v_54, _v_55, blk_loc(e.mem, _v_55), _v_56, _v_57, _v_58, blk_loc(e.mem, _v_58), _v_59, blk_loc(e.mem, _v_59), _v_60, blk_loc(e.mem, _v_60), _v_61, blk_loc(e.mem, _v_61), _v_62, _v_63, _h_8, blk_loc(e.mem, _h_8), _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_64 = _o_2[0];
    _v_65 = _o_2[1];
    _v_66 = _o_2[2];
    _v_67 = _o_2[3];
    _v_68 = _o_2[4];
    _v_69 = _o_2[5];
    _v_70 = _o_2[6];
    _v_71 = _o_2[7];
    _v_72 = _o_2[8];
    _v_73 = _o_2[9];
    _v_74 = _o_2[10];
    _v_75 = _o_2[11];
    _v_76 = _o_2[12];
    _v_77 = _o_2[13];
    _v_78 = _o_2[14];
    _v_79 = _o_2[15];
    _v_80 = _o_2[16];
    _v_81 = _o_2[17];
    _v_82 = _o_2[18];
    _v_83 = _o_2[19];
    _v_84 = _o_2[20];
    _v_85 = _o_2[21];
    _v_86 = _o_2[22];
    _v_87 = _o_2[23];
    _v_88 = _o_2[24];
    _v_89 = _o_2[25];
    _v_90 = _o_2[26];
    r0 = _v_64;
    r1 = _v_65;
    r2 = _v_66;
    r3 = _v_67;
    r4 = _v_68;
    r5 = _v_69;
    r6 = _v_70;
    r7 = _v_71;
    r8 = _v_72;
    r9 = _v_73;
    r10 = _v_74;
    r11 = _v_75;
    r12 = _v_76;
    r13 = _v_77;
    r14 = _v_78;
    r15 = _v_79;
    r16 = _v_80;
    r17 = _v_81;
    r18 = _v_82;
    r19 = _v_83;
    r20 = _v_84;
    r21 = _v_85;
    r22 = _v_86;
    r23 = _v_87;
    r24 = _v_88;
    r25 = _v_89;
    r26 = _v_90;
    WL_RETN(27);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K124;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K124, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K124, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RESOURCE_CONTROL_MAIN)) {
      u64 _t_1 = task_node(e, FID_RESOURCE_CONTROL_MAIN, WL_CONT, WL_IDX, 0);
      return term_tsk(FID_RESOURCE_CONTROL_MAIN, _t_1);
    }
    WL_JMP(FID_RESOURCE_CONTROL_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K124)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    Term _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    u32 _h_21 = r21;
    Term _h_22 = r22;
    u32 _h_23 = r23;
    Term _h_24 = r24;
    Term _h_25 = r25;
    Term _h_26 = r26;
    WL_OPEN
    if (_h_0 == 0) {
      if (seq) {
        WL_ROOM(15);
        STK(0) = _h_1;
        STK(1) = _h_14;
        STK(2) = _h_15;
        STK(3) = _h_16;
        STK(4) = _h_17;
        STK(5) = _h_18;
        STK(6) = _h_19;
        STK(7) = _h_20;
        STK(8) = _h_21;
        STK(9) = _h_22;
        STK(10) = _h_23;
        STK(11) = _h_24;
        STK(12) = _h_25;
        STK(13) = _h_26;
        STK(14) = FID_MAIN_K125;
        WL_PUSHN(15);
      } else {
        u64 _t_2 = task_node(e, FID_MAIN_K125, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _h_1;
        e.mem[_t_2 + 1] = _h_14;
        e.mem[_t_2 + 2] = _h_15;
        e.mem[_t_2 + 3] = _h_16;
        e.mem[_t_2 + 4] = _h_17;
        e.mem[_t_2 + 5] = _h_18;
        e.mem[_t_2 + 6] = _h_19;
        e.mem[_t_2 + 7] = _h_20;
        e.mem[_t_2 + 8] = _h_21;
        e.mem[_t_2 + 9] = _h_22;
        e.mem[_t_2 + 10] = _h_23;
        e.mem[_t_2 + 11] = _h_24;
        e.mem[_t_2 + 12] = _h_25;
        e.mem[_t_2 + 13] = _h_26;
        WL_CONT = term_tsk(FID_MAIN_K125, _t_2);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
        u64 _t_3 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_2;
        e.mem[_t_3 + 1] = _h_3;
        e.mem[_t_3 + 2] = _h_4;
        e.mem[_t_3 + 3] = _h_5;
        e.mem[_t_3 + 4] = _h_6;
        e.mem[_t_3 + 5] = _h_7;
        e.mem[_t_3 + 6] = _h_8;
        e.mem[_t_3 + 7] = _h_9;
        e.mem[_t_3 + 8] = _h_10;
        e.mem[_t_3 + 9] = _h_11;
        e.mem[_t_3 + 10] = _h_12;
        e.mem[_t_3 + 11] = _h_13;
        return term_tsk(FID_SNAPSHOT, _t_3);
      }
      r0 = _h_2;
      r1 = _h_3;
      r2 = _h_4;
      r3 = _h_5;
      r4 = _h_6;
      r5 = _h_7;
      r6 = _h_8;
      r7 = _h_9;
      r8 = _h_10;
      r9 = _h_11;
      r10 = _h_12;
      r11 = _h_13;
      WL_JMP(FID_SNAPSHOT);
    } else if (_h_0 == 1) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_1;
        STK(1) = FID_MAIN_K130;
        WL_PUSHN(2);
      } else {
        u64 _t_12 = task_node(e, FID_MAIN_K130, WL_CONT, WL_IDX, 1);
        e.mem[_t_12 + 0] = _h_1;
        WL_CONT = term_tsk(FID_MAIN_K130, _t_12);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
        u64 _t_13 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _h_2;
        e.mem[_t_13 + 1] = _h_3;
        e.mem[_t_13 + 2] = _h_4;
        e.mem[_t_13 + 3] = _h_5;
        e.mem[_t_13 + 4] = _h_6;
        e.mem[_t_13 + 5] = _h_7;
        e.mem[_t_13 + 6] = _h_8;
        e.mem[_t_13 + 7] = _h_9;
        e.mem[_t_13 + 8] = _h_10;
        e.mem[_t_13 + 9] = _h_11;
        e.mem[_t_13 + 10] = _h_12;
        e.mem[_t_13 + 11] = _h_13;
        return term_tsk(FID_SNAPSHOT, _t_13);
      }
      r0 = _h_2;
      r1 = _h_3;
      r2 = _h_4;
      r3 = _h_5;
      r4 = _h_6;
      r5 = _h_7;
      r6 = _h_8;
      r7 = _h_9;
      r8 = _h_10;
      r9 = _h_11;
      r10 = _h_12;
      r11 = _h_13;
      WL_JMP(FID_SNAPSHOT);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_1;
        STK(1) = FID_MAIN_K131;
        WL_PUSHN(2);
      } else {
        u64 _t_14 = task_node(e, FID_MAIN_K131, WL_CONT, WL_IDX, 1);
        e.mem[_t_14 + 0] = _h_1;
        WL_CONT = term_tsk(FID_MAIN_K131, _t_14);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW)) {
        u64 _t_15 = task_node(e, FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW, WL_CONT, WL_IDX, 0);
        e.mem[_t_15 + 0] = _h_2;
        return term_tsk(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW, _t_15);
      }
      r0 = _h_2;
      WL_JMP(FID__________________________________BENDVY_EXPERIMENTS_PUBLIC_SIMULATION_BEND_V1_OWNER_VIEW_VIEW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K125)
  {
    WL_POPN(14);
    u32 _h_52 = STK(0);
    Term _h_53 = STK(1);
    u32 _h_54 = STK(2);
    Term _h_55 = STK(3);
    u32 _h_56 = STK(4);
    Term _h_57 = STK(5);
    Term _h_58 = STK(6);
    Term _h_59 = STK(7);
    u32 _h_60 = STK(8);
    Term _h_61 = STK(9);
    u32 _h_62 = STK(10);
    Term _h_63 = STK(11);
    Term _h_64 = STK(12);
    Term _h_65 = STK(13);
    u32 _h_27 = r0;
    u32 _h_28 = r1;
    u32 _h_29 = r2;
    Term _h_30 = r3;
    u32 _h_31 = r4;
    Term _h_32 = r5;
    Term _h_33 = r6;
    Term _h_34 = r7;
    Term _h_35 = r8;
    Term _h_36 = r9;
    u32 _h_37 = r10;
    u32 _h_38 = r11;
    u32 _h_39 = r12;
    u32 _h_40 = r13;
    u32 _h_41 = r14;
    u32 _h_42 = r15;
    Term _h_43 = r16;
    Term _h_44 = r17;
    Term _h_45 = r18;
    Term _h_46 = r19;
    Term _h_47 = r20;
    u32 _h_48 = r21;
    Term _h_49 = r22;
    u32 _h_50 = r23;
    u32 _h_51 = r24;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _h_52;
      STK(1) = _h_60;
      STK(2) = _h_61;
      STK(3) = _h_62;
      STK(4) = _h_63;
      STK(5) = _h_64;
      STK(6) = _h_65;
      STK(7) = _h_27;
      STK(8) = _h_28;
      STK(9) = _h_29;
      STK(10) = _h_30;
      STK(11) = _h_31;
      STK(12) = _h_32;
      STK(13) = _h_33;
      STK(14) = _h_34;
      STK(15) = _h_35;
      STK(16) = _h_36;
      STK(17) = _h_37;
      STK(18) = _h_38;
      STK(19) = _h_39;
      STK(20) = _h_40;
      STK(21) = _h_41;
      STK(22) = _h_42;
      STK(23) = _h_43;
      STK(24) = _h_44;
      STK(25) = _h_45;
      STK(26) = _h_46;
      STK(27) = _h_47;
      STK(28) = _h_48;
      STK(29) = _h_49;
      STK(30) = _h_50;
      STK(31) = _h_51;
      STK(32) = FID_MAIN_K126;
      WL_PUSHN(33);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K126, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_52;
      e.mem[_t_4 + 1] = _h_60;
      e.mem[_t_4 + 2] = _h_61;
      e.mem[_t_4 + 3] = _h_62;
      e.mem[_t_4 + 4] = _h_63;
      e.mem[_t_4 + 5] = _h_64;
      e.mem[_t_4 + 6] = _h_65;
      e.mem[_t_4 + 7] = _h_27;
      e.mem[_t_4 + 8] = _h_28;
      e.mem[_t_4 + 9] = _h_29;
      e.mem[_t_4 + 10] = _h_30;
      e.mem[_t_4 + 11] = _h_31;
      e.mem[_t_4 + 12] = _h_32;
      e.mem[_t_4 + 13] = _h_33;
      e.mem[_t_4 + 14] = _h_34;
      e.mem[_t_4 + 15] = _h_35;
      e.mem[_t_4 + 16] = _h_36;
      e.mem[_t_4 + 17] = _h_37;
      e.mem[_t_4 + 18] = _h_38;
      e.mem[_t_4 + 19] = _h_39;
      e.mem[_t_4 + 20] = _h_40;
      e.mem[_t_4 + 21] = _h_41;
      e.mem[_t_4 + 22] = _h_42;
      e.mem[_t_4 + 23] = _h_43;
      e.mem[_t_4 + 24] = _h_44;
      e.mem[_t_4 + 25] = _h_45;
      e.mem[_t_4 + 26] = _h_46;
      e.mem[_t_4 + 27] = _h_47;
      e.mem[_t_4 + 28] = _h_48;
      e.mem[_t_4 + 29] = _h_49;
      e.mem[_t_4 + 30] = _h_50;
      e.mem[_t_4 + 31] = _h_51;
      WL_CONT = term_tsk(FID_MAIN_K126, _t_4);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_APP_DESCRIBE_0)) {
      u64 _t_5 = task_node(e, FID_APP_DESCRIBE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_53;
      e.mem[_t_5 + 1] = _h_54;
      e.mem[_t_5 + 2] = _h_55;
      e.mem[_t_5 + 3] = _h_56;
      e.mem[_t_5 + 4] = _h_57;
      e.mem[_t_5 + 5] = _h_58;
      e.mem[_t_5 + 6] = _h_59;
      return term_tsk(FID_APP_DESCRIBE_0, _t_5);
    }
    r0 = _h_53;
    r1 = _h_54;
    r2 = _h_55;
    r3 = _h_56;
    r4 = _h_57;
    r5 = _h_58;
    r6 = _h_59;
    WL_JMP(FID_APP_DESCRIBE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K126)
  {
    WL_POPN(32);
    u32 _h_79 = STK(0);
    u32 _h_80 = STK(1);
    Term _h_81 = STK(2);
    u32 _h_82 = STK(3);
    Term _h_83 = STK(4);
    Term _h_84 = STK(5);
    Term _h_85 = STK(6);
    u32 _h_86 = STK(7);
    u32 _h_87 = STK(8);
    u32 _h_88 = STK(9);
    Term _h_89 = STK(10);
    u32 _h_90 = STK(11);
    Term _h_91 = STK(12);
    Term _h_92 = STK(13);
    Term _h_93 = STK(14);
    Term _h_94 = STK(15);
    Term _h_95 = STK(16);
    u32 _h_96 = STK(17);
    u32 _h_97 = STK(18);
    u32 _h_98 = STK(19);
    u32 _h_99 = STK(20);
    u32 _h_100 = STK(21);
    u32 _h_101 = STK(22);
    Term _h_102 = STK(23);
    Term _h_103 = STK(24);
    Term _h_104 = STK(25);
    Term _h_105 = STK(26);
    Term _h_106 = STK(27);
    u32 _h_107 = STK(28);
    Term _h_108 = STK(29);
    u32 _h_109 = STK(30);
    u32 _h_110 = STK(31);
    Term _h_66 = r0;
    u32 _h_67 = r1;
    Term _h_68 = r2;
    u32 _h_69 = r3;
    Term _h_70 = r4;
    Term _h_71 = r5;
    Term _h_72 = r6;
    u32 _h_73 = r7;
    Term _h_74 = r8;
    u32 _h_75 = r9;
    Term _h_76 = r10;
    Term _h_77 = r11;
    Term _h_78 = r12;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _o_0[7];
    if (spin_19(e, _o_0, _h_66, blk_loc(e.mem, _h_66), _h_67, _h_68, blk_loc(e.mem, _h_68), _h_69, _h_70, blk_loc(e.mem, _h_70), _h_71, blk_loc(e.mem, _h_71), _h_72, blk_loc(e.mem, _h_72)) == 0) {
      return 0;
    }
    _v_7 = _o_0[0];
    _v_8 = _o_0[1];
    _v_9 = _o_0[2];
    _v_10 = _o_0[3];
    _v_11 = _o_0[4];
    _v_12 = _o_0[5];
    _v_13 = _o_0[6];
    _v_0 = _v_7;
    _v_1 = _v_8;
    _v_2 = _v_9;
    _v_3 = _v_10;
    _v_4 = _v_11;
    _v_5 = _v_12;
    _v_6 = _v_13;
    if (seq) {
      WL_ROOM(39);
      STK(0) = _h_79;
      STK(1) = _h_86;
      STK(2) = _h_87;
      STK(3) = _h_88;
      STK(4) = _h_89;
      STK(5) = _h_90;
      STK(6) = _h_91;
      STK(7) = _h_92;
      STK(8) = _h_93;
      STK(9) = _h_94;
      STK(10) = _h_95;
      STK(11) = _h_96;
      STK(12) = _h_97;
      STK(13) = _h_98;
      STK(14) = _h_99;
      STK(15) = _h_100;
      STK(16) = _h_101;
      STK(17) = _h_102;
      STK(18) = _h_103;
      STK(19) = _h_104;
      STK(20) = _h_105;
      STK(21) = _h_106;
      STK(22) = _h_107;
      STK(23) = _h_108;
      STK(24) = _h_109;
      STK(25) = _h_110;
      STK(26) = _h_80;
      STK(27) = _h_81;
      STK(28) = _h_82;
      STK(29) = _h_83;
      STK(30) = _h_84;
      STK(31) = _h_85;
      STK(32) = _h_73;
      STK(33) = _h_74;
      STK(34) = _h_75;
      STK(35) = _h_76;
      STK(36) = _h_77;
      STK(37) = _h_78;
      STK(38) = FID_MAIN_K127;
      WL_PUSHN(39);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K127, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_79;
      e.mem[_t_6 + 1] = _h_86;
      e.mem[_t_6 + 2] = _h_87;
      e.mem[_t_6 + 3] = _h_88;
      e.mem[_t_6 + 4] = _h_89;
      e.mem[_t_6 + 5] = _h_90;
      e.mem[_t_6 + 6] = _h_91;
      e.mem[_t_6 + 7] = _h_92;
      e.mem[_t_6 + 8] = _h_93;
      e.mem[_t_6 + 9] = _h_94;
      e.mem[_t_6 + 10] = _h_95;
      e.mem[_t_6 + 11] = _h_96;
      e.mem[_t_6 + 12] = _h_97;
      e.mem[_t_6 + 13] = _h_98;
      e.mem[_t_6 + 14] = _h_99;
      e.mem[_t_6 + 15] = _h_100;
      e.mem[_t_6 + 16] = _h_101;
      e.mem[_t_6 + 17] = _h_102;
      e.mem[_t_6 + 18] = _h_103;
      e.mem[_t_6 + 19] = _h_104;
      e.mem[_t_6 + 20] = _h_105;
      e.mem[_t_6 + 21] = _h_106;
      e.mem[_t_6 + 22] = _h_107;
      e.mem[_t_6 + 23] = _h_108;
      e.mem[_t_6 + 24] = _h_109;
      e.mem[_t_6 + 25] = _h_110;
      e.mem[_t_6 + 26] = _h_80;
      e.mem[_t_6 + 27] = _h_81;
      e.mem[_t_6 + 28] = _h_82;
      e.mem[_t_6 + 29] = _h_83;
      e.mem[_t_6 + 30] = _h_84;
      e.mem[_t_6 + 31] = _h_85;
      e.mem[_t_6 + 32] = _h_73;
      e.mem[_t_6 + 33] = _h_74;
      e.mem[_t_6 + 34] = _h_75;
      e.mem[_t_6 + 35] = _h_76;
      e.mem[_t_6 + 36] = _h_77;
      e.mem[_t_6 + 37] = _h_78;
      WL_CONT = term_tsk(FID_MAIN_K127, _t_6);
      WL_IDX = 38;
    }
    if (!DEVICE && !seq && fid_nofk(FID_APP_DESCRIBE_0)) {
      u64 _t_7 = task_node(e, FID_APP_DESCRIBE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _v_0;
      e.mem[_t_7 + 1] = _v_1;
      e.mem[_t_7 + 2] = _v_2;
      e.mem[_t_7 + 3] = _v_3;
      e.mem[_t_7 + 4] = _v_4;
      e.mem[_t_7 + 5] = _v_5;
      e.mem[_t_7 + 6] = _v_6;
      return term_tsk(FID_APP_DESCRIBE_0, _t_7);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    WL_JMP(FID_APP_DESCRIBE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K127)
  {
    WL_POPN(38);
    u32 _h_124 = STK(0);
    u32 _h_125 = STK(1);
    u32 _h_126 = STK(2);
    u32 _h_127 = STK(3);
    Term _h_128 = STK(4);
    u32 _h_129 = STK(5);
    Term _h_130 = STK(6);
    Term _h_131 = STK(7);
    Term _h_132 = STK(8);
    Term _h_133 = STK(9);
    Term _h_134 = STK(10);
    u32 _h_135 = STK(11);
    u32 _h_136 = STK(12);
    u32 _h_137 = STK(13);
    u32 _h_138 = STK(14);
    u32 _h_139 = STK(15);
    u32 _h_140 = STK(16);
    Term _h_141 = STK(17);
    Term _h_142 = STK(18);
    Term _h_143 = STK(19);
    Term _h_144 = STK(20);
    Term _h_145 = STK(21);
    u32 _h_146 = STK(22);
    Term _h_147 = STK(23);
    u32 _h_148 = STK(24);
    u32 _h_149 = STK(25);
    u32 _h_150 = STK(26);
    Term _h_151 = STK(27);
    u32 _h_152 = STK(28);
    Term _h_153 = STK(29);
    Term _h_154 = STK(30);
    Term _h_155 = STK(31);
    u32 _h_156 = STK(32);
    Term _h_157 = STK(33);
    u32 _h_158 = STK(34);
    Term _h_159 = STK(35);
    Term _h_160 = STK(36);
    Term _h_161 = STK(37);
    Term _h_111 = r0;
    u32 _h_112 = r1;
    Term _h_113 = r2;
    u32 _h_114 = r3;
    Term _h_115 = r4;
    Term _h_116 = r5;
    Term _h_117 = r6;
    u32 _h_118 = r7;
    Term _h_119 = r8;
    u32 _h_120 = r9;
    Term _h_121 = r10;
    Term _h_122 = r11;
    Term _h_123 = r12;
    WL_OPEN
    Term _b_0 = 0;
    if (_h_156 == 0) {
      _b_0 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_157);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_158);
      e.mem[_nd_0 + 2] = rfc_seal(e, _h_159);
      e.mem[_nd_0 + 3] = rfc_seal(e, _h_160);
      e.mem[_nd_0 + 4] = rfc_seal(e, _h_161);
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_APP_DESCRIPTION, _nd_0));
      _b_0 = term_ctr(CID_SOME, _nd_1);
    }
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _b_1 = 0;
    if (_h_150 == 0) {
      _b_1 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_3 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_3 + 0] = rfc_seal(e, _h_151);
      e.mem[_nd_3 + 1] = rfc_seal(e, _h_152);
      e.mem[_nd_3 + 2] = rfc_seal(e, _h_153);
      e.mem[_nd_3 + 3] = rfc_seal(e, _h_154);
      e.mem[_nd_3 + 4] = rfc_seal(e, _h_155);
      u64 _nd_4 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_APP_DESCRIPTION, _nd_3));
      _b_1 = term_ctr(CID_SOME, _nd_4);
    }
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, _b_1);
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    Term _descriptions_0 = term_ctr(CID_CON, _nd_5);
    Term _b_2 = 0;
    if (_h_118 == 0) {
      _b_2 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_6 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_6 + 0] = rfc_seal(e, _h_119);
      e.mem[_nd_6 + 1] = rfc_seal(e, _h_120);
      e.mem[_nd_6 + 2] = rfc_seal(e, _h_121);
      e.mem[_nd_6 + 3] = rfc_seal(e, _h_122);
      e.mem[_nd_6 + 4] = rfc_seal(e, _h_123);
      u64 _nd_7 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_APP_DESCRIPTION, _nd_6));
      _b_2 = term_ctr(CID_SOME, _nd_7);
    }
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _b_2);
    e.mem[_nd_8 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_124;
      STK(1) = _h_125;
      STK(2) = _h_126;
      STK(3) = _h_127;
      STK(4) = _h_128;
      STK(5) = _h_129;
      STK(6) = _h_130;
      STK(7) = _h_131;
      STK(8) = _h_132;
      STK(9) = _h_133;
      STK(10) = _h_134;
      STK(11) = _h_135;
      STK(12) = _h_136;
      STK(13) = _h_137;
      STK(14) = _h_138;
      STK(15) = _h_139;
      STK(16) = _h_140;
      STK(17) = _h_141;
      STK(18) = _h_142;
      STK(19) = _h_143;
      STK(20) = _h_144;
      STK(21) = _h_145;
      STK(22) = _h_146;
      STK(23) = _h_147;
      STK(24) = _h_148;
      STK(25) = _h_149;
      STK(26) = _h_111;
      STK(27) = _h_112;
      STK(28) = _h_113;
      STK(29) = _h_114;
      STK(30) = _h_115;
      STK(31) = _h_116;
      STK(32) = _h_117;
      STK(33) = FID_MAIN_K128;
      WL_PUSHN(34);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K128, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_124;
      e.mem[_t_8 + 1] = _h_125;
      e.mem[_t_8 + 2] = _h_126;
      e.mem[_t_8 + 3] = _h_127;
      e.mem[_t_8 + 4] = _h_128;
      e.mem[_t_8 + 5] = _h_129;
      e.mem[_t_8 + 6] = _h_130;
      e.mem[_t_8 + 7] = _h_131;
      e.mem[_t_8 + 8] = _h_132;
      e.mem[_t_8 + 9] = _h_133;
      e.mem[_t_8 + 10] = _h_134;
      e.mem[_t_8 + 11] = _h_135;
      e.mem[_t_8 + 12] = _h_136;
      e.mem[_t_8 + 13] = _h_137;
      e.mem[_t_8 + 14] = _h_138;
      e.mem[_t_8 + 15] = _h_139;
      e.mem[_t_8 + 16] = _h_140;
      e.mem[_t_8 + 17] = _h_141;
      e.mem[_t_8 + 18] = _h_142;
      e.mem[_t_8 + 19] = _h_143;
      e.mem[_t_8 + 20] = _h_144;
      e.mem[_t_8 + 21] = _h_145;
      e.mem[_t_8 + 22] = _h_146;
      e.mem[_t_8 + 23] = _h_147;
      e.mem[_t_8 + 24] = _h_148;
      e.mem[_t_8 + 25] = _h_149;
      e.mem[_t_8 + 26] = _h_111;
      e.mem[_t_8 + 27] = _h_112;
      e.mem[_t_8 + 28] = _h_113;
      e.mem[_t_8 + 29] = _h_114;
      e.mem[_t_8 + 30] = _h_115;
      e.mem[_t_8 + 31] = _h_116;
      e.mem[_t_8 + 32] = _h_117;
      WL_CONT = term_tsk(FID_MAIN_K128, _t_8);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_9 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _descriptions_0;
      e.mem[_t_9 + 1] = term_ctr(CID_CON, _nd_8);
      return term_tsk(FID_LIST_APPEND, _t_9);
    }
    r0 = _descriptions_0;
    r1 = term_ctr(CID_CON, _nd_8);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K128)
  {
    WL_POPN(33);
    u32 _h_163 = STK(0);
    u32 _h_164 = STK(1);
    u32 _h_165 = STK(2);
    u32 _h_166 = STK(3);
    Term _h_167 = STK(4);
    u32 _h_168 = STK(5);
    Term _h_169 = STK(6);
    Term _h_170 = STK(7);
    Term _h_171 = STK(8);
    Term _h_172 = STK(9);
    Term _h_173 = STK(10);
    u32 _h_174 = STK(11);
    u32 _h_175 = STK(12);
    u32 _h_176 = STK(13);
    u32 _h_177 = STK(14);
    u32 _h_178 = STK(15);
    u32 _h_179 = STK(16);
    Term _h_180 = STK(17);
    Term _h_181 = STK(18);
    Term _h_182 = STK(19);
    Term _h_183 = STK(20);
    Term _h_184 = STK(21);
    u32 _h_185 = STK(22);
    Term _h_186 = STK(23);
    u32 _h_187 = STK(24);
    u32 _h_188 = STK(25);
    Term _h_189 = STK(26);
    u32 _h_190 = STK(27);
    Term _h_191 = STK(28);
    u32 _h_192 = STK(29);
    Term _h_193 = STK(30);
    Term _h_194 = STK(31);
    Term _h_195 = STK(32);
    Term _h_162 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_163;
      STK(1) = _h_176;
      STK(2) = _h_177;
      STK(3) = _h_178;
      STK(4) = _h_179;
      STK(5) = _h_180;
      STK(6) = _h_181;
      STK(7) = _h_182;
      STK(8) = _h_183;
      STK(9) = _h_184;
      STK(10) = _h_185;
      STK(11) = _h_186;
      STK(12) = _h_187;
      STK(13) = _h_188;
      STK(14) = _h_189;
      STK(15) = _h_190;
      STK(16) = _h_191;
      STK(17) = _h_192;
      STK(18) = _h_193;
      STK(19) = _h_194;
      STK(20) = _h_195;
      STK(21) = _h_162;
      STK(22) = FID_MAIN_K129;
      WL_PUSHN(23);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K129, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_163;
      e.mem[_t_10 + 1] = _h_176;
      e.mem[_t_10 + 2] = _h_177;
      e.mem[_t_10 + 3] = _h_178;
      e.mem[_t_10 + 4] = _h_179;
      e.mem[_t_10 + 5] = _h_180;
      e.mem[_t_10 + 6] = _h_181;
      e.mem[_t_10 + 7] = _h_182;
      e.mem[_t_10 + 8] = _h_183;
      e.mem[_t_10 + 9] = _h_184;
      e.mem[_t_10 + 10] = _h_185;
      e.mem[_t_10 + 11] = _h_186;
      e.mem[_t_10 + 12] = _h_187;
      e.mem[_t_10 + 13] = _h_188;
      e.mem[_t_10 + 14] = _h_189;
      e.mem[_t_10 + 15] = _h_190;
      e.mem[_t_10 + 16] = _h_191;
      e.mem[_t_10 + 17] = _h_192;
      e.mem[_t_10 + 18] = _h_193;
      e.mem[_t_10 + 19] = _h_194;
      e.mem[_t_10 + 20] = _h_195;
      e.mem[_t_10 + 21] = _h_162;
      WL_CONT = term_tsk(FID_MAIN_K129, _t_10);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_11 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_164;
      e.mem[_t_11 + 1] = _h_165;
      e.mem[_t_11 + 2] = _h_166;
      e.mem[_t_11 + 3] = _h_167;
      e.mem[_t_11 + 4] = _h_168;
      e.mem[_t_11 + 5] = _h_169;
      e.mem[_t_11 + 6] = _h_170;
      e.mem[_t_11 + 7] = _h_171;
      e.mem[_t_11 + 8] = _h_172;
      e.mem[_t_11 + 9] = _h_173;
      e.mem[_t_11 + 10] = _h_174;
      e.mem[_t_11 + 11] = _h_175;
      return term_tsk(FID_SNAPSHOT, _t_11);
    }
    r0 = _h_164;
    r1 = _h_165;
    r2 = _h_166;
    r3 = _h_167;
    r4 = _h_168;
    r5 = _h_169;
    r6 = _h_170;
    r7 = _h_171;
    r8 = _h_172;
    r9 = _h_173;
    r10 = _h_174;
    r11 = _h_175;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K129)
  {
    WL_POPN(22);
    u32 _h_221 = STK(0);
    u32 _h_222 = STK(1);
    u32 _h_223 = STK(2);
    u32 _h_224 = STK(3);
    u32 _h_225 = STK(4);
    Term _h_226 = STK(5);
    Term _h_227 = STK(6);
    Term _h_228 = STK(7);
    Term _h_229 = STK(8);
    Term _h_230 = STK(9);
    u32 _h_231 = STK(10);
    Term _h_232 = STK(11);
    u32 _h_233 = STK(12);
    u32 _h_234 = STK(13);
    Term _h_235 = STK(14);
    u32 _h_236 = STK(15);
    Term _h_237 = STK(16);
    u32 _h_238 = STK(17);
    Term _h_239 = STK(18);
    Term _h_240 = STK(19);
    Term _h_241 = STK(20);
    Term _h_242 = STK(21);
    u32 _h_196 = r0;
    u32 _h_197 = r1;
    u32 _h_198 = r2;
    Term _h_199 = r3;
    u32 _h_200 = r4;
    Term _h_201 = r5;
    Term _h_202 = r6;
    Term _h_203 = r7;
    Term _h_204 = r8;
    Term _h_205 = r9;
    u32 _h_206 = r10;
    u32 _h_207 = r11;
    u32 _h_208 = r12;
    u32 _h_209 = r13;
    u32 _h_210 = r14;
    u32 _h_211 = r15;
    Term _h_212 = r16;
    Term _h_213 = r17;
    Term _h_214 = r18;
    Term _h_215 = r19;
    Term _h_216 = r20;
    u32 _h_217 = r21;
    Term _h_218 = r22;
    u32 _h_219 = r23;
    u32 _h_220 = r24;
    WL_OPEN
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _o_1[1];
    if (spin_11(e, _o_1, _h_221) == 0) {
      return 0;
    }
    _v_15 = _o_1[0];
    _v_14 = _v_15;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    Term _o_2[29];
    if (spin_12(e, _o_2, _v_14, _h_222, _h_223, _h_224, _h_225, _h_226, _h_227, blk_loc(e.mem, _h_227), _h_228, _h_229, blk_loc(e.mem, _h_229), _h_230, blk_loc(e.mem, _h_230), _h_231, _h_232, blk_loc(e.mem, _h_232), _h_233, _h_234, _h_235, blk_loc(e.mem, _h_235), _h_236, _h_237, blk_loc(e.mem, _h_237), _h_238, _h_239, blk_loc(e.mem, _h_239), _h_240, blk_loc(e.mem, _h_240), _h_241, blk_loc(e.mem, _h_241), _h_242, blk_loc(e.mem, _h_242), _h_196, _h_197, _h_198, _h_199, blk_loc(e.mem, _h_199), _h_200, _h_201, _h_202, blk_loc(e.mem, _h_202), _h_203, blk_loc(e.mem, _h_203), _h_204, blk_loc(e.mem, _h_204), _h_205, blk_loc(e.mem, _h_205), _h_206, _h_207, _h_208, _h_209, _h_210, _h_211, _h_212, _h_213, blk_loc(e.mem, _h_213), _h_214, _h_215, blk_loc(e.mem, _h_215), _h_216, blk_loc(e.mem, _h_216), _h_217, _h_218, blk_loc(e.mem, _h_218), _h_219, _h_220) == 0) {
      return 0;
    }
    _v_16 = _o_2[0];
    _v_17 = _o_2[1];
    _v_18 = _o_2[2];
    _v_19 = _o_2[3];
    _v_20 = _o_2[4];
    _v_21 = _o_2[5];
    _v_22 = _o_2[6];
    _v_23 = _o_2[7];
    _v_24 = _o_2[8];
    _v_25 = _o_2[9];
    _v_26 = _o_2[10];
    _v_27 = _o_2[11];
    _v_28 = _o_2[12];
    _v_29 = _o_2[13];
    _v_30 = _o_2[14];
    _v_31 = _o_2[15];
    _v_32 = _o_2[16];
    _v_33 = _o_2[17];
    _v_34 = _o_2[18];
    _v_35 = _o_2[19];
    _v_36 = _o_2[20];
    _v_37 = _o_2[21];
    _v_38 = _o_2[22];
    _v_39 = _o_2[23];
    _v_40 = _o_2[24];
    _v_41 = _o_2[25];
    _v_42 = _o_2[26];
    _v_43 = _o_2[27];
    _v_44 = _o_2[28];
    r0 = _v_16;
    r1 = _v_17;
    r2 = _v_18;
    r3 = _v_19;
    r4 = _v_20;
    r5 = _v_21;
    r6 = _v_22;
    r7 = _v_23;
    r8 = _v_24;
    r9 = _v_25;
    r10 = _v_26;
    r11 = _v_27;
    r12 = _v_28;
    r13 = _v_29;
    r14 = _v_30;
    r15 = _v_31;
    r16 = _v_32;
    r17 = _v_33;
    r18 = _v_34;
    r19 = _v_35;
    r20 = _v_36;
    r21 = _v_37;
    r22 = _v_38;
    r23 = _v_39;
    r24 = _v_40;
    r25 = _v_41;
    r26 = _v_42;
    r27 = _v_43;
    r28 = _v_44;
    WL_RETN(29);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K130)
  {
    WL_POPN(1);
    u32 _h_268 = STK(0);
    u32 _h_243 = r0;
    u32 _h_244 = r1;
    u32 _h_245 = r2;
    Term _h_246 = r3;
    u32 _h_247 = r4;
    Term _h_248 = r5;
    Term _h_249 = r6;
    Term _h_250 = r7;
    Term _h_251 = r8;
    Term _h_252 = r9;
    u32 _h_253 = r10;
    u32 _h_254 = r11;
    u32 _h_255 = r12;
    u32 _h_256 = r13;
    u32 _h_257 = r14;
    u32 _h_258 = r15;
    Term _h_259 = r16;
    Term _h_260 = r17;
    Term _h_261 = r18;
    Term _h_262 = r19;
    Term _h_263 = r20;
    u32 _h_264 = r21;
    Term _h_265 = r22;
    u32 _h_266 = r23;
    u32 _h_267 = r24;
    WL_OPEN
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _o_3[1];
    if (spin_11(e, _o_3, _h_268) == 0) {
      return 0;
    }
    _v_46 = _o_3[0];
    _v_45 = _v_46;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    Term _o_4[29];
    if (spin_22(e, _o_4, _v_45, _h_243, _h_244, _h_245, _h_246, blk_loc(e.mem, _h_246), _h_247, _h_248, _h_249, blk_loc(e.mem, _h_249), _h_250, blk_loc(e.mem, _h_250), _h_251, blk_loc(e.mem, _h_251), _h_252, blk_loc(e.mem, _h_252), _h_253, _h_254, _h_255, _h_256, _h_257, _h_258, _h_259, _h_260, blk_loc(e.mem, _h_260), _h_261, _h_262, blk_loc(e.mem, _h_262), _h_263, blk_loc(e.mem, _h_263), _h_264, _h_265, blk_loc(e.mem, _h_265), _h_266, _h_267) == 0) {
      return 0;
    }
    _v_47 = _o_4[0];
    _v_48 = _o_4[1];
    _v_49 = _o_4[2];
    _v_50 = _o_4[3];
    _v_51 = _o_4[4];
    _v_52 = _o_4[5];
    _v_53 = _o_4[6];
    _v_54 = _o_4[7];
    _v_55 = _o_4[8];
    _v_56 = _o_4[9];
    _v_57 = _o_4[10];
    _v_58 = _o_4[11];
    _v_59 = _o_4[12];
    _v_60 = _o_4[13];
    _v_61 = _o_4[14];
    _v_62 = _o_4[15];
    _v_63 = _o_4[16];
    _v_64 = _o_4[17];
    _v_65 = _o_4[18];
    _v_66 = _o_4[19];
    _v_67 = _o_4[20];
    _v_68 = _o_4[21];
    _v_69 = _o_4[22];
    _v_70 = _o_4[23];
    _v_71 = _o_4[24];
    _v_72 = _o_4[25];
    _v_73 = _o_4[26];
    _v_74 = _o_4[27];
    _v_75 = _o_4[28];
    r0 = _v_47;
    r1 = _v_48;
    r2 = _v_49;
    r3 = _v_50;
    r4 = _v_51;
    r5 = _v_52;
    r6 = _v_53;
    r7 = _v_54;
    r8 = _v_55;
    r9 = _v_56;
    r10 = _v_57;
    r11 = _v_58;
    r12 = _v_59;
    r13 = _v_60;
    r14 = _v_61;
    r15 = _v_62;
    r16 = _v_63;
    r17 = _v_64;
    r18 = _v_65;
    r19 = _v_66;
    r20 = _v_67;
    r21 = _v_68;
    r22 = _v_69;
    r23 = _v_70;
    r24 = _v_71;
    r25 = _v_72;
    r26 = _v_73;
    r27 = _v_74;
    r28 = _v_75;
    WL_RETN(29);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K131)
  {
    WL_POPN(1);
    u32 _h_272 = STK(0);
    Term _h_269 = r0;
    Term _h_270 = r1;
    Term _h_271 = r2;
    WL_OPEN
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _o_5[1];
    if (spin_11(e, _o_5, _h_272) == 0) {
      return 0;
    }
    _v_77 = _o_5[0];
    _v_76 = _v_77;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    Term _v_100 = 0;
    Term _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    Term _v_106 = 0;
    Term _o_6[29];
    if (spin_23(e, _o_6, _v_76, _h_269, blk_loc(e.mem, _h_269), _h_270, _h_271, blk_loc(e.mem, _h_271)) == 0) {
      return 0;
    }
    _v_78 = _o_6[0];
    _v_79 = _o_6[1];
    _v_80 = _o_6[2];
    _v_81 = _o_6[3];
    _v_82 = _o_6[4];
    _v_83 = _o_6[5];
    _v_84 = _o_6[6];
    _v_85 = _o_6[7];
    _v_86 = _o_6[8];
    _v_87 = _o_6[9];
    _v_88 = _o_6[10];
    _v_89 = _o_6[11];
    _v_90 = _o_6[12];
    _v_91 = _o_6[13];
    _v_92 = _o_6[14];
    _v_93 = _o_6[15];
    _v_94 = _o_6[16];
    _v_95 = _o_6[17];
    _v_96 = _o_6[18];
    _v_97 = _o_6[19];
    _v_98 = _o_6[20];
    _v_99 = _o_6[21];
    _v_100 = _o_6[22];
    _v_101 = _o_6[23];
    _v_102 = _o_6[24];
    _v_103 = _o_6[25];
    _v_104 = _o_6[26];
    _v_105 = _o_6[27];
    _v_106 = _o_6[28];
    r0 = _v_78;
    r1 = _v_79;
    r2 = _v_80;
    r3 = _v_81;
    r4 = _v_82;
    r5 = _v_83;
    r6 = _v_84;
    r7 = _v_85;
    r8 = _v_86;
    r9 = _v_87;
    r10 = _v_88;
    r11 = _v_89;
    r12 = _v_90;
    r13 = _v_91;
    r14 = _v_92;
    r15 = _v_93;
    r16 = _v_94;
    r17 = _v_95;
    r18 = _v_96;
    r19 = _v_97;
    r20 = _v_98;
    r21 = _v_99;
    r22 = _v_100;
    r23 = _v_101;
    r24 = _v_102;
    r25 = _v_103;
    r26 = _v_104;
    r27 = _v_105;
    r28 = _v_106;
    WL_RETN(29);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========



// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
