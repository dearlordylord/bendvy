function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $consume$(($resource$045control$058main$()));
}

function $consume$(_delivered_0) {
  if (_delivered_0.$ === "resource-control.Delivered") {
    const _factory_0 = _delivered_0["factory"];
    const _world_0 = _delivered_0["world"];
    const _app_0 = _delivered_0["app"];
    const _description_0 = _delivered_0["description"];
    return $before_seen$(_factory_0, _app_0, _description_0, ($snapshot$(_world_0)));
  } else if (_delivered_0.$ === "resource-control.BuildRejected") {
    const _factory_1 = _delivered_0["factory"];
    const _world_1 = _delivered_0["world"];
    const _owners_0 = _delivered_0["owners"];
    return $build_failed$(($factory_next$(_factory_1)), _owners_0, ($snapshot$(_world_1)));
  } else {
    const _factory_2 = _delivered_0["factory"];
    const _resource_0 = _delivered_0["resource"];
    return $create_failed$(($factory_next$(_factory_2)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058view$(_resource_0)));
  }
}

function $resource$045control$058main$() {
  return $resource$045control$058created$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), array_new(1, 17))));
}

function $before_seen$(_factory_0, _app_0, _first_0, _got_0) {
  const _world_0 = _got_0["fst"];
  const _before_0 = _got_0["snd"];
  return $second$(_factory_0, _world_0, _before_0, _first_0, ($app$058describe$1260$(_app_0)));
}

function $snapshot$(_world_0) {
  return $projected$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $build_failed$(_next_0, _owners_0, _got_0) {
  const _view_0 = _got_0["snd"];
  return {$: "BuildRejected", "factoryNext": _next_0, "snapshot": _view_0};
}

function $factory_next$(_factory_0) {
  const _next_0 = _factory_0["nextNamespace"];
  return _next_0;
}

function $create_failed$(_next_0, _got_0) {
  const _view_0 = _got_0["snd"];
  return {$: "CreateRejected", "factoryNext": _next_0, "resource": _view_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058view$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058sized$({$: "Tuple", fst: _owner_0, snd: _owner_0.length});
}

function $resource$045control$058created$(_result_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "resource-control.CreateRejected", "factory": _factory_0, "resource": _resource_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    const _schema_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045schema$058resource_schema$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045schema$058resource$1260$("Settings"))));
    return $resource$045control$058built$(_factory_1, _world_0, ($app$058build$1260$("Update", {$: "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Entry", "step": {$: "../../../../../../../../../../../bendvy/src/ecs/schedule.Phase", "name": "Update"}, "requirements": {$: "Nil"}}, ($app$058empty$1260$(1, {$: "app.Enabled"}, _schema_0)))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $second$(_factory_0, _world_0, _before_0, _first_0, _got_0) {
  const _app_0 = _got_0["fst"];
  const _repeated_0 = _got_0["snd"];
  return $disabled$(_factory_0, _world_0, _before_0, {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _repeated_0, "tail": {$: "Nil"}}}, ($app$058describe$1260$(($disable$(_app_0)))));
}

function $app$058describe$1260$(_app_0) {
  const _schema_0 = _app_0["schema"];
  const _t_0 = _app_0["debug"];
  if (_t_0.$ === "app.Disabled") {
    const _bindings_0 = _app_0["bindings"];
    const _schedule_0 = _app_0["schedule"];
    return {$: "Tuple", "fst": {$: "app.Application", "schema": _schema_0, "debug": {$: "app.Disabled"}, "bindings": _bindings_0, "schedule": _schedule_0}, "snd": {$: "None"}};
  } else {
    const _bindings_1 = _app_0["bindings"];
    const _t_1 = _app_0["schedule"];
    const _t_2 = _t_1["schedule"];
    const _namespace_0 = _t_2["namespace"];
    const _name_0 = _t_2["name"];
    const _steps_0 = _t_2["steps"];
    const _owners_0 = _t_2["owners"];
    const _requirements_0 = _t_1["requirements"];
    return {$: "Tuple", "fst": {$: "app.Application", "schema": _schema_0, "debug": {$: "app.Enabled"}, "bindings": _bindings_1, "schedule": {$: "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": {$: "../../../../../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, "requirements": _requirements_0}}, "snd": {$: "Some", "value": {$: "app.Description", "schema": ($retained$045schema$058entries$1260$(_schema_0)), "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "systems": ($app$058entries$1260$(_bindings_1))}}};
  }
}

function $projected$(_got_0) {
  const _world_0 = _got_0["fst"];
  const _resourceView_0 = _got_0["snd"];
  return $counted$(_resourceView_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058view$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058sized$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _length_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058completed$(_length_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058collect$(_length_0, 0, _owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045schema$058resource_schema$1260$(_declaration_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045schema$058resource_key$1260$(_declaration_0));
  return {$: "../../../../../../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Resource"}, "key": _key_0, "name": _key_0}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045schema$058resource$1260$(_key_0) {
  return {$: "../../../../../../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/ordinary-schema.Resource", "key": _key_0};
}

function $resource$045control$058built$(_factory_0, _world_0, _result_0) {
  if (_result_0.$ === "app.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "resource-control.BuildRejected", "factory": _factory_0, "world": _world_0, "owners": _owners_0};
  } else {
    const _app_0 = _result_0["app"];
    return $resource$045control$058described$(_factory_0, _world_0, ($app$058describe$1260$(_app_0)));
  }
}

function $app$058build$1260$(_name_0, _plan_0, _collected_0) {
  const _schema_0 = _collected_0["schema"];
  const _debug_0 = _collected_0["debug"];
  const _namespace_0 = _collected_0["namespace"];
  const _bindings_0 = _collected_0["bindings"];
  const _owners_0 = _collected_0["owners"];
  const _t_0 = _collected_0["valid"];
  if (!_t_0) {
    return {$: "app.Invalid", "owners": _owners_0};
  } else {
    return $app$058built$1260$(_schema_0, _debug_0, _bindings_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, ($app$058ids$1260$(_bindings_0)), _owners_0)));
  }
}

function $app$058empty$1260$(_namespace_0, _debug_0, _schema_0) {
  return {$: "app.Owners", "schema": _schema_0, "debug": _debug_0, "namespace": _namespace_0, "bindings": {$: "Nil"}, "owners": {$: "Unit"}, "valid": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": {$: "Unit"}, "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $disabled$(_factory_0, _world_0, _before_0, _descriptions_0, _got_0) {
  const _app_0 = _got_0["fst"];
  const _last_0 = _got_0["snd"];
  return $finished$(($factory_next$(_factory_0)), _before_0, _app_0, ($List$append$(_descriptions_0, {$: "Con", "head": _last_0, "tail": {$: "Nil"}})), ($snapshot$(_world_0)));
}

function $disable$(_app_0) {
  const _schema_0 = _app_0["schema"];
  const _bindings_0 = _app_0["bindings"];
  const _schedule_0 = _app_0["schedule"];
  return {$: "app.Application", "schema": _schema_0, "debug": {$: "app.Disabled"}, "bindings": _bindings_0, "schedule": _schedule_0};
}

function $retained$045schema$058entries$1260$(_catalog_0) {
  const _entries_0 = _catalog_0["entries"];
  return _entries_0;
}

function $app$058entries$1260$(_bindings_0) {
  if (_bindings_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _bindings_0["head"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _slot_0 = _t_0["slot"];
    const _clauses_0 = _t_0["clauses"];
    const _rest_0 = _bindings_0["tail"];
    return {$: "Con", "head": {$: "app.Entry", "id": _id_0, "name": _name_0, "access": _access_0, "slot": _slot_0, "clauses": _clauses_0}, "tail": ($app$058entries$1260$(_rest_0))};
  }
}

function $counted$(_resourceView_0, _got_0) {
  const _t_0 = _got_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _pendingCount_0 = _got_0["snd"];
  return $bits_seen$(_resourceView_0, _pendingCount_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047scenario$045observation$058bits$(_capacity_0, 0, _live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058completed$(_length_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../../../../bendvy/experiments/public-simulation/bend-v1/owner-view.FullCell", "length": _length_0, "values": _values_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058collect$(_count_0, _index_0, _owner_0) {
  if (_count_0 === 0) {
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_count_0 - 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058fetched$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058collect$(_rest_0, ((_index_0 + 1) >>> 0), _x_0);
}), {$: "Tuple", fst: _owner_0, snd: _owner_0[_index_0 % _owner_0.length]});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045schema$058resource_key$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $resource$045control$058described$(_factory_0, _world_0, _got_0) {
  const _app_0 = _got_0["fst"];
  const _description_0 = _got_0["snd"];
  return {$: "resource-control.Delivered", "factory": _factory_0, "world": _world_0, "app": _app_0, "description": _description_0};
}

function $app$058built$1260$(_schema_0, _debug_0, _bindings_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "app.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _result_0["schedule"];
    return {$: "app.Built", "app": {$: "app.Application", "schema": _schema_0, "debug": _debug_0, "bindings": _bindings_0, "schedule": _schedule_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0)), _catalog_0, _owners_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0)))));
}

function $app$058ids$1260$(_bindings_0) {
  if (_bindings_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _bindings_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _bindings_0["tail"];
    return {$: "Con", "head": _id_0, "tail": ($app$058ids$1260$(_rest_0))};
  }
}

function $finished$(_next_0, _before_0, _app_0, _descriptions_0, _got_0) {
  const _after_0 = _got_0["snd"];
  return {$: "Reported", "report": {$: "Report", "factoryNext": _next_0, "before": _before_0, "after": _after_0, "descriptions": _descriptions_0}};
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $bits_seen$(_resourceView_0, _pendingCount_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _got_0) {
  const _live_0 = _got_0["fst"];
  const _bits_0 = _got_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "Snapshot", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "capacity": _capacity_0, "depth": _depth_0, "liveBits": _bits_0, "store": _store_0, "resource": _resourceView_0, "events": _events_0, "pendingCount": _pendingCount_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}};
}

function $$$$047scenario$045observation$058bits$(_count_0, _id_0, _live_0) {
  if (_count_0 === 0) {
    return {$: "Tuple", "fst": _live_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_count_0 - 1);
    return $$$$047scenario$045observation$058bits_got$(run_clo((_x_0) => {
  return $$$$047scenario$045observation$058bits$(_rest_0, ((_id_0 + 1) >>> 0), _x_0);
}), {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058fetched$(_next_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058prepended$(_value_0, _next_0(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058finish_build$1260$(_built_0, _needs_0) {
  if (_built_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Built", "schedule": {$: "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058flatten$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0) {
  if (_plan_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058requirements$1260$(_right_0)));
  }
}

function $$$$047scenario$045observation$058bits_got$(_next_0, _got_0) {
  const _live_0 = _got_0["fst"];
  const _value_0 = _got_0["snd"];
  return $$$$047scenario$045observation$058bits_tail$(_value_0, _next_0(_live_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045simulation$047bend$045v1$047owner$045view$058prepended$(_value_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../../../../../../../bendvy/src/ecs/schedule.Built", "schedule": {$: "../../../../../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_seen_0, _head_0)), _head_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $$$$047scenario$045observation$058bits_tail$(_value_0, _got_0) {
  const _live_0 = _got_0["fst"];
  const _tail_0 = _got_0["snd"];
  return {$: "Tuple", "fst": _live_0, "snd": {$: "Con", "head": _value_0, "tail": _tail_0}};
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058unique_add$1260$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1260$(_head_0, _item_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058contains$1260$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$045provision$058same$1260$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../../../../../../../../../../../bendvy/src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,3,0,0,1,0,1,25,1,0,2,0,1,40,2,41,2,0,2,0,1,40,2,108,7,0,1,3,0,4,0,0,40,1,41,14,41,27,201,0,7,0,1,4,0,13,0,0,40,1,40,2,40,3,40,4,74,5,75,6,101,6,108,8,135,9,40,10,157,11,40,12,40,2,7,1,2,5,0,0,1,6,0,2,1,0,90,1,75,7,1,2,7,0,0,0,8,0,0,0,7,0,1,9,0,0,0,7,0,1,10,0,2,0,0,74,1,119,7,1,2,11,0,0,1,12,0,2,1,0,134,1,119,0,7,1,2,13,0,0,1,14,0,2,1,0,150,1,135,7,1,1,15,0,0,0,7,1,2,16,0,0,1,17,0,2,1,0,172,1,157,7,1,1,18,0,3,0,0,40,1,185,2,186,4,7,1,2,19,0,0,1,20,0,2,1,0,185,1,186,7,1,2,21,0,0,1,22,0,2,1,0,216,1,201,7,1,2,23,0,0,0,24,0,1,0,0,229,7,1,1,25,0,5,0,0,246,1,40,2,185,3,297,4,333,7,1,2,26,0,0,1,27,0,2,1,0,261,1,246,7,1,1,28,0,3,0,0,274,1,185,2,185,7,0,5,29,0,0,0,30,0,0,0,31,0,0,0,32,0,0,0,33,0,0,0,7,1,2,34,0,0,1,35,0,2,1,0,312,1,297,7,1,3,36,0,2,0,0,40,1,40,37,0,1,0,0,185,38,0,0,0,7,1,2,39,0,0,1,40,0,2,1,0,348,1,333,7,1,1,41,0,5,0,0,40,1,185,2,186,3,185,4,365,7,1,2,42,0,0,1,43,0,2,1,0,380,1,365,7,1,1,44,0,2,0,0,185,1,391,7,0,7,45,0,0,0,46,0,0,0,47,0,0,0,48,0,0,0,49,0,0,0,50,0,0,0,51,0,0,0],["Reported","BuildRejected","CreateRejected","Report","Snapshot","Nil","Con","False","True","Unit","../../../../../../../../../../../bendvy/experiments/public-simulation/bend-v1/owner-view.FullCell","Nil","Con","Nil","Con","Unit","Nil","Con","../../../../../../../../../../../bendvy/src/ecs/world.RegistrationMeta","Nil","Con","Nil","Con","None","Some","app.Description","Nil","Con","../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Entry","../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Component","../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Resource","../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Event","../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Relation","../../../../../../../../../../../bendvy/src/ecs/schema-fragments.Service","Nil","Con","../../../../../../../../../../../bendvy/src/ecs/schedule.System","../../../../../../../../../../../bendvy/src/ecs/schedule.Phase","../../../../../../../../../../../bendvy/src/ecs/schedule.Barrier","Nil","Con","app.Entry","Nil","Con","../declaration.Clause","../declaration.Read","../declaration.Write","../declaration.Optional","../declaration.With","../declaration.Without","../declaration.Added","../declaration.Changed"]]);