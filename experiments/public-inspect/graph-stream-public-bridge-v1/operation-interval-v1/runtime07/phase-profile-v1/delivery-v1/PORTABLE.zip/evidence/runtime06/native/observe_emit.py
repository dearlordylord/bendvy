#!/usr/bin/env python3
"""Read-only, exact-process observer for one admitted Native emit command.

This does not run, signal, trace, or alter the collector or compiler. It reads
/proc only for descendants of its launch shell and writes two sidecar records.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

DISCOVERY_SECONDS = 60
SAMPLE_SECONDS = 1


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def exclusive_json(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode('utf-8')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, 'O_NOFOLLOW'):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def lexical(path):
    value = str(path)
    if not path.is_absolute() or str(path) != value or '..' in path.parts:
        raise ValueError('expected canonical absolute path: ' + value)
    for parent in (path, *path.parents):
        if parent.is_symlink():
            raise ValueError('symlink path component: ' + str(parent))
    return path


def parse_stat(text):
    close = text.rfind(')')
    if close < 0:
        raise ValueError('malformed /proc stat')
    prefix = text[:close + 1]
    tail = text[close + 2:].split()
    if len(tail) < 22:
        raise ValueError('short /proc stat')
    return {
        'comm': prefix[prefix.find('(') + 1:-1],
        'state': tail[0],
        'ppid': int(tail[1]),
        'minorFaults': int(tail[7]),
        'majorFaults': int(tail[9]),
        'utimeTicks': int(tail[11]),
        'stimeTicks': int(tail[12]),
        'startTimeTicks': int(tail[19]),
        'rssPages': int(tail[21]),
    }


def process_table():
    table = {}
    for item in Path('/proc').iterdir():
        if not item.name.isdecimal():
            continue
        try:
            table[int(item.name)] = parse_stat((item / 'stat').read_text())
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, OSError):
            continue
    return table


def belongs_to_owner(pid, table, owner_pid, owner_start):
    seen = set()
    cursor = pid
    while cursor in table and cursor not in seen:
        seen.add(cursor)
        row = table[cursor]
        if cursor == owner_pid:
            return row['startTimeTicks'] == owner_start
        cursor = row['ppid']
    return False


def proc_details(pid):
    root = Path('/proc') / str(pid)
    argv_raw = (root / 'cmdline').read_bytes()
    argv = [part.decode('utf-8', 'surrogateescape') for part in argv_raw.split(b'\0') if part]
    exe_raw = os.readlink(root / 'exe')
    cwd_raw = os.readlink(root / 'cwd')
    status = (root / 'status').read_text()
    vmrss = None
    cpus_allowed = None
    for line in status.splitlines():
        if line.startswith('VmRSS:'):
            fields = line.split()
            vmrss = int(fields[1]) if len(fields) >= 2 else None
        elif line.startswith('Cpus_allowed_list:'):
            cpus_allowed = line.split(':', 1)[1].strip()
    return {
        'argv': argv,
        'exeLink': exe_raw,
        'exeCanonical': os.path.realpath(exe_raw),
        'cwdLink': cwd_raw,
        'vmRssKiB': vmrss,
        'cpusAllowedList': cpus_allowed,
    }


def host_sample():
    lines = Path('/proc/stat').read_text().splitlines()
    total = next((line.split()[1:] for line in lines if line.startswith('cpu ')), None)
    cpu5 = next((line.split()[1:] for line in lines if line.startswith('cpu5 ')), None)
    return {
        'cpuTotalTicks': [int(x) for x in total] if total is not None else None,
        'cpu5Ticks': [int(x) for x in cpu5] if cpu5 is not None else None,
        'loadAverage': [float(x) for x in Path('/proc/loadavg').read_text().split()[:3]],
    }


def cgroup_path(pid):
    """Return this process's cgroup-v2 control directory, if visible."""
    try:
        rows = (Path('/proc') / str(pid) / 'cgroup').read_text().splitlines()
    except (FileNotFoundError, PermissionError, OSError):
        return None
    unified = next((row[3:] for row in rows if row.startswith('0::/')), None)
    if unified is None or '..' in Path(unified).parts:
        return None
    return Path('/sys/fs/cgroup') / unified.lstrip('/')


def cgroup_sample(directory):
    if directory is None:
        return {'available': False}
    result = {'available': True, 'directory': str(directory)}
    for name in ('cpu.stat', 'cpu.max'):
        path = directory / name
        try:
            raw = path.read_text().strip()
        except (FileNotFoundError, PermissionError, OSError) as error:
            result[name] = {'path': str(path), 'readError': type(error).__name__}
        else:
            if name == 'cpu.stat':
                values = {}
                for line in raw.splitlines():
                    fields = line.split()
                    if len(fields) == 2:
                        try:
                            values[fields[0]] = int(fields[1])
                        except ValueError:
                            values[fields[0]] = fields[1]
                result[name] = {'path': str(path), 'values': values}
            else:
                result[name] = {'path': str(path), 'value': raw}
    return result


def output_metadata(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return {'exists': False}
    return {
        'exists': True,
        'isRegularFile': path.is_file() and not path.is_symlink(),
        'isSymlink': path.is_symlink(),
        'bytes': st.st_size,
        'mtimeNs': st.st_mtime_ns,
        'device': st.st_dev,
        'inode': st.st_ino,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()

    plan_path = lexical(Path(args.plan))
    script_path = lexical(Path(__file__))
    plan_bytes = plan_path.read_bytes()
    plan_sha = hashlib.sha256(plan_bytes).hexdigest()
    if plan_sha != args.plan_sha256:
        raise ValueError('plan SHA does not match admitted hash')
    plan = json.loads(plan_bytes)
    observer_binding = plan['processObserver']
    if observer_binding.get('schema') != 'read-only-bend-emitter-observer-v1':
        raise ValueError('unsupported observer binding')
    if lexical(Path(observer_binding['script'])) != script_path:
        raise ValueError('observer script path differs from plan binding')
    script_sha = hashlib.sha256(script_path.read_bytes()).hexdigest()
    if plan['pins'].get(str(script_path)) != script_sha or observer_binding.get('scriptSHA256') != script_sha:
        raise ValueError('observer source differs from its pinned plan binding')
    argv_template = [str(script_path), '--plan', str(plan_path), '--plan-sha256', '{plan_sha256}']
    if observer_binding['pythonArgvTemplate'] != argv_template:
        raise ValueError('observer Python argv template differs from plan binding')
    expected_argv = [str(script_path), '--plan', str(plan_path), '--plan-sha256', plan_sha]
    if sys.argv != expected_argv:
        raise ValueError('observer argv differs from plan binding')
    if os.path.realpath(sys.executable) != os.path.realpath(observer_binding['interpreter']):
        raise ValueError('observer interpreter differs from plan binding')
    observer_cpu = observer_binding['cpu']
    if type(observer_cpu) is not int or observer_binding['discoverySeconds'] != DISCOVERY_SECONDS or observer_binding['sampleSeconds'] != SAMPLE_SECONDS:
        raise ValueError('observer CPU or sampling bounds differ from implementation')
    if observer_binding['taskset'] != plan['tools']['taskset']:
        raise ValueError('observer taskset differs from plan tool binding')
    expected_taskset_argv = [
        observer_binding['taskset'], '-c', str(observer_cpu), observer_binding['interpreter'],
        str(script_path), '--plan', str(plan_path), '--plan-sha256', '{plan_sha256}',
    ]
    if observer_binding['tasksetArgvTemplate'] != expected_taskset_argv:
        raise ValueError('observer taskset argv template differs from plan binding')
    if sorted(os.sched_getaffinity(0)) != [observer_cpu]:
        raise ValueError('observer affinity differs from plan binding')
    ready_path = lexical(Path(observer_binding['ready']))
    observation_path = lexical(Path(observer_binding['observation']))
    stdout_path = lexical(Path(observer_binding['stdout']))
    stderr_path = lexical(Path(observer_binding['stderr']))
    if os.path.realpath('/proc/self/fd/1') != str(stdout_path) or os.path.realpath('/proc/self/fd/2') != str(stderr_path):
        raise ValueError('observer stdout/stderr redirections differ from plan binding')
    if plan.get('role') != 'native' or [row.get('label') for row in plan.get('commands', [])] != ['emit', 'build', 'consumer']:
        raise ValueError('not the exact Native three-command plan')
    emit = plan['commands'][0]
    if emit.get('capSeconds') != 30:
        raise ValueError('unexpected emitter cap')
    taskset = plan['tools']['taskset']
    if emit['argv'][:3] != [taskset, '-c', '5']:
        raise ValueError('unexpected emitter taskset prefix')
    target_argv = emit['argv'][3:]
    if len(target_argv) != 4 or target_argv[0] != plan['tools']['bend'] or target_argv[2] != '-o':
        raise ValueError('unexpected Bend emitter argv shape')
    output_path = lexical(Path(plan['generated']))
    if target_argv[3] != str(output_path):
        raise ValueError('emitter output argv differs from generated path')
    cwd = lexical(Path(plan['cwd']))
    collector_binding = plan['collectorBinding']
    collector_path = lexical(Path(collector_binding['collector']['path']))
    python_path = lexical(Path(collector_binding['interpreter']['path']))
    collector_argv = [str(python_path), str(collector_path), 'run', str(plan_path), args.plan_sha256]
    collector_exe = os.path.realpath(str(python_path))
    bend_exe = os.path.realpath(target_argv[0])
    if not cwd.is_dir() or not output_path.parent.is_dir():
        raise ValueError('cwd/output parent must exist')
    if output_metadata(output_path)['exists']:
        raise ValueError('fresh generated C path must start absent')
    if any(path.exists() or path.is_symlink() for path in (ready_path, observation_path)):
        raise ValueError('observer sidecar outputs must start absent')

    owner_pid = os.getppid()
    owner_stat_path = Path('/proc') / str(owner_pid) / 'stat'
    owner_stat = parse_stat(owner_stat_path.read_text())
    observer_pid = os.getpid()
    observer_stat_path = Path('/proc') / str(observer_pid) / 'stat'
    observer_start = parse_stat(observer_stat_path.read_text())['startTimeTicks']
    started_ns = time.monotonic_ns()
    observer_cgroup_start = cgroup_sample(cgroup_path(observer_pid))
    ready = {
        'schema': 'bend-emitter-observer-ready-v1',
        'planPath': str(plan_path),
        'planSHA256': plan_sha,
        'ownerShell': {'pid': owner_pid, 'startTimeTicks': owner_stat['startTimeTicks']},
        'observer': {'pid': observer_pid, 'startTimeTicks': observer_start, 'affinity': sorted(os.sched_getaffinity(0))},
        'targetArgv': target_argv,
        'targetExeCanonical': bend_exe,
        'collectorArgv': collector_argv,
        'collectorExeCanonical': collector_exe,
        'cwd': str(cwd),
        'generatedC': str(output_path),
        'freshAtStart': True,
        'observerStartedUTC': utc_now(),
        'observerStartMonotonicNs': started_ns,
        'observerScriptSHA256': script_sha,
        'observerOutputPaths': {
            'ready': str(ready_path),
            'observation': str(observation_path),
            'stdout': str(stdout_path),
            'stderr': str(stderr_path),
        },
        'clockTicksPerSecond': os.sysconf('SC_CLK_TCK'),
        'pageSizeBytes': os.sysconf('SC_PAGE_SIZE'),
        'observerCgroupAtStart': observer_cgroup_start,
        'discoverySeconds': DISCOVERY_SECONDS,
        'sampleSeconds': SAMPLE_SECONDS,
        'discoveryPollSeconds': 0.5,
        'monitorScope': 'only descendants of the launching shell; exact collector argv/exe/cwd and exact Bend argv/exe/cwd required',
        'operations': 'read-only /proc and filesystem metadata; no signals, compiler controls, or environment/argv changes to collector/emitter',
    }
    exclusive_json(ready_path, ready)

    discovery_deadline = time.monotonic() + DISCOVERY_SECONDS
    bound = None
    while time.monotonic() < discovery_deadline:
        table = process_table()
        owner = table.get(owner_pid)
        if owner is None or owner['startTimeTicks'] != owner_stat['startTimeTicks']:
            break
        descendants = [pid for pid in table if pid != owner_pid and belongs_to_owner(pid, table, owner_pid, owner_stat['startTimeTicks'])]
        collectors = []
        for pid in descendants:
            try:
                details = proc_details(pid)
            except (FileNotFoundError, ProcessLookupError, PermissionError, OSError):
                continue
            if (details['argv'] == collector_argv and details['exeCanonical'] == collector_exe
                    and os.path.realpath(details['cwdLink']) == str(cwd)):
                collectors.append((pid, table[pid], details))
        for pid in descendants:
            try:
                details = proc_details(pid)
            except (FileNotFoundError, ProcessLookupError, PermissionError, OSError):
                continue
            if details['argv'] != target_argv or details['exeCanonical'] != bend_exe or os.path.realpath(details['cwdLink']) != str(cwd):
                continue
            chain = []
            cursor = pid
            while cursor in table and cursor != owner_pid:
                chain.append(cursor)
                cursor = table[cursor]['ppid']
            collector = next((item for item in collectors if item[0] in chain), None)
            if collector is not None:
                bound = {'pid': pid, 'stat': table[pid], 'details': details, 'collector': collector, 'chain': chain}
                break
        if bound is not None:
            break
        time.sleep(0.5)

    termination = 'target-not-seen-before-bounded-discovery-deadline'
    samples = []
    process_exit_utc = None
    pid_reuse_utc = None
    mismatch_utc = None
    target_cgroup = None
    target_cgroup_start = None
    if bound is not None:
        target_pid = bound['pid']
        target_start = bound['stat']['startTimeTicks']
        collector_pid, collector_stat, collector_details = bound['collector']
        target_cgroup = cgroup_path(target_pid)
        target_cgroup_start = cgroup_sample(target_cgroup)
        target_identity = {
            'pid': target_pid,
            'startTimeTicks': target_start,
            'argv': bound['details']['argv'],
            'exeLink': bound['details']['exeLink'],
            'exeCanonical': bound['details']['exeCanonical'],
            'cwdLink': bound['details']['cwdLink'],
            'collector': {
                'pid': collector_pid,
                'startTimeTicks': collector_stat['startTimeTicks'],
                'argv': collector_details['argv'],
                'exeCanonical': collector_details['exeCanonical'],
            },
            'ancestorPidsToOwner': bound['chain'],
        }
        termination = 'observing'
        next_sample = time.monotonic_ns()
        while True:
            now_ns = time.monotonic_ns()
            delay = (next_sample - now_ns) / 1_000_000_000
            if delay > 0:
                time.sleep(delay)
            now_ns = time.monotonic_ns()
            table = process_table()
            owner = table.get(owner_pid)
            if owner is None or owner['startTimeTicks'] != owner_stat['startTimeTicks']:
                termination = 'launch-shell-identity-lost'
                break
            current = table.get(target_pid)
            if current is None:
                termination = 'emitter-exit-observed'
                process_exit_utc = utc_now()
                break
            if current['startTimeTicks'] != target_start:
                termination = 'pid-reused-after-emitter'
                pid_reuse_utc = utc_now()
                break
            if current['state'] in ('Z', 'X'):
                termination = 'emitter-exit-observed'
                process_exit_utc = utc_now()
                break
            if not belongs_to_owner(target_pid, table, owner_pid, owner_stat['startTimeTicks']):
                termination = 'emitter-left-owned-ancestry'
                mismatch_utc = utc_now()
                break
            try:
                details = proc_details(target_pid)
                parent_details = proc_details(collector_pid)
            except (FileNotFoundError, ProcessLookupError, PermissionError, OSError):
                termination = 'emitter-exit-observed'
                process_exit_utc = utc_now()
                break
            current_collector = table.get(collector_pid)
            if (details['argv'] != target_argv or details['exeCanonical'] != bend_exe or os.path.realpath(details['cwdLink']) != str(cwd)
                    or current_collector is None or current_collector['startTimeTicks'] != collector_stat['startTimeTicks']
                    or parent_details['argv'] != collector_argv or parent_details['exeCanonical'] != collector_exe
                    or os.path.realpath(parent_details['cwdLink']) != str(cwd)):
                termination = 'bound-command-changed'
                mismatch_utc = utc_now()
                break
            observer_stat = parse_stat(observer_stat_path.read_text())
            samples.append({
                'sample': len(samples),
                'observedUTC': utc_now(),
                'elapsedMonotonicNs': str(now_ns - started_ns),
                'pid': target_pid,
                'startTimeTicks': current['startTimeTicks'],
                'state': current['state'],
                'utimeTicks': current['utimeTicks'],
                'stimeTicks': current['stimeTicks'],
                'rssPages': current['rssPages'],
                'minorFaults': current['minorFaults'],
                'majorFaults': current['majorFaults'],
                'vmRssKiB': details['vmRssKiB'],
                'cpusAllowedList': details['cpusAllowedList'],
                'observerProcess': {
                    'pid': observer_pid,
                    'startTimeTicks': observer_start,
                    'utimeTicks': observer_stat['utimeTicks'],
                    'stimeTicks': observer_stat['stimeTicks'],
                    'affinity': sorted(os.sched_getaffinity(0)),
                },
                'host': host_sample(),
                'output': output_metadata(output_path),
            })
            next_sample = time.monotonic_ns() + SAMPLE_SECONDS * 1_000_000_000

    final = {
        'schema': 'bend-emitter-process-observation-v1',
        'ready': ready,
        'target': target_identity if bound is not None else None,
        'samples': samples,
        'termination': termination,
        'processExitObservedUTC': process_exit_utc,
        'pidReuseObservedUTC': pid_reuse_utc,
        'identityMismatchObservedUTC': mismatch_utc,
        'observerFinishedUTC': utc_now(),
        'observerElapsedMonotonicNs': str(time.monotonic_ns() - started_ns),
        'generatedCAfterObserver': output_metadata(output_path),
        'targetCgroupAtFirstObservation': target_cgroup_start,
        'targetCgroupAtEnd': cgroup_sample(target_cgroup),
        'observerCgroupAtEnd': cgroup_sample(cgroup_path(observer_pid)),
        'samplingLimitations': 'one-second polling omits startup and final sub-second CPU/RSS changes; observer adds bounded CPU0 /proc-read overhead; no phase or performance attribution',
    }
    exclusive_json(observation_path, final)
    if bound is None:
        return 2
    if termination != 'emitter-exit-observed':
        return 3
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except BaseException as error:
        if isinstance(error, SystemExit):
            raise
        print(f'{type(error).__name__}: {error}', file=sys.stderr)
        raise SystemExit(1)
