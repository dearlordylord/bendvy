# runtime07 source-emitter profile

This is a bounded diagnostic of the existing complete 136-operation
operation-interval consumer. It is not a qualification run: the command used a
local diagnostic build of the official Bend 2.0.35 source under Bun 1.3.14,
CPU 5, with the existing 30-second source-emission cap. The retained receipt is
`native/receipt.json` (SHA-256
`559f059337cb8cf195e7230fb87ed7c0044a55d90d0105a5058d267cf0535e2a`), bound
to plan `native/plan.json` (SHA-256
`0261a5e3ae1cb6ca72d8b49f53d7c557f89702a77591c4df94fb36db20de25fa`). It is
`INCOMPLETE` after the child deadline; the generated C file is absent and
stdout/stderr are empty. No Clang build, executable, or runtime was produced.

The raw profile is `native/compile-book.jsonl`, 5,245,410 bytes and SHA-256
`7df66c3de11cd1e723212f45efe3096655d76351957d687a1530f4087be1ee7e`. It has
23,181 records. Instrumented `emit_body` calls completed for 3,709 definitions
in fact pass 0 (13.845 seconds summed) and 2,080 definitions in the partial
pass 1 (10.429 seconds summed); the last record is the start of
`inspector-query:composed_lookup_target~37` in pass 1. These are source-emitter
monotonic durations from the instrumented Bun process, not native compiler CPU
time or runtime measurements.

The dominant completed body time is in the composed query path:

| Source module | Pass 0 | Partial pass 1 | Total |
| --- | ---: | ---: | ---: |
| `inspector-query` | 6.773 s | 6.550 s | 13.323 s |
| `inspector-query-projection` | 2.221 s | 2.148 s | 4.369 s |

This does not attribute every cost to fusion, and the incomplete second pass
does not establish a final total. In pass 0, the profile contains 68 distinct
specialized definitions for each of `composed_scan`, `composed_lookup`,
`grant_composed`, `pair`, `pair_matches`, `pair_project`, and
`projected_left`. The partial pass 1 has all 68 `pair`/`pair_matches`/
`pair_project`/`projected_left` variants, 67 `composed_scan` starts, and fewer
starts for some lookup/enumeration helpers before the deadline. The consumer
has 16 relation declaration cases, calls both Inspector and Check paths, and
uses two schemas; machine query cases add further typed specializations. The
counts are observations from the retained profile, not a proof that the source
case count maps one-to-one to generated definitions.

The source path explains why this family is a plausible avoidable template
cost. The private consumer passes declarations statically through
`Calls.inspect` and `Calls.check`; `inspect_plan` and `condition_plan` call
`Decl.inspect`/`Decl.condition` with `~declaration`
(`operation-interval-v1/consumer.bend:67-70`). The current public wrappers
accept static declarations and pass static specs into the two typed relation
projections (`src/ecs/ordinary-inspector-relation.bend:58-61`). Those
projections pass `~spec` into `relations` and `Select.pair`
(`src/ecs/inspector-relation-projection.bend:37-42`, and the parallel
`src/ecs/check-relation-projection.bend:37-42`). `Select.pair` takes static
left and right selections (`src/ecs/inspector-query-projection.bend:76-91`),
and the composed query kernel propagates static `~selection` through lookup,
scan, enumeration, and the grant (`src/ecs/inspector-query.bend:126-165`).

The diagnostic compiler snapshot is based on upstream tag
`79df8d9c40722ee9507a1e253f283b51025f9d6c`; the uninstrumented
`comp.ts` hash is `32fb66e09f608ce9e4b173384bcfeec453db8c5bc96650e26ad861bef815a8d9`.
The retained instrumented snapshot is separately pinned in the plan and has
hash `d49c05b4913f3dd14a4777944b5dc574499a8699e48a6d84ab952e3ece304a46`.
Three exact source members have trailing whitespace or an extra final blank
line that makes the repository's cached whitespace check reject a plain-text
copy. The worktree copies remain byte-for-byte unchanged; the staged snapshot
retains their raw bytes as deterministic gzip members. `SOURCE-COMPRESSION-MAP.json`
binds each original logical path and raw size/hash to its compressed path and
size/hash. Decompressing each mapped member reconstructs the exact pinned
bytes; no frozen source, patch, receipt, or plan was normalized.
In that compiler, `file_book` computes dependency flatness from the reached
term graph (`comp.ts:1342-1427`). `flat_call` tests that result
(`837-840`); `emit_fuse` recursively emits a non-flat callee body, while flat
calls use `emit_native` (`2158-2183`). `emit_native` caches by the specialized
definition name plus erased argument layouts (`2200-2227`). `emit_body` uses
that fusion path for flat or one-use tail calls (`2531-2545`). `compile_book`
emits all selected definitions on each ownership/hot/stat fact pass
(`2782-2850`). This is source evidence for how many static variants can cost
repeated emitter work, but there is no generated C from this attempt with
which to quantify inlining or C size.

The narrow candidate for a separately reviewed source experiment is to keep
the public declaration APIs, `H`/`S`/`V` types, and owner-preserving query
results unchanged while testing an internal runtime-spec path for the ordinary
relation queries. `RQ.Spec<S>` is `Data` (`src/ecs/relation-query.bend:18-19`),
so that value can be evaluated as an ordinary argument while evaluator code
remains statically typed. `Select.DeclaredSelection<H,S,V>` is instead `Type`
and contains owner-taking callbacks
(`src/ecs/inspector-query-projection.bend:51-52`); it is not a `Data` payload
and must not be copied into both query closures or reused across affine owners.
A candidate should therefore keep `~spec` on the public grant and preserve the
returned `ComposedReadQuery` type. It can use small static wrappers for
Inspector and Check whose closures pass the concrete `RQ.Spec<S>` as an
ordinary argument to shared, relation-specific match/project kernels; those
kernels keep `~component` and `~world` static, accept runtime `spec`, and
thread `H` through each query operation. This avoids capturing or reusing the
affine `DeclaredSelection` value while allowing the expensive scan/lookup
body to share code across declaration values. The thin wrappers may still be
specialized per declaration, so a source/emission check must verify that the
large `composed_scan`/`composed_lookup` kernels actually share. Simply changing
the final `grant_composed` selection parameter may leave static specialization
in `relations`/`Select.pair`. The runtime form must continue to use the same
namespace/liveness checks, relation matching and projection, and separate
Inspector/Check owners. Existing `grant_composed` callers include
`ordinary-query-observable.bend` and both relation projections; they must keep
working unchanged. No core source change is part of this diagnostic, and the
candidate remains a hypothesis until a source check, the full independent
136-operation oracle on required backends, and a separately reviewed
performance measurement.

Pinned current-source hashes for the affected core boundary are:

| File | SHA-256 |
| --- | --- |
| `src/ecs/ordinary-inspector-relation.bend` | `be23061be395e35d8a3243cc2e9619a0a3fa0b18b167c67195657a213b2766be` |
| `src/ecs/inspector-relation-projection.bend` | `0655e6bd0a6d4e275fe5e4e444b11cf5f6d1ca72c716f58ac9d4d64d6dc99f0f` |
| `src/ecs/check-relation-projection.bend` | `291a9e3dd15902136308b282f3bd13cc68542fe76664108f51cbbb49f6086a8b` |
| `src/ecs/inspector-query.bend` | `7a4c90e0f1e63d6a89aea256bd96c874758db73865dad02481a32c1dded8b58d` |
| `src/ecs/inspector-query-projection.bend` | `422efbb7c19e8091a77f7e90e7f4e3d95474ae41d46e934b270b89638cd5f561` |
| `src/ecs/ordinary-query-observable.bend` | `826ff50600b6b789cbe53ea717f316ca7edbad4e8cb68f63ea8db29e2e6b12b5` |
| `src/ecs/ordinary-app-relation.bend` | `7d50aa1574b3cb09b3106a92b57f6b05cffe728b282f526d8442602f212c37cf` |
