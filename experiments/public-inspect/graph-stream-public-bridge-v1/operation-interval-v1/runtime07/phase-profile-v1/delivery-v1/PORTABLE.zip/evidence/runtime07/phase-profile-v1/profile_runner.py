#!/usr/bin/env python3
"""Run one pinned, diagnostic-only Bend source phase-profile command."""
from __future__ import annotations

import argparse
import difflib
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_file(path: Path) -> str:
    with path.open('rb') as stream:
        return digest(stream.read())


def exclusive_write(path: Path, data: bytes) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(path, flags, 0o600)
    try:
        offset = 0
        while offset < len(data):
            offset += os.write(fd, data[offset:])
    finally:
        os.close(fd)


def exclusive_json(path: Path, value: object) -> bytes:
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode('utf-8')
    exclusive_write(path, data)
    return data


def pin_snapshot(pins: dict[str, str]) -> dict[str, str]:
    actual = {}
    for raw, expected in pins.items():
        path = Path(raw)
        if not path.is_absolute() or path.is_symlink() or not path.is_file():
            raise ValueError('pinned regular file is unavailable: ' + raw)
        actual[raw] = hash_file(path)
        if actual[raw] != expected:
            raise ValueError('pinned file changed: ' + raw)
    return actual


def tree_inventory(root: Path) -> dict[str, str]:
    actual = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('symlink in pinned compiler tree: ' + str(path))
        if path.is_file():
            actual[path.relative_to(root).as_posix()] = hash_file(path)
    return actual


def file_record(path: Path) -> dict[str, object]:
    if not path.exists() and not path.is_symlink():
        return {'path': str(path), 'exists': False}
    if path.is_symlink() or not path.is_file():
        return {'path': str(path), 'exists': True, 'regular': False}
    raw = path.read_bytes()
    return {'path': str(path), 'exists': True, 'regular': True,
            'bytes': len(raw), 'sha256': digest(raw)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()

    script = Path(__file__).resolve()
    plan_path = Path(args.plan).resolve()
    frozen = plan_path.read_bytes()
    plan_sha = digest(frozen)
    if plan_sha != args.plan_sha256:
        raise ValueError('admitted plan hash mismatch')
    plan = json.loads(frozen)
    if (plan.get('format') != 'bend-compiler-phase-profile-v1'
            or plan.get('planPath') != str(plan_path)
            or plan.get('runner', {}).get('path') != str(script)
            or os.path.realpath(sys.executable) != plan['runner']['python']):
        raise ValueError('plan, runner, or interpreter binding mismatch')
    if hash_file(script) != plan['runner']['sha256']:
        raise ValueError('runner source changed')

    pins = plan['pins']
    before = pin_snapshot(pins)
    source = plan['compilerSource']
    upstream = Path(source['officialRoot'])
    copy = Path(source['copyRoot'])
    if (tree_inventory(upstream) != source['officialFiles']
            or tree_inventory(copy) != source['copiedFiles']):
        raise ValueError('official or copied compiler source inventory changed')
    changed = [name for name, value in source['officialFiles'].items()
               if source['copiedFiles'].get(name) != value]
    if changed != [source['instrumentedFile']]:
        raise ValueError('private compiler copy has unexpected source changes')
    target = source['instrumentedFile']
    patch = ''.join(difflib.unified_diff(
        (upstream / target).read_text(encoding='utf-8').splitlines(keepends=True),
        (copy / target).read_text(encoding='utf-8').splitlines(keepends=True),
        fromfile='a/' + target, tofile='b/' + target,
    )).encode('utf-8')
    patch_path = Path(source['patchPath'])
    if (patch != patch_path.read_bytes()
            or digest(patch) != source['patchSHA256']
            or source['upstreamCommit'] != '79df8d9c40722ee9507a1e253f283b51025f9d6c'):
        raise ValueError('upstream source delta is not the pinned diagnostic patch')

    command = plan['command']
    expected_argv = [plan['tools']['taskset'], '-c', '5', plan['tools']['bun'],
                     source['entrypoint'], plan['entrypoint'], '-o',
                     plan['outputs']['generatedC']]
    if (command.get('label') != 'native-source-emit-profile'
            or command.get('capSeconds') != 30
            or command.get('capture') != 'split'
            or command.get('cpu') != 5
            or command.get('argv') != expected_argv
            or plan['outputs']['phaseJSONL'] != plan['instrumentation']['profilePath']):
        raise ValueError('child command or profile output differs from frozen plan')
    instrumented = (copy / target).read_text(encoding='utf-8')
    if ('PHASE_PROFILE_PATH = '
            + json.dumps(plan['outputs']['phaseJSONL'])) not in instrumented:
        raise ValueError('instrumented source writes to a different profile path')
    output_paths = [Path(raw) for raw in plan['outputs'].values()]
    for path in output_paths:
        if not path.parent.is_dir() or path.exists() or path.is_symlink():
            raise ValueError('diagnostic output is not fresh: ' + str(path))
    if str(Path(plan['entrypoint']).parent) != plan['cwd']:
        raise ValueError('working directory does not match entrypoint root')

    lock_path = Path(plan['lockPath'])
    if str(lock_path) != '/tmp/bendvy-parity-heavy.lock':
        raise ValueError('unexpected internal heavy-work lock')
    lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError('heavy-work lock is occupied; child was not started') from error
        if pin_snapshot(pins) != before:
            raise ValueError('pinned input changed before child start')
        pre = exclusive_json(Path(plan['guards']['pre']), {
            'format': 'bend-compiler-phase-profile-guard-v1',
            'phase': 'pre-child', 'planSHA256': plan_sha, 'timeNs': time.time_ns(),
            'pins': before, 'outputs': [file_record(path) for path in output_paths],
            'childStarted': False,
        })
        runner_path = Path(plan['taskRunner']['path'])
        if hash_file(runner_path) != plan['taskRunner']['sha256']:
            raise ValueError('pinned task_runner changed')
        spec = importlib.util.spec_from_file_location('pinned_bendvy_task_runner', runner_path)
        if spec is None or spec.loader is None:
            raise RuntimeError('cannot import pinned task_runner')
        task_runner = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(task_runner)
        try:
            result = task_runner.execute_result(
                expected_argv, 30, env=plan['environment'], cwd=plan['cwd'], capture='split')
        except Exception as error:
            result = getattr(error, 'result', None) or {
                'exit': None,
                'failure': type(error).__name__ + ': ' + str(error),
                'stdout': getattr(error, 'stdout', b'') or b'',
                'stderr': getattr(error, 'stderr', b'') or b'',
                'runnerSHA256': plan['taskRunner']['sha256'],
            }
        stdout = result.get('stdout', b'')
        stderr = result.get('stderr', b'')
        exclusive_write(Path(plan['outputs']['stdout']), stdout)
        exclusive_write(Path(plan['outputs']['stderr']), stderr)

        post_pins, pin_error = {}, None
        try:
            post_pins = pin_snapshot(pins)
        except Exception as error:
            pin_error = type(error).__name__ + ': ' + str(error)
        profile_path = Path(plan['outputs']['phaseJSONL'])
        profile = profile_path.read_bytes() if profile_path.is_file() and not profile_path.is_symlink() else b''
        complete_jsonl, first_event, last_event = False, None, None
        if profile and profile.endswith(b'\n'):
            try:
                rows = [json.loads(line) for line in profile.splitlines()]
                first_event = rows[0].get('event') if rows else None
                last_event = rows[-1].get('event') if rows else None
                complete_jsonl = bool(rows)
            except (UnicodeDecodeError, json.JSONDecodeError):
                pass
        unchanged = pin_error is None and post_pins == before
        complete = (
            result.get('failure') is None and result.get('exit') == 0
            and Path(plan['outputs']['generatedC']).is_file()
            and not Path(plan['outputs']['generatedC']).is_symlink()
            and complete_jsonl and first_event == 'compile-book-start'
            and last_event == 'compile-book-complete' and unchanged
        )
        raw_paths = [plan['outputs'][name] for name in
                     ('generatedC', 'phaseJSONL', 'stdout', 'stderr')]
        post = exclusive_json(Path(plan['guards']['post']), {
            'format': 'bend-compiler-phase-profile-guard-v1',
            'phase': 'post-child', 'planSHA256': plan_sha, 'timeNs': time.time_ns(),
            'pinsUnchanged': unchanged, 'pinError': pin_error, 'pins': post_pins,
            'outputs': [file_record(Path(raw)) for raw in raw_paths],
            'profileFirstEvent': first_event, 'profileLastEvent': last_event,
        })
        receipt = {
            'format': 'bend-compiler-phase-profile-receipt-v1',
            'classification': 'DIAGNOSTIC_COMPLETE' if complete else 'INCOMPLETE',
            'acceptanceClaim': False, 'performanceClaim': False,
            'planPath': str(plan_path), 'planSHA256': plan_sha,
            'command': {'label': command['label'], 'argv': expected_argv,
                        'capSeconds': 30, 'capture': 'split',
                        'exit': result.get('exit'), 'failure': result.get('failure'),
                        'runnerSHA256': result.get('runnerSHA256')},
            'raw': {name: file_record(Path(plan['outputs'][name]))
                    for name in ('stdout', 'stderr', 'generatedC', 'phaseJSONL')},
            'guards': {'preSHA256': digest(pre), 'postSHA256': digest(post)},
            'pinnedInputsUnchanged': unchanged,
            'profileFirstEvent': first_event, 'profileLastEvent': last_event,
            'note': 'Bun execution of exact upstream v2.0.35 source with local compile_book phase instrumentation; diagnostic only, not installed-compiler acceptance or performance evidence.',
        }
        exclusive_json(Path(plan['outputs']['receipt']), receipt)
        return 0 if complete else 1
    finally:
        os.close(lock_fd)


if __name__ == '__main__':
    raise SystemExit(main())
