function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
let intervalActive=false, intervalStart=null, intervalElapsed=0n, intervalCount=0, intervalResultSeen=false, intervalLastResult=null;
let intervalChunks=[], intervalBytes=0, intervalDigest=2166136261, intervalReady=false;
function intervalRequire(ok){if(!ok)throw Error('inspector interval timer protocol failure');}
function io_inspector_interval_reset(){intervalRequire(!intervalActive&&!intervalReady);intervalReady=true;intervalElapsed=0n;intervalCount=0;intervalChunks=[];intervalBytes=0;intervalDigest=2166136261;intervalResultSeen=false;intervalLastResult=null;return {$:"Unit"};}
function io_inspector_interval_begin(index){intervalRequire(intervalReady&&!intervalActive&&index===intervalCount);intervalStart=process.hrtime.bigint();intervalResultSeen=false;intervalLastResult=null;intervalActive=true;return {$:"Unit"};}
function io_inspector_interval_force_result(value){intervalRequire(intervalReady&&intervalActive&&!intervalResultSeen);intervalLastResult=value;intervalResultSeen=true;return value;}
function io_inspector_interval_end(){intervalRequire(intervalReady&&intervalActive&&intervalResultSeen);intervalElapsed+=process.hrtime.bigint()-intervalStart;intervalActive=false;intervalResultSeen=false;intervalLastResult=null;intervalCount++;return {$:"Unit"};}
function io_inspector_interval_capture(text){intervalRequire(intervalReady&&!intervalActive);const b=io_bytes(text+'\n');for(const x of b)intervalDigest=Math.imul(intervalDigest^x,16777619)>>>0;intervalBytes+=b.length;intervalChunks.push(b);return {$:"Unit"};}
function io_inspector_interval_finish(){intervalRequire(intervalReady&&!intervalActive&&intervalCount===136);io_out(2,io_bytes(JSON.stringify({elapsedNs:intervalElapsed.toString(),bytes:intervalBytes,digest:intervalDigest,intervals:intervalCount})+'\n'));for(const b of intervalChunks)io_out(1,b);intervalChunks=[];intervalReady=false;return {$:"Unit"};}
io_eff("clock.reset",io_inspector_interval_reset);io_eff("clock.begin",io_inspector_interval_begin);io_eff("clock.force_workshop_string",io_inspector_interval_force_result);io_eff("clock.force_workshop_checked",io_inspector_interval_force_result);io_eff("clock.force_workshop_snapshot",io_inspector_interval_force_result);io_eff("clock.force_workshop_streams",io_inspector_interval_force_result);io_eff("clock.force_garden_string",io_inspector_interval_force_result);io_eff("clock.force_garden_checked",io_inspector_interval_force_result);io_eff("clock.force_garden_snapshot",io_inspector_interval_force_result);io_eff("clock.force_garden_streams",io_inspector_interval_force_result);io_eff("clock.end",io_inspector_interval_end);io_eff("clock.capture",io_inspector_interval_capture);io_eff("clock.finish",io_inspector_interval_finish);

})();

for (const k of ["clock.reset","clock.capture","clock.begin","clock.force_workshop_string","clock.end","clock.force_workshop_snapshot","clock.force_garden_string","clock.force_workshop_checked","clock.force_workshop_streams","clock.force_garden_checked","clock.force_garden_snapshot","clock.finish","clock.force_garden_streams"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058reset$(_x_1), run_clo((_x_2) => {
  return $start_workshop$(($setup$058build$1261$()));
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $clock$058reset$(_k_0) {
  return { $: "$FFI", run: $0eff["clock.reset"].run, need: $0eff["clock.reset"].need, args: [], kont: (_k_0) };
}
function $start_workshop$(_result_0) {
  if (_result_0.$ === "setup.Ready") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return run_clo((_x_0) => {
  return $IO$bind$(($run_cases$1261$(0, _world_0)), run_clo((_x_1) => {
  return $after_categories_workshop$(_x_1, _registry_0);
}), _x_0);
});
  } else {
    return run_clo((_x_2) => {
  return $IO$pure$({$: "Unit"}, _x_2);
});
  }
}

function $setup$058build$1261$() {
  return $setup$058created$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), ($setup$058initial_resources$1261$()))));
}

function $run_cases$1261$(_index_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($case_begin$12616$(_index_0, "link/required-out", 2, _world_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($case_begin$12617$(((_index_0 + 4) >>> 0), "link/optional-out", 3, _x_1)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$bind$(($case_begin$12618$(((_index_0 + 8) >>> 0), "link/present-out", 2, _x_3)), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$(($case_begin$12619$(((_index_0 + 12) >>> 0), "link/absent-out", 1, _x_5)), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$bind$(($case_begin$12620$(((_index_0 + 16) >>> 0), "link/required-in", 1, _x_7)), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$bind$(($case_begin$12621$(((_index_0 + 20) >>> 0), "link/optional-in", 3, _x_9)), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $IO$bind$(($case_begin$12622$(((_index_0 + 24) >>> 0), "link/present-in", 1, _x_11)), run_clo((_x_13) => {
  return run_clo((_x_14) => {
  return $IO$bind$(($case_begin$12623$(((_index_0 + 28) >>> 0), "link/absent-in", 2, _x_13)), run_clo((_x_15) => {
  return run_clo((_x_16) => {
  return $IO$bind$(($case_begin$12624$(((_index_0 + 32) >>> 0), "parent/required-out", 2, _x_15)), run_clo((_x_17) => {
  return run_clo((_x_18) => {
  return $IO$bind$(($case_begin$12625$(((_index_0 + 36) >>> 0), "parent/optional-out", 3, _x_17)), run_clo((_x_19) => {
  return run_clo((_x_20) => {
  return $IO$bind$(($case_begin$12626$(((_index_0 + 40) >>> 0), "parent/present-out", 2, _x_19)), run_clo((_x_21) => {
  return run_clo((_x_22) => {
  return $IO$bind$(($case_begin$12627$(((_index_0 + 44) >>> 0), "parent/absent-out", 1, _x_21)), run_clo((_x_23) => {
  return run_clo((_x_24) => {
  return $IO$bind$(($case_begin$12628$(((_index_0 + 48) >>> 0), "parent/required-in", 1, _x_23)), run_clo((_x_25) => {
  return run_clo((_x_26) => {
  return $IO$bind$(($case_begin$12629$(((_index_0 + 52) >>> 0), "parent/optional-in", 3, _x_25)), run_clo((_x_27) => {
  return run_clo((_x_28) => {
  return $IO$bind$(($case_begin$12630$(((_index_0 + 56) >>> 0), "parent/present-in", 1, _x_27)), run_clo((_x_29) => {
  return $case_begin$12631$(((_index_0 + 60) >>> 0), "parent/absent-in", 2, _x_29);
}), _x_28);
});
}), _x_26);
});
}), _x_24);
});
}), _x_22);
});
}), _x_20);
});
}), _x_18);
});
}), _x_16);
});
}), _x_14);
});
}), _x_12);
});
}), _x_10);
});
}), _x_8);
});
}), _x_6);
});
}), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $after_categories_workshop$(_world_0, _registry_0) {
  return $after_categories_garden_built$(_world_0, _registry_0, ($setup$058build$1260$()));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $setup$058created$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $setup$058reserved_one$1261$(_factory_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    const _factory_1 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.CreationRefused", "factory": _factory_1, "resources": _resource_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $setup$058initial_resources$1261$() {
  return {$: "state.Resources", "owned": array_node([11], [12]), "siblingOwned": array_node([21], [22]), "flow": {$: "../../../../src/ecs/machine.Present", "current": 4, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "../../../../src/ecs/machine.Present", "current": 10, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "ran": 0, "flowStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$()), "levelStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$())};
}

function $case_begin$12616$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12616$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12616$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12617$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12617$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12617$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12618$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12618$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12618$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12619$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12619$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12619$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12620$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12620$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12620$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12621$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12621$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12621$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12622$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12622$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12622$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12623$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12623$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12623$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12624$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12624$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12624$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12625$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12625$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12625$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12626$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12626$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12626$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12627$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12627$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12627$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12628$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12628$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12628$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12629$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12629$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12629$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12630$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12630$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12630$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12631$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12631$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12631$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $after_categories_garden_built$(_workshop_0, _workshopRegistry_0, _result_0) {
  if (_result_0.$ === "setup.Ready") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return run_clo((_x_0) => {
  return $IO$bind$(($run_cases$1260$(64, _world_0)), run_clo((_x_1) => {
  return $after_categories_garden$(_workshop_0, _workshopRegistry_0, _x_1, _registry_0);
}), _x_0);
});
  } else {
    return run_clo((_x_2) => {
  return $IO$pure$({$: "Unit"}, _x_2);
});
  }
}

function $setup$058build$1260$() {
  return $setup$058created$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), ($setup$058initial_resources$1260$()))));
}

function $setup$058reserved_one$1261$(_factory_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $setup$058reserved_two$1261$(_factory_0, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReservationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Nil"}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($setup$058empty_store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "../../../../src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $calls$058inspect$12616$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12616$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12616$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12616$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12617$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12617$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12617$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12617$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12618$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12618$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12618$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12618$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12619$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12619$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12619$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12619$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12620$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12620$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12620$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12620$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12621$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12621$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12621$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12621$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12622$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12622$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12622$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12622$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12623$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12623$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12623$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12623$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12624$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12624$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12624$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12624$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12625$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12625$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12625$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12625$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12626$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12626$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12626$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12626$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12627$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12627$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12627$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12627$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12628$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12628$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12628$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12628$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12629$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12629$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12629$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12629$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12630$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12630$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12630$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12630$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12631$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12631$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12631$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12631$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $run_cases$1260$(_index_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($case_begin$1260$(_index_0, "link/required-out", 2, _world_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($case_begin$1261$(((_index_0 + 4) >>> 0), "link/optional-out", 3, _x_1)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$bind$(($case_begin$1262$(((_index_0 + 8) >>> 0), "link/present-out", 2, _x_3)), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$(($case_begin$1263$(((_index_0 + 12) >>> 0), "link/absent-out", 1, _x_5)), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$bind$(($case_begin$1264$(((_index_0 + 16) >>> 0), "link/required-in", 1, _x_7)), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$bind$(($case_begin$1265$(((_index_0 + 20) >>> 0), "link/optional-in", 3, _x_9)), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $IO$bind$(($case_begin$1266$(((_index_0 + 24) >>> 0), "link/present-in", 1, _x_11)), run_clo((_x_13) => {
  return run_clo((_x_14) => {
  return $IO$bind$(($case_begin$1267$(((_index_0 + 28) >>> 0), "link/absent-in", 2, _x_13)), run_clo((_x_15) => {
  return run_clo((_x_16) => {
  return $IO$bind$(($case_begin$1268$(((_index_0 + 32) >>> 0), "parent/required-out", 2, _x_15)), run_clo((_x_17) => {
  return run_clo((_x_18) => {
  return $IO$bind$(($case_begin$1269$(((_index_0 + 36) >>> 0), "parent/optional-out", 3, _x_17)), run_clo((_x_19) => {
  return run_clo((_x_20) => {
  return $IO$bind$(($case_begin$12610$(((_index_0 + 40) >>> 0), "parent/present-out", 2, _x_19)), run_clo((_x_21) => {
  return run_clo((_x_22) => {
  return $IO$bind$(($case_begin$12611$(((_index_0 + 44) >>> 0), "parent/absent-out", 1, _x_21)), run_clo((_x_23) => {
  return run_clo((_x_24) => {
  return $IO$bind$(($case_begin$12612$(((_index_0 + 48) >>> 0), "parent/required-in", 1, _x_23)), run_clo((_x_25) => {
  return run_clo((_x_26) => {
  return $IO$bind$(($case_begin$12613$(((_index_0 + 52) >>> 0), "parent/optional-in", 3, _x_25)), run_clo((_x_27) => {
  return run_clo((_x_28) => {
  return $IO$bind$(($case_begin$12614$(((_index_0 + 56) >>> 0), "parent/present-in", 1, _x_27)), run_clo((_x_29) => {
  return $case_begin$12615$(((_index_0 + 60) >>> 0), "parent/absent-in", 2, _x_29);
}), _x_28);
});
}), _x_26);
});
}), _x_24);
});
}), _x_22);
});
}), _x_20);
});
}), _x_18);
});
}), _x_16);
});
}), _x_14);
});
}), _x_12);
});
}), _x_10);
});
}), _x_8);
});
}), _x_6);
});
}), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $after_categories_garden$(_workshop_0, _workshopRegistry_0, _garden_0, _gardenRegistry_0) {
  return $workshop_machine$(128, _workshop_0, _workshopRegistry_0, _garden_0, _gardenRegistry_0);
}

function $setup$058created$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $setup$058reserved_one$1260$(_factory_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    const _factory_1 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.CreationRefused", "factory": _factory_1, "resources": _resource_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $setup$058initial_resources$1260$() {
  return {$: "state.Resources", "owned": array_node([11], [12]), "siblingOwned": array_node([21], [22]), "flow": {$: "../../../../src/ecs/machine.Present", "current": 4, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "../../../../src/ecs/machine.Present", "current": 10, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "ran": 0, "flowStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$()), "levelStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$())};
}

function $setup$058reserved_two$1261$(_factory_0, _first_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $setup$058reserved_three$1261$(_factory_0, _first_0, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReservationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Nil"}}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $setup$058empty_store$1261$(__0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$(($setup$058initial_components$1261$()));
}

function $calls$058inspect_prepared$12616$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12618$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $inspection_capture_next$1261$(_name_0, _result_0, _worldDump_0, _instanceDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  const _instance_0 = _instanceDump_0["fst"];
  const _instanceText_0 = _instanceDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($result_text$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_instanceText_0 + _x_4);
  const _x_6 = (":instance=" + _x_5);
  const _x_7 = (_name_0 + _x_6);
  return $IO$bind$((_x_8) => $clock$058capture$(("inspect:" + _x_7), _x_8), run_clo((_x_9) => {
  return run_tail(_next_0, {$: "InspectReport", "world": _world_0, "instance": _instance_0});
}), _x_0);
});
}

function $dump$058world$1261$(_world_0) {
  return $dump$058counted$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0)));
}

function $instance_report$1261$(_instance_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Fresh"}, "snd": "Fresh"};
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "snd": ("Active(" + _x_4)};
  }
}

function $case_first_inspect_captured$12616$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12616$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12617$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12619$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12617$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12617$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12618$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12620$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12618$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12618$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12619$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12621$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12619$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12619$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12620$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12622$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12620$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12620$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12621$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12623$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12621$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12621$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12622$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12624$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12622$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12622$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12623$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12625$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12623$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12623$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12624$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12626$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12624$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12624$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12625$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12627$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12625$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12625$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12626$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12628$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12626$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12626$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12627$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12629$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12627$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12627$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12628$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12630$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12628$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12628$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12629$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12631$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12629$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12629$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12630$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12632$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12630$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12630$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12631$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1263$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12633$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12631$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12631$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $case_begin$1260$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1260$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1260$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1261$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1261$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1261$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1262$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1262$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1262$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1263$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1263$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1263$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1264$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1264$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1264$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1265$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1265$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1265$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1266$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1266$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1266$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1267$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1267$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1267$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1268$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1268$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1268$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$1269$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1269$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$1269$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12610$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12610$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12610$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12611$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12611$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12611$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12612$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12612$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12612$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12613$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12613$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12613$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12614$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12614$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12614$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $case_begin$12615$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12615$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $case_first_inspect_done$12615$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $workshop_machine$(_index_0, _world_0, _registry_0, _garden_0, _gardenRegistry_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058inspect_machine$1261$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $after_machine_first$(_index_0, _x_1, _registry_0, _garden_0, _gardenRegistry_0);
}), _x_0);
});
}

function $setup$058reserved_one$1260$(_factory_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $setup$058reserved_two$1260$(_factory_0, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReservationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Nil"}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($setup$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $setup$058reserved_three$1261$(_factory_0, _first_0, _middle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $setup$058activate_first$1261$(_factory_0, _first_0, _middle_0, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _first_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReservationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Nil"}}}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$(_components_0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $setup$058initial_components$1261$() {
  const _x_0 = {$: "Nil"};
  const _x_1 = {$: "Nil"};
  return {$: "state.Components", "cells": array_new(4, _x_0), "sibling": array_new(4, _x_1)};
}

function $measure$058run_observed$1263$(_index_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $measure$058after_observed_begin$1263$(_operation_0, _x_2);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12618$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12618$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12618$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $clock$058capture$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.capture"].run, need: $0eff["clock.capture"].need, args: [(_text_0)], kont: (_k_0) };
}
function $result_text$(_result_0) {
  if (_result_0.$ === "Done") {
    const _text_0 = _result_0["value"];
    const _x_0 = (_text_0 + ")");
    return ("Done(" + _x_0);
  } else {
    return "Fail";
  }
}

function $dump$058counted$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1261$(_count_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $case_second_inspect$12616$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12616$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12616$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12619$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12619$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12619$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12617$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12617$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12617$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12620$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12620$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12620$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12618$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12618$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12618$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12621$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12621$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12621$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12619$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12619$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12619$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12622$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12622$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12622$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12620$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12620$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12620$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12623$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12623$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12623$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12621$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12621$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12621$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12624$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12624$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12624$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12622$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12622$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12622$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12625$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12625$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12625$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12623$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12623$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12623$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12626$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12626$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12626$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12624$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12624$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12624$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12627$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12627$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12627$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12625$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12625$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12625$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12628$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12628$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12628$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12626$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12626$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12626$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12629$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12629$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12629$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12627$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12627$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12627$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12630$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12630$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12630$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12628$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12628$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12628$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12631$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12631$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12631$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12629$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12629$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12629$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12632$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12632$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12632$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12630$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12630$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12630$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12633$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12633$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12633$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12631$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12631$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12631$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect$1260$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1260$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1260$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1260$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1261$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1261$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1261$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1261$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1262$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1262$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1262$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1262$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1263$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1263$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1263$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1263$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1264$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1264$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1264$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1264$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1265$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1265$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1265$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1265$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1266$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1266$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1266$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1266$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1267$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1267$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1267$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1267$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1268$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1268$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1268$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1268$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$1269$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$1269$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$1269$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$1269$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12610$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12610$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12610$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12610$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12611$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12611$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12611$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12611$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12612$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12612$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12612$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12612$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12613$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12613$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12613$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12613$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12614$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12614$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12614$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12614$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect$12615$(_index_0, _instance_0, _world_0) {
  return $calls$058inspect_prepared$12615$(_index_0, _instance_0, _world_0);
}

function $case_first_inspect_done$12615$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_first_inspect_captured$12615$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $machine$045calls$058inspect_machine$1261$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1261$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $after_machine_first$(_index_0, _observed_0, _registry_0, _garden_0, _gardenRegistry_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $machine_inspection_capture_next$1261$(_result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $continue_machine_first$(_index_0, _x_0, _registry_0, _garden_0, _gardenRegistry_0);
}));
}

function $setup$058reserved_two$1260$(_factory_0, _first_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $setup$058reserved_three$1260$(_factory_0, _first_0, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReservationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Nil"}}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $setup$058empty_store$1260$(__0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$(($setup$058initial_components$1260$()));
}

function $setup$058activate_first$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058activate_middle$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _middle_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ActivationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "stage": 1, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $clock$058begin$(_index_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.begin"].run, need: $0eff["clock.begin"].need, args: [(_index_0)], kont: (_k_0) };
}
function $measure$058after_observed_begin$1263$(_operation_0, __0) {
  return $measure$058finish_observed$1263$(_operation_0({$: "Unit"}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12618$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12618$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12618$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12636$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $dump$058resourced$1261$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1261$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $dump$058store$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1261$(($dump$058resources$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $case_second_inspect_done$12616$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12616$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12619$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12619$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12619$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12638$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12617$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12617$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12620$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12620$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12620$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12640$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12618$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12618$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12621$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12621$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12621$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12642$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12619$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12619$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12622$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12622$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12622$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12644$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12620$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12620$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12623$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12623$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12623$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12646$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12621$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12621$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12624$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12624$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12624$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12648$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12622$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12622$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12625$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12625$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12625$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12650$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12623$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12623$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12626$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12626$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12626$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12652$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12624$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12624$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12627$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12627$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12627$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12654$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12625$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12625$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12628$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12628$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12628$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12656$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12626$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12626$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12629$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12629$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12629$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12658$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12627$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12627$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12630$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12630$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12630$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12660$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12628$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12628$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12631$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12631$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12631$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12662$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12629$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12629$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12632$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12632$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12632$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12664$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12630$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12630$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12633$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12633$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12633$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12666$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12631$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12631$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $calls$058inspect_prepared$1260$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1262$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $inspection_capture_next$1260$(_name_0, _result_0, _worldDump_0, _instanceDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  const _instance_0 = _instanceDump_0["fst"];
  const _instanceText_0 = _instanceDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($result_text$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_instanceText_0 + _x_4);
  const _x_6 = (":instance=" + _x_5);
  const _x_7 = (_name_0 + _x_6);
  return $IO$bind$((_x_8) => $clock$058capture$(("inspect:" + _x_7), _x_8), run_clo((_x_9) => {
  return run_tail(_next_0, {$: "InspectReport", "world": _world_0, "instance": _instance_0});
}), _x_0);
});
}

function $dump$058world$1260$(_world_0) {
  return $dump$058counted$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $instance_report$1260$(_instance_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Fresh"}, "snd": "Fresh"};
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "snd": ("Active(" + _x_4)};
  }
}

function $case_first_inspect_captured$1260$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1260$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1261$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1263$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1261$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1261$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1262$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1264$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1262$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1262$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1263$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1265$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1263$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1263$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1264$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1266$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1264$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1264$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1265$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1267$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1265$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1265$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1266$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1268$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1266$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1266$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1267$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1269$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1267$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1267$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1268$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12610$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1268$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1268$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$1269$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12611$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$1269$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$1269$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12610$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12612$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12610$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12610$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12611$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12613$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12611$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12611$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12612$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12614$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12612$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12612$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12613$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12615$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12613$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12613$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12614$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12616$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12614$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12614$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $calls$058inspect_prepared$12615$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1262$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12617$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $case_first_inspect_captured$12615$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return $case_second_inspect$12615$(_index_0, _name_0, _expected_0, _instance_0, _world_0);
}

function $measure$058run_observed$1261$(_index_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $measure$058after_observed_begin$1261$(_operation_0, _x_2);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1261$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1261$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1261$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $machine_inspection_capture_next$1261$(_result_0, _worldDump_0, _instanceDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  const _instance_0 = _instanceDump_0["fst"];
  const _instanceText_0 = _instanceDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($machine_result_text$1261$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_instanceText_0 + _x_4);
  return $IO$bind$((_x_6) => $clock$058capture$(("machine-inspect:" + _x_5), _x_6), run_clo((_x_7) => {
  return run_tail(_next_0, {$: "InspectReport", "world": _world_0, "instance": _instance_0});
}), _x_0);
});
}

function $continue_machine_first$(_index_0, _report_0, _registry_0, _garden_0, _gardenRegistry_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058inspect_machine$1261$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $after_machine_second$(_index_0, _x_1, _registry_0, _garden_0, _gardenRegistry_0);
}), _x_0);
});
}

function $setup$058reserved_three$1260$(_factory_0, _first_0, _middle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $setup$058activate_first$1260$(_factory_0, _first_0, _middle_0, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _first_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReservationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Nil"}}}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$(_components_0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $setup$058initial_components$1260$() {
  const _x_0 = {$: "Nil"};
  const _x_1 = {$: "Nil"};
  return {$: "state.Components", "cells": array_new(4, _x_0), "sibling": array_new(4, _x_1)};
}

function $setup$058activate_middle$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058activate_last$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _last_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ActivationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "stage": 2, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $measure$058finish_observed$1263$(_value_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_workshop_string$(_value_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $clock$058end$(_x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$(_x_2, _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1263$(_cursor_0, _registeredAt_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1263$(_cursor_0, _registeredAt_0, _frame_0, _result_1);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12636$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12616$(_args_0, _ctx_0);
}

function $dump$058stored$1261$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058store$1261$(_value_0) {
  const _owner_0 = _value_0["components"];
  const _relations_0 = _value_0["graph"];
  return $dump$058store_done$1261$(_relations_0, ($dump$058components$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resources$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $dump$058resource_done$1261$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($dump$058tree$1262$(_siblingOwned_0)), ($dump$058tree$1262$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $case_second_inspect_captured$12616$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12616$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12638$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12617$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12617$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12617$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12640$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12618$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12618$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12618$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12642$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12619$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12619$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12619$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12644$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12620$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12620$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12620$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12646$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12621$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12621$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12621$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12648$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12622$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12622$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12622$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12650$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12623$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12623$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12623$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12652$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12624$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12624$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12624$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12654$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12625$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12625$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12625$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12656$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12626$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12626$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12626$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12658$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12627$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12627$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12627$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12660$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12628$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12628$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12628$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12662$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12629$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12629$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12629$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12664$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12630$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12630$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12630$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12666$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12631$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12631$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12631$(_index_0, _name_0, _expected_0, _world_0);
}

function $measure$058run_observed$1262$(_index_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $measure$058after_observed_begin$1262$(_operation_0, _x_2);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1262$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1262$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1262$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $dump$058counted$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1260$(_count_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $case_second_inspect$1260$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1260$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1260$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1263$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1263$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1263$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1261$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1261$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1261$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1264$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1264$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1264$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1262$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1262$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1262$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1265$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1265$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1265$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1263$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1263$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1263$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1266$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1266$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1266$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1264$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1264$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1264$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1267$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1267$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1267$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1265$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1265$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1265$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1268$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1268$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1268$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1266$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1266$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1266$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1269$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1269$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1269$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1267$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1267$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1267$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12610$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12610$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12610$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1268$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1268$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1268$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12611$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12611$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12611$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$1269$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$1269$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$1269$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12612$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12612$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12612$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12610$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12610$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12610$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12613$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12613$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12613$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12611$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12611$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12611$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12614$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12614$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12614$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12612$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12612$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12612$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12615$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12615$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12615$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12613$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12613$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12613$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12616$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12616$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12616$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12614$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12614$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12614$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$12617$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12617$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12617$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $case_second_inspect$12615$(_index_0, _name_0, _expected_0, _instance_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058inspect$12615$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $case_second_inspect_done$12615$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $measure$058after_observed_begin$1261$(_operation_0, __0) {
  return $measure$058finish_observed$1261$(_operation_0({$: "Unit"}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1261$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1261$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1261$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1261$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1263$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $machine_result_text$1261$(_result_0) {
  if (_result_0.$ === "Done") {
    const _value_0 = _result_0["value"];
    return $machine_snapshot_text$1261$(_value_0);
  } else {
    return "Fail";
  }
}

function $after_machine_second$(_index_0, _observed_0, _registry_0, _garden_0, _gardenRegistry_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $machine_inspection_capture_next$1261$(_result_0, ($dump$058world$1261$(_world_0)), ($instance_report$1261$(_instance_0)), run_clo((_x_0) => {
  return $continue_machine_second$(_index_0, _x_0, _registry_0, _garden_0, _gardenRegistry_0);
}));
}

function $setup$058activate_first$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058activate_middle$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _middle_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ActivationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "stage": 1, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $setup$058activate_last$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058queue_edges$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(($setup$058seed_world$1261$(_first_0, _middle_0, _last_0, _world_0)))));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ActivationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "stage": 3, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $clock$058force_workshop_string$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_workshop_string"].run, need: $0eff["clock.force_workshop_string"].need, args: [$0m0(_value_0)], kont: ((f) => (x) => (f($0m17(x))))(_k_0) };
}
function $clock$058end$(_k_0) {
  return { $: "$FFI", run: $0eff["clock.end"].run, need: $0eff["clock.end"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1263$(_cursor_0, _registeredAt_0, _frame_0, _result_0) {
  const _world_0 = _frame_0["world"];
  if (_result_0.$ === "Fail") {
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1263$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $calls$058inspect_body$12616$(__0, _owner_0) {
  return $consumer$058inspect_body$12616$({$: "Unit"}, _owner_0);
}

function $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1260$(_live_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058store_done$1261$(_relations_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($dump$058graph$1261$(_relations_0));
  const _x_1 = (";graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _relations_0}, "snd": (_text_0 + _x_1)};
}

function $dump$058components$1261$(_value_0) {
  const _cells_0 = _value_0["cells"];
  const _sibling_0 = _value_0["sibling"];
  return $dump$058component_done$1261$(($dump$058tree$1261$(_cells_0)), ($dump$058tree$1261$(_sibling_0)));
}

function $dump$058resource_done$1261$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _siblingObserved_0, _result_0) {
  const _siblingOwned_0 = _siblingObserved_0["fst"];
  const _siblingText_0 = _siblingObserved_0["snd"];
  const _owned_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($dump$058stream$(_levelStream_0));
  const _x_1 = ($dump$058stream$(_flowStream_0));
  const _x_2 = (";" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ran_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058slot$1263$(_level_0));
  const _x_8 = (";ran=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058slot$1262$(_flow_0));
  const _x_11 = (";" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";" + _x_12);
  const _x_14 = (_siblingText_0 + _x_13);
  const _x_15 = (";sibling=" + _x_14);
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": (_text_0 + _x_15)};
}

function $dump$058tree$1262$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1262$(($dump$058u32$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1262$(($dump$058tree$1262$(_b_0)), ($dump$058tree$1262$(_a_0)));
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $case_first_check$12616$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12616$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12616$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12617$(__0, _owner_0) {
  return $consumer$058inspect_body$12617$({$: "Unit"}, _owner_0);
}

function $case_first_check$12617$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12617$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12617$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12618$(__0, _owner_0) {
  return $consumer$058inspect_body$12618$({$: "Unit"}, _owner_0);
}

function $case_first_check$12618$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12618$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12618$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12619$(__0, _owner_0) {
  return $consumer$058inspect_body$12619$({$: "Unit"}, _owner_0);
}

function $case_first_check$12619$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12619$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12619$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12620$(__0, _owner_0) {
  return $consumer$058inspect_body$12620$({$: "Unit"}, _owner_0);
}

function $case_first_check$12620$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12620$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12620$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12621$(__0, _owner_0) {
  return $consumer$058inspect_body$12621$({$: "Unit"}, _owner_0);
}

function $case_first_check$12621$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12621$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12621$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12622$(__0, _owner_0) {
  return $consumer$058inspect_body$12622$({$: "Unit"}, _owner_0);
}

function $case_first_check$12622$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12622$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12622$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12623$(__0, _owner_0) {
  return $consumer$058inspect_body$12623$({$: "Unit"}, _owner_0);
}

function $case_first_check$12623$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12623$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12623$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12624$(__0, _owner_0) {
  return $consumer$058inspect_body$12624$({$: "Unit"}, _owner_0);
}

function $case_first_check$12624$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12624$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12624$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12625$(__0, _owner_0) {
  return $consumer$058inspect_body$12625$({$: "Unit"}, _owner_0);
}

function $case_first_check$12625$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12625$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12625$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12626$(__0, _owner_0) {
  return $consumer$058inspect_body$12626$({$: "Unit"}, _owner_0);
}

function $case_first_check$12626$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12626$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12626$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12627$(__0, _owner_0) {
  return $consumer$058inspect_body$12627$({$: "Unit"}, _owner_0);
}

function $case_first_check$12627$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12627$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12627$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12628$(__0, _owner_0) {
  return $consumer$058inspect_body$12628$({$: "Unit"}, _owner_0);
}

function $case_first_check$12628$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12628$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12628$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12629$(__0, _owner_0) {
  return $consumer$058inspect_body$12629$({$: "Unit"}, _owner_0);
}

function $case_first_check$12629$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12629$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12629$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12630$(__0, _owner_0) {
  return $consumer$058inspect_body$12630$({$: "Unit"}, _owner_0);
}

function $case_first_check$12630$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12630$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12630$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12631$(__0, _owner_0) {
  return $consumer$058inspect_body$12631$({$: "Unit"}, _owner_0);
}

function $case_first_check$12631$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12631$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12631$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $measure$058after_observed_begin$1262$(_operation_0, __0) {
  return $measure$058finish_observed$1262$(_operation_0({$: "Unit"}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1262$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1262$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1262$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1264$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $dump$058resourced$1260$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1260$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $dump$058store$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(($dump$058resources$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $case_second_inspect_done$1260$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1260$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1263$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1263$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1263$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1266$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1261$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1261$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1264$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1264$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1264$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1268$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1262$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1262$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1265$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1265$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1265$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12610$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1263$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1263$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1266$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1266$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1266$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12612$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1264$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1264$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1267$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1267$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1267$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12614$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1265$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1265$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1268$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1268$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1268$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12616$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1266$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1266$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1269$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1269$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1269$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12618$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1267$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1267$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12610$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12610$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12610$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12620$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1268$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1268$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12611$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12611$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12611$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12622$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$1269$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$1269$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12612$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12612$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12612$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12624$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12610$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12610$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12613$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12613$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12613$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12626$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12611$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12611$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12614$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12614$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12614$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12628$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12612$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12612$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12615$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12615$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12615$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12630$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12613$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12613$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12616$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12616$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12616$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12632$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12614$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12614$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$12617$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12617$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$12617$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12634$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $case_second_inspect_done$12615$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $inspection_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $case_second_inspect_captured$12615$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $measure$058finish_observed$1261$(_value_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_workshop_snapshot$(_value_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $clock$058end$(_x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$(_x_2, _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1261$(_cursor_0, _registeredAt_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1261$(_cursor_0, _registeredAt_0, _frame_0, _result_1);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1263$(_args_0, _ctx_0) {
  return $machine$045calls$058snapshot_body$1261$(_args_0, _ctx_0);
}

function $machine_snapshot_text$1261$(_value_0) {
  const _flow_0 = _value_0["flow"];
  const _level_0 = _value_0["level"];
  const _rows_0 = _value_0["rows"];
  const _events_0 = _value_0["events"];
  const _x_0 = ($List$show$12616$(_events_0));
  const _x_1 = ($Nat$show$(($List$length$(_rows_0))));
  const _x_2 = (",events=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($current_text$1263$(_level_0));
  const _x_5 = (",rows=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($current_text$1262$(_flow_0));
  const _x_8 = (",level=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("flow=" + _x_9);
}

function $continue_machine_second$(_index_0, _report_0, _registry_0, _garden_0, _gardenRegistry_0) {
  const _world_0 = _report_0["world"];
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058check_machine$1261$(((_index_0 + 2) >>> 0), _world_0)), run_clo((_x_1) => {
  return $after_machine_check$(_index_0, _x_1, _registry_0, _garden_0, _gardenRegistry_0);
}), _x_0);
});
}

function $setup$058activate_middle$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058activate_last$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _last_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ActivationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "stage": 2, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $setup$058queue_edges$1261$(_factory_0, _first_0, _middle_0, _last_0, _transaction_0) {
  return $setup$058accepted_edge_one$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058link$1261$()), _first_0, _middle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $setup$058seed_world$1261$(_first_0, _middle_0, _last_0, _world_0) {
  return $setup$058seeded_world$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1266$(run_clo((_x_0) => {
  return $setup$058seed_store_effect$1261$(_first_0, _middle_0, _last_0, _x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1263$(_registeredAt_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058inspect_body$12616$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12636$(_owner_0)));
}

function $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$12612$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$12616$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = ("," + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("," + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = ("," + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058tree$1260$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1260$(($dump$058boolean$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1260$(($dump$058tree$1260$(_b_0)), ($dump$058tree$1260$(_a_0)));
  }
}

function $dump$058graph$1261$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($List$show$12620$(_inverses_0));
  const _x_1 = ($List$show$12619$(_edges_0));
  const _x_2 = (";" + _x_0);
  return (_x_1 + _x_2);
}

function $dump$058component_done$1261$(_cellsObserved_0, _siblingObserved_0) {
  const _cells_0 = _cellsObserved_0["fst"];
  const _text_0 = _cellsObserved_0["snd"];
  const _sibling_0 = _siblingObserved_0["fst"];
  const _siblingText_0 = _siblingObserved_0["snd"];
  const _x_0 = (";sibling=" + _siblingText_0);
  return {$: "Tuple", "fst": {$: "state.Components", "cells": _cells_0, "sibling": _sibling_0}, "snd": (_text_0 + _x_0)};
}

function $dump$058tree$1261$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1261$(($dump$058u32_list$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1261$(($dump$058tree$1261$(_b_0)), ($dump$058tree$1261$(_a_0)));
  }
}

function $dump$058slot$1262$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058slot$1263$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058stream$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _start_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_start_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($Nat$show$(_dropped_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1263$(_positions_0));
  const _x_6 = ("," + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($List$show$1262$(_batches_0));
  const _x_9 = ("," + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("stream(" + _x_10);
}

function $dump$058leaf$1262$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058u32$(_value_0) {
  return $dump$058u32_value$(_value_0);
}

function $dump$058tree_left$1262$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1262$(_a_0, _text_0, _b_0);
}

function $calls$058check$12616$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12616$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12616$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12616$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12617$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12638$(_owner_0)));
}

function $calls$058check$12617$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12617$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12617$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12617$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12618$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12640$(_owner_0)));
}

function $calls$058check$12618$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12618$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12618$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12618$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12619$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12642$(_owner_0)));
}

function $calls$058check$12619$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12619$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12619$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12619$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12620$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12644$(_owner_0)));
}

function $calls$058check$12620$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12620$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12620$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12620$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12621$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12646$(_owner_0)));
}

function $calls$058check$12621$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12621$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12621$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12621$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12622$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12648$(_owner_0)));
}

function $calls$058check$12622$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12622$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12622$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12622$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12623$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12650$(_owner_0)));
}

function $calls$058check$12623$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12623$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12623$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12623$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12624$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12652$(_owner_0)));
}

function $calls$058check$12624$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12624$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12624$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12624$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12625$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12654$(_owner_0)));
}

function $calls$058check$12625$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12625$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12625$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12625$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12626$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12656$(_owner_0)));
}

function $calls$058check$12626$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12626$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12626$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12626$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12627$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12658$(_owner_0)));
}

function $calls$058check$12627$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12627$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12627$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12627$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12628$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12660$(_owner_0)));
}

function $calls$058check$12628$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12628$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12628$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12628$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12629$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12662$(_owner_0)));
}

function $calls$058check$12629$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12629$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12629$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12629$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12630$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12664$(_owner_0)));
}

function $calls$058check$12630$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12630$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12630$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12630$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12631$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12666$(_owner_0)));
}

function $calls$058check$12631$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12631$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12631$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12631$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $measure$058finish_observed$1262$(_value_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_garden_string$(_value_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $clock$058end$(_x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$(_x_2, _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1262$(_cursor_0, _registeredAt_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1262$(_cursor_0, _registeredAt_0, _frame_0, _result_1);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1264$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1260$(_args_0, _ctx_0);
}

function $dump$058stored$1260$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058store$1260$(_value_0) {
  const _owner_0 = _value_0["components"];
  const _relations_0 = _value_0["graph"];
  return $dump$058store_done$1260$(_relations_0, ($dump$058components$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $dump$058resource_done$1260$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($dump$058tree$1262$(_siblingOwned_0)), ($dump$058tree$1262$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $case_second_inspect_captured$1260$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1260$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1266$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1261$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1261$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1261$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1268$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1262$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1262$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1262$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12610$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1263$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1263$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1263$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12612$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1264$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1264$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1264$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12614$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1265$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1265$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1265$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12616$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1266$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1266$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1266$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12618$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1267$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1267$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1267$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12620$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1268$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1268$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1268$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12622$(_args_0, _ctx_0) {
  return $calls$058inspect_body$1269$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$1269$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$1269$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12624$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12610$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12610$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12610$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12626$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12611$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12611$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12611$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12628$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12612$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12612$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12612$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12630$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12613$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12613$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12613$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12632$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12614$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12614$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12614$(_index_0, _name_0, _expected_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12634$(_args_0, _ctx_0) {
  return $calls$058inspect_body$12615$(_args_0, _ctx_0);
}

function $case_second_inspect_captured$12615$(_index_0, _name_0, _expected_0, _report_0) {
  const _world_0 = _report_0["world"];
  return $case_first_check$12615$(_index_0, _name_0, _expected_0, _world_0);
}

function $clock$058force_workshop_snapshot$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_workshop_snapshot"].run, need: $0eff["clock.force_workshop_snapshot"].need, args: [$0m25(_value_0)], kont: ((f) => (x) => (f($0m26(x))))(_k_0) };
}
function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1261$(_cursor_0, _registeredAt_0, _frame_0, _result_0) {
  const _world_0 = _frame_0["world"];
  if (_result_0.$ === "Fail") {
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1261$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $machine$045calls$058snapshot_body$1261$(__0, _owner_0) {
  return $machine$045calls$058snapshot_body_observed$1261$(($machine$045calls$058flow_snapshot$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1267$(_owner_0)))));
}

function $current_text$1262$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Unavailable") {
    return "unavailable";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $current_text$1263$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Unavailable") {
    return "unavailable";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $List$show$12616$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1261$(_h_0));
    const _x_1 = ($List$show$go$12618$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $machine$045calls$058check_machine$1261$(_index_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1261$({$: "Unit"}, _world_0);
}));
}

function $after_machine_check$(_index_0, _observed_0, _registry_0, _garden_0, _gardenRegistry_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $machine_checked_capture_next$1261$(_result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return $continue_machine_check$(_index_0, _x_0, _registry_0, _garden_0, _gardenRegistry_0);
}));
}

function $setup$058activate_last$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058queue_edges$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(($setup$058seed_world$1260$(_first_0, _middle_0, _last_0, _world_0)))));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ActivationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "stage": 3, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $setup$058accepted_edge_one$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058accepted_edge_two$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058link$1261$()), _last_0, _middle_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047ordinary$045category$045v1$047declarations$058link$1261$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}};
}

function $setup$058seeded_world$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1266$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $setup$058seed_store_effect$1261$(_first_0, _middle_0, _last_0, _store_0) {
  return {$: "Tuple", "fst": ($setup$058seed_store$1261$(_store_0, _first_0, _middle_0, _last_0)), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $consumer$058inspect_rows$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": ($List$show$12624$(_rows_0))}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12636$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12616$()))))), _owner_0);
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058leaf$1260$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058boolean$(_value_0) {
  return $dump$058boolean_value$(_value_0);
}

function $dump$058tree_left$1260$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1260$(_a_0, _text_0, _b_0);
}

function $List$show$12619$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1261$(_h_0));
    const _x_1 = ($List$show$go$12619$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12620$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12620$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058leaf$1261$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058u32_list$(_value_0) {
  return $dump$058bracket_u32_list$(($dump$058u32_list_parts$(_value_0)));
}

function $dump$058tree_left$1261$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1261$(_a_0, _text_0, _b_0);
}

function $dump$058pending$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_value_1));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("next(" + _x_4);
  }
}

function $dump$058previous$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058batch$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058position$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058u32_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $dump$058tree_join$1262$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $calls$058check_prepared$12616$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12618$(_expected_0, _world_0);
}));
}

function $checked_capture_next$1261$(_name_0, _result_0, _worldDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($checked_text$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  return $IO$bind$((_x_6) => $clock$058capture$(("check:" + _x_5), _x_6), run_clo((_x_7) => {
  return run_tail(_next_0, _world_0);
}), _x_0);
});
}

function $case_second_check$12616$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12616$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12638$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12617$()))))), _owner_0);
}

function $calls$058check_prepared$12617$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12619$(_expected_0, _world_0);
}));
}

function $case_second_check$12617$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12617$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12640$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12618$()))))), _owner_0);
}

function $calls$058check_prepared$12618$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12620$(_expected_0, _world_0);
}));
}

function $case_second_check$12618$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12618$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12642$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12619$()))))), _owner_0);
}

function $calls$058check_prepared$12619$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12621$(_expected_0, _world_0);
}));
}

function $case_second_check$12619$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12619$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12644$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12620$()))))), _owner_0);
}

function $calls$058check_prepared$12620$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12622$(_expected_0, _world_0);
}));
}

function $case_second_check$12620$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12620$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12646$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12621$()))))), _owner_0);
}

function $calls$058check_prepared$12621$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12623$(_expected_0, _world_0);
}));
}

function $case_second_check$12621$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12621$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12648$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12622$()))))), _owner_0);
}

function $calls$058check_prepared$12622$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12624$(_expected_0, _world_0);
}));
}

function $case_second_check$12622$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12622$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12650$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12623$()))))), _owner_0);
}

function $calls$058check_prepared$12623$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12625$(_expected_0, _world_0);
}));
}

function $case_second_check$12623$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12623$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12652$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12624$()))))), _owner_0);
}

function $calls$058check_prepared$12624$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12626$(_expected_0, _world_0);
}));
}

function $case_second_check$12624$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12624$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12654$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12625$()))))), _owner_0);
}

function $calls$058check_prepared$12625$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12627$(_expected_0, _world_0);
}));
}

function $case_second_check$12625$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12625$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12656$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12626$()))))), _owner_0);
}

function $calls$058check_prepared$12626$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12628$(_expected_0, _world_0);
}));
}

function $case_second_check$12626$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12626$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12658$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12627$()))))), _owner_0);
}

function $calls$058check_prepared$12627$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12629$(_expected_0, _world_0);
}));
}

function $case_second_check$12627$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12627$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12660$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12628$()))))), _owner_0);
}

function $calls$058check_prepared$12628$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12630$(_expected_0, _world_0);
}));
}

function $case_second_check$12628$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12628$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12662$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12629$()))))), _owner_0);
}

function $calls$058check_prepared$12629$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12631$(_expected_0, _world_0);
}));
}

function $case_second_check$12629$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12629$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12664$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12630$()))))), _owner_0);
}

function $calls$058check_prepared$12630$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12632$(_expected_0, _world_0);
}));
}

function $case_second_check$12630$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12630$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12666$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(($consumer$058inspect_plan$12631$()))))), _owner_0);
}

function $calls$058check_prepared$12631$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1261$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12633$(_expected_0, _world_0);
}));
}

function $case_second_check$12631$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12631$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1261$(_name_0, _x_1);
}), _x_0);
});
}

function $clock$058force_garden_string$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_garden_string"].run, need: $0eff["clock.force_garden_string"].need, args: [$0m27(_value_0)], kont: ((f) => (x) => (f($0m34(x))))(_k_0) };
}
function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1262$(_cursor_0, _registeredAt_0, _frame_0, _result_0) {
  const _world_0 = _frame_0["world"];
  if (_result_0.$ === "Fail") {
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1262$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $calls$058inspect_body$1260$(__0, _owner_0) {
  return $consumer$058inspect_body$1260$({$: "Unit"}, _owner_0);
}

function $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1260$(_live_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058store_done$1260$(_relations_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($dump$058graph$1260$(_relations_0));
  const _x_1 = (";graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _relations_0}, "snd": (_text_0 + _x_1)};
}

function $dump$058components$1260$(_value_0) {
  const _cells_0 = _value_0["cells"];
  const _sibling_0 = _value_0["sibling"];
  return $dump$058component_done$1260$(($dump$058tree$1261$(_cells_0)), ($dump$058tree$1261$(_sibling_0)));
}

function $dump$058resource_done$1260$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _siblingObserved_0, _result_0) {
  const _siblingOwned_0 = _siblingObserved_0["fst"];
  const _siblingText_0 = _siblingObserved_0["snd"];
  const _owned_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($dump$058stream$(_levelStream_0));
  const _x_1 = ($dump$058stream$(_flowStream_0));
  const _x_2 = (";" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ran_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058slot$1261$(_level_0));
  const _x_8 = (";ran=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058slot$1260$(_flow_0));
  const _x_11 = (";" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";" + _x_12);
  const _x_14 = (_siblingText_0 + _x_13);
  const _x_15 = (";sibling=" + _x_14);
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": (_text_0 + _x_15)};
}

function $case_first_check$1260$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1260$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1260$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1261$(__0, _owner_0) {
  return $consumer$058inspect_body$1261$({$: "Unit"}, _owner_0);
}

function $case_first_check$1261$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1261$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1261$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1262$(__0, _owner_0) {
  return $consumer$058inspect_body$1262$({$: "Unit"}, _owner_0);
}

function $case_first_check$1262$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1262$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1262$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1263$(__0, _owner_0) {
  return $consumer$058inspect_body$1263$({$: "Unit"}, _owner_0);
}

function $case_first_check$1263$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1263$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1263$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1264$(__0, _owner_0) {
  return $consumer$058inspect_body$1264$({$: "Unit"}, _owner_0);
}

function $case_first_check$1264$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1264$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1264$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1265$(__0, _owner_0) {
  return $consumer$058inspect_body$1265$({$: "Unit"}, _owner_0);
}

function $case_first_check$1265$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1265$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1265$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1266$(__0, _owner_0) {
  return $consumer$058inspect_body$1266$({$: "Unit"}, _owner_0);
}

function $case_first_check$1266$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1266$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1266$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1267$(__0, _owner_0) {
  return $consumer$058inspect_body$1267$({$: "Unit"}, _owner_0);
}

function $case_first_check$1267$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1267$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1267$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1268$(__0, _owner_0) {
  return $consumer$058inspect_body$1268$({$: "Unit"}, _owner_0);
}

function $case_first_check$1268$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1268$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1268$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$1269$(__0, _owner_0) {
  return $consumer$058inspect_body$1269$({$: "Unit"}, _owner_0);
}

function $case_first_check$1269$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1269$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$1269$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12610$(__0, _owner_0) {
  return $consumer$058inspect_body$12610$({$: "Unit"}, _owner_0);
}

function $case_first_check$12610$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12610$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12610$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12611$(__0, _owner_0) {
  return $consumer$058inspect_body$12611$({$: "Unit"}, _owner_0);
}

function $case_first_check$12611$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12611$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12611$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12612$(__0, _owner_0) {
  return $consumer$058inspect_body$12612$({$: "Unit"}, _owner_0);
}

function $case_first_check$12612$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12612$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12612$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12613$(__0, _owner_0) {
  return $consumer$058inspect_body$12613$({$: "Unit"}, _owner_0);
}

function $case_first_check$12613$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12613$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12613$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12614$(__0, _owner_0) {
  return $consumer$058inspect_body$12614$({$: "Unit"}, _owner_0);
}

function $case_first_check$12614$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12614$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12614$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $calls$058inspect_body$12615$(__0, _owner_0) {
  return $consumer$058inspect_body$12615$({$: "Unit"}, _owner_0);
}

function $case_first_check$12615$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12615$(((_index_0 + 2) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_first_check_done$12615$(_index_0, _name_0, _expected_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1261$(_registeredAt_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $machine$045calls$058snapshot_body_observed$1261$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _snapshot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": _snapshot_0}};
}

function $machine$045calls$058flow_snapshot$1261$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _flow_0 = _observed_0["snd"];
  return $machine$045calls$058level_snapshot$1261$(_flow_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1266$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1267$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1267$(($machine$045calls$058flow_cap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1261$(($machine$045calls$058snapshot_plan$1261$()))))))), _ctx_0);
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $dump$058notice$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    const _x_0 = ($U32$show$(_value_1));
    return ("user:" + _x_0);
  } else if (_value_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _value_2 = _value_0["failure"];
    const _x_1 = ($dump$058failure$1261$(_value_2));
    return ("relationFailed:" + _x_1);
  } else if (_value_0.$ === "../../../../src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_0));
    return ("componentRemoved:" + _x_2);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_3 = ($List$show$12617$(_frames_0));
    return ("cleanupPaused:" + _x_3);
  }
}

function $List$show$go$12618$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1261$(_h_0));
    const _x_1 = ($List$show$go$12618$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $measure$058run_checked$1261$(_index_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $measure$058after_checked_begin$1261$(_operation_0, _x_2);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1261$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1261$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1261$(($machine$045calls$058check_plan$1261$())))(_world_0));
}

function $machine_checked_capture_next$1261$(_result_0, _worldDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($checked_text$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  return $IO$bind$((_x_4) => $clock$058capture$(("machine-check:" + _x_3), _x_4), run_clo((_x_5) => {
  return run_tail(_next_0, _world_0);
}), _x_0);
});
}

function $continue_machine_check$(_index_0, _world_0, _registry_0, _garden_0, _gardenRegistry_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058read_streams$1261$(((_index_0 + 3) >>> 0), _registry_0, _world_0)), run_clo((_x_1) => {
  return $after_machine_streams$1260$(_x_1, _garden_0, _gardenRegistry_0);
}), _x_0);
});
}

function $setup$058queue_edges$1260$(_factory_0, _first_0, _middle_0, _last_0, _transaction_0) {
  return $setup$058accepted_edge_one$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058link$1260$()), _first_0, _middle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $setup$058seed_world$1260$(_first_0, _middle_0, _last_0, _world_0) {
  return $setup$058seeded_world$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(run_clo((_x_0) => {
  return $setup$058seed_store_effect$1260$(_first_0, _middle_0, _last_0, _x_0);
}), _world_0)));
}

function $setup$058accepted_edge_two$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058accepted_edge_three$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()), _first_0, _middle_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 2}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $setup$058seed_store$1261$(_store_0, _first_0, _middle_0, _last_0) {
  const _t_0 = _store_0["components"];
  const _cells_0 = _t_0["cells"];
  const _sibling_0 = _t_0["sibling"];
  const _graph_0 = _store_0["graph"];
  const _cells1_0 = ($setup$058write_component$1261$(_cells_0, _first_0, ($setup$058cell_payload$(1))));
  const _cells2_0 = ($setup$058write_component$1261$(_cells1_0, _middle_0, ($setup$058cell_payload$(2))));
  const _cells3_0 = ($setup$058write_component$1261$(_cells2_0, _last_0, ($setup$058cell_payload$(3))));
  const _siblings1_0 = ($setup$058write_component$1261$(_sibling_0, _first_0, ($setup$058sibling_payload$(1))));
  const _siblings2_0 = ($setup$058write_component$1261$(_siblings1_0, _middle_0, ($setup$058sibling_payload$(2))));
  const _siblings3_0 = ($setup$058write_component$1261$(_siblings2_0, _last_0, ($setup$058sibling_payload$(3))));
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "state.Components", "cells": _cells3_0, "sibling": _siblings3_0}, "graph": _graph_0};
}

function $List$show$12624$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1261$(_h_0));
    const _x_1 = ($List$show$go$12626$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1263$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $consumer$058inspect_plan$12616$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12616$())};
}

function $dump$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1264$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $dump$058tree_join$1260$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $dump$058edge$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1261$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12619$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1261$(_h_0));
    const _x_1 = ($List$show$go$12619$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058inverse$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($List$show$1260$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1261$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12620$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12620$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058bracket_u32_list$(_observed_0) {
  const _kept_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "]");
  return {$: "Tuple", "fst": _kept_0, "snd": ("[" + _x_0)};
}

function $dump$058u32_list_parts$(_value_0) {
  if (_value_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": ""};
  } else {
    const _head_0 = _value_0["head"];
    const _t_0 = _value_0["tail"];
    if (_t_0.$ === "Nil") {
      return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": {$: "Nil"}}, "snd": ($U32$show$(_head_0))};
    } else {
      const _second_0 = _t_0["head"];
      const _rest_0 = _t_0["tail"];
      return $dump$058u32_list_prepend$(_head_0, ($dump$058u32_list_parts$({$: "Con", "head": _second_0, "tail": _rest_0})));
    }
  }
}

function $dump$058tree_join$1261$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $dump$058batch$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _items_0 = _value_0["values"];
  const _x_0 = ($List$show$1261$(_items_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058batch$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058position$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12618$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12618$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12616$())))(_world_0));
}

function $checked_text$(_result_0) {
  if (_result_0.$ === "Done") {
    const _value_0 = _result_0["value"];
    return $Bool$show$(_value_0);
  } else {
    return "Fail";
  }
}

function $case_second_check_done$1261$(_name_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1261$(_name_0, _result_0, ($dump$058world$1261$(_world_0)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $IO$pure$(_x_0, _x_1);
});
}));
}

function $consumer$058inspect_plan$12617$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12617$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12619$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12619$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12617$())))(_world_0));
}

function $consumer$058inspect_plan$12618$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12618$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12620$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12620$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12618$())))(_world_0));
}

function $consumer$058inspect_plan$12619$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12619$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12621$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12621$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12619$())))(_world_0));
}

function $consumer$058inspect_plan$12620$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12620$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12622$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12622$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12620$())))(_world_0));
}

function $consumer$058inspect_plan$12621$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12621$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12623$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12623$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12621$())))(_world_0));
}

function $consumer$058inspect_plan$12622$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12622$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12624$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12624$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12622$())))(_world_0));
}

function $consumer$058inspect_plan$12623$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12623$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12625$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12625$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12623$())))(_world_0));
}

function $consumer$058inspect_plan$12624$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12624$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12626$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12626$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12624$())))(_world_0));
}

function $consumer$058inspect_plan$12625$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12625$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12627$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12627$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12625$())))(_world_0));
}

function $consumer$058inspect_plan$12626$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12626$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12628$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12628$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12626$())))(_world_0));
}

function $consumer$058inspect_plan$12627$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12627$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12629$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12629$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12627$())))(_world_0));
}

function $consumer$058inspect_plan$12628$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12628$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12630$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12630$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12628$())))(_world_0));
}

function $consumer$058inspect_plan$12629$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12629$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12631$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12631$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12629$())))(_world_0));
}

function $consumer$058inspect_plan$12630$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12630$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12632$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12632$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12630$())))(_world_0));
}

function $consumer$058inspect_plan$12631$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12631$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12633$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12633$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(($consumer$058condition_plan$12631$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1262$(_registeredAt_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058inspect_body$1260$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1264$(_owner_0)));
}

function $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$12612$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1269$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = ("," + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("," + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = ("," + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058graph$1260$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($List$show$12614$(_inverses_0));
  const _x_1 = ($List$show$12613$(_edges_0));
  const _x_2 = (";" + _x_0);
  return (_x_1 + _x_2);
}

function $dump$058component_done$1260$(_cellsObserved_0, _siblingObserved_0) {
  const _cells_0 = _cellsObserved_0["fst"];
  const _text_0 = _cellsObserved_0["snd"];
  const _sibling_0 = _siblingObserved_0["fst"];
  const _siblingText_0 = _siblingObserved_0["snd"];
  const _x_0 = (";sibling=" + _siblingText_0);
  return {$: "Tuple", "fst": {$: "state.Components", "cells": _cells_0, "sibling": _sibling_0}, "snd": (_text_0 + _x_0)};
}

function $dump$058slot$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058slot$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $calls$058check$1260$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1260$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1260$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1260$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1261$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1266$(_owner_0)));
}

function $calls$058check$1261$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1261$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1261$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1261$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1262$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1268$(_owner_0)));
}

function $calls$058check$1262$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1262$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1262$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1262$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1263$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12610$(_owner_0)));
}

function $calls$058check$1263$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1263$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1263$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1263$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1264$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12612$(_owner_0)));
}

function $calls$058check$1264$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1264$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1264$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1264$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1265$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12614$(_owner_0)));
}

function $calls$058check$1265$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1265$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1265$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1265$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1266$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12616$(_owner_0)));
}

function $calls$058check$1266$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1266$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1266$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1266$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1267$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12618$(_owner_0)));
}

function $calls$058check$1267$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1267$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1267$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1267$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1268$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12620$(_owner_0)));
}

function $calls$058check$1268$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1268$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1268$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1268$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$1269$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12622$(_owner_0)));
}

function $calls$058check$1269$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$1269$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$1269$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$1269$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12610$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12624$(_owner_0)));
}

function $calls$058check$12610$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12610$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12610$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12610$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12611$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12626$(_owner_0)));
}

function $calls$058check$12611$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12611$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12611$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12611$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12612$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12628$(_owner_0)));
}

function $calls$058check$12612$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12612$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12612$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12612$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12613$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12630$(_owner_0)));
}

function $calls$058check$12613$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12613$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12613$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12613$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12614$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12632$(_owner_0)));
}

function $calls$058check$12614$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12614$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12614$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12614$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $consumer$058inspect_body$12615$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12634$(_owner_0)));
}

function $calls$058check$12615$(_index_0, _expected_0, _world_0) {
  return $calls$058check_prepared$12615$(_index_0, _expected_0, _world_0);
}

function $case_first_check_done$12615$(_index_0, _name_0, _expected_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $case_second_check$12615$(_index_0, _name_0, _expected_0, _x_0);
}));
}

function $machine$045calls$058level_snapshot$1261$(_flow_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _level_0 = _observed_0["snd"];
  return $machine$045calls$058rows_snapshot$1261$(_flow_0, _level_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1263$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1266$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1266$(($machine$045calls$058level_cap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1261$(($machine$045calls$058snapshot_plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1267$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058flow_cap$1261$(_caps_0) {
  const _flow_0 = _caps_0["first"];
  return _flow_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $machine$045calls$058snapshot_plan$1261$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($machine$045calls$058snapshot_caps$1261$())};
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $dump$058failure$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _op_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($dump$058relation_error$(_error_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_source_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058operation$(_op_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058descriptor$1261$(_relation_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1261$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $measure$058after_checked_begin$1261$(_operation_0, __0) {
  return $measure$058finish_checked$1261$(_operation_0({$: "Unit"}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1261$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1262$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1261$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $machine$045calls$058check_plan$1261$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058required$1261$(_x_0);
}), "caps": ($machine$045calls$058check_caps$1261$())};
}

function $machine$045calls$058read_streams$1261$(_index_0, _registry_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_started$1261$(_index_0, _registry_0, _world_0, _x_2);
}), _x_0);
});
}

function $after_machine_streams$1260$(_observed_0, _garden_0, _gardenRegistry_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058capture$(($machine$045calls$058stream_read_text$1261$(_observed_0)), _x_1), run_clo((_x_2) => {
  return $garden_machine$(132, _garden_0, _gardenRegistry_0);
}), _x_0);
});
}

function $setup$058accepted_edge_one$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058accepted_edge_two$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058link$1260$()), _last_0, _middle_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047ordinary$045category$045v1$047declarations$058link$1260$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}};
}

function $setup$058seeded_world$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $setup$058seed_store_effect$1260$(_first_0, _middle_0, _last_0, _store_0) {
  return {$: "Tuple", "fst": ($setup$058seed_store$1260$(_store_0, _first_0, _middle_0, _last_0)), "snd": {$: "Unit"}};
}

function $setup$058accepted_edge_three$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058accepted_edge_four$1261$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()), _last_0, _middle_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 3}};
  }
}

function $$$$047ordinary$045category$045v1$047declarations$058parent$1261$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $setup$058write_component$1261$(_values_0, _handle_0, _payload_0) {
  const _id_0 = _handle_0["id"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return (_values_0[_x_0 % _values_0.length] = _payload_0, _values_0);
}

function $setup$058cell_payload$(_id_0) {
  const _x_0 = (Math.imul(_id_0, 10) >>> 0);
  const _x_1 = (Math.imul(_id_0, 10) >>> 0);
  return {$: "Con", "head": ((_x_0 + 1) >>> 0), "tail": {$: "Con", "head": ((_x_1 + 2) >>> 0), "tail": {$: "Nil"}}};
}

function $setup$058sibling_payload$(_id_0) {
  const _x_0 = (Math.imul(_id_0, 10) >>> 0);
  const _x_1 = (Math.imul(_id_0, 10) >>> 0);
  return {$: "Con", "head": ((_x_0 + 3) >>> 0), "tail": {$: "Con", "head": ((_x_1 + 4) >>> 0), "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1261$(_value_0) {
  const _entity_0 = _value_0["entity"];
  const _t_0 = _value_0["data"];
  const _cells_0 = _t_0["right"];
  const _x_0 = ($List$show$12625$(_cells_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_entity_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12626$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1261$(_h_0));
    const _x_1 = ($List$show$go$12626$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12616$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12618$();
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1264$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $dump$058descriptor$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($dump$058relation_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverseName_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058u32_list_prepend$(_head_0, _observed_0) {
  const _tail_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_head_0));
  const _x_1 = ("," + _text_0);
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_0}, "snd": (_x_0 + _x_1)};
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058transition$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12618$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12637$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1263$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $consumer$058condition_plan$12616$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12616$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12617$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12619$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12619$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12639$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12617$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12617$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12618$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12620$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12620$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12641$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12618$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12618$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12619$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12621$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12621$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12643$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12619$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12619$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12620$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12622$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12622$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12645$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12620$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12620$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12621$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12623$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12623$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12647$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12621$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12621$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12622$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12624$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12624$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12649$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12622$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12622$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12623$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12625$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12625$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12651$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12623$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12623$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12624$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12626$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12626$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12653$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12624$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12624$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12625$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12627$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12627$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12655$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12625$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12625$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12626$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12628$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12628$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12657$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12626$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12626$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12627$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12629$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12629$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12659$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12627$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12627$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12628$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12630$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12630$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12661$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12628$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12628$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12629$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12631$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12631$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12663$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12629$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12629$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12630$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12632$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12632$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12665$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12630$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12630$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12631$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12633$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12633$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12667$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12631$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12631$())};
}

function $consumer$058inspect_rows$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": ($List$show$12621$(_rows_0))}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1264$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1260$()))))), _owner_0);
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1260$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1260$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $calls$058check_prepared$1260$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1262$(_expected_0, _world_0);
}));
}

function $checked_capture_next$1260$(_name_0, _result_0, _worldDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($checked_text$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  return $IO$bind$((_x_6) => $clock$058capture$(("check:" + _x_5), _x_6), run_clo((_x_7) => {
  return run_tail(_next_0, _world_0);
}), _x_0);
});
}

function $case_second_check$1260$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1260$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1266$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1261$()))))), _owner_0);
}

function $calls$058check_prepared$1261$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1263$(_expected_0, _world_0);
}));
}

function $case_second_check$1261$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1261$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1268$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1262$()))))), _owner_0);
}

function $calls$058check_prepared$1262$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1264$(_expected_0, _world_0);
}));
}

function $case_second_check$1262$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1262$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12610$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1263$()))))), _owner_0);
}

function $calls$058check_prepared$1263$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1265$(_expected_0, _world_0);
}));
}

function $case_second_check$1263$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1263$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12612$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1264$()))))), _owner_0);
}

function $calls$058check_prepared$1264$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1266$(_expected_0, _world_0);
}));
}

function $case_second_check$1264$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1264$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12614$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1265$()))))), _owner_0);
}

function $calls$058check_prepared$1265$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1267$(_expected_0, _world_0);
}));
}

function $case_second_check$1265$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1265$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12616$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1266$()))))), _owner_0);
}

function $calls$058check_prepared$1266$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1268$(_expected_0, _world_0);
}));
}

function $case_second_check$1266$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1266$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12618$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1267$()))))), _owner_0);
}

function $calls$058check_prepared$1267$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1269$(_expected_0, _world_0);
}));
}

function $case_second_check$1267$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1267$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12620$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1268$()))))), _owner_0);
}

function $calls$058check_prepared$1268$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12610$(_expected_0, _world_0);
}));
}

function $case_second_check$1268$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1268$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12622$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$1269$()))))), _owner_0);
}

function $calls$058check_prepared$1269$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12611$(_expected_0, _world_0);
}));
}

function $case_second_check$1269$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$1269$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12624$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$12610$()))))), _owner_0);
}

function $calls$058check_prepared$12610$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12612$(_expected_0, _world_0);
}));
}

function $case_second_check$12610$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12610$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12626$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$12611$()))))), _owner_0);
}

function $calls$058check_prepared$12611$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12613$(_expected_0, _world_0);
}));
}

function $case_second_check$12611$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12611$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12628$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$12612$()))))), _owner_0);
}

function $calls$058check_prepared$12612$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12614$(_expected_0, _world_0);
}));
}

function $case_second_check$12612$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12612$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12630$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$12613$()))))), _owner_0);
}

function $calls$058check_prepared$12613$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12615$(_expected_0, _world_0);
}));
}

function $case_second_check$12613$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12613$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12632$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$12614$()))))), _owner_0);
}

function $calls$058check_prepared$12614$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12616$(_expected_0, _world_0);
}));
}

function $case_second_check$12614$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12614$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12634$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(($consumer$058inspect_plan$12615$()))))), _owner_0);
}

function $calls$058check_prepared$12615$(_index_0, _expected_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12617$(_expected_0, _world_0);
}));
}

function $case_second_check$12615$(_index_0, _name_0, _expected_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($calls$058check$12615$(((_index_0 + 3) >>> 0), _expected_0, _world_0)), run_clo((_x_1) => {
  return $case_second_check_done$1260$(_name_0, _x_1);
}), _x_0);
});
}

function $machine$045calls$058rows_snapshot$1261$(_flow_0, _level_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _rows_0 = _observed_0["snd"];
  return $machine$045calls$058rows_snapshot_event$1261$(_flow_0, _level_0, _rows_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1265$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1263$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($machine$045calls$058relation_cap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1261$(($machine$045calls$058snapshot_plan$1261$()))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1266$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058level_cap$1261$(_caps_0) {
  const _t_0 = _caps_0["second"];
  const _level_0 = _t_0["first"];
  return _level_0;
}

function $machine$045calls$058snapshot_caps$1261$() {
  return {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1262$()), "second": {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1263$()), "second": {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1261$()), "second": ($machine$045calls$058frame_event_cap$1261$())}}};
}

function $dump$058operation$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-types.Relate") {
    return "relate";
  } else {
    return "reorderChildren";
  }
}

function $dump$058relation_error$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-types.MissingEntity") {
    const _source_0 = _value_0["source"];
    const _x_0 = ($U32$show$(_source_0));
    return ("missingEntity:" + _x_0);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.MissingTargetEntity") {
    const _source_1 = _value_0["source"];
    const _target_0 = _value_0["target"];
    const _relation_0 = _value_0["relation"];
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (":" + _relation_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_1));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("missingTarget:" + _x_6);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.SelfRelationNotAllowed") {
    const _source_2 = _value_0["source"];
    const _relation_1 = _value_0["relation"];
    const _x_7 = ($U32$show$(_source_2));
    const _x_8 = (":" + _relation_1);
    const _x_9 = (_x_7 + _x_8);
    return ("selfRelation:" + _x_9);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.HierarchyCycle") {
    const _source_3 = _value_0["source"];
    const _target_1 = _value_0["target"];
    const _relation_2 = _value_0["relation"];
    const _x_10 = ($U32$show$(_target_1));
    const _x_11 = (":" + _relation_2);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_source_3));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("hierarchyCycle:" + _x_15);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.MissingChildEntity") {
    const _source_4 = _value_0["source"];
    const _child_0 = _value_0["child"];
    const _relation_3 = _value_0["relation"];
    const _x_16 = ($U32$show$(_child_0));
    const _x_17 = (":" + _relation_3);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($U32$show$(_source_4));
    const _x_20 = (":" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    return ("missingChild:" + _x_21);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.DuplicateChild") {
    const _source_5 = _value_0["source"];
    const _child_1 = _value_0["child"];
    const _relation_4 = _value_0["relation"];
    const _x_22 = ($U32$show$(_child_1));
    const _x_23 = (":" + _relation_4);
    const _x_24 = (_x_22 + _x_23);
    const _x_25 = ($U32$show$(_source_5));
    const _x_26 = (":" + _x_24);
    const _x_27 = (_x_25 + _x_26);
    return ("duplicateChild:" + _x_27);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.ChildNotRelatedToParent") {
    const _source_6 = _value_0["source"];
    const _child_2 = _value_0["child"];
    const _relation_5 = _value_0["relation"];
    const _x_28 = ($U32$show$(_child_2));
    const _x_29 = (":" + _relation_5);
    const _x_30 = (_x_28 + _x_29);
    const _x_31 = ($U32$show$(_source_6));
    const _x_32 = (":" + _x_30);
    const _x_33 = (_x_31 + _x_32);
    return ("childNotRelated:" + _x_33);
  } else {
    const _source_7 = _value_0["source"];
    const _relation_6 = _value_0["relation"];
    const _x_34 = ($U32$show$(_source_7));
    const _x_35 = (":" + _relation_6);
    const _x_36 = (_x_34 + _x_35);
    return ("childSetMismatch:" + _x_36);
  }
}

function $dump$058cleanup$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_1 = ($List$show$12618$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _relation_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_5 = ($List$show$1260$(_children_0));
    const _x_6 = ($List$show$12618$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($dump$058descriptor$1261$(_relation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _value_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1261$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $measure$058finish_checked$1261$(_value_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_workshop_checked$(_value_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $clock$058end$(_x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$(_x_2, _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _value_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1262$(_args_0, _ctx_0) {
  return $machine$045calls$058check_body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058required$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058availability$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(($machine$045calls$058flow_decl$1261$()))), ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1262$(_world_0)));
}

function $machine$045calls$058check_caps$1261$() {
  return {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058condition$1261$()), "second": ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1261$())};
}

function $machine$045calls$058stream_read_started$1261$(_index_0, _context_0, _world_0, __0) {
  return run_clo((_x_0) => {
  return $IO$bind$(run_clo((_x_1) => {
  return $IO$pure$(($machine$045calls$058observed_run_result$1261$(($machine$045calls$058actual_reader_run$1261$(_world_0, _context_0)))), _x_1);
}), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_forced$1261$(_x_2);
}), _x_0);
});
}

function $machine$045calls$058stream_read_text$1261$(_read_0) {
  const _runtime_0 = _read_0["runtime"];
  const _reader_0 = _read_0["reader"];
  const _instance_0 = _read_0["instance"];
  const _result_0 = _read_0["result"];
  return $machine$045calls$058stream_read_runtime_text$1261$(_runtime_0, _reader_0, _instance_0, _result_0);
}

function $garden_machine$(_index_0, _world_0, _registry_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058inspect_machine$1260$(_index_0, {$: "../../../../src/ecs/inspector.Fresh"}, _world_0)), run_clo((_x_1) => {
  return $after_garden_machine_first$(_index_0, _x_1, _registry_0);
}), _x_0);
});
}

function $setup$058accepted_edge_two$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058accepted_edge_three$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()), _first_0, _middle_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 2}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $setup$058seed_store$1260$(_store_0, _first_0, _middle_0, _last_0) {
  const _t_0 = _store_0["components"];
  const _cells_0 = _t_0["cells"];
  const _sibling_0 = _t_0["sibling"];
  const _graph_0 = _store_0["graph"];
  const _cells1_0 = ($setup$058write_component$1260$(_cells_0, _first_0, ($setup$058cell_payload$(1))));
  const _cells2_0 = ($setup$058write_component$1260$(_cells1_0, _middle_0, ($setup$058cell_payload$(2))));
  const _cells3_0 = ($setup$058write_component$1260$(_cells2_0, _last_0, ($setup$058cell_payload$(3))));
  const _siblings1_0 = ($setup$058write_component$1260$(_sibling_0, _first_0, ($setup$058sibling_payload$(1))));
  const _siblings2_0 = ($setup$058write_component$1260$(_siblings1_0, _middle_0, ($setup$058sibling_payload$(2))));
  const _siblings3_0 = ($setup$058write_component$1260$(_siblings2_0, _last_0, ($setup$058sibling_payload$(3))));
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "state.Components", "cells": _cells3_0, "sibling": _siblings3_0}, "graph": _graph_0};
}

function $setup$058accepted_edge_four$1261$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058commit_edges$1261$(_factory_0, _first_0, _middle_0, _last_0, _transaction_0);
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 4}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = ($U32$show$(_ns_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$12625$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058cell$1261$(_h_0));
    const _x_1 = ($List$show$go$12625$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12618$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_required_out$1261$()))));
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1264$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $dump$058relation_kind$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return "ordinary";
  } else {
    return "hierarchy";
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058transition$(_value_0) {
  const _a_0 = _value_0["from"];
  const _b_0 = _value_0["to"];
  const _x_0 = ($U32$show$(_b_0));
  const _x_1 = ($U32$show$(_a_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058transition$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12637$(_args_0, _ctx_0) {
  return $calls$058check_body$12616$(_args_0, _ctx_0);
}

function $consumer$058required$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12616$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12618$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12619$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_optional_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12639$(_args_0, _ctx_0) {
  return $calls$058check_body$12617$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12617$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12619$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12620$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_present_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12641$(_args_0, _ctx_0) {
  return $calls$058check_body$12618$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12618$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12620$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12621$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12643$(_args_0, _ctx_0) {
  return $calls$058check_body$12619$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12619$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12621$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12622$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_required_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12645$(_args_0, _ctx_0) {
  return $calls$058check_body$12620$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12620$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12622$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12623$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_optional_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12647$(_args_0, _ctx_0) {
  return $calls$058check_body$12621$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12621$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12623$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12624$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_present_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12649$(_args_0, _ctx_0) {
  return $calls$058check_body$12622$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12622$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12624$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12625$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12651$(_args_0, _ctx_0) {
  return $calls$058check_body$12623$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12623$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12625$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12626$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_required_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12653$(_args_0, _ctx_0) {
  return $calls$058check_body$12624$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12624$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12626$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12627$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_optional_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12655$(_args_0, _ctx_0) {
  return $calls$058check_body$12625$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12625$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12627$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12628$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_present_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12657$(_args_0, _ctx_0) {
  return $calls$058check_body$12626$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12626$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12628$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12629$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_out$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12659$(_args_0, _ctx_0) {
  return $calls$058check_body$12627$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12627$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12629$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12630$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_required_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12661$(_args_0, _ctx_0) {
  return $calls$058check_body$12628$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12628$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12630$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12631$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_optional_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12663$(_args_0, _ctx_0) {
  return $calls$058check_body$12629$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12629$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12631$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12632$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_present_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12665$(_args_0, _ctx_0) {
  return $calls$058check_body$12630$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12630$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12632$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12633$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12667$(_args_0, _ctx_0) {
  return $calls$058check_body$12631$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12631$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12633$();
}

function $List$show$12621$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_h_0));
    const _x_1 = ($List$show$go$12623$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1262$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $consumer$058inspect_plan$1260$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1260$())};
}

function $dump$058notice$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    const _x_0 = ($U32$show$(_value_1));
    return ("user:" + _x_0);
  } else if (_value_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _value_2 = _value_0["failure"];
    const _x_1 = ($dump$058failure$1260$(_value_2));
    return ("relationFailed:" + _x_1);
  } else if (_value_0.$ === "../../../../src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_0));
    return ("componentRemoved:" + _x_2);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_3 = ($List$show$12610$(_frames_0));
    return ("cleanupPaused:" + _x_3);
  }
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1260$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058edge$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1260$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1260$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058inverse$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($List$show$1260$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1260$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $measure$058run_checked$1260$(_index_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $measure$058after_checked_begin$1260$(_operation_0, _x_2);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1262$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1262$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1260$())))(_world_0));
}

function $case_second_check_done$1260$(_name_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $checked_capture_next$1260$(_name_0, _result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $IO$pure$(_x_0, _x_1);
});
}));
}

function $consumer$058inspect_plan$1261$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1261$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1263$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1263$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1261$())))(_world_0));
}

function $consumer$058inspect_plan$1262$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1262$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1264$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1264$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1262$())))(_world_0));
}

function $consumer$058inspect_plan$1263$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1263$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1265$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1265$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1263$())))(_world_0));
}

function $consumer$058inspect_plan$1264$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1264$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1266$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1266$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1264$())))(_world_0));
}

function $consumer$058inspect_plan$1265$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1265$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1267$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1267$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1265$())))(_world_0));
}

function $consumer$058inspect_plan$1266$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1266$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1268$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1268$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1266$())))(_world_0));
}

function $consumer$058inspect_plan$1267$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1267$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1269$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1269$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1267$())))(_world_0));
}

function $consumer$058inspect_plan$1268$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1268$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12610$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12610$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1268$())))(_world_0));
}

function $consumer$058inspect_plan$1269$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1269$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12611$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12611$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$1269$())))(_world_0));
}

function $consumer$058inspect_plan$12610$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12610$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12612$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12612$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$12610$())))(_world_0));
}

function $consumer$058inspect_plan$12611$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12611$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12613$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12613$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$12611$())))(_world_0));
}

function $consumer$058inspect_plan$12612$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12612$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12614$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12614$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$12612$())))(_world_0));
}

function $consumer$058inspect_plan$12613$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12613$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12615$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12615$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$12613$())))(_world_0));
}

function $consumer$058inspect_plan$12614$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12614$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12616$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12616$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$12614$())))(_world_0));
}

function $consumer$058inspect_plan$12615$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12615$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$12617$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12617$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(($consumer$058condition_plan$12615$())))(_world_0));
}

function $machine$045calls$058rows_snapshot_event$1261$(_flow_0, _level_0, _rows_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "machine-types.Snapshot", "flow": _flow_0, "level": _level_0, "rows": _rows_0, "events": _events_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1265$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1265$(($machine$045calls$058event_cap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1261$(($machine$045calls$058snapshot_plan$1261$()))))))), _ctx_0);
}

function $machine$045calls$058relation_cap$1261$(_caps_0) {
  const _t_0 = _caps_0["second"];
  const _t_1 = _t_0["second"];
  const _relations_0 = _t_1["first"];
  return _relations_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1262$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1262$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1263$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1263$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(($machine$045calls$058relation_spec$1261$()));
}

function $machine$045calls$058frame_event_cap$1261$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $machine$045calls$058frame_events$1261$(_x_0);
})};
}

function $List$show$12618$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12616$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $clock$058force_workshop_checked$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_workshop_checked"].run, need: $0eff["clock.force_workshop_checked"].need, args: [$0m42(_value_0)], kont: ((f) => (x) => (f($0m43(x))))(_k_0) };
}
function $machine$045calls$058check_body$1261$(__0, _owner_0) {
  return $machine$045calls$058check_query$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058matches$1261$(_owner_0, 7)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058availability$1261$(_name_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(_declaration_0) {
  if (_declaration_0.$ === "../../../../src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $machine$045calls$058flow_decl$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$("Flow", {$: "Con", "head": 4, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}}}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1262$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1262$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($state$058flow$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058condition$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_provide$1261$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($machine$045calls$058relation_spec$1261$()));
}

function $machine$045calls$058observed_run_result$1261$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _completion_0 = _result_0["completion"];
  return $machine$045calls$058pending_runtime$1261$(_runtime_0, _reader_0, _completion_0);
}

function $machine$045calls$058actual_reader_run$1261$(_world_0, _context_0) {
  const _state_0 = _context_0["state"];
  const _reader_0 = _context_0["reader"];
  const _readerId_0 = _context_0["readerId"];
  return $machine$045calls$058actual_reader_run_context$1261$(_world_0, _state_0, _reader_0, _readerId_0);
}

function $machine$045calls$058stream_read_forced$1261$(_pending_0) {
  const _observed_0 = _pending_0["observed"];
  const _state_0 = _pending_0["state"];
  const _reader_0 = _pending_0["reader"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_workshop_streams$(_observed_0, _x_1), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_finish$1261$(_x_2, _state_0, _reader_0);
}), _x_0);
});
}

function $machine$045calls$058stream_read_runtime_text$1261$(_runtime_0, _reader_0, _instance_0, _result_0) {
  const _world_0 = _runtime_0["world"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _x_0 = ($machine$045calls$058world_dump_text$1261$(($dump$058world$1261$(_world_0))));
  const _x_1 = ($machine$045calls$058actual_reader_text$1261$(_reader_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($machine$045calls$058runtime_positions_text$(_positions_0));
  const _x_5 = (":reader=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_capacity_0));
  const _x_8 = (":positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_boundary_0));
  const _x_11 = (":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($Nat$show$(_frameStart_0));
  const _x_14 = (":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($Nat$show$(_tick_0));
  const _x_17 = (":" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($machine$045calls$058stream_result_text$1261$(_result_0));
  const _x_20 = (":runtime=" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($machine$045calls$058stream_instance_text$1261$(_instance_0));
  const _x_23 = (":" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  return ("stream-read:" + _x_24);
}

function $machine$045calls$058inspect_machine$1260$(_index_0, _instance_0, _world_0) {
  return $measure$058run_observed$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1260$(_instance_0, {$: "Unit"}, _world_0);
}));
}

function $after_garden_machine_first$(_index_0, _observed_0, _registry_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $machine_inspection_capture_next$1260$(_result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $continue_garden_machine_first$(_index_0, _x_0, _registry_0);
}));
}

function $setup$058accepted_edge_three$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058accepted_edge_four$1260$(_factory_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_transaction_0, ($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()), _last_0, _middle_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 3}};
  }
}

function $$$$047ordinary$045category$045v1$047declarations$058parent$1260$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $setup$058write_component$1260$(_values_0, _handle_0, _payload_0) {
  const _id_0 = _handle_0["id"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return (_values_0[_x_0 % _values_0.length] = _payload_0, _values_0);
}

function $setup$058commit_edges$1261$(_factory_0, _first_0, _middle_0, _last_0, _transaction_0) {
  return $setup$058committed$1261$(_factory_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(_transaction_0, {$: "../../../../src/ecs/relation-commands.Original", "event": 31})), {$: "../../../../src/ecs/relation-commands.Original", "event": 32})))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058cell$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  const _direction_0 = _value_0["end"];
  const _value_1 = _value_0["value"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058relation_value$1261$(_value_1));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058end$(_direction_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$12625$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058cell$1261$(_h_0));
    const _x_1 = ($List$show$go$12625$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1263$(_argument_0) {
  return {$: "../../../../src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1263$(_argument_0, _x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1263$(_x_1, _x_2, _argument_0);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(_declaration_0) {
  const _source_0 = _declaration_0["source"];
  const _mode_0 = _declaration_0["mode"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1261$(_source_0, _mode_0);
}

function $consumer$058link_required_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_out$1261$("link_required_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12616$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12616$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12618$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_required_out$1261$()))));
}

function $consumer$058link_optional_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_out$1261$("link_optional_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12617$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12617$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12619$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_optional_out$1261$()))));
}

function $consumer$058link_present_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_out$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12618$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12618$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12620$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_present_out$1261$()))));
}

function $consumer$058link_absent_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12619$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12619$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12621$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_out$1261$()))));
}

function $consumer$058link_required_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_in$1261$("link_required_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12620$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12620$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12622$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_required_in$1261$()))));
}

function $consumer$058link_optional_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_in$1261$("link_optional_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12621$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12621$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12623$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_optional_in$1261$()))));
}

function $consumer$058link_present_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_in$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12622$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12622$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12624$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_present_in$1261$()))));
}

function $consumer$058link_absent_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_in$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$()));
}

function $calls$058check_body$12623$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12623$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12625$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_in$1261$()))));
}

function $consumer$058parent_required_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_out$1261$("parent_required_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12624$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12624$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12626$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_required_out$1261$()))));
}

function $consumer$058parent_optional_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_out$1261$("parent_optional_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12625$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12625$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12627$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_optional_out$1261$()))));
}

function $consumer$058parent_present_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_out$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12626$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12626$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12628$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_present_out$1261$()))));
}

function $consumer$058parent_absent_out$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12627$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12627$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12629$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_out$1261$()))));
}

function $consumer$058parent_required_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_in$1261$("parent_required_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12628$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12628$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12630$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_required_in$1261$()))));
}

function $consumer$058parent_optional_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_in$1261$("parent_optional_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12629$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12629$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12631$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_optional_in$1261$()))));
}

function $consumer$058parent_present_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_in$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12630$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12630$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12632$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_present_in$1261$()))));
}

function $consumer$058parent_absent_in$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_in$1261$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$()));
}

function $calls$058check_body$12631$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12631$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12633$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_in$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_value_0) {
  const _entity_0 = _value_0["entity"];
  const _t_0 = _value_0["data"];
  const _cells_0 = _t_0["right"];
  const _x_0 = ($List$show$12622$(_cells_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_entity_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12623$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_h_0));
    const _x_1 = ($List$show$go$12623$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1262$();
}

function $dump$058failure$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _op_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($dump$058relation_error$(_error_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_source_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058operation$(_op_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058descriptor$1260$(_relation_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058descriptor$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($dump$058relation_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverseName_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $measure$058after_checked_begin$1260$(_operation_0, __0) {
  return $measure$058finish_checked$1260$(_operation_0({$: "Unit"}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1262$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1265$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1262$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $consumer$058condition_plan$1260$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1260$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1263$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1263$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1267$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1261$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1261$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1262$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1264$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1264$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1269$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1262$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1262$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1263$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1265$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1265$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12611$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1263$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1263$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1264$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1266$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1266$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12613$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1264$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1264$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1265$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1267$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1267$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12615$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1265$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1265$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1266$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1268$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1268$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12617$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1266$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1266$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1267$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1269$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1269$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12619$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1267$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1267$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1268$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12610$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12610$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12621$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1268$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1268$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1269$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12611$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12611$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12623$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1269$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1269$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12610$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12612$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12612$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12625$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12610$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12610$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12611$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12613$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12613$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12627$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12611$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12611$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12612$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12614$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12614$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12629$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12612$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12612$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12613$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12615$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12615$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12631$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12613$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12613$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12614$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12616$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12616$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12633$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12614$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12614$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058inspect$12615$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12617$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$12617$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12635$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$12615$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12615$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1265$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058event_cap$1261$(_caps_0) {
  const _t_0 = _caps_0["second"];
  const _t_1 = _t_0["second"];
  const _events_0 = _t_1["second"];
  return _events_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1262$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1262$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1263$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1263$(_x_0);
})};
}

function $machine$045calls$058relation_spec$1261$() {
  return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1261$("link", ($$$$047ordinary$045category$045v1$047declarations$058link$1261$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1261$("linkedBy", ($$$$047ordinary$045category$045v1$047declarations$058link$1261$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1261$("parent", ($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1261$("children", ($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()))), "tail": {$: "Nil"}}}}}};
}

function $machine$045calls$058frame_events$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $machine$045calls$058frame_events_from_view$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)));
}

function $List$show$go$12616$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12616$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $machine$045calls$058check_query$1261$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return $machine$045calls$058check_rows$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1262$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058matches$1261$(_owner_0, _value_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058compared$1261$(_value_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058get$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$(_name_0, _values_0) {
  return {$: "../../../../src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1262$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $state$058flow$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_provide$1261$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_current$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1262$(_argument_0) {
  return {$: "../../../../src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1262$(_argument_0, _x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1262$(_x_1, _x_2, _argument_0);
});
})};
}

function $machine$045calls$058pending_runtime$1261$(_runtime_0, _reader_0, _completion_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $machine$045calls$058pending_reader$1261$(_world_0, {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, ($machine$045calls$058reader_with_identity$1261$(_reader_0)), _completion_0);
}

function $machine$045calls$058actual_reader_run_context$1261$(_world_0, _state_0, _reader_0, _readerId_0) {
  return $machine$045calls$058actual_reader_run_state$1261$(_world_0, _state_0, _reader_0, _readerId_0);
}

function $clock$058force_workshop_streams$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_workshop_streams"].run, need: $0eff["clock.force_workshop_streams"].need, args: [$0m44(_value_0)], kont: ((f) => (x) => (f($0m48(x))))(_k_0) };
}
function $machine$045calls$058stream_read_finish$1261$(_observed_0, _state_0, _reader_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058end$(_x_1), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_after_end$1261$(_observed_0, _state_0, _reader_0, _x_2);
}), _x_0);
});
}

function $machine$045calls$058stream_instance_text$1261$(_instance_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return "Fresh";
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("Active(" + _x_4);
  }
}

function $machine$045calls$058stream_result_text$1261$(_result_0) {
  if (_result_0.$ === "Done") {
    const _value_0 = _result_0["value"];
    return $machine$045calls$058streams_text$1261$(_value_0);
  } else {
    return "Fail";
  }
}

function $machine$045calls$058runtime_positions_text$(_positions_0) {
  return $List$show$1265$(_positions_0);
}

function $machine$045calls$058actual_reader_text$1261$(_reader_0) {
  const _registry_0 = _reader_0["registry"];
  return $machine$045calls$058reader_registry_text$1261$(_registry_0);
}

function $machine$045calls$058world_dump_text$1261$(_joined_0) {
  const _text_0 = _joined_0["snd"];
  return _text_0;
}

function $measure$058run_observed$1260$(_index_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $measure$058after_observed_begin$1260$(_operation_0, _x_2);
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058run$1260$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1260$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1260$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $machine_inspection_capture_next$1260$(_result_0, _worldDump_0, _instanceDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  const _instance_0 = _instanceDump_0["fst"];
  const _instanceText_0 = _instanceDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($machine_result_text$1260$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_instanceText_0 + _x_4);
  return $IO$bind$((_x_6) => $clock$058capture$(("machine-inspect:" + _x_5), _x_6), run_clo((_x_7) => {
  return run_tail(_next_0, {$: "InspectReport", "world": _world_0, "instance": _instance_0});
}), _x_0);
});
}

function $continue_garden_machine_first$(_index_0, _report_0, _registry_0) {
  const _world_0 = _report_0["world"];
  const _instance_0 = _report_0["instance"];
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058inspect_machine$1260$(((_index_0 + 1) >>> 0), _instance_0, _world_0)), run_clo((_x_1) => {
  return $after_garden_machine_second$(_index_0, _x_1, _registry_0);
}), _x_0);
});
}

function $setup$058accepted_edge_four$1260$(_factory_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058commit_edges$1260$(_factory_0, _first_0, _middle_0, _last_0, _transaction_0);
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.RelationQueueRefused", "factory": _factory_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 4}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $setup$058committed$1261$(_factory_0, _first_0, _middle_0, _last_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    return $setup$058state_transition_requests$1261$(_factory_0, _first_0, _middle_0, _last_0, ($setup$058advance_world$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)))));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.CommitRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058finish_tx$1261$(_transaction_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_transaction_0, {$: "../../../../src/ecs/transaction.Success"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1267$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058end$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-query.Outgoing") {
    return "Outgoing";
  } else {
    return "Incoming";
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058relation_value$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-query.Missing") {
    return "Missing";
  } else if (_value_0.$ === "../../../../src/ecs/relation-query.Target") {
    const _target_0 = _value_0["handle"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_target_0));
    return ("Target:" + _x_0);
  } else {
    const _targets_0 = _value_0["handles"];
    const _x_1 = ($List$show$12626$(_targets_0));
    return ("Sources:" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1263$(_argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$())))(_owner_0), _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1263$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1263$(_owner_0, _target_0, _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1261$(_source_0, _mode_0) {
  if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.RequiredOut") {
    const _key_0 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_relation$1261$(_key_0, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.OptionalOut") {
    const _key_1 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1261$(_key_1, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.PresentOut") {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_relation$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.AbsentOut") {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_relation$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.RequiredIn") {
    const _key_2 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_related$1261$(_key_2, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.OptionalIn") {
    const _key_3 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1261$(_key_3, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.PresentIn") {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_related$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_related$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_out$1261$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.RequiredOut", "key": _key_0}};
}

function $$$$047ordinary$045category$045v1$047declarations$058declared_link$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1261$(($$$$047ordinary$045category$045v1$047declarations$058link$1261$()));
}

function $consumer$058condition_body$12616$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12637$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_out$1261$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.OptionalOut", "key": _key_0}};
}

function $consumer$058condition_body$12617$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12639$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_out$1261$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.PresentOut"}};
}

function $consumer$058condition_body$12618$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12641$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1261$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.AbsentOut"}};
}

function $consumer$058condition_body$12619$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12643$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_in$1261$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.RequiredIn", "key": _key_0}};
}

function $consumer$058condition_body$12620$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12645$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_in$1261$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.OptionalIn", "key": _key_0}};
}

function $consumer$058condition_body$12621$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12647$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_in$1261$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.PresentIn"}};
}

function $consumer$058condition_body$12622$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12649$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_in$1261$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.AbsentIn"}};
}

function $consumer$058condition_body$12623$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12651$(_owner_0)));
}

function $$$$047ordinary$045category$045v1$047declarations$058declared_parent$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1261$(($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()));
}

function $consumer$058condition_body$12624$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12653$(_owner_0)));
}

function $consumer$058condition_body$12625$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12655$(_owner_0)));
}

function $consumer$058condition_body$12626$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12657$(_owner_0)));
}

function $consumer$058condition_body$12627$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12659$(_owner_0)));
}

function $consumer$058condition_body$12628$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12661$(_owner_0)));
}

function $consumer$058condition_body$12629$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12663$(_owner_0)));
}

function $consumer$058condition_body$12630$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12665$(_owner_0)));
}

function $consumer$058condition_body$12631$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12667$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = ($U32$show$(_ns_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$12622$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_h_0));
    const _x_1 = ($List$show$go$12622$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1262$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_required_out$1260$()))));
}

function $dump$058cleanup$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_1 = ($List$show$12611$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_value_0.$ === "../../../../src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _relation_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_5 = ($List$show$1260$(_children_0));
    const _x_6 = ($List$show$12611$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($dump$058descriptor$1260$(_relation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _value_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $measure$058finish_checked$1260$(_value_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_garden_checked$(_value_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $clock$058end$(_x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$(_x_2, _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _value_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1265$(_args_0, _ctx_0) {
  return $calls$058check_body$1260$(_args_0, _ctx_0);
}

function $consumer$058required$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1262$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1263$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_optional_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1267$(_args_0, _ctx_0) {
  return $calls$058check_body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1263$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1264$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_present_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1269$(_args_0, _ctx_0) {
  return $calls$058check_body$1262$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1262$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1264$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1265$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12611$(_args_0, _ctx_0) {
  return $calls$058check_body$1263$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1263$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1265$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1266$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_required_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12613$(_args_0, _ctx_0) {
  return $calls$058check_body$1264$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1264$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1266$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1267$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_optional_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12615$(_args_0, _ctx_0) {
  return $calls$058check_body$1265$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1265$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1267$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1268$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_present_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12617$(_args_0, _ctx_0) {
  return $calls$058check_body$1266$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1266$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1268$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1269$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12619$(_args_0, _ctx_0) {
  return $calls$058check_body$1267$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1267$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1269$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12610$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_required_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12621$(_args_0, _ctx_0) {
  return $calls$058check_body$1268$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1268$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12610$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12611$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_optional_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12623$(_args_0, _ctx_0) {
  return $calls$058check_body$1269$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$1269$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12611$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12612$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_present_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12625$(_args_0, _ctx_0) {
  return $calls$058check_body$12610$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12610$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12612$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12613$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_out$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12627$(_args_0, _ctx_0) {
  return $calls$058check_body$12611$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12611$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12613$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12614$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_required_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12629$(_args_0, _ctx_0) {
  return $calls$058check_body$12612$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12612$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12614$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12615$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_optional_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12631$(_args_0, _ctx_0) {
  return $calls$058check_body$12613$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12613$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12615$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12616$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_present_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12633$(_args_0, _ctx_0) {
  return $calls$058check_body$12614$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12614$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12616$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$12617$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$12635$(_args_0, _ctx_0) {
  return $calls$058check_body$12615$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058condition$12615$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12617$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1262$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1262$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1262$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1263$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1263$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1263$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Optional"}, "project": true};
}

function $machine$045calls$058frame_events_from_view$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $machine$045calls$058check_rows$1261$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _rows_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($Nat$is_eq$(($List$length$(_rows_0)), 2))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1262$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($machine$045calls$058relation_check_cap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1261$(($machine$045calls$058check_plan$1261$()))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058compared$1261$(_value_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _view_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058is_current$1261$(_view_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058get$1261$(_owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1264$(_owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_current$1261$(_ctx_0) {
  const _world_0 = _ctx_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_projected$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1262$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1262$(_argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$())))(_owner_0), _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1262$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1262$(_owner_0, _target_0, _argument_0);
}

function $machine$045calls$058pending_reader$1261$(_world_0, _state_0, _identified_0, _completion_0) {
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  const _reader_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return $machine$045calls$058pending_completion$1261$(_world_0, {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, _reader_0, _readerId_0, ($machine$045calls$058actual_parent_position$1261$(_positions_0, _readerId_0)), _completion_0);
}

function $machine$045calls$058reader_with_identity$1261$(_reader_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $machine$045calls$058reader_identity_fields$1261$(_keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)));
}

function $machine$045calls$058actual_reader_run_state$1261$(_world_0, _state_0, _reader_0, _readerId_0) {
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run$1261$(($machine$045calls$058collected_runtime$1261$(_world_0, {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0})), _reader_0, {$: "machine-calls.ReaderArgs", "readerId": _readerId_0, "registeredAt": _tick_0});
}

function $machine$045calls$058stream_read_after_end$1261$(_observed_0, _state_0, _reader_0, __0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  return run_clo((_x_0) => {
  return $IO$pure$({$: "machine-calls.StreamRead", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": _reader_0, "instance": _instance_0, "result": _result_0}, _x_0);
});
}

function $machine$045calls$058streams_text$1261$(_value_0) {
  const _flow_0 = _value_0["flow"];
  const _level_0 = _value_0["level"];
  const _parentFailures_0 = _value_0["parentFailures"];
  const _parentLagged_0 = _value_0["parentLagged"];
  const _parentPosition_0 = _value_0["parentPosition"];
  const _x_0 = ($machine$045calls$058position_maybe_text$(_parentPosition_0));
  const _x_1 = ($Bool$show$(_parentLagged_0));
  const _x_2 = (":parentPosition=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$12615$(_parentFailures_0));
  const _x_5 = (":parentLagged=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($machine$045calls$058reading_text$(_level_0));
  const _x_8 = (",parentFailures=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($machine$045calls$058reading_text$(_flow_0));
  const _x_11 = (",level=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  return ("flow=" + _x_12);
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($machine$045calls$058position_text$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $machine$045calls$058reader_registry_text$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1264$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_namespace_0));
  const _x_10 = (":" + _x_8);
  return (_x_9 + _x_10);
}

function $measure$058after_observed_begin$1260$(_operation_0, __0) {
  return $measure$058finish_observed$1260$(_operation_0({$: "Unit"}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058first$1260$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1260$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058initialized$1260$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1260$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1261$(_args_0, {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $machine_result_text$1260$(_result_0) {
  if (_result_0.$ === "Done") {
    const _value_0 = _result_0["value"];
    return $machine_snapshot_text$1260$(_value_0);
  } else {
    return "Fail";
  }
}

function $after_garden_machine_second$(_index_0, _observed_0, _registry_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  return $machine_inspection_capture_next$1260$(_result_0, ($dump$058world$1260$(_world_0)), ($instance_report$1260$(_instance_0)), run_clo((_x_0) => {
  return $continue_garden_machine_second$(_index_0, _x_0, _registry_0);
}));
}

function $setup$058commit_edges$1260$(_factory_0, _first_0, _middle_0, _last_0, _transaction_0) {
  return $setup$058committed$1260$(_factory_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(_transaction_0, {$: "../../../../src/ecs/relation-commands.Original", "event": 31})), {$: "../../../../src/ecs/relation-commands.Original", "event": 32})))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $setup$058state_transition_requests$1261$(_factory_0, _first_0, _middle_0, _last_0, _world_0) {
  return $setup$058initial_requests_committed$1261$(_factory_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1261$(($setup$058initial_state_requests$1261$(($setup$058advance_world$1261$(_world_0)))))));
}

function $setup$058advance_world$1261$(_world_0) {
  return $setup$058advanced_world$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1267$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $List$show$12626$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_h_0));
    const _x_1 = ($List$show$go$12624$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1263$(_observed_0, _argument_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1263$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1263$(_targets_0, _argument_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1263$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$() {
  return {$: "../../../../src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1261$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1263$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1263$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_relation$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_declaration_0) {
  const _value_0 = _declaration_0["descriptor"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_relation$1261$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_relation$1261$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_related$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_related$1261$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_related$1261$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1261$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-failure-reader.Declaration", "descriptor": _descriptor_0};
}

function $consumer$058condition_rows$1261$(_expected_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($Nat$is_eq$(($List$length$(_rows_0)), _expected_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12637$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12616$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12639$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12617$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12641$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12618$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12643$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12619$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12645$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12620$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12647$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12621$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12649$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12622$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12651$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12623$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12653$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12624$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12655$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12625$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12657$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12626$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12659$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12627$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12661$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12628$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12663$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12629$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12665$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12630$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12667$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(($consumer$058condition_plan$12631$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _direction_0 = _value_0["end"];
  const _value_1 = _value_0["value"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058relation_value$1260$(_value_1));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058end$(_direction_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$12622$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_h_0));
    const _x_1 = ($List$show$go$12622$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(_argument_0) {
  return {$: "../../../../src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1261$(_argument_0, _x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1261$(_x_1, _x_2, _argument_0);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(_declaration_0) {
  const _source_0 = _declaration_0["source"];
  const _mode_0 = _declaration_0["mode"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1260$(_source_0, _mode_0);
}

function $consumer$058link_required_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_out$1260$("link_required_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $clock$058force_garden_checked$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_garden_checked"].run, need: $0eff["clock.force_garden_checked"].need, args: [$0m52(_value_0)], kont: ((f) => (x) => (f($0m53(x))))(_k_0) };
}
function $calls$058check_body$1260$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1260$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1262$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_required_out$1260$()))));
}

function $consumer$058link_optional_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_out$1260$("link_optional_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1261$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1261$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1263$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_optional_out$1260$()))));
}

function $consumer$058link_present_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_out$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1262$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1262$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1264$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_present_out$1260$()))));
}

function $consumer$058link_absent_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1263$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1263$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1265$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_out$1260$()))));
}

function $consumer$058link_required_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_in$1260$("link_required_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1264$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1264$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1266$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_required_in$1260$()))));
}

function $consumer$058link_optional_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_in$1260$("link_optional_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1265$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1265$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1267$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_optional_in$1260$()))));
}

function $consumer$058link_present_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_in$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1266$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1266$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1268$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_present_in$1260$()))));
}

function $consumer$058link_absent_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_in$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$()));
}

function $calls$058check_body$1267$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1267$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1269$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_in$1260$()))));
}

function $consumer$058parent_required_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_out$1260$("parent_required_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$1268$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1268$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12610$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_required_out$1260$()))));
}

function $consumer$058parent_optional_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_out$1260$("parent_optional_out", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$1269$(_expected_0, _owner_0) {
  return $consumer$058condition_body$1269$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12611$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_optional_out$1260$()))));
}

function $consumer$058parent_present_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_out$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$12610$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12610$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12612$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_present_out$1260$()))));
}

function $consumer$058parent_absent_out$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$12611$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12611$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12613$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_out$1260$()))));
}

function $consumer$058parent_required_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_in$1260$("parent_required_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$12612$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12612$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12614$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_required_in$1260$()))));
}

function $consumer$058parent_optional_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_in$1260$("parent_optional_in", ($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$12613$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12613$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12615$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_optional_in$1260$()))));
}

function $consumer$058parent_present_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_in$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$12614$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12614$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12616$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_present_in$1260$()))));
}

function $consumer$058parent_absent_in$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_in$1260$(($$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$()));
}

function $calls$058check_body$12615$(_expected_0, _owner_0) {
  return $consumer$058condition_body$12615$(_expected_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$12617$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_in$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1262$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1262$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1263$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1263$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1263$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1263$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($state$058level$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $Nat$is_eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(cmp_new(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1262$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $machine$045calls$058relation_check_cap$1261$(_caps_0) {
  const _relations_0 = _caps_0["second"];
  return _relations_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058is_current$1261$(_view_0, _value_0) {
  if (_view_0.$ === "../../../../src/ecs/machine.Unavailable") {
    return false;
  } else {
    const _current_0 = _view_0["value"];
    return (_current_0 === _value_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1264$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1264$(($machine$045calls$058flow_check_cap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1261$(($machine$045calls$058check_plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_projected$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1262$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1262$(_observed_0, _argument_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1262$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1262$(_targets_0, _argument_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1262$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$() {
  return {$: "../../../../src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1261$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1262$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1262$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$())))(_owner_0)(_target_0));
}

function $machine$045calls$058pending_completion$1261$(_world_0, _state_0, _reader_0, _readerId_0, _position_0, _completion_0) {
  if (_completion_0.$ === "../../../../src/ecs/relation-failure-runtime.Succeeded") {
    const _output_0 = _completion_0["output"];
    return {$: "machine-calls.PendingRead", "observed": {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Fresh"}, "result": {$: "Done", "value": ($machine$045calls$058streams_position$1261$(_output_0, _position_0))}}, "state": _state_0, "reader": _reader_0};
  } else if (_completion_0.$ === "../../../../src/ecs/relation-failure-runtime.Failed") {
    const _error_0 = _completion_0["error"];
    return {$: "machine-calls.PendingRead", "observed": {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Fresh"}, "result": {$: "Fail", "error": _error_0}}, "state": _state_0, "reader": _reader_0};
  } else {
    return {$: "machine-calls.PendingRead", "observed": {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Fresh"}, "result": {$: "Fail", "error": {$: "Unit"}}}, "state": _state_0, "reader": _reader_0};
  }
}

function $machine$045calls$058actual_parent_position$1261$(_positions_0, _readerId_0) {
  return $machine$045calls$058actual_parent_position_from$(_positions_0, _readerId_0);
}

function $machine$045calls$058reader_identity_fields$1261$(_keys_0, _identified_0) {
  const _registry_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "snd": _readerId_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run$1261$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_identified$1261$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _keys_0, _args_0);
}

function $machine$045calls$058collected_runtime$1261$(_world_0, _state_0) {
  return $machine$045calls$058collected_runtime_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world$1261$(run_clo((_x_0) => {
  return $machine$045calls$058identity_world$1261$(_x_0);
}), ($machine$045calls$058state_runtime$1261$(_world_0, _state_0)))));
}

function $machine$045calls$058reading_text$(_value_0) {
  const _values_0 = _value_0["values"];
  const _lagged_0 = _value_0["lagged"];
  const _x_0 = ($Bool$show$(_lagged_0));
  const _x_1 = ($List$show$1266$(_values_0));
  const _x_2 = (":lagged=" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058failure$1261$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $machine$045calls$058position_maybe_text$(_position_0) {
  if (_position_0.$ === "None") {
    return "none";
  } else {
    const _found_0 = _position_0["value"];
    return $machine$045calls$058position_text$(_found_0);
  }
}

function $machine$045calls$058position_text$(_position_0) {
  const _id_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registeredAt_0 = _position_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registeredAt_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($machine$045calls$058position_text$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $measure$058finish_observed$1260$(_value_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_garden_snapshot$(_value_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$((_x_4) => $clock$058end$(_x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$(_x_2, _x_6);
});
}), _x_3);
});
}), _x_0);
});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058invoked$1260$(_cursor_0, _registeredAt_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1260$(_cursor_0, _registeredAt_0, _frame_0, _result_1);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1261$(_args_0, _ctx_0) {
  return $machine$045calls$058snapshot_body$1260$(_args_0, _ctx_0);
}

function $machine_snapshot_text$1260$(_value_0) {
  const _flow_0 = _value_0["flow"];
  const _level_0 = _value_0["level"];
  const _rows_0 = _value_0["rows"];
  const _events_0 = _value_0["events"];
  const _x_0 = ($List$show$1269$(_events_0));
  const _x_1 = ($Nat$show$(($List$length$(_rows_0))));
  const _x_2 = (",events=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($current_text$1261$(_level_0));
  const _x_5 = (",rows=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($current_text$1260$(_flow_0));
  const _x_8 = (",level=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("flow=" + _x_9);
}

function $continue_garden_machine_second$(_index_0, _report_0, _registry_0) {
  const _world_0 = _report_0["world"];
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058check_machine$1260$(((_index_0 + 2) >>> 0), _world_0)), run_clo((_x_1) => {
  return $after_garden_machine_check$(_index_0, _x_1, _registry_0);
}), _x_0);
});
}

function $setup$058committed$1260$(_factory_0, _first_0, _middle_0, _last_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    return $setup$058state_transition_requests$1260$(_factory_0, _first_0, _middle_0, _last_0, ($setup$058advance_world$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.CommitRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058finish_tx$1260$(_transaction_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_transaction_0, {$: "../../../../src/ecs/transaction.Success"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1265$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $setup$058initial_requests_committed$1261$(_factory_0, _first_0, _middle_0, _last_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    const _world3_0 = ($setup$058advance_world$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0))));
    return $setup$058reader_registered_transitions$1261$(_factory_0, _first_0, _middle_0, _last_0, ($machine$045calls$058register_reader$1261$(_world3_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.MachineCommitRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058initial_state_requests$1261$(_world_0) {
  const _flow_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "../../../../src/ecs/machine.Set", "value": 7, "skipSame": false}));
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1263$(_flow_0, {$: "../../../../src/ecs/machine.Set", "value": 11, "skipSame": false});
}

function $setup$058advanced_world$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($setup$058enqueue_tx$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($setup$058publish_tx$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $List$show$go$12624$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_h_0));
    const _x_1 = ($List$show$go$12624$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1263$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1263$(_targets_0, _argument_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1263$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1263$(_rest_0, _argument_0, _x_0, _x_1);
});
}), _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1263$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1263$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1263$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1263$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1263$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1263$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1263$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058relation_value$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-query.Missing") {
    return "Missing";
  } else if (_value_0.$ === "../../../../src/ecs/relation-query.Target") {
    const _target_0 = _value_0["handle"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_target_0));
    return ("Target:" + _x_0);
  } else {
    const _targets_0 = _value_0["handles"];
    const _x_1 = ($List$show$12623$(_targets_0));
    return ("Sources:" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1261$(_argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0), _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1261$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1261$(_owner_0, _target_0, _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1260$(_source_0, _mode_0) {
  if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.RequiredOut") {
    const _key_0 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_relation$1260$(_key_0, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.OptionalOut") {
    const _key_1 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1260$(_key_1, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.PresentOut") {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_relation$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.AbsentOut") {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_relation$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.RequiredIn") {
    const _key_2 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_related$1260$(_key_2, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.OptionalIn") {
    const _key_3 = _mode_0["key"];
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1260$(_key_3, ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../src/ecs/ordinary-inspector-relation.PresentIn") {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_related$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else {
    return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_related$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_out$1260$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.RequiredOut", "key": _key_0}};
}

function $$$$047ordinary$045category$045v1$047declarations$058declared_link$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($$$$047ordinary$045category$045v1$047declarations$058link$1260$()));
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058condition_body$1260$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1265$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(_argument_0) {
  return {$: "../../../../src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1260$(_argument_0, _x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1260$(_x_1, _x_2, _argument_0);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_out$1260$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.OptionalOut", "key": _key_0}};
}

function $consumer$058condition_body$1261$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1267$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_out$1260$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.PresentOut"}};
}

function $consumer$058condition_body$1262$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1269$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1260$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.AbsentOut"}};
}

function $consumer$058condition_body$1263$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12611$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058required_in$1260$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.RequiredIn", "key": _key_0}};
}

function $consumer$058condition_body$1264$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12613$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058optional_in$1260$(_key_0, _declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.OptionalIn", "key": _key_0}};
}

function $consumer$058condition_body$1265$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12615$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058present_in$1260$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.PresentIn"}};
}

function $consumer$058condition_body$1266$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12617$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058absent_in$1260$(_declaration_0) {
  return {$: "../../../../src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../src/ecs/ordinary-inspector-relation.AbsentIn"}};
}

function $consumer$058condition_body$1267$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12619$(_owner_0)));
}

function $$$$047ordinary$045category$045v1$047declarations$058declared_parent$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()));
}

function $consumer$058condition_body$1268$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12621$(_owner_0)));
}

function $consumer$058condition_body$1269$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12623$(_owner_0)));
}

function $consumer$058condition_body$12610$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12625$(_owner_0)));
}

function $consumer$058condition_body$12611$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12627$(_owner_0)));
}

function $consumer$058condition_body$12612$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12629$(_owner_0)));
}

function $consumer$058condition_body$12613$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12631$(_owner_0)));
}

function $consumer$058condition_body$12614$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12633$(_owner_0)));
}

function $consumer$058condition_body$12615$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12635$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1262$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1263$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1263$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $state$058level$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": _level_0};
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1264$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058flow_check_cap$1261$(_caps_0) {
  const _flow_0 = _caps_0["first"];
  return _flow_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1262$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1262$(_targets_0, _argument_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1262$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1262$(_rest_0, _argument_0, _x_0, _x_1);
});
}), _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1262$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1262$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1262$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1262$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1262$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1262$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $machine$045calls$058streams_position$1261$(_streams_0, _position_0) {
  const _flow_0 = _streams_0["flow"];
  const _level_0 = _streams_0["level"];
  const _parentFailures_0 = _streams_0["parentFailures"];
  const _parentLagged_0 = _streams_0["parentLagged"];
  return {$: "machine-types.Streams", "flow": _flow_0, "level": _level_0, "parentFailures": _parentFailures_0, "parentLagged": _parentLagged_0, "parentPosition": _position_0};
}

function $machine$045calls$058actual_parent_position_from$(_positions_0, _readerId_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _positions_0["head"];
    const _id_0 = _t_0["id"];
    const __0 = _t_0["cursor"];
    const __1 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $machine$045calls$058parent_position_choose$((_id_0 === _readerId_0), {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": __0, "registeredAt": __1}, ($machine$045calls$058actual_parent_position_from$(_rest_0, _readerId_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_identified$1261$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)), {$: "../../../../src/ecs/relation-failure-runtime.Input", "readings": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1261$(_keys_0, _domains_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $machine$045calls$058collected_runtime_result$1261$(_result_0) {
  const _runtime_0 = _result_0["fst"];
  return _runtime_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_result$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058effect_clocked$1261$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $machine$045calls$058identity_world$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Unit"}};
}

function $machine$045calls$058state_runtime$1261$(_world_0, _state_0) {
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($machine$045calls$058transition_text$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$go$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058failure$1261$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $clock$058force_garden_snapshot$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_garden_snapshot"].run, need: $0eff["clock.force_garden_snapshot"].need, args: [$0m54(_value_0)], kont: ((f) => (x) => (f($0m55(x))))(_k_0) };
}
function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058finished$1260$(_cursor_0, _registeredAt_0, _frame_0, _result_0) {
  const _world_0 = _frame_0["world"];
  if (_result_0.$ === "Fail") {
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1260$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $machine$045calls$058snapshot_body$1260$(__0, _owner_0) {
  return $machine$045calls$058snapshot_body_observed$1260$(($machine$045calls$058flow_snapshot$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1263$(_owner_0)))));
}

function $current_text$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Unavailable") {
    return "unavailable";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $current_text$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Unavailable") {
    return "unavailable";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $machine$045calls$058check_machine$1260$(_index_0, _world_0) {
  return $measure$058run_checked$1260$(_index_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1260$({$: "Unit"}, _world_0);
}));
}

function $after_garden_machine_check$(_index_0, _observed_0, _registry_0) {
  const _world_0 = _observed_0["world"];
  const _result_0 = _observed_0["result"];
  return $machine_checked_capture_next$1260$(_result_0, ($dump$058world$1260$(_world_0)), run_clo((_x_0) => {
  return $continue_garden_machine_check$(_index_0, _x_0, _registry_0);
}));
}

function $setup$058state_transition_requests$1260$(_factory_0, _first_0, _middle_0, _last_0, _world_0) {
  return $setup$058initial_requests_committed$1260$(_factory_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1260$(($setup$058initial_state_requests$1260$(($setup$058advance_world$1260$(_world_0)))))));
}

function $setup$058advance_world$1260$(_world_0) {
  return $setup$058advanced_world$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1265$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $setup$058reader_registered_transitions$1261$(_factory_0, _first_0, _middle_0, _last_0, _result_0) {
  if (_result_0.$ === "machine-calls.StreamReaderRegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderRegistrationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $setup$058reader_registered_world$1261$(_factory_0, _first_0, _middle_0, _last_0, _world_1, ($machine$045calls$058identify_reader$1261$(_registry_0)));
  }
}

function $machine$045calls$058register_reader$1261$(_world_0) {
  return $machine$045calls$058registered_context$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1261$(_world_0)), {$: "Con", "head": ($machine$045calls$058parent_key$1261$()), "tail": {$: "Nil"}}, "MachineStreamReader", {$: "Con", "head": "FlowStream", "tail": {$: "Con", "head": "LevelStream", "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058access$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1261$(($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()))))), "tail": {$: "Nil"}}}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1262$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1262$({$: "../../../../src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(($setup$058flow_decl$1261$())))}, _frame_0, _input_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1263$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1263$({$: "../../../../src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1263$(($setup$058level_decl$1261$())))}, _frame_0, _input_0);
}

function $setup$058enqueue_tx$1261$(_world_0, _commands_0) {
  return $setup$058enqueue_all$1261$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $setup$058publish_tx$1261$(_world_0, _events_0) {
  return $setup$058publish_all$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1263$(_target_0, _rows_0, _continue_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1263$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1263$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1263$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1263$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1261$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1263$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1263$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1263$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1263$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1263$(_target_0, _argument_0, _owner_0)));
  }
}

function $List$show$12623$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_h_0));
    const _x_1 = ($List$show$go$12621$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1261$(_observed_0, _argument_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1261$(_targets_0, _argument_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$() {
  return {$: "../../../../src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1261$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1261$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_relation$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_declaration_0) {
  const _value_0 = _declaration_0["descriptor"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_relation$1260$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_relation$1260$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058read_related$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058with_related$1260$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058without_related$1260$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(_descriptor_0) {
  return {$: "../../../../src/ecs/relation-failure-reader.Declaration", "descriptor": _descriptor_0};
}

function $consumer$058condition_rows$1260$(_expected_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($Nat$is_eq$(($List$length$(_rows_0)), _expected_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1265$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1260$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_enumerate$1260$(_argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$())))(_owner_0), _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup$1260$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1260$(_owner_0, _target_0, _argument_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1267$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1261$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1269$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1262$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12611$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1263$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12613$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1264$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12615$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1265$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12617$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1266$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12619$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1267$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12621$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1268$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12623$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$1269$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12625$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$12610$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12627$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$12611$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12629$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$12612$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12631$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$12613$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12633$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$12614$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$12635$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(($consumer$058condition_plan$12615$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1262$(_target_0, _rows_0, _continue_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1262$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1262$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1262$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1262$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1262$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1262$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1262$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1262$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1262$(_target_0, _argument_0, _owner_0)));
  }
}

function $machine$045calls$058parent_position_choose$(_found_0, _position_0, _fallback_0) {
  if (_found_0) {
    return {$: "Some", "value": _position_0};
  } else {
    return _fallback_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "../../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../src/ecs/relation-failure-runtime.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058outcome$1261$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1261$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _input_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1261$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1261$(_domains_0, _key_0, _position_0)), "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1261$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_result$1261$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058effect_clocked$1261$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $machine$045calls$058transition_text$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($U32$show$(_to_0));
  const _x_1 = ($U32$show$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($machine$045calls$058transition_text$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058succeeded$1260$(_registeredAt_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $machine$045calls$058snapshot_body_observed$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _snapshot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": _snapshot_0}};
}

function $machine$045calls$058flow_snapshot$1260$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _flow_0 = _observed_0["snd"];
  return $machine$045calls$058level_snapshot$1260$(_flow_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1262$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1263$(($machine$045calls$058flow_cap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1260$(($machine$045calls$058snapshot_plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058run$1260$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1260$(_args_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1260$(($machine$045calls$058check_plan$1260$())))(_world_0));
}

function $machine_checked_capture_next$1260$(_result_0, _worldDump_0, _next_0) {
  const _world_0 = _worldDump_0["fst"];
  const _worldText_0 = _worldDump_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($checked_text$(_result_0));
  const _x_2 = (":" + _worldText_0);
  const _x_3 = (_x_1 + _x_2);
  return $IO$bind$((_x_4) => $clock$058capture$(("machine-check:" + _x_3), _x_4), run_clo((_x_5) => {
  return run_tail(_next_0, _world_0);
}), _x_0);
});
}

function $continue_garden_machine_check$(_index_0, _world_0, _registry_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($machine$045calls$058read_streams$1260$(((_index_0 + 3) >>> 0), _registry_0, _world_0)), run_clo((_x_1) => {
  return $after_garden_machine_streams$(_x_1);
}), _x_0);
});
}

function $setup$058initial_requests_committed$1260$(_factory_0, _first_0, _middle_0, _last_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    const _world3_0 = ($setup$058advance_world$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0))));
    return $setup$058reader_registered_transitions$1260$(_factory_0, _first_0, _middle_0, _last_0, ($machine$045calls$058register_reader$1260$(_world3_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.MachineCommitRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058initial_state_requests$1260$(_world_0) {
  const _flow_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), {$: "../../../../src/ecs/machine.Set", "value": 7, "skipSame": false}));
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_flow_0, {$: "../../../../src/ecs/machine.Set", "value": 11, "skipSame": false});
}

function $setup$058advanced_world$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($setup$058enqueue_tx$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($setup$058publish_tx$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $setup$058reader_registered_world$1261$(_factory_0, _first_0, _middle_0, _last_0, _world_0, _identified_0) {
  const _registry_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return $setup$058reject_cycle$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058apply_transitions$1261$(($setup$058activate_registered_reader$1261$(_readerId_0, _world_0)))));
}

function $machine$045calls$058identify_reader$1261$(_registry_0) {
  const _state_0 = _registry_0["state"];
  const _reader_0 = _registry_0["reader"];
  const _readerId_0 = _registry_0["readerId"];
  return {$: "Tuple", "fst": {$: "machine-calls.ReaderContext", "state": _state_0, "reader": _reader_0, "readerId": _readerId_0}, "snd": _readerId_0};
}

function $machine$045calls$058registered_context$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/relation-failure-runtime.RegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "machine-calls.StreamReaderRegistrationFailed", "world": ($machine$045calls$058runtime_world$1261$(_runtime_0))};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    return $machine$045calls$058registered_context_success$1261$(_runtime_1, _reader_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register$1261$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058registered_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $machine$045calls$058parent_key$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058key$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1261$(($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058access$1261$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _name_0 = _t_0["name"];
  return $String$concat$({$: "Con", "head": _name_0, "tail": {$: "Con", "head": ":read", "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1262$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1262$(_tx_0, _request_0);
}

function $setup$058flow_decl$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1261$("Flow", {$: "Con", "head": 4, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}}}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1263$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1263$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1263$(_declaration_0) {
  if (_declaration_0.$ === "../../../../src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $setup$058level_decl$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1263$("Level", {$: "Con", "head": 10, "tail": {$: "Con", "head": 11, "tail": {$: "Con", "head": 12, "tail": {$: "Nil"}}}});
}

function $setup$058enqueue_all$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $setup$058publish_all$1261$(_world_0, _notices_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _notices_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1263$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1263$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1263$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1263$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matches_runtime$1261$(_argument_0, _owner_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1263$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1263$() {
  return {$: "../../../../src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1263$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1263$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1261$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1261$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1261$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1263$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1263$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $List$show$go$12621$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_h_0));
    const _x_1 = ($List$show$go$12621$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1261$(_targets_0, _argument_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1261$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1261$(_rest_0, _argument_0, _x_0, _x_1);
});
}), _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1261$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1261$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1261$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1261$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1262$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scanned$1260$(_observed_0, _argument_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1260$(_targets_0, _argument_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$() {
  return {$: "../../../../src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_target$1260$(_owner_0, _target_0, _argument_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1260$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1262$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1262$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1262$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1262$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matches_runtime$1261$(_argument_0, _owner_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1262$() {
  return {$: "../../../../src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1262$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1262$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1262$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1262$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058outcome$1261$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1261$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1261$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_clocked$1261$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_collected$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1261$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $machine$045calls$058level_snapshot$1260$(_flow_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _level_0 = _observed_0["snd"];
  return $machine$045calls$058rows_snapshot$1260$(_flow_0, _level_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1262$(($machine$045calls$058level_cap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1260$(($machine$045calls$058snapshot_plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058flow_cap$1260$(_caps_0) {
  const _flow_0 = _caps_0["first"];
  return _flow_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $machine$045calls$058snapshot_plan$1260$() {
  return {$: "../../../../src/ecs/inspector.Plan", "caps": ($machine$045calls$058snapshot_caps$1260$())};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058ready$1260$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../../../../src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058required_field$1260$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $machine$045calls$058check_plan$1260$() {
  return {$: "../../../../src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058required$1260$(_x_0);
}), "caps": ($machine$045calls$058check_caps$1260$())};
}

function $machine$045calls$058read_streams$1260$(_index_0, _registry_0, _world_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058begin$(_index_0, _x_1), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_started$1260$(_index_0, _registry_0, _world_0, _x_2);
}), _x_0);
});
}

function $after_garden_machine_streams$(_observed_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058capture$(($machine$045calls$058stream_read_text$1260$(_observed_0)), _x_1), run_clo((_x_2) => {
  return (_x_3) => $clock$058finish$(_x_3);
}), _x_0);
});
}

function $setup$058reader_registered_transitions$1260$(_factory_0, _first_0, _middle_0, _last_0, _result_0) {
  if (_result_0.$ === "machine-calls.StreamReaderRegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderRegistrationRefused", "factory": _factory_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $setup$058reader_registered_world$1260$(_factory_0, _first_0, _middle_0, _last_0, _world_1, ($machine$045calls$058identify_reader$1260$(_registry_0)));
  }
}

function $machine$045calls$058register_reader$1260$(_world_0) {
  return $machine$045calls$058registered_context$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0)), {$: "Con", "head": ($machine$045calls$058parent_key$1260$()), "tail": {$: "Nil"}}, "MachineStreamReader", {$: "Con", "head": "FlowStream", "tail": {$: "Con", "head": "LevelStream", "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058access$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()))))), "tail": {$: "Nil"}}}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1260$({$: "../../../../src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($setup$058flow_decl$1260$())))}, _frame_0, _input_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1261$({$: "../../../../src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1262$(($setup$058level_decl$1260$())))}, _frame_0, _input_0);
}

function $setup$058enqueue_tx$1260$(_world_0, _commands_0) {
  return $setup$058enqueue_all$1260$(_commands_0, _world_0);
}

function $setup$058publish_tx$1260$(_world_0, _events_0) {
  return $setup$058publish_all$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $setup$058reject_cycle$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _world_0) {
  return $setup$058cycle_queued$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($$$$047ordinary$045category$045v1$047declarations$058parent$1261$()), _middle_0, _last_0)));
}

function $setup$058apply_transitions$1261$(_world_0) {
  return $setup$058with_resources$1261$(run_clo((_x_0) => {
  return $setup$058apply_level$1261$(($setup$058apply_flow$1261$(_x_0)));
}), _world_0);
}

function $setup$058activate_registered_reader$1261$(_readerId_0, _world_0) {
  return $setup$058activate_at_clock$1261$(_readerId_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $machine$045calls$058runtime_world$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  return _world_0;
}

function $machine$045calls$058registered_context_success$1261$(_runtime_0, _reader_0) {
  return $machine$045calls$058registered_context_join$1261$(($machine$045calls$058runtime_fields$1261$(_runtime_0)), ($machine$045calls$058reader_with_identity$1261$(_reader_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058registered_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../src/ecs/relation-failure-runtime.RegistrationFailed", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../src/ecs/relation-failure-runtime.Registered", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1261$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058key$1261$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _id_0 = _t_0["key"];
  return {$: "../../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0};
}

function $String$concat$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($String$concat$(_t_0));
    return (_h_0 + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1262$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1262$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1262$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1263$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1263$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1263$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1263$(_name_0, _values_0) {
  return {$: "../../../../src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1263$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1263$(_left_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058project_runtime$1261$(_argument_0, _owner_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matches_runtime$1261$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matched_runtime$1261$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1263$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1263$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1261$(_target_0, _rows_0, _continue_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1261$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1261$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1261$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1261$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1261$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1261$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1260$(_targets_0, _argument_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1260$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan$1260$(_rest_0, _argument_0, _x_0, _x_1);
});
}), _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1260$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_valid$1260$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1260$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1260$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1262$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1262$(_left_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058project_runtime$1261$(_argument_0, _owner_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matches_runtime$1261$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matched_runtime$1261$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1262$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1262$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1261$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _error_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1261$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), "tick": _clock_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../src/ecs/relation-failure-runtime.Failed", "error": _error_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1261$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1261$(_world_0, _clock_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1261$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), _id_0, _clock_0, false)), _clock_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1261$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1261$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1261$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_collected$1261$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1261$(_world_0, _tick_0, _domains_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _tick_0, _domains_0);
}

function $machine$045calls$058rows_snapshot$1260$(_flow_0, _level_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _rows_0 = _observed_0["snd"];
  return $machine$045calls$058rows_snapshot_event$1260$(_flow_0, _level_0, _rows_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1261$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($machine$045calls$058relation_cap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1260$(($machine$045calls$058snapshot_plan$1260$()))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058level_cap$1260$(_caps_0) {
  const _t_0 = _caps_0["second"];
  const _level_0 = _t_0["first"];
  return _level_0;
}

function $machine$045calls$058snapshot_caps$1260$() {
  return {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1260$()), "second": {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1261$()), "second": {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1260$()), "second": ($machine$045calls$058frame_event_cap$1260$())}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $machine$045calls$058check_body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058required$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058availability$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($machine$045calls$058flow_decl$1260$()))), ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0)));
}

function $machine$045calls$058check_caps$1260$() {
  return {$: "../../../../src/ecs/capabilities.Bundle", "first": ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058condition$1260$()), "second": ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1260$())};
}

function $machine$045calls$058stream_read_started$1260$(_index_0, _context_0, _world_0, __0) {
  return run_clo((_x_0) => {
  return $IO$bind$(run_clo((_x_1) => {
  return $IO$pure$(($machine$045calls$058observed_run_result$1260$(($machine$045calls$058actual_reader_run$1260$(_world_0, _context_0)))), _x_1);
}), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_forced$1260$(_x_2);
}), _x_0);
});
}

function $machine$045calls$058stream_read_text$1260$(_read_0) {
  const _runtime_0 = _read_0["runtime"];
  const _reader_0 = _read_0["reader"];
  const _instance_0 = _read_0["instance"];
  const _result_0 = _read_0["result"];
  return $machine$045calls$058stream_read_runtime_text$1260$(_runtime_0, _reader_0, _instance_0, _result_0);
}

function $clock$058finish$(_k_0) {
  return { $: "$FFI", run: $0eff["clock.finish"].run, need: $0eff["clock.finish"].need, args: [], kont: (_k_0) };
}
function $setup$058reader_registered_world$1260$(_factory_0, _first_0, _middle_0, _last_0, _world_0, _identified_0) {
  const _registry_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return $setup$058reject_cycle$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058apply_transitions$1260$(($setup$058activate_registered_reader$1260$(_readerId_0, _world_0)))));
}

function $machine$045calls$058identify_reader$1260$(_registry_0) {
  const _state_0 = _registry_0["state"];
  const _reader_0 = _registry_0["reader"];
  const _readerId_0 = _registry_0["readerId"];
  return {$: "Tuple", "fst": {$: "machine-calls.ReaderContext", "state": _state_0, "reader": _reader_0, "readerId": _readerId_0}, "snd": _readerId_0};
}

function $machine$045calls$058registered_context$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/relation-failure-runtime.RegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "machine-calls.StreamReaderRegistrationFailed", "world": ($machine$045calls$058runtime_world$1260$(_runtime_0))};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    return $machine$045calls$058registered_context_success$1260$(_runtime_1, _reader_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058registered_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $machine$045calls$058parent_key$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058key$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058access$1260$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _name_0 = _t_0["name"];
  return $String$concat$({$: "Con", "head": _name_0, "tail": {$: "Con", "head": ":read", "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1260$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1260$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(_declaration_0) {
  if (_declaration_0.$ === "../../../../src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $setup$058flow_decl$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$("Flow", {$: "Con", "head": 4, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}}}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next_declared$1261$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1261$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058name$1262$(_declaration_0) {
  if (_declaration_0.$ === "../../../../src/ecs/ordinary-machine-declaration.Declaration") {
    const _name_0 = _declaration_0["name"];
    return _name_0;
  } else {
    const _name_1 = _declaration_0["name"];
    return _name_1;
  }
}

function $setup$058level_decl$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1262$("Level", {$: "Con", "head": 10, "tail": {$: "Con", "head": 11, "tail": {$: "Con", "head": 12, "tail": {$: "Nil"}}}});
}

function $setup$058enqueue_all$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $setup$058publish_all$1260$(_world_0, _notices_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _notices_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $setup$058cycle_queued$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058cycle_committed$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1261$(_transaction_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderRelationQueueRefused", "factory": _factory_0, "registry": _registry_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 5}};
  }
}

function $setup$058with_resources$1261$(_change_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _change_0(_resource_0), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $setup$058apply_level$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $setup$058level_applied$1261$(_owned_0, _siblingOwned_0, _flow_0, _ran_0, _flowStream_0, _levelStream_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1262$(_level_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1262$(_level_0)))));
}

function $setup$058apply_flow$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $setup$058flow_applied$1261$(_owned_0, _siblingOwned_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1263$(_flow_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1263$(_flow_0)))));
}

function $setup$058activate_at_clock$1261$(_readerId_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $setup$058activate_world_readers$1261$(_readerId_0, _tick_0, _world_0);
}

function $machine$045calls$058registered_context_join$1261$(_split_0, _identified_0) {
  const _world_0 = _split_0["fst"];
  const _state_0 = _split_0["snd"];
  return $machine$045calls$058registered_context_parts$1261$(_world_0, _state_0, _identified_0);
}

function $machine$045calls$058runtime_fields$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1262$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1262$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1262$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1262$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1263$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1263$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1263$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1263$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1263$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058project_runtime$1261$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058projected_runtime$1261$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matched_runtime$1261$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058accepted$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1261$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058graph_read$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1261$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1261$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1261$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1261$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matches_runtime$1260$(_argument_0, _owner_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1261$() {
  return {$: "../../../../src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1261$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1261$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_matched$1260$(_target_0, _rows_0, _continue_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1260$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1260$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_matches_target$1260$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1260$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_lookup_selected$1260$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1260$(_target_0, _argument_0, _owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1262$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058project_runtime$1261$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058projected_runtime$1261$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matched_runtime$1261$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058accepted$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1261$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph_joined$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058graph_read$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1261$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1261$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1261$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../src/ecs/relation-failure-runtime.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1261$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _key_0, "values": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1261$({$: "../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1261$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1261$(_items_0, {$: "../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $machine$045calls$058rows_snapshot_event$1260$(_flow_0, _level_0, _rows_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "machine-types.Snapshot", "flow": _flow_0, "level": _level_0, "rows": _rows_0, "events": _events_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(($machine$045calls$058event_cap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$058plan_caps$1260$(($machine$045calls$058snapshot_plan$1260$()))))))), _ctx_0);
}

function $machine$045calls$058relation_cap$1260$(_caps_0) {
  const _t_0 = _caps_0["second"];
  const _t_1 = _t_0["second"];
  const _relations_0 = _t_1["first"];
  return _relations_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1260$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058inspect$1261$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1261$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058grant$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1261$(($machine$045calls$058relation_spec$1260$()));
}

function $machine$045calls$058frame_event_cap$1260$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $machine$045calls$058frame_events$1260$(_x_0);
})};
}

function $machine$045calls$058check_body$1260$(__0, _owner_0) {
  return $machine$045calls$058check_query$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058matches$1260$(_owner_0, 7)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058availability$1260$(_name_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  }
}

function $machine$045calls$058flow_decl$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$("Flow", {$: "Con", "head": 4, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}}}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($state$058flow$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058condition$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_provide$1260$();
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058grant$1260$() {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed_runtime$1260$(($machine$045calls$058relation_spec$1260$()));
}

function $machine$045calls$058observed_run_result$1260$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _completion_0 = _result_0["completion"];
  return $machine$045calls$058pending_runtime$1260$(_runtime_0, _reader_0, _completion_0);
}

function $machine$045calls$058actual_reader_run$1260$(_world_0, _context_0) {
  const _state_0 = _context_0["state"];
  const _reader_0 = _context_0["reader"];
  const _readerId_0 = _context_0["readerId"];
  return $machine$045calls$058actual_reader_run_context$1260$(_world_0, _state_0, _reader_0, _readerId_0);
}

function $machine$045calls$058stream_read_forced$1260$(_pending_0) {
  const _observed_0 = _pending_0["observed"];
  const _state_0 = _pending_0["state"];
  const _reader_0 = _pending_0["reader"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058force_garden_streams$(_observed_0, _x_1), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_finish$1260$(_x_2, _state_0, _reader_0);
}), _x_0);
});
}

function $machine$045calls$058stream_read_runtime_text$1260$(_runtime_0, _reader_0, _instance_0, _result_0) {
  const _world_0 = _runtime_0["world"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _x_0 = ($machine$045calls$058world_dump_text$1260$(($dump$058world$1260$(_world_0))));
  const _x_1 = ($machine$045calls$058actual_reader_text$1260$(_reader_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($machine$045calls$058runtime_positions_text$(_positions_0));
  const _x_5 = (":reader=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_capacity_0));
  const _x_8 = (":positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_boundary_0));
  const _x_11 = (":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($Nat$show$(_frameStart_0));
  const _x_14 = (":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($Nat$show$(_tick_0));
  const _x_17 = (":" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($machine$045calls$058stream_result_text$1260$(_result_0));
  const _x_20 = (":runtime=" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($machine$045calls$058stream_instance_text$1260$(_instance_0));
  const _x_23 = (":" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  return ("stream-read:" + _x_24);
}

function $setup$058reject_cycle$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _world_0) {
  return $setup$058cycle_queued$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), ($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()), _middle_0, _last_0)));
}

function $setup$058apply_transitions$1260$(_world_0) {
  return $setup$058with_resources$1260$(run_clo((_x_0) => {
  return $setup$058apply_level$1260$(($setup$058apply_flow$1260$(_x_0)));
}), _world_0);
}

function $setup$058activate_registered_reader$1260$(_readerId_0, _world_0) {
  return $setup$058activate_at_clock$1260$(_readerId_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $machine$045calls$058runtime_world$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  return _world_0;
}

function $machine$045calls$058registered_context_success$1260$(_runtime_0, _reader_0) {
  return $machine$045calls$058registered_context_join$1260$(($machine$045calls$058runtime_fields$1260$(_runtime_0)), ($machine$045calls$058reader_with_identity$1260$(_reader_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058registered_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../src/ecs/relation-failure-runtime.RegistrationFailed", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../../src/ecs/relation-failure-runtime.Registered", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058key$1260$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _id_0 = _t_0["key"];
  return {$: "../../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1260$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1260$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1260$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1260$(_name_0, _values_0) {
  return {$: "../../../../src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058next$1261$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1261$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1261$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058declared$1262$(_name_0, _values_0) {
  return {$: "../../../../src/ecs/ordinary-machine-declaration.Vocabulary", "name": _name_0, "values": _values_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $setup$058cycle_committed$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    return $setup$058pending_requests$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058advance_world$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)))));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderCommitRefused", "factory": _factory_0, "registry": _registry_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058level_applied$1261$(_owned_0, _siblingOwned_0, _flow_0, _ran_0, _flowStream_0, _levelStream_0, _applied_0) {
  const _slot_0 = _applied_0["slot"];
  const _event_0 = _applied_0["event"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _slot_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": ($setup$058publish_transition$(_event_0, _levelStream_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1262$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1262$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1262$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $setup$058flow_applied$1261$(_owned_0, _siblingOwned_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _applied_0) {
  const _slot_0 = _applied_0["slot"];
  const _event_0 = _applied_0["event"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _slot_0, "level": _level_0, "ran": _ran_0, "flowStream": ($setup$058publish_transition$(_event_0, _flowStream_0)), "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1263$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1263$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1263$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $setup$058activate_world_readers$1261$(_readerId_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($setup$058activate_readers$1261$(_readerId_0, _tick_0, _resource_0)), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $machine$045calls$058registered_context_parts$1261$(_world_0, _state_0, _identified_0) {
  const _reader_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return {$: "machine-calls.StreamReaderRegistered", "world": _world_0, "registry": {$: "machine-calls.ReaderContext", "state": _state_0, "reader": _reader_0, "readerId": _readerId_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1262$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1262$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1262$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1262$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1262$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1262$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1262$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1262$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1263$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1263$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1263$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1263$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1263$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1263$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1263$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1263$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058projected_runtime$1261$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058cells$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1261$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058accepted$1261$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1261$(_spec_0, _graph_0, _handle_0, _component_0) {
  const _items_0 = _spec_0["requirements"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058requirements$1261$(_items_0, _graph_0, _namespace_0, _id_0, true, {$: "Nil"})), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _component_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058graph_read$1261$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1261$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1261$(_left_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058project_runtime$1260$(_argument_0, _owner_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matches_runtime$1260$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matched_runtime$1260$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1261$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1261$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_scan_projected$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_project$1260$(_target_0, _argument_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1260$(_target_0, _argument_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_match_right$1260$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matches_runtime$1260$(_argument_0, _owner_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1260$() {
  return {$: "../../../../src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058projected_runtime$1261$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058cells$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1261$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058accepted$1261$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph_joined$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1261$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1261$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1261$(_key_0, _wanted_0)), {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1261$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1261$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1261$(_front_0, _back_0, _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1261$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1261$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1261$(($machine$045calls$058classify_failure$1261$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058event_cap$1260$(_caps_0) {
  const _t_0 = _caps_0["second"];
  const _t_1 = _t_0["second"];
  const _events_0 = _t_1["second"];
  return _events_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1260$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058provide$1261$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1261$(_x_0);
})};
}

function $machine$045calls$058relation_spec$1260$() {
  return {$: "../../../../src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1260$("link", ($$$$047ordinary$045category$045v1$047declarations$058link$1260$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1260$("linkedBy", ($$$$047ordinary$045category$045v1$047declarations$058link$1260$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_relation$1260$("parent", ($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058optional_related$1260$("children", ($$$$047ordinary$045category$045v1$047declarations$058parent$1260$()))), "tail": {$: "Nil"}}}}}};
}

function $machine$045calls$058frame_events$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $machine$045calls$058frame_events_from_view$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $machine$045calls$058check_query$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return $machine$045calls$058check_rows$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058matches$1260$(_owner_0, _value_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058compared$1260$(_value_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058get$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $state$058flow$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_provide$1260$() {
  return {$: "../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_current$1260$(_x_0);
})};
}

function $machine$045calls$058pending_runtime$1260$(_runtime_0, _reader_0, _completion_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $machine$045calls$058pending_reader$1260$(_world_0, {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, ($machine$045calls$058reader_with_identity$1260$(_reader_0)), _completion_0);
}

function $machine$045calls$058actual_reader_run_context$1260$(_world_0, _state_0, _reader_0, _readerId_0) {
  return $machine$045calls$058actual_reader_run_state$1260$(_world_0, _state_0, _reader_0, _readerId_0);
}

function $clock$058force_garden_streams$(_value_0, _k_0) {
  return { $: "$FFI", run: $0eff["clock.force_garden_streams"].run, need: $0eff["clock.force_garden_streams"].need, args: [$0m56(_value_0)], kont: ((f) => (x) => (f($0m59(x))))(_k_0) };
}
function $machine$045calls$058stream_read_finish$1260$(_observed_0, _state_0, _reader_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $clock$058end$(_x_1), run_clo((_x_2) => {
  return $machine$045calls$058stream_read_after_end$1260$(_observed_0, _state_0, _reader_0, _x_2);
}), _x_0);
});
}

function $machine$045calls$058stream_instance_text$1260$(_instance_0) {
  if (_instance_0.$ === "../../../../src/ecs/inspector.Fresh") {
    return "Fresh";
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_cursor_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("Active(" + _x_4);
  }
}

function $machine$045calls$058stream_result_text$1260$(_result_0) {
  if (_result_0.$ === "Done") {
    const _value_0 = _result_0["value"];
    return $machine$045calls$058streams_text$1260$(_value_0);
  } else {
    return "Fail";
  }
}

function $machine$045calls$058actual_reader_text$1260$(_reader_0) {
  const _registry_0 = _reader_0["registry"];
  return $machine$045calls$058reader_registry_text$1260$(_registry_0);
}

function $machine$045calls$058world_dump_text$1260$(_joined_0) {
  const _text_0 = _joined_0["snd"];
  return _text_0;
}

function $setup$058cycle_queued$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _transaction_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return $setup$058cycle_committed$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1260$(_transaction_0)));
  } else {
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderRelationQueueRefused", "factory": _factory_0, "registry": _registry_0, "transaction": _transaction_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "edge": 5}};
  }
}

function $setup$058with_resources$1260$(_change_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _change_0(_resource_0), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $setup$058apply_level$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $setup$058level_applied$1260$(_owned_0, _siblingOwned_0, _flow_0, _ran_0, _flowStream_0, _levelStream_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1260$(_level_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1260$(_level_0)))));
}

function $setup$058apply_flow$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $setup$058flow_applied$1260$(_owned_0, _siblingOwned_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1261$(_flow_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1261$(_flow_0)))));
}

function $setup$058activate_at_clock$1260$(_readerId_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $setup$058activate_world_readers$1260$(_readerId_0, _tick_0, _world_0);
}

function $machine$045calls$058registered_context_join$1260$(_split_0, _identified_0) {
  const _world_0 = _split_0["fst"];
  const _state_0 = _split_0["snd"];
  return $machine$045calls$058registered_context_parts$1260$(_world_0, _state_0, _identified_0);
}

function $machine$045calls$058runtime_fields$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
}

function $machine$045calls$058reader_with_identity$1260$(_reader_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $machine$045calls$058reader_identity_fields$1260$(_keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1260$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write$1261$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_tx$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $setup$058pending_requests$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _world_0) {
  return $setup$058pending_complete$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1261$(($setup$058pending_state_requests$1261$(_world_0)))));
}

function $setup$058publish_transition$(_event_0, _stream_0) {
  if (_event_0.$ === "None") {
    return _stream_0;
  } else {
    const _event_1 = _event_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, 3, _event_1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1262$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1262$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, (_current_0 === _value_0))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0) {
  if (_pending_0.$ === "../../../../src/ecs/machine.NoPending") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return {$: "../../../../src/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1263$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1263$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, (_current_0 === _value_0))));
}

function $setup$058activate_readers$1261$(_readerId_0, _tick_0, _resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_flowStream_0, _readerId_0, _tick_0)), "levelStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_levelStream_0, _readerId_0, _tick_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1262$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($state$058put_flow$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1262$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1262$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1262$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1262$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1263$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($state$058put_level$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1263$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1263$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1263$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1263$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058cells$1261$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows_result$1261$(_observed_0, _handle_0, _component_0) {
  const _selected_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _selected_0, "snd": {$: "../../../../src/ecs/relation-query.Row", "entity": _handle_0, "cells": _cells_0, "component": _component_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058requirements$1261$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _graph_0 = $1;
      const _namespace_0 = $2;
      const _id_0 = $3;
      const _selected_0 = $4;
      const _acc_0 = $5;
      if (_remaining_0.$ === "Nil") {
        return {$: "Tuple", "fst": _selected_0, "snd": ($List$reverse$(_acc_0))};
      } else {
        const _t_0 = _remaining_0["head"];
        const _key_0 = _t_0["key"];
        const _descriptor_0 = _t_0["descriptor"];
        const _end_0 = _t_0["end"];
        const _mode_0 = _t_0["mode"];
        const _project_0 = _t_0["project"];
        const _rest_0 = _remaining_0["tail"];
        const _observed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058value$1261$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0));
        $0 = _rest_0;
        $1 = _graph_0;
        $2 = _namespace_0;
        $3 = _id_0;
        $4 = ($Bool$and$(_selected_0, ($$$$047$$$047$$$047$$$047src$047ecs$047query$058selection_aux$1260$(_mode_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058presence$1261$(_observed_0))))));
        $5 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058add_cell$1261$(_project_0, _key_0, _end_0, _observed_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1261$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058project_runtime$1260$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058projected_runtime$1260$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058matched_runtime$1260$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058graph_read$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_left$1260$(_target_0, _argument_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1260$(_left_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058project_runtime$1260$(_argument_0, _owner_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matches_runtime$1260$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matched_runtime$1260$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058cells$1261$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1261$() {
  return {$: "../../../../src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1261$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1261$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1261$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1261$(($List$reverse$(_back_0)), _cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1261$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1261$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1261$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1261$(_batches_0, _wanted_0, _item_0))};
  }
}

function $machine$045calls$058classify_failure$1261$(_event_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _failure_0 = _event_0["failure"];
    return {$: "Some", "value": ($machine$045calls$058relation_failure_key$1261$(_failure_0))};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058current$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1261$(_world_0)));
}

function $machine$045calls$058frame_events_from_view$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $machine$045calls$058check_rows$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _rows_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($Nat$is_eq$(($List$length$(_rows_0)), 2))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($machine$045calls$058relation_check_cap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1260$(($machine$045calls$058check_plan$1260$()))))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058compared$1260$(_value_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _view_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058is_current$1260$(_view_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045declaration$058get$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_current$1260$(_ctx_0) {
  const _world_0 = _ctx_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_projected$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0)));
}

function $machine$045calls$058pending_reader$1260$(_world_0, _state_0, _identified_0, _completion_0) {
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  const _reader_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return $machine$045calls$058pending_completion$1260$(_world_0, {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, _reader_0, _readerId_0, ($machine$045calls$058actual_parent_position$1260$(_positions_0, _readerId_0)), _completion_0);
}

function $machine$045calls$058actual_reader_run_state$1260$(_world_0, _state_0, _reader_0, _readerId_0) {
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run$1260$(($machine$045calls$058collected_runtime$1260$(_world_0, {$: "machine-calls.RuntimeState", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0})), _reader_0, {$: "machine-calls.ReaderArgs", "readerId": _readerId_0, "registeredAt": _tick_0});
}

function $machine$045calls$058stream_read_after_end$1260$(_observed_0, _state_0, _reader_0, __0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _result_0 = _observed_0["result"];
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  return run_clo((_x_0) => {
  return $IO$pure$({$: "machine-calls.StreamRead", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": _reader_0, "instance": _instance_0, "result": _result_0}, _x_0);
});
}

function $machine$045calls$058streams_text$1260$(_value_0) {
  const _flow_0 = _value_0["flow"];
  const _level_0 = _value_0["level"];
  const _parentFailures_0 = _value_0["parentFailures"];
  const _parentLagged_0 = _value_0["parentLagged"];
  const _parentPosition_0 = _value_0["parentPosition"];
  const _x_0 = ($machine$045calls$058position_maybe_text$(_parentPosition_0));
  const _x_1 = ($Bool$show$(_parentLagged_0));
  const _x_2 = (":parentPosition=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1268$(_parentFailures_0));
  const _x_5 = (":parentLagged=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($machine$045calls$058reading_text$(_level_0));
  const _x_8 = (",parentFailures=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($machine$045calls$058reading_text$(_flow_0));
  const _x_11 = (",level=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  return ("flow=" + _x_12);
}

function $machine$045calls$058reader_registry_text$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1264$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_namespace_0));
  const _x_10 = (":" + _x_8);
  return (_x_9 + _x_10);
}

function $setup$058cycle_committed$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    return $setup$058pending_requests$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058advance_world$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderCommitRefused", "factory": _factory_0, "registry": _registry_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058level_applied$1260$(_owned_0, _siblingOwned_0, _flow_0, _ran_0, _flowStream_0, _levelStream_0, _applied_0) {
  const _slot_0 = _applied_0["slot"];
  const _event_0 = _applied_0["event"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _slot_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": ($setup$058publish_transition$(_event_0, _levelStream_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1260$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1260$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $setup$058flow_applied$1260$(_owned_0, _siblingOwned_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _applied_0) {
  const _slot_0 = _applied_0["slot"];
  const _event_0 = _applied_0["event"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _slot_0, "level": _level_0, "ran": _ran_0, "flowStream": ($setup$058publish_transition$(_event_0, _flowStream_0)), "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_snapshot$1261$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1261$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $setup$058activate_world_readers$1260$(_readerId_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($setup$058activate_readers$1260$(_readerId_0, _tick_0, _resource_0)), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $machine$045calls$058registered_context_parts$1260$(_world_0, _state_0, _identified_0) {
  const _reader_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return {$: "machine-calls.StreamReaderRegistered", "world": _world_0, "registry": {$: "machine-calls.ReaderContext", "state": _state_0, "reader": _reader_0, "readerId": _readerId_0}};
}

function $machine$045calls$058reader_identity_fields$1260$(_keys_0, _identified_0) {
  const _registry_0 = _identified_0["fst"];
  const _readerId_0 = _identified_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "snd": _readerId_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1260$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1260$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058write_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1261$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($state$058level$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1261$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $setup$058pending_complete$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    return $setup$058pending_reserved$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderMachineCommitRefused", "factory": _factory_0, "registry": _registry_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058pending_state_requests$1261$(_world_0) {
  const _flow_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "../../../../src/ecs/machine.Set", "value": 9, "skipSame": false}));
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1263$(_flow_0, {$: "../../../../src/ecs/machine.Set", "value": 12, "skipSame": true});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../src/ecs/machine-stream.Stream", "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1262$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "../../../../src/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1263$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "../../../../src/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $state$058put_flow$1261$(_resources_0, _replacement_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _replacement_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1262$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1262$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $state$058put_level$1261$(_resources_0, _replacement_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _replacement_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1263$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1263$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058value$1261$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0) {
  if (_end_0.$ === "../../../../src/ecs/relation-query.Outgoing") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058outgoing_value$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058incoming_value$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047query$058selection_aux$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../src/ecs/query.Required") {
    if (_value_0.$ === "../../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../src/ecs/query.Present") {
    if (_value_0.$ === "../../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../src/ecs/query.Absent") {
    if (_value_0.$ === "../../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058presence$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-query.Missing") {
    return {$: "../../../../src/ecs/component.ComponentAbsent"};
  } else {
    return {$: "../../../../src/ecs/component.Found", "value": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058add_cell$1261$(_project_0, _key_0, _end_0, _value_0, _cells_0) {
  if (!_project_0) {
    return _cells_0;
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-query.Cell", "key": _key_0, "end": _end_0, "value": _value_0}, "tail": _cells_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058projected_runtime$1260$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _handle_0, _component_0) {
  const _items_0 = _spec_0["requirements"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058requirements$1260$(_items_0, _graph_0, _namespace_0, _id_0, true, {$: "Nil"})), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _component_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058graph_read$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_runtime_projected_right$1260$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058project_runtime$1260$(_spec_0, _frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058projected_runtime$1260$(_spec_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058matched_runtime$1260$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph_joined$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058graph_read$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1261$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1261$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1261$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1261$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1261$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1261$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1261$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $machine$045calls$058relation_failure_key$1261$(_failure_0) {
  const _relation_0 = _failure_0["relation"];
  return $machine$045calls$058failure_descriptor_key$1261$(_relation_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058projected$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1261$(_slot_0))};
}

function $machine$045calls$058relation_check_cap$1260$(_caps_0) {
  const _relations_0 = _caps_0["second"];
  return _relations_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058is_current$1260$(_view_0, _value_0) {
  if (_view_0.$ === "../../../../src/ecs/machine.Unavailable") {
    return false;
  } else {
    const _current_0 = _view_0["value"];
    return (_current_0 === _value_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(($machine$045calls$058flow_check_cap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047check$058caps_field$1260$(($machine$045calls$058check_plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045machine$045projection$058check_projected$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $machine$045calls$058pending_completion$1260$(_world_0, _state_0, _reader_0, _readerId_0, _position_0, _completion_0) {
  if (_completion_0.$ === "../../../../src/ecs/relation-failure-runtime.Succeeded") {
    const _output_0 = _completion_0["output"];
    return {$: "machine-calls.PendingRead", "observed": {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Fresh"}, "result": {$: "Done", "value": ($machine$045calls$058streams_position$1260$(_output_0, _position_0))}}, "state": _state_0, "reader": _reader_0};
  } else if (_completion_0.$ === "../../../../src/ecs/relation-failure-runtime.Failed") {
    const _error_0 = _completion_0["error"];
    return {$: "machine-calls.PendingRead", "observed": {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Fresh"}, "result": {$: "Fail", "error": _error_0}}, "state": _state_0, "reader": _reader_0};
  } else {
    return {$: "machine-calls.PendingRead", "observed": {$: "../../../../src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../src/ecs/inspector.Fresh"}, "result": {$: "Fail", "error": {$: "Unit"}}}, "state": _state_0, "reader": _reader_0};
  }
}

function $machine$045calls$058actual_parent_position$1260$(_positions_0, _readerId_0) {
  return $machine$045calls$058actual_parent_position_from$(_positions_0, _readerId_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run$1260$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_identified$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _keys_0, _args_0);
}

function $machine$045calls$058collected_runtime$1260$(_world_0, _state_0) {
  return $machine$045calls$058collected_runtime_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world$1260$(run_clo((_x_0) => {
  return $machine$045calls$058identity_world$1260$(_x_0);
}), ($machine$045calls$058state_runtime$1260$(_world_0, _state_0)))));
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058failure$1260$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $setup$058pending_requests$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _world_0) {
  return $setup$058pending_complete$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($setup$058finish_tx$1260$(($setup$058pending_state_requests$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1260$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1260$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, (_current_0 === _value_0))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_present$1261$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1261$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, (_current_0 === _value_0))));
}

function $setup$058activate_readers$1260$(_readerId_0, _tick_0, _resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_flowStream_0, _readerId_0, _tick_0)), "levelStream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_levelStream_0, _readerId_0, _tick_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($state$058put_flow$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1260$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($state$058put_level$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1261$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $state$058level$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": _level_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058reset$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $setup$058pending_reserved$1261$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return {$: "setup.Ready", "world": ($setup$058advance_world$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $setup$058apply_spawn$1261$(_handle_0, _x_0);
}))))), "registry": _registry_0, "first": _first_0, "middle": _middle_0, "last": _last_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderReservationRefused", "factory": _factory_0, "registry": _registry_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0) {
  if (_pending_0.$ === "../../../../src/ecs/machine.Queued") {
    const _prior_0 = _pending_0["value"];
    const _t_0 = _pending_0["skipSame"];
    if (!_t_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058forced_pending$1260$((_prior_0 === _value_0), _prior_0, _value_0);
    } else {
      return {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
    }
  } else {
    return {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058outgoing_value$1261$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../src/ecs/relation-query.Missing"};
  } else {
    const _id_0 = _value_0["value"];
    return {$: "../../../../src/ecs/relation-query.Target", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058incoming_value$1261$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "../../../../src/ecs/relation-query.Missing"};
  } else {
    const _first_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "../../../../src/ecs/relation-query.Sources", "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058handles_acc$1261$({$: "Con", "head": _first_0, "tail": _rest_0}, _namespace_0, {$: "Nil"}))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows_result$1260$(_observed_0, _handle_0, _component_0) {
  const _selected_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _selected_0, "snd": {$: "../../../../src/ecs/relation-query.Row", "entity": _handle_0, "cells": _cells_0, "component": _component_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058requirements$1260$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _graph_0 = $1;
      const _namespace_0 = $2;
      const _id_0 = $3;
      const _selected_0 = $4;
      const _acc_0 = $5;
      if (_remaining_0.$ === "Nil") {
        return {$: "Tuple", "fst": _selected_0, "snd": ($List$reverse$(_acc_0))};
      } else {
        const _t_0 = _remaining_0["head"];
        const _key_0 = _t_0["key"];
        const _descriptor_0 = _t_0["descriptor"];
        const _end_0 = _t_0["end"];
        const _mode_0 = _t_0["mode"];
        const _project_0 = _t_0["project"];
        const _rest_0 = _remaining_0["tail"];
        const _observed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058value$1260$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0));
        $0 = _rest_0;
        $1 = _graph_0;
        $2 = _namespace_0;
        $3 = _id_0;
        $4 = ($Bool$and$(_selected_0, ($$$$047$$$047$$$047$$$047src$047ecs$047query$058selection_aux$1260$(_mode_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058presence$1260$(_observed_0))))));
        $5 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058add_cell$1260$(_project_0, _key_0, _end_0, _observed_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058projected_runtime$1260$(_spec_0, _target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058accepted$1260$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058graph_joined$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/check.Frame", "world": _world_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($machine$045calls$058stream_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1261$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1261$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1261$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1261$(_items_0, 0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1261$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1261$(_items_0, 0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1261$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1261$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1261$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $machine$045calls$058failure_descriptor_key$1261$(_relation_0) {
  const _id_0 = _relation_0["key"];
  return {$: "../../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058current_view$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $machine$045calls$058flow_check_cap$1260$(_caps_0) {
  const _flow_0 = _caps_0["first"];
  return _flow_0;
}

function $machine$045calls$058streams_position$1260$(_streams_0, _position_0) {
  const _flow_0 = _streams_0["flow"];
  const _level_0 = _streams_0["level"];
  const _parentFailures_0 = _streams_0["parentFailures"];
  const _parentLagged_0 = _streams_0["parentLagged"];
  return {$: "machine-types.Streams", "flow": _flow_0, "level": _level_0, "parentFailures": _parentFailures_0, "parentLagged": _parentLagged_0, "parentPosition": _position_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_identified$1260$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)), {$: "../../../../src/ecs/relation-failure-runtime.Input", "readings": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $machine$045calls$058collected_runtime_result$1260$(_result_0) {
  const _runtime_0 = _result_0["fst"];
  return _runtime_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_result$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058effect_clocked$1260$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $machine$045calls$058identity_world$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Unit"}};
}

function $machine$045calls$058state_runtime$1260$(_world_0, _state_0) {
  const _domains_0 = _state_0["domains"];
  const _positions_0 = _state_0["positions"];
  const _tick_0 = _state_0["tick"];
  const _frameStart_0 = _state_0["frameStart"];
  const _boundary_0 = _state_0["boundary"];
  const _capacity_0 = _state_0["capacity"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058failure$1260$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $setup$058pending_complete$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Success") {
    return $setup$058pending_reserved$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderMachineCommitRefused", "factory": _factory_0, "registry": _registry_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058pending_state_requests$1260$(_world_0) {
  const _flow_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), {$: "../../../../src/ecs/machine.Set", "value": 9, "skipSame": false}));
  return $$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_flow_0, {$: "../../../../src/ecs/machine.Set", "value": 12, "skipSame": true});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1260$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "../../../../src/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058apply_decision$1261$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "../../../../src/ecs/machine.Applied", "slot": {$: "../../../../src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "../../../../src/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $state$058put_flow$1260$(_resources_0, _replacement_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _replacement_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1260$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $state$058put_level$1260$(_resources_0, _replacement_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flow_0 = _resources_0["flow"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flow_0, "level": _replacement_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional$1261$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $setup$058apply_spawn$1261$(_handle_0, _world_0) {
  return $setup$058spawn_activated$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045queue$058forced_pending$1260$(_same_0, _prior_0, _value_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/machine.Queued", "value": _prior_0, "skipSame": false};
  } else {
    return {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058handles_acc$1261$($0, $1, $2) {
  for (;;) {
    {
      const _ids_0 = $0;
      const _namespace_0 = $1;
      const _acc_0 = $2;
      if (_ids_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _id_0 = _ids_0["head"];
        const _rest_0 = _ids_0["tail"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = {$: "Con", "head": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058value$1260$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0) {
  if (_end_0.$ === "../../../../src/ecs/relation-query.Outgoing") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058outgoing_value$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058incoming_value$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058presence$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-query.Missing") {
    return {$: "../../../../src/ecs/component.ComponentAbsent"};
  } else {
    return {$: "../../../../src/ecs/component.Found", "value": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058add_cell$1260$(_project_0, _key_0, _end_0, _value_0, _cells_0) {
  if (!_project_0) {
    return _cells_0;
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-query.Cell", "key": _key_0, "end": _end_0, "value": _value_0}, "tail": _cells_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047check$045relation$045projection$058cells$1260$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $machine$045calls$058stream_runner$1261$(_world_0, _input_0) {
  return $machine$045calls$058stream_outcome$1261$(($machine$045calls$058read_world$1261$(_world_0, _input_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1261$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "../../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../src/ecs/relation-failure-runtime.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058outcome$1260$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1260$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _input_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_result$1260$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058effect_clocked$1260$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $setup$058pending_reserved$1260$(_factory_0, _registry_0, _first_0, _middle_0, _last_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return {$: "setup.Ready", "world": ($setup$058advance_world$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $setup$058apply_spawn$1260$(_handle_0, _x_0);
}))))), "registry": _registry_0, "first": _first_0, "middle": _middle_0, "last": _last_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "setup.BuildRefused", "failure": {$: "setup.ReaderReservationRefused", "factory": _factory_0, "registry": _registry_0, "world": _world_0, "handles": {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _middle_0, "tail": {$: "Con", "head": _last_0, "tail": {$: "Nil"}}}}, "error": _error_0}};
  }
}

function $setup$058spawn_activated$1261$(_handle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058populated_world$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1266$(run_clo((_x_0) => {
  return {$: "Tuple", "fst": ($setup$058populate_store$1261$(_x_0, _handle_0, {$: "Con", "head": 99, "tail": {$: "Con", "head": 100, "tail": {$: "Nil"}}}, {$: "Con", "head": 101, "tail": {$: "Con", "head": 102, "tail": {$: "Nil"}}})), "snd": {$: "Unit"}};
}), _world_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058outgoing_value$1260$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../src/ecs/relation-query.Missing"};
  } else {
    const _id_0 = _value_0["value"];
    return {$: "../../../../src/ecs/relation-query.Target", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058incoming_value$1260$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "../../../../src/ecs/relation-query.Missing"};
  } else {
    const _first_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "../../../../src/ecs/relation-query.Sources", "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058handles_acc$1260$({$: "Con", "head": _first_0, "tail": _rest_0}, _namespace_0, {$: "Nil"}))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $machine$045calls$058stream_outcome$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _streams_0 = _observed_0["snd"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _streams_0};
}

function $machine$045calls$058read_world$1261$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _readerId_0 = _t_0["readerId"];
  return $machine$045calls$058read_world_input$1261$(_readerId_0, _readings_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058outcome$1260$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_clocked$1260$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_collected$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $setup$058apply_spawn$1260$(_handle_0, _world_0) {
  return $setup$058spawn_activated$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
}

function $setup$058populated_world$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $setup$058populate_store$1261$(_store_0, _handle_0, _cellsPayload_0, _siblingPayload_0) {
  const _t_0 = _store_0["components"];
  const _cells_0 = _t_0["cells"];
  const _sibling_0 = _t_0["sibling"];
  const _graph_0 = _store_0["graph"];
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "state.Components", "cells": ($setup$058write_component$1261$(_cells_0, _handle_0, _cellsPayload_0)), "sibling": ($setup$058write_component$1261$(_sibling_0, _handle_0, _siblingPayload_0))}, "graph": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045query$058handles_acc$1260$($0, $1, $2) {
  for (;;) {
    {
      const _ids_0 = $0;
      const _namespace_0 = $1;
      const _acc_0 = $2;
      if (_ids_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _id_0 = _ids_0["head"];
        const _rest_0 = _ids_0["tail"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = {$: "Con", "head": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $machine$045calls$058read_world_input$1261$(_readerId_0, _readings_0, _world_0) {
  return $machine$045calls$058read_world_clocked$1261$(_readerId_0, _readings_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _error_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), "tick": _clock_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../src/ecs/relation-failure-runtime.Failed", "error": _error_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _clock_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), _id_0, _clock_0, false)), _clock_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_collected$1260$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _tick_0, _domains_0);
}

function $setup$058spawn_activated$1260$(_handle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return $setup$058populated_world$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(run_clo((_x_0) => {
  return {$: "Tuple", "fst": ($setup$058populate_store$1260$(_x_0, _handle_0, {$: "Con", "head": 99, "tail": {$: "Con", "head": 100, "tail": {$: "Nil"}}}, {$: "Con", "head": 101, "tail": {$: "Con", "head": 102, "tail": {$: "Nil"}}})), "snd": {$: "Unit"}};
}), _world_0)));
  } else {
    return _world_0;
  }
}

function $machine$045calls$058read_world_clocked$1261$(_readerId_0, _readings_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $machine$045calls$058read_world_tick$1261$(_readerId_0, _readings_0, _world_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1260$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "../../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "../../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "../../../../src/ecs/relation-failure-runtime.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _key_0, "values": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$({$: "../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$(_items_0, {$: "../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $setup$058populated_world$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $setup$058populate_store$1260$(_store_0, _handle_0, _cellsPayload_0, _siblingPayload_0) {
  const _t_0 = _store_0["components"];
  const _cells_0 = _t_0["cells"];
  const _sibling_0 = _t_0["sibling"];
  const _graph_0 = _store_0["graph"];
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "state.Components", "cells": ($setup$058write_component$1260$(_cells_0, _handle_0, _cellsPayload_0)), "sibling": ($setup$058write_component$1260$(_sibling_0, _handle_0, _siblingPayload_0))}, "graph": _graph_0};
}

function $machine$045calls$058read_world_tick$1261$(_readerId_0, _readings_0, _world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $machine$045calls$058read_world_resources$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, ($machine$045calls$058reader_streams$1261$(_readerId_0, _tick_0, ($machine$045calls$058parent_reading$1261$(_readings_0)), _resource_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(($machine$045calls$058classify_failure$1260$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $machine$045calls$058read_world_resources$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _observed_0) {
  const _resource_0 = _observed_0["fst"];
  const _streams_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _streams_0};
}

function $machine$045calls$058reader_streams$1261$(_readerId_0, _tick_0, _parent_0, _resources_0) {
  const _values_0 = _parent_0["values"];
  const _lagged_0 = _parent_0["lagged"];
  return $machine$045calls$058reader_streams_values$1261$(_readerId_0, _tick_0, _values_0, _lagged_0, _resources_0);
}

function $machine$045calls$058parent_reading$1261$(_readings_0) {
  if (_readings_0.$ === "Nil") {
    return {$: "../../../../src/ecs/event-runtime.Reading", "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _readings_0["head"];
    const _key_0 = _t_0["key"];
    const _values_0 = _t_0["values"];
    const _lagged_0 = _t_0["lagged"];
    return $machine$045calls$058parent_reading_key$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1261$(_key_0, ($machine$045calls$058parent_key$1261$()))), _values_0, _lagged_0);
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$() {
  return {$: "../../../../src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $machine$045calls$058classify_failure$1260$(_event_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _failure_0 = _event_0["failure"];
    return {$: "Some", "value": ($machine$045calls$058relation_failure_key$1260$(_failure_0))};
  } else {
    return {$: "None"};
  }
}

function $machine$045calls$058reader_streams_values$1261$(_readerId_0, _tick_0, _parentValues_0, _parentLagged_0, _resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flowSlot_0 = _resources_0["flow"];
  const _levelSlot_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _flowReading_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_flowStream_0, _readerId_0, _tick_0));
  const _levelReading_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_levelStream_0, _readerId_0, _tick_0));
  const _nextFlow_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_flowStream_0, _readerId_0, _tick_0, true));
  const _nextLevel_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_levelStream_0, _readerId_0, _tick_0, true));
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flowSlot_0, "level": _levelSlot_0, "ran": _ran_0, "flowStream": _nextFlow_0, "levelStream": _nextLevel_0}, "snd": {$: "machine-types.Streams", "flow": _flowReading_0, "level": _levelReading_0, "parentFailures": _parentValues_0, "parentLagged": _parentLagged_0, "parentPosition": {$: "None"}}};
}

function $machine$045calls$058parent_reading_key$1261$(_same_0, _values_0, _lagged_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/event-runtime.Reading", "values": ($machine$045calls$058parent_reading_values$1261$(_values_0, {$: "Nil"})), "lagged": _lagged_0};
  } else {
    return {$: "../../../../src/ecs/event-runtime.Reading", "values": {$: "Nil"}, "lagged": false};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $machine$045calls$058relation_failure_key$1260$(_failure_0) {
  const _relation_0 = _failure_0["relation"];
  return $machine$045calls$058failure_descriptor_key$1260$(_relation_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe_position$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $machine$045calls$058parent_reading_values$1261$($0, $1) {
  for (;;) {
    {
      const _events_0 = $0;
      const _reversed_0 = $1;
      if (_events_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _event_0 = _events_0["head"];
        const _rest_0 = _events_0["tail"];
        $0 = _rest_0;
        $1 = ($machine$045calls$058parent_event_reverse$1261$(_event_0, _reversed_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($machine$045calls$058stream_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": ($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $machine$045calls$058failure_descriptor_key$1260$(_relation_0) {
  const _id_0 = _relation_0["key"];
  return {$: "../../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe_position$1260$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0);
  }
}

function $machine$045calls$058parent_event_reverse$1261$(_event_0, _reversed_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _failure_0 = _event_0["failure"];
    return {$: "Con", "head": _failure_0, "tail": _reversed_0};
  } else {
    return _reversed_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $machine$045calls$058stream_runner$1260$(_world_0, _input_0) {
  return $machine$045calls$058stream_outcome$1260$(($machine$045calls$058read_world$1260$(_world_0, _input_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $machine$045calls$058stream_outcome$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _streams_0 = _observed_0["snd"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _streams_0};
}

function $machine$045calls$058read_world$1260$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _readerId_0 = _t_0["readerId"];
  return $machine$045calls$058read_world_input$1260$(_readerId_0, _readings_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../../../../src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $machine$045calls$058read_world_input$1260$(_readerId_0, _readings_0, _world_0) {
  return $machine$045calls$058read_world_clocked$1260$(_readerId_0, _readings_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_items_0, _rest_0);
  }
}

function $machine$045calls$058read_world_clocked$1260$(_readerId_0, _readings_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $machine$045calls$058read_world_tick$1260$(_readerId_0, _readings_0, _world_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $machine$045calls$058read_world_tick$1260$(_readerId_0, _readings_0, _world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $machine$045calls$058read_world_resources$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, ($machine$045calls$058reader_streams$1260$(_readerId_0, _tick_0, ($machine$045calls$058parent_reading$1260$(_readings_0)), _resource_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $machine$045calls$058read_world_resources$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _observed_0) {
  const _resource_0 = _observed_0["fst"];
  const _streams_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _streams_0};
}

function $machine$045calls$058reader_streams$1260$(_readerId_0, _tick_0, _parent_0, _resources_0) {
  const _values_0 = _parent_0["values"];
  const _lagged_0 = _parent_0["lagged"];
  return $machine$045calls$058reader_streams_values$1260$(_readerId_0, _tick_0, _values_0, _lagged_0, _resources_0);
}

function $machine$045calls$058parent_reading$1260$(_readings_0) {
  if (_readings_0.$ === "Nil") {
    return {$: "../../../../src/ecs/event-runtime.Reading", "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _readings_0["head"];
    const _key_0 = _t_0["key"];
    const _values_0 = _t_0["values"];
    const _lagged_0 = _t_0["lagged"];
    return $machine$045calls$058parent_reading_key$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, ($machine$045calls$058parent_key$1260$()))), _values_0, _lagged_0);
  }
}

function $machine$045calls$058reader_streams_values$1260$(_readerId_0, _tick_0, _parentValues_0, _parentLagged_0, _resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _siblingOwned_0 = _resources_0["siblingOwned"];
  const _flowSlot_0 = _resources_0["flow"];
  const _levelSlot_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _flowReading_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_flowStream_0, _readerId_0, _tick_0));
  const _levelReading_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_levelStream_0, _readerId_0, _tick_0));
  const _nextFlow_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_flowStream_0, _readerId_0, _tick_0, true));
  const _nextLevel_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_levelStream_0, _readerId_0, _tick_0, true));
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "siblingOwned": _siblingOwned_0, "flow": _flowSlot_0, "level": _levelSlot_0, "ran": _ran_0, "flowStream": _nextFlow_0, "levelStream": _nextLevel_0}, "snd": {$: "machine-types.Streams", "flow": _flowReading_0, "level": _levelReading_0, "parentFailures": _parentValues_0, "parentLagged": _parentLagged_0, "parentPosition": {$: "None"}}};
}

function $machine$045calls$058parent_reading_key$1260$(_same_0, _values_0, _lagged_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/event-runtime.Reading", "values": ($machine$045calls$058parent_reading_values$1260$(_values_0, {$: "Nil"})), "lagged": _lagged_0};
  } else {
    return {$: "../../../../src/ecs/event-runtime.Reading", "values": {$: "Nil"}, "lagged": false};
  }
}

function $machine$045calls$058parent_reading_values$1260$($0, $1) {
  for (;;) {
    {
      const _events_0 = $0;
      const _reversed_0 = $1;
      if (_events_0.$ === "Nil") {
        return $List$reverse$(_reversed_0);
      } else {
        const _event_0 = _events_0["head"];
        const _rest_0 = _events_0["tail"];
        $0 = _rest_0;
        $1 = ($machine$045calls$058parent_event_reverse$1260$(_event_0, _reversed_0));
        continue;
      }
    }
  }
}

function $machine$045calls$058parent_event_reverse$1260$(_event_0, _reversed_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _failure_0 = _event_0["failure"];
    return {$: "Con", "head": _failure_0, "tail": _reversed_0};
  } else {
    return _reversed_0;
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Batch has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m5(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": BigInt(v["cursor"]), "registeredAt": BigInt(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m7(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-stream.Stream": at = at[key] = {...v, "batches": $0m4(v["batches"]), "positions": $0m6(v["positions"]), "droppedThrough": BigInt(v["droppedThrough"]), "frameStart": BigInt(v["frameStart"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-stream.Stream has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-stream.Stream); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m3(v["flowStream"]), "levelStream": $0m3(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m13(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Batch": at = at[key] = {...v, "tick": nat_host(v["tick"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Batch has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m13(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m15(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": nat_host(v["cursor"]), "registeredAt": nat_host(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m14(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m15(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-stream.Stream": at = at[key] = {...v, "batches": $0m12(v["batches"]), "positions": $0m14(v["positions"]), "droppedThrough": nat_host(v["droppedThrough"]), "frameStart": nat_host(v["frameStart"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-stream.Stream has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-stream.Stream); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m11(v["flowStream"]), "levelStream": $0m11(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m16(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m9(f($0m1(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "resource": $0m10(v["resource"]), "pending": $0m16(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m1(f($0m9(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": BigInt(v["depth"]), "resource": $0m2(v["resource"]), "pending": $0m8(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m1(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m19(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m11(v["flowStream"]), "levelStream": $0m11(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m21(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "resource": $0m19(v["resource"]), "pending": $0m20(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m23(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m3(v["flowStream"]), "levelStream": $0m3(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m24(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m22(f($0m21(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m22(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": BigInt(v["depth"]), "resource": $0m23(v["resource"]), "pending": $0m24(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m20(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m21(f($0m22(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m18(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "resource": $0m19(v["resource"]), "pending": $0m20(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m17(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m18(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m25(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m1(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m26(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m18(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m29(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m3(v["flowStream"]), "levelStream": $0m3(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m32(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m11(v["flowStream"]), "levelStream": $0m11(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m33(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m31(f($0m28(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m31(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "resource": $0m32(v["resource"]), "pending": $0m33(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m30(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m28(f($0m31(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m28(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": BigInt(v["depth"]), "resource": $0m29(v["resource"]), "pending": $0m30(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m27(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m28(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m36(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m11(v["flowStream"]), "levelStream": $0m11(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m38(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "resource": $0m36(v["resource"]), "pending": $0m37(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m40(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "state.Resources": at = at[key] = {...v, "flowStream": $0m3(v["flowStream"]), "levelStream": $0m3(v["levelStream"])}; return top[0];
      default: throw "bend: state.Resources has no tag " + v?.$ + " (its tags: state.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m41(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m39(f($0m38(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m39(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": BigInt(v["depth"]), "resource": $0m40(v["resource"]), "pending": $0m41(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m37(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m38(f($0m39(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m35(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "resource": $0m36(v["resource"]), "pending": $0m37(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m34(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m35(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m42(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/check.Checked": at = at[key] = {...v, "world": $0m1(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/check.Checked has no tag " + v?.$ + " (its tags: ../../../../src/ecs/check.Checked); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m43(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/check.Checked": at = at[key] = {...v, "world": $0m18(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/check.Checked has no tag " + v?.$ + " (its tags: ../../../../src/ecs/check.Checked); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m47(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m7(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m46(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "machine-types.Streams": at = at[key] = {...v, "parentPosition": $0m47(v["parentPosition"])}; return top[0];
      default: throw "bend: machine-types.Streams has no tag " + v?.$ + " (its tags: machine-types.Streams); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m45(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Fail": at[key] = v; return top[0];
      case "Done": at = at[key] = {...v, "value": $0m46(v["value"])}; return top[0];
      default: throw "bend: Result has no tag " + v?.$ + " (its tags: Fail, Done); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m44(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m1(v["world"]), "result": $0m45(v["result"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m51(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m15(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m50(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "machine-types.Streams": at = at[key] = {...v, "parentPosition": $0m51(v["parentPosition"])}; return top[0];
      default: throw "bend: machine-types.Streams has no tag " + v?.$ + " (its tags: machine-types.Streams); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m49(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Fail": at[key] = v; return top[0];
      case "Done": at = at[key] = {...v, "value": $0m50(v["value"])}; return top[0];
      default: throw "bend: Result has no tag " + v?.$ + " (its tags: Fail, Done); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m48(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m18(v["world"]), "result": $0m49(v["result"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m52(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/check.Checked": at = at[key] = {...v, "world": $0m28(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/check.Checked has no tag " + v?.$ + " (its tags: ../../../../src/ecs/check.Checked); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m53(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/check.Checked": at = at[key] = {...v, "world": $0m35(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/check.Checked has no tag " + v?.$ + " (its tags: ../../../../src/ecs/check.Checked); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m54(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m28(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m55(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m35(v["world"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m58(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "machine-types.Streams": at = at[key] = {...v, "parentPosition": $0m47(v["parentPosition"])}; return top[0];
      default: throw "bend: machine-types.Streams has no tag " + v?.$ + " (its tags: machine-types.Streams); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m57(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Fail": at[key] = v; return top[0];
      case "Done": at = at[key] = {...v, "value": $0m58(v["value"])}; return top[0];
      default: throw "bend: Result has no tag " + v?.$ + " (its tags: Fail, Done); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m56(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m28(v["world"]), "result": $0m57(v["result"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m61(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "machine-types.Streams": at = at[key] = {...v, "parentPosition": $0m51(v["parentPosition"])}; return top[0];
      default: throw "bend: machine-types.Streams has no tag " + v?.$ + " (its tags: machine-types.Streams); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m60(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Fail": at[key] = v; return top[0];
      case "Done": at = at[key] = {...v, "value": $0m61(v["value"])}; return top[0];
      default: throw "bend: Result has no tag " + v?.$ + " (its tags: Fail, Done); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m59(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/inspector.Observed": at = at[key] = {...v, "world": $0m35(v["world"]), "result": $0m60(v["result"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/inspector.Observed has no tag " + v?.$ + " (its tags: ../../../../src/ecs/inspector.Observed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);