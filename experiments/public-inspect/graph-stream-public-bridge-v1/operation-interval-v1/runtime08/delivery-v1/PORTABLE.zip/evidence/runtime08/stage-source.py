#!/usr/bin/env python3
"""Build the single-identity, import-relocated #55 candidate source stage."""
import hashlib
import json
import re
from pathlib import Path


ROOT = Path('/workspace/formal-proofs/bendvy')
WT = Path('/workspace/formal-proofs/bendvy-worktrees/inspector55-operation-interval')
LEAF = WT / 'experiments/public-inspect/graph-stream-public-bridge-v1/operation-interval-v1'
OUT = LEAF / 'runtime08'
STAGE = OUT / 'source-stage'
MAP = OUT / 'SOURCE-COPY-MAP.json'
BASE_PLAN = LEAF / 'runtime04/js/plan.json'
ROOT_CORE = ROOT / 'src/ecs'
WT_CORE = WT / 'src/ecs'
PRIVATE = {
    str(ROOT_CORE / 'inspector-query.bend'): WT_CORE / 'inspector-query.bend',
    str(ROOT_CORE / 'inspector-relation-projection.bend'): WT_CORE / 'inspector-relation-projection.bend',
    str(ROOT_CORE / 'check-relation-projection.bend'): WT_CORE / 'check-relation-projection.bend',
}
IMPORT = re.compile(r'^(?P<prefix>\s*import\s+)(?P<target>\S+)(?P<suffix>.*)$')
FOREIGN_IMPORT = re.compile(r'^\s+import\s+["\'](?P<target>[^"\']+)["\']\s*(?:#.*)?$')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular_bytes(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'expected regular source file: {path}')
    return path.read_bytes()


def canonical_source(path):
    path = Path(path).resolve(strict=True)
    try:
        relative = path.relative_to(WT_CORE)
    except ValueError:
        return str(path)
    return str(ROOT_CORE / relative)


def stage_relative(source):
    path = Path(source)
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return path.relative_to(WT).as_posix()


def rewrite_imports(source_path, raw, destinations):
    result = []
    edits = []
    leading_imports = True
    text = raw.decode('utf-8')
    for number, line in enumerate(text.splitlines(keepends=True), 1):
        ending = ''
        body = line
        if body.endswith('\r\n'):
            body, ending = body[:-2], '\r\n'
        elif body.endswith('\n'):
            body, ending = body[:-1], '\n'
        stripped = body.strip()
        if leading_imports and (not stripped or stripped.startswith('#')):
            result.append(line)
            continue
        match = IMPORT.match(body) if leading_imports else None
        if match is None:
            leading_imports = False
            result.append(line)
            continue
        if match.group('target') == 'Base':
            result.append(line)
            continue
        token = match.group('target')
        target = Path(token) if Path(token).is_absolute() else source_path.parent / token
        canonical = canonical_source(target)
        if canonical not in destinations:
            raise ValueError(f'import target absent from frozen 83-source closure: {source_path}:{number}: {token} -> {canonical}')
        relocated = str(STAGE / destinations[canonical])
        suffix = match.group('suffix')
        result.append(match.group('prefix') + relocated + suffix + ending)
        edits.append({'line': number, 'sourceToken': token, 'stageToken': relocated,
                      'canonicalTarget': canonical, 'aliasAndCommentSuffix': suffix})
    rewritten = ''.join(result).encode('utf-8')
    return rewritten, edits


def imports_removed(raw):
    text = raw.decode('utf-8')
    kept = []
    leading_imports = True
    for line in text.splitlines(keepends=True):
        body = line.rstrip('\r\n')
        stripped = body.strip()
        if leading_imports and (not stripped or stripped.startswith('#')):
            kept.append(line)
            continue
        match = IMPORT.match(body) if leading_imports else None
        if match is None:
            leading_imports = False
            kept.append(line)
        elif match.group('target') == 'Base':
            kept.append(line)
    return ''.join(kept).encode('utf-8')


def foreign_imports(raw):
    """Find indented FFI resource imports without changing their source bytes."""
    found = []
    for number, line in enumerate(raw.decode('utf-8').splitlines(), 1):
        match = FOREIGN_IMPORT.fullmatch(line)
        if match is not None:
            found.append({'line': number, 'token': match.group('target')})
    return found


def main():
    if STAGE.exists() or MAP.exists():
        raise SystemExit('runtime08 source stage/map must start absent')
    base = json.loads(BASE_PLAN.read_text())
    inventory = base['sourceInventory']
    if len(inventory) != 83:
        raise SystemExit('expected the frozen 83-source closure')
    for source, expected in inventory.items():
        if sha(regular_bytes(source)) != expected:
            raise SystemExit(f'current master/source basis drift: {source}')
    if set(PRIVATE) != {str(ROOT_CORE / name) for name in (
        'inspector-query.bend', 'inspector-relation-projection.bend', 'check-relation-projection.bend')}:
        raise SystemExit('private core set changed')

    destinations = {source: stage_relative(source) for source in inventory}
    if len(set(destinations.values())) != len(destinations):
        raise SystemExit('source stage path collision')
    source_origins = {source: PRIVATE.get(source, Path(source)) for source in inventory}
    if any(not Path(origin).is_file() for origin in source_origins.values()):
        raise SystemExit('source origin missing')

    STAGE.mkdir(parents=True)
    rows = []
    foreign_edges = []
    for canonical, stage_rel in sorted(destinations.items()):
        origin = Path(source_origins[canonical])
        original = regular_bytes(origin)
        for foreign in foreign_imports(original):
            token_path = Path(foreign['token'])
            if token_path.is_absolute() or '..' in token_path.parts:
                raise ValueError(f'foreign resource import must stay beside its Bend source: {canonical}:{foreign["line"]}: {foreign["token"]}')
            resource_source = (origin.parent / token_path).resolve(strict=True)
            resource_stage_rel = (Path(stage_rel).parent / token_path).as_posix()
            resource_stage = STAGE / resource_stage_rel
            try:
                resource_stage.resolve().relative_to(STAGE.resolve())
            except ValueError as error:
                raise ValueError(f'foreign resource escapes staged root: {canonical}:{foreign["line"]}') from error
            foreign_edges.append({
                'importingCanonicalSource': canonical,
                'importLine': foreign['line'],
                'literalToken': foreign['token'],
                'sourcePath': str(resource_source),
                'stageRelativePath': resource_stage_rel,
                'stagePath': str(resource_stage),
                'sourceBytes': regular_bytes(resource_source),
            })
        relocated, edits = rewrite_imports(origin, original, destinations)
        target = STAGE / stage_rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(relocated)
        # Reverse only the recorded import-token substitutions and require exact bytes.
        restored = relocated.decode('utf-8').splitlines(keepends=True)
        by_line = {edit['line']: edit for edit in edits}
        reconstructed = []
        for number, line in enumerate(restored, 1):
            edit = by_line.get(number)
            if edit is None:
                reconstructed.append(line)
                continue
            relocated_token = edit['stageToken']
            reconstructed.append(line.replace(relocated_token, edit['sourceToken'], 1))
        if ''.join(reconstructed).encode('utf-8') != original:
            raise SystemExit(f'import-only reverse normalization failed: {canonical}')
        row = {
            'canonicalSource': canonical,
            'canonicalSourceSHA256': sha(regular_bytes(canonical)),
            'contentSource': str(origin.resolve()),
            'contentSourceSHA256': sha(original),
            'stageRelativePath': stage_rel,
            'stageAbsolutePath': str(target),
            'stageSHA256': sha(relocated),
            'importRelocations': edits,
            'importOnlyReconstructionSHA256': sha(original),
            'reconstructionMatchesContentSource': True,
        }
        rows.append(row)

    # FFI imports are indented inside their owning defs, so they must retain
    # their literal relative paths. Copy only those compiler inputs beside the
    # relocated module; do not rewrite or fold them into the Bend source map.
    foreign_resources = {}
    for edge in foreign_edges:
        resource_rel = edge['stageRelativePath']
        prior = foreign_resources.get(resource_rel)
        current = {
            'sourcePath': edge['sourcePath'],
            'sourceSHA256': sha(edge['sourceBytes']),
            'stageRelativePath': resource_rel,
            'stagePath': edge['stagePath'],
            'stageSHA256': sha(edge['sourceBytes']),
        }
        if prior is not None and prior != current:
            raise SystemExit(f'conflicting FFI resource mapping: {resource_rel}')
        foreign_resources[resource_rel] = current
    for resource_rel, resource in sorted(foreign_resources.items()):
        target = STAGE / resource_rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(regular_bytes(resource['sourcePath']))
        if sha(regular_bytes(target)) != resource['sourceSHA256']:
            raise SystemExit(f'FFI resource copy differs: {resource_rel}')

    semantic_changes = []
    for canonical, origin in source_origins.items():
        if canonical not in PRIVATE:
            if regular_bytes(origin) != regular_bytes(canonical):
                raise SystemExit(f'noncandidate source body differs from current master: {canonical}')
            continue
        base_body = imports_removed(regular_bytes(canonical))
        candidate_body = imports_removed(regular_bytes(origin))
        if base_body != candidate_body:
            semantic_changes.append({
                'canonicalSource': canonical,
                'currentMasterSHA256': sha(regular_bytes(canonical)),
                'privateCandidateSource': str(origin.resolve()),
                'privateCandidateSHA256': sha(regular_bytes(origin)),
                'currentMasterNonImportSHA256': sha(base_body),
                'privateCandidateNonImportSHA256': sha(candidate_body),
                'scope': 'private candidate body delta; all imports are independently mapped above',
            })
    if {row['canonicalSource'] for row in semantic_changes} != set(PRIVATE):
        raise SystemExit('semantic body delta must be exactly the three authorized private core files')

    check_receipt = OUT / 'source-check-v2/receipt.json'
    predecessor_check_receipt = OUT / 'source-check/receipt.json'
    source_check = {'path': str(check_receipt), 'sha256': sha(regular_bytes(check_receipt))}
    predecessor_source_check = {
        'path': str(predecessor_check_receipt),
        'sha256': sha(regular_bytes(predecessor_check_receipt)),
        'scope': 'preserved pre-stage root-source check; not the candidate-closure check',
    }
    payload = {
        'format': 'inspector55-source-stage-v1',
        'baseRuntime04Plan': str(BASE_PLAN),
        'baseRuntime04PlanSHA256': sha(regular_bytes(BASE_PLAN)),
        'originalClosureCount': len(inventory),
        'stageRoot': str(STAGE),
        'entrypointCanonicalSource': base['entrypoint'],
        'entrypointStagePath': str(STAGE / destinations[base['entrypoint']]),
        'predecessorSourceCheckReceipt': predecessor_source_check,
        'sourceCheckReceipt': source_check,
        'foreignImportEdges': [
            {k: v for k, v in edge.items() if k != 'sourceBytes'}
            for edge in foreign_edges
        ],
        'foreignResources': [value for _, value in sorted(foreign_resources.items())],
        'privateSemanticBodyChanges': semantic_changes,
        'rows': rows,
    }
    MAP.write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n')
    print('stage files', len(rows))
    print('source map sha256', sha(regular_bytes(MAP)))
    print('semantic body deltas', len(semantic_changes))


if __name__ == '__main__':
    main()
