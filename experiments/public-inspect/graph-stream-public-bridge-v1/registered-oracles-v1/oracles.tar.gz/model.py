"""Independent complete source model. No actual compiler/runtime outputs are inputs."""
from pathlib import Path
import json,os,types,gzip,hashlib
HERE=Path(__file__).resolve().parent
SUBJECT=Path('/workspace/formal-proofs/bendvy-worktrees/graph-stream-public-bridge-v1/experiments/public-inspect/graph-stream-public-bridge-v1')
CORE=Path('/workspace/formal-proofs/bendvy/src/ecs')
base=types.ModuleType('original');exec(compile((HERE/'original-model.py.source').read_bytes(),str(HERE/'original-model.py.source'),'exec'),base.__dict__)
ctr,ls,text=base.ctr,base.ls,base.text
ACCESS=['Flow','Link','LinkedBy','Parent','Children']
def world(ns,seed,clock=13,registered=False):
 value=base.world(ns,seed)
 if registered:
  value=value.replace('regs=[1:Existing:[Flow, Link]],nextSystem=2','regs=[2:CommittedFlowAndRelations:[Flow, Link, LinkedBy, Parent, Children], 1:Existing:[Flow, Link]],nextSystem=3')
 return value.replace('clock=13)',f'clock={clock})')
def named(root,module,constructor):return os.path.relpath(CORE/(module+'.bend'),root)[:-5]+'.'+constructor
def observation(root,ns,swap=False,local_consumer='consumer',foreign=False):
 def n(module,constructor):return named(root,module,constructor)
 def handle(i):return ctr(n('world','Handle'),str(ns),str(i))
 rows=[]
 for entity in [1,2,3]:
  cells=[]
  for key,end,incoming,hierarchy in [('link','Outgoing',False,False),('linkedBy','Incoming',True,False),('parent','Outgoing',False,True),('children','Incoming',True,True)]:
   if not incoming and entity in [1,3]:v=ctr(n('relation-query','Target'),handle(2))
   elif incoming and entity==2:v=ctr(n('relation-query','Sources'),ls([handle(i) for i in ([1,3] if hierarchy else [3,1])]))
   else:v=ctr(n('relation-query','Missing'))
   cells.append(ctr(n('relation-query','Cell'),text(key),ctr(n('relation-query',end)),v))
  if swap:cells[0],cells[1]=cells[1],cells[0]
  rows.append(ctr(n('inspector-query','ProjectedRow'),handle(entity),ctr(n('inspector-query-projection','Product'),ctr('Unit'),ls(cells))))
 return ctr(local_consumer+'.Observation','19',ctr(n('machine','Current'),'7'),ctr(n('machine','Current'),'11'),ls(rows),*([ctr('Fail',ctr(n('inspector-query','MissingEntity'),'2'))] if foreign else []))
def registered(ns,seed):
 root=SUBJECT/'registered-v2';w=text(world(ns,seed,registered=True));o=ctr('consumer.Observed','0',observation(root,ns,local_consumer='../consumer'))
 return ctr('Some',ctr('consumer.Report',w,o,w,o,w,str(ns),'2',text('CommittedFlowAndRelations'),ls([text(x) for x in ACCESS]),ctr('Some',ctr('Done',ctr('True'))),'13',w))+'\n'
def reached(kind):
 root=SUBJECT/'reached-controls-v2'/kind;clock=kind=='noninterference-mutant';swap=kind=='routing-swap-mutant'
 w0=text(world(31,100));w1=text(world(31,100,15 if clock else 13));w2=text(world(31,100,17 if clock else 13));o=observation(root,31,swap)
 return ctr('consumer.Report',w0,o,w1,o,w2,ctr('Done',ctr('True')),w2)+'\n'
def foreign(ns,seed):
 root=SUBJECT/'runtime-controls-v2';w=text(world(ns,seed));o=observation(root,ns,foreign=True)
 return ctr('consumer.Report',w,o,w,o,w,ctr('Done',ctr('True')),w)+'\n'
def generate():
 outputs={'workshop-registered':registered(31,100),'garden-registered':registered(47,200),'namespace-normal':reached('namespace-normal'),'noninterference-mutant':reached('noninterference-mutant'),'routing-swap-mutant':reached('routing-swap-mutant'),'workshop-foreign':foreign(31,100),'garden-foreign':foreign(47,200)}
 catalogue={}
 for name,value in outputs.items():
  raw=value.encode();path=HERE/(name+'.stdout');path.write_bytes(raw);packed=HERE/(name+'.stdout.gz');packed.write_bytes(gzip.compress(raw,mtime=0))
  entry=SUBJECT/'registered-v2'/('entry-workshop.bend' if name.startswith('workshop') else 'entry-garden.bend') if name.endswith('registered') else SUBJECT/'reached-controls-v2'/name/'entry-workshop.bend'
  if name.endswith('foreign'):entry=SUBJECT/'runtime-controls-v2'/('entry-workshop.bend' if name.startswith('workshop') else 'entry-garden.bend')
  catalogue[name]={'path':str(packed),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'entrypoint':str(entry),'countermodelRejectsNormal':name.endswith('mutant') and value!=outputs['namespace-normal']}
 normal=catalogue['namespace-normal']
 for key in ['noninterference-mutant','routing-swap-mutant']:
  catalogue[key].update({'normalOracle':normal['path'],'normalOracleBytes':normal['bytes'],'normalOracleSHA256':normal['sha256']})
 (HERE/'ORACLES.json').write_text(json.dumps(catalogue,indent=2)+'\n')
 return catalogue
if __name__=='__main__':print(json.dumps(generate(),indent=2))
