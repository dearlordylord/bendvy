function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return {$: "Tuple", "fst": run_loop($consumer$058scenario$1260$(31, 100)), "snd": run_loop($consumer$058scenario$1261$(47, 200))};
}

function $consumer$058scenario$1260$(_namespace_0, _base_0) {
  return $consumer$058installed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058install$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(($fixture$058world$1260$(_namespace_0, _base_0)))))));
}

function $consumer$058scenario$1261$(_namespace_0, _base_0) {
  return $consumer$058installed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058install$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1261$(($fixture$058world$1261$(_namespace_0, _base_0)))))));
}

function $consumer$058installed$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  return $consumer$058sequence$1260$({$: "Con", "head": run_clo((_x_0) => {
  return $consumer$058action$1260$(1, "link_absent_out", _x_0);
}), "tail": {$: "Con", "head": run_clo((_x_1) => {
  return $consumer$058action$1261$(1, "parent_absent_out", _x_1);
}), "tail": {$: "Nil"}}}, "", {$: "consumer.Context", "world": _world_0, "instance": {$: "../../../../../../../../bendvy/src/ecs/inspector.Fresh"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058install$1260$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented_install$1260$(_app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $fixture$058world$1260$(_namespace_0, _base_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 4, "highWater": 3, "live": array_node(array_node([false], [true]), array_node([true], [true])), "capacity": 4, "depth": 2, "store": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": {$: "state.Components", "cells": array_node([_base_0], [((_base_0 + 2) >>> 0)])}, "graph": ($fixture$058graph$1260$())}, "resource": ($fixture$058resources$1260$(_base_0)), "events": ($fixture$058notices$1260$()), "pending": {$: "Con", "head": run_clo((_x_0) => {
  return $fixture$058command$1260$(_x_0);
}), "tail": {$: "Nil"}}, "registrations": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": 1, "name": "Existing", "access": {$: "Con", "head": "Flow", "tail": {$: "Con", "head": "Link", "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}, "nextSystemId": 2, "clock": 13};
}

function $consumer$058installed$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  return $consumer$058sequence$1261$({$: "Con", "head": run_clo((_x_0) => {
  return $consumer$058action$1262$(1, "link_absent_out", _x_0);
}), "tail": {$: "Con", "head": run_clo((_x_1) => {
  return $consumer$058action$1263$(1, "parent_absent_out", _x_1);
}), "tail": {$: "Nil"}}}, "", {$: "consumer.Context", "world": _world_0, "instance": {$: "../../../../../../../../bendvy/src/ecs/inspector.Fresh"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058install$1261$(_app_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented_install$1261$(_app_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045composer$058empty$1261$(_world_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $fixture$058world$1261$(_namespace_0, _base_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 4, "highWater": 3, "live": array_node(array_node([false], [true]), array_node([true], [true])), "capacity": 4, "depth": 2, "store": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": {$: "state.Components", "cells": array_node([_base_0], [((_base_0 + 2) >>> 0)])}, "graph": ($fixture$058graph$1261$())}, "resource": ($fixture$058resources$1261$(_base_0)), "events": ($fixture$058notices$1261$()), "pending": {$: "Con", "head": run_clo((_x_0) => {
  return $fixture$058command$1261$(_x_0);
}), "tail": {$: "Nil"}}, "registrations": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": 1, "name": "Existing", "access": {$: "Con", "head": "Flow", "tail": {$: "Con", "head": "Link", "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}, "nextSystemId": 2, "clock": 13};
}

function $consumer$058sequence$1260$(_actions_0, _prefix_0, _context_0) {
  if (_actions_0.$ === "Nil") {
    return _prefix_0;
  } else {
    const _first_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return $consumer$058joined$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  const _x_2 = (_x_1 + "\n");
  return $consumer$058sequence$1260$(_rest_0, (_prefix_0 + _x_2), _x_0);
});
}), _first_0(_context_0));
  }
}

function $consumer$058action$1260$(_expected_0, _name_0, _context_0) {
  const _world_0 = _context_0["world"];
  const _instance_0 = _context_0["instance"];
  return $consumer$058before$1260$(_expected_0, _name_0, _instance_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058action$1261$(_expected_0, _name_0, _context_0) {
  const _world_0 = _context_0["world"];
  const _instance_0 = _context_0["instance"];
  return $consumer$058before$1261$(_expected_0, _name_0, _instance_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented_install$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _debug_0 = _app_0["debug"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $fixture$058graph$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058link$1260$()), "source": 1, "target": 2}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058link$1260$()), "source": 3, "target": 2}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058parent$1260$()), "source": 1, "target": 2}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058parent$1260$()), "source": 3, "target": 2}, "tail": {$: "Nil"}}}}}, "inverses": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": ($declarations$058link$1260$()), "target": 2, "sources": {$: "Con", "head": 3, "tail": {$: "Con", "head": 1, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": ($declarations$058parent$1260$()), "target": 2, "sources": {$: "Con", "head": 1, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}}};
}

function $fixture$058resources$1260$(_base_0) {
  return {$: "state.Resources", "owned": array_node([_base_0], [((_base_0 + 1) >>> 0)]), "flow": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": 7, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": 9, "skipSame": false}, "previous": {$: "Some", "value": 4}, "changed": true}, "level": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": 11, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": 12, "skipSame": true}, "previous": {$: "Some", "value": 10}, "changed": false}, "ran": 0, "flowStream": ($fixture$058stream$()), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$())};
}

function $fixture$058notices$1260$() {
  return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": 17}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Failure", "relation": ($declarations$058parent$1260$()), "operation": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Relate"}, "source": 2, "target": 3, "error": {$: "../../../../../../../../bendvy/src/ecs/relation-types.HierarchyCycle", "source": 2, "target": 3, "relation": "Parent"}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": 23}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused", "frames": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": 3}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors", "id": 3, "remaining": {$: "Con", "head": ($declarations$058link$1260$()), "tail": {$: "Con", "head": ($declarations$058parent$1260$()), "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": 3, "descriptor": ($declarations$058parent$1260$()), "remainingDescriptors": {$: "Con", "head": ($declarations$058link$1260$()), "tail": {$: "Nil"}}, "remainingChildren": {$: "Con", "head": 1, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupFinish", "id": 3}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Nil"}}}}};
}

function $fixture$058command$1260$(_world_0) {
  return $fixture$058clocked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
}

function $consumer$058sequence$1261$(_actions_0, _prefix_0, _context_0) {
  if (_actions_0.$ === "Nil") {
    return _prefix_0;
  } else {
    const _first_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return $consumer$058joined$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  const _x_2 = (_x_1 + "\n");
  return $consumer$058sequence$1261$(_rest_0, (_prefix_0 + _x_2), _x_0);
});
}), _first_0(_context_0));
  }
}

function $consumer$058action$1262$(_expected_0, _name_0, _context_0) {
  const _world_0 = _context_0["world"];
  const _instance_0 = _context_0["instance"];
  return $consumer$058before$1262$(_expected_0, _name_0, _instance_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058action$1263$(_expected_0, _name_0, _context_0) {
  const _world_0 = _context_0["world"];
  const _instance_0 = _context_0["instance"];
  return $consumer$058before$1263$(_expected_0, _name_0, _instance_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058presented_install$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _debug_0 = _app_0["debug"];
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": {$: "../../../../../../../../bendvy/src/ecs/ordinary-app-recipe.Recipe"}, "debug": _debug_0};
}

function $fixture$058graph$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058link$1261$()), "source": 1, "target": 2}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058link$1261$()), "source": 3, "target": 2}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058parent$1261$()), "source": 1, "target": 2}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Edge", "relation": ($declarations$058parent$1261$()), "source": 3, "target": 2}, "tail": {$: "Nil"}}}}}, "inverses": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": ($declarations$058link$1261$()), "target": 2, "sources": {$: "Con", "head": 3, "tail": {$: "Con", "head": 1, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": ($declarations$058parent$1261$()), "target": 2, "sources": {$: "Con", "head": 1, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}}};
}

function $fixture$058resources$1261$(_base_0) {
  return {$: "state.Resources", "owned": array_node([_base_0], [((_base_0 + 1) >>> 0)]), "flow": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": 7, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": 9, "skipSame": false}, "previous": {$: "Some", "value": 4}, "changed": true}, "level": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": 11, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": 12, "skipSame": true}, "previous": {$: "Some", "value": 10}, "changed": false}, "ran": 0, "flowStream": ($fixture$058stream$()), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$())};
}

function $fixture$058notices$1261$() {
  return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Original", "event": 17}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Failure", "relation": ($declarations$058parent$1261$()), "operation": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Relate"}, "source": 2, "target": 3, "error": {$: "../../../../../../../../bendvy/src/ecs/relation-types.HierarchyCycle", "source": 2, "target": 3, "relation": "Parent"}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": 23}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.CleanupPaused", "frames": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": 3}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors", "id": 3, "remaining": {$: "Con", "head": ($declarations$058link$1261$()), "tail": {$: "Con", "head": ($declarations$058parent$1261$()), "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": 3, "descriptor": ($declarations$058parent$1261$()), "remainingDescriptors": {$: "Con", "head": ($declarations$058link$1261$()), "tail": {$: "Nil"}}, "remainingChildren": {$: "Con", "head": 1, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-types.CleanupFinish", "id": 3}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Nil"}}}}};
}

function $fixture$058command$1261$(_world_0) {
  return $fixture$058clocked$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
}

function $consumer$058joined$1260$(_next_0, _result_0) {
  const _context_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return run_tail(_next_0(_context_0), _text_0);
}

function $consumer$058before$1260$(_expected_0, _name_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("\nBefore=" + _x_0);
  return $consumer$058first$1260$(_expected_0, (_name_0 + _x_1), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1260$(_instance_0, {$: "Unit"}, _world_0)));
}

function $dump$058world$1260$(_world_0) {
  return $dump$058counted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $consumer$058before$1261$(_expected_0, _name_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("\nBefore=" + _x_0);
  return $consumer$058first$1261$(_expected_0, (_name_0 + _x_1), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1261$(_instance_0, {$: "Unit"}, _world_0)));
}

function $declarations$058link$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Ordinary"}};
}

function $declarations$058parent$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Hierarchy"}};
}

function $fixture$058stream$() {
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": 2, "values": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/machine.Transition", "from": 4, "to": 7}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": 3, "values": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/machine.Transition", "from": 7, "to": 8}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/machine.Transition", "from": 8, "to": 7}, "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}}, "positions": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": 5, "cursor": 1, "registeredAt": 1}, "tail": {$: "Nil"}}, "droppedThrough": 0, "frameStart": 2};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $fixture$058clocked$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058joined$1261$(_next_0, _result_0) {
  const _context_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return run_tail(_next_0(_context_0), _text_0);
}

function $consumer$058before$1262$(_expected_0, _name_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("\nBefore=" + _x_0);
  return $consumer$058first$1262$(_expected_0, (_name_0 + _x_1), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1262$(_instance_0, {$: "Unit"}, _world_0)));
}

function $dump$058world$1261$(_world_0) {
  return $dump$058counted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0)));
}

function $consumer$058before$1263$(_expected_0, _name_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("\nBefore=" + _x_0);
  return $consumer$058first$1263$(_expected_0, (_name_0 + _x_1), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1263$(_instance_0, {$: "Unit"}, _world_0)));
}

function $declarations$058link$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Ordinary"}};
}

function $declarations$058parent$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../../../../../bendvy/src/ecs/relation-types.Hierarchy"}};
}

function $fixture$058clocked$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058first$1260$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("FirstRows=" + _x_1);
  return $consumer$058first_instance$1260$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1260$(_instance_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1260$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1260$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1260$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $dump$058counted$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1260$(_count_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $consumer$058first$1261$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("FirstRows=" + _x_1);
  return $consumer$058first_instance$1261$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1260$(_instance_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1261$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1261$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1261$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $consumer$058first$1262$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("FirstRows=" + _x_1);
  return $consumer$058first_instance$1262$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1261$(_instance_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1262$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1262$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1262$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $dump$058counted$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $dump$058resourced$1261$(_count_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $consumer$058first$1263$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("FirstRows=" + _x_1);
  return $consumer$058first_instance$1263$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1261$(_instance_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1263$(_instance_0, _args_0, _world_0) {
  if (_instance_0.$ === "../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1263$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)));
  } else {
    const _cursor_0 = _instance_0["cursor"];
    const _registeredAt_0 = _instance_0["registeredAt"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1263$(_args_0, _cursor_0, _registeredAt_0, _world_0);
  }
}

function $consumer$058first_instance$1260$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("FirstCursor=" + _x_0);
  return $consumer$058after_first$1260$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058inspected$(_value_0) {
  if (_value_0.$ === "Done") {
    const _text_0 = _value_0["value"];
    return _text_0;
  } else {
    return "InspectorFailure";
  }
}

function $consumer$058instance_text$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, "snd": "Fresh"};
  } else {
    const _cursor_0 = _value_0["cursor"];
    const _registeredAt_0 = _value_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = ($U32$show$(_cursor_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "snd": ("Active:" + _x_3)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1260$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1260$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1260$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058invoked$1260$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1261$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $dump$058resourced$1260$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1260$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $dump$058store$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($dump$058resources$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $consumer$058first_instance$1261$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("FirstCursor=" + _x_0);
  return $consumer$058after_first$1261$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1261$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1261$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1261$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058invoked$1260$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1263$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $consumer$058first_instance$1262$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("FirstCursor=" + _x_0);
  return $consumer$058after_first$1262$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1261$(_world_0)));
}

function $consumer$058instance_text$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/inspector.Fresh") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Fresh"}, "snd": "Fresh"};
  } else {
    const _cursor_0 = _value_0["cursor"];
    const _registeredAt_0 = _value_0["registeredAt"];
    const _x_0 = ($U32$show$(_registeredAt_0));
    const _x_1 = ($U32$show$(_cursor_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "snd": ("Active:" + _x_3)};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1262$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1262$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1262$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058invoked$1261$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1265$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $dump$058resourced$1261$(_pendingCount_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058stored$1261$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $dump$058store$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(($dump$058resources$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $consumer$058first_instance$1263$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("FirstCursor=" + _x_0);
  return $consumer$058after_first$1263$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058first$1263$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registeredAt_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1263$(_args_0, 0, _registeredAt_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058initialized$1263$(_args_0, _cursor_0, _registeredAt_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058invoked$1261$(_cursor_0, _registeredAt_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1267$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})));
}

function $consumer$058after_first$1260$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058second$1260$(_expected_0, (_prefix_0 + _x_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1260$(_instance_0, {$: "Unit"}, _world_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058invoked$1260$(_cursor_0, _registeredAt_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058finished$1260$(_cursor_0, _registeredAt_0, _frame_0, _result_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1261$(_args_0, _ctx_0) {
  return $consumer$058inspect_body$1260$(_args_0, _ctx_0);
}

function $dump$058stored$1260$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058store$1260$(_value_0) {
  const _owner_0 = _value_0["components"];
  const _relations_0 = _value_0["graph"];
  return $dump$058store_done$1260$(_relations_0, ($dump$058components$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $dump$058resource_done$1260$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($dump$058tree$1261$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $consumer$058after_first$1261$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058second$1261$(_expected_0, (_prefix_0 + _x_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1261$(_instance_0, {$: "Unit"}, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1263$(_args_0, _ctx_0) {
  return $consumer$058inspect_body$1261$(_args_0, _ctx_0);
}

function $consumer$058after_first$1262$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058second$1262$(_expected_0, (_prefix_0 + _x_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1262$(_instance_0, {$: "Unit"}, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058invoked$1261$(_cursor_0, _registeredAt_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058finished$1261$(_cursor_0, _registeredAt_0, _frame_0, _result_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1265$(_args_0, _ctx_0) {
  return $consumer$058inspect_body$1262$(_args_0, _ctx_0);
}

function $dump$058stored$1261$(_pendingCount_0, _resourceText_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _storeText_0 = _result_0["snd"];
  return $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $dump$058store$1261$(_value_0) {
  const _owner_0 = _value_0["components"];
  const _relations_0 = _value_0["graph"];
  return $dump$058store_done$1261$(_relations_0, ($dump$058components$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058resources$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _ran_0 = _resources_0["ran"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  return $dump$058resource_done$1261$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, ($dump$058tree$1261$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $consumer$058after_first$1263$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058second$1263$(_expected_0, (_prefix_0 + _x_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058run$1263$(_instance_0, {$: "Unit"}, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1267$(_args_0, _ctx_0) {
  return $consumer$058inspect_body$1263$(_args_0, _ctx_0);
}

function $consumer$058second$1260$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("SecondRows=" + _x_1);
  return $consumer$058second_instance$1260$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1260$(_instance_0)));
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058finished$1260$(_cursor_0, _registeredAt_0, _frame_0, _result_0) {
  const _world_0 = _frame_0["world"];
  if (_result_0.$ === "Fail") {
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058succeeded$1260$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $consumer$058inspect_body$1260$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1261$(_owner_0)));
}

function $dump$058live$1260$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1260$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058store_done$1260$(_relations_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($dump$058graph$1260$(_relations_0));
  const _x_1 = (";graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _relations_0}, "snd": (_text_0 + _x_1)};
}

function $dump$058components$1260$(_value_0) {
  const _cells_0 = _value_0["cells"];
  return $dump$058component_done$1260$(($dump$058tree$1261$(_cells_0)));
}

function $dump$058resource_done$1260$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _result_0) {
  const _owned_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($dump$058stream$(_levelStream_0));
  const _x_1 = ($dump$058stream$(_flowStream_0));
  const _x_2 = (";" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ran_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058slot$1261$(_level_0));
  const _x_8 = (";ran=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058slot$1260$(_flow_0));
  const _x_11 = (";" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";" + _x_12);
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": (_text_0 + _x_13)};
}

function $dump$058tree$1261$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1261$(($dump$058u32$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1261$(($dump$058tree$1261$(_b_0)), ($dump$058tree$1261$(_a_0)));
  }
}

function $consumer$058second$1261$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("SecondRows=" + _x_1);
  return $consumer$058second_instance$1261$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1260$(_instance_0)));
}

function $consumer$058inspect_body$1261$(__0, _owner_0) {
  return $consumer$058inspect_rows$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1263$(_owner_0)));
}

function $consumer$058second$1262$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("SecondRows=" + _x_1);
  return $consumer$058second_instance$1262$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1261$(_instance_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058finished$1261$(_cursor_0, _registeredAt_0, _frame_0, _result_0) {
  const _world_0 = _frame_0["world"];
  if (_result_0.$ === "Fail") {
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Fail", "error": _error_0}};
  } else {
    const _value_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058succeeded$1261$(_registeredAt_0, _value_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $consumer$058inspect_body$1262$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1265$(_owner_0)));
}

function $dump$058live$1261$(_pendingCount_0, _resourceText_0, _storeText_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, ($dump$058tree$1260$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $dump$058store_done$1261$(_relations_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($dump$058graph$1261$(_relations_0));
  const _x_1 = (";graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _relations_0}, "snd": (_text_0 + _x_1)};
}

function $dump$058components$1261$(_value_0) {
  const _cells_0 = _value_0["cells"];
  return $dump$058component_done$1261$(($dump$058tree$1261$(_cells_0)));
}

function $dump$058resource_done$1261$(_flow_0, _level_0, _ran_0, _flowStream_0, _levelStream_0, _result_0) {
  const _owned_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($dump$058stream$(_levelStream_0));
  const _x_1 = ($dump$058stream$(_flowStream_0));
  const _x_2 = (";" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ran_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058slot$1263$(_level_0));
  const _x_8 = (";ran=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058slot$1262$(_flow_0));
  const _x_11 = (";" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";" + _x_12);
  return {$: "Tuple", "fst": {$: "state.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "ran": _ran_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0}, "snd": (_text_0 + _x_13)};
}

function $consumer$058second$1263$(_expected_0, _prefix_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  const _instance_0 = _observed_0["instance"];
  const _value_0 = _observed_0["result"];
  const _x_0 = ($consumer$058inspected$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("SecondRows=" + _x_1);
  return $consumer$058second_instance$1263$(_expected_0, (_prefix_0 + _x_2), _world_0, ($consumer$058instance_text$1261$(_instance_0)));
}

function $consumer$058inspect_body$1263$(__0, _owner_0) {
  return $consumer$058inspect_rows$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1267$(_owner_0)));
}

function $consumer$058second_instance$1260$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("SecondCursor=" + _x_0);
  return $consumer$058after_second$1260$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1260$(_world_0)));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058succeeded$1260$(_registeredAt_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $consumer$058inspect_rows$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": ($List$show$12611$(_rows_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1261$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058plan_caps$1260$(($consumer$058inspect_plan$1260$()))))), _owner_0);
}

function $dump$058finished$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1268$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1265$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = ("," + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("," + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = ("," + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058tree$1260$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $dump$058leaf$1260$(($dump$058boolean$(_value_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $dump$058tree_left$1260$(($dump$058tree$1260$(_b_0)), ($dump$058tree$1260$(_a_0)));
  }
}

function $dump$058graph$1260$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($List$show$12610$(_inverses_0));
  const _x_1 = ($List$show$1269$(_edges_0));
  const _x_2 = (";" + _x_0);
  return (_x_1 + _x_2);
}

function $dump$058component_done$1260$(_result_0) {
  const _cells_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "state.Components", "cells": _cells_0}, "snd": _text_0};
}

function $dump$058slot$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058slot$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058stream$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _start_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_start_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($Nat$show$(_dropped_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1263$(_positions_0));
  const _x_6 = ("," + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($List$show$1262$(_batches_0));
  const _x_9 = ("," + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("stream(" + _x_10);
}

function $dump$058leaf$1261$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058u32$(_value_0) {
  return $dump$058u32_value$(_value_0);
}

function $dump$058tree_left$1261$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1261$(_a_0, _text_0, _b_0);
}

function $consumer$058second_instance$1261$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("SecondCursor=" + _x_0);
  return $consumer$058after_second$1261$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1263$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058plan_caps$1260$(($consumer$058inspect_plan$1261$()))))), _owner_0);
}

function $consumer$058second_instance$1262$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("SecondCursor=" + _x_0);
  return $consumer$058after_second$1262$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058succeeded$1261$(_registeredAt_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cursor_0 = _observed_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/inspector.Observed", "world": _world_0, "instance": {$: "../../../../../../../../bendvy/src/ecs/inspector.Active", "cursor": _cursor_0, "registeredAt": _registeredAt_0}, "result": {$: "Done", "value": _value_0}};
}

function $consumer$058inspect_rows$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": ($List$show$12619$(_rows_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1265$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058plan_caps$1261$(($consumer$058inspect_plan$1262$()))))), _owner_0);
}

function $dump$058finished$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _store_0, _resources_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0, _pendingCount_0, _resourceText_0, _storeText_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + ")");
  const _x_2 = ($U32$show$(_nextSystem_0));
  const _x_3 = (",clock=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1268$(_registrations_0));
  const _x_6 = (",nextSystem=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_pendingCount_0));
  const _x_9 = (",regs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$12614$(_events_0));
  const _x_12 = (",pending=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events=" + _x_13);
  const _x_15 = (_resourceText_0 + _x_14);
  const _x_16 = ("," + _x_15);
  const _x_17 = (_storeText_0 + _x_16);
  const _x_18 = ($Nat$show$(_depth_0));
  const _x_19 = ("," + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_capacity_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ("," + _x_23);
  const _x_25 = (_text_0 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = ("," + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = ("," + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = ("," + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("world(" + _x_34)};
}

function $dump$058graph$1261$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($List$show$12618$(_inverses_0));
  const _x_1 = ($List$show$12617$(_edges_0));
  const _x_2 = (";" + _x_0);
  return (_x_1 + _x_2);
}

function $dump$058component_done$1261$(_result_0) {
  const _cells_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "state.Components", "cells": _cells_0}, "snd": _text_0};
}

function $dump$058slot$1262$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $dump$058slot$1263$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _old_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($dump$058previous$(_old_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($dump$058pending$(_next_0));
    const _x_6 = ("," + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($U32$show$(_current_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("slot(" + _x_10);
  }
}

function $consumer$058second_instance$1263$(_expected_0, _prefix_0, _world_0, _observed_0) {
  const _instance_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ("SecondCursor=" + _x_0);
  return $consumer$058after_second$1263$(_expected_0, (_prefix_0 + _x_1), _instance_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1267$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058plan_caps$1261$(($consumer$058inspect_plan$1263$()))))), _owner_0);
}

function $consumer$058after_second$1260$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058first_check$1260$(_expected_0, (_prefix_0 + _x_0), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1260$(_expected_0, _world_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1261$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058plan_caps$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $consumer$058inspect_plan$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1260$())};
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058leaf$1260$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $dump$058boolean$(_value_0) {
  return $dump$058boolean_value$(_value_0);
}

function $dump$058tree_left$1260$(_b_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $dump$058tree_join$1260$(_a_0, _text_0, _b_0);
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058pending$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($U32$show$(_value_1));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("next(" + _x_4);
  }
}

function $dump$058previous$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058batch$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058position$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058u32_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $dump$058tree_join$1261$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $consumer$058after_second$1261$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058first_check$1261$(_expected_0, (_prefix_0 + _x_0), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1261$(_expected_0, _world_0)));
}

function $consumer$058inspect_plan$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1261$())};
}

function $consumer$058after_second$1262$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058first_check$1262$(_expected_0, (_prefix_0 + _x_0), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1262$(_expected_0, _world_0)));
}

function $List$show$12619$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1261$(_h_0));
    const _x_1 = ($List$show$go$12621$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1263$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$058plan_caps$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $consumer$058inspect_plan$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1262$())};
}

function $List$show$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1261$(_h_0));
    const _x_1 = ($List$show$go$12616$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1261$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12618$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12618$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058after_second$1263$(_expected_0, _prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + "\n");
  return $consumer$058first_check$1263$(_expected_0, (_prefix_0 + _x_0), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1263$(_expected_0, _world_0)));
}

function $consumer$058inspect_plan$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector.Plan", "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1263$())};
}

function $consumer$058first_check$1260$(_expected_0, _prefix_0, _instance_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _value_0 = _result_0["result"];
  const _x_0 = ($consumer$058checked$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("CheckFirst=" + _x_1);
  return $consumer$058second_check$1260$((_prefix_0 + _x_2), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1260$(_expected_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1260$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1260$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1260$(($consumer$058condition_plan$1260$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_value_0) {
  const _entity_0 = _value_0["entity"];
  const _t_0 = _value_0["data"];
  const _cells_0 = _t_0["right"];
  const _x_0 = ($List$show$12612$(_cells_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_entity_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1260$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1260$();
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $dump$058notice$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    const _x_0 = ($U32$show$(_value_1));
    return ("user:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    const _value_2 = _value_0["failure"];
    const _x_1 = ($dump$058failure$1260$(_value_2));
    return ("relationFailed:" + _x_1);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_0));
    return ("componentRemoved:" + _x_2);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_3 = ($List$show$1266$(_frames_0));
    return ("cleanupPaused:" + _x_3);
  }
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1264$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058registration$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $dump$058tree_join$1260$(_a_0, _text_0, _result_0) {
  const _b_0 = _result_0["fst"];
  const _other_0 = _result_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $dump$058edge$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1260$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058inverse$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($List$show$1260$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1260$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058batch$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _items_0 = _value_0["values"];
  const _x_0 = ($List$show$1261$(_items_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058batch$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058position$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058first_check$1261$(_expected_0, _prefix_0, _instance_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _value_0 = _result_0["result"];
  const _x_0 = ($consumer$058checked$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("CheckFirst=" + _x_1);
  return $consumer$058second_check$1260$((_prefix_0 + _x_2), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1261$(_expected_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1261$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1261$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1260$(($consumer$058condition_plan$1261$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1261$();
}

function $consumer$058first_check$1262$(_expected_0, _prefix_0, _instance_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _value_0 = _result_0["result"];
  const _x_0 = ($consumer$058checked$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("CheckFirst=" + _x_1);
  return $consumer$058second_check$1261$((_prefix_0 + _x_2), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1262$(_expected_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1262$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1262$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1261$(($consumer$058condition_plan$1262$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1261$(_value_0) {
  const _entity_0 = _value_0["entity"];
  const _t_0 = _value_0["data"];
  const _cells_0 = _t_0["right"];
  const _x_0 = ($List$show$12620$(_cells_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_entity_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12621$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058builtin_row$1261$(_h_0));
    const _x_1 = ($List$show$go$12621$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1262$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1262$();
}

function $dump$058notice$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    const _x_0 = ($U32$show$(_value_1));
    return ("user:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.RelationFailed") {
    const _value_2 = _value_0["failure"];
    const _x_1 = ($dump$058failure$1261$(_value_2));
    return ("relationFailed:" + _x_1);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_2 = ($U32$show$(_id_0));
    return ("componentRemoved:" + _x_2);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_3 = ($List$show$12615$(_frames_0));
    return ("cleanupPaused:" + _x_3);
  }
}

function $List$show$go$12616$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058notice$1261$(_h_0));
    const _x_1 = ($List$show$go$12616$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058edge$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1261$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058edge$1261$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058inverse$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($List$show$1260$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($dump$058descriptor$1261$(_relation_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12618$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12618$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058first_check$1263$(_expected_0, _prefix_0, _instance_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _value_0 = _result_0["result"];
  const _x_0 = ($consumer$058checked$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("CheckFirst=" + _x_1);
  return $consumer$058second_check$1261$((_prefix_0 + _x_2), _instance_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1263$(_expected_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1263$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1263$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1261$(($consumer$058condition_plan$1263$())))(_world_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058inspect$1263$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1263$();
}

function $consumer$058second_check$1260$(_prefix_0, _instance_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _value_0 = _result_0["result"];
  const _x_0 = ($consumer$058checked$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("CheckSecond=" + _x_1);
  return $consumer$058complete$1260$((_prefix_0 + _x_2), _instance_0, ($dump$058world$1260$(_world_0)));
}

function $consumer$058checked$(_value_0) {
  if (_value_0.$ === "Done") {
    const _value_1 = _value_0["value"];
    return $Bool$show$(_value_1);
  } else {
    return "CheckFailure";
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1260$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1260$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $consumer$058condition_plan$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1260$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = ($U32$show$(_ns_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1261$();
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $dump$058failure$1260$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _op_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($dump$058relation_error$(_error_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_source_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058operation$(_op_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058descriptor$1260$(_relation_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1264$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $dump$058descriptor$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($dump$058relation_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverseName_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058transition$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1261$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1262$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1260$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1261$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1263$();
}

function $consumer$058second_check$1261$(_prefix_0, _instance_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _value_0 = _result_0["result"];
  const _x_0 = ($consumer$058checked$(_value_0));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("CheckSecond=" + _x_1);
  return $consumer$058complete$1261$((_prefix_0 + _x_2), _instance_0, ($dump$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1262$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1264$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1261$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $consumer$058condition_plan$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1262$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = ($U32$show$(_ns_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$12620$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1261$(_h_0));
    const _x_1 = ($List$show$go$12620$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1262$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1265$();
}

function $dump$058failure$1261$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _op_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($dump$058relation_error$(_error_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_source_0));
  const _x_5 = (":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($dump$058operation$(_op_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($dump$058descriptor$1261$(_relation_0));
  const _x_11 = (":" + _x_9);
  return (_x_10 + _x_11);
}

function $List$show$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1261$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $dump$058descriptor$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverseName_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($dump$058relation_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverseName_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1263$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1266$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $consumer$058condition_plan$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $consumer$058required$1261$(_x_0);
}), "caps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1263$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058grant$1263$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1267$();
}

function $consumer$058complete$1260$(_prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "consumer.Context", "world": _world_0, "instance": _instance_0}, "snd": (_prefix_0 + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _value_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $consumer$058condition_body$1260$(_args_0, _ctx_0);
}

function $consumer$058required$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _direction_0 = _value_0["end"];
  const _value_1 = _value_0["value"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058relation_value$1260$(_value_1));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058end$(_direction_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1260$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1261$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1261$(_x_1, _x_2);
});
})};
}

function $dump$058operation$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.Relate") {
    return "relate";
  } else {
    return "reorderChildren";
  }
}

function $dump$058relation_error$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.MissingEntity") {
    const _source_0 = _value_0["source"];
    const _x_0 = ($U32$show$(_source_0));
    return ("missingEntity:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.MissingTargetEntity") {
    const _source_1 = _value_0["source"];
    const _target_0 = _value_0["target"];
    const _relation_0 = _value_0["relation"];
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (":" + _relation_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_1));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("missingTarget:" + _x_6);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.SelfRelationNotAllowed") {
    const _source_2 = _value_0["source"];
    const _relation_1 = _value_0["relation"];
    const _x_7 = ($U32$show$(_source_2));
    const _x_8 = (":" + _relation_1);
    const _x_9 = (_x_7 + _x_8);
    return ("selfRelation:" + _x_9);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.HierarchyCycle") {
    const _source_3 = _value_0["source"];
    const _target_1 = _value_0["target"];
    const _relation_2 = _value_0["relation"];
    const _x_10 = ($U32$show$(_target_1));
    const _x_11 = (":" + _relation_2);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_source_3));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("hierarchyCycle:" + _x_15);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.MissingChildEntity") {
    const _source_4 = _value_0["source"];
    const _child_0 = _value_0["child"];
    const _relation_3 = _value_0["relation"];
    const _x_16 = ($U32$show$(_child_0));
    const _x_17 = (":" + _relation_3);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($U32$show$(_source_4));
    const _x_20 = (":" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    return ("missingChild:" + _x_21);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.DuplicateChild") {
    const _source_5 = _value_0["source"];
    const _child_1 = _value_0["child"];
    const _relation_4 = _value_0["relation"];
    const _x_22 = ($U32$show$(_child_1));
    const _x_23 = (":" + _relation_4);
    const _x_24 = (_x_22 + _x_23);
    const _x_25 = ($U32$show$(_source_5));
    const _x_26 = (":" + _x_24);
    const _x_27 = (_x_25 + _x_26);
    return ("duplicateChild:" + _x_27);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.ChildNotRelatedToParent") {
    const _source_6 = _value_0["source"];
    const _child_2 = _value_0["child"];
    const _relation_5 = _value_0["relation"];
    const _x_28 = ($U32$show$(_child_2));
    const _x_29 = (":" + _relation_5);
    const _x_30 = (_x_28 + _x_29);
    const _x_31 = ($U32$show$(_source_6));
    const _x_32 = (":" + _x_30);
    const _x_33 = (_x_31 + _x_32);
    return ("childNotRelated:" + _x_33);
  } else {
    const _source_7 = _value_0["source"];
    const _relation_6 = _value_0["relation"];
    const _x_34 = ($U32$show$(_source_7));
    const _x_35 = (":" + _relation_6);
    const _x_36 = (_x_34 + _x_35);
    return ("childSetMismatch:" + _x_36);
  }
}

function $dump$058cleanup$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_1 = ($List$show$1267$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _relation_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_5 = ($List$show$1260$(_children_0));
    const _x_6 = ($List$show$1267$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($dump$058descriptor$1260$(_relation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _value_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1264$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $dump$058relation_kind$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return "ordinary";
  } else {
    return "hierarchy";
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $dump$058transition$(_value_0) {
  const _a_0 = _value_0["from"];
  const _b_0 = _value_0["to"];
  const _x_0 = ($U32$show$(_b_0));
  const _x_1 = ($U32$show$(_a_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058transition$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1262$(_args_0, _ctx_0) {
  return $consumer$058condition_body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1263$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1263$(_x_1, _x_2);
});
})};
}

function $consumer$058complete$1261$(_prefix_0, _instance_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "consumer.Context", "world": _world_0, "instance": _instance_0}, "snd": (_prefix_0 + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _value_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1264$(_args_0, _ctx_0) {
  return $consumer$058condition_body$1262$(_args_0, _ctx_0);
}

function $consumer$058required$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1262$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1262$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  const _direction_0 = _value_0["end"];
  const _value_1 = _value_0["value"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058relation_value$1261$(_value_1));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058end$(_direction_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  return (_key_0 + _x_4);
}

function $List$show$go$12620$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058cell$1261$(_h_0));
    const _x_1 = ($List$show$go$12620$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1265$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1265$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1265$(_x_1, _x_2);
});
})};
}

function $dump$058cleanup$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_1 = ($List$show$12616$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _relation_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_5 = ($List$show$1260$(_children_0));
    const _x_6 = ($List$show$12616$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($dump$058descriptor$1261$(_relation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _value_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058cleanup$1261$(_h_0));
    const _x_1 = ($List$show$go$12615$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1266$(_args_0, _ctx_0) {
  return $consumer$058condition_body$1263$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058condition$1263$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1263$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1267$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1267$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1267$(_x_1, _x_2);
});
})};
}

function $consumer$058condition_body$1260$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058end$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing") {
    return "Outgoing";
  } else {
    return "Incoming";
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058relation_value$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Missing") {
    return "Missing";
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Target") {
    const _target_0 = _value_0["handle"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_target_0));
    return ("Target:" + _x_0);
  } else {
    const _targets_0 = _value_0["handles"];
    const _x_1 = ($List$show$12613$(_targets_0));
    return ("Sources:" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1261$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1261$(_owner_0, _target_0);
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058condition_body$1261$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1260$(_expected_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1262$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1262$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1263$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1263$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1263$(_owner_0, _target_0);
}

function $consumer$058condition_body$1262$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1264$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1262$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1264$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058relation_value$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Missing") {
    return "Missing";
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Target") {
    const _target_0 = _value_0["handle"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_target_0));
    return ("Target:" + _x_0);
  } else {
    const _targets_0 = _value_0["handles"];
    const _x_1 = ($List$show$12621$(_targets_0));
    return ("Sources:" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1265$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1265$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1265$(_owner_0, _target_0);
}

function $List$show$12616$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058condition_body$1263$(_expected_0, _owner_0) {
  return $consumer$058condition_rows$1261$(_expected_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1266$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058grant$1263$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1266$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1267$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1267$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1267$(_owner_0, _target_0);
}

function $consumer$058condition_rows$1260$(_expected_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($Nat$is_eq$(($List$length$(_rows_0)), _expected_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1260$(($consumer$058condition_plan$1260$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_x_1, _x_2);
});
})};
}

function $List$show$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1261$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1261$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1261$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0)(_target_0));
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1262$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1260$(($consumer$058condition_plan$1261$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1262$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1262$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1263$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1263$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1263$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1260$())))(_owner_0)(_target_0));
}

function $consumer$058condition_rows$1261$(_expected_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _rows_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($Nat$is_eq$(($List$length$(_rows_0)), _expected_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1264$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1261$(($consumer$058condition_plan$1262$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1264$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1264$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1264$(_x_1, _x_2);
});
})};
}

function $List$show$12621$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_h_0));
    const _x_1 = ($List$show$go$12619$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1265$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1263$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1265$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1263$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1261$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1265$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1265$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$())))(_owner_0)(_target_0));
}

function $List$show$go$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($dump$058descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058each_composed$1266$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1261$(($consumer$058condition_plan$1263$()))))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058grant_composed$1266$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1266$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1266$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1267$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1263$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1267$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1267$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1267$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_world$1261$())))(_owner_0)(_target_0));
}

function $Nat$is_eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(cmp_new(_a_0, _b_0));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1260$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0);
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1260$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1261$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1261$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1261$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1261$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1261$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1261$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1261$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1262$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1262$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1262$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1263$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1263$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1263$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1263$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1263$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1263$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_each_field$1262$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1264$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1264$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1264$(_owner_0, _target_0);
}

function $List$show$go$12619$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045app$045relation$058handle$1261$(_h_0));
    const _x_1 = ($List$show$go$12619$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1263$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1265$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1265$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1265$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1265$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1265$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1263$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1265$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1265$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1263$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_enumerate$1266$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup$1266$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1266$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1267$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1267$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1267$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1267$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1267$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1263$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1267$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1267$())))(_owner_0)(_target_0));
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$())))(_owner_0)(_target_0));
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1261$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1261$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1261$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1265$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1261$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1261$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1261$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1261$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1262$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1262$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1262$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1263$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1261$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1263$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1263$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1263$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1263$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1263$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1264$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1262$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1264$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_handles_field$1262$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1261$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1264$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1264$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1265$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1263$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1265$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12611$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1265$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1265$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1265$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_handles_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1261$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058inspect_valid_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1263$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1265$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1263$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1265$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scanned$1266$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1262$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1266$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_target$1266$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1266$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_world$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1267$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1263$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1267$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1267$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1267$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1267$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1267$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1263$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1267$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1260$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1261$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1263$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1261$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1261$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1261$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1262$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1262$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1262$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1262$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1262$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1262$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1263$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1263$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1263$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1263$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1262$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1264$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1264$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1264$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1264$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid$1261$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1264$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1262$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1264$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1264$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_valid_field$1262$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1263$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1269$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1265$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1265$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1265$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1265$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1261$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1261$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1261$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1263$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1263$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1266$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1266$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan$1266$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1266$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_valid$1266$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1262$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1266$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1266$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1267$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1267$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1267$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1267$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1262$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1260$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1261$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1262$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1262$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1262$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1262$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1262$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1262$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1263$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1263$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1264$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1262$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1264$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1268$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1264$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1264$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1264$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_handles_joined$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045frame$045world$058check_valid_joined$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_missing$1262$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1264$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1262$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1264$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1265$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1265$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12610$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1265$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1265$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_matched$1266$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1262$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1266$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1266$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1266$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1266$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_matched$1266$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1262$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair$1266$())))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1267$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1267$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12610$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1267$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1267$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$12611$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1260$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1264$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1261$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1261$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1261$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1261$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1265$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1262$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1262$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1262$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1262$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1263$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1261$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1263$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1261$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_scan_projected$1262$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1266$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1264$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1264$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1264$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1264$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_mismatched$1262$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$058composed_lookup_projected$1262$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../../../bendvy/src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1265$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1262$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$12610$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1263$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1263$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1265$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1263$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$12610$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$12611$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches$1266$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1266$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project$1266$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1266$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1267$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1263$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1267$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1263$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$12610$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1263$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1261$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1261$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1261$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1264$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1262$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1262$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1261$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1261$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1264$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1264$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1264$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1264$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1269$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1262$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1262$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1263$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1263$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1263$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$12610$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_matches_target$1266$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1266$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058pair_project_target$1266$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1266$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058relations$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1263$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1263$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1260$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1260$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1262$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1262$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1261$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1262$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1260$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1261$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1261$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1261$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1264$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1262$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1267$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1262$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1262$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1264$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1262$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1262$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1268$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1262$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1262$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matched_right$1266$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1263$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_left$1266$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _left_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1262$(_left_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1263$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matches$1263$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058project$1263$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1260$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1260$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1260$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1260$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1261$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1261$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1261$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1261$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058matches_field$1266$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1262$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1262$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058yes$1262$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058empty_value$1262$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058projected_right$1262$(_left_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _right_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.Product", "left": _left_0, "right": _right_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045query$045projection$058project_field$1267$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1262$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1261$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1262$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058relations$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1263$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1263$(_x_2, _x_3);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058matched$1263$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058projected$1263$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1260$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(_spec_0, _graph_0, _handle_0, _component_0) {
  const _items_0 = _spec_0["requirements"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058requirements$1260$(_items_0, _graph_0, _namespace_0, _id_0, true, {$: "Nil"})), {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _component_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(_declaration_0) {
  const _source_0 = _declaration_0["source"];
  const _mode_0 = _declaration_0["mode"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1260$(_source_0, _mode_0);
}

function $consumer$058link_absent_out$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1260$(($declarations$058declared_link$1260$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1260$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1261$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1261$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0)));
}

function $consumer$058parent_absent_out$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1260$(($declarations$058declared_parent$1260$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1262$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1262$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058accepted$1261$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(_spec_0, _graph_0, _handle_0, _component_0) {
  const _items_0 = _spec_0["requirements"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058requirements$1261$(_items_0, _graph_0, _namespace_0, _id_0, true, {$: "Nil"})), {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _component_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(_declaration_0) {
  const _source_0 = _declaration_0["source"];
  const _mode_0 = _declaration_0["mode"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1261$(_source_0, _mode_0);
}

function $consumer$058link_absent_out$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1261$(($declarations$058declared_link$1261$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058graph_joined$1261$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1261$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045relation$045projection$058cells$1261$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matches$1263$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058project$1263$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0)));
}

function $consumer$058parent_absent_out$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1261$(($declarations$058declared_parent$1261$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1260$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph_joined$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1260$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058link_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows_result$1260$(_observed_0, _handle_0, _component_0) {
  const _selected_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _selected_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Row", "entity": _handle_0, "cells": _cells_0, "component": _component_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058requirements$1260$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _graph_0 = $1;
      const _namespace_0 = $2;
      const _id_0 = $3;
      const _selected_0 = $4;
      const _acc_0 = $5;
      if (_remaining_0.$ === "Nil") {
        return {$: "Tuple", "fst": _selected_0, "snd": ($List$reverse$(_acc_0))};
      } else {
        const _t_0 = _remaining_0["head"];
        const _key_0 = _t_0["key"];
        const _descriptor_0 = _t_0["descriptor"];
        const _end_0 = _t_0["end"];
        const _mode_0 = _t_0["mode"];
        const _project_0 = _t_0["project"];
        const _rest_0 = _remaining_0["tail"];
        const _observed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058value$1260$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0));
        $0 = _rest_0;
        $1 = _graph_0;
        $2 = _namespace_0;
        $3 = _id_0;
        $4 = ($Bool$and$(_selected_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047query$058selection_aux$1260$(_mode_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058presence$1260$(_observed_0))))));
        $5 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058add_cell$1260$(_project_0, _key_0, _end_0, _observed_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1260$(_source_0, _mode_0) {
  if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.RequiredOut") {
    const _key_0 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_relation$1260$(_key_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.OptionalOut") {
    const _key_1 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_relation$1260$(_key_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.PresentOut") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_relation$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.AbsentOut") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_relation$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.RequiredIn") {
    const _key_2 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_related$1260$(_key_2, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.OptionalIn") {
    const _key_3 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_related$1260$(_key_3, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.PresentIn") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_related$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_related$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_source_0)))), "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1260$(_declaration_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.AbsentOut"}};
}

function $declarations$058declared_link$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($declarations$058link$1260$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1261$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058accepted$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1261$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058cells$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1260$(($consumer$058parent_absent_out$1260$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $declarations$058declared_parent$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($declarations$058parent$1260$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1262$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058accepted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph_joined$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058graph_read$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1262$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058cells$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058link_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows_result$1261$(_observed_0, _handle_0, _component_0) {
  const _selected_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _selected_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Row", "entity": _handle_0, "cells": _cells_0, "component": _component_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058requirements$1261$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _graph_0 = $1;
      const _namespace_0 = $2;
      const _id_0 = $3;
      const _selected_0 = $4;
      const _acc_0 = $5;
      if (_remaining_0.$ === "Nil") {
        return {$: "Tuple", "fst": _selected_0, "snd": ($List$reverse$(_acc_0))};
      } else {
        const _t_0 = _remaining_0["head"];
        const _key_0 = _t_0["key"];
        const _descriptor_0 = _t_0["descriptor"];
        const _end_0 = _t_0["end"];
        const _mode_0 = _t_0["mode"];
        const _project_0 = _t_0["project"];
        const _rest_0 = _remaining_0["tail"];
        const _observed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058value$1261$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0));
        $0 = _rest_0;
        $1 = _graph_0;
        $2 = _namespace_0;
        $3 = _id_0;
        $4 = ($Bool$and$(_selected_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047query$058selection_aux$1260$(_mode_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058presence$1261$(_observed_0))))));
        $5 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058add_cell$1261$(_project_0, _key_0, _end_0, _observed_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058selected_spec$1261$(_source_0, _mode_0) {
  if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.RequiredOut") {
    const _key_0 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_relation$1261$(_key_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.OptionalOut") {
    const _key_1 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_relation$1261$(_key_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.PresentOut") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_relation$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.AbsentOut") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_relation$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.RequiredIn") {
    const _key_2 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_related$1261$(_key_2, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.OptionalIn") {
    const _key_3 = _mode_0["key"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_related$1261$(_key_3, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.PresentIn") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_related$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Spec", "requirements": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_related$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_source_0)))), "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058absent_out$1261$(_declaration_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.Declaration", "source": _declaration_0, "mode": {$: "../../../../../../../../bendvy/src/ecs/ordinary-inspector-relation.AbsentOut"}};
}

function $declarations$058declared_link$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1261$(($declarations$058link$1261$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058matched$1263$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058accepted$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058projected$1263$(_target_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058cells$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058spec_rows$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058spec$1261$(($consumer$058parent_absent_out$1261$()))), _graph_0, _target_0, {$: "Unit"}))))};
}

function $declarations$058declared_parent$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1261$(($declarations$058parent$1261$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058accepted$1260$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph_joined$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058cells$1260$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058value$1260$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0) {
  if (_end_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058outgoing_value$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058incoming_value$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047query$058selection_aux$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/query.Required") {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/query.Present") {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../bendvy/src/ecs/query.Absent") {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058presence$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent"};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/component.Found", "value": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058add_cell$1260$(_project_0, _key_0, _end_0, _value_0, _cells_0) {
  if (!_project_0) {
    return _cells_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Cell", "key": _key_0, "end": _end_0, "value": _value_0}, "tail": _cells_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_relation$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1260$(_declaration_0) {
  const _value_0 = _declaration_0["descriptor"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_relation$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_relation$1260$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_relation$1260$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_related$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_related$1260$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_related$1260$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_related$1260$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1260$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-reader.Declaration", "descriptor": _descriptor_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058accepted$1261$(_observed_0) {
  const _selected_0 = _observed_0["fst"];
  return _selected_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058graph_joined$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _graph_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$045relation$045projection$058cells$1261$(_observed_0) {
  const _t_0 = _observed_0["snd"];
  const _items_0 = _t_0["cells"];
  return _items_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058value$1261$(_graph_0, _descriptor_0, _end_0, _namespace_0, _id_0) {
  if (_end_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058outgoing_value$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058incoming_value$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058presence$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/relation-query.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ComponentAbsent"};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/component.Found", "value": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058add_cell$1261$(_project_0, _key_0, _end_0, _value_0, _cells_0) {
  if (!_project_0) {
    return _cells_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Cell", "key": _key_0, "end": _end_0, "value": _value_0}, "tail": _cells_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_relation$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045inspector$045relation$058descriptor$1261$(_declaration_0) {
  const _value_0 = _declaration_0["descriptor"];
  return _value_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_relation$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_relation$1261$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_relation$1261$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Outgoing"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058read_related$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Required"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058optional_related$1261$(_key_0, _descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": _key_0, "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Optional"}, "project": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058with_related$1261$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Present"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058without_related$1261$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Requirement", "key": "", "descriptor": _descriptor_0, "end": {$: "../../../../../../../../bendvy/src/ecs/relation-query.Incoming"}, "mode": {$: "../../../../../../../../bendvy/src/ecs/query.Absent"}, "project": false};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045failure$045reader$058relation$1261$(_descriptor_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/relation-failure-reader.Declaration", "descriptor": _descriptor_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058outgoing_value$1260$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Missing"};
  } else {
    const _id_0 = _value_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Target", "handle": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058incoming_value$1260$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Missing"};
  } else {
    const _first_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Sources", "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058handles_acc$1260$({$: "Con", "head": _first_0, "tail": _rest_0}, _namespace_0, {$: "Nil"}))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058outgoing_value$1261$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Missing"};
  } else {
    const _id_0 = _value_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Target", "handle": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058incoming_value$1261$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Missing"};
  } else {
    const _first_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/relation-query.Sources", "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058handles_acc$1261$({$: "Con", "head": _first_0, "tail": _rest_0}, _namespace_0, {$: "Nil"}))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058handles_acc$1260$($0, $1, $2) {
  for (;;) {
    {
      const _ids_0 = $0;
      const _namespace_0 = $1;
      const _acc_0 = $2;
      if (_ids_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _id_0 = _ids_0["head"];
        const _rest_0 = _ids_0["tail"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045query$058handles_acc$1261$($0, $1, $2) {
  for (;;) {
    {
      const _ids_0 = $0;
      const _namespace_0 = $1;
      const _acc_0 = $2;
      if (_ids_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _id_0 = _ids_0["head"];
        const _rest_0 = _ids_0["tail"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,1,0,0,2,2,0,11,1,11,4],["Tuple"]]);