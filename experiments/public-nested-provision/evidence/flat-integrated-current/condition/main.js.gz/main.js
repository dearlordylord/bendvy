function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _x_0 = ($scenario$1260$({$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 3, "condition": 1}, "tail": {$: "Nil"}}));
  const _x_1 = ($scenario$1261$({$: "Con", "head": {$: "../../src/ecs/schedule.Phase", "name": "failure"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 2, "condition": 1}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.Barrier"}, "tail": {$: "Nil"}}}}}));
  const _x_2 = ($scenario$1260$({$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 1, "condition": 0}, "tail": {$: "Nil"}}}));
  const _x_3 = (_x_0 + _x_1);
  const _x_4 = ($scenario$1260$({$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 2, "condition": 0}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.Barrier"}, "tail": {$: "Nil"}}}}));
  const _x_5 = (_x_2 + _x_3);
  const _x_6 = ($scenario$1260$({$: "Con", "head": {$: "../../src/ecs/schedule.Phase", "name": "before"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.Phase", "name": "after"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 2, "condition": 1}, "tail": {$: "Nil"}}}}}}));
  const _x_7 = (_x_4 + _x_5);
  const _x_8 = ($scenario$1260$({$: "Con", "head": {$: "../../src/ecs/schedule.Phase", "name": "before"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.Phase", "name": "after"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schedule.System", "id": 2, "condition": 1}, "tail": {$: "Nil"}}}}}));
  const _x_9 = (_x_6 + _x_7);
  return (_x_10) => $IO$print$((_x_8 + _x_9), _x_10);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $scenario$1260$(_steps_0) {
  return $created$1260$(($$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047src$047ecs$047world$058factory$()), 0)), _steps_0);
}

function $scenario$1261$(_steps_0) {
  return $created$1261$(($$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047src$047ecs$047world$058factory$()), 0)), _steps_0);
}

function $created$1260$(_result_0, _steps_0) {
  if (_result_0.$ === "../../src/ecs/world.CreateRejected") {
    return "create-failed";
  } else {
    const _world_0 = _result_0["world"];
    return $init_a$1260$(($$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "A", {$: "Con", "head": "commands.enqueue", "tail": {$: "Nil"}})), _steps_0);
  }
}

function $$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $created$1261$(_result_0, _steps_0) {
  if (_result_0.$ === "../../src/ecs/world.CreateRejected") {
    return "create-failed";
  } else {
    const _world_0 = _result_0["world"];
    return $init_a$1261$(($$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "A", {$: "Con", "head": "commands.enqueue", "tail": {$: "Nil"}})), _steps_0);
  }
}

function $init_a$1260$(_result_0, _steps_0) {
  if (_result_0.$ === "../../src/ecs/system.RegistrationFailed") {
    return "registration-failed";
  } else {
    const _world_0 = _result_0["world"];
    const _a_0 = _result_0["registry"];
    return $init_b$1260$(($$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "B", {$: "Con", "head": "resource.write", "tail": {$: "Con", "head": "events.publish", "tail": {$: "Nil"}}})), _a_0, _steps_0);
  }
}

function $$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../src/ecs/world.CreateRejected", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../src/ecs/world.Created", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $init_a$1261$(_result_0, _steps_0) {
  if (_result_0.$ === "../../src/ecs/system.RegistrationFailed") {
    return "registration-failed";
  } else {
    const _world_0 = _result_0["world"];
    const _a_0 = _result_0["registry"];
    return $init_b$1261$(($$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "B", {$: "Con", "head": "resource.write", "tail": {$: "Con", "head": "events.publish", "tail": {$: "Nil"}}})), _a_0, _steps_0);
  }
}

function $init_b$1260$(_result_0, _a_0, _steps_0) {
  if (_result_0.$ === "../../src/ecs/system.RegistrationFailed") {
    return "registration-failed";
  } else {
    const _world_0 = _result_0["world"];
    const _b_0 = _result_0["registry"];
    return $built$1260$(($$$$047$$$047src$047ecs$047schedule$058build$1260$(1, "tick", _steps_0, {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Nil"}}}, {$: "Owners", "a": _a_0, "b": _b_0})), _world_0);
  }
}

function $$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $empty$(__0) {
  return {$: "Unit"};
}

function $init_b$1261$(_result_0, _a_0, _steps_0) {
  if (_result_0.$ === "../../src/ecs/system.RegistrationFailed") {
    return "registration-failed";
  } else {
    const _world_0 = _result_0["world"];
    const _b_0 = _result_0["registry"];
    return $built$1261$(($$$$047$$$047src$047ecs$047schedule$058build$1260$(1, "tick", _steps_0, {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Nil"}}}, {$: "Owners", "a": _a_0, "b": _b_0})), _world_0);
  }
}

function $built$1260$(_build_0, _world_0) {
  if (_build_0.$ === "../../src/ecs/schedule.Invalid") {
    return "invalid\n";
  } else {
    const _schedule_0 = _build_0["schedule"];
    return $twice_second$1260$(($record_run$(run_loop($$$$047$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0)), {$: "Nil"})));
  }
}

function $$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $built$1261$(_build_0, _world_0) {
  if (_build_0.$ === "../../src/ecs/schedule.Invalid") {
    return "invalid\n";
  } else {
    const _schedule_0 = _build_0["schedule"];
    return $twice_second$1261$(($record_run$(run_loop($$$$047$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0)), {$: "Nil"})));
  }
}

function $twice_second$1260$(_first_0) {
  const _schedule_0 = _first_0["fst"];
  const _nested_0 = _first_0["snd"];
  return $twice_nested$1260$(_schedule_0, _nested_0);
}

function $record_run$(_result_0, _lines_0) {
  if (_result_0.$ === "../../src/ecs/schedule.Finished") {
    const _schedule_0 = _result_0["schedule"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    const _x_0 = ($show_steps$(_observations_0));
    return $record_capture$(_schedule_0, ($capture$(_world_0)), ($List$append$(_lines_0, {$: "Con", "head": ("ok:" + _x_0), "tail": {$: "Nil"}})));
  } else if (_result_0.$ === "../../src/ecs/schedule.Failed") {
    const _schedule_1 = _result_0["schedule"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    const _x_1 = ($show_steps$(_observations_1));
    const _x_2 = (":" + _x_1);
    const _x_3 = (_error_0 + _x_2);
    return $record_capture$(_schedule_1, ($capture$(_world_1)), ($List$append$(_lines_0, {$: "Con", "head": ("fail:" + _x_3), "tail": {$: "Nil"}})));
  } else {
    const _schedule_2 = _result_0["schedule"];
    const _world_2 = _result_0["world"];
    return $record_capture$(_schedule_2, ($capture$(_world_2)), ($List$append$(_lines_0, {$: "Con", "head": "rejected", "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../src/ecs/schedule.Built", "schedule": {$: "../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../src/ecs/world.RegistrationRejected") {
    return {$: "../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.RegistrationRejected", "error": {$: "../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $twice_second$1261$(_first_0) {
  const _schedule_0 = _first_0["fst"];
  const _nested_0 = _first_0["snd"];
  return $twice_nested$1261$(_schedule_0, _nested_0);
}

function $$$$047$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0) {
  return $$$$047$$$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $twice_nested$1260$(_schedule_0, _nested_0) {
  const _world_0 = _nested_0["fst"];
  const _lines_0 = _nested_0["snd"];
  return $final$(($record_run$(run_loop($$$$047$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0)), _lines_0)));
}

function $record_capture$(_schedule_0, _captured_0, _lines_0) {
  const _world_0 = _captured_0["fst"];
  const _text_0 = _captured_0["snd"];
  return {$: "Tuple", "fst": _schedule_0, "snd": {$: "Tuple", "fst": _world_0, "snd": ($List$append$(_lines_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}}))}};
}

function $capture$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($numbers$(_events_0));
  const _x_1 = ($U32$show$(_resource_0));
  const _x_2 = (":" + _x_0);
  return $capture_handles$(($$$$047$$$047src$047ecs$047world$058handles$1260$({$: "../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), (_x_1 + _x_2));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $show_steps$(_steps_0) {
  if (_steps_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _steps_0["head"];
    if (_t_0.$ === "../../src/ecs/schedule.Entered") {
      const _name_0 = _t_0["name"];
      const _rest_0 = _steps_0["tail"];
      const _x_0 = ($show_steps$(_rest_0));
      const _x_1 = (";" + _x_0);
      const _x_2 = (_name_0 + _x_1);
      return ("phase:" + _x_2);
    } else if (_t_0.$ === "../../src/ecs/schedule.Ran") {
      const _id_0 = _t_0["id"];
      const _rest_1 = _steps_0["tail"];
      const _x_3 = ($show_steps$(_rest_1));
      const _x_4 = ($U32$show$(_id_0));
      const _x_5 = (";" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      return ("run:" + _x_6);
    } else if (_t_0.$ === "../../src/ecs/schedule.Skipped") {
      const _id_1 = _t_0["id"];
      const _rest_2 = _steps_0["tail"];
      const _x_7 = ($show_steps$(_rest_2));
      const _x_8 = ($U32$show$(_id_1));
      const _x_9 = (";" + _x_7);
      const _x_10 = (_x_8 + _x_9);
      return ("skip:" + _x_10);
    } else {
      const _rest_3 = _steps_0["tail"];
      const _x_11 = ($show_steps$(_rest_3));
      return ("barrier;" + _x_11);
    }
  }
}

function $$$$047$$$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0);
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $twice_nested$1261$(_schedule_0, _nested_0) {
  const _world_0 = _nested_0["fst"];
  const _lines_0 = _nested_0["snd"];
  return $final$(($record_run$(run_loop($$$$047$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0)), _lines_0)));
}

function $$$$047$$$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0);
}

function $final$(_result_0) {
  const _nested_0 = _result_0["snd"];
  return $final_nested$(_nested_0);
}

function $capture_handles$(_observed_0, _prefix_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  const _x_0 = ($ids$(_handles_0));
  const _x_1 = (":" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_prefix_0 + _x_1)};
}

function $$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $numbers$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($numbers$(_rest_0));
    const _x_1 = ($U32$show$(_value_0));
    const _x_2 = ("," + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047src$047ecs$047schedule$058run_checked$1260$((_namespace_0 === _actual_0), {$: "../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047src$047ecs$047schedule$058run_checked$1261$((_namespace_0 === _actual_0), {$: "../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $final_nested$(_nested_0) {
  const _world_0 = _nested_0["fst"];
  const _lines_0 = _nested_0["snd"];
  return $flush_capture$(($capture$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))), _lines_0);
}

function $ids$(_handles_0) {
  if (_handles_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _handles_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _handles_0["tail"];
    const _x_0 = ($ids$(_rest_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = ("," + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../src/ecs/world.Ready", "live": _live_0, "handles": {$: "Nil"}});
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047src$047ecs$047schedule$058run_checked$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047src$047ecs$047schedule$058execute$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047$$$047src$047ecs$047schedule$058run_checked$1261$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047src$047ecs$047schedule$058execute$1261$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $flush_capture$(_captured_0, _lines_0) {
  const _text_0 = _captured_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = ($show_lines$(_lines_0));
  const _x_2 = ("flush:" + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../src/ecs/world.Ready") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../src/ecs/world.Ready") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../src/ecs/world.Ready") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../src/ecs/world.Read", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../src/ecs/world.Ready", "live": _live_5, "handles": ($$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047schedule$058execute$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../src/ecs/schedule.Finished", "schedule": {$: "../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047src$047ecs$047schedule$058execute$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($condition$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047schedule$058execute$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../src/ecs/schedule.Finished", "schedule": {$: "../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047src$047ecs$047schedule$058after_condition$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047src$047ecs$047schedule$058execute$1261$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($condition$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $show_lines$(_lines_0) {
  if (_lines_0.$ === "Nil") {
    return "";
  } else {
    const _line_0 = _lines_0["head"];
    const _rest_0 = _lines_0["tail"];
    const _x_0 = ($show_lines$(_rest_0));
    const _x_1 = ("\n" + _x_0);
    return (_line_0 + _x_1);
  }
}

function $$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $condition$(_world_0, _slot_0) {
  return $condition_observed$(run_loop($gameplay_read$1260$(_world_0)), _slot_0);
}

function $$$$047$$$047src$047ecs$047schedule$058after_condition$1261$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  } else {
    return $$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $condition_observed$(_observed_0, _slot_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($Bool$and$(($Bool$not$((_slot_0 === 0))), (_value_0 < 1000000)))};
}

function $gameplay_read$1260$(_ctx_0) {
  return $$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0);
}

function $$$$047$$$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($dispatch_fail$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  } else {
    return $$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($dispatch_fail$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $dispatch$(_owners_0, _world_0, _id_0) {
  return $dispatch_value$(_owners_0, _world_0, _id_0);
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$({$: "../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $read_counter$(_x_0);
})})), _ctx_0);
}

function $dispatch_fail$(_owners_0, _world_0, _id_0) {
  return $dispatch_fail_value$(_owners_0, _world_0, _id_0);
}

function $$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/schedule.Failed", "schedule": {$: "../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $dispatch_value$(_owners_0, _world_0, _id_0) {
  const _a_0 = _owners_0["a"];
  const _b_0 = _owners_0["b"];
  if (_id_0 == 1) {
    return $result_a$(($$$$047$$$047src$047ecs$047system$058run$1260$(_a_0, _world_0, 8)), _b_0);
  } else if ((_id_0 & 1) == 1) {
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  } else if (_id_0 == 2) {
    return $result_b$(($$$$047$$$047src$047ecs$047system$058run$1260$(_b_0, _world_0, 2)), _a_0);
  } else {
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  }
}

function $$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $read_counter$(_world_0) {
  return $$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0);
}

function $dispatch_fail_value$(_owners_0, _world_0, _id_0) {
  const _a_0 = _owners_0["a"];
  const _b_0 = _owners_0["b"];
  if (_id_0 == 1) {
    return $result_a$(($$$$047$$$047src$047ecs$047system$058run$1260$(_a_0, _world_0, 6)), _b_0);
  } else if ((_id_0 & 1) == 1) {
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  } else if (_id_0 == 2) {
    return $result_b$(($$$$047$$$047src$047ecs$047system$058run$1260$(_b_0, _world_0, 7)), _a_0);
  } else {
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  }
}

function $result_a$(_result_0, _b_0) {
  if (_result_0.$ === "../../src/ecs/system.Completed") {
    const _a_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_0}, "snd": _outcome_0};
  } else {
    const _a_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_1, "b": _b_0}, "snd": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "registration"}};
  }
}

function $$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $result_b$(_result_0, _a_0) {
  if (_result_0.$ === "../../src/ecs/system.Completed") {
    const _b_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_0}, "snd": _outcome_0};
  } else {
    const _b_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "Owners", "a": _a_0, "b": _b_1}, "snd": {$: "../../src/ecs/system.Failed", "world": _world_0, "error": "registration"}};
  }
}

function $$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(($project_counter$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $project_counter$(_value_0) {
  return $project_counter_value$(_value_0);
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $project_counter_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": _value_0};
}

function $$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($runner$(_world_0, _args_0)));
  }
}

function $$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return false;
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    const _x_0 = ($$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
    const _x_1 = ($$$$047$$$047src$047ecs$047world$058registration_list_matches$(_rest_0, _id_0, _name_0, _access_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $runner$(_world_0, _value_0) {
  return $runner_value$(_world_0, _value_0);
}

function $$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $Bool$and$((_mid_0 === _id_0), ($Bool$and$(($String$eq$(_mname_0, _name_0)), ($$$$047$$$047src$047ecs$047world$058access_equal$(_maccess_0, _access_0)))));
}

function $runner_value$(_world_0, _value_0) {
  if (_value_0 == 2) {
    return $live_value$(($$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
  } else if ((_value_0 & 7) == 2) {
    const _40_0 = u32_to_word(_value_0)["tail"]["tail"]["tail"]["head"];
    const _41_0 = u32_to_word(_value_0)["tail"]["tail"]["tail"]["tail"];
    return {$: "../../src/ecs/system.Succeeded", "world": ($$$$047$$$047src$047ecs$047world$058event_publish$1260$(($change$(_world_0, word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": true, "tail": {$: "WCon", "head": false, "tail": {$: "WCon", "head": _40_0, "tail": _41_0}}}}))), {$: "Con", "head": word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": true, "tail": {$: "WCon", "head": false, "tail": {$: "WCon", "head": _40_0, "tail": _41_0}}}}), "tail": {$: "Nil"}})), "output": {$: "Unit"}};
  } else if (_value_0 == 6) {
    return {$: "../../src/ecs/system.Succeeded", "world": ($enqueue_spawn$(($publish$(($change$(_world_0, 2)), {$: "Con", "head": 2, "tail": {$: "Nil"}})))), "output": {$: "Unit"}};
  } else if ((_value_0 & 7) == 6) {
    const _98_0 = u32_to_word(_value_0)["tail"]["tail"]["tail"]["head"];
    const _99_0 = u32_to_word(_value_0)["tail"]["tail"]["tail"]["tail"];
    return {$: "../../src/ecs/system.Succeeded", "world": ($$$$047$$$047src$047ecs$047world$058event_publish$1260$(($change$(_world_0, word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": true, "tail": {$: "WCon", "head": true, "tail": {$: "WCon", "head": _98_0, "tail": _99_0}}}}))), {$: "Con", "head": word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": true, "tail": {$: "WCon", "head": true, "tail": {$: "WCon", "head": _98_0, "tail": _99_0}}}}), "tail": {$: "Nil"}})), "output": {$: "Unit"}};
  } else if (_value_0 == 8) {
    return {$: "../../src/ecs/system.Succeeded", "world": ($enqueue_spawn$(_world_0)), "output": {$: "Unit"}};
  } else if ((_value_0 & 3) == 0) {
    const _156_0 = u32_to_word(_value_0)["tail"]["tail"]["head"];
    const _157_0 = u32_to_word(_value_0)["tail"]["tail"]["tail"];
    return {$: "../../src/ecs/system.Succeeded", "world": ($$$$047$$$047src$047ecs$047world$058event_publish$1260$(($change$(_world_0, word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": false, "tail": {$: "WCon", "head": _156_0, "tail": _157_0}}}))), {$: "Con", "head": word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": false, "tail": {$: "WCon", "head": _156_0, "tail": _157_0}}}), "tail": {$: "Nil"}})), "output": {$: "Unit"}};
  } else if (_value_0 == 7) {
    return $failure_reserved$(($$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    const _216_0 = u32_to_word(_value_0)["tail"]["head"];
    const _217_0 = u32_to_word(_value_0)["tail"]["tail"];
    return {$: "../../src/ecs/system.Succeeded", "world": ($$$$047$$$047src$047ecs$047world$058event_publish$1260$(($change$(_world_0, word_to_u32({$: "WCon", "head": true, "tail": {$: "WCon", "head": _216_0, "tail": _217_0}}))), {$: "Con", "head": word_to_u32({$: "WCon", "head": true, "tail": {$: "WCon", "head": _216_0, "tail": _217_0}}), "tail": {$: "Nil"}})), "output": {$: "Unit"}};
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($String$eq$(__2, _y_0)), ($$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $live_value$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  const _x_0 = ($List$length$(_handles_0));
  const _x_1 = (_x_0 >>> 0);
  return {$: "../../src/ecs/system.Succeeded", "world": ($$$$047$$$047src$047ecs$047world$058event_publish$1260$(($change$(_world_0, ((2 + _x_1) >>> 0))), {$: "Con", "head": 2, "tail": {$: "Nil"}})), "output": {$: "Unit"}};
}

function $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $change$(_world_0, _value_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = (Math.imul(_resource_0, 10) >>> 0);
  return {$: "../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": ((_x_0 + _value_0) >>> 0), "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $enqueue_spawn$(_world_0) {
  return $queued_reserved$(($$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $publish$(_world_0, _events_0) {
  return $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $failure_reserved$(_reservation_0) {
  const _world_0 = _reservation_0["fst"];
  return $failed_replaced$(($$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, 777)));
}

function $$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $queued_reserved$(_reservation_0) {
  const _world_0 = _reservation_0["fst"];
  const _t_0 = _reservation_0["snd"];
  if (_t_0.$ === "../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $activate_handle$(_x_0, _handle_0);
}));
  } else {
    return _world_0;
  }
}

function $failed_replaced$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  const _old_0 = _replaced_0["snd"];
  const _tx_0 = ($$$$047$$$047src$047ecs$047transaction$058add_undo$1260$(($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), run_clo((_x_0) => {
  return $restore_resource$(_x_0, _old_0);
})));
  const _staged_0 = ($$$$047$$$047src$047ecs$047transaction$058stage$1260$(($$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, 7)), run_clo((_x_1) => {
  return $queued$(_x_1);
})));
  return $failed_finished$(($$$$047$$$047src$047ecs$047transaction$058finish$1260$(_staged_0, {$: "../../src/ecs/transaction.Failure", "error": "planned"})));
}

function $$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _replacement_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _resource_0};
}

function $$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.ReservationRejected", "error": {$: "../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $activate_handle$(_world_0, _handle_0) {
  return $activated$(($$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047transaction$058add_undo$1260$(_tx_0, _inverse_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": _inverse_0, "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $restore_resource$(_world_0, _value_0) {
  return $restored$(($$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _value_0)));
}

function $$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $queued$(_world_0) {
  return $reserved$(($$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $failed_finished$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../src/ecs/transaction.Failure") {
    const _error_0 = _t_0["error"];
    return {$: "../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  } else {
    return {$: "../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Reserved", "handle": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $activated$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $restored$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  return _world_0;
}

function $reserved$(_reservation_0) {
  const _world_0 = _reservation_0["fst"];
  const _t_0 = _reservation_0["snd"];
  if (_t_0.$ === "../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $activated$(($$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/transaction.Success") {
    const _committed_0 = ($enqueue$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../src/ecs/transaction.Returned", "world": ($publish$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $enqueue$(_world_0, _commands_0) {
  return $enqueue_all$(_commands_0, _world_0);
}

function $$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.Rejected", "error": {$: "../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Accepted"}};
  }
}

function $enqueue_all$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);