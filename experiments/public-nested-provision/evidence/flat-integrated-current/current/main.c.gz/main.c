
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_NIL 13
#define CID_CON 14
#define CID_______SRC_ECS_SCHEDULE_SYSTEM 15
#define CID_______SRC_ECS_SCHEDULE_PHASE 16
#define CID_______SRC_ECS_SCHEDULE_BARRIER 17
#define CID_CHR 18
#define CID_______SRC_ECS_WORLD_CREATED 19
#define CID_______SRC_ECS_WORLD_CREATEREJECTED 20
#define CID_SCHEMA 21
#define CID_______SRC_ECS_WORLD_FACTORY 22
#define CID_______SRC_ECS_WORLD_WORLD 23
#define CID_______SRC_ECS_SYSTEM_REGISTERED 24
#define CID_______SRC_ECS_SYSTEM_REGISTRATIONFAILED 25
#define CID_______SRC_ECS_WORLD_REGISTRATIONMETA 26
#define CID_______SRC_ECS_SYSTEM_SUCCEEDED 27
#define CID_______SRC_ECS_SYSTEM_FAILED 28
#define CID_______SRC_ECS_SYSTEM_REGISTRY 29
#define CID_______SRC_ECS_SCHEDULE_BUILT 30
#define CID_______SRC_ECS_SCHEDULE_INVALID 31
#define CID_OWNERS 32
#define CID_______SRC_ECS_WORLD_REGISTERED 33
#define CID_______SRC_ECS_WORLD_REGISTRATIONREJECTED 34
#define CID_______SRC_ECS_SCHEDULE_SCHEDULE 35
#define CID_______SRC_ECS_SCHEDULE_FINISHED 36
#define CID_______SRC_ECS_SCHEDULE_FAILED 37
#define CID_______SRC_ECS_SCHEDULE_REJECTED 38
#define CID_______SRC_ECS_WORLD_MISSINGENTITY 39
#define CID_______SRC_ECS_WORLD_CAPACITYEXCEEDED 40
#define CID_______SRC_ECS_WORLD_NAMESPACEEXHAUSTED 41
#define CID_______SRC_ECS_WORLD_SYSTEMIDEXHAUSTED 42
#define CID_______SRC_ECS_SCHEDULE_ENTERED 43
#define CID_______SRC_ECS_SCHEDULE_RAN 44
#define CID_______SRC_ECS_SCHEDULE_SKIPPED 45
#define CID_______SRC_ECS_SCHEDULE_APPLIED 46
#define CID_______SRC_ECS_WORLD_HANDLE 47
#define CID_______SRC_ECS_WORLD_HANDLESCAN 48
#define CID_______SRC_ECS_WORLD_READY 49
#define CID_______SRC_ECS_WORLD_READ 50
#define CID_______SRC_ECS_CAPABILITIES_VALUEREAD 51
#define CID_WNIL 52
#define CID_______SRC_ECS_SYSTEM_COMPLETED 53
#define CID_______SRC_ECS_SYSTEM_REGISTRATIONREJECTED 54
#define CID_______SRC_ECS_WORLD_RESERVED 55
#define CID_______SRC_ECS_WORLD_RESERVATIONREJECTED 56
#define CID_LT 57
#define CID_EQ 58
#define CID_GT 59
#define CID_______SRC_ECS_TRANSACTION_TX 60
#define CID_______SRC_ECS_TRANSACTION_RETURNED 61
#define CID_______SRC_ECS_TRANSACTION_SUCCESS 62
#define CID_______SRC_ECS_TRANSACTION_FAILURE 63
#define CID_______SRC_ECS_WORLD_GROWTH 64
#define CID_______SRC_ECS_WORLD_ACCEPTED 65
#define CID_______SRC_ECS_WORLD_REJECTED 66
#define CID_IO_PRINT 67
#define FID_______SRC_ECS_TRANSACTION_ROLLBACK_0 0
#define FID_______SRC_ECS_TRANSACTION_ROLLBACK_0_K3 1
#define FID_______SRC_ECS_TRANSACTION_FINISH_0 2
#define FID_______SRC_ECS_TRANSACTION_FINISH_0_K23 3
#define FID_STRING_CMP 4
#define FID_STRING_CMP_K35 5
#define FID_LIST_LENGTH 6
#define FID_LIST_LENGTH_K47 7
#define FID_STRING_ORDER 8
#define FID_STRING_ORDER_K49 9
#define FID_QUEUED_RESERVED_C58 10
#define FID_______SRC_ECS_WORLD_ACCESS_EQUAL 11
#define FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K64 12
#define FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K65 13
#define FID_STRING_EQ 14
#define FID_STRING_EQ_K67 15
#define FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES 16
#define FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K74 17
#define FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K75 18
#define FID_RUNNER 19
#define FID_RUNNER_K77 20
#define FID_RUNNER_C78 21
#define FID_RUNNER_C79 22
#define FID_RUNNER_K80 23
#define FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES 24
#define FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K83 25
#define FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K84 26
#define FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0 27
#define FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K88 28
#define FID_______SRC_ECS_SYSTEM_RUN_0 29
#define FID_______SRC_ECS_SYSTEM_RUN_0_K106 30
#define FID_______SRC_ECS_SYSTEM_RUN_0_K107 31
#define FID_DISPATCH_FAIL 32
#define FID_DISPATCH_FAIL_K124 33
#define FID_DISPATCH_FAIL_K125 34
#define FID_DISPATCH 35
#define FID_DISPATCH_K130 36
#define FID_DISPATCH_K131 37
#define FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0 38
#define FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K133 39
#define FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K134 40
#define FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K135 41
#define FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K136 42
#define FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K137 43
#define FID_GAMEPLAY_READ_0 44
#define FID_GAMEPLAY_READ_0_C145 45
#define FID_GAMEPLAY_READ_0_K146 46
#define FID_CONDITION 47
#define FID_CONDITION_K161 48
#define FID_______SRC_ECS_WORLD_DRAIN_FIFO_0 49
#define FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K171 50
#define FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K172 51
#define FID_SHOW_LINES 52
#define FID_SHOW_LINES_K174 53
#define FID_SHOW_LINES_K175 54
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1 55
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K177 56
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K178 57
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K179 58
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K180 59
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C181 60
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C182 61
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C183 62
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K184 63
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K185 64
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K186 65
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K187 66
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K188 67
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K189 68
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0 69
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K191 70
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K192 71
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K193 72
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K194 73
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C195 74
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C196 75
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C197 76
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K198 77
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K199 78
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K200 79
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K201 80
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K202 81
#define FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K203 82
#define FID_U32_SHOW_GO 83
#define FID_______SRC_ECS_WORLD_BARRIER_0 84
#define FID_IDS 85
#define FID_IDS_K217 86
#define FID_IDS_K218 87
#define FID_IDS_K219 88
#define FID_NUMBERS 89
#define FID_NUMBERS_K229 90
#define FID_NUMBERS_K230 91
#define FID_NUMBERS_K231 92
#define FID_U32_SHOW 93
#define FID_FINAL 94
#define FID_FINAL_K239 95
#define FID_FINAL_K240 96
#define FID_FINAL_K241 97
#define FID_FINAL_K242 98
#define FID_FINAL_K243 99
#define FID_______SRC_ECS_SCHEDULE_CONTAINS 100
#define FID_______SRC_ECS_SCHEDULE_CONTAINS_K250 101
#define FID_SHOW_STEPS 102
#define FID_SHOW_STEPS_K254 103
#define FID_SHOW_STEPS_K255 104
#define FID_SHOW_STEPS_K256 105
#define FID_SHOW_STEPS_K257 106
#define FID_SHOW_STEPS_K258 107
#define FID_SHOW_STEPS_K259 108
#define FID_SHOW_STEPS_K260 109
#define FID_SHOW_STEPS_K261 110
#define FID_SHOW_STEPS_K262 111
#define FID_SHOW_STEPS_K263 112
#define FID_SHOW_STEPS_K264 113
#define FID_SHOW_STEPS_K265 114
#define FID_LIST_APPEND 115
#define FID_LIST_APPEND_K267 116
#define FID_CAPTURE 117
#define FID_CAPTURE_K269 118
#define FID_CAPTURE_K270 119
#define FID_CAPTURE_K271 120
#define FID_CAPTURE_K272 121
#define FID_CAPTURE_K273 122
#define FID_CAPTURE_K274 123
#define FID_CAPTURE_K275 124
#define FID_RECORD_CAPTURE 125
#define FID_RECORD_CAPTURE_K277 126
#define FID_______SRC_ECS_SCHEDULE_RUN_1 127
#define FID_______SRC_ECS_SCHEDULE_VALID 128
#define FID_______SRC_ECS_SCHEDULE_VALID_K288 129
#define FID_______SRC_ECS_SCHEDULE_VALID_K289 130
#define FID_______SRC_ECS_SCHEDULE_VALID_K290 131
#define FID_______SRC_ECS_SCHEDULE_RUN_0 132
#define FID_RECORD_RUN 133
#define FID_RECORD_RUN_K294 134
#define FID_RECORD_RUN_K295 135
#define FID_RECORD_RUN_K296 136
#define FID_RECORD_RUN_K297 137
#define FID_RECORD_RUN_K298 138
#define FID_RECORD_RUN_K299 139
#define FID_RECORD_RUN_K300 140
#define FID_RECORD_RUN_K301 141
#define FID_RECORD_RUN_K302 142
#define FID_RECORD_RUN_K303 143
#define FID_RECORD_RUN_K304 144
#define FID_RECORD_RUN_K305 145
#define FID_______SRC_ECS_SCHEDULE_BUILD_0 146
#define FID_______SRC_ECS_SCHEDULE_BUILD_0_K317 147
#define FID_SCENARIO_1 148
#define FID_SCENARIO_1_K367 149
#define FID_SCENARIO_1_K368 150
#define FID_SCENARIO_1_K369 151
#define FID_SCENARIO_1_K370 152
#define FID_SCENARIO_1_K371 153
#define FID_SCENARIO_0 154
#define FID_SCENARIO_0_K373 155
#define FID_SCENARIO_0_K374 156
#define FID_SCENARIO_0_K375 157
#define FID_SCENARIO_0_K376 158
#define FID_SCENARIO_0_K377 159
#define FID_STRING_APPEND 160
#define FID_STRING_APPEND_K379 161
#define FID_MAIN 162
#define FID_MAIN_K381 163
#define FID_MAIN_K382 164
#define FID_MAIN_K383 165
#define FID_MAIN_K384 166
#define FID_MAIN_K385 167
#define FID_MAIN_K386 168
#define FID_MAIN_K387 169
#define FID_MAIN_K388 170
#define FID_MAIN_K389 171
#define FID_MAIN_K390 172
#define FID_MAIN_K391 173
#define FID_IO_PRINT 174
#define FID_IO_EMIT 175
#define FID_CLO_APPLY 176
#define FID_EXIT 177
#define FID_ENTER 178
CONSTV u8 FID_T[][3] = { { 13, 0, 2 }, { 2, 1, 2 }, { 17, 0, 2 }, { 13, 12, 2 }, { 2, 0, 2 }, { 5, 3, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 3, 3, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 6, 0, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 13, 0, 2 }, { 13, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 14, 14, 2 }, { 4, 0, 2 }, { 5, 1, 2 }, { 2, 1, 2 }, { 15, 0, 2 }, { 13, 1, 2 }, { 18, 0, 2 }, { 19, 13, 2 }, { 19, 14, 2 }, { 23, 0, 2 }, { 25, 20, 2 }, { 25, 20, 2 }, { 23, 0, 2 }, { 25, 20, 2 }, { 25, 20, 2 }, { 30, 0, 2 }, { 27, 1, 2 }, { 15, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 12, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 13, 0, 2 }, { 14, 13, 2 }, { 13, 0, 2 }, { 13, 12, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 27, 0, 2 }, { 27, 1, 2 }, { 27, 12, 2 }, { 27, 1, 2 }, { 29, 13, 2 }, { 5, 0, 2 }, { 15, 0, 2 }, { 27, 0, 2 }, { 28, 28, 2 }, { 15, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 30, 24, 2 }, { 27, 0, 2 }, { 27, 1, 2 }, { 27, 12, 2 }, { 27, 1, 2 }, { 29, 13, 2 }, { 5, 0, 2 }, { 15, 0, 2 }, { 27, 0, 2 }, { 28, 28, 2 }, { 15, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 30, 24, 2 }, { 3, 0, 2 }, { 12, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 26, 0, 2 }, { 13, 12, 2 }, { 14, 13, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 12, 0, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 27, 0, 2 }, { 26, 1, 2 }, { 25, 0, 2 }, { 3, 0, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 3, 1, 2 }, { 25, 0, 2 }, { 29, 0, 2 }, { 28, 13, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 27, 1, 2 }, { 29, 13, 2 }, { 29, 1, 2 }, { 29, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 27, 1, 2 }, { 27, 13, 2 }, { 27, 1, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 1, 0, 2 }, { 26, 14, 2 }, { 28, 28, 2 }, { 26, 26, 2 }, { 29, 28, 2 }, { 26, 26, 2 }, { 1, 0, 2 }, { 26, 14, 2 }, { 28, 28, 2 }, { 26, 26, 2 }, { 29, 28, 2 }, { 26, 26, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 0, 1 }, { 1, 1 }, { 14, 0 }, { 2, 0 }, { 0, 1 }, { 1, 1 }, { 13, 1 }, { 18, 0 }, { 13, 0 }, { 3, 1 }, { 2, 1 }, { 2, 1 }, { 5, 1 }, { 4, 1 }, { 1, 1 }, { 10, 1 }, { 1, 1 }, { 1, 1 }, { 4, 1 }, { 18, 1 }, { 19, 1 }, { 17, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 2, 1 }, { 2, 0 }, { 2, 0 }, { 3, 0 }, { 1, 0 }, { 0, 0 }, { 20, 1 }, { 19, 1 }, { 2, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 4, 1 }, { 3, 1 }, { 0, 1 }, { 1, 1 }, { 3, 0 }, { 0, 1 }, { 1, 1 }, { 2, 0 } };
#define STAT_LEN 379

#define WL_RESW 28
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
    if ((N) <= 29) break; r29 = e.mem[(A) + 29]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
    case 29: r29 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25; (V)[26] = r26; (V)[27] = r27;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25]; r26 = (V)[26]; r27 = (V)[27];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29

#define WL_TABLE WL_X(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0) WL_X(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0_K3) WL_X(FID_______SRC_ECS_TRANSACTION_FINISH_0) WL_X(FID_______SRC_ECS_TRANSACTION_FINISH_0_K23) WL_X(FID_STRING_CMP) WL_X(FID_STRING_CMP_K35) WL_X(FID_LIST_LENGTH) WL_X(FID_LIST_LENGTH_K47) WL_X(FID_STRING_ORDER) WL_X(FID_STRING_ORDER_K49) WL_X(FID_QUEUED_RESERVED_C58) WL_X(FID_______SRC_ECS_WORLD_ACCESS_EQUAL) WL_X(FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K64) WL_X(FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K65) WL_X(FID_STRING_EQ) WL_X(FID_STRING_EQ_K67) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K74) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K75) WL_X(FID_RUNNER) WL_X(FID_RUNNER_K77) WL_X(FID_RUNNER_C78) WL_X(FID_RUNNER_C79) WL_X(FID_RUNNER_K80) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K83) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K84) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0) WL_X(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K88) WL_X(FID_______SRC_ECS_SYSTEM_RUN_0) WL_X(FID_______SRC_ECS_SYSTEM_RUN_0_K106) WL_X(FID_______SRC_ECS_SYSTEM_RUN_0_K107) WL_X(FID_DISPATCH_FAIL) WL_X(FID_DISPATCH_FAIL_K124) WL_X(FID_DISPATCH_FAIL_K125) WL_X(FID_DISPATCH) WL_X(FID_DISPATCH_K130) WL_X(FID_DISPATCH_K131) WL_X(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0) WL_X(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K133) WL_X(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K134) WL_X(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K135) WL_X(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K136) WL_X(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K137) WL_X(FID_GAMEPLAY_READ_0) WL_X(FID_GAMEPLAY_READ_0_C145) WL_X(FID_GAMEPLAY_READ_0_K146) WL_X(FID_CONDITION) WL_X(FID_CONDITION_K161) WL_X(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0) WL_X(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K171) WL_X(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K172) WL_X(FID_SHOW_LINES) WL_X(FID_SHOW_LINES_K174) WL_X(FID_SHOW_LINES_K175) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K177) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K178) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K179) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K180) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C181) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C182) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C183) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K184) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K185) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K186) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K187) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K188) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K189) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K191) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K192) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K193) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K194) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C195) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C196) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C197) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K198) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K199) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K200) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K201) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K202) WL_X(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K203) WL_X(FID_U32_SHOW_GO) WL_X(FID_______SRC_ECS_WORLD_BARRIER_0) WL_X(FID_IDS) WL_X(FID_IDS_K217) WL_X(FID_IDS_K218) WL_X(FID_IDS_K219) WL_X(FID_NUMBERS) WL_X(FID_NUMBERS_K229) WL_X(FID_NUMBERS_K230) WL_X(FID_NUMBERS_K231) WL_X(FID_U32_SHOW) WL_X(FID_FINAL) WL_X(FID_FINAL_K239) WL_X(FID_FINAL_K240) WL_X(FID_FINAL_K241) WL_X(FID_FINAL_K242) WL_X(FID_FINAL_K243) WL_X(FID_______SRC_ECS_SCHEDULE_CONTAINS) WL_X(FID_______SRC_ECS_SCHEDULE_CONTAINS_K250) WL_X(FID_SHOW_STEPS) WL_X(FID_SHOW_STEPS_K254) WL_X(FID_SHOW_STEPS_K255) WL_X(FID_SHOW_STEPS_K256) WL_X(FID_SHOW_STEPS_K257) WL_X(FID_SHOW_STEPS_K258) WL_X(FID_SHOW_STEPS_K259) WL_X(FID_SHOW_STEPS_K260) WL_X(FID_SHOW_STEPS_K261) WL_X(FID_SHOW_STEPS_K262) WL_X(FID_SHOW_STEPS_K263) WL_X(FID_SHOW_STEPS_K264) WL_X(FID_SHOW_STEPS_K265) WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K267) WL_X(FID_CAPTURE) WL_X(FID_CAPTURE_K269) WL_X(FID_CAPTURE_K270) WL_X(FID_CAPTURE_K271) WL_X(FID_CAPTURE_K272) WL_X(FID_CAPTURE_K273) WL_X(FID_CAPTURE_K274) WL_X(FID_CAPTURE_K275) WL_X(FID_RECORD_CAPTURE) WL_X(FID_RECORD_CAPTURE_K277) WL_X(FID_______SRC_ECS_SCHEDULE_RUN_1) WL_X(FID_______SRC_ECS_SCHEDULE_VALID) WL_X(FID_______SRC_ECS_SCHEDULE_VALID_K288) WL_X(FID_______SRC_ECS_SCHEDULE_VALID_K289) WL_X(FID_______SRC_ECS_SCHEDULE_VALID_K290) WL_X(FID_______SRC_ECS_SCHEDULE_RUN_0) WL_X(FID_RECORD_RUN) WL_X(FID_RECORD_RUN_K294) WL_X(FID_RECORD_RUN_K295) WL_X(FID_RECORD_RUN_K296) WL_X(FID_RECORD_RUN_K297) WL_X(FID_RECORD_RUN_K298) WL_X(FID_RECORD_RUN_K299) WL_X(FID_RECORD_RUN_K300) WL_X(FID_RECORD_RUN_K301) WL_X(FID_RECORD_RUN_K302) WL_X(FID_RECORD_RUN_K303) WL_X(FID_RECORD_RUN_K304) WL_X(FID_RECORD_RUN_K305) WL_X(FID_______SRC_ECS_SCHEDULE_BUILD_0) WL_X(FID_______SRC_ECS_SCHEDULE_BUILD_0_K317) WL_X(FID_SCENARIO_1) WL_X(FID_SCENARIO_1_K367) WL_X(FID_SCENARIO_1_K368) WL_X(FID_SCENARIO_1_K369) WL_X(FID_SCENARIO_1_K370) WL_X(FID_SCENARIO_1_K371) WL_X(FID_SCENARIO_0) WL_X(FID_SCENARIO_0_K373) WL_X(FID_SCENARIO_0_K374) WL_X(FID_SCENARIO_0_K375) WL_X(FID_SCENARIO_0_K376) WL_X(FID_SCENARIO_0_K377) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K379) WL_X(FID_MAIN) WL_X(FID_MAIN_K381) WL_X(FID_MAIN_K382) WL_X(FID_MAIN_K383) WL_X(FID_MAIN_K384) WL_X(FID_MAIN_K385) WL_X(FID_MAIN_K386) WL_X(FID_MAIN_K387) WL_X(FID_MAIN_K388) WL_X(FID_MAIN_K389) WL_X(FID_MAIN_K390) WL_X(FID_MAIN_K391) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 2), 110ull, term_ctr(CID_SCON, STAT_OFF + 4), 97ull, term_ctr(CID_SCON, STAT_OFF + 6), 108ull, term_ctr(CID_SCON, STAT_OFF + 8), 112ull, term_ctr(CID_SCON, STAT_OFF + 10), 2ull, term_pak(CID_NIL, 0), 110ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 16), 105ull, term_ctr(CID_SCON, STAT_OFF + 18), 116ull, term_ctr(CID_SCON, STAT_OFF + 20), 97ull, term_ctr(CID_SCON, STAT_OFF + 22), 114ull, term_ctr(CID_SCON, STAT_OFF + 24), 116ull, term_ctr(CID_SCON, STAT_OFF + 26), 115ull, term_ctr(CID_SCON, STAT_OFF + 28), 105ull, term_ctr(CID_SCON, STAT_OFF + 30), 103ull, term_ctr(CID_SCON, STAT_OFF + 32), 101ull, term_ctr(CID_SCON, STAT_OFF + 34), 114ull, term_ctr(CID_SCON, STAT_OFF + 36), 119ull, term_ctr(CID_SCON, STAT_OFF + 16), 111ull, term_ctr(CID_SCON, STAT_OFF + 40), 110ull, term_ctr(CID_SCON, STAT_OFF + 42), 107ull, term_ctr(CID_SCON, STAT_OFF + 44), 110ull, term_ctr(CID_SCON, STAT_OFF + 46), 117ull, term_ctr(CID_SCON, STAT_OFF + 48), 10ull, term_pak(CID_SNIL, 0), term_pak(CID_______SRC_ECS_SCHEDULE_APPLIED, 0), term_pak(CID_NIL, 0), 58ull, term_pak(CID_SNIL, 0), 104ull, term_ctr(CID_SCON, STAT_OFF + 56), 115ull, term_ctr(CID_SCON, STAT_OFF + 58), 117ull, term_ctr(CID_SCON, STAT_OFF + 60), 108ull, term_ctr(CID_SCON, STAT_OFF + 62), 102ull, term_ctr(CID_SCON, STAT_OFF + 64), 48ull, term_pak(CID_SNIL, 0), 44ull, term_pak(CID_SNIL, 0), 59ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 56), 115ull, term_ctr(CID_SCON, STAT_OFF + 74), 97ull, term_ctr(CID_SCON, STAT_OFF + 76), 104ull, term_ctr(CID_SCON, STAT_OFF + 78), 112ull, term_ctr(CID_SCON, STAT_OFF + 80), 110ull, term_ctr(CID_SCON, STAT_OFF + 56), 117ull, term_ctr(CID_SCON, STAT_OFF + 84), 114ull, term_ctr(CID_SCON, STAT_OFF + 86), 112ull, term_ctr(CID_SCON, STAT_OFF + 56), 105ull, term_ctr(CID_SCON, STAT_OFF + 90), 107ull, term_ctr(CID_SCON, STAT_OFF + 92), 115ull, term_ctr(CID_SCON, STAT_OFF + 94), 114ull, term_ctr(CID_SCON, STAT_OFF + 72), 101ull, term_ctr(CID_SCON, STAT_OFF + 98), 105ull, term_ctr(CID_SCON, STAT_OFF + 100), 114ull, term_ctr(CID_SCON, STAT_OFF + 102), 114ull, term_ctr(CID_SCON, STAT_OFF + 104), 97ull, term_ctr(CID_SCON, STAT_OFF + 106), 98ull, term_ctr(CID_SCON, STAT_OFF + 108), 107ull, term_ctr(CID_SCON, STAT_OFF + 56), 111ull, term_ctr(CID_SCON, STAT_OFF + 112), 108ull, term_ctr(CID_SCON, STAT_OFF + 56), 105ull, term_ctr(CID_SCON, STAT_OFF + 116), 97ull, term_ctr(CID_SCON, STAT_OFF + 118), 102ull, term_ctr(CID_SCON, STAT_OFF + 120), 116ull, term_ctr(CID_SCON, STAT_OFF + 2), 99ull, term_ctr(CID_SCON, STAT_OFF + 124), 101ull, term_ctr(CID_SCON, STAT_OFF + 126), 106ull, term_ctr(CID_SCON, STAT_OFF + 128), 101ull, term_ctr(CID_SCON, STAT_OFF + 130), 114ull, term_ctr(CID_SCON, STAT_OFF + 132), term_ctr(CID_SCON, STAT_OFF + 134), term_pak(CID_NIL, 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 52), 105ull, term_ctr(CID_SCON, STAT_OFF + 138), 108ull, term_ctr(CID_SCON, STAT_OFF + 140), 97ull, term_ctr(CID_SCON, STAT_OFF + 142), 118ull, term_ctr(CID_SCON, STAT_OFF + 144), 110ull, term_ctr(CID_SCON, STAT_OFF + 146), 105ull, term_ctr(CID_SCON, STAT_OFF + 148), 108ull, term_ctr(CID_SCON, STAT_OFF + 2), 105ull, term_ctr(CID_SCON, STAT_OFF + 152), 97ull, term_ctr(CID_SCON, STAT_OFF + 154), 102ull, term_ctr(CID_SCON, STAT_OFF + 156), 45ull, term_ctr(CID_SCON, STAT_OFF + 158), 110ull, term_ctr(CID_SCON, STAT_OFF + 160), 111ull, term_ctr(CID_SCON, STAT_OFF + 162), 105ull, term_ctr(CID_SCON, STAT_OFF + 164), 116ull, term_ctr(CID_SCON, STAT_OFF + 166), 97ull, term_ctr(CID_SCON, STAT_OFF + 168), 114ull, term_ctr(CID_SCON, STAT_OFF + 170), 116ull, term_ctr(CID_SCON, STAT_OFF + 172), 115ull, term_ctr(CID_SCON, STAT_OFF + 174), 105ull, term_ctr(CID_SCON, STAT_OFF + 176), 103ull, term_ctr(CID_SCON, STAT_OFF + 178), 101ull, term_ctr(CID_SCON, STAT_OFF + 180), 114ull, term_ctr(CID_SCON, STAT_OFF + 182), 107ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 186), 105ull, term_ctr(CID_SCON, STAT_OFF + 188), 116ull, term_ctr(CID_SCON, STAT_OFF + 190), 1ull, term_ctr(CID_CON, STAT_OFF + 14), 66ull, term_pak(CID_SNIL, 0), 101ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 198), 105ull, term_ctr(CID_SCON, STAT_OFF + 200), 114ull, term_ctr(CID_SCON, STAT_OFF + 202), 119ull, term_ctr(CID_SCON, STAT_OFF + 204), 46ull, term_ctr(CID_SCON, STAT_OFF + 206), 101ull, term_ctr(CID_SCON, STAT_OFF + 208), 99ull, term_ctr(CID_SCON, STAT_OFF + 210), 114ull, term_ctr(CID_SCON, STAT_OFF + 212), 117ull, term_ctr(CID_SCON, STAT_OFF + 214), 111ull, term_ctr(CID_SCON, STAT_OFF + 216), 115ull, term_ctr(CID_SCON, STAT_OFF + 218), 101ull, term_ctr(CID_SCON, STAT_OFF + 220), 114ull, term_ctr(CID_SCON, STAT_OFF + 222), 104ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 226), 105ull, term_ctr(CID_SCON, STAT_OFF + 228), 108ull, term_ctr(CID_SCON, STAT_OFF + 230), 98ull, term_ctr(CID_SCON, STAT_OFF + 232), 117ull, term_ctr(CID_SCON, STAT_OFF + 234), 112ull, term_ctr(CID_SCON, STAT_OFF + 236), 46ull, term_ctr(CID_SCON, STAT_OFF + 238), 115ull, term_ctr(CID_SCON, STAT_OFF + 240), 116ull, term_ctr(CID_SCON, STAT_OFF + 242), 110ull, term_ctr(CID_SCON, STAT_OFF + 244), 101ull, term_ctr(CID_SCON, STAT_OFF + 246), 118ull, term_ctr(CID_SCON, STAT_OFF + 248), 101ull, term_ctr(CID_SCON, STAT_OFF + 250), term_ctr(CID_SCON, STAT_OFF + 252), term_pak(CID_NIL, 0), term_ctr(CID_SCON, STAT_OFF + 224), term_ctr(CID_CON, STAT_OFF + 254), 101ull, term_ctr(CID_SCON, STAT_OFF + 160), 116ull, term_ctr(CID_SCON, STAT_OFF + 258), 97ull, term_ctr(CID_SCON, STAT_OFF + 260), 101ull, term_ctr(CID_SCON, STAT_OFF + 262), 114ull, term_ctr(CID_SCON, STAT_OFF + 264), 99ull, term_ctr(CID_SCON, STAT_OFF + 266), 65ull, term_pak(CID_SNIL, 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 198), 101ull, term_ctr(CID_SCON, STAT_OFF + 272), 117ull, term_ctr(CID_SCON, STAT_OFF + 274), 113ull, term_ctr(CID_SCON, STAT_OFF + 276), 110ull, term_ctr(CID_SCON, STAT_OFF + 278), 101ull, term_ctr(CID_SCON, STAT_OFF + 280), 46ull, term_ctr(CID_SCON, STAT_OFF + 282), 115ull, term_ctr(CID_SCON, STAT_OFF + 284), 100ull, term_ctr(CID_SCON, STAT_OFF + 286), 110ull, term_ctr(CID_SCON, STAT_OFF + 288), 97ull, term_ctr(CID_SCON, STAT_OFF + 290), 109ull, term_ctr(CID_SCON, STAT_OFF + 292), 109ull, term_ctr(CID_SCON, STAT_OFF + 294), 111ull, term_ctr(CID_SCON, STAT_OFF + 296), 99ull, term_ctr(CID_SCON, STAT_OFF + 298), term_ctr(CID_SCON, STAT_OFF + 300), term_pak(CID_NIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 198), 111ull, term_ctr(CID_SCON, STAT_OFF + 304), 102ull, term_ctr(CID_SCON, STAT_OFF + 306), 101ull, term_ctr(CID_SCON, STAT_OFF + 308), 98ull, term_ctr(CID_SCON, STAT_OFF + 310), term_ctr(CID_SCON, STAT_OFF + 312), 1ull, 1ull, 114ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 317), 116ull, term_ctr(CID_SCON, STAT_OFF + 319), 102ull, term_ctr(CID_SCON, STAT_OFF + 321), 97ull, term_ctr(CID_SCON, STAT_OFF + 323), term_ctr(CID_SCON, STAT_OFF + 325), 2ull, 1ull, term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 328), term_pak(CID_NIL, 0), term_ctr(CID_______SRC_ECS_SCHEDULE_PHASE, STAT_OFF + 327), term_ctr(CID_CON, STAT_OFF + 330), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 315), term_ctr(CID_CON, STAT_OFF + 332), term_ctr(CID_______SRC_ECS_SCHEDULE_PHASE, STAT_OFF + 314), term_ctr(CID_CON, STAT_OFF + 334), term_pak(CID_______SRC_ECS_SCHEDULE_BARRIER, 0), term_ctr(CID_CON, STAT_OFF + 332), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 315), term_ctr(CID_CON, STAT_OFF + 338), term_ctr(CID_______SRC_ECS_SCHEDULE_PHASE, STAT_OFF + 314), term_ctr(CID_CON, STAT_OFF + 340), 2ull, 0ull, term_pak(CID_______SRC_ECS_SCHEDULE_BARRIER, 0), term_pak(CID_NIL, 0), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 344), term_ctr(CID_CON, STAT_OFF + 346), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 315), term_ctr(CID_CON, STAT_OFF + 348), 1ull, 0ull, term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 352), term_pak(CID_NIL, 0), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 315), term_ctr(CID_CON, STAT_OFF + 354), 3ull, 1ull, term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 358), term_pak(CID_NIL, 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 304), 108ull, term_ctr(CID_SCON, STAT_OFF + 362), 105ull, term_ctr(CID_SCON, STAT_OFF + 364), 97ull, term_ctr(CID_SCON, STAT_OFF + 366), 102ull, term_ctr(CID_SCON, STAT_OFF + 368), term_ctr(CID_SCON, STAT_OFF + 370), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 328), term_ctr(CID_CON, STAT_OFF + 346), term_ctr(CID_______SRC_ECS_SCHEDULE_SYSTEM, STAT_OFF + 315), term_ctr(CID_CON, STAT_OFF + 373), term_ctr(CID_______SRC_ECS_SCHEDULE_PHASE, STAT_OFF + 372), term_ctr(CID_CON, STAT_OFF + 375) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  Term _command_0 = r12;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _command_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_20);
    _v_24 = _world_12;
    _v_25 = _world_13;
    _v_26 = _world_14;
    _v_27 = _world_15;
    _v_28 = _world_16;
    _v_29 = _world_17;
    _v_30 = _world_18;
    _v_31 = _world_19;
    _v_32 = term_ctr(CID_CON, _nd_0);
    _v_33 = _world_21;
    _v_34 = _world_22;
    _v_35 = _world_23;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h4 = r4;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _commands_1 = r0;
  u32 _world_12 = r1;
  u32 _world_13 = r2;
  u32 _world_14 = r3;
  Term _world_15 = r4;
  u32 _world_16 = r5;
  Term _world_17 = r6;
  u32 _world_18 = r7;
  Term _world_19 = r8;
  Term _world_20 = r9;
  Term _world_21 = r10;
  u32 _world_22 = r11;
  u32 _world_23 = r12;
  WL_SPIN
    if (term_aux(_commands_1) == CID_NIL) {
      _v_12 = _world_12;
      _v_13 = _world_13;
      _v_14 = _world_14;
      _v_15 = _world_15;
      _v_16 = _world_16;
      _v_17 = _world_17;
      _v_18 = _world_18;
      _v_19 = _world_19;
      _v_20 = _world_20;
      _v_21 = _world_21;
      _v_22 = _world_22;
      _v_23 = _world_23;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _v_24 = 0;
      u32 _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      Term _v_29 = 0;
      u32 _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      u32 _v_40 = 0;
      Term _v_41 = 0;
      u32 _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_0[12];
      if (spin_0(e, _o_0, _world_12, _world_13, _world_14, _world_15, _world_15 == h4 ? q4 : blk_loc(e.mem, _world_15), _world_16, _world_17, _world_18, _world_19, _world_19 == h8 ? q8 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h9 ? q9 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h10 ? q10 : blk_loc(e.mem, _world_21), _world_22, _world_23, _f_0, _f_0 == h10 ? q10 : _f_0 == h9 ? q9 : _f_0 == h8 ? q8 : _f_0 == h4 ? q4 : _f_0 == h0 ? q0 : blk_loc(e.mem, _f_0)) == 0) {
        return 0;
      }
      _v_36 = _o_0[0];
      _v_37 = _o_0[1];
      _v_38 = _o_0[2];
      _v_39 = _o_0[3];
      _v_40 = _o_0[4];
      _v_41 = _o_0[5];
      _v_42 = _o_0[6];
      _v_43 = _o_0[7];
      _v_44 = _o_0[8];
      _v_45 = _o_0[9];
      _v_46 = _o_0[10];
      _v_47 = _o_0[11];
      _v_24 = _v_36;
      _v_25 = _v_37;
      _v_26 = _v_38;
      _v_27 = _v_39;
      _v_28 = _v_40;
      _v_29 = _v_41;
      _v_30 = _v_42;
      _v_31 = _v_43;
      _v_32 = _v_44;
      _v_33 = _v_45;
      _v_34 = _v_46;
      _v_35 = _v_47;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_24;
      r2 = _v_25;
      r3 = _v_26;
      r4 = _v_27;
      r5 = _v_28;
      r6 = _v_29;
      r7 = _v_30;
      r8 = _v_31;
      r9 = _v_32;
      r10 = _v_33;
      r11 = _v_34;
      r12 = _v_35;
      _commands_1 = r0;
      _world_12 = r1;
      _world_13 = r2;
      _world_14 = r3;
      _world_15 = r4;
      _world_16 = r5;
      _world_17 = r6;
      _world_18 = r7;
      _world_19 = r8;
      _world_20 = r9;
      _world_21 = r10;
      _world_22 = r11;
      _world_23 = r12;
      WL_AGAIN(spin_1);
    }
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  o[6] = _v_18;
  o[7] = _v_19;
  o[8] = _v_20;
  o[9] = _v_21;
  o[10] = _v_22;
  o[11] = _v_23;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_3 = 0;
    } else {
      _v_3 = _b_0;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, u32 r13, u32 r14, u32 r15) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _allowed_0 = r0;
  u32 _value_1 = r1;
  u32 _world_0 = r2;
  u32 _world_1 = r3;
  u32 _world_2 = r4;
  Term _world_3 = r5;
  u32 _world_4 = r6;
  Term _world_5 = r7;
  u32 _world_6 = r8;
  Term _world_7 = r9;
  Term _world_8 = r10;
  Term _world_9 = r11;
  u32 _world_10 = r12;
  u32 _world_11 = r13;
  u32 _handle_2 = r14;
  u32 _handle_3 = r15;
  WL_SPIN
    if (_allowed_0 == 0) {
      _v_14 = _world_0;
      _v_15 = _world_1;
      _v_16 = _world_2;
      _v_17 = _world_3;
      _v_18 = _world_4;
      _v_19 = _world_5;
      _v_20 = _world_6;
      _v_21 = _world_7;
      _v_22 = _world_8;
      _v_23 = _world_9;
      _v_24 = _world_10;
      _v_25 = _world_11;
      _v_26 = 1;
      _v_27 = 0;
    } else {
      Term _at_0 = _world_3 == h5 ? q5 : blk_loc(e.mem, _world_3);
      Term _at_1 = blk_at(_world_3, _handle_3, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      blk_write(e.mem, 0, _at_0, _at_1 + 0, _value_1);
      _v_14 = _world_0;
      _v_15 = _world_1;
      _v_16 = _world_2;
      _v_17 = _world_3;
      _v_18 = _world_4;
      _v_19 = _world_5;
      _v_20 = _world_6;
      _v_21 = _world_7;
      _v_22 = _world_8;
      _v_23 = _world_9;
      _v_24 = _world_10;
      _v_25 = _world_11;
      _v_26 = 0;
      _v_27 = 0;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_16 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_16 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_5);
    }
  break;
  }
  o[0] = _v_16;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_14 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_15 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_5(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_14 = _v_15;
  break;
  }
  o[0] = _v_14;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  Term _commands_1 = r12;
  WL_SPIN
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    Term _o_2[12];
    if (spin_1(e, _o_2, _commands_1, _commands_1 == h12 ? q12 : blk_loc(e.mem, _commands_1), _world_12, _world_13, _world_14, _world_15, _world_15 == h3 ? q3 : blk_loc(e.mem, _world_15), _world_16, _world_17, _world_18, _world_19, _world_19 == h7 ? q7 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h8 ? q8 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h9 ? q9 : blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_41 = _o_2[0];
    _v_42 = _o_2[1];
    _v_43 = _o_2[2];
    _v_44 = _o_2[3];
    _v_45 = _o_2[4];
    _v_46 = _o_2[5];
    _v_47 = _o_2[6];
    _v_48 = _o_2[7];
    _v_49 = _o_2[8];
    _v_50 = _o_2[9];
    _v_51 = _o_2[10];
    _v_52 = _o_2[11];
    _v_29 = _v_41;
    _v_30 = _v_42;
    _v_31 = _v_43;
    _v_32 = _v_44;
    _v_33 = _v_45;
    _v_34 = _v_46;
    _v_35 = _v_47;
    _v_36 = _v_48;
    _v_37 = _v_49;
    _v_38 = _v_50;
    _v_39 = _v_51;
    _v_40 = _v_52;
  break;
  }
  o[0] = _v_29;
  o[1] = _v_30;
  o[2] = _v_31;
  o[3] = _v_32;
  o[4] = _v_33;
  o[5] = _v_34;
  o[6] = _v_35;
  o[7] = _v_36;
  o[8] = _v_37;
  o[9] = _v_38;
  o[10] = _v_39;
  o[11] = _v_40;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_69 = 0;
  Term _xs_3 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_xs_3) == CID_NIL) {
      _v_69 = _acc_1;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _xs_3, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_3;
      r1 = term_ctr(CID_CON, _nd_1);
      _xs_3 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_8);
    }
  break;
  }
  o[0] = _v_69;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_67 = 0;
  Term _xs_2 = r0;
  WL_SPIN
    Term _v_68 = 0;
    Term _o_4[1];
    Term _a_1 = term_pak(CID_NIL, 0);
    if (spin_8(e, _o_4, _xs_2, _xs_2 == h0 ? q0 : blk_loc(e.mem, _xs_2), _a_1, _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_68 = _o_4[0];
    _v_67 = _v_68;
  break;
  }
  o[0] = _v_67;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_148 = 0;
  Term _reversed_0 = r0;
  Term _output_0 = r1;
  WL_SPIN
    if (term_aux(_reversed_0) == CID_NIL) {
      _v_148 = _output_0;
    } else {
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _reversed_0, 2, _fb_3);
      Term _f_6 = _fb_3[0];
      Term _f_7 = _fb_3[1];
      u64 _nd_3 = _sp_3 >= HEAP_OFF ? _sp_3 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, _f_6);
      e.mem[_nd_3 + 1] = rfc_seal(e, _output_0);
      r0 = _f_7;
      r1 = term_ctr(CID_CON, _nd_3);
      _reversed_0 = r0;
      _output_0 = r1;
      WL_AGAIN(spin_13);
    }
  break;
  }
  o[0] = _v_148;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_144 = 0;
  Term _left_0 = r0;
  Term _right_0 = r1;
  WL_SPIN
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _o_6[1];
    if (spin_7(e, _o_6, _left_0, _left_0 == h0 ? q0 : blk_loc(e.mem, _left_0)) == 0) {
      return 0;
    }
    _v_146 = _o_6[0];
    _v_145 = _v_146;
    Term _v_147 = 0;
    Term _o_7[1];
    if (spin_13(e, _o_7, _v_145, _v_145 == h1 ? q1 : _v_145 == h0 ? q0 : blk_loc(e.mem, _v_145), _right_0, _right_0 == h1 ? q1 : blk_loc(e.mem, _right_0)) == 0) {
      return 0;
    }
    _v_147 = _o_7[0];
    _v_144 = _v_147;
  break;
  }
  o[0] = _v_144;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  u32 _v_130 = 0;
  u32 _v_131 = 0;
  u32 _v_132 = 0;
  Term _v_133 = 0;
  u32 _v_134 = 0;
  Term _v_135 = 0;
  u32 _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  Term _v_139 = 0;
  u32 _v_140 = 0;
  u32 _v_141 = 0;
  u32 _world_48 = r0;
  u32 _world_49 = r1;
  u32 _world_50 = r2;
  Term _world_51 = r3;
  u32 _world_52 = r4;
  Term _world_53 = r5;
  u32 _world_54 = r6;
  Term _world_55 = r7;
  Term _world_56 = r8;
  Term _world_57 = r9;
  u32 _world_58 = r10;
  u32 _world_59 = r11;
  Term _published_1 = r12;
  WL_SPIN
    Term _v_142 = 0;
    Term _v_143 = 0;
    Term _o_8[1];
    if (spin_12(e, _o_8, _world_55, _world_55 == h7 ? q7 : blk_loc(e.mem, _world_55), _published_1, _published_1 == h12 ? q12 : blk_loc(e.mem, _published_1)) == 0) {
      return 0;
    }
    _v_143 = _o_8[0];
    _v_142 = _v_143;
    _v_130 = _world_48;
    _v_131 = _world_49;
    _v_132 = _world_50;
    _v_133 = _world_51;
    _v_134 = _world_52;
    _v_135 = _world_53;
    _v_136 = _world_54;
    _v_137 = _v_142;
    _v_138 = _world_56;
    _v_139 = _world_57;
    _v_140 = _world_58;
    _v_141 = _world_59;
  break;
  }
  o[0] = _v_130;
  o[1] = _v_131;
  o[2] = _v_132;
  o[3] = _v_133;
  o[4] = _v_134;
  o[5] = _v_135;
  o[6] = _v_136;
  o[7] = _v_137;
  o[8] = _v_138;
  o[9] = _v_139;
  o[10] = _v_140;
  o[11] = _v_141;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  u32 _v_106 = 0;
  u32 _v_107 = 0;
  u32 _v_108 = 0;
  Term _v_109 = 0;
  u32 _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  Term _v_114 = 0;
  Term _v_115 = 0;
  u32 _v_116 = 0;
  u32 _v_117 = 0;
  u32 _world_36 = r0;
  u32 _world_37 = r1;
  u32 _world_38 = r2;
  Term _world_39 = r3;
  u32 _world_40 = r4;
  Term _world_41 = r5;
  u32 _world_42 = r6;
  Term _world_43 = r7;
  Term _world_44 = r8;
  Term _world_45 = r9;
  u32 _world_46 = r10;
  u32 _world_47 = r11;
  Term _published_0 = r12;
  WL_SPIN
    if (term_aux(_published_0) == CID_NIL) {
      _v_106 = _world_36;
      _v_107 = _world_37;
      _v_108 = _world_38;
      _v_109 = _world_39;
      _v_110 = _world_40;
      _v_111 = _world_41;
      _v_112 = _world_42;
      _v_113 = _world_43;
      _v_114 = _world_44;
      _v_115 = _world_45;
      _v_116 = _world_46;
      _v_117 = _world_47;
    } else {
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _published_0, 2, _fb_2);
      Term _f_4 = _fb_2[0];
      Term _f_5 = _fb_2[1];
      u64 _nd_2 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _f_4);
      e.mem[_nd_2 + 1] = rfc_seal(e, _f_5);
      u32 _v_118 = 0;
      u32 _v_119 = 0;
      u32 _v_120 = 0;
      Term _v_121 = 0;
      u32 _v_122 = 0;
      Term _v_123 = 0;
      u32 _v_124 = 0;
      Term _v_125 = 0;
      Term _v_126 = 0;
      Term _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      Term _o_9[12];
      Term _a_2 = term_ctr(CID_CON, _nd_2);
      if (spin_11(e, _o_9, _world_36, _world_37, _world_38, _world_39, _world_39 == h3 ? q3 : blk_loc(e.mem, _world_39), _world_40, _world_41, _world_42, _world_43, _world_43 == h7 ? q7 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h8 ? q8 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h9 ? q9 : blk_loc(e.mem, _world_45), _world_46, _world_47, _a_2, _a_2 == h12 ? q12 : _a_2 == h9 ? q9 : _a_2 == h8 ? q8 : _a_2 == h7 ? q7 : _a_2 == h3 ? q3 : blk_loc(e.mem, _a_2)) == 0) {
        return 0;
      }
      _v_118 = _o_9[0];
      _v_119 = _o_9[1];
      _v_120 = _o_9[2];
      _v_121 = _o_9[3];
      _v_122 = _o_9[4];
      _v_123 = _o_9[5];
      _v_124 = _o_9[6];
      _v_125 = _o_9[7];
      _v_126 = _o_9[8];
      _v_127 = _o_9[9];
      _v_128 = _o_9[10];
      _v_129 = _o_9[11];
      _v_106 = _v_118;
      _v_107 = _v_119;
      _v_108 = _v_120;
      _v_109 = _v_121;
      _v_110 = _v_122;
      _v_111 = _v_123;
      _v_112 = _v_124;
      _v_113 = _v_125;
      _v_114 = _v_126;
      _v_115 = _v_127;
      _v_116 = _v_128;
      _v_117 = _v_129;
    }
  break;
  }
  o[0] = _v_106;
  o[1] = _v_107;
  o[2] = _v_108;
  o[3] = _v_109;
  o[4] = _v_110;
  o[5] = _v_111;
  o[6] = _v_112;
  o[7] = _v_113;
  o[8] = _v_114;
  o[9] = _v_115;
  o[10] = _v_116;
  o[11] = _v_117;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  Term _v_90 = 0;
  Term _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  u32 _world_30 = r6;
  Term _world_31 = r7;
  Term _world_32 = r8;
  Term _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  Term _events_1 = r12;
  WL_SPIN
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    Term _o_10[12];
    if (spin_10(e, _o_10, _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h8 ? q8 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h9 ? q9 : blk_loc(e.mem, _world_33), _world_34, _world_35, _events_1, _events_1 == h12 ? q12 : blk_loc(e.mem, _events_1)) == 0) {
      return 0;
    }
    _v_94 = _o_10[0];
    _v_95 = _o_10[1];
    _v_96 = _o_10[2];
    _v_97 = _o_10[3];
    _v_98 = _o_10[4];
    _v_99 = _o_10[5];
    _v_100 = _o_10[6];
    _v_101 = _o_10[7];
    _v_102 = _o_10[8];
    _v_103 = _o_10[9];
    _v_104 = _o_10[10];
    _v_105 = _o_10[11];
    _v_82 = _v_94;
    _v_83 = _v_95;
    _v_84 = _v_96;
    _v_85 = _v_97;
    _v_86 = _v_98;
    _v_87 = _v_99;
    _v_88 = _v_100;
    _v_89 = _v_101;
    _v_90 = _v_102;
    _v_91 = _v_103;
    _v_92 = _v_104;
    _v_93 = _v_105;
  break;
  }
  o[0] = _v_82;
  o[1] = _v_83;
  o[2] = _v_84;
  o[3] = _v_85;
  o[4] = _v_86;
  o[5] = _v_87;
  o[6] = _v_88;
  o[7] = _v_89;
  o[8] = _v_90;
  o[9] = _v_91;
  o[10] = _v_92;
  o[11] = _v_93;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  Term _v_75 = 0;
  Term _v_76 = 0;
  Term _v_77 = 0;
  u32 _v_78 = 0;
  u32 _v_79 = 0;
  u32 _v_80 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  u32 _handle_2 = r12;
  u32 _handle_3 = r13;
  WL_SPIN
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _o_0[1];
    if (spin_2(e, _o_0, U32_BIN(0ull, <, _handle_3), U32_BIN(_handle_3, <, _world_13)) == 0) {
      return 0;
    }
    _v_83 = _o_0[0];
    _v_82 = _v_83;
    u32 _v_84 = 0;
    Term _o_1[1];
    if (spin_2(e, _o_1, U32_BIN(_world_12, ==, _handle_2), _v_82) == 0) {
      return 0;
    }
    _v_84 = _o_1[0];
    _v_81 = _v_84;
    _v_68 = _world_12;
    _v_69 = _world_13;
    _v_70 = _world_14;
    _v_71 = _world_15;
    _v_72 = _world_16;
    _v_73 = _world_17;
    _v_74 = _world_18;
    _v_75 = _world_19;
    _v_76 = _world_20;
    _v_77 = _world_21;
    _v_78 = _world_22;
    _v_79 = _world_23;
    _v_80 = _v_81;
  break;
  }
  o[0] = _v_68;
  o[1] = _v_69;
  o[2] = _v_70;
  o[3] = _v_71;
  o[4] = _v_72;
  o[5] = _v_73;
  o[6] = _v_74;
  o[7] = _v_75;
  o[8] = _v_76;
  o[9] = _v_77;
  o[10] = _v_78;
  o[11] = _v_79;
  o[12] = _v_80;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15) {
  u32 wpoll = 0;
  Term h6 = r6;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_99 = 0;
  u32 _v_100 = 0;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  Term _v_104 = 0;
  u32 _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  Term _v_108 = 0;
  u32 _v_109 = 0;
  u32 _v_110 = 0;
  u32 _v_111 = 0;
  u32 _v_112 = 0;
  u32 _value_0 = r0;
  u32 _handle_4 = r1;
  u32 _handle_5 = r2;
  u32 _checked_0 = r3;
  u32 _checked_1 = r4;
  u32 _checked_2 = r5;
  Term _checked_3 = r6;
  u32 _checked_4 = r7;
  Term _checked_5 = r8;
  u32 _checked_6 = r9;
  Term _checked_7 = r10;
  Term _checked_8 = r11;
  Term _checked_9 = r12;
  u32 _checked_10 = r13;
  u32 _checked_11 = r14;
  u32 _checked_12 = r15;
  WL_SPIN
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    Term _v_116 = 0;
    u32 _v_117 = 0;
    Term _v_118 = 0;
    u32 _v_119 = 0;
    Term _v_120 = 0;
    Term _v_121 = 0;
    Term _v_122 = 0;
    u32 _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    Term _o_3[14];
    if (spin_3(e, _o_3, _checked_12, _value_0, _checked_0, _checked_1, _checked_2, _checked_3, _checked_3 == h6 ? q6 : blk_loc(e.mem, _checked_3), _checked_4, _checked_5, _checked_6, _checked_7, _checked_7 == h10 ? q10 : blk_loc(e.mem, _checked_7), _checked_8, _checked_8 == h11 ? q11 : blk_loc(e.mem, _checked_8), _checked_9, _checked_9 == h12 ? q12 : blk_loc(e.mem, _checked_9), _checked_10, _checked_11, _handle_4, _handle_5) == 0) {
      return 0;
    }
    _v_113 = _o_3[0];
    _v_114 = _o_3[1];
    _v_115 = _o_3[2];
    _v_116 = _o_3[3];
    _v_117 = _o_3[4];
    _v_118 = _o_3[5];
    _v_119 = _o_3[6];
    _v_120 = _o_3[7];
    _v_121 = _o_3[8];
    _v_122 = _o_3[9];
    _v_123 = _o_3[10];
    _v_124 = _o_3[11];
    _v_125 = _o_3[12];
    _v_126 = _o_3[13];
    _v_99 = _v_113;
    _v_100 = _v_114;
    _v_101 = _v_115;
    _v_102 = _v_116;
    _v_103 = _v_117;
    _v_104 = _v_118;
    _v_105 = _v_119;
    _v_106 = _v_120;
    _v_107 = _v_121;
    _v_108 = _v_122;
    _v_109 = _v_123;
    _v_110 = _v_124;
    _v_111 = _v_125;
    _v_112 = _v_126;
  break;
  }
  o[0] = _v_99;
  o[1] = _v_100;
  o[2] = _v_101;
  o[3] = _v_102;
  o[4] = _v_103;
  o[5] = _v_104;
  o[6] = _v_105;
  o[7] = _v_106;
  o[8] = _v_107;
  o[9] = _v_108;
  o[10] = _v_109;
  o[11] = _v_110;
  o[12] = _v_111;
  o[13] = _v_112;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _handle_0 = r12;
  u32 _handle_1 = r13;
  WL_SPIN
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    u32 _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    Term _o_2[13];
    if (spin_15(e, _o_2, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_11, _handle_0, _handle_1) == 0) {
      return 0;
    }
    _v_55 = _o_2[0];
    _v_56 = _o_2[1];
    _v_57 = _o_2[2];
    _v_58 = _o_2[3];
    _v_59 = _o_2[4];
    _v_60 = _o_2[5];
    _v_61 = _o_2[6];
    _v_62 = _o_2[7];
    _v_63 = _o_2[8];
    _v_64 = _o_2[9];
    _v_65 = _o_2[10];
    _v_66 = _o_2[11];
    _v_67 = _o_2[12];
    _v_42 = _v_55;
    _v_43 = _v_56;
    _v_44 = _v_57;
    _v_45 = _v_58;
    _v_46 = _v_59;
    _v_47 = _v_60;
    _v_48 = _v_61;
    _v_49 = _v_62;
    _v_50 = _v_63;
    _v_51 = _v_64;
    _v_52 = _v_65;
    _v_53 = _v_66;
    _v_54 = _v_67;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    u32 _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    Term _o_4[14];
    if (spin_16(e, _o_4, 1, _handle_0, _handle_1, _v_42, _v_43, _v_44, _v_45, _v_45 == h9 ? q9 : _v_45 == h8 ? q8 : _v_45 == h7 ? q7 : _v_45 == h3 ? q3 : blk_loc(e.mem, _v_45), _v_46, _v_47, _v_48, _v_49, _v_49 == h9 ? q9 : _v_49 == h8 ? q8 : _v_49 == h7 ? q7 : _v_49 == h3 ? q3 : blk_loc(e.mem, _v_49), _v_50, _v_50 == h9 ? q9 : _v_50 == h8 ? q8 : _v_50 == h7 ? q7 : _v_50 == h3 ? q3 : blk_loc(e.mem, _v_50), _v_51, _v_51 == h9 ? q9 : _v_51 == h8 ? q8 : _v_51 == h7 ? q7 : _v_51 == h3 ? q3 : blk_loc(e.mem, _v_51), _v_52, _v_53, _v_54) == 0) {
      return 0;
    }
    _v_85 = _o_4[0];
    _v_86 = _o_4[1];
    _v_87 = _o_4[2];
    _v_88 = _o_4[3];
    _v_89 = _o_4[4];
    _v_90 = _o_4[5];
    _v_91 = _o_4[6];
    _v_92 = _o_4[7];
    _v_93 = _o_4[8];
    _v_94 = _o_4[9];
    _v_95 = _o_4[10];
    _v_96 = _o_4[11];
    _v_97 = _o_4[12];
    _v_98 = _o_4[13];
    _v_28 = _v_85;
    _v_29 = _v_86;
    _v_30 = _v_87;
    _v_31 = _v_88;
    _v_32 = _v_89;
    _v_33 = _v_90;
    _v_34 = _v_91;
    _v_35 = _v_92;
    _v_36 = _v_93;
    _v_37 = _v_94;
    _v_38 = _v_95;
    _v_39 = _v_96;
    _v_40 = _v_97;
    _v_41 = _v_98;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  Term _v_144 = 0;
  u32 _v_145 = 0;
  Term _v_146 = 0;
  Term _v_147 = 0;
  Term _v_148 = 0;
  u32 _v_149 = 0;
  u32 _v_150 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  Term _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  WL_SPIN
    _v_139 = _result_0;
    _v_140 = _result_1;
    _v_141 = _result_2;
    _v_142 = _result_3;
    _v_143 = _result_4;
    _v_144 = _result_5;
    _v_145 = _result_6;
    _v_146 = _result_7;
    _v_147 = _result_8;
    _v_148 = _result_9;
    _v_149 = _result_10;
    _v_150 = _result_11;
  break;
  }
  o[0] = _v_139;
  o[1] = _v_140;
  o[2] = _v_141;
  o[3] = _v_142;
  o[4] = _v_143;
  o[5] = _v_144;
  o[6] = _v_145;
  o[7] = _v_146;
  o[8] = _v_147;
  o[9] = _v_148;
  o[10] = _v_149;
  o[11] = _v_150;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_3 = 0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _h1b_0 = r0;
  u32 _h2b_0 = r1;
  Term _rr_0 = r2;
  Term _rr_1 = r3;
  u32 _rr_2 = r4;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h1b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _rr_0);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h2b_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _rr_1);
    _v_3 = term_ctr(CID_SCON, _nd_2);
    _v_4 = term_ctr(CID_SCON, _nd_3);
    _v_5 = _rr_2;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_47 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_47 = 1;
    } else {
      _v_47 = 0;
    }
  break;
  }
  o[0] = _v_47;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  Term _v_96 = 0;
  u32 _v_97 = 0;
  Term _v_98 = 0;
  u32 _v_99 = 0;
  Term _v_100 = 0;
  Term _v_101 = 0;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _v_105 = 0;
  u32 _v_106 = 0;
  u32 _v_107 = 0;
  Term _grown_0 = r0;
  u32 _grown_1 = r1;
  Term _grown_2 = r2;
  u32 _namespace_0 = r3;
  u32 _nextId_0 = r4;
  u32 _highWater_0 = r5;
  u32 _resource_0 = r6;
  Term _events_0 = r7;
  Term _pending_0 = r8;
  Term _registrations_0 = r9;
  u32 _nextSystemId_0 = r10;
  u32 _clock_0 = r11;
  WL_SPIN
    _v_93 = _namespace_0;
    _v_94 = U32_BIN(_nextId_0, +, 1ull);
    _v_95 = _nextId_0;
    _v_96 = _grown_0;
    _v_97 = _grown_1;
    _v_98 = _grown_2;
    _v_99 = _resource_0;
    _v_100 = _events_0;
    _v_101 = _pending_0;
    _v_102 = _registrations_0;
    _v_103 = _nextSystemId_0;
    _v_104 = _clock_0;
    _v_105 = 0;
    _v_106 = _namespace_0;
    _v_107 = _nextId_0;
  break;
  }
  o[0] = _v_93;
  o[1] = _v_94;
  o[2] = _v_95;
  o[3] = _v_96;
  o[4] = _v_97;
  o[5] = _v_98;
  o[6] = _v_99;
  o[7] = _v_100;
  o[8] = _v_101;
  o[9] = _v_102;
  o[10] = _v_103;
  o[11] = _v_104;
  o[12] = _v_105;
  o[13] = _v_106;
  o[14] = _v_107;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  u32 _available_0 = r0;
  u32 _grow_0 = r1;
  u32 _world_24 = r2;
  u32 _world_25 = r3;
  u32 _world_26 = r4;
  Term _world_27 = r5;
  u32 _world_28 = r6;
  Term _world_29 = r7;
  u32 _world_30 = r8;
  Term _world_31 = r9;
  Term _world_32 = r10;
  Term _world_33 = r11;
  u32 _world_34 = r12;
  u32 _world_35 = r13;
  WL_SPIN
    if (_available_0 == 0) {
      _v_63 = _world_24;
      _v_64 = _world_25;
      _v_65 = _world_26;
      _v_66 = _world_27;
      _v_67 = _world_28;
      _v_68 = _world_29;
      _v_69 = _world_30;
      _v_70 = _world_31;
      _v_71 = _world_32;
      _v_72 = _world_33;
      _v_73 = _world_34;
      _v_74 = _world_35;
      _v_75 = 1;
      _v_76 = 1;
      _v_77 = 0;
    } else {
      if (_grow_0 == 0) {
        u32 _v_78 = 0;
        u32 _v_79 = 0;
        u32 _v_80 = 0;
        Term _v_81 = 0;
        u32 _v_82 = 0;
        Term _v_83 = 0;
        u32 _v_84 = 0;
        Term _v_85 = 0;
        Term _v_86 = 0;
        Term _v_87 = 0;
        u32 _v_88 = 0;
        u32 _v_89 = 0;
        u32 _v_90 = 0;
        u32 _v_91 = 0;
        u32 _v_92 = 0;
        Term _o_1[15];
        if (spin_22(e, _o_1, _world_27, _world_27 == h5 ? q5 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_24, _world_25, _world_26, _world_30, _world_31, _world_31 == h9 ? q9 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h10 ? q10 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h11 ? q11 : blk_loc(e.mem, _world_33), _world_34, _world_35) == 0) {
          return 0;
        }
        _v_78 = _o_1[0];
        _v_79 = _o_1[1];
        _v_80 = _o_1[2];
        _v_81 = _o_1[3];
        _v_82 = _o_1[4];
        _v_83 = _o_1[5];
        _v_84 = _o_1[6];
        _v_85 = _o_1[7];
        _v_86 = _o_1[8];
        _v_87 = _o_1[9];
        _v_88 = _o_1[10];
        _v_89 = _o_1[11];
        _v_90 = _o_1[12];
        _v_91 = _o_1[13];
        _v_92 = _o_1[14];
        _v_63 = _v_78;
        _v_64 = _v_79;
        _v_65 = _v_80;
        _v_66 = _v_81;
        _v_67 = _v_82;
        _v_68 = _v_83;
        _v_69 = _v_84;
        _v_70 = _v_85;
        _v_71 = _v_86;
        _v_72 = _v_87;
        _v_73 = _v_88;
        _v_74 = _v_89;
        _v_75 = _v_90;
        _v_76 = _v_91;
        _v_77 = _v_92;
      } else {
        u32 _a_0 = U32_BIN(_world_28, *, 2ull);
        Term _a_1 = nat_chk(e, _world_29 + 1);
        Term _fv_0[1];
        _fv_0[0] = 0;
        Term _a_2 = blk_node(e, _world_27, blk_new(e, 0, _world_29, 0, 1, _fv_0));
        u32 _v_108 = 0;
        u32 _v_109 = 0;
        u32 _v_110 = 0;
        Term _v_111 = 0;
        u32 _v_112 = 0;
        Term _v_113 = 0;
        u32 _v_114 = 0;
        Term _v_115 = 0;
        Term _v_116 = 0;
        Term _v_117 = 0;
        u32 _v_118 = 0;
        u32 _v_119 = 0;
        u32 _v_120 = 0;
        u32 _v_121 = 0;
        u32 _v_122 = 0;
        Term _o_2[15];
        if (spin_22(e, _o_2, _a_2, _a_2 == h11 ? q11 : _a_2 == h10 ? q10 : _a_2 == h9 ? q9 : _a_2 == h5 ? q5 : blk_loc(e.mem, _a_2), _a_0, _a_1, _world_24, _world_25, _world_26, _world_30, _world_31, _world_31 == h9 ? q9 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h10 ? q10 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h11 ? q11 : blk_loc(e.mem, _world_33), _world_34, _world_35) == 0) {
          return 0;
        }
        _v_108 = _o_2[0];
        _v_109 = _o_2[1];
        _v_110 = _o_2[2];
        _v_111 = _o_2[3];
        _v_112 = _o_2[4];
        _v_113 = _o_2[5];
        _v_114 = _o_2[6];
        _v_115 = _o_2[7];
        _v_116 = _o_2[8];
        _v_117 = _o_2[9];
        _v_118 = _o_2[10];
        _v_119 = _o_2[11];
        _v_120 = _o_2[12];
        _v_121 = _o_2[13];
        _v_122 = _o_2[14];
        _v_63 = _v_108;
        _v_64 = _v_109;
        _v_65 = _v_110;
        _v_66 = _v_111;
        _v_67 = _v_112;
        _v_68 = _v_113;
        _v_69 = _v_114;
        _v_70 = _v_115;
        _v_71 = _v_116;
        _v_72 = _v_117;
        _v_73 = _v_118;
        _v_74 = _v_119;
        _v_75 = _v_120;
        _v_76 = _v_121;
        _v_77 = _v_122;
      }
    }
  break;
  }
  o[0] = _v_63;
  o[1] = _v_64;
  o[2] = _v_65;
  o[3] = _v_66;
  o[4] = _v_67;
  o[5] = _v_68;
  o[6] = _v_69;
  o[7] = _v_70;
  o[8] = _v_71;
  o[9] = _v_72;
  o[10] = _v_73;
  o[11] = _v_74;
  o[12] = _v_75;
  o[13] = _v_76;
  o[14] = _v_77;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  WL_SPIN
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _o_0[1];
    if (spin_20(e, _o_0, U32_BIN(_world_13, <, _world_16)) == 0) {
      return 0;
    }
    _v_46 = _o_0[0];
    _v_45 = _v_46;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    u32 _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    Term _o_3[15];
    if (spin_21(e, _o_3, U32_BIN(_world_13, <, 131073ull), _v_45, _world_12, _world_13, _world_14, _world_15, _world_15 == h3 ? q3 : blk_loc(e.mem, _world_15), _world_16, _world_17, _world_18, _world_19, _world_19 == h7 ? q7 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h8 ? q8 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h9 ? q9 : blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_48 = _o_3[0];
    _v_49 = _o_3[1];
    _v_50 = _o_3[2];
    _v_51 = _o_3[3];
    _v_52 = _o_3[4];
    _v_53 = _o_3[5];
    _v_54 = _o_3[6];
    _v_55 = _o_3[7];
    _v_56 = _o_3[8];
    _v_57 = _o_3[9];
    _v_58 = _o_3[10];
    _v_59 = _o_3[11];
    _v_60 = _o_3[12];
    _v_61 = _o_3[13];
    _v_62 = _o_3[14];
    _v_30 = _v_48;
    _v_31 = _v_49;
    _v_32 = _v_50;
    _v_33 = _v_51;
    _v_34 = _v_52;
    _v_35 = _v_53;
    _v_36 = _v_54;
    _v_37 = _v_55;
    _v_38 = _v_56;
    _v_39 = _v_57;
    _v_40 = _v_58;
    _v_41 = _v_59;
    _v_42 = _v_60;
    _v_43 = _v_61;
    _v_44 = _v_62;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_135 = 0;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  Term _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  Term _v_143 = 0;
  Term _v_144 = 0;
  u32 _v_145 = 0;
  u32 _v_146 = 0;
  u32 _reservation_0 = r0;
  u32 _reservation_1 = r1;
  u32 _reservation_2 = r2;
  Term _reservation_3 = r3;
  u32 _reservation_4 = r4;
  Term _reservation_5 = r5;
  u32 _reservation_6 = r6;
  Term _reservation_7 = r7;
  Term _reservation_8 = r8;
  Term _reservation_9 = r9;
  u32 _reservation_10 = r10;
  u32 _reservation_11 = r11;
  u32 _reservation_12 = r12;
  u32 _reservation_13 = r13;
  u32 _reservation_14 = r14;
  WL_SPIN
    if (_reservation_12 == 0) {
      u32 _v_147 = 0;
      u32 _v_148 = 0;
      u32 _v_149 = 0;
      Term _v_150 = 0;
      u32 _v_151 = 0;
      Term _v_152 = 0;
      u32 _v_153 = 0;
      Term _v_154 = 0;
      Term _v_155 = 0;
      Term _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      u32 _v_159 = 0;
      u32 _v_160 = 0;
      u32 _v_161 = 0;
      u32 _v_162 = 0;
      u32 _v_163 = 0;
      Term _v_164 = 0;
      u32 _v_165 = 0;
      Term _v_166 = 0;
      u32 _v_167 = 0;
      Term _v_168 = 0;
      Term _v_169 = 0;
      Term _v_170 = 0;
      u32 _v_171 = 0;
      u32 _v_172 = 0;
      u32 _v_173 = 0;
      u32 _v_174 = 0;
      Term _o_5[14];
      if (spin_14(e, _o_5, _reservation_0, _reservation_1, _reservation_2, _reservation_3, _reservation_3 == h3 ? q3 : blk_loc(e.mem, _reservation_3), _reservation_4, _reservation_5, _reservation_6, _reservation_7, _reservation_7 == h7 ? q7 : blk_loc(e.mem, _reservation_7), _reservation_8, _reservation_8 == h8 ? q8 : blk_loc(e.mem, _reservation_8), _reservation_9, _reservation_9 == h9 ? q9 : blk_loc(e.mem, _reservation_9), _reservation_10, _reservation_11, _reservation_13, _reservation_14) == 0) {
        return 0;
      }
      _v_161 = _o_5[0];
      _v_162 = _o_5[1];
      _v_163 = _o_5[2];
      _v_164 = _o_5[3];
      _v_165 = _o_5[4];
      _v_166 = _o_5[5];
      _v_167 = _o_5[6];
      _v_168 = _o_5[7];
      _v_169 = _o_5[8];
      _v_170 = _o_5[9];
      _v_171 = _o_5[10];
      _v_172 = _o_5[11];
      _v_173 = _o_5[12];
      _v_174 = _o_5[13];
      _v_147 = _v_161;
      _v_148 = _v_162;
      _v_149 = _v_163;
      _v_150 = _v_164;
      _v_151 = _v_165;
      _v_152 = _v_166;
      _v_153 = _v_167;
      _v_154 = _v_168;
      _v_155 = _v_169;
      _v_156 = _v_170;
      _v_157 = _v_171;
      _v_158 = _v_172;
      _v_159 = _v_173;
      _v_160 = _v_174;
      u32 _v_175 = 0;
      u32 _v_176 = 0;
      u32 _v_177 = 0;
      Term _v_178 = 0;
      u32 _v_179 = 0;
      Term _v_180 = 0;
      u32 _v_181 = 0;
      Term _v_182 = 0;
      Term _v_183 = 0;
      Term _v_184 = 0;
      u32 _v_185 = 0;
      u32 _v_186 = 0;
      Term _o_6[12];
      if (spin_17(e, _o_6, _v_147, _v_148, _v_149, _v_150, _v_150 == h9 ? q9 : _v_150 == h8 ? q8 : _v_150 == h7 ? q7 : _v_150 == h3 ? q3 : blk_loc(e.mem, _v_150), _v_151, _v_152, _v_153, _v_154, _v_154 == h9 ? q9 : _v_154 == h8 ? q8 : _v_154 == h7 ? q7 : _v_154 == h3 ? q3 : blk_loc(e.mem, _v_154), _v_155, _v_155 == h9 ? q9 : _v_155 == h8 ? q8 : _v_155 == h7 ? q7 : _v_155 == h3 ? q3 : blk_loc(e.mem, _v_155), _v_156, _v_156 == h9 ? q9 : _v_156 == h8 ? q8 : _v_156 == h7 ? q7 : _v_156 == h3 ? q3 : blk_loc(e.mem, _v_156), _v_157, _v_158, _v_159, _v_160) == 0) {
        return 0;
      }
      _v_175 = _o_6[0];
      _v_176 = _o_6[1];
      _v_177 = _o_6[2];
      _v_178 = _o_6[3];
      _v_179 = _o_6[4];
      _v_180 = _o_6[5];
      _v_181 = _o_6[6];
      _v_182 = _o_6[7];
      _v_183 = _o_6[8];
      _v_184 = _o_6[9];
      _v_185 = _o_6[10];
      _v_186 = _o_6[11];
      _v_135 = _v_175;
      _v_136 = _v_176;
      _v_137 = _v_177;
      _v_138 = _v_178;
      _v_139 = _v_179;
      _v_140 = _v_180;
      _v_141 = _v_181;
      _v_142 = _v_182;
      _v_143 = _v_183;
      _v_144 = _v_184;
      _v_145 = _v_185;
      _v_146 = _v_186;
    } else {
      _v_135 = _reservation_0;
      _v_136 = _reservation_1;
      _v_137 = _reservation_2;
      _v_138 = _reservation_3;
      _v_139 = _reservation_4;
      _v_140 = _reservation_5;
      _v_141 = _reservation_6;
      _v_142 = _reservation_7;
      _v_143 = _reservation_8;
      _v_144 = _reservation_9;
      _v_145 = _reservation_10;
      _v_146 = _reservation_11;
    }
  break;
  }
  o[0] = _v_135;
  o[1] = _v_136;
  o[2] = _v_137;
  o[3] = _v_138;
  o[4] = _v_139;
  o[5] = _v_140;
  o[6] = _v_141;
  o[7] = _v_142;
  o[8] = _v_143;
  o[9] = _v_144;
  o[10] = _v_145;
  o[11] = _v_146;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  u32 _replacement_0 = r12;
  WL_SPIN
    _v_26 = _world_12;
    _v_27 = _world_13;
    _v_28 = _world_14;
    _v_29 = _world_15;
    _v_30 = _world_16;
    _v_31 = _world_17;
    _v_32 = _replacement_0;
    _v_33 = _world_19;
    _v_34 = _world_20;
    _v_35 = _world_21;
    _v_36 = _world_22;
    _v_37 = _world_23;
    _v_38 = _world_18;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _replaced_0 = r0;
  u32 _replaced_1 = r1;
  u32 _replaced_2 = r2;
  Term _replaced_3 = r3;
  u32 _replaced_4 = r4;
  Term _replaced_5 = r5;
  u32 _replaced_6 = r6;
  Term _replaced_7 = r7;
  Term _replaced_8 = r8;
  Term _replaced_9 = r9;
  u32 _replaced_10 = r10;
  u32 _replaced_11 = r11;
  u32 _replaced_12 = r12;
  WL_SPIN
    _v_51 = _replaced_0;
    _v_52 = _replaced_1;
    _v_53 = _replaced_2;
    _v_54 = _replaced_3;
    _v_55 = _replaced_4;
    _v_56 = _replaced_5;
    _v_57 = _replaced_6;
    _v_58 = _replaced_7;
    _v_59 = _replaced_8;
    _v_60 = _replaced_9;
    _v_61 = _replaced_10;
    _v_62 = _replaced_11;
  break;
  }
  o[0] = _v_51;
  o[1] = _v_52;
  o[2] = _v_53;
  o[3] = _v_54;
  o[4] = _v_55;
  o[5] = _v_56;
  o[6] = _v_57;
  o[7] = _v_58;
  o[8] = _v_59;
  o[9] = _v_60;
  o[10] = _v_61;
  o[11] = _v_62;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = (U32_BIN(_a_1, >, _b_1) + U32_BIN(_a_1, >=, _b_1));
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  WL_SPIN
    _v_45 = _world_0;
    _v_46 = _world_1;
    _v_47 = _world_2;
    _v_48 = _world_3;
    _v_49 = _world_4;
    _v_50 = _world_5;
    _v_51 = _world_6;
    _v_52 = _world_7;
    _v_53 = _world_8;
    _v_54 = _world_9;
    _v_55 = _world_10;
    _v_56 = _world_11;
    _v_57 = term_pak(CID_NIL, 0);
    _v_58 = term_pak(CID_NIL, 0);
    _v_59 = term_pak(CID_NIL, 0);
  break;
  }
  o[0] = _v_45;
  o[1] = _v_46;
  o[2] = _v_47;
  o[3] = _v_48;
  o[4] = _v_49;
  o[5] = _v_50;
  o[6] = _v_51;
  o[7] = _v_52;
  o[8] = _v_53;
  o[9] = _v_54;
  o[10] = _v_55;
  o[11] = _v_56;
  o[12] = _v_57;
  o[13] = _v_58;
  o[14] = _v_59;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  Term _v_75 = 0;
  u32 _v_76 = 0;
  Term _v_77 = 0;
  u32 _v_78 = 0;
  Term _v_79 = 0;
  Term _v_80 = 0;
  Term _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  u32 _value_0 = r12;
  WL_SPIN
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    u32 _v_88 = 0;
    Term _v_89 = 0;
    u32 _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    Term _v_100 = 0;
    u32 _v_101 = 0;
    Term _v_102 = 0;
    u32 _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    Term _o_1[13];
    if (spin_24(e, _o_1, _world_12, _world_13, _world_14, _world_15, _world_15 == h3 ? q3 : blk_loc(e.mem, _world_15), _world_16, _world_17, _world_18, _world_19, _world_19 == h7 ? q7 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h8 ? q8 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h9 ? q9 : blk_loc(e.mem, _world_21), _world_22, _world_23, _value_0) == 0) {
      return 0;
    }
    _v_97 = _o_1[0];
    _v_98 = _o_1[1];
    _v_99 = _o_1[2];
    _v_100 = _o_1[3];
    _v_101 = _o_1[4];
    _v_102 = _o_1[5];
    _v_103 = _o_1[6];
    _v_104 = _o_1[7];
    _v_105 = _o_1[8];
    _v_106 = _o_1[9];
    _v_107 = _o_1[10];
    _v_108 = _o_1[11];
    _v_109 = _o_1[12];
    _v_84 = _v_97;
    _v_85 = _v_98;
    _v_86 = _v_99;
    _v_87 = _v_100;
    _v_88 = _v_101;
    _v_89 = _v_102;
    _v_90 = _v_103;
    _v_91 = _v_104;
    _v_92 = _v_105;
    _v_93 = _v_106;
    _v_94 = _v_107;
    _v_95 = _v_108;
    _v_96 = _v_109;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    u32 _v_114 = 0;
    Term _v_115 = 0;
    u32 _v_116 = 0;
    Term _v_117 = 0;
    Term _v_118 = 0;
    Term _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    Term _o_2[12];
    if (spin_25(e, _o_2, _v_84, _v_85, _v_86, _v_87, _v_87 == h9 ? q9 : _v_87 == h8 ? q8 : _v_87 == h7 ? q7 : _v_87 == h3 ? q3 : blk_loc(e.mem, _v_87), _v_88, _v_89, _v_90, _v_91, _v_91 == h9 ? q9 : _v_91 == h8 ? q8 : _v_91 == h7 ? q7 : _v_91 == h3 ? q3 : blk_loc(e.mem, _v_91), _v_92, _v_92 == h9 ? q9 : _v_92 == h8 ? q8 : _v_92 == h7 ? q7 : _v_92 == h3 ? q3 : blk_loc(e.mem, _v_92), _v_93, _v_93 == h9 ? q9 : _v_93 == h8 ? q8 : _v_93 == h7 ? q7 : _v_93 == h3 ? q3 : blk_loc(e.mem, _v_93), _v_94, _v_95, _v_96) == 0) {
      return 0;
    }
    _v_110 = _o_2[0];
    _v_111 = _o_2[1];
    _v_112 = _o_2[2];
    _v_113 = _o_2[3];
    _v_114 = _o_2[4];
    _v_115 = _o_2[5];
    _v_116 = _o_2[6];
    _v_117 = _o_2[7];
    _v_118 = _o_2[8];
    _v_119 = _o_2[9];
    _v_120 = _o_2[10];
    _v_121 = _o_2[11];
    _v_72 = _v_110;
    _v_73 = _v_111;
    _v_74 = _v_112;
    _v_75 = _v_113;
    _v_76 = _v_114;
    _v_77 = _v_115;
    _v_78 = _v_116;
    _v_79 = _v_117;
    _v_80 = _v_118;
    _v_81 = _v_119;
    _v_82 = _v_120;
    _v_83 = _v_121;
  break;
  }
  o[0] = _v_72;
  o[1] = _v_73;
  o[2] = _v_74;
  o[3] = _v_75;
  o[4] = _v_76;
  o[5] = _v_77;
  o[6] = _v_78;
  o[7] = _v_79;
  o[8] = _v_80;
  o[9] = _v_81;
  o[10] = _v_82;
  o[11] = _v_83;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_137 = 0;
  u32 _v_138 = 0;
  u32 _v_139 = 0;
  Term _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  Term _v_144 = 0;
  Term _v_145 = 0;
  Term _v_146 = 0;
  u32 _v_147 = 0;
  u32 _v_148 = 0;
  Term _v_149 = 0;
  Term _v_150 = 0;
  Term _v_151 = 0;
  u32 _tx_0 = r0;
  u32 _tx_1 = r1;
  u32 _tx_2 = r2;
  Term _tx_3 = r3;
  u32 _tx_4 = r4;
  Term _tx_5 = r5;
  u32 _tx_6 = r6;
  Term _tx_7 = r7;
  Term _tx_8 = r8;
  Term _tx_9 = r9;
  u32 _tx_10 = r10;
  u32 _tx_11 = r11;
  Term _tx_12 = r12;
  Term _tx_13 = r13;
  Term _tx_14 = r14;
  Term _inverse_0 = r15;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _inverse_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _tx_12);
    _v_137 = _tx_0;
    _v_138 = _tx_1;
    _v_139 = _tx_2;
    _v_140 = _tx_3;
    _v_141 = _tx_4;
    _v_142 = _tx_5;
    _v_143 = _tx_6;
    _v_144 = _tx_7;
    _v_145 = _tx_8;
    _v_146 = _tx_9;
    _v_147 = _tx_10;
    _v_148 = _tx_11;
    _v_149 = term_ctr(CID_CON, _nd_2);
    _v_150 = _tx_13;
    _v_151 = _tx_14;
  break;
  }
  o[0] = _v_137;
  o[1] = _v_138;
  o[2] = _v_139;
  o[3] = _v_140;
  o[4] = _v_141;
  o[5] = _v_142;
  o[6] = _v_143;
  o[7] = _v_144;
  o[8] = _v_145;
  o[9] = _v_146;
  o[10] = _v_147;
  o[11] = _v_148;
  o[12] = _v_149;
  o[13] = _v_150;
  o[14] = _v_151;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_197 = 0;
  u32 _v_198 = 0;
  u32 _v_199 = 0;
  Term _v_200 = 0;
  u32 _v_201 = 0;
  Term _v_202 = 0;
  u32 _v_203 = 0;
  Term _v_204 = 0;
  Term _v_205 = 0;
  Term _v_206 = 0;
  u32 _v_207 = 0;
  u32 _v_208 = 0;
  Term _v_209 = 0;
  Term _v_210 = 0;
  Term _v_211 = 0;
  u32 _tx_15 = r0;
  u32 _tx_16 = r1;
  u32 _tx_17 = r2;
  Term _tx_18 = r3;
  u32 _tx_19 = r4;
  Term _tx_20 = r5;
  u32 _tx_21 = r6;
  Term _tx_22 = r7;
  Term _tx_23 = r8;
  Term _tx_24 = r9;
  u32 _tx_25 = r10;
  u32 _tx_26 = r11;
  Term _tx_27 = r12;
  Term _tx_28 = r13;
  Term _tx_29 = r14;
  u32 _event_0 = r15;
  WL_SPIN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _event_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _tx_29);
    _v_197 = _tx_15;
    _v_198 = _tx_16;
    _v_199 = _tx_17;
    _v_200 = _tx_18;
    _v_201 = _tx_19;
    _v_202 = _tx_20;
    _v_203 = _tx_21;
    _v_204 = _tx_22;
    _v_205 = _tx_23;
    _v_206 = _tx_24;
    _v_207 = _tx_25;
    _v_208 = _tx_26;
    _v_209 = _tx_27;
    _v_210 = _tx_28;
    _v_211 = term_ctr(CID_CON, _nd_3);
  break;
  }
  o[0] = _v_197;
  o[1] = _v_198;
  o[2] = _v_199;
  o[3] = _v_200;
  o[4] = _v_201;
  o[5] = _v_202;
  o[6] = _v_203;
  o[7] = _v_204;
  o[8] = _v_205;
  o[9] = _v_206;
  o[10] = _v_207;
  o[11] = _v_208;
  o[12] = _v_209;
  o[13] = _v_210;
  o[14] = _v_211;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_224 = 0;
  u32 _v_225 = 0;
  u32 _v_226 = 0;
  Term _v_227 = 0;
  u32 _v_228 = 0;
  Term _v_229 = 0;
  u32 _v_230 = 0;
  Term _v_231 = 0;
  Term _v_232 = 0;
  Term _v_233 = 0;
  u32 _v_234 = 0;
  u32 _v_235 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  u32 _world_30 = r6;
  Term _world_31 = r7;
  Term _world_32 = r8;
  Term _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  WL_SPIN
    u32 _v_236 = 0;
    u32 _v_237 = 0;
    u32 _v_238 = 0;
    Term _v_239 = 0;
    u32 _v_240 = 0;
    Term _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    Term _v_244 = 0;
    Term _v_245 = 0;
    u32 _v_246 = 0;
    u32 _v_247 = 0;
    u32 _v_248 = 0;
    u32 _v_249 = 0;
    u32 _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    Term _v_254 = 0;
    u32 _v_255 = 0;
    Term _v_256 = 0;
    u32 _v_257 = 0;
    Term _v_258 = 0;
    Term _v_259 = 0;
    Term _v_260 = 0;
    u32 _v_261 = 0;
    u32 _v_262 = 0;
    u32 _v_263 = 0;
    u32 _v_264 = 0;
    u32 _v_265 = 0;
    Term _o_6[15];
    if (spin_19(e, _o_6, _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h8 ? q8 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h9 ? q9 : blk_loc(e.mem, _world_33), _world_34, _world_35) == 0) {
      return 0;
    }
    _v_251 = _o_6[0];
    _v_252 = _o_6[1];
    _v_253 = _o_6[2];
    _v_254 = _o_6[3];
    _v_255 = _o_6[4];
    _v_256 = _o_6[5];
    _v_257 = _o_6[6];
    _v_258 = _o_6[7];
    _v_259 = _o_6[8];
    _v_260 = _o_6[9];
    _v_261 = _o_6[10];
    _v_262 = _o_6[11];
    _v_263 = _o_6[12];
    _v_264 = _o_6[13];
    _v_265 = _o_6[14];
    _v_236 = _v_251;
    _v_237 = _v_252;
    _v_238 = _v_253;
    _v_239 = _v_254;
    _v_240 = _v_255;
    _v_241 = _v_256;
    _v_242 = _v_257;
    _v_243 = _v_258;
    _v_244 = _v_259;
    _v_245 = _v_260;
    _v_246 = _v_261;
    _v_247 = _v_262;
    _v_248 = _v_263;
    _v_249 = _v_264;
    _v_250 = _v_265;
    u32 _v_266 = 0;
    u32 _v_267 = 0;
    u32 _v_268 = 0;
    Term _v_269 = 0;
    u32 _v_270 = 0;
    Term _v_271 = 0;
    u32 _v_272 = 0;
    Term _v_273 = 0;
    Term _v_274 = 0;
    Term _v_275 = 0;
    u32 _v_276 = 0;
    u32 _v_277 = 0;
    Term _o_7[12];
    if (spin_23(e, _o_7, _v_236, _v_237, _v_238, _v_239, _v_239 == h9 ? q9 : _v_239 == h8 ? q8 : _v_239 == h7 ? q7 : _v_239 == h3 ? q3 : blk_loc(e.mem, _v_239), _v_240, _v_241, _v_242, _v_243, _v_243 == h9 ? q9 : _v_243 == h8 ? q8 : _v_243 == h7 ? q7 : _v_243 == h3 ? q3 : blk_loc(e.mem, _v_243), _v_244, _v_244 == h9 ? q9 : _v_244 == h8 ? q8 : _v_244 == h7 ? q7 : _v_244 == h3 ? q3 : blk_loc(e.mem, _v_244), _v_245, _v_245 == h9 ? q9 : _v_245 == h8 ? q8 : _v_245 == h7 ? q7 : _v_245 == h3 ? q3 : blk_loc(e.mem, _v_245), _v_246, _v_247, _v_248, _v_249, _v_250) == 0) {
      return 0;
    }
    _v_266 = _o_7[0];
    _v_267 = _o_7[1];
    _v_268 = _o_7[2];
    _v_269 = _o_7[3];
    _v_270 = _o_7[4];
    _v_271 = _o_7[5];
    _v_272 = _o_7[6];
    _v_273 = _o_7[7];
    _v_274 = _o_7[8];
    _v_275 = _o_7[9];
    _v_276 = _o_7[10];
    _v_277 = _o_7[11];
    _v_224 = _v_266;
    _v_225 = _v_267;
    _v_226 = _v_268;
    _v_227 = _v_269;
    _v_228 = _v_270;
    _v_229 = _v_271;
    _v_230 = _v_272;
    _v_231 = _v_273;
    _v_232 = _v_274;
    _v_233 = _v_275;
    _v_234 = _v_276;
    _v_235 = _v_277;
  break;
  }
  o[0] = _v_224;
  o[1] = _v_225;
  o[2] = _v_226;
  o[3] = _v_227;
  o[4] = _v_228;
  o[5] = _v_229;
  o[6] = _v_230;
  o[7] = _v_231;
  o[8] = _v_232;
  o[9] = _v_233;
  o[10] = _v_234;
  o[11] = _v_235;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_293 = 0;
  u32 _v_294 = 0;
  u32 _v_295 = 0;
  Term _v_296 = 0;
  u32 _v_297 = 0;
  Term _v_298 = 0;
  u32 _v_299 = 0;
  Term _v_300 = 0;
  Term _v_301 = 0;
  Term _v_302 = 0;
  u32 _v_303 = 0;
  u32 _v_304 = 0;
  Term _v_305 = 0;
  Term _v_306 = 0;
  Term _v_307 = 0;
  u32 _tx_30 = r0;
  u32 _tx_31 = r1;
  u32 _tx_32 = r2;
  Term _tx_33 = r3;
  u32 _tx_34 = r4;
  Term _tx_35 = r5;
  u32 _tx_36 = r6;
  Term _tx_37 = r7;
  Term _tx_38 = r8;
  Term _tx_39 = r9;
  u32 _tx_40 = r10;
  u32 _tx_41 = r11;
  Term _tx_42 = r12;
  Term _tx_43 = r13;
  Term _tx_44 = r14;
  Term _command_0 = r15;
  WL_SPIN
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, _command_0);
    e.mem[_nd_5 + 1] = rfc_seal(e, _tx_43);
    _v_293 = _tx_30;
    _v_294 = _tx_31;
    _v_295 = _tx_32;
    _v_296 = _tx_33;
    _v_297 = _tx_34;
    _v_298 = _tx_35;
    _v_299 = _tx_36;
    _v_300 = _tx_37;
    _v_301 = _tx_38;
    _v_302 = _tx_39;
    _v_303 = _tx_40;
    _v_304 = _tx_41;
    _v_305 = _tx_42;
    _v_306 = term_ctr(CID_CON, _nd_5);
    _v_307 = _tx_44;
  break;
  }
  o[0] = _v_293;
  o[1] = _v_294;
  o[2] = _v_295;
  o[3] = _v_296;
  o[4] = _v_297;
  o[5] = _v_298;
  o[6] = _v_299;
  o[7] = _v_300;
  o[8] = _v_301;
  o[9] = _v_302;
  o[10] = _v_303;
  o[11] = _v_304;
  o[12] = _v_305;
  o[13] = _v_306;
  o[14] = _v_307;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h13 = r13;
  u32 _v_322 = 0;
  u32 _v_323 = 0;
  u32 _v_324 = 0;
  u32 _v_325 = 0;
  Term _v_326 = 0;
  u32 _v_327 = 0;
  Term _v_328 = 0;
  u32 _v_329 = 0;
  Term _v_330 = 0;
  Term _v_331 = 0;
  Term _v_332 = 0;
  u32 _v_333 = 0;
  u32 _v_334 = 0;
  Term _v_335 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  Term _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  Term _result_13 = r13;
  WL_SPIN
    if (_result_12 == 1) {
      _v_322 = 1;
      _v_323 = _result_0;
      _v_324 = _result_1;
      _v_325 = _result_2;
      _v_326 = _result_3;
      _v_327 = _result_4;
      _v_328 = _result_5;
      _v_329 = _result_6;
      _v_330 = _result_7;
      _v_331 = _result_8;
      _v_332 = _result_9;
      _v_333 = _result_10;
      _v_334 = _result_11;
      _v_335 = _result_13;
    } else {
      _v_322 = 0;
      _v_323 = _result_0;
      _v_324 = _result_1;
      _v_325 = _result_2;
      _v_326 = _result_3;
      _v_327 = _result_4;
      _v_328 = _result_5;
      _v_329 = _result_6;
      _v_330 = _result_7;
      _v_331 = _result_8;
      _v_332 = _result_9;
      _v_333 = _result_10;
      _v_334 = _result_11;
      _v_335 = 0;
    }
  break;
  }
  o[0] = _v_322;
  o[1] = _v_323;
  o[2] = _v_324;
  o[3] = _v_325;
  o[4] = _v_326;
  o[5] = _v_327;
  o[6] = _v_328;
  o[7] = _v_329;
  o[8] = _v_330;
  o[9] = _v_331;
  o[10] = _v_332;
  o[11] = _v_333;
  o[12] = _v_334;
  o[13] = _v_335;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _handle_0 = r12;
  u32 _handle_1 = r13;
  WL_SPIN
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _o_0[14];
    if (spin_14(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_11, _handle_0, _handle_1) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_24 = _v_38;
    _v_25 = _v_39;
    _v_26 = _v_40;
    _v_27 = _v_41;
    _v_28 = _v_42;
    _v_29 = _v_43;
    _v_30 = _v_44;
    _v_31 = _v_45;
    _v_32 = _v_46;
    _v_33 = _v_47;
    _v_34 = _v_48;
    _v_35 = _v_49;
    _v_36 = _v_50;
    _v_37 = _v_51;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _o_1[12];
    if (spin_17(e, _o_1, _v_24, _v_25, _v_26, _v_27, _v_27 == h9 ? q9 : _v_27 == h8 ? q8 : _v_27 == h7 ? q7 : _v_27 == h3 ? q3 : blk_loc(e.mem, _v_27), _v_28, _v_29, _v_30, _v_31, _v_31 == h9 ? q9 : _v_31 == h8 ? q8 : _v_31 == h7 ? q7 : _v_31 == h3 ? q3 : blk_loc(e.mem, _v_31), _v_32, _v_32 == h9 ? q9 : _v_32 == h8 ? q8 : _v_32 == h7 ? q7 : _v_32 == h3 ? q3 : blk_loc(e.mem, _v_32), _v_33, _v_33 == h9 ? q9 : _v_33 == h8 ? q8 : _v_33 == h7 ? q7 : _v_33 == h3 ? q3 : blk_loc(e.mem, _v_33), _v_34, _v_35, _v_36, _v_37) == 0) {
      return 0;
    }
    _v_52 = _o_1[0];
    _v_53 = _o_1[1];
    _v_54 = _o_1[2];
    _v_55 = _o_1[3];
    _v_56 = _o_1[4];
    _v_57 = _o_1[5];
    _v_58 = _o_1[6];
    _v_59 = _o_1[7];
    _v_60 = _o_1[8];
    _v_61 = _o_1[9];
    _v_62 = _o_1[10];
    _v_63 = _o_1[11];
    _v_12 = _v_52;
    _v_13 = _v_53;
    _v_14 = _v_54;
    _v_15 = _v_55;
    _v_16 = _v_56;
    _v_17 = _v_57;
    _v_18 = _v_58;
    _v_19 = _v_59;
    _v_20 = _v_60;
    _v_21 = _v_61;
    _v_22 = _v_62;
    _v_23 = _v_63;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  o[6] = _v_18;
  o[7] = _v_19;
  o[8] = _v_20;
  o[9] = _v_21;
  o[10] = _v_22;
  o[11] = _v_23;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_0);
    _v_1 = _p_1;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _reservation_0 = r0;
  u32 _reservation_1 = r1;
  u32 _reservation_2 = r2;
  Term _reservation_3 = r3;
  u32 _reservation_4 = r4;
  Term _reservation_5 = r5;
  u32 _reservation_6 = r6;
  Term _reservation_7 = r7;
  Term _reservation_8 = r8;
  Term _reservation_9 = r9;
  u32 _reservation_10 = r10;
  u32 _reservation_11 = r11;
  u32 _reservation_12 = r12;
  u32 _reservation_13 = r13;
  u32 _reservation_14 = r14;
  WL_SPIN
    if (_reservation_12 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _reservation_13;
      e.mem[_nd_0 + 1] = _reservation_14;
      u32 _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      Term _v_69 = 0;
      u32 _v_70 = 0;
      Term _v_71 = 0;
      u32 _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      Term _o_2[12];
      Term _a_0 = term_clo(FID_QUEUED_RESERVED_C58, _nd_0);
      if (spin_0(e, _o_2, _reservation_0, _reservation_1, _reservation_2, _reservation_3, _reservation_3 == h3 ? q3 : blk_loc(e.mem, _reservation_3), _reservation_4, _reservation_5, _reservation_6, _reservation_7, _reservation_7 == h7 ? q7 : blk_loc(e.mem, _reservation_7), _reservation_8, _reservation_8 == h8 ? q8 : blk_loc(e.mem, _reservation_8), _reservation_9, _reservation_9 == h9 ? q9 : blk_loc(e.mem, _reservation_9), _reservation_10, _reservation_11, _a_0, _a_0 == h9 ? q9 : _a_0 == h8 ? q8 : _a_0 == h7 ? q7 : _a_0 == h3 ? q3 : blk_loc(e.mem, _a_0)) == 0) {
        return 0;
      }
      _v_66 = _o_2[0];
      _v_67 = _o_2[1];
      _v_68 = _o_2[2];
      _v_69 = _o_2[3];
      _v_70 = _o_2[4];
      _v_71 = _o_2[5];
      _v_72 = _o_2[6];
      _v_73 = _o_2[7];
      _v_74 = _o_2[8];
      _v_75 = _o_2[9];
      _v_76 = _o_2[10];
      _v_77 = _o_2[11];
      _v_42 = _v_66;
      _v_43 = _v_67;
      _v_44 = _v_68;
      _v_45 = _v_69;
      _v_46 = _v_70;
      _v_47 = _v_71;
      _v_48 = _v_72;
      _v_49 = _v_73;
      _v_50 = _v_74;
      _v_51 = _v_75;
      _v_52 = _v_76;
      _v_53 = _v_77;
    } else {
      _v_42 = _reservation_0;
      _v_43 = _reservation_1;
      _v_44 = _reservation_2;
      _v_45 = _reservation_3;
      _v_46 = _reservation_4;
      _v_47 = _reservation_5;
      _v_48 = _reservation_6;
      _v_49 = _reservation_7;
      _v_50 = _reservation_8;
      _v_51 = _reservation_9;
      _v_52 = _reservation_10;
      _v_53 = _reservation_11;
    }
  break;
  }
  o[0] = _v_42;
  o[1] = _v_43;
  o[2] = _v_44;
  o[3] = _v_45;
  o[4] = _v_46;
  o[5] = _v_47;
  o[6] = _v_48;
  o[7] = _v_49;
  o[8] = _v_50;
  o[9] = _v_51;
  o[10] = _v_52;
  o[11] = _v_53;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _value_0 = r12;
  WL_SPIN
    _v_24 = _world_0;
    _v_25 = _world_1;
    _v_26 = _world_2;
    _v_27 = _world_3;
    _v_28 = _world_4;
    _v_29 = _world_5;
    _v_30 = U32_BIN(U32_BIN(_world_6, *, 10ull), +, _value_0);
    _v_31 = _world_7;
    _v_32 = _world_8;
    _v_33 = _world_9;
    _v_34 = _world_10;
    _v_35 = _world_11;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_1 = 0;
  u32 _c_0 = r0;
  WL_SPIN
    if (_c_0 == 1) {
      _v_1 = 1;
    } else {
      _v_1 = 0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_51 = 0;
  u32 _present_0 = r0;
  u32 _namespace_2 = r1;
  u32 _id_0 = r2;
  Term _handles_0 = r3;
  WL_SPIN
    if (_present_0 == 0) {
      _v_51 = _handles_0;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _id_0);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_______SRC_ECS_WORLD_HANDLE, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _handles_0);
      _v_51 = term_ctr(CID_CON, _nd_1);
    }
  break;
  }
  o[0] = _v_51;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, Term r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _fuel_0 = r0;
  Term _remaining_1 = r1;
  u32 _namespace_1 = r2;
  u32 _phase_0 = r3;
  Term _phase_1 = r4;
  Term _phase_2 = r5;
  Term _phase_3 = r6;
  WL_SPIN
    if (_fuel_0 == 0) {
      if (_phase_0 == 0) {
        _v_47 = _phase_1;
        _v_48 = _phase_2;
      } else {
        _v_47 = _phase_1;
        _v_48 = _phase_3;
      }
    } else {
      Term _more_0 = (_fuel_0 - 1);
      if (_remaining_1 == 0) {
        if (_phase_0 == 0) {
          _v_47 = _phase_1;
          _v_48 = _phase_2;
        } else {
          _v_47 = _phase_1;
          _v_48 = _phase_3;
        }
      } else {
        Term _rest_0 = (_remaining_1 - 1);
        if (_phase_0 == 0) {
          Term _at_0 = _phase_1 == h4 ? q4 : blk_loc(e.mem, _phase_1);
          Term _at_1 = blk_at(_phase_1, ((u64)(u32)(nat_chk(e, _rest_0 + 1))), 0);
          u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
          r0 = _more_0;
          r1 = nat_chk(e, _rest_0 + 1);
          r2 = _namespace_1;
          r3 = 1;
          r4 = _phase_1;
          r5 = _c_0;
          r6 = _phase_2;
          _fuel_0 = r0;
          _remaining_1 = r1;
          _namespace_1 = r2;
          _phase_0 = r3;
          _phase_1 = r4;
          _phase_2 = r5;
          _phase_3 = r6;
          WL_AGAIN(spin_41);
        } else {
          Term _v_49 = 0;
          Term _v_50 = 0;
          Term _o_0[1];
          if (spin_42(e, _o_0, _phase_2, _namespace_1, ((u64)(u32)(nat_chk(e, _rest_0 + 1))), _phase_3, _phase_3 == h6 ? q6 : blk_loc(e.mem, _phase_3)) == 0) {
            return 0;
          }
          _v_50 = _o_0[0];
          _v_49 = _v_50;
          r0 = _more_0;
          r1 = _rest_0;
          r2 = _namespace_1;
          r3 = 0;
          r4 = _phase_1;
          r5 = _v_49;
          r6 = 0;
          _fuel_0 = r0;
          _remaining_1 = r1;
          _namespace_1 = r2;
          _phase_0 = r3;
          _phase_1 = r4;
          _phase_2 = r5;
          _phase_3 = r6;
          WL_AGAIN(spin_41);
        }
      }
    }
  break;
  }
  o[0] = _v_47;
  o[1] = _v_48;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, Term r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _remaining_0 = r0;
  u32 _namespace_0 = r1;
  Term _live_0 = r2;
  WL_SPIN
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _o_1[2];
    Term _a_0 = term_pak(CID_NIL, 0);
    Term _a_1 = 0;
    if (spin_41(e, _o_1, nat_mul(e, 2ull, _remaining_0), _remaining_0, _namespace_0, 0, _live_0, _live_0 == h2 ? q2 : blk_loc(e.mem, _live_0), _a_0, _a_0 == h2 ? q2 : blk_loc(e.mem, _a_0), _a_1, _a_1 == h2 ? q2 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_45 = _o_1[0];
    _v_46 = _o_1[1];
    _v_43 = _v_45;
    _v_44 = _v_46;
  break;
  }
  o[0] = _v_43;
  o[1] = _v_44;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  Term _v_68 = 0;
  u32 _v_69 = 0;
  Term _v_70 = 0;
  u32 _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  Term _v_77 = 0;
  Term _scanned_0 = r0;
  Term _scanned_1 = r1;
  u32 _namespace_3 = r2;
  u32 _nextId_0 = r3;
  u32 _highWater_0 = r4;
  u32 _capacity_0 = r5;
  Term _depth_0 = r6;
  u32 _resource_0 = r7;
  Term _events_0 = r8;
  Term _pending_0 = r9;
  Term _registrations_0 = r10;
  u32 _nextSystemId_0 = r11;
  u32 _clock_0 = r12;
  WL_SPIN
    _v_65 = _namespace_3;
    _v_66 = _nextId_0;
    _v_67 = _highWater_0;
    _v_68 = _scanned_0;
    _v_69 = _capacity_0;
    _v_70 = _depth_0;
    _v_71 = _resource_0;
    _v_72 = _events_0;
    _v_73 = _pending_0;
    _v_74 = _registrations_0;
    _v_75 = _nextSystemId_0;
    _v_76 = _clock_0;
    _v_77 = _scanned_1;
  break;
  }
  o[0] = _v_65;
  o[1] = _v_66;
  o[2] = _v_67;
  o[3] = _v_68;
  o[4] = _v_69;
  o[5] = _v_70;
  o[6] = _v_71;
  o[7] = _v_72;
  o[8] = _v_73;
  o[9] = _v_74;
  o[10] = _v_75;
  o[11] = _v_76;
  o[12] = _v_77;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  WL_SPIN
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _o_2[2];
    if (spin_40(e, _o_2, ((u64)_world_14), _world_12, _world_15, _world_15 == h3 ? q3 : blk_loc(e.mem, _world_15)) == 0) {
      return 0;
    }
    _v_41 = _o_2[0];
    _v_42 = _o_2[1];
    _v_39 = _v_41;
    _v_40 = _v_42;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    Term _o_3[13];
    if (spin_43(e, _o_3, _v_39, _v_39 == h9 ? q9 : _v_39 == h8 ? q8 : _v_39 == h7 ? q7 : _v_39 == h3 ? q3 : blk_loc(e.mem, _v_39), _v_40, _v_40 == h9 ? q9 : _v_40 == h8 ? q8 : _v_40 == h7 ? q7 : _v_40 == h3 ? q3 : blk_loc(e.mem, _v_40), _world_12, _world_13, _world_14, _world_16, _world_17, _world_18, _world_19, _world_19 == h7 ? q7 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h8 ? q8 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h9 ? q9 : blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_52 = _o_3[0];
    _v_53 = _o_3[1];
    _v_54 = _o_3[2];
    _v_55 = _o_3[3];
    _v_56 = _o_3[4];
    _v_57 = _o_3[5];
    _v_58 = _o_3[6];
    _v_59 = _o_3[7];
    _v_60 = _o_3[8];
    _v_61 = _o_3[9];
    _v_62 = _o_3[10];
    _v_63 = _o_3[11];
    _v_64 = _o_3[12];
    _v_26 = _v_52;
    _v_27 = _v_53;
    _v_28 = _v_54;
    _v_29 = _v_55;
    _v_30 = _v_56;
    _v_31 = _v_57;
    _v_32 = _v_58;
    _v_33 = _v_59;
    _v_34 = _v_60;
    _v_35 = _v_61;
    _v_36 = _v_62;
    _v_37 = _v_63;
    _v_38 = _v_64;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_258 = 0;
  u32 _v_259 = 0;
  u32 _v_260 = 0;
  Term _v_261 = 0;
  u32 _v_262 = 0;
  Term _v_263 = 0;
  u32 _v_264 = 0;
  Term _v_265 = 0;
  Term _v_266 = 0;
  Term _v_267 = 0;
  u32 _v_268 = 0;
  u32 _v_269 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  u32 _world_30 = r6;
  Term _world_31 = r7;
  Term _world_32 = r8;
  Term _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  WL_SPIN
    u32 _v_270 = 0;
    u32 _v_271 = 0;
    u32 _v_272 = 0;
    Term _v_273 = 0;
    u32 _v_274 = 0;
    Term _v_275 = 0;
    u32 _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    u32 _v_280 = 0;
    u32 _v_281 = 0;
    u32 _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    u32 _v_286 = 0;
    u32 _v_287 = 0;
    Term _v_288 = 0;
    u32 _v_289 = 0;
    Term _v_290 = 0;
    u32 _v_291 = 0;
    Term _v_292 = 0;
    Term _v_293 = 0;
    Term _v_294 = 0;
    u32 _v_295 = 0;
    u32 _v_296 = 0;
    u32 _v_297 = 0;
    u32 _v_298 = 0;
    u32 _v_299 = 0;
    Term _o_11[15];
    if (spin_19(e, _o_11, _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_32 == h8 ? q8 : blk_loc(e.mem, _world_32), _world_33, _world_33 == h9 ? q9 : blk_loc(e.mem, _world_33), _world_34, _world_35) == 0) {
      return 0;
    }
    _v_285 = _o_11[0];
    _v_286 = _o_11[1];
    _v_287 = _o_11[2];
    _v_288 = _o_11[3];
    _v_289 = _o_11[4];
    _v_290 = _o_11[5];
    _v_291 = _o_11[6];
    _v_292 = _o_11[7];
    _v_293 = _o_11[8];
    _v_294 = _o_11[9];
    _v_295 = _o_11[10];
    _v_296 = _o_11[11];
    _v_297 = _o_11[12];
    _v_298 = _o_11[13];
    _v_299 = _o_11[14];
    _v_270 = _v_285;
    _v_271 = _v_286;
    _v_272 = _v_287;
    _v_273 = _v_288;
    _v_274 = _v_289;
    _v_275 = _v_290;
    _v_276 = _v_291;
    _v_277 = _v_292;
    _v_278 = _v_293;
    _v_279 = _v_294;
    _v_280 = _v_295;
    _v_281 = _v_296;
    _v_282 = _v_297;
    _v_283 = _v_298;
    _v_284 = _v_299;
    u32 _v_300 = 0;
    u32 _v_301 = 0;
    u32 _v_302 = 0;
    Term _v_303 = 0;
    u32 _v_304 = 0;
    Term _v_305 = 0;
    u32 _v_306 = 0;
    Term _v_307 = 0;
    Term _v_308 = 0;
    Term _v_309 = 0;
    u32 _v_310 = 0;
    u32 _v_311 = 0;
    Term _o_12[12];
    if (spin_36(e, _o_12, _v_270, _v_271, _v_272, _v_273, _v_273 == h9 ? q9 : _v_273 == h8 ? q8 : _v_273 == h7 ? q7 : _v_273 == h3 ? q3 : blk_loc(e.mem, _v_273), _v_274, _v_275, _v_276, _v_277, _v_277 == h9 ? q9 : _v_277 == h8 ? q8 : _v_277 == h7 ? q7 : _v_277 == h3 ? q3 : blk_loc(e.mem, _v_277), _v_278, _v_278 == h9 ? q9 : _v_278 == h8 ? q8 : _v_278 == h7 ? q7 : _v_278 == h3 ? q3 : blk_loc(e.mem, _v_278), _v_279, _v_279 == h9 ? q9 : _v_279 == h8 ? q8 : _v_279 == h7 ? q7 : _v_279 == h3 ? q3 : blk_loc(e.mem, _v_279), _v_280, _v_281, _v_282, _v_283, _v_284) == 0) {
      return 0;
    }
    _v_300 = _o_12[0];
    _v_301 = _o_12[1];
    _v_302 = _o_12[2];
    _v_303 = _o_12[3];
    _v_304 = _o_12[4];
    _v_305 = _o_12[5];
    _v_306 = _o_12[6];
    _v_307 = _o_12[7];
    _v_308 = _o_12[8];
    _v_309 = _o_12[9];
    _v_310 = _o_12[10];
    _v_311 = _o_12[11];
    _v_258 = _v_300;
    _v_259 = _v_301;
    _v_260 = _v_302;
    _v_261 = _v_303;
    _v_262 = _v_304;
    _v_263 = _v_305;
    _v_264 = _v_306;
    _v_265 = _v_307;
    _v_266 = _v_308;
    _v_267 = _v_309;
    _v_268 = _v_310;
    _v_269 = _v_311;
  break;
  }
  o[0] = _v_258;
  o[1] = _v_259;
  o[2] = _v_260;
  o[3] = _v_261;
  o[4] = _v_262;
  o[5] = _v_263;
  o[6] = _v_264;
  o[7] = _v_265;
  o[8] = _v_266;
  o[9] = _v_267;
  o[10] = _v_268;
  o[11] = _v_269;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, u32 r16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h9 = r9;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h18 = r18;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _registry_10 = r0;
  u32 _registry_11 = r1;
  Term _registry_12 = r2;
  Term _registry_13 = r3;
  u32 _registry_14 = r4;
  u32 _outcome_0 = r5;
  u32 _outcome_1 = r6;
  u32 _outcome_2 = r7;
  u32 _outcome_3 = r8;
  Term _outcome_4 = r9;
  u32 _outcome_5 = r10;
  Term _outcome_6 = r11;
  u32 _outcome_7 = r12;
  Term _outcome_8 = r13;
  Term _outcome_9 = r14;
  Term _outcome_10 = r15;
  u32 _outcome_11 = r16;
  u32 _outcome_12 = r17;
  Term _outcome_13 = r18;
  WL_SPIN
    _v_20 = 0;
    _v_21 = _registry_10;
    _v_22 = _registry_11;
    _v_23 = _registry_12;
    _v_24 = _registry_13;
    _v_25 = _registry_14;
    _v_26 = _outcome_0;
    _v_27 = _outcome_1;
    _v_28 = _outcome_2;
    _v_29 = _outcome_3;
    _v_30 = _outcome_4;
    _v_31 = _outcome_5;
    _v_32 = _outcome_6;
    _v_33 = _outcome_7;
    _v_34 = _outcome_8;
    _v_35 = _outcome_9;
    _v_36 = _outcome_10;
    _v_37 = _outcome_11;
    _v_38 = _outcome_12;
    _v_39 = _outcome_13;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  o[10] = _v_30;
  o[11] = _v_31;
  o[12] = _v_32;
  o[13] = _v_33;
  o[14] = _v_34;
  o[15] = _v_35;
  o[16] = _v_36;
  o[17] = _v_37;
  o[18] = _v_38;
  o[19] = _v_39;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _v_3 = 0;
  u32 _value_1 = r0;
  WL_SPIN
    _v_2 = _value_1;
    _v_3 = _value_1;
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  u32 _value_0 = r0;
  WL_SPIN
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _o_0[2];
    if (spin_46(e, _o_0, _value_0) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_4 = _v_6;
    _v_5 = _v_7;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _observed_0 = r0;
  u32 _observed_1 = r1;
  u32 _namespace_0 = r2;
  u32 _nextId_0 = r3;
  u32 _highWater_0 = r4;
  Term _live_0 = r5;
  u32 _capacity_0 = r6;
  Term _depth_0 = r7;
  Term _events_0 = r8;
  Term _pending_0 = r9;
  Term _registrations_0 = r10;
  u32 _nextSystemId_0 = r11;
  u32 _clock_0 = r12;
  WL_SPIN
    _v_21 = _namespace_0;
    _v_22 = _nextId_0;
    _v_23 = _highWater_0;
    _v_24 = _live_0;
    _v_25 = _capacity_0;
    _v_26 = _depth_0;
    _v_27 = _observed_0;
    _v_28 = _events_0;
    _v_29 = _pending_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _observed_1;
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  WL_SPIN
    _v_26 = _world_12;
    _v_27 = _world_13;
    _v_28 = _world_14;
    _v_29 = _world_15;
    _v_30 = _world_16;
    _v_31 = _world_17;
    _v_32 = _world_18;
    _v_33 = _world_19;
    _v_34 = _world_20;
    _v_35 = _world_21;
    _v_36 = _world_22;
    _v_37 = _world_23;
    _v_38 = _world_12;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, Term r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, u32 r20, u32 r21, Term r22, u64 q22, Term r23, u64 q23, u32 r24) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h9 = r9;
  Term h10 = r10;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h19 = r19;
  Term h22 = r22;
  Term h23 = r23;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  Term _result_12 = r12;
  Term _result_13 = r13;
  Term _result_14 = r14;
  Term _result_15 = r15;
  Term _result_16 = r16;
  u32 _result_17 = r17;
  u32 _result_18 = r18;
  Term _result_19 = r19;
  u32 _b_0 = r20;
  u32 _b_1 = r21;
  Term _b_2 = r22;
  Term _b_3 = r23;
  u32 _b_4 = r24;
  WL_SPIN
    if (_result_0 == 0) {
      _v_24 = _result_1;
      _v_25 = _result_2;
      _v_26 = _result_3;
      _v_27 = _result_4;
      _v_28 = _result_5;
      _v_29 = _b_0;
      _v_30 = _b_1;
      _v_31 = _b_2;
      _v_32 = _b_3;
      _v_33 = _b_4;
      _v_34 = _result_6;
      _v_35 = _result_7;
      _v_36 = _result_8;
      _v_37 = _result_9;
      _v_38 = _result_10;
      _v_39 = _result_11;
      _v_40 = _result_12;
      _v_41 = _result_13;
      _v_42 = _result_14;
      _v_43 = _result_15;
      _v_44 = _result_16;
      _v_45 = _result_17;
      _v_46 = _result_18;
      _v_47 = _result_19;
    } else {
      _v_24 = _result_1;
      _v_25 = _result_2;
      _v_26 = _result_3;
      _v_27 = _result_4;
      _v_28 = _result_5;
      _v_29 = _b_0;
      _v_30 = _b_1;
      _v_31 = _b_2;
      _v_32 = _b_3;
      _v_33 = _b_4;
      _v_34 = 1;
      _v_35 = _result_6;
      _v_36 = _result_7;
      _v_37 = _result_8;
      _v_38 = _result_9;
      _v_39 = _result_10;
      _v_40 = _result_11;
      _v_41 = _result_12;
      _v_42 = _result_13;
      _v_43 = _result_14;
      _v_44 = _result_15;
      _v_45 = _result_16;
      _v_46 = _result_17;
      _v_47 = term_ctr(CID_SCON, STAT_OFF + 38);
    }
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  o[12] = _v_36;
  o[13] = _v_37;
  o[14] = _v_38;
  o[15] = _v_39;
  o[16] = _v_40;
  o[17] = _v_41;
  o[18] = _v_42;
  o[19] = _v_43;
  o[20] = _v_44;
  o[21] = _v_45;
  o[22] = _v_46;
  o[23] = _v_47;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, Term r12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, u32 r20, u32 r21, Term r22, u64 q22, Term r23, u64 q23, u32 r24) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h9 = r9;
  Term h10 = r10;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h19 = r19;
  Term h22 = r22;
  Term h23 = r23;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  Term _v_74 = 0;
  Term _v_75 = 0;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  u32 _v_78 = 0;
  Term _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  Term _v_90 = 0;
  Term _v_91 = 0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  Term _v_95 = 0;
  u32 _result_20 = r0;
  u32 _result_21 = r1;
  u32 _result_22 = r2;
  Term _result_23 = r3;
  Term _result_24 = r4;
  u32 _result_25 = r5;
  u32 _result_26 = r6;
  u32 _result_27 = r7;
  u32 _result_28 = r8;
  Term _result_29 = r9;
  Term _result_30 = r10;
  Term _result_31 = r11;
  Term _result_32 = r12;
  Term _result_33 = r13;
  Term _result_34 = r14;
  Term _result_35 = r15;
  Term _result_36 = r16;
  u32 _result_37 = r17;
  u32 _result_38 = r18;
  Term _result_39 = r19;
  u32 _a_0 = r20;
  u32 _a_1 = r21;
  Term _a_2 = r22;
  Term _a_3 = r23;
  u32 _a_4 = r24;
  WL_SPIN
    if (_result_20 == 0) {
      _v_72 = _a_0;
      _v_73 = _a_1;
      _v_74 = _a_2;
      _v_75 = _a_3;
      _v_76 = _a_4;
      _v_77 = _result_21;
      _v_78 = _result_22;
      _v_79 = _result_23;
      _v_80 = _result_24;
      _v_81 = _result_25;
      _v_82 = _result_26;
      _v_83 = _result_27;
      _v_84 = _result_28;
      _v_85 = _result_29;
      _v_86 = _result_30;
      _v_87 = _result_31;
      _v_88 = _result_32;
      _v_89 = _result_33;
      _v_90 = _result_34;
      _v_91 = _result_35;
      _v_92 = _result_36;
      _v_93 = _result_37;
      _v_94 = _result_38;
      _v_95 = _result_39;
    } else {
      _v_72 = _a_0;
      _v_73 = _a_1;
      _v_74 = _a_2;
      _v_75 = _a_3;
      _v_76 = _a_4;
      _v_77 = _result_21;
      _v_78 = _result_22;
      _v_79 = _result_23;
      _v_80 = _result_24;
      _v_81 = _result_25;
      _v_82 = 1;
      _v_83 = _result_26;
      _v_84 = _result_27;
      _v_85 = _result_28;
      _v_86 = _result_29;
      _v_87 = _result_30;
      _v_88 = _result_31;
      _v_89 = _result_32;
      _v_90 = _result_33;
      _v_91 = _result_34;
      _v_92 = _result_35;
      _v_93 = _result_36;
      _v_94 = _result_37;
      _v_95 = term_ctr(CID_SCON, STAT_OFF + 38);
    }
  break;
  }
  o[0] = _v_72;
  o[1] = _v_73;
  o[2] = _v_74;
  o[3] = _v_75;
  o[4] = _v_76;
  o[5] = _v_77;
  o[6] = _v_78;
  o[7] = _v_79;
  o[8] = _v_80;
  o[9] = _v_81;
  o[10] = _v_82;
  o[11] = _v_83;
  o[12] = _v_84;
  o[13] = _v_85;
  o[14] = _v_86;
  o[15] = _v_87;
  o[16] = _v_88;
  o[17] = _v_89;
  o[18] = _v_90;
  o[19] = _v_91;
  o[20] = _v_92;
  o[21] = _v_93;
  o[22] = _v_94;
  o[23] = _v_95;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _world_12 = r0;
  u32 _world_13 = r1;
  u32 _world_14 = r2;
  Term _world_15 = r3;
  u32 _world_16 = r4;
  Term _world_17 = r5;
  u32 _world_18 = r6;
  Term _world_19 = r7;
  Term _world_20 = r8;
  Term _world_21 = r9;
  u32 _world_22 = r10;
  u32 _world_23 = r11;
  WL_SPIN
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_0[2];
    if (spin_47(e, _o_0, _world_18) == 0) {
      return 0;
    }
    _v_28 = _o_0[0];
    _v_29 = _o_0[1];
    _v_26 = _v_28;
    _v_27 = _v_29;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    Term _o_1[13];
    if (spin_48(e, _o_1, _v_26, _v_27, _world_12, _world_13, _world_14, _world_15, _world_15 == h3 ? q3 : blk_loc(e.mem, _world_15), _world_16, _world_17, _world_19, _world_19 == h7 ? q7 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h8 ? q8 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h9 ? q9 : blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_30 = _o_1[0];
    _v_31 = _o_1[1];
    _v_32 = _o_1[2];
    _v_33 = _o_1[3];
    _v_34 = _o_1[4];
    _v_35 = _o_1[5];
    _v_36 = _o_1[6];
    _v_37 = _o_1[7];
    _v_38 = _o_1[8];
    _v_39 = _o_1[9];
    _v_40 = _o_1[10];
    _v_41 = _o_1[11];
    _v_42 = _o_1[12];
    _v_13 = _v_30;
    _v_14 = _v_31;
    _v_15 = _v_32;
    _v_16 = _v_33;
    _v_17 = _v_34;
    _v_18 = _v_35;
    _v_19 = _v_36;
    _v_20 = _v_37;
    _v_21 = _v_38;
    _v_22 = _v_39;
    _v_23 = _v_40;
    _v_24 = _v_41;
    _v_25 = _v_42;
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  o[5] = _v_18;
  o[6] = _v_19;
  o[7] = _v_20;
  o[8] = _v_21;
  o[9] = _v_22;
  o[10] = _v_23;
  o[11] = _v_24;
  o[12] = _v_25;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  WL_SPIN
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_0[13];
    if (spin_52(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
      return 0;
    }
    _v_27 = _o_0[0];
    _v_28 = _o_0[1];
    _v_29 = _o_0[2];
    _v_30 = _o_0[3];
    _v_31 = _o_0[4];
    _v_32 = _o_0[5];
    _v_33 = _o_0[6];
    _v_34 = _o_0[7];
    _v_35 = _o_0[8];
    _v_36 = _o_0[9];
    _v_37 = _o_0[10];
    _v_38 = _o_0[11];
    _v_39 = _o_0[12];
    _v_14 = _v_27;
    _v_15 = _v_28;
    _v_16 = _v_29;
    _v_17 = _v_30;
    _v_18 = _v_31;
    _v_19 = _v_32;
    _v_20 = _v_33;
    _v_21 = _v_34;
    _v_22 = _v_35;
    _v_23 = _v_36;
    _v_24 = _v_37;
    _v_25 = _v_38;
    _v_26 = _v_39;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_41 = 0;
  Term _cap_0 = r0;
  WL_SPIN
    _v_41 = _cap_0;
  break;
  }
  o[0] = _v_41;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _observed_0 = r0;
  u32 _observed_1 = r1;
  u32 _observed_2 = r2;
  Term _observed_3 = r3;
  u32 _observed_4 = r4;
  Term _observed_5 = r5;
  u32 _observed_6 = r6;
  Term _observed_7 = r7;
  Term _observed_8 = r8;
  Term _observed_9 = r9;
  u32 _observed_10 = r10;
  u32 _observed_11 = r11;
  u32 _observed_12 = r12;
  u32 _slot_2 = r13;
  WL_SPIN
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    Term _o_0[1];
    if (spin_20(e, _o_0, U32_BIN(_slot_2, ==, 0ull)) == 0) {
      return 0;
    }
    _v_28 = _o_0[0];
    _v_27 = _v_28;
    u32 _v_29 = 0;
    Term _o_1[1];
    if (spin_2(e, _o_1, _v_27, U32_BIN(_observed_12, <, 1000000ull)) == 0) {
      return 0;
    }
    _v_29 = _o_1[0];
    _v_26 = _v_29;
    _v_13 = _observed_0;
    _v_14 = _observed_1;
    _v_15 = _observed_2;
    _v_16 = _observed_3;
    _v_17 = _observed_4;
    _v_18 = _observed_5;
    _v_19 = _observed_6;
    _v_20 = _observed_7;
    _v_21 = _observed_8;
    _v_22 = _observed_9;
    _v_23 = _observed_10;
    _v_24 = _observed_11;
    _v_25 = _v_26;
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  o[5] = _v_18;
  o[6] = _v_19;
  o[7] = _v_20;
  o[8] = _v_21;
  o[9] = _v_22;
  o[10] = _v_23;
  o[11] = _v_24;
  o[12] = _v_25;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _available_0 = r0;
  u32 _world_12 = r1;
  u32 _world_13 = r2;
  u32 _world_14 = r3;
  Term _world_15 = r4;
  u32 _world_16 = r5;
  Term _world_17 = r6;
  u32 _world_18 = r7;
  Term _world_19 = r8;
  Term _world_20 = r9;
  Term _world_21 = r10;
  u32 _world_22 = r11;
  u32 _world_23 = r12;
  Term _name_1 = r13;
  Term _access_1 = r14;
  WL_SPIN
    if (_available_0 == 0) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_14 = _world_12;
      _v_15 = _world_13;
      _v_16 = _world_14;
      _v_17 = _world_15;
      _v_18 = _world_16;
      _v_19 = _world_17;
      _v_20 = _world_18;
      _v_21 = _world_19;
      _v_22 = _world_20;
      _v_23 = _world_21;
      _v_24 = _world_22;
      _v_25 = _world_23;
      _v_26 = 1;
      _v_27 = 3;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _world_22);
      e.mem[_nd_0 + 1] = rfc_seal(e, _name_1);
      e.mem[_nd_0 + 2] = rfc_seal(e, _access_1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_______SRC_ECS_WORLD_REGISTRATIONMETA, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _world_21);
      _v_14 = _world_12;
      _v_15 = _world_13;
      _v_16 = _world_14;
      _v_17 = _world_15;
      _v_18 = _world_16;
      _v_19 = _world_17;
      _v_20 = _world_18;
      _v_21 = _world_19;
      _v_22 = _world_20;
      _v_23 = term_ctr(CID_CON, _nd_1);
      _v_24 = U32_BIN(_world_22, +, 1ull);
      _v_25 = _world_23;
      _v_26 = 0;
      _v_27 = _world_22;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, Term r15, u64 q15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h15 = r15;
  Term h16 = r16;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _result_0 = r12;
  u32 _result_1 = r13;
  u32 _namespace_1 = r14;
  Term _name_1 = r15;
  Term _access_1 = r16;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_18 = 1;
      _v_19 = _world_0;
      _v_20 = _world_1;
      _v_21 = _world_2;
      _v_22 = _world_3;
      _v_23 = _world_4;
      _v_24 = _world_5;
      _v_25 = _world_6;
      _v_26 = _world_7;
      _v_27 = _world_8;
      _v_28 = _world_9;
      _v_29 = _world_10;
      _v_30 = _world_11;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
    } else {
      _v_18 = 0;
      _v_19 = _world_0;
      _v_20 = _world_1;
      _v_21 = _world_2;
      _v_22 = _world_3;
      _v_23 = _world_4;
      _v_24 = _world_5;
      _v_25 = _world_6;
      _v_26 = _world_7;
      _v_27 = _world_8;
      _v_28 = _world_9;
      _v_29 = _world_10;
      _v_30 = _world_11;
      _v_31 = _namespace_1;
      _v_32 = _result_1;
      _v_33 = _name_1;
      _v_34 = _access_1;
      _v_35 = 0ull;
    }
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  o[9] = _v_27;
  o[10] = _v_28;
  o[11] = _v_29;
  o[12] = _v_30;
  o[13] = _v_31;
  o[14] = _v_32;
  o[15] = _v_33;
  o[16] = _v_34;
  o[17] = _v_35;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, u32 r13) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _allowed_0 = r0;
  u32 _namespace_2 = r1;
  Term _name_2 = r2;
  Term _steps_2 = r3;
  u32 _owners_20 = r4;
  u32 _owners_21 = r5;
  Term _owners_22 = r6;
  Term _owners_23 = r7;
  u32 _owners_24 = r8;
  u32 _owners_25 = r9;
  u32 _owners_26 = r10;
  Term _owners_27 = r11;
  Term _owners_28 = r12;
  u32 _owners_29 = r13;
  WL_SPIN
    if (_allowed_0 == 0) {
      term_sink(e, _name_2);
      term_sink(e, _steps_2);
      _v_14 = 1;
      _v_15 = _owners_20;
      _v_16 = _owners_21;
      _v_17 = _owners_22;
      _v_18 = _owners_23;
      _v_19 = _owners_24;
      _v_20 = _owners_25;
      _v_21 = _owners_26;
      _v_22 = _owners_27;
      _v_23 = _owners_28;
      _v_24 = _owners_29;
      _v_25 = 0;
      _v_26 = 0;
      _v_27 = 0;
    } else {
      _v_14 = 0;
      _v_15 = _namespace_2;
      _v_16 = _name_2;
      _v_17 = _steps_2;
      _v_18 = _owners_20;
      _v_19 = _owners_21;
      _v_20 = _owners_22;
      _v_21 = _owners_23;
      _v_22 = _owners_24;
      _v_23 = _owners_25;
      _v_24 = _owners_26;
      _v_25 = _owners_27;
      _v_26 = _owners_28;
      _v_27 = _owners_29;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  Term _name_1 = r12;
  Term _access_1 = r13;
  WL_SPIN
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    Term _o_0[14];
    if (spin_56(e, _o_0, U32_BIN(_world_10, <, 4294967295ull), _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_11, _name_1, _name_1 == h12 ? q12 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h13 ? q13 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_42 = _o_0[0];
    _v_43 = _o_0[1];
    _v_44 = _o_0[2];
    _v_45 = _o_0[3];
    _v_46 = _o_0[4];
    _v_47 = _o_0[5];
    _v_48 = _o_0[6];
    _v_49 = _o_0[7];
    _v_50 = _o_0[8];
    _v_51 = _o_0[9];
    _v_52 = _o_0[10];
    _v_53 = _o_0[11];
    _v_54 = _o_0[12];
    _v_55 = _o_0[13];
    _v_28 = _v_42;
    _v_29 = _v_43;
    _v_30 = _v_44;
    _v_31 = _v_45;
    _v_32 = _v_46;
    _v_33 = _v_47;
    _v_34 = _v_48;
    _v_35 = _v_49;
    _v_36 = _v_50;
    _v_37 = _v_51;
    _v_38 = _v_52;
    _v_39 = _v_53;
    _v_40 = _v_54;
    _v_41 = _v_55;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, Term r15, u64 q15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h15 = r15;
  Term h16 = r16;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  Term _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  u32 _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  Term _v_90 = 0;
  u32 _v_91 = 0;
  u32 _registered_0 = r0;
  u32 _registered_1 = r1;
  u32 _registered_2 = r2;
  Term _registered_3 = r3;
  u32 _registered_4 = r4;
  Term _registered_5 = r5;
  u32 _registered_6 = r6;
  Term _registered_7 = r7;
  Term _registered_8 = r8;
  Term _registered_9 = r9;
  u32 _registered_10 = r10;
  u32 _registered_11 = r11;
  u32 _registered_12 = r12;
  u32 _registered_13 = r13;
  u32 _namespace_0 = r14;
  Term _name_2 = r15;
  Term _access_2 = r16;
  WL_SPIN
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    Term _v_96 = 0;
    u32 _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    Term _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    Term _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    Term _o_2[18];
    if (spin_57(e, _o_2, _registered_0, _registered_1, _registered_2, _registered_3, _registered_3 == h3 ? q3 : blk_loc(e.mem, _registered_3), _registered_4, _registered_5, _registered_6, _registered_7, _registered_7 == h7 ? q7 : blk_loc(e.mem, _registered_7), _registered_8, _registered_8 == h8 ? q8 : blk_loc(e.mem, _registered_8), _registered_9, _registered_9 == h9 ? q9 : blk_loc(e.mem, _registered_9), _registered_10, _registered_11, _registered_12, _registered_13, _namespace_0, _name_2, _name_2 == h15 ? q15 : blk_loc(e.mem, _name_2), _access_2, _access_2 == h16 ? q16 : blk_loc(e.mem, _access_2)) == 0) {
      return 0;
    }
    _v_92 = _o_2[0];
    _v_93 = _o_2[1];
    _v_94 = _o_2[2];
    _v_95 = _o_2[3];
    _v_96 = _o_2[4];
    _v_97 = _o_2[5];
    _v_98 = _o_2[6];
    _v_99 = _o_2[7];
    _v_100 = _o_2[8];
    _v_101 = _o_2[9];
    _v_102 = _o_2[10];
    _v_103 = _o_2[11];
    _v_104 = _o_2[12];
    _v_105 = _o_2[13];
    _v_106 = _o_2[14];
    _v_107 = _o_2[15];
    _v_108 = _o_2[16];
    _v_109 = _o_2[17];
    _v_74 = _v_92;
    _v_75 = _v_93;
    _v_76 = _v_94;
    _v_77 = _v_95;
    _v_78 = _v_96;
    _v_79 = _v_97;
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    _v_89 = _v_107;
    _v_90 = _v_108;
    _v_91 = _v_109;
  break;
  }
  o[0] = _v_74;
  o[1] = _v_75;
  o[2] = _v_76;
  o[3] = _v_77;
  o[4] = _v_78;
  o[5] = _v_79;
  o[6] = _v_80;
  o[7] = _v_81;
  o[8] = _v_82;
  o[9] = _v_83;
  o[10] = _v_84;
  o[11] = _v_85;
  o[12] = _v_86;
  o[13] = _v_87;
  o[14] = _v_88;
  o[15] = _v_89;
  o[16] = _v_90;
  o[17] = _v_91;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, Term r14, u64 q14) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  u32 _v_100 = 0;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  Term _v_104 = 0;
  u32 _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  Term _v_108 = 0;
  u32 _v_109 = 0;
  u32 _v_110 = 0;
  u32 _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  Term _v_114 = 0;
  u32 _v_115 = 0;
  u32 _named_0 = r0;
  u32 _named_1 = r1;
  u32 _named_2 = r2;
  Term _named_3 = r3;
  u32 _named_4 = r4;
  Term _named_5 = r5;
  u32 _named_6 = r6;
  Term _named_7 = r7;
  Term _named_8 = r8;
  Term _named_9 = r9;
  u32 _named_10 = r10;
  u32 _named_11 = r11;
  u32 _named_12 = r12;
  Term _name_1 = r13;
  Term _access_1 = r14;
  WL_SPIN
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    Term _v_119 = 0;
    u32 _v_120 = 0;
    Term _v_121 = 0;
    u32 _v_122 = 0;
    Term _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    _name_1 = term_keep(e, _name_1, 1);
    _access_1 = term_keep(e, _access_1, 1);
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    u32 _v_132 = 0;
    Term _v_133 = 0;
    u32 _v_134 = 0;
    Term _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    Term _v_138 = 0;
    Term _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    u32 _v_143 = 0;
    Term _o_1[14];
    if (spin_59(e, _o_1, _named_0, _named_1, _named_2, _named_3, _named_3 == h3 ? q3 : blk_loc(e.mem, _named_3), _named_4, _named_5, _named_6, _named_7, _named_7 == h7 ? q7 : blk_loc(e.mem, _named_7), _named_8, _named_8 == h8 ? q8 : blk_loc(e.mem, _named_8), _named_9, _named_9 == h9 ? q9 : blk_loc(e.mem, _named_9), _named_10, _named_11, _name_1, _name_1 == h13 ? q13 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h14 ? q14 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_130 = _o_1[0];
    _v_131 = _o_1[1];
    _v_132 = _o_1[2];
    _v_133 = _o_1[3];
    _v_134 = _o_1[4];
    _v_135 = _o_1[5];
    _v_136 = _o_1[6];
    _v_137 = _o_1[7];
    _v_138 = _o_1[8];
    _v_139 = _o_1[9];
    _v_140 = _o_1[10];
    _v_141 = _o_1[11];
    _v_142 = _o_1[12];
    _v_143 = _o_1[13];
    _v_116 = _v_130;
    _v_117 = _v_131;
    _v_118 = _v_132;
    _v_119 = _v_133;
    _v_120 = _v_134;
    _v_121 = _v_135;
    _v_122 = _v_136;
    _v_123 = _v_137;
    _v_124 = _v_138;
    _v_125 = _v_139;
    _v_126 = _v_140;
    _v_127 = _v_141;
    _v_128 = _v_142;
    _v_129 = _v_143;
    u32 _v_144 = 0;
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    Term _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    u32 _v_151 = 0;
    Term _v_152 = 0;
    Term _v_153 = 0;
    Term _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    u32 _v_158 = 0;
    Term _v_159 = 0;
    Term _v_160 = 0;
    u32 _v_161 = 0;
    Term _o_2[18];
    if (spin_60(e, _o_2, _v_116, _v_117, _v_118, _v_119, _v_119 == h14 ? q14 : _v_119 == h13 ? q13 : _v_119 == h9 ? q9 : _v_119 == h8 ? q8 : _v_119 == h7 ? q7 : _v_119 == h3 ? q3 : blk_loc(e.mem, _v_119), _v_120, _v_121, _v_122, _v_123, _v_123 == h14 ? q14 : _v_123 == h13 ? q13 : _v_123 == h9 ? q9 : _v_123 == h8 ? q8 : _v_123 == h7 ? q7 : _v_123 == h3 ? q3 : blk_loc(e.mem, _v_123), _v_124, _v_124 == h14 ? q14 : _v_124 == h13 ? q13 : _v_124 == h9 ? q9 : _v_124 == h8 ? q8 : _v_124 == h7 ? q7 : _v_124 == h3 ? q3 : blk_loc(e.mem, _v_124), _v_125, _v_125 == h14 ? q14 : _v_125 == h13 ? q13 : _v_125 == h9 ? q9 : _v_125 == h8 ? q8 : _v_125 == h7 ? q7 : _v_125 == h3 ? q3 : blk_loc(e.mem, _v_125), _v_126, _v_127, _v_128, _v_129, _named_12, _name_1, _name_1 == h13 ? q13 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h14 ? q14 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_144 = _o_2[0];
    _v_145 = _o_2[1];
    _v_146 = _o_2[2];
    _v_147 = _o_2[3];
    _v_148 = _o_2[4];
    _v_149 = _o_2[5];
    _v_150 = _o_2[6];
    _v_151 = _o_2[7];
    _v_152 = _o_2[8];
    _v_153 = _o_2[9];
    _v_154 = _o_2[10];
    _v_155 = _o_2[11];
    _v_156 = _o_2[12];
    _v_157 = _o_2[13];
    _v_158 = _o_2[14];
    _v_159 = _o_2[15];
    _v_160 = _o_2[16];
    _v_161 = _o_2[17];
    _v_98 = _v_144;
    _v_99 = _v_145;
    _v_100 = _v_146;
    _v_101 = _v_147;
    _v_102 = _v_148;
    _v_103 = _v_149;
    _v_104 = _v_150;
    _v_105 = _v_151;
    _v_106 = _v_152;
    _v_107 = _v_153;
    _v_108 = _v_154;
    _v_109 = _v_155;
    _v_110 = _v_156;
    _v_111 = _v_157;
    _v_112 = _v_158;
    _v_113 = _v_159;
    _v_114 = _v_160;
    _v_115 = _v_161;
  break;
  }
  o[0] = _v_98;
  o[1] = _v_99;
  o[2] = _v_100;
  o[3] = _v_101;
  o[4] = _v_102;
  o[5] = _v_103;
  o[6] = _v_104;
  o[7] = _v_105;
  o[8] = _v_106;
  o[9] = _v_107;
  o[10] = _v_108;
  o[11] = _v_109;
  o[12] = _v_110;
  o[13] = _v_111;
  o[14] = _v_112;
  o[15] = _v_113;
  o[16] = _v_114;
  o[17] = _v_115;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  u32 _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  u32 _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  Term _name_0 = r12;
  Term _access_0 = r13;
  WL_SPIN
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_0[13];
    if (spin_49(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
      return 0;
    }
    _v_67 = _o_0[0];
    _v_68 = _o_0[1];
    _v_69 = _o_0[2];
    _v_70 = _o_0[3];
    _v_71 = _o_0[4];
    _v_72 = _o_0[5];
    _v_73 = _o_0[6];
    _v_74 = _o_0[7];
    _v_75 = _o_0[8];
    _v_76 = _o_0[9];
    _v_77 = _o_0[10];
    _v_78 = _o_0[11];
    _v_79 = _o_0[12];
    _v_54 = _v_67;
    _v_55 = _v_68;
    _v_56 = _v_69;
    _v_57 = _v_70;
    _v_58 = _v_71;
    _v_59 = _v_72;
    _v_60 = _v_73;
    _v_61 = _v_74;
    _v_62 = _v_75;
    _v_63 = _v_76;
    _v_64 = _v_77;
    _v_65 = _v_78;
    _v_66 = _v_79;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    Term _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    u32 _v_97 = 0;
    Term _o_3[18];
    if (spin_62(e, _o_3, _v_54, _v_55, _v_56, _v_57, _v_57 == h13 ? q13 : _v_57 == h12 ? q12 : _v_57 == h9 ? q9 : _v_57 == h8 ? q8 : _v_57 == h7 ? q7 : _v_57 == h3 ? q3 : blk_loc(e.mem, _v_57), _v_58, _v_59, _v_60, _v_61, _v_61 == h13 ? q13 : _v_61 == h12 ? q12 : _v_61 == h9 ? q9 : _v_61 == h8 ? q8 : _v_61 == h7 ? q7 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_62 == h13 ? q13 : _v_62 == h12 ? q12 : _v_62 == h9 ? q9 : _v_62 == h8 ? q8 : _v_62 == h7 ? q7 : _v_62 == h3 ? q3 : blk_loc(e.mem, _v_62), _v_63, _v_63 == h13 ? q13 : _v_63 == h12 ? q12 : _v_63 == h9 ? q9 : _v_63 == h8 ? q8 : _v_63 == h7 ? q7 : _v_63 == h3 ? q3 : blk_loc(e.mem, _v_63), _v_64, _v_65, _v_66, _name_0, _name_0 == h12 ? q12 : blk_loc(e.mem, _name_0), _access_0, _access_0 == h13 ? q13 : blk_loc(e.mem, _access_0)) == 0) {
      return 0;
    }
    _v_80 = _o_3[0];
    _v_81 = _o_3[1];
    _v_82 = _o_3[2];
    _v_83 = _o_3[3];
    _v_84 = _o_3[4];
    _v_85 = _o_3[5];
    _v_86 = _o_3[6];
    _v_87 = _o_3[7];
    _v_88 = _o_3[8];
    _v_89 = _o_3[9];
    _v_90 = _o_3[10];
    _v_91 = _o_3[11];
    _v_92 = _o_3[12];
    _v_93 = _o_3[13];
    _v_94 = _o_3[14];
    _v_95 = _o_3[15];
    _v_96 = _o_3[16];
    _v_97 = _o_3[17];
    _v_36 = _v_80;
    _v_37 = _v_81;
    _v_38 = _v_82;
    _v_39 = _v_83;
    _v_40 = _v_84;
    _v_41 = _v_85;
    _v_42 = _v_86;
    _v_43 = _v_87;
    _v_44 = _v_88;
    _v_45 = _v_89;
    _v_46 = _v_90;
    _v_47 = _v_91;
    _v_48 = _v_92;
    _v_49 = _v_93;
    _v_50 = _v_94;
    _v_51 = _v_95;
    _v_52 = _v_96;
    _v_53 = _v_97;
  break;
  }
  o[0] = _v_36;
  o[1] = _v_37;
  o[2] = _v_38;
  o[3] = _v_39;
  o[4] = _v_40;
  o[5] = _v_41;
  o[6] = _v_42;
  o[7] = _v_43;
  o[8] = _v_44;
  o[9] = _v_45;
  o[10] = _v_46;
  o[11] = _v_47;
  o[12] = _v_48;
  o[13] = _v_49;
  o[14] = _v_50;
  o[15] = _v_51;
  o[16] = _v_52;
  o[17] = _v_53;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, u32 r0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  u32 _resource_1 = r2;
  WL_SPIN
    if (_available_0 == 0) {
      _v_14 = 1;
      _v_15 = _namespace_0;
      _v_16 = _resource_1;
      _v_17 = 0;
      _v_18 = 0;
      _v_19 = 0;
      _v_20 = 0;
      _v_21 = 0;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
      _v_26 = 0;
      _v_27 = 0;
    } else {
      Term _fv_0[1];
      _fv_0[0] = 0;
      _v_14 = 0;
      _v_15 = U32_BIN(_namespace_0, +, 1ull);
      _v_16 = _namespace_0;
      _v_17 = 1ull;
      _v_18 = 0ull;
      _v_19 = blk_new(e, 0, 0, 0, 1, _fv_0);
      _v_20 = 1ull;
      _v_21 = 0;
      _v_22 = _resource_1;
      _v_23 = term_pak(CID_NIL, 0);
      _v_24 = term_pak(CID_NIL, 0);
      _v_25 = term_pak(CID_NIL, 0);
      _v_26 = 1ull;
      _v_27 = 0ull;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0)
  {
    Term _undo_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    u32 _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    u32 _world_11 = r12;
    WL_OPEN
    if (term_aux(_undo_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      WL_RETN(12);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _undo_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = heap_alloc(e, cls_fit(13));
      e.mem[_nd_0 + 0] = rfc_seal(e, _world_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _world_1);
      e.mem[_nd_0 + 2] = rfc_seal(e, _world_2);
      e.mem[_nd_0 + 3] = rfc_seal(e, _world_3);
      e.mem[_nd_0 + 4] = rfc_seal(e, _world_4);
      e.mem[_nd_0 + 5] = rfc_seal(e, _world_5);
      e.mem[_nd_0 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_0 + 7] = rfc_seal(e, _world_6);
      e.mem[_nd_0 + 8] = rfc_seal(e, _world_7);
      e.mem[_nd_0 + 9] = rfc_seal(e, _world_8);
      e.mem[_nd_0 + 10] = rfc_seal(e, _world_9);
      e.mem[_nd_0 + 11] = rfc_seal(e, _world_10);
      e.mem[_nd_0 + 12] = rfc_seal(e, _world_11);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_______SRC_ECS_TRANSACTION_ROLLBACK_0_K3;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_TRANSACTION_ROLLBACK_0_K3, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0_K3, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        e.mem[_t_1 + 1] = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_0);
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _f_0;
      r1 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_0);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0_K3)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_1[13];
    u64 _sp_1 = ctr_take(e, _h_0, 13, _fb_1);
    u32 _f_3 = _fb_1[0];
    u32 _f_4 = _fb_1[1];
    u32 _f_5 = _fb_1[2];
    Term _f_6 = _fb_1[3];
    u32 _f_7 = _fb_1[4];
    Term _f_8 = _fb_1[5];
    Term _f_9 = _fb_1[6];
    Term _f_10 = _fb_1[7];
    Term _f_11 = _fb_1[8];
    Term _f_12 = _fb_1[9];
    Term _f_13 = _fb_1[10];
    u32 _f_14 = _fb_1[11];
    u32 _f_15 = _fb_1[12];
    spare_free(e, cls_fit(13), _sp_1);
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0)) {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_TRANSACTION_ROLLBACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _f_3;
      e.mem[_t_2 + 2] = _f_4;
      e.mem[_t_2 + 3] = _f_5;
      e.mem[_t_2 + 4] = _f_6;
      e.mem[_t_2 + 5] = _f_7;
      e.mem[_t_2 + 6] = _f_8;
      e.mem[_t_2 + 7] = _f_10;
      e.mem[_t_2 + 8] = _f_11;
      e.mem[_t_2 + 9] = _f_12;
      e.mem[_t_2 + 10] = _f_13;
      e.mem[_t_2 + 11] = _f_14;
      e.mem[_t_2 + 12] = _f_15;
      return term_tsk(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0, _t_2);
    }
    r0 = _f_2;
    r1 = _f_3;
    r2 = _f_4;
    r3 = _f_5;
    r4 = _f_6;
    r5 = _f_7;
    r6 = _f_8;
    r7 = _f_10;
    r8 = _f_11;
    r9 = _f_12;
    r10 = _f_13;
    r11 = _f_14;
    r12 = _f_15;
    WL_JMP(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_TRANSACTION_FINISH_0)
  {
    u32 _tx_0 = r0;
    u32 _tx_1 = r1;
    u32 _tx_2 = r2;
    Term _tx_3 = r3;
    u32 _tx_4 = r4;
    Term _tx_5 = r5;
    u32 _tx_6 = r6;
    Term _tx_7 = r7;
    Term _tx_8 = r8;
    Term _tx_9 = r9;
    u32 _tx_10 = r10;
    u32 _tx_11 = r11;
    Term _tx_12 = r12;
    Term _tx_13 = r13;
    Term _tx_14 = r14;
    u32 _outcome_0 = r15;
    Term _outcome_1 = r16;
    WL_OPEN
    if (_outcome_0 == 0) {
      term_sink(e, _tx_12);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      u32 _v_6 = 0;
      Term _v_7 = 0;
      Term _v_8 = 0;
      Term _v_9 = 0;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      Term _v_13 = 0;
      Term _o_0[1];
      if (spin_4(e, _o_0, _tx_13, blk_loc(e.mem, _tx_13)) == 0) {
        return 0;
      }
      _v_13 = _o_0[0];
      _v_12 = _v_13;
      u32 _v_14 = 0;
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      Term _v_17 = 0;
      u32 _v_18 = 0;
      Term _v_19 = 0;
      u32 _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      u32 _v_24 = 0;
      u32 _v_25 = 0;
      Term _o_1[12];
      if (spin_6(e, _o_1, _tx_0, _tx_1, _tx_2, _tx_3, blk_loc(e.mem, _tx_3), _tx_4, _tx_5, _tx_6, _tx_7, blk_loc(e.mem, _tx_7), _tx_8, blk_loc(e.mem, _tx_8), _tx_9, blk_loc(e.mem, _tx_9), _tx_10, _tx_11, _v_12, blk_loc(e.mem, _v_12)) == 0) {
        return 0;
      }
      _v_14 = _o_1[0];
      _v_15 = _o_1[1];
      _v_16 = _o_1[2];
      _v_17 = _o_1[3];
      _v_18 = _o_1[4];
      _v_19 = _o_1[5];
      _v_20 = _o_1[6];
      _v_21 = _o_1[7];
      _v_22 = _o_1[8];
      _v_23 = _o_1[9];
      _v_24 = _o_1[10];
      _v_25 = _o_1[11];
      _v_0 = _v_14;
      _v_1 = _v_15;
      _v_2 = _v_16;
      _v_3 = _v_17;
      _v_4 = _v_18;
      _v_5 = _v_19;
      _v_6 = _v_20;
      _v_7 = _v_21;
      _v_8 = _v_22;
      _v_9 = _v_23;
      _v_10 = _v_24;
      _v_11 = _v_25;
      u32 _v_26 = 0;
      u32 _v_27 = 0;
      u32 _v_28 = 0;
      Term _v_29 = 0;
      u32 _v_30 = 0;
      Term _v_31 = 0;
      u32 _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      u32 _v_36 = 0;
      u32 _v_37 = 0;
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _o_2[1];
      if (spin_7(e, _o_2, _tx_14, blk_loc(e.mem, _tx_14)) == 0) {
        return 0;
      }
      _v_39 = _o_2[0];
      _v_38 = _v_39;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      u32 _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      Term _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      Term _o_3[12];
      if (spin_9(e, _o_3, _v_0, _v_1, _v_2, _v_3, blk_loc(e.mem, _v_3), _v_4, _v_5, _v_6, _v_7, blk_loc(e.mem, _v_7), _v_8, blk_loc(e.mem, _v_8), _v_9, blk_loc(e.mem, _v_9), _v_10, _v_11, _v_38, blk_loc(e.mem, _v_38)) == 0) {
        return 0;
      }
      _v_40 = _o_3[0];
      _v_41 = _o_3[1];
      _v_42 = _o_3[2];
      _v_43 = _o_3[3];
      _v_44 = _o_3[4];
      _v_45 = _o_3[5];
      _v_46 = _o_3[6];
      _v_47 = _o_3[7];
      _v_48 = _o_3[8];
      _v_49 = _o_3[9];
      _v_50 = _o_3[10];
      _v_51 = _o_3[11];
      _v_26 = _v_40;
      _v_27 = _v_41;
      _v_28 = _v_42;
      _v_29 = _v_43;
      _v_30 = _v_44;
      _v_31 = _v_45;
      _v_32 = _v_46;
      _v_33 = _v_47;
      _v_34 = _v_48;
      _v_35 = _v_49;
      _v_36 = _v_50;
      _v_37 = _v_51;
      r0 = _v_26;
      r1 = _v_27;
      r2 = _v_28;
      r3 = _v_29;
      r4 = _v_30;
      r5 = _v_31;
      r6 = _v_32;
      r7 = _v_33;
      r8 = _v_34;
      r9 = _v_35;
      r10 = _v_36;
      r11 = _v_37;
      r12 = 0;
      r13 = 0;
      WL_RETN(14);
    } else {
      term_sink(e, _tx_13);
      term_sink(e, _tx_14);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _outcome_1;
        STK(1) = FID_______SRC_ECS_TRANSACTION_FINISH_0_K23;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_TRANSACTION_FINISH_0_K23, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _outcome_1;
        WL_CONT = term_tsk(FID_______SRC_ECS_TRANSACTION_FINISH_0_K23, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0)) {
        u64 _t_1 = task_node(e, FID_______SRC_ECS_TRANSACTION_ROLLBACK_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _tx_12;
        e.mem[_t_1 + 1] = _tx_0;
        e.mem[_t_1 + 2] = _tx_1;
        e.mem[_t_1 + 3] = _tx_2;
        e.mem[_t_1 + 4] = _tx_3;
        e.mem[_t_1 + 5] = _tx_4;
        e.mem[_t_1 + 6] = _tx_5;
        e.mem[_t_1 + 7] = _tx_6;
        e.mem[_t_1 + 8] = _tx_7;
        e.mem[_t_1 + 9] = _tx_8;
        e.mem[_t_1 + 10] = _tx_9;
        e.mem[_t_1 + 11] = _tx_10;
        e.mem[_t_1 + 12] = _tx_11;
        return term_tsk(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0, _t_1);
      }
      r0 = _tx_12;
      r1 = _tx_0;
      r2 = _tx_1;
      r3 = _tx_2;
      r4 = _tx_3;
      r5 = _tx_4;
      r6 = _tx_5;
      r7 = _tx_6;
      r8 = _tx_7;
      r9 = _tx_8;
      r10 = _tx_9;
      r11 = _tx_10;
      r12 = _tx_11;
      WL_JMP(FID_______SRC_ECS_TRANSACTION_ROLLBACK_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_TRANSACTION_FINISH_0_K23)
  {
    WL_POPN(1);
    Term _outcome_2 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    WL_OPEN
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = 1;
    r13 = _outcome_2;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      if (term_aux(_b_0) == CID_SNIL) {
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 1;
        WL_RETN(3);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _b_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_ctr(CID_SCON, _nd_0);
        r2 = 0;
        WL_RETN(3);
      }
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _a_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      if (term_aux(_b_0) == CID_SNIL) {
        u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
        r0 = term_ctr(CID_SCON, _nd_1);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 2;
        WL_RETN(3);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _b_0, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        u32 _v_0 = 0;
        u32 _v_1 = 0;
        u32 _v_2 = 0;
        u32 _v_3 = 0;
        u32 _v_4 = 0;
        u32 _v_5 = 0;
        Term _o_0[3];
        if (spin_26(e, _o_0, _f_2, _f_4) == 0) {
          return 0;
        }
        _v_3 = _o_0[0];
        _v_4 = _o_0[1];
        _v_5 = _o_0[2];
        _v_0 = _v_3;
        _v_1 = _v_4;
        _v_2 = _v_5;
        if (_v_2 == 0) {
          u64 _nd_2 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_2 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_2 + 1] = rfc_seal(e, _f_3);
          u64 _nd_3 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_3 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_2);
          r1 = term_ctr(CID_SCON, _nd_3);
          r2 = 0;
          WL_RETN(3);
        } else if (_v_2 == 1) {
          spare_free(e, cls_fit(2), _sp_2);
          spare_free(e, cls_fit(2), _sp_1);
          if (seq) {
            WL_ROOM(3);
            STK(0) = _v_0;
            STK(1) = _v_1;
            STK(2) = FID_STRING_CMP_K35;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_STRING_CMP_K35, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_0;
            e.mem[_t_0 + 1] = _v_1;
            WL_CONT = term_tsk(FID_STRING_CMP_K35, _t_0);
            WL_IDX = 2;
          }
          r0 = _f_3;
          r1 = _f_5;
          _a_0 = r0;
          _b_0 = r1;
          WL_AGAIN(FID_STRING_CMP);
        } else {
          u64 _nd_4 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_4 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_4 + 1] = rfc_seal(e, _f_3);
          u64 _nd_5 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_5 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_5 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_4);
          r1 = term_ctr(CID_SCON, _nd_5);
          r2 = 2;
          WL_RETN(3);
        }
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP_K35)
  {
    WL_POPN(2);
    u32 _v_9 = STK(0);
    u32 _v_10 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_1[3];
    if (spin_18(e, _o_1, _v_9, _v_10, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    r0 = _v_11;
    r1 = _v_12;
    r2 = _v_13;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_LENGTH)
  {
    Term _xs_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      term_sink(e, _f_0);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_LIST_LENGTH_K47;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_LENGTH_K47, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_LIST_LENGTH_K47, _t_0);
        WL_IDX = 0;
      }
      r0 = _f_1;
      _xs_0 = r0;
      WL_AGAIN(FID_LIST_LENGTH);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_LENGTH_K47)
  {
    Term _h_0 = r0;
    WL_OPEN
    r0 = nat_chk(e, _h_0 + 1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_ORDER_K49;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_ORDER_K49, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_ORDER_K49, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_CMP)) {
      u64 _t_1 = task_node(e, FID_STRING_CMP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_CMP, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_CMP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER_K49)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    Term _b_1 = 0;
    if (_h_2 == 0) {
      _b_1 = term_pak(CID_LT, 0);
    } else if (_h_2 == 1) {
      _b_1 = term_pak(CID_EQ, 0);
    } else {
      _b_1 = term_pak(CID_GT, 0);
    }
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_1 = term_ctr(CID_TUPLE, _nd_0);
    if (spin_35(e, _o_0, _a_1, blk_loc(e.mem, _a_1), _b_1, blk_loc(e.mem, _b_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    u32 _o_1 = 0;
    if (term_aux(_v_0) == CID_LT) {
      _o_1 = 0;
    } else if (term_aux(_v_0) == CID_EQ) {
      _o_1 = 1;
    } else {
      _o_1 = 2;
    }
    r0 = _o_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUED_RESERVED_C58)
  {
    u32 _reservation_15 = r0;
    u32 _reservation_16 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _o_1[12];
    if (spin_34(e, _o_1, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_7, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12, _reservation_15, _reservation_16) == 0) {
      return 0;
    }
    _v_54 = _o_1[0];
    _v_55 = _o_1[1];
    _v_56 = _o_1[2];
    _v_57 = _o_1[3];
    _v_58 = _o_1[4];
    _v_59 = _o_1[5];
    _v_60 = _o_1[6];
    _v_61 = _o_1[7];
    _v_62 = _o_1[8];
    _v_63 = _o_1[9];
    _v_64 = _o_1[10];
    _v_65 = _o_1[11];
    u64 _nd_1 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_54);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_55);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_56);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_57);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_58);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_59);
    e.mem[_nd_1 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_1 + 7] = rfc_seal(e, _v_60);
    e.mem[_nd_1 + 8] = rfc_seal(e, _v_61);
    e.mem[_nd_1 + 9] = rfc_seal(e, _v_62);
    e.mem[_nd_1 + 10] = rfc_seal(e, _v_63);
    e.mem[_nd_1 + 11] = rfc_seal(e, _v_64);
    e.mem[_nd_1 + 12] = rfc_seal(e, _v_65);
    r0 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_ACCESS_EQUAL)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _ys_0, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        term_sink(e, _f_0);
        term_sink(e, _f_1);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _xs_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      if (term_aux(_ys_0) == CID_NIL) {
        term_sink(e, _f_2);
        term_sink(e, _f_3);
        spare_free(e, cls_fit(2), _sp_1);
        r0 = 0;
        WL_RETN(1);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _ys_0, 2, _fb_2);
        Term _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        spare_free(e, cls_fit(2), _sp_1);
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_3;
          STK(1) = _f_5;
          STK(2) = FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K64;
          WL_PUSHN(3);
        } else {
          u64 _t_0 = task_node(e, FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K64, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_3;
          e.mem[_t_0 + 1] = _f_5;
          WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K64, _t_0);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
          u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_4;
          return term_tsk(FID_STRING_EQ, _t_1);
        }
        r0 = _f_2;
        r1 = _f_4;
        WL_JMP(FID_STRING_EQ);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K64)
  {
    WL_POPN(2);
    Term _f_6 = STK(0);
    Term _f_7 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K65;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K65, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K65, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_ACCESS_EQUAL)) {
      u64 _t_3 = task_node(e, FID_______SRC_ECS_WORLD_ACCESS_EQUAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_6;
      e.mem[_t_3 + 1] = _f_7;
      return term_tsk(FID_______SRC_ECS_WORLD_ACCESS_EQUAL, _t_3);
    }
    r0 = _f_6;
    r1 = _f_7;
    WL_JMP(FID_______SRC_ECS_WORLD_ACCESS_EQUAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_ACCESS_EQUAL_K65)
  {
    WL_POPN(1);
    u32 _h_2 = STK(0);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_2(e, _o_0, _h_2, _h_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_EQ_K67;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_EQ_K67, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_EQ_K67, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_ORDER)) {
      u64 _t_1 = task_node(e, FID_STRING_ORDER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_ORDER, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_ORDER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ_K67)
  {
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_38(e, _o_0, _h_0) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES)
  {
    u32 _meta_0 = r0;
    Term _meta_1 = r1;
    Term _meta_2 = r2;
    u32 _id_0 = r3;
    Term _name_0 = r4;
    Term _access_0 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _meta_0;
      STK(1) = _meta_2;
      STK(2) = _id_0;
      STK(3) = _access_0;
      STK(4) = FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K74;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K74, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _meta_0;
      e.mem[_t_0 + 1] = _meta_2;
      e.mem[_t_0 + 2] = _id_0;
      e.mem[_t_0 + 3] = _access_0;
      WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K74, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _meta_1;
      e.mem[_t_1 + 1] = _name_0;
      return term_tsk(FID_STRING_EQ, _t_1);
    }
    r0 = _meta_1;
    r1 = _name_0;
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K74)
  {
    WL_POPN(4);
    u32 _meta_3 = STK(0);
    Term _meta_4 = STK(1);
    u32 _id_1 = STK(2);
    Term _access_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _meta_3;
      STK(1) = _id_1;
      STK(2) = _h_0;
      STK(3) = FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K75;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K75, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _meta_3;
      e.mem[_t_2 + 1] = _id_1;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K75, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_ACCESS_EQUAL)) {
      u64 _t_3 = task_node(e, FID_______SRC_ECS_WORLD_ACCESS_EQUAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _meta_4;
      e.mem[_t_3 + 1] = _access_1;
      return term_tsk(FID_______SRC_ECS_WORLD_ACCESS_EQUAL, _t_3);
    }
    r0 = _meta_4;
    r1 = _access_1;
    WL_JMP(FID_______SRC_ECS_WORLD_ACCESS_EQUAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES_K75)
  {
    WL_POPN(3);
    u32 _meta_5 = STK(0);
    u32 _id_2 = STK(1);
    u32 _h_2 = STK(2);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_2(e, _o_0, _h_2, _h_1) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u32 _v_2 = 0;
    Term _o_1[1];
    if (spin_2(e, _o_1, U32_BIN(_meta_5, ==, _id_2), _v_0) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUNNER)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    u32 _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _value_0 = r12;
    WL_OPEN
    if (_value_0 == 2) {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      u32 _v_6 = 0;
      Term _v_7 = 0;
      Term _v_8 = 0;
      Term _v_9 = 0;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      u32 _v_13 = 0;
      u32 _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      Term _v_18 = 0;
      u32 _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      u32 _v_23 = 0;
      u32 _v_24 = 0;
      Term _v_25 = 0;
      Term _o_0[13];
      if (spin_39(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
        return 0;
      }
      _v_13 = _o_0[0];
      _v_14 = _o_0[1];
      _v_15 = _o_0[2];
      _v_16 = _o_0[3];
      _v_17 = _o_0[4];
      _v_18 = _o_0[5];
      _v_19 = _o_0[6];
      _v_20 = _o_0[7];
      _v_21 = _o_0[8];
      _v_22 = _o_0[9];
      _v_23 = _o_0[10];
      _v_24 = _o_0[11];
      _v_25 = _o_0[12];
      _v_0 = _v_13;
      _v_1 = _v_14;
      _v_2 = _v_15;
      _v_3 = _v_16;
      _v_4 = _v_17;
      _v_5 = _v_18;
      _v_6 = _v_19;
      _v_7 = _v_20;
      _v_8 = _v_21;
      _v_9 = _v_22;
      _v_10 = _v_23;
      _v_11 = _v_24;
      _v_12 = _v_25;
      if (seq) {
        WL_ROOM(13);
        STK(0) = _v_0;
        STK(1) = _v_1;
        STK(2) = _v_2;
        STK(3) = _v_3;
        STK(4) = _v_4;
        STK(5) = _v_5;
        STK(6) = _v_6;
        STK(7) = _v_7;
        STK(8) = _v_8;
        STK(9) = _v_9;
        STK(10) = _v_10;
        STK(11) = _v_11;
        STK(12) = FID_RUNNER_K77;
        WL_PUSHN(13);
      } else {
        u64 _t_0 = task_node(e, FID_RUNNER_K77, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _v_0;
        e.mem[_t_0 + 1] = _v_1;
        e.mem[_t_0 + 2] = _v_2;
        e.mem[_t_0 + 3] = _v_3;
        e.mem[_t_0 + 4] = _v_4;
        e.mem[_t_0 + 5] = _v_5;
        e.mem[_t_0 + 6] = _v_6;
        e.mem[_t_0 + 7] = _v_7;
        e.mem[_t_0 + 8] = _v_8;
        e.mem[_t_0 + 9] = _v_9;
        e.mem[_t_0 + 10] = _v_10;
        e.mem[_t_0 + 11] = _v_11;
        WL_CONT = term_tsk(FID_RUNNER_K77, _t_0);
        WL_IDX = 12;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_LENGTH)) {
        u64 _t_1 = task_node(e, FID_LIST_LENGTH, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_12;
        return term_tsk(FID_LIST_LENGTH, _t_1);
      }
      r0 = _v_12;
      WL_JMP(FID_LIST_LENGTH);
    } else if ((_value_0 & 7) == 2) {
      u32 _40_0 = ((_value_0 >> 3) & 1);
      u32 _41_0 = ((_value_0 >> 4) & 1);
      u32 _41_1 = ((_value_0 >> 5) & 1);
      u32 _41_2 = ((_value_0 >> 6) & 1);
      u32 _41_3 = ((_value_0 >> 7) & 1);
      u32 _41_4 = ((_value_0 >> 8) & 1);
      u32 _41_5 = ((_value_0 >> 9) & 1);
      u32 _41_6 = ((_value_0 >> 10) & 1);
      u32 _41_7 = ((_value_0 >> 11) & 1);
      u32 _41_8 = ((_value_0 >> 12) & 1);
      u32 _41_9 = ((_value_0 >> 13) & 1);
      u32 _41_10 = ((_value_0 >> 14) & 1);
      u32 _41_11 = ((_value_0 >> 15) & 1);
      u32 _41_12 = ((_value_0 >> 16) & 1);
      u32 _41_13 = ((_value_0 >> 17) & 1);
      u32 _41_14 = ((_value_0 >> 18) & 1);
      u32 _41_15 = ((_value_0 >> 19) & 1);
      u32 _41_16 = ((_value_0 >> 20) & 1);
      u32 _41_17 = ((_value_0 >> 21) & 1);
      u32 _41_18 = ((_value_0 >> 22) & 1);
      u32 _41_19 = ((_value_0 >> 23) & 1);
      u32 _41_20 = ((_value_0 >> 24) & 1);
      u32 _41_21 = ((_value_0 >> 25) & 1);
      u32 _41_22 = ((_value_0 >> 26) & 1);
      u32 _41_23 = ((_value_0 >> 27) & 1);
      u32 _41_24 = ((_value_0 >> 28) & 1);
      u32 _41_25 = ((_value_0 >> 29) & 1);
      u32 _41_26 = ((_value_0 >> 30) & 1);
      u32 _41_27 = ((_value_0 >> 31) & 1);
      u32 _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      Term _v_89 = 0;
      u32 _v_90 = 0;
      Term _v_91 = 0;
      u32 _v_92 = 0;
      Term _v_93 = 0;
      Term _v_94 = 0;
      Term _v_95 = 0;
      u32 _v_96 = 0;
      u32 _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      u32 _v_102 = 0;
      Term _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      Term _v_106 = 0;
      Term _v_107 = 0;
      u32 _v_108 = 0;
      u32 _v_109 = 0;
      u32 _v_110 = 0;
      u32 _v_111 = 0;
      u32 _v_112 = 0;
      Term _v_113 = 0;
      u32 _v_114 = 0;
      Term _v_115 = 0;
      u32 _v_116 = 0;
      Term _v_117 = 0;
      Term _v_118 = 0;
      Term _v_119 = 0;
      u32 _v_120 = 0;
      u32 _v_121 = 0;
      Term _o_3[12];
      if (spin_37(e, _o_3, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11, (((u64)0 << 0) | ((u64)1 << 1) | ((u64)0 << 2) | ((u64)_40_0 << 3) | ((u64)_41_0 << 4) | ((u64)_41_1 << 5) | ((u64)_41_2 << 6) | ((u64)_41_3 << 7) | ((u64)_41_4 << 8) | ((u64)_41_5 << 9) | ((u64)_41_6 << 10) | ((u64)_41_7 << 11) | ((u64)_41_8 << 12) | ((u64)_41_9 << 13) | ((u64)_41_10 << 14) | ((u64)_41_11 << 15) | ((u64)_41_12 << 16) | ((u64)_41_13 << 17) | ((u64)_41_14 << 18) | ((u64)_41_15 << 19) | ((u64)_41_16 << 20) | ((u64)_41_17 << 21) | ((u64)_41_18 << 22) | ((u64)_41_19 << 23) | ((u64)_41_20 << 24) | ((u64)_41_21 << 25) | ((u64)_41_22 << 26) | ((u64)_41_23 << 27) | ((u64)_41_24 << 28) | ((u64)_41_25 << 29) | ((u64)_41_26 << 30) | ((u64)_41_27 << 31))) == 0) {
        return 0;
      }
      _v_110 = _o_3[0];
      _v_111 = _o_3[1];
      _v_112 = _o_3[2];
      _v_113 = _o_3[3];
      _v_114 = _o_3[4];
      _v_115 = _o_3[5];
      _v_116 = _o_3[6];
      _v_117 = _o_3[7];
      _v_118 = _o_3[8];
      _v_119 = _o_3[9];
      _v_120 = _o_3[10];
      _v_121 = _o_3[11];
      _v_98 = _v_110;
      _v_99 = _v_111;
      _v_100 = _v_112;
      _v_101 = _v_113;
      _v_102 = _v_114;
      _v_103 = _v_115;
      _v_104 = _v_116;
      _v_105 = _v_117;
      _v_106 = _v_118;
      _v_107 = _v_119;
      _v_108 = _v_120;
      _v_109 = _v_121;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, (((u64)0 << 0) | ((u64)1 << 1) | ((u64)0 << 2) | ((u64)_40_0 << 3) | ((u64)_41_0 << 4) | ((u64)_41_1 << 5) | ((u64)_41_2 << 6) | ((u64)_41_3 << 7) | ((u64)_41_4 << 8) | ((u64)_41_5 << 9) | ((u64)_41_6 << 10) | ((u64)_41_7 << 11) | ((u64)_41_8 << 12) | ((u64)_41_9 << 13) | ((u64)_41_10 << 14) | ((u64)_41_11 << 15) | ((u64)_41_12 << 16) | ((u64)_41_13 << 17) | ((u64)_41_14 << 18) | ((u64)_41_15 << 19) | ((u64)_41_16 << 20) | ((u64)_41_17 << 21) | ((u64)_41_18 << 22) | ((u64)_41_19 << 23) | ((u64)_41_20 << 24) | ((u64)_41_21 << 25) | ((u64)_41_22 << 26) | ((u64)_41_23 << 27) | ((u64)_41_24 << 28) | ((u64)_41_25 << 29) | ((u64)_41_26 << 30) | ((u64)_41_27 << 31)));
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_122 = 0;
      u32 _v_123 = 0;
      u32 _v_124 = 0;
      Term _v_125 = 0;
      u32 _v_126 = 0;
      Term _v_127 = 0;
      u32 _v_128 = 0;
      Term _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      u32 _v_132 = 0;
      u32 _v_133 = 0;
      Term _o_4[12];
      Term _a_1 = term_ctr(CID_CON, _nd_0);
      if (spin_10(e, _o_4, _v_98, _v_99, _v_100, _v_101, blk_loc(e.mem, _v_101), _v_102, _v_103, _v_104, _v_105, blk_loc(e.mem, _v_105), _v_106, blk_loc(e.mem, _v_106), _v_107, blk_loc(e.mem, _v_107), _v_108, _v_109, _a_1, blk_loc(e.mem, _a_1)) == 0) {
        return 0;
      }
      _v_122 = _o_4[0];
      _v_123 = _o_4[1];
      _v_124 = _o_4[2];
      _v_125 = _o_4[3];
      _v_126 = _o_4[4];
      _v_127 = _o_4[5];
      _v_128 = _o_4[6];
      _v_129 = _o_4[7];
      _v_130 = _o_4[8];
      _v_131 = _o_4[9];
      _v_132 = _o_4[10];
      _v_133 = _o_4[11];
      _v_86 = _v_122;
      _v_87 = _v_123;
      _v_88 = _v_124;
      _v_89 = _v_125;
      _v_90 = _v_126;
      _v_91 = _v_127;
      _v_92 = _v_128;
      _v_93 = _v_129;
      _v_94 = _v_130;
      _v_95 = _v_131;
      _v_96 = _v_132;
      _v_97 = _v_133;
      r0 = 0;
      r1 = _v_86;
      r2 = _v_87;
      r3 = _v_88;
      r4 = _v_89;
      r5 = _v_90;
      r6 = _v_91;
      r7 = _v_92;
      r8 = _v_93;
      r9 = _v_94;
      r10 = _v_95;
      r11 = _v_96;
      r12 = _v_97;
      r13 = 0;
      WL_RETN(14);
    } else if (_value_0 == 6) {
      u32 _v_134 = 0;
      u32 _v_135 = 0;
      u32 _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      Term _v_139 = 0;
      u32 _v_140 = 0;
      Term _v_141 = 0;
      Term _v_142 = 0;
      Term _v_143 = 0;
      u32 _v_144 = 0;
      u32 _v_145 = 0;
      u32 _v_146 = 0;
      u32 _v_147 = 0;
      u32 _v_148 = 0;
      Term _v_149 = 0;
      u32 _v_150 = 0;
      Term _v_151 = 0;
      u32 _v_152 = 0;
      Term _v_153 = 0;
      Term _v_154 = 0;
      Term _v_155 = 0;
      u32 _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      u32 _v_159 = 0;
      u32 _v_160 = 0;
      Term _v_161 = 0;
      u32 _v_162 = 0;
      Term _v_163 = 0;
      u32 _v_164 = 0;
      Term _v_165 = 0;
      Term _v_166 = 0;
      Term _v_167 = 0;
      u32 _v_168 = 0;
      u32 _v_169 = 0;
      u32 _v_170 = 0;
      u32 _v_171 = 0;
      u32 _v_172 = 0;
      Term _v_173 = 0;
      u32 _v_174 = 0;
      Term _v_175 = 0;
      u32 _v_176 = 0;
      Term _v_177 = 0;
      Term _v_178 = 0;
      Term _v_179 = 0;
      u32 _v_180 = 0;
      u32 _v_181 = 0;
      Term _o_5[12];
      if (spin_37(e, _o_5, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11, 2ull) == 0) {
        return 0;
      }
      _v_170 = _o_5[0];
      _v_171 = _o_5[1];
      _v_172 = _o_5[2];
      _v_173 = _o_5[3];
      _v_174 = _o_5[4];
      _v_175 = _o_5[5];
      _v_176 = _o_5[6];
      _v_177 = _o_5[7];
      _v_178 = _o_5[8];
      _v_179 = _o_5[9];
      _v_180 = _o_5[10];
      _v_181 = _o_5[11];
      _v_158 = _v_170;
      _v_159 = _v_171;
      _v_160 = _v_172;
      _v_161 = _v_173;
      _v_162 = _v_174;
      _v_163 = _v_175;
      _v_164 = _v_176;
      _v_165 = _v_177;
      _v_166 = _v_178;
      _v_167 = _v_179;
      _v_168 = _v_180;
      _v_169 = _v_181;
      u32 _v_182 = 0;
      u32 _v_183 = 0;
      u32 _v_184 = 0;
      Term _v_185 = 0;
      u32 _v_186 = 0;
      Term _v_187 = 0;
      u32 _v_188 = 0;
      Term _v_189 = 0;
      Term _v_190 = 0;
      Term _v_191 = 0;
      u32 _v_192 = 0;
      u32 _v_193 = 0;
      Term _o_6[12];
      Term _a_2 = term_ctr(CID_CON, STAT_OFF + 14);
      if (spin_9(e, _o_6, _v_158, _v_159, _v_160, _v_161, blk_loc(e.mem, _v_161), _v_162, _v_163, _v_164, _v_165, blk_loc(e.mem, _v_165), _v_166, blk_loc(e.mem, _v_166), _v_167, blk_loc(e.mem, _v_167), _v_168, _v_169, _a_2, blk_loc(e.mem, _a_2)) == 0) {
        return 0;
      }
      _v_182 = _o_6[0];
      _v_183 = _o_6[1];
      _v_184 = _o_6[2];
      _v_185 = _o_6[3];
      _v_186 = _o_6[4];
      _v_187 = _o_6[5];
      _v_188 = _o_6[6];
      _v_189 = _o_6[7];
      _v_190 = _o_6[8];
      _v_191 = _o_6[9];
      _v_192 = _o_6[10];
      _v_193 = _o_6[11];
      _v_146 = _v_182;
      _v_147 = _v_183;
      _v_148 = _v_184;
      _v_149 = _v_185;
      _v_150 = _v_186;
      _v_151 = _v_187;
      _v_152 = _v_188;
      _v_153 = _v_189;
      _v_154 = _v_190;
      _v_155 = _v_191;
      _v_156 = _v_192;
      _v_157 = _v_193;
      u32 _v_194 = 0;
      u32 _v_195 = 0;
      u32 _v_196 = 0;
      Term _v_197 = 0;
      u32 _v_198 = 0;
      Term _v_199 = 0;
      u32 _v_200 = 0;
      Term _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      u32 _v_204 = 0;
      u32 _v_205 = 0;
      Term _o_7[12];
      if (spin_44(e, _o_7, _v_146, _v_147, _v_148, _v_149, blk_loc(e.mem, _v_149), _v_150, _v_151, _v_152, _v_153, blk_loc(e.mem, _v_153), _v_154, blk_loc(e.mem, _v_154), _v_155, blk_loc(e.mem, _v_155), _v_156, _v_157) == 0) {
        return 0;
      }
      _v_194 = _o_7[0];
      _v_195 = _o_7[1];
      _v_196 = _o_7[2];
      _v_197 = _o_7[3];
      _v_198 = _o_7[4];
      _v_199 = _o_7[5];
      _v_200 = _o_7[6];
      _v_201 = _o_7[7];
      _v_202 = _o_7[8];
      _v_203 = _o_7[9];
      _v_204 = _o_7[10];
      _v_205 = _o_7[11];
      _v_134 = _v_194;
      _v_135 = _v_195;
      _v_136 = _v_196;
      _v_137 = _v_197;
      _v_138 = _v_198;
      _v_139 = _v_199;
      _v_140 = _v_200;
      _v_141 = _v_201;
      _v_142 = _v_202;
      _v_143 = _v_203;
      _v_144 = _v_204;
      _v_145 = _v_205;
      r0 = 0;
      r1 = _v_134;
      r2 = _v_135;
      r3 = _v_136;
      r4 = _v_137;
      r5 = _v_138;
      r6 = _v_139;
      r7 = _v_140;
      r8 = _v_141;
      r9 = _v_142;
      r10 = _v_143;
      r11 = _v_144;
      r12 = _v_145;
      r13 = 0;
      WL_RETN(14);
    } else if ((_value_0 & 7) == 6) {
      u32 _98_0 = ((_value_0 >> 3) & 1);
      u32 _99_0 = ((_value_0 >> 4) & 1);
      u32 _99_1 = ((_value_0 >> 5) & 1);
      u32 _99_2 = ((_value_0 >> 6) & 1);
      u32 _99_3 = ((_value_0 >> 7) & 1);
      u32 _99_4 = ((_value_0 >> 8) & 1);
      u32 _99_5 = ((_value_0 >> 9) & 1);
      u32 _99_6 = ((_value_0 >> 10) & 1);
      u32 _99_7 = ((_value_0 >> 11) & 1);
      u32 _99_8 = ((_value_0 >> 12) & 1);
      u32 _99_9 = ((_value_0 >> 13) & 1);
      u32 _99_10 = ((_value_0 >> 14) & 1);
      u32 _99_11 = ((_value_0 >> 15) & 1);
      u32 _99_12 = ((_value_0 >> 16) & 1);
      u32 _99_13 = ((_value_0 >> 17) & 1);
      u32 _99_14 = ((_value_0 >> 18) & 1);
      u32 _99_15 = ((_value_0 >> 19) & 1);
      u32 _99_16 = ((_value_0 >> 20) & 1);
      u32 _99_17 = ((_value_0 >> 21) & 1);
      u32 _99_18 = ((_value_0 >> 22) & 1);
      u32 _99_19 = ((_value_0 >> 23) & 1);
      u32 _99_20 = ((_value_0 >> 24) & 1);
      u32 _99_21 = ((_value_0 >> 25) & 1);
      u32 _99_22 = ((_value_0 >> 26) & 1);
      u32 _99_23 = ((_value_0 >> 27) & 1);
      u32 _99_24 = ((_value_0 >> 28) & 1);
      u32 _99_25 = ((_value_0 >> 29) & 1);
      u32 _99_26 = ((_value_0 >> 30) & 1);
      u32 _99_27 = ((_value_0 >> 31) & 1);
      u32 _v_206 = 0;
      u32 _v_207 = 0;
      u32 _v_208 = 0;
      Term _v_209 = 0;
      u32 _v_210 = 0;
      Term _v_211 = 0;
      u32 _v_212 = 0;
      Term _v_213 = 0;
      Term _v_214 = 0;
      Term _v_215 = 0;
      u32 _v_216 = 0;
      u32 _v_217 = 0;
      u32 _v_218 = 0;
      u32 _v_219 = 0;
      u32 _v_220 = 0;
      Term _v_221 = 0;
      u32 _v_222 = 0;
      Term _v_223 = 0;
      u32 _v_224 = 0;
      Term _v_225 = 0;
      Term _v_226 = 0;
      Term _v_227 = 0;
      u32 _v_228 = 0;
      u32 _v_229 = 0;
      u32 _v_230 = 0;
      u32 _v_231 = 0;
      u32 _v_232 = 0;
      Term _v_233 = 0;
      u32 _v_234 = 0;
      Term _v_235 = 0;
      u32 _v_236 = 0;
      Term _v_237 = 0;
      Term _v_238 = 0;
      Term _v_239 = 0;
      u32 _v_240 = 0;
      u32 _v_241 = 0;
      Term _o_8[12];
      if (spin_37(e, _o_8, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11, (((u64)0 << 0) | ((u64)1 << 1) | ((u64)1 << 2) | ((u64)_98_0 << 3) | ((u64)_99_0 << 4) | ((u64)_99_1 << 5) | ((u64)_99_2 << 6) | ((u64)_99_3 << 7) | ((u64)_99_4 << 8) | ((u64)_99_5 << 9) | ((u64)_99_6 << 10) | ((u64)_99_7 << 11) | ((u64)_99_8 << 12) | ((u64)_99_9 << 13) | ((u64)_99_10 << 14) | ((u64)_99_11 << 15) | ((u64)_99_12 << 16) | ((u64)_99_13 << 17) | ((u64)_99_14 << 18) | ((u64)_99_15 << 19) | ((u64)_99_16 << 20) | ((u64)_99_17 << 21) | ((u64)_99_18 << 22) | ((u64)_99_19 << 23) | ((u64)_99_20 << 24) | ((u64)_99_21 << 25) | ((u64)_99_22 << 26) | ((u64)_99_23 << 27) | ((u64)_99_24 << 28) | ((u64)_99_25 << 29) | ((u64)_99_26 << 30) | ((u64)_99_27 << 31))) == 0) {
        return 0;
      }
      _v_230 = _o_8[0];
      _v_231 = _o_8[1];
      _v_232 = _o_8[2];
      _v_233 = _o_8[3];
      _v_234 = _o_8[4];
      _v_235 = _o_8[5];
      _v_236 = _o_8[6];
      _v_237 = _o_8[7];
      _v_238 = _o_8[8];
      _v_239 = _o_8[9];
      _v_240 = _o_8[10];
      _v_241 = _o_8[11];
      _v_218 = _v_230;
      _v_219 = _v_231;
      _v_220 = _v_232;
      _v_221 = _v_233;
      _v_222 = _v_234;
      _v_223 = _v_235;
      _v_224 = _v_236;
      _v_225 = _v_237;
      _v_226 = _v_238;
      _v_227 = _v_239;
      _v_228 = _v_240;
      _v_229 = _v_241;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, (((u64)0 << 0) | ((u64)1 << 1) | ((u64)1 << 2) | ((u64)_98_0 << 3) | ((u64)_99_0 << 4) | ((u64)_99_1 << 5) | ((u64)_99_2 << 6) | ((u64)_99_3 << 7) | ((u64)_99_4 << 8) | ((u64)_99_5 << 9) | ((u64)_99_6 << 10) | ((u64)_99_7 << 11) | ((u64)_99_8 << 12) | ((u64)_99_9 << 13) | ((u64)_99_10 << 14) | ((u64)_99_11 << 15) | ((u64)_99_12 << 16) | ((u64)_99_13 << 17) | ((u64)_99_14 << 18) | ((u64)_99_15 << 19) | ((u64)_99_16 << 20) | ((u64)_99_17 << 21) | ((u64)_99_18 << 22) | ((u64)_99_19 << 23) | ((u64)_99_20 << 24) | ((u64)_99_21 << 25) | ((u64)_99_22 << 26) | ((u64)_99_23 << 27) | ((u64)_99_24 << 28) | ((u64)_99_25 << 29) | ((u64)_99_26 << 30) | ((u64)_99_27 << 31)));
      e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_242 = 0;
      u32 _v_243 = 0;
      u32 _v_244 = 0;
      Term _v_245 = 0;
      u32 _v_246 = 0;
      Term _v_247 = 0;
      u32 _v_248 = 0;
      Term _v_249 = 0;
      Term _v_250 = 0;
      Term _v_251 = 0;
      u32 _v_252 = 0;
      u32 _v_253 = 0;
      Term _o_9[12];
      Term _a_3 = term_ctr(CID_CON, _nd_1);
      if (spin_10(e, _o_9, _v_218, _v_219, _v_220, _v_221, blk_loc(e.mem, _v_221), _v_222, _v_223, _v_224, _v_225, blk_loc(e.mem, _v_225), _v_226, blk_loc(e.mem, _v_226), _v_227, blk_loc(e.mem, _v_227), _v_228, _v_229, _a_3, blk_loc(e.mem, _a_3)) == 0) {
        return 0;
      }
      _v_242 = _o_9[0];
      _v_243 = _o_9[1];
      _v_244 = _o_9[2];
      _v_245 = _o_9[3];
      _v_246 = _o_9[4];
      _v_247 = _o_9[5];
      _v_248 = _o_9[6];
      _v_249 = _o_9[7];
      _v_250 = _o_9[8];
      _v_251 = _o_9[9];
      _v_252 = _o_9[10];
      _v_253 = _o_9[11];
      _v_206 = _v_242;
      _v_207 = _v_243;
      _v_208 = _v_244;
      _v_209 = _v_245;
      _v_210 = _v_246;
      _v_211 = _v_247;
      _v_212 = _v_248;
      _v_213 = _v_249;
      _v_214 = _v_250;
      _v_215 = _v_251;
      _v_216 = _v_252;
      _v_217 = _v_253;
      r0 = 0;
      r1 = _v_206;
      r2 = _v_207;
      r3 = _v_208;
      r4 = _v_209;
      r5 = _v_210;
      r6 = _v_211;
      r7 = _v_212;
      r8 = _v_213;
      r9 = _v_214;
      r10 = _v_215;
      r11 = _v_216;
      r12 = _v_217;
      r13 = 0;
      WL_RETN(14);
    } else if (_value_0 == 8) {
      u32 _v_254 = 0;
      u32 _v_255 = 0;
      u32 _v_256 = 0;
      Term _v_257 = 0;
      u32 _v_258 = 0;
      Term _v_259 = 0;
      u32 _v_260 = 0;
      Term _v_261 = 0;
      Term _v_262 = 0;
      Term _v_263 = 0;
      u32 _v_264 = 0;
      u32 _v_265 = 0;
      u32 _v_266 = 0;
      u32 _v_267 = 0;
      u32 _v_268 = 0;
      Term _v_269 = 0;
      u32 _v_270 = 0;
      Term _v_271 = 0;
      u32 _v_272 = 0;
      Term _v_273 = 0;
      Term _v_274 = 0;
      Term _v_275 = 0;
      u32 _v_276 = 0;
      u32 _v_277 = 0;
      Term _o_10[12];
      if (spin_44(e, _o_10, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
        return 0;
      }
      _v_266 = _o_10[0];
      _v_267 = _o_10[1];
      _v_268 = _o_10[2];
      _v_269 = _o_10[3];
      _v_270 = _o_10[4];
      _v_271 = _o_10[5];
      _v_272 = _o_10[6];
      _v_273 = _o_10[7];
      _v_274 = _o_10[8];
      _v_275 = _o_10[9];
      _v_276 = _o_10[10];
      _v_277 = _o_10[11];
      _v_254 = _v_266;
      _v_255 = _v_267;
      _v_256 = _v_268;
      _v_257 = _v_269;
      _v_258 = _v_270;
      _v_259 = _v_271;
      _v_260 = _v_272;
      _v_261 = _v_273;
      _v_262 = _v_274;
      _v_263 = _v_275;
      _v_264 = _v_276;
      _v_265 = _v_277;
      r0 = 0;
      r1 = _v_254;
      r2 = _v_255;
      r3 = _v_256;
      r4 = _v_257;
      r5 = _v_258;
      r6 = _v_259;
      r7 = _v_260;
      r8 = _v_261;
      r9 = _v_262;
      r10 = _v_263;
      r11 = _v_264;
      r12 = _v_265;
      r13 = 0;
      WL_RETN(14);
    } else if ((_value_0 & 3) == 0) {
      u32 _156_0 = ((_value_0 >> 2) & 1);
      u32 _157_0 = ((_value_0 >> 3) & 1);
      u32 _157_1 = ((_value_0 >> 4) & 1);
      u32 _157_2 = ((_value_0 >> 5) & 1);
      u32 _157_3 = ((_value_0 >> 6) & 1);
      u32 _157_4 = ((_value_0 >> 7) & 1);
      u32 _157_5 = ((_value_0 >> 8) & 1);
      u32 _157_6 = ((_value_0 >> 9) & 1);
      u32 _157_7 = ((_value_0 >> 10) & 1);
      u32 _157_8 = ((_value_0 >> 11) & 1);
      u32 _157_9 = ((_value_0 >> 12) & 1);
      u32 _157_10 = ((_value_0 >> 13) & 1);
      u32 _157_11 = ((_value_0 >> 14) & 1);
      u32 _157_12 = ((_value_0 >> 15) & 1);
      u32 _157_13 = ((_value_0 >> 16) & 1);
      u32 _157_14 = ((_value_0 >> 17) & 1);
      u32 _157_15 = ((_value_0 >> 18) & 1);
      u32 _157_16 = ((_value_0 >> 19) & 1);
      u32 _157_17 = ((_value_0 >> 20) & 1);
      u32 _157_18 = ((_value_0 >> 21) & 1);
      u32 _157_19 = ((_value_0 >> 22) & 1);
      u32 _157_20 = ((_value_0 >> 23) & 1);
      u32 _157_21 = ((_value_0 >> 24) & 1);
      u32 _157_22 = ((_value_0 >> 25) & 1);
      u32 _157_23 = ((_value_0 >> 26) & 1);
      u32 _157_24 = ((_value_0 >> 27) & 1);
      u32 _157_25 = ((_value_0 >> 28) & 1);
      u32 _157_26 = ((_value_0 >> 29) & 1);
      u32 _157_27 = ((_value_0 >> 30) & 1);
      u32 _157_28 = ((_value_0 >> 31) & 1);
      u32 _v_278 = 0;
      u32 _v_279 = 0;
      u32 _v_280 = 0;
      Term _v_281 = 0;
      u32 _v_282 = 0;
      Term _v_283 = 0;
      u32 _v_284 = 0;
      Term _v_285 = 0;
      Term _v_286 = 0;
      Term _v_287 = 0;
      u32 _v_288 = 0;
      u32 _v_289 = 0;
      u32 _v_290 = 0;
      u32 _v_291 = 0;
      u32 _v_292 = 0;
      Term _v_293 = 0;
      u32 _v_294 = 0;
      Term _v_295 = 0;
      u32 _v_296 = 0;
      Term _v_297 = 0;
      Term _v_298 = 0;
      Term _v_299 = 0;
      u32 _v_300 = 0;
      u32 _v_301 = 0;
      u32 _v_302 = 0;
      u32 _v_303 = 0;
      u32 _v_304 = 0;
      Term _v_305 = 0;
      u32 _v_306 = 0;
      Term _v_307 = 0;
      u32 _v_308 = 0;
      Term _v_309 = 0;
      Term _v_310 = 0;
      Term _v_311 = 0;
      u32 _v_312 = 0;
      u32 _v_313 = 0;
      Term _o_11[12];
      if (spin_37(e, _o_11, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11, (((u64)0 << 0) | ((u64)0 << 1) | ((u64)_156_0 << 2) | ((u64)_157_0 << 3) | ((u64)_157_1 << 4) | ((u64)_157_2 << 5) | ((u64)_157_3 << 6) | ((u64)_157_4 << 7) | ((u64)_157_5 << 8) | ((u64)_157_6 << 9) | ((u64)_157_7 << 10) | ((u64)_157_8 << 11) | ((u64)_157_9 << 12) | ((u64)_157_10 << 13) | ((u64)_157_11 << 14) | ((u64)_157_12 << 15) | ((u64)_157_13 << 16) | ((u64)_157_14 << 17) | ((u64)_157_15 << 18) | ((u64)_157_16 << 19) | ((u64)_157_17 << 20) | ((u64)_157_18 << 21) | ((u64)_157_19 << 22) | ((u64)_157_20 << 23) | ((u64)_157_21 << 24) | ((u64)_157_22 << 25) | ((u64)_157_23 << 26) | ((u64)_157_24 << 27) | ((u64)_157_25 << 28) | ((u64)_157_26 << 29) | ((u64)_157_27 << 30) | ((u64)_157_28 << 31))) == 0) {
        return 0;
      }
      _v_302 = _o_11[0];
      _v_303 = _o_11[1];
      _v_304 = _o_11[2];
      _v_305 = _o_11[3];
      _v_306 = _o_11[4];
      _v_307 = _o_11[5];
      _v_308 = _o_11[6];
      _v_309 = _o_11[7];
      _v_310 = _o_11[8];
      _v_311 = _o_11[9];
      _v_312 = _o_11[10];
      _v_313 = _o_11[11];
      _v_290 = _v_302;
      _v_291 = _v_303;
      _v_292 = _v_304;
      _v_293 = _v_305;
      _v_294 = _v_306;
      _v_295 = _v_307;
      _v_296 = _v_308;
      _v_297 = _v_309;
      _v_298 = _v_310;
      _v_299 = _v_311;
      _v_300 = _v_312;
      _v_301 = _v_313;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, (((u64)0 << 0) | ((u64)0 << 1) | ((u64)_156_0 << 2) | ((u64)_157_0 << 3) | ((u64)_157_1 << 4) | ((u64)_157_2 << 5) | ((u64)_157_3 << 6) | ((u64)_157_4 << 7) | ((u64)_157_5 << 8) | ((u64)_157_6 << 9) | ((u64)_157_7 << 10) | ((u64)_157_8 << 11) | ((u64)_157_9 << 12) | ((u64)_157_10 << 13) | ((u64)_157_11 << 14) | ((u64)_157_12 << 15) | ((u64)_157_13 << 16) | ((u64)_157_14 << 17) | ((u64)_157_15 << 18) | ((u64)_157_16 << 19) | ((u64)_157_17 << 20) | ((u64)_157_18 << 21) | ((u64)_157_19 << 22) | ((u64)_157_20 << 23) | ((u64)_157_21 << 24) | ((u64)_157_22 << 25) | ((u64)_157_23 << 26) | ((u64)_157_24 << 27) | ((u64)_157_25 << 28) | ((u64)_157_26 << 29) | ((u64)_157_27 << 30) | ((u64)_157_28 << 31)));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_314 = 0;
      u32 _v_315 = 0;
      u32 _v_316 = 0;
      Term _v_317 = 0;
      u32 _v_318 = 0;
      Term _v_319 = 0;
      u32 _v_320 = 0;
      Term _v_321 = 0;
      Term _v_322 = 0;
      Term _v_323 = 0;
      u32 _v_324 = 0;
      u32 _v_325 = 0;
      Term _o_12[12];
      Term _a_4 = term_ctr(CID_CON, _nd_2);
      if (spin_10(e, _o_12, _v_290, _v_291, _v_292, _v_293, blk_loc(e.mem, _v_293), _v_294, _v_295, _v_296, _v_297, blk_loc(e.mem, _v_297), _v_298, blk_loc(e.mem, _v_298), _v_299, blk_loc(e.mem, _v_299), _v_300, _v_301, _a_4, blk_loc(e.mem, _a_4)) == 0) {
        return 0;
      }
      _v_314 = _o_12[0];
      _v_315 = _o_12[1];
      _v_316 = _o_12[2];
      _v_317 = _o_12[3];
      _v_318 = _o_12[4];
      _v_319 = _o_12[5];
      _v_320 = _o_12[6];
      _v_321 = _o_12[7];
      _v_322 = _o_12[8];
      _v_323 = _o_12[9];
      _v_324 = _o_12[10];
      _v_325 = _o_12[11];
      _v_278 = _v_314;
      _v_279 = _v_315;
      _v_280 = _v_316;
      _v_281 = _v_317;
      _v_282 = _v_318;
      _v_283 = _v_319;
      _v_284 = _v_320;
      _v_285 = _v_321;
      _v_286 = _v_322;
      _v_287 = _v_323;
      _v_288 = _v_324;
      _v_289 = _v_325;
      r0 = 0;
      r1 = _v_278;
      r2 = _v_279;
      r3 = _v_280;
      r4 = _v_281;
      r5 = _v_282;
      r6 = _v_283;
      r7 = _v_284;
      r8 = _v_285;
      r9 = _v_286;
      r10 = _v_287;
      r11 = _v_288;
      r12 = _v_289;
      r13 = 0;
      WL_RETN(14);
    } else if (_value_0 == 7) {
      u32 _v_326 = 0;
      u32 _v_327 = 0;
      u32 _v_328 = 0;
      Term _v_329 = 0;
      u32 _v_330 = 0;
      Term _v_331 = 0;
      u32 _v_332 = 0;
      Term _v_333 = 0;
      Term _v_334 = 0;
      Term _v_335 = 0;
      u32 _v_336 = 0;
      u32 _v_337 = 0;
      u32 _v_338 = 0;
      u32 _v_339 = 0;
      u32 _v_340 = 0;
      u32 _v_341 = 0;
      u32 _v_342 = 0;
      u32 _v_343 = 0;
      Term _v_344 = 0;
      u32 _v_345 = 0;
      Term _v_346 = 0;
      u32 _v_347 = 0;
      Term _v_348 = 0;
      Term _v_349 = 0;
      Term _v_350 = 0;
      u32 _v_351 = 0;
      u32 _v_352 = 0;
      u32 _v_353 = 0;
      u32 _v_354 = 0;
      u32 _v_355 = 0;
      Term _o_13[15];
      if (spin_19(e, _o_13, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
        return 0;
      }
      _v_341 = _o_13[0];
      _v_342 = _o_13[1];
      _v_343 = _o_13[2];
      _v_344 = _o_13[3];
      _v_345 = _o_13[4];
      _v_346 = _o_13[5];
      _v_347 = _o_13[6];
      _v_348 = _o_13[7];
      _v_349 = _o_13[8];
      _v_350 = _o_13[9];
      _v_351 = _o_13[10];
      _v_352 = _o_13[11];
      _v_353 = _o_13[12];
      _v_354 = _o_13[13];
      _v_355 = _o_13[14];
      _v_326 = _v_341;
      _v_327 = _v_342;
      _v_328 = _v_343;
      _v_329 = _v_344;
      _v_330 = _v_345;
      _v_331 = _v_346;
      _v_332 = _v_347;
      _v_333 = _v_348;
      _v_334 = _v_349;
      _v_335 = _v_350;
      _v_336 = _v_351;
      _v_337 = _v_352;
      _v_338 = _v_353;
      _v_339 = _v_354;
      _v_340 = _v_355;
      u32 _v_356 = 0;
      u32 _v_357 = 0;
      u32 _v_358 = 0;
      Term _v_359 = 0;
      u32 _v_360 = 0;
      Term _v_361 = 0;
      u32 _v_362 = 0;
      Term _v_363 = 0;
      Term _v_364 = 0;
      Term _v_365 = 0;
      u32 _v_366 = 0;
      u32 _v_367 = 0;
      u32 _v_368 = 0;
      u32 _v_369 = 0;
      u32 _v_370 = 0;
      u32 _v_371 = 0;
      Term _v_372 = 0;
      u32 _v_373 = 0;
      Term _v_374 = 0;
      u32 _v_375 = 0;
      Term _v_376 = 0;
      Term _v_377 = 0;
      Term _v_378 = 0;
      u32 _v_379 = 0;
      u32 _v_380 = 0;
      u32 _v_381 = 0;
      Term _o_14[13];
      if (spin_24(e, _o_14, _v_326, _v_327, _v_328, _v_329, blk_loc(e.mem, _v_329), _v_330, _v_331, _v_332, _v_333, blk_loc(e.mem, _v_333), _v_334, blk_loc(e.mem, _v_334), _v_335, blk_loc(e.mem, _v_335), _v_336, _v_337, 777ull) == 0) {
        return 0;
      }
      _v_369 = _o_14[0];
      _v_370 = _o_14[1];
      _v_371 = _o_14[2];
      _v_372 = _o_14[3];
      _v_373 = _o_14[4];
      _v_374 = _o_14[5];
      _v_375 = _o_14[6];
      _v_376 = _o_14[7];
      _v_377 = _o_14[8];
      _v_378 = _o_14[9];
      _v_379 = _o_14[10];
      _v_380 = _o_14[11];
      _v_381 = _o_14[12];
      _v_356 = _v_369;
      _v_357 = _v_370;
      _v_358 = _v_371;
      _v_359 = _v_372;
      _v_360 = _v_373;
      _v_361 = _v_374;
      _v_362 = _v_375;
      _v_363 = _v_376;
      _v_364 = _v_377;
      _v_365 = _v_378;
      _v_366 = _v_379;
      _v_367 = _v_380;
      _v_368 = _v_381;
      u32 _v_382 = 0;
      u32 _v_383 = 0;
      u32 _v_384 = 0;
      Term _v_385 = 0;
      u32 _v_386 = 0;
      Term _v_387 = 0;
      u32 _v_388 = 0;
      Term _v_389 = 0;
      Term _v_390 = 0;
      Term _v_391 = 0;
      u32 _v_392 = 0;
      u32 _v_393 = 0;
      Term _v_394 = 0;
      Term _v_395 = 0;
      Term _v_396 = 0;
      u32 _v_397 = 0;
      u32 _v_398 = 0;
      u32 _v_399 = 0;
      Term _v_400 = 0;
      u32 _v_401 = 0;
      Term _v_402 = 0;
      u32 _v_403 = 0;
      Term _v_404 = 0;
      Term _v_405 = 0;
      Term _v_406 = 0;
      u32 _v_407 = 0;
      u32 _v_408 = 0;
      Term _v_409 = 0;
      Term _v_410 = 0;
      Term _v_411 = 0;
      u32 _v_412 = 0;
      u32 _v_413 = 0;
      u32 _v_414 = 0;
      Term _v_415 = 0;
      u32 _v_416 = 0;
      Term _v_417 = 0;
      u32 _v_418 = 0;
      Term _v_419 = 0;
      Term _v_420 = 0;
      Term _v_421 = 0;
      u32 _v_422 = 0;
      u32 _v_423 = 0;
      Term _v_424 = 0;
      Term _v_425 = 0;
      Term _v_426 = 0;
      Term _o_15[15];
      if (spin_27(e, _o_15, _v_356, _v_357, _v_358, _v_359, blk_loc(e.mem, _v_359), _v_360, _v_361, _v_362, _v_363, blk_loc(e.mem, _v_363), _v_364, blk_loc(e.mem, _v_364), _v_365, blk_loc(e.mem, _v_365), _v_366, _v_367) == 0) {
        return 0;
      }
      _v_412 = _o_15[0];
      _v_413 = _o_15[1];
      _v_414 = _o_15[2];
      _v_415 = _o_15[3];
      _v_416 = _o_15[4];
      _v_417 = _o_15[5];
      _v_418 = _o_15[6];
      _v_419 = _o_15[7];
      _v_420 = _o_15[8];
      _v_421 = _o_15[9];
      _v_422 = _o_15[10];
      _v_423 = _o_15[11];
      _v_424 = _o_15[12];
      _v_425 = _o_15[13];
      _v_426 = _o_15[14];
      _v_397 = _v_412;
      _v_398 = _v_413;
      _v_399 = _v_414;
      _v_400 = _v_415;
      _v_401 = _v_416;
      _v_402 = _v_417;
      _v_403 = _v_418;
      _v_404 = _v_419;
      _v_405 = _v_420;
      _v_406 = _v_421;
      _v_407 = _v_422;
      _v_408 = _v_423;
      _v_409 = _v_424;
      _v_410 = _v_425;
      _v_411 = _v_426;
      u64 _nd_3 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_3 + 0] = _v_368;
      u32 _v_440 = 0;
      u32 _v_441 = 0;
      u32 _v_442 = 0;
      Term _v_443 = 0;
      u32 _v_444 = 0;
      Term _v_445 = 0;
      u32 _v_446 = 0;
      Term _v_447 = 0;
      Term _v_448 = 0;
      Term _v_449 = 0;
      u32 _v_450 = 0;
      u32 _v_451 = 0;
      Term _v_452 = 0;
      Term _v_453 = 0;
      Term _v_454 = 0;
      Term _o_17[15];
      Term _a_5 = term_clo(FID_RUNNER_C78, _nd_3);
      if (spin_29(e, _o_17, _v_397, _v_398, _v_399, _v_400, blk_loc(e.mem, _v_400), _v_401, _v_402, _v_403, _v_404, blk_loc(e.mem, _v_404), _v_405, blk_loc(e.mem, _v_405), _v_406, blk_loc(e.mem, _v_406), _v_407, _v_408, _v_409, blk_loc(e.mem, _v_409), _v_410, blk_loc(e.mem, _v_410), _v_411, blk_loc(e.mem, _v_411), _a_5, blk_loc(e.mem, _a_5)) == 0) {
        return 0;
      }
      _v_440 = _o_17[0];
      _v_441 = _o_17[1];
      _v_442 = _o_17[2];
      _v_443 = _o_17[3];
      _v_444 = _o_17[4];
      _v_445 = _o_17[5];
      _v_446 = _o_17[6];
      _v_447 = _o_17[7];
      _v_448 = _o_17[8];
      _v_449 = _o_17[9];
      _v_450 = _o_17[10];
      _v_451 = _o_17[11];
      _v_452 = _o_17[12];
      _v_453 = _o_17[13];
      _v_454 = _o_17[14];
      _v_382 = _v_440;
      _v_383 = _v_441;
      _v_384 = _v_442;
      _v_385 = _v_443;
      _v_386 = _v_444;
      _v_387 = _v_445;
      _v_388 = _v_446;
      _v_389 = _v_447;
      _v_390 = _v_448;
      _v_391 = _v_449;
      _v_392 = _v_450;
      _v_393 = _v_451;
      _v_394 = _v_452;
      _v_395 = _v_453;
      _v_396 = _v_454;
      u32 _v_455 = 0;
      u32 _v_456 = 0;
      u32 _v_457 = 0;
      Term _v_458 = 0;
      u32 _v_459 = 0;
      Term _v_460 = 0;
      u32 _v_461 = 0;
      Term _v_462 = 0;
      Term _v_463 = 0;
      Term _v_464 = 0;
      u32 _v_465 = 0;
      u32 _v_466 = 0;
      Term _v_467 = 0;
      Term _v_468 = 0;
      Term _v_469 = 0;
      u32 _v_470 = 0;
      u32 _v_471 = 0;
      u32 _v_472 = 0;
      Term _v_473 = 0;
      u32 _v_474 = 0;
      Term _v_475 = 0;
      u32 _v_476 = 0;
      Term _v_477 = 0;
      Term _v_478 = 0;
      Term _v_479 = 0;
      u32 _v_480 = 0;
      u32 _v_481 = 0;
      Term _v_482 = 0;
      Term _v_483 = 0;
      Term _v_484 = 0;
      u32 _v_485 = 0;
      u32 _v_486 = 0;
      u32 _v_487 = 0;
      Term _v_488 = 0;
      u32 _v_489 = 0;
      Term _v_490 = 0;
      u32 _v_491 = 0;
      Term _v_492 = 0;
      Term _v_493 = 0;
      Term _v_494 = 0;
      u32 _v_495 = 0;
      u32 _v_496 = 0;
      Term _v_497 = 0;
      Term _v_498 = 0;
      Term _v_499 = 0;
      Term _o_18[15];
      if (spin_30(e, _o_18, _v_382, _v_383, _v_384, _v_385, blk_loc(e.mem, _v_385), _v_386, _v_387, _v_388, _v_389, blk_loc(e.mem, _v_389), _v_390, blk_loc(e.mem, _v_390), _v_391, blk_loc(e.mem, _v_391), _v_392, _v_393, _v_394, blk_loc(e.mem, _v_394), _v_395, blk_loc(e.mem, _v_395), _v_396, blk_loc(e.mem, _v_396), 7ull) == 0) {
        return 0;
      }
      _v_485 = _o_18[0];
      _v_486 = _o_18[1];
      _v_487 = _o_18[2];
      _v_488 = _o_18[3];
      _v_489 = _o_18[4];
      _v_490 = _o_18[5];
      _v_491 = _o_18[6];
      _v_492 = _o_18[7];
      _v_493 = _o_18[8];
      _v_494 = _o_18[9];
      _v_495 = _o_18[10];
      _v_496 = _o_18[11];
      _v_497 = _o_18[12];
      _v_498 = _o_18[13];
      _v_499 = _o_18[14];
      _v_470 = _v_485;
      _v_471 = _v_486;
      _v_472 = _v_487;
      _v_473 = _v_488;
      _v_474 = _v_489;
      _v_475 = _v_490;
      _v_476 = _v_491;
      _v_477 = _v_492;
      _v_478 = _v_493;
      _v_479 = _v_494;
      _v_480 = _v_495;
      _v_481 = _v_496;
      _v_482 = _v_497;
      _v_483 = _v_498;
      _v_484 = _v_499;
      u32 _v_512 = 0;
      u32 _v_513 = 0;
      u32 _v_514 = 0;
      Term _v_515 = 0;
      u32 _v_516 = 0;
      Term _v_517 = 0;
      u32 _v_518 = 0;
      Term _v_519 = 0;
      Term _v_520 = 0;
      Term _v_521 = 0;
      u32 _v_522 = 0;
      u32 _v_523 = 0;
      Term _v_524 = 0;
      Term _v_525 = 0;
      Term _v_526 = 0;
      Term _o_20[15];
      Term _a_6 = term_clo(FID_RUNNER_C79, 0);
      if (spin_32(e, _o_20, _v_470, _v_471, _v_472, _v_473, blk_loc(e.mem, _v_473), _v_474, _v_475, _v_476, _v_477, blk_loc(e.mem, _v_477), _v_478, blk_loc(e.mem, _v_478), _v_479, blk_loc(e.mem, _v_479), _v_480, _v_481, _v_482, blk_loc(e.mem, _v_482), _v_483, blk_loc(e.mem, _v_483), _v_484, blk_loc(e.mem, _v_484), _a_6, blk_loc(e.mem, _a_6)) == 0) {
        return 0;
      }
      _v_512 = _o_20[0];
      _v_513 = _o_20[1];
      _v_514 = _o_20[2];
      _v_515 = _o_20[3];
      _v_516 = _o_20[4];
      _v_517 = _o_20[5];
      _v_518 = _o_20[6];
      _v_519 = _o_20[7];
      _v_520 = _o_20[8];
      _v_521 = _o_20[9];
      _v_522 = _o_20[10];
      _v_523 = _o_20[11];
      _v_524 = _o_20[12];
      _v_525 = _o_20[13];
      _v_526 = _o_20[14];
      _v_455 = _v_512;
      _v_456 = _v_513;
      _v_457 = _v_514;
      _v_458 = _v_515;
      _v_459 = _v_516;
      _v_460 = _v_517;
      _v_461 = _v_518;
      _v_462 = _v_519;
      _v_463 = _v_520;
      _v_464 = _v_521;
      _v_465 = _v_522;
      _v_466 = _v_523;
      _v_467 = _v_524;
      _v_468 = _v_525;
      _v_469 = _v_526;
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_RUNNER_K80;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID_RUNNER_K80, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_RUNNER_K80, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_TRANSACTION_FINISH_0)) {
        u64 _t_3 = task_node(e, FID_______SRC_ECS_TRANSACTION_FINISH_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _v_455;
        e.mem[_t_3 + 1] = _v_456;
        e.mem[_t_3 + 2] = _v_457;
        e.mem[_t_3 + 3] = _v_458;
        e.mem[_t_3 + 4] = _v_459;
        e.mem[_t_3 + 5] = _v_460;
        e.mem[_t_3 + 6] = _v_461;
        e.mem[_t_3 + 7] = _v_462;
        e.mem[_t_3 + 8] = _v_463;
        e.mem[_t_3 + 9] = _v_464;
        e.mem[_t_3 + 10] = _v_465;
        e.mem[_t_3 + 11] = _v_466;
        e.mem[_t_3 + 12] = _v_467;
        e.mem[_t_3 + 13] = _v_468;
        e.mem[_t_3 + 14] = _v_469;
        e.mem[_t_3 + 15] = 1;
        e.mem[_t_3 + 16] = term_ctr(CID_SCON, STAT_OFF + 12);
        return term_tsk(FID_______SRC_ECS_TRANSACTION_FINISH_0, _t_3);
      }
      r0 = _v_455;
      r1 = _v_456;
      r2 = _v_457;
      r3 = _v_458;
      r4 = _v_459;
      r5 = _v_460;
      r6 = _v_461;
      r7 = _v_462;
      r8 = _v_463;
      r9 = _v_464;
      r10 = _v_465;
      r11 = _v_466;
      r12 = _v_467;
      r13 = _v_468;
      r14 = _v_469;
      r15 = 1;
      r16 = term_ctr(CID_SCON, STAT_OFF + 12);
      WL_JMP(FID_______SRC_ECS_TRANSACTION_FINISH_0);
    } else {
      u32 _216_0 = ((_value_0 >> 1) & 1);
      u32 _217_0 = ((_value_0 >> 2) & 1);
      u32 _217_1 = ((_value_0 >> 3) & 1);
      u32 _217_2 = ((_value_0 >> 4) & 1);
      u32 _217_3 = ((_value_0 >> 5) & 1);
      u32 _217_4 = ((_value_0 >> 6) & 1);
      u32 _217_5 = ((_value_0 >> 7) & 1);
      u32 _217_6 = ((_value_0 >> 8) & 1);
      u32 _217_7 = ((_value_0 >> 9) & 1);
      u32 _217_8 = ((_value_0 >> 10) & 1);
      u32 _217_9 = ((_value_0 >> 11) & 1);
      u32 _217_10 = ((_value_0 >> 12) & 1);
      u32 _217_11 = ((_value_0 >> 13) & 1);
      u32 _217_12 = ((_value_0 >> 14) & 1);
      u32 _217_13 = ((_value_0 >> 15) & 1);
      u32 _217_14 = ((_value_0 >> 16) & 1);
      u32 _217_15 = ((_value_0 >> 17) & 1);
      u32 _217_16 = ((_value_0 >> 18) & 1);
      u32 _217_17 = ((_value_0 >> 19) & 1);
      u32 _217_18 = ((_value_0 >> 20) & 1);
      u32 _217_19 = ((_value_0 >> 21) & 1);
      u32 _217_20 = ((_value_0 >> 22) & 1);
      u32 _217_21 = ((_value_0 >> 23) & 1);
      u32 _217_22 = ((_value_0 >> 24) & 1);
      u32 _217_23 = ((_value_0 >> 25) & 1);
      u32 _217_24 = ((_value_0 >> 26) & 1);
      u32 _217_25 = ((_value_0 >> 27) & 1);
      u32 _217_26 = ((_value_0 >> 28) & 1);
      u32 _217_27 = ((_value_0 >> 29) & 1);
      u32 _217_28 = ((_value_0 >> 30) & 1);
      u32 _217_29 = ((_value_0 >> 31) & 1);
      u32 _v_541 = 0;
      u32 _v_542 = 0;
      u32 _v_543 = 0;
      Term _v_544 = 0;
      u32 _v_545 = 0;
      Term _v_546 = 0;
      u32 _v_547 = 0;
      Term _v_548 = 0;
      Term _v_549 = 0;
      Term _v_550 = 0;
      u32 _v_551 = 0;
      u32 _v_552 = 0;
      u32 _v_553 = 0;
      u32 _v_554 = 0;
      u32 _v_555 = 0;
      Term _v_556 = 0;
      u32 _v_557 = 0;
      Term _v_558 = 0;
      u32 _v_559 = 0;
      Term _v_560 = 0;
      Term _v_561 = 0;
      Term _v_562 = 0;
      u32 _v_563 = 0;
      u32 _v_564 = 0;
      u32 _v_565 = 0;
      u32 _v_566 = 0;
      u32 _v_567 = 0;
      Term _v_568 = 0;
      u32 _v_569 = 0;
      Term _v_570 = 0;
      u32 _v_571 = 0;
      Term _v_572 = 0;
      Term _v_573 = 0;
      Term _v_574 = 0;
      u32 _v_575 = 0;
      u32 _v_576 = 0;
      Term _o_22[12];
      if (spin_37(e, _o_22, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11, (((u64)1 << 0) | ((u64)_216_0 << 1) | ((u64)_217_0 << 2) | ((u64)_217_1 << 3) | ((u64)_217_2 << 4) | ((u64)_217_3 << 5) | ((u64)_217_4 << 6) | ((u64)_217_5 << 7) | ((u64)_217_6 << 8) | ((u64)_217_7 << 9) | ((u64)_217_8 << 10) | ((u64)_217_9 << 11) | ((u64)_217_10 << 12) | ((u64)_217_11 << 13) | ((u64)_217_12 << 14) | ((u64)_217_13 << 15) | ((u64)_217_14 << 16) | ((u64)_217_15 << 17) | ((u64)_217_16 << 18) | ((u64)_217_17 << 19) | ((u64)_217_18 << 20) | ((u64)_217_19 << 21) | ((u64)_217_20 << 22) | ((u64)_217_21 << 23) | ((u64)_217_22 << 24) | ((u64)_217_23 << 25) | ((u64)_217_24 << 26) | ((u64)_217_25 << 27) | ((u64)_217_26 << 28) | ((u64)_217_27 << 29) | ((u64)_217_28 << 30) | ((u64)_217_29 << 31))) == 0) {
        return 0;
      }
      _v_565 = _o_22[0];
      _v_566 = _o_22[1];
      _v_567 = _o_22[2];
      _v_568 = _o_22[3];
      _v_569 = _o_22[4];
      _v_570 = _o_22[5];
      _v_571 = _o_22[6];
      _v_572 = _o_22[7];
      _v_573 = _o_22[8];
      _v_574 = _o_22[9];
      _v_575 = _o_22[10];
      _v_576 = _o_22[11];
      _v_553 = _v_565;
      _v_554 = _v_566;
      _v_555 = _v_567;
      _v_556 = _v_568;
      _v_557 = _v_569;
      _v_558 = _v_570;
      _v_559 = _v_571;
      _v_560 = _v_572;
      _v_561 = _v_573;
      _v_562 = _v_574;
      _v_563 = _v_575;
      _v_564 = _v_576;
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, (((u64)1 << 0) | ((u64)_216_0 << 1) | ((u64)_217_0 << 2) | ((u64)_217_1 << 3) | ((u64)_217_2 << 4) | ((u64)_217_3 << 5) | ((u64)_217_4 << 6) | ((u64)_217_5 << 7) | ((u64)_217_6 << 8) | ((u64)_217_7 << 9) | ((u64)_217_8 << 10) | ((u64)_217_9 << 11) | ((u64)_217_10 << 12) | ((u64)_217_11 << 13) | ((u64)_217_12 << 14) | ((u64)_217_13 << 15) | ((u64)_217_14 << 16) | ((u64)_217_15 << 17) | ((u64)_217_16 << 18) | ((u64)_217_17 << 19) | ((u64)_217_18 << 20) | ((u64)_217_19 << 21) | ((u64)_217_20 << 22) | ((u64)_217_21 << 23) | ((u64)_217_22 << 24) | ((u64)_217_23 << 25) | ((u64)_217_24 << 26) | ((u64)_217_25 << 27) | ((u64)_217_26 << 28) | ((u64)_217_27 << 29) | ((u64)_217_28 << 30) | ((u64)_217_29 << 31)));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_577 = 0;
      u32 _v_578 = 0;
      u32 _v_579 = 0;
      Term _v_580 = 0;
      u32 _v_581 = 0;
      Term _v_582 = 0;
      u32 _v_583 = 0;
      Term _v_584 = 0;
      Term _v_585 = 0;
      Term _v_586 = 0;
      u32 _v_587 = 0;
      u32 _v_588 = 0;
      Term _o_23[12];
      Term _a_7 = term_ctr(CID_CON, _nd_6);
      if (spin_10(e, _o_23, _v_553, _v_554, _v_555, _v_556, blk_loc(e.mem, _v_556), _v_557, _v_558, _v_559, _v_560, blk_loc(e.mem, _v_560), _v_561, blk_loc(e.mem, _v_561), _v_562, blk_loc(e.mem, _v_562), _v_563, _v_564, _a_7, blk_loc(e.mem, _a_7)) == 0) {
        return 0;
      }
      _v_577 = _o_23[0];
      _v_578 = _o_23[1];
      _v_579 = _o_23[2];
      _v_580 = _o_23[3];
      _v_581 = _o_23[4];
      _v_582 = _o_23[5];
      _v_583 = _o_23[6];
      _v_584 = _o_23[7];
      _v_585 = _o_23[8];
      _v_586 = _o_23[9];
      _v_587 = _o_23[10];
      _v_588 = _o_23[11];
      _v_541 = _v_577;
      _v_542 = _v_578;
      _v_543 = _v_579;
      _v_544 = _v_580;
      _v_545 = _v_581;
      _v_546 = _v_582;
      _v_547 = _v_583;
      _v_548 = _v_584;
      _v_549 = _v_585;
      _v_550 = _v_586;
      _v_551 = _v_587;
      _v_552 = _v_588;
      r0 = 0;
      r1 = _v_541;
      r2 = _v_542;
      r3 = _v_543;
      r4 = _v_544;
      r5 = _v_545;
      r6 = _v_546;
      r7 = _v_547;
      r8 = _v_548;
      r9 = _v_549;
      r10 = _v_550;
      r11 = _v_551;
      r12 = _v_552;
      r13 = 0;
      WL_RETN(14);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUNNER_K77)
  {
    WL_POPN(12);
    u32 _v_26 = STK(0);
    u32 _v_27 = STK(1);
    u32 _v_28 = STK(2);
    Term _v_29 = STK(3);
    u32 _v_30 = STK(4);
    Term _v_31 = STK(5);
    u32 _v_32 = STK(6);
    Term _v_33 = STK(7);
    Term _v_34 = STK(8);
    Term _v_35 = STK(9);
    u32 _v_36 = STK(10);
    u32 _v_37 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    u32 _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    Term _o_1[12];
    if (spin_37(e, _o_1, _v_26, _v_27, _v_28, _v_29, blk_loc(e.mem, _v_29), _v_30, _v_31, _v_32, _v_33, blk_loc(e.mem, _v_33), _v_34, blk_loc(e.mem, _v_34), _v_35, blk_loc(e.mem, _v_35), _v_36, _v_37, U32_BIN(2ull, +, ((u64)(u32)(_h_0)))) == 0) {
      return 0;
    }
    _v_50 = _o_1[0];
    _v_51 = _o_1[1];
    _v_52 = _o_1[2];
    _v_53 = _o_1[3];
    _v_54 = _o_1[4];
    _v_55 = _o_1[5];
    _v_56 = _o_1[6];
    _v_57 = _o_1[7];
    _v_58 = _o_1[8];
    _v_59 = _o_1[9];
    _v_60 = _o_1[10];
    _v_61 = _o_1[11];
    _v_38 = _v_50;
    _v_39 = _v_51;
    _v_40 = _v_52;
    _v_41 = _v_53;
    _v_42 = _v_54;
    _v_43 = _v_55;
    _v_44 = _v_56;
    _v_45 = _v_57;
    _v_46 = _v_58;
    _v_47 = _v_59;
    _v_48 = _v_60;
    _v_49 = _v_61;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    u32 _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    Term _o_2[12];
    Term _a_0 = term_ctr(CID_CON, STAT_OFF + 14);
    if (spin_11(e, _o_2, _v_38, _v_39, _v_40, _v_41, blk_loc(e.mem, _v_41), _v_42, _v_43, _v_44, _v_45, blk_loc(e.mem, _v_45), _v_46, blk_loc(e.mem, _v_46), _v_47, blk_loc(e.mem, _v_47), _v_48, _v_49, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_74 = _o_2[0];
    _v_75 = _o_2[1];
    _v_76 = _o_2[2];
    _v_77 = _o_2[3];
    _v_78 = _o_2[4];
    _v_79 = _o_2[5];
    _v_80 = _o_2[6];
    _v_81 = _o_2[7];
    _v_82 = _o_2[8];
    _v_83 = _o_2[9];
    _v_84 = _o_2[10];
    _v_85 = _o_2[11];
    _v_62 = _v_74;
    _v_63 = _v_75;
    _v_64 = _v_76;
    _v_65 = _v_77;
    _v_66 = _v_78;
    _v_67 = _v_79;
    _v_68 = _v_80;
    _v_69 = _v_81;
    _v_70 = _v_82;
    _v_71 = _v_83;
    _v_72 = _v_84;
    _v_73 = _v_85;
    r0 = 0;
    r1 = _v_62;
    r2 = _v_63;
    r3 = _v_64;
    r4 = _v_65;
    r5 = _v_66;
    r6 = _v_67;
    r7 = _v_68;
    r8 = _v_69;
    r9 = _v_70;
    r10 = _v_71;
    r11 = _v_72;
    r12 = _v_73;
    r13 = 0;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUNNER_C78)
  {
    u32 _v_427 = r0;
    Term _x_0 = r1;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    u32 _v_428 = 0;
    u32 _v_429 = 0;
    u32 _v_430 = 0;
    Term _v_431 = 0;
    u32 _v_432 = 0;
    Term _v_433 = 0;
    u32 _v_434 = 0;
    Term _v_435 = 0;
    Term _v_436 = 0;
    Term _v_437 = 0;
    u32 _v_438 = 0;
    u32 _v_439 = 0;
    Term _o_16[12];
    if (spin_28(e, _o_16, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_7, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12, _v_427) == 0) {
      return 0;
    }
    _v_428 = _o_16[0];
    _v_429 = _o_16[1];
    _v_430 = _o_16[2];
    _v_431 = _o_16[3];
    _v_432 = _o_16[4];
    _v_433 = _o_16[5];
    _v_434 = _o_16[6];
    _v_435 = _o_16[7];
    _v_436 = _o_16[8];
    _v_437 = _o_16[9];
    _v_438 = _o_16[10];
    _v_439 = _o_16[11];
    u64 _nd_4 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_4 + 0] = rfc_seal(e, _v_428);
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_429);
    e.mem[_nd_4 + 2] = rfc_seal(e, _v_430);
    e.mem[_nd_4 + 3] = rfc_seal(e, _v_431);
    e.mem[_nd_4 + 4] = rfc_seal(e, _v_432);
    e.mem[_nd_4 + 5] = rfc_seal(e, _v_433);
    e.mem[_nd_4 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_4 + 7] = rfc_seal(e, _v_434);
    e.mem[_nd_4 + 8] = rfc_seal(e, _v_435);
    e.mem[_nd_4 + 9] = rfc_seal(e, _v_436);
    e.mem[_nd_4 + 10] = rfc_seal(e, _v_437);
    e.mem[_nd_4 + 11] = rfc_seal(e, _v_438);
    e.mem[_nd_4 + 12] = rfc_seal(e, _v_439);
    r0 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUNNER_C79)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_1[13];
    u64 _sp_1 = ctr_take(e, _x_1, 13, _fb_1);
    u32 _f_13 = _fb_1[0];
    u32 _f_14 = _fb_1[1];
    u32 _f_15 = _fb_1[2];
    Term _f_16 = _fb_1[3];
    u32 _f_17 = _fb_1[4];
    Term _f_18 = _fb_1[5];
    Term _f_19 = _fb_1[6];
    Term _f_20 = _fb_1[7];
    Term _f_21 = _fb_1[8];
    Term _f_22 = _fb_1[9];
    Term _f_23 = _fb_1[10];
    u32 _f_24 = _fb_1[11];
    u32 _f_25 = _fb_1[12];
    spare_free(e, cls_fit(13), _sp_1);
    u32 _v_500 = 0;
    u32 _v_501 = 0;
    u32 _v_502 = 0;
    Term _v_503 = 0;
    u32 _v_504 = 0;
    Term _v_505 = 0;
    u32 _v_506 = 0;
    Term _v_507 = 0;
    Term _v_508 = 0;
    Term _v_509 = 0;
    u32 _v_510 = 0;
    u32 _v_511 = 0;
    Term _o_19[12];
    if (spin_31(e, _o_19, _f_13, _f_14, _f_15, _f_16, blk_loc(e.mem, _f_16), _f_17, _f_18, _f_20, _f_21, blk_loc(e.mem, _f_21), _f_22, blk_loc(e.mem, _f_22), _f_23, blk_loc(e.mem, _f_23), _f_24, _f_25) == 0) {
      return 0;
    }
    _v_500 = _o_19[0];
    _v_501 = _o_19[1];
    _v_502 = _o_19[2];
    _v_503 = _o_19[3];
    _v_504 = _o_19[4];
    _v_505 = _o_19[5];
    _v_506 = _o_19[6];
    _v_507 = _o_19[7];
    _v_508 = _o_19[8];
    _v_509 = _o_19[9];
    _v_510 = _o_19[10];
    _v_511 = _o_19[11];
    u64 _nd_5 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_5 + 0] = rfc_seal(e, _v_500);
    e.mem[_nd_5 + 1] = rfc_seal(e, _v_501);
    e.mem[_nd_5 + 2] = rfc_seal(e, _v_502);
    e.mem[_nd_5 + 3] = rfc_seal(e, _v_503);
    e.mem[_nd_5 + 4] = rfc_seal(e, _v_504);
    e.mem[_nd_5 + 5] = rfc_seal(e, _v_505);
    e.mem[_nd_5 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_5 + 7] = rfc_seal(e, _v_506);
    e.mem[_nd_5 + 8] = rfc_seal(e, _v_507);
    e.mem[_nd_5 + 9] = rfc_seal(e, _v_508);
    e.mem[_nd_5 + 10] = rfc_seal(e, _v_509);
    e.mem[_nd_5 + 11] = rfc_seal(e, _v_510);
    e.mem[_nd_5 + 12] = rfc_seal(e, _v_511);
    r0 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RUNNER_K80)
  {
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    u32 _h_3 = r2;
    Term _h_4 = r3;
    u32 _h_5 = r4;
    Term _h_6 = r5;
    u32 _h_7 = r6;
    Term _h_8 = r7;
    Term _h_9 = r8;
    Term _h_10 = r9;
    u32 _h_11 = r10;
    u32 _h_12 = r11;
    u32 _h_13 = r12;
    Term _h_14 = r13;
    WL_OPEN
    u32 _v_527 = 0;
    u32 _v_528 = 0;
    u32 _v_529 = 0;
    u32 _v_530 = 0;
    Term _v_531 = 0;
    u32 _v_532 = 0;
    Term _v_533 = 0;
    u32 _v_534 = 0;
    Term _v_535 = 0;
    Term _v_536 = 0;
    Term _v_537 = 0;
    u32 _v_538 = 0;
    u32 _v_539 = 0;
    Term _v_540 = 0;
    Term _o_21[14];
    if (spin_33(e, _o_21, _h_1, _h_2, _h_3, _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, _h_13, _h_14, blk_loc(e.mem, _h_14)) == 0) {
      return 0;
    }
    _v_527 = _o_21[0];
    _v_528 = _o_21[1];
    _v_529 = _o_21[2];
    _v_530 = _o_21[3];
    _v_531 = _o_21[4];
    _v_532 = _o_21[5];
    _v_533 = _o_21[6];
    _v_534 = _o_21[7];
    _v_535 = _o_21[8];
    _v_536 = _o_21[9];
    _v_537 = _o_21[10];
    _v_538 = _o_21[11];
    _v_539 = _o_21[12];
    _v_540 = _o_21[13];
    r0 = _v_527;
    r1 = _v_528;
    r2 = _v_529;
    r3 = _v_530;
    r4 = _v_531;
    r5 = _v_532;
    r6 = _v_533;
    r7 = _v_534;
    r8 = _v_535;
    r9 = _v_536;
    r10 = _v_537;
    r11 = _v_538;
    r12 = _v_539;
    r13 = _v_540;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    WL_OPEN
    if (term_aux(_registrations_0) == CID_NIL) {
      term_sink(e, _name_0);
      term_sink(e, _access_0);
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _registrations_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      _name_0 = term_keep(e, _name_0, 1);
      _access_0 = term_keep(e, _access_0, 1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _f_1;
        STK(1) = _id_0;
        STK(2) = _name_0;
        STK(3) = _access_0;
        STK(4) = FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K83;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K83, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _id_0;
        e.mem[_t_0 + 2] = _name_0;
        e.mem[_t_0 + 3] = _access_0;
        WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K83, _t_0);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES)) {
        u64 _t_1 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _id_0;
        e.mem[_t_1 + 4] = _name_0;
        e.mem[_t_1 + 5] = _access_0;
        return term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _id_0;
      r4 = _name_0;
      r5 = _access_0;
      WL_JMP(FID_______SRC_ECS_WORLD_REGISTRATION_META_MATCHES);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K83)
  {
    WL_POPN(4);
    Term _f_5 = STK(0);
    u32 _id_1 = STK(1);
    Term _name_1 = STK(2);
    Term _access_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K84;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K84, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K84, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
      u64 _t_3 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      e.mem[_t_3 + 1] = _id_1;
      e.mem[_t_3 + 2] = _name_1;
      e.mem[_t_3 + 3] = _access_1;
      return term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_3);
    }
    r0 = _f_5;
    r1 = _id_1;
    r2 = _name_1;
    r3 = _access_1;
    WL_JMP(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES_K84)
  {
    WL_POPN(1);
    u32 _h_2 = STK(0);
    u32 _h_1 = r0;
    WL_OPEN
    r0 = ((_h_2) | (_h_1));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    u32 _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _id_0 = r12;
    Term _name_0 = r13;
    Term _access_0 = r14;
    WL_OPEN
    _world_9 = term_keep(e, _world_9, 1);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _world_11;
      STK(12) = FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K88;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K88, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K88, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
      u64 _t_1 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_9;
      e.mem[_t_1 + 1] = _id_0;
      e.mem[_t_1 + 2] = _name_0;
      e.mem[_t_1 + 3] = _access_0;
      return term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_1);
    }
    r0 = _world_9;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    WL_JMP(FID_______SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K88)
  {
    WL_POPN(12);
    u32 _world_12 = STK(0);
    u32 _world_13 = STK(1);
    u32 _world_14 = STK(2);
    Term _world_15 = STK(3);
    u32 _world_16 = STK(4);
    Term _world_17 = STK(5);
    u32 _world_18 = STK(6);
    Term _world_19 = STK(7);
    Term _world_20 = STK(8);
    Term _world_21 = STK(9);
    u32 _world_22 = STK(10);
    u32 _world_23 = STK(11);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = _world_12;
    r1 = _world_13;
    r2 = _world_14;
    r3 = _world_15;
    r4 = _world_16;
    r5 = _world_17;
    r6 = _world_18;
    r7 = _world_19;
    r8 = _world_20;
    r9 = _world_21;
    r10 = _world_22;
    r11 = _world_23;
    r12 = _h_0;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SYSTEM_RUN_0)
  {
    u32 _registry_0 = r0;
    u32 _registry_1 = r1;
    Term _registry_2 = r2;
    Term _registry_3 = r3;
    u32 _registry_4 = r4;
    u32 _world_0 = r5;
    u32 _world_1 = r6;
    u32 _world_2 = r7;
    Term _world_3 = r8;
    u32 _world_4 = r9;
    Term _world_5 = r10;
    u32 _world_6 = r11;
    Term _world_7 = r12;
    Term _world_8 = r13;
    Term _world_9 = r14;
    u32 _world_10 = r15;
    u32 _world_11 = r16;
    u32 _args_0 = r17;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _o_0[13];
    if (spin_49(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_14 = _o_0[1];
    _v_15 = _o_0[2];
    _v_16 = _o_0[3];
    _v_17 = _o_0[4];
    _v_18 = _o_0[5];
    _v_19 = _o_0[6];
    _v_20 = _o_0[7];
    _v_21 = _o_0[8];
    _v_22 = _o_0[9];
    _v_23 = _o_0[10];
    _v_24 = _o_0[11];
    _v_25 = _o_0[12];
    _v_0 = _v_13;
    _v_1 = _v_14;
    _v_2 = _v_15;
    _v_3 = _v_16;
    _v_4 = _v_17;
    _v_5 = _v_18;
    _v_6 = _v_19;
    _v_7 = _v_20;
    _v_8 = _v_21;
    _v_9 = _v_22;
    _v_10 = _v_23;
    _v_11 = _v_24;
    _v_12 = _v_25;
    u32 _s_0 = U32_BIN(_registry_0, ==, _v_12);
    if (_s_0 == 0) {
      r0 = 1;
      r1 = _registry_0;
      r2 = _registry_1;
      r3 = _registry_2;
      r4 = _registry_3;
      r5 = _registry_4;
      r6 = _v_0;
      r7 = _v_1;
      r8 = _v_2;
      r9 = _v_3;
      r10 = _v_4;
      r11 = _v_5;
      r12 = _v_6;
      r13 = _v_7;
      r14 = _v_8;
      r15 = _v_9;
      r16 = _v_10;
      r17 = _v_11;
      r18 = _args_0;
      r19 = 0;
      WL_RETN(20);
    } else {
      _registry_2 = term_keep(e, _registry_2, 1);
      _registry_3 = term_keep(e, _registry_3, 1);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _registry_0;
        STK(1) = _registry_1;
        STK(2) = _registry_2;
        STK(3) = _registry_3;
        STK(4) = _registry_4;
        STK(5) = _args_0;
        STK(6) = FID_______SRC_ECS_SYSTEM_RUN_0_K106;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_SYSTEM_RUN_0_K106, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _registry_0;
        e.mem[_t_0 + 1] = _registry_1;
        e.mem[_t_0 + 2] = _registry_2;
        e.mem[_t_0 + 3] = _registry_3;
        e.mem[_t_0 + 4] = _registry_4;
        e.mem[_t_0 + 5] = _args_0;
        WL_CONT = term_tsk(FID_______SRC_ECS_SYSTEM_RUN_0_K106, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0)) {
        u64 _t_1 = task_node(e, FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _v_5;
        e.mem[_t_1 + 6] = _v_6;
        e.mem[_t_1 + 7] = _v_7;
        e.mem[_t_1 + 8] = _v_8;
        e.mem[_t_1 + 9] = _v_9;
        e.mem[_t_1 + 10] = _v_10;
        e.mem[_t_1 + 11] = _v_11;
        e.mem[_t_1 + 12] = _registry_1;
        e.mem[_t_1 + 13] = _registry_2;
        e.mem[_t_1 + 14] = _registry_3;
        return term_tsk(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _registry_1;
      r13 = _registry_2;
      r14 = _registry_3;
      WL_JMP(FID_______SRC_ECS_WORLD_REGISTRATION_MATCHES_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SYSTEM_RUN_0_K106)
  {
    WL_POPN(6);
    u32 _registry_5 = STK(0);
    u32 _registry_6 = STK(1);
    Term _registry_7 = STK(2);
    Term _registry_8 = STK(3);
    u32 _registry_9 = STK(4);
    u32 _args_1 = STK(5);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    WL_OPEN
    if (_h_12 == 0) {
      r0 = 1;
      r1 = _registry_5;
      r2 = _registry_6;
      r3 = _registry_7;
      r4 = _registry_8;
      r5 = _registry_9;
      r6 = _h_0;
      r7 = _h_1;
      r8 = _h_2;
      r9 = _h_3;
      r10 = _h_4;
      r11 = _h_5;
      r12 = _h_6;
      r13 = _h_7;
      r14 = _h_8;
      r15 = _h_9;
      r16 = _h_10;
      r17 = _h_11;
      r18 = _args_1;
      r19 = 0;
      WL_RETN(20);
    } else {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _registry_5;
        STK(1) = _registry_6;
        STK(2) = _registry_7;
        STK(3) = _registry_8;
        STK(4) = _registry_9;
        STK(5) = FID_______SRC_ECS_SYSTEM_RUN_0_K107;
        WL_PUSHN(6);
      } else {
        u64 _t_2 = task_node(e, FID_______SRC_ECS_SYSTEM_RUN_0_K107, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _registry_5;
        e.mem[_t_2 + 1] = _registry_6;
        e.mem[_t_2 + 2] = _registry_7;
        e.mem[_t_2 + 3] = _registry_8;
        e.mem[_t_2 + 4] = _registry_9;
        WL_CONT = term_tsk(FID_______SRC_ECS_SYSTEM_RUN_0_K107, _t_2);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_RUNNER)) {
        u64 _t_3 = task_node(e, FID_RUNNER, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_0;
        e.mem[_t_3 + 1] = _h_1;
        e.mem[_t_3 + 2] = _h_2;
        e.mem[_t_3 + 3] = _h_3;
        e.mem[_t_3 + 4] = _h_4;
        e.mem[_t_3 + 5] = _h_5;
        e.mem[_t_3 + 6] = _h_6;
        e.mem[_t_3 + 7] = _h_7;
        e.mem[_t_3 + 8] = _h_8;
        e.mem[_t_3 + 9] = _h_9;
        e.mem[_t_3 + 10] = _h_10;
        e.mem[_t_3 + 11] = _h_11;
        e.mem[_t_3 + 12] = _args_1;
        return term_tsk(FID_RUNNER, _t_3);
      }
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      r5 = _h_5;
      r6 = _h_6;
      r7 = _h_7;
      r8 = _h_8;
      r9 = _h_9;
      r10 = _h_10;
      r11 = _h_11;
      r12 = _args_1;
      WL_JMP(FID_RUNNER);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SYSTEM_RUN_0_K107)
  {
    WL_POPN(5);
    u32 _registry_10 = STK(0);
    u32 _registry_11 = STK(1);
    Term _registry_12 = STK(2);
    Term _registry_13 = STK(3);
    u32 _registry_14 = STK(4);
    u32 _h_13 = r0;
    u32 _h_14 = r1;
    u32 _h_15 = r2;
    u32 _h_16 = r3;
    Term _h_17 = r4;
    u32 _h_18 = r5;
    Term _h_19 = r6;
    u32 _h_20 = r7;
    Term _h_21 = r8;
    Term _h_22 = r9;
    Term _h_23 = r10;
    u32 _h_24 = r11;
    u32 _h_25 = r12;
    Term _h_26 = r13;
    WL_OPEN
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _o_1[20];
    if (spin_45(e, _o_1, _registry_10, _registry_11, _registry_12, blk_loc(e.mem, _registry_12), _registry_13, blk_loc(e.mem, _registry_13), _registry_14, _h_13, _h_14, _h_15, _h_16, _h_17, blk_loc(e.mem, _h_17), _h_18, _h_19, _h_20, _h_21, blk_loc(e.mem, _h_21), _h_22, blk_loc(e.mem, _h_22), _h_23, blk_loc(e.mem, _h_23), _h_24, _h_25, _h_26, blk_loc(e.mem, _h_26)) == 0) {
      return 0;
    }
    _v_39 = _o_1[0];
    _v_40 = _o_1[1];
    _v_41 = _o_1[2];
    _v_42 = _o_1[3];
    _v_43 = _o_1[4];
    _v_44 = _o_1[5];
    _v_45 = _o_1[6];
    _v_46 = _o_1[7];
    _v_47 = _o_1[8];
    _v_48 = _o_1[9];
    _v_49 = _o_1[10];
    _v_50 = _o_1[11];
    _v_51 = _o_1[12];
    _v_52 = _o_1[13];
    _v_53 = _o_1[14];
    _v_54 = _o_1[15];
    _v_55 = _o_1[16];
    _v_56 = _o_1[17];
    _v_57 = _o_1[18];
    _v_58 = _o_1[19];
    r0 = _v_39;
    r1 = _v_40;
    r2 = _v_41;
    r3 = _v_42;
    r4 = _v_43;
    r5 = _v_44;
    r6 = _v_45;
    r7 = _v_46;
    r8 = _v_47;
    r9 = _v_48;
    r10 = _v_49;
    r11 = _v_50;
    r12 = _v_51;
    r13 = _v_52;
    r14 = _v_53;
    r15 = _v_54;
    r16 = _v_55;
    r17 = _v_56;
    r18 = _v_57;
    r19 = _v_58;
    WL_RETN(20);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DISPATCH_FAIL)
  {
    u32 _owners_0 = r0;
    u32 _owners_1 = r1;
    Term _owners_2 = r2;
    Term _owners_3 = r3;
    u32 _owners_4 = r4;
    u32 _owners_5 = r5;
    u32 _owners_6 = r6;
    Term _owners_7 = r7;
    Term _owners_8 = r8;
    u32 _owners_9 = r9;
    u32 _world_0 = r10;
    u32 _world_1 = r11;
    u32 _world_2 = r12;
    Term _world_3 = r13;
    u32 _world_4 = r14;
    Term _world_5 = r15;
    u32 _world_6 = r16;
    Term _world_7 = r17;
    Term _world_8 = r18;
    Term _world_9 = r19;
    u32 _world_10 = r20;
    u32 _world_11 = r21;
    u32 _id_0 = r22;
    WL_OPEN
    if (_id_0 == 1) {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _owners_5;
        STK(1) = _owners_6;
        STK(2) = _owners_7;
        STK(3) = _owners_8;
        STK(4) = _owners_9;
        STK(5) = FID_DISPATCH_FAIL_K124;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_DISPATCH_FAIL_K124, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _owners_5;
        e.mem[_t_0 + 1] = _owners_6;
        e.mem[_t_0 + 2] = _owners_7;
        e.mem[_t_0 + 3] = _owners_8;
        e.mem[_t_0 + 4] = _owners_9;
        WL_CONT = term_tsk(FID_DISPATCH_FAIL_K124, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SYSTEM_RUN_0)) {
        u64 _t_1 = task_node(e, FID_______SRC_ECS_SYSTEM_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owners_0;
        e.mem[_t_1 + 1] = _owners_1;
        e.mem[_t_1 + 2] = _owners_2;
        e.mem[_t_1 + 3] = _owners_3;
        e.mem[_t_1 + 4] = _owners_4;
        e.mem[_t_1 + 5] = _world_0;
        e.mem[_t_1 + 6] = _world_1;
        e.mem[_t_1 + 7] = _world_2;
        e.mem[_t_1 + 8] = _world_3;
        e.mem[_t_1 + 9] = _world_4;
        e.mem[_t_1 + 10] = _world_5;
        e.mem[_t_1 + 11] = _world_6;
        e.mem[_t_1 + 12] = _world_7;
        e.mem[_t_1 + 13] = _world_8;
        e.mem[_t_1 + 14] = _world_9;
        e.mem[_t_1 + 15] = _world_10;
        e.mem[_t_1 + 16] = _world_11;
        e.mem[_t_1 + 17] = 6ull;
        return term_tsk(FID_______SRC_ECS_SYSTEM_RUN_0, _t_1);
      }
      r0 = _owners_0;
      r1 = _owners_1;
      r2 = _owners_2;
      r3 = _owners_3;
      r4 = _owners_4;
      r5 = _world_0;
      r6 = _world_1;
      r7 = _world_2;
      r8 = _world_3;
      r9 = _world_4;
      r10 = _world_5;
      r11 = _world_6;
      r12 = _world_7;
      r13 = _world_8;
      r14 = _world_9;
      r15 = _world_10;
      r16 = _world_11;
      r17 = 6ull;
      WL_JMP(FID_______SRC_ECS_SYSTEM_RUN_0);
    } else if ((_id_0 & 1) == 1) {
      u32 _48_0 = ((_id_0 >> 1) & 1);
      u32 _49_0 = ((_id_0 >> 2) & 1);
      u32 _49_1 = ((_id_0 >> 3) & 1);
      u32 _49_2 = ((_id_0 >> 4) & 1);
      u32 _49_3 = ((_id_0 >> 5) & 1);
      u32 _49_4 = ((_id_0 >> 6) & 1);
      u32 _49_5 = ((_id_0 >> 7) & 1);
      u32 _49_6 = ((_id_0 >> 8) & 1);
      u32 _49_7 = ((_id_0 >> 9) & 1);
      u32 _49_8 = ((_id_0 >> 10) & 1);
      u32 _49_9 = ((_id_0 >> 11) & 1);
      u32 _49_10 = ((_id_0 >> 12) & 1);
      u32 _49_11 = ((_id_0 >> 13) & 1);
      u32 _49_12 = ((_id_0 >> 14) & 1);
      u32 _49_13 = ((_id_0 >> 15) & 1);
      u32 _49_14 = ((_id_0 >> 16) & 1);
      u32 _49_15 = ((_id_0 >> 17) & 1);
      u32 _49_16 = ((_id_0 >> 18) & 1);
      u32 _49_17 = ((_id_0 >> 19) & 1);
      u32 _49_18 = ((_id_0 >> 20) & 1);
      u32 _49_19 = ((_id_0 >> 21) & 1);
      u32 _49_20 = ((_id_0 >> 22) & 1);
      u32 _49_21 = ((_id_0 >> 23) & 1);
      u32 _49_22 = ((_id_0 >> 24) & 1);
      u32 _49_23 = ((_id_0 >> 25) & 1);
      u32 _49_24 = ((_id_0 >> 26) & 1);
      u32 _49_25 = ((_id_0 >> 27) & 1);
      u32 _49_26 = ((_id_0 >> 28) & 1);
      u32 _49_27 = ((_id_0 >> 29) & 1);
      u32 _49_28 = ((_id_0 >> 30) & 1);
      u32 _49_29 = ((_id_0 >> 31) & 1);
      r0 = _owners_0;
      r1 = _owners_1;
      r2 = _owners_2;
      r3 = _owners_3;
      r4 = _owners_4;
      r5 = _owners_5;
      r6 = _owners_6;
      r7 = _owners_7;
      r8 = _owners_8;
      r9 = _owners_9;
      r10 = 1;
      r11 = _world_0;
      r12 = _world_1;
      r13 = _world_2;
      r14 = _world_3;
      r15 = _world_4;
      r16 = _world_5;
      r17 = _world_6;
      r18 = _world_7;
      r19 = _world_8;
      r20 = _world_9;
      r21 = _world_10;
      r22 = _world_11;
      r23 = term_ctr(CID_SCON, STAT_OFF + 50);
      WL_RETN(24);
    } else if (_id_0 == 2) {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _owners_0;
        STK(1) = _owners_1;
        STK(2) = _owners_2;
        STK(3) = _owners_3;
        STK(4) = _owners_4;
        STK(5) = FID_DISPATCH_FAIL_K125;
        WL_PUSHN(6);
      } else {
        u64 _t_2 = task_node(e, FID_DISPATCH_FAIL_K125, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _owners_0;
        e.mem[_t_2 + 1] = _owners_1;
        e.mem[_t_2 + 2] = _owners_2;
        e.mem[_t_2 + 3] = _owners_3;
        e.mem[_t_2 + 4] = _owners_4;
        WL_CONT = term_tsk(FID_DISPATCH_FAIL_K125, _t_2);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SYSTEM_RUN_0)) {
        u64 _t_3 = task_node(e, FID_______SRC_ECS_SYSTEM_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _owners_5;
        e.mem[_t_3 + 1] = _owners_6;
        e.mem[_t_3 + 2] = _owners_7;
        e.mem[_t_3 + 3] = _owners_8;
        e.mem[_t_3 + 4] = _owners_9;
        e.mem[_t_3 + 5] = _world_0;
        e.mem[_t_3 + 6] = _world_1;
        e.mem[_t_3 + 7] = _world_2;
        e.mem[_t_3 + 8] = _world_3;
        e.mem[_t_3 + 9] = _world_4;
        e.mem[_t_3 + 10] = _world_5;
        e.mem[_t_3 + 11] = _world_6;
        e.mem[_t_3 + 12] = _world_7;
        e.mem[_t_3 + 13] = _world_8;
        e.mem[_t_3 + 14] = _world_9;
        e.mem[_t_3 + 15] = _world_10;
        e.mem[_t_3 + 16] = _world_11;
        e.mem[_t_3 + 17] = 7ull;
        return term_tsk(FID_______SRC_ECS_SYSTEM_RUN_0, _t_3);
      }
      r0 = _owners_5;
      r1 = _owners_6;
      r2 = _owners_7;
      r3 = _owners_8;
      r4 = _owners_9;
      r5 = _world_0;
      r6 = _world_1;
      r7 = _world_2;
      r8 = _world_3;
      r9 = _world_4;
      r10 = _world_5;
      r11 = _world_6;
      r12 = _world_7;
      r13 = _world_8;
      r14 = _world_9;
      r15 = _world_10;
      r16 = _world_11;
      r17 = 7ull;
      WL_JMP(FID_______SRC_ECS_SYSTEM_RUN_0);
    } else {
      u32 _110_0 = ((_id_0 >> 1) & 1);
      u32 _111_0 = ((_id_0 >> 2) & 1);
      u32 _111_1 = ((_id_0 >> 3) & 1);
      u32 _111_2 = ((_id_0 >> 4) & 1);
      u32 _111_3 = ((_id_0 >> 5) & 1);
      u32 _111_4 = ((_id_0 >> 6) & 1);
      u32 _111_5 = ((_id_0 >> 7) & 1);
      u32 _111_6 = ((_id_0 >> 8) & 1);
      u32 _111_7 = ((_id_0 >> 9) & 1);
      u32 _111_8 = ((_id_0 >> 10) & 1);
      u32 _111_9 = ((_id_0 >> 11) & 1);
      u32 _111_10 = ((_id_0 >> 12) & 1);
      u32 _111_11 = ((_id_0 >> 13) & 1);
      u32 _111_12 = ((_id_0 >> 14) & 1);
      u32 _111_13 = ((_id_0 >> 15) & 1);
      u32 _111_14 = ((_id_0 >> 16) & 1);
      u32 _111_15 = ((_id_0 >> 17) & 1);
      u32 _111_16 = ((_id_0 >> 18) & 1);
      u32 _111_17 = ((_id_0 >> 19) & 1);
      u32 _111_18 = ((_id_0 >> 20) & 1);
      u32 _111_19 = ((_id_0 >> 21) & 1);
      u32 _111_20 = ((_id_0 >> 22) & 1);
      u32 _111_21 = ((_id_0 >> 23) & 1);
      u32 _111_22 = ((_id_0 >> 24) & 1);
      u32 _111_23 = ((_id_0 >> 25) & 1);
      u32 _111_24 = ((_id_0 >> 26) & 1);
      u32 _111_25 = ((_id_0 >> 27) & 1);
      u32 _111_26 = ((_id_0 >> 28) & 1);
      u32 _111_27 = ((_id_0 >> 29) & 1);
      u32 _111_28 = ((_id_0 >> 30) & 1);
      u32 _111_29 = ((_id_0 >> 31) & 1);
      r0 = _owners_0;
      r1 = _owners_1;
      r2 = _owners_2;
      r3 = _owners_3;
      r4 = _owners_4;
      r5 = _owners_5;
      r6 = _owners_6;
      r7 = _owners_7;
      r8 = _owners_8;
      r9 = _owners_9;
      r10 = 1;
      r11 = _world_0;
      r12 = _world_1;
      r13 = _world_2;
      r14 = _world_3;
      r15 = _world_4;
      r16 = _world_5;
      r17 = _world_6;
      r18 = _world_7;
      r19 = _world_8;
      r20 = _world_9;
      r21 = _world_10;
      r22 = _world_11;
      r23 = term_ctr(CID_SCON, STAT_OFF + 50);
      WL_RETN(24);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DISPATCH_FAIL_K124)
  {
    WL_POPN(5);
    u32 _owners_10 = STK(0);
    u32 _owners_11 = STK(1);
    Term _owners_12 = STK(2);
    Term _owners_13 = STK(3);
    u32 _owners_14 = STK(4);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    Term _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _o_0[24];
    if (spin_50(e, _o_0, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, _h_19, blk_loc(e.mem, _h_19), _owners_10, _owners_11, _owners_12, blk_loc(e.mem, _owners_12), _owners_13, blk_loc(e.mem, _owners_13), _owners_14) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    _v_19 = _o_0[19];
    _v_20 = _o_0[20];
    _v_21 = _o_0[21];
    _v_22 = _o_0[22];
    _v_23 = _o_0[23];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    WL_RETN(24);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DISPATCH_FAIL_K125)
  {
    WL_POPN(5);
    u32 _owners_15 = STK(0);
    u32 _owners_16 = STK(1);
    Term _owners_17 = STK(2);
    Term _owners_18 = STK(3);
    u32 _owners_19 = STK(4);
    u32 _h_20 = r0;
    u32 _h_21 = r1;
    u32 _h_22 = r2;
    Term _h_23 = r3;
    Term _h_24 = r4;
    u32 _h_25 = r5;
    u32 _h_26 = r6;
    u32 _h_27 = r7;
    u32 _h_28 = r8;
    Term _h_29 = r9;
    Term _h_30 = r10;
    Term _h_31 = r11;
    Term _h_32 = r12;
    Term _h_33 = r13;
    Term _h_34 = r14;
    Term _h_35 = r15;
    Term _h_36 = r16;
    u32 _h_37 = r17;
    u32 _h_38 = r18;
    Term _h_39 = r19;
    WL_OPEN
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _o_1[24];
    if (spin_51(e, _o_1, _h_20, _h_21, _h_22, _h_23, blk_loc(e.mem, _h_23), _h_24, blk_loc(e.mem, _h_24), _h_25, _h_26, _h_27, _h_28, _h_29, blk_loc(e.mem, _h_29), _h_30, blk_loc(e.mem, _h_30), _h_31, _h_32, _h_33, blk_loc(e.mem, _h_33), _h_34, blk_loc(e.mem, _h_34), _h_35, blk_loc(e.mem, _h_35), _h_36, blk_loc(e.mem, _h_36), _h_37, _h_38, _h_39, blk_loc(e.mem, _h_39), _owners_15, _owners_16, _owners_17, blk_loc(e.mem, _owners_17), _owners_18, blk_loc(e.mem, _owners_18), _owners_19) == 0) {
      return 0;
    }
    _v_24 = _o_1[0];
    _v_25 = _o_1[1];
    _v_26 = _o_1[2];
    _v_27 = _o_1[3];
    _v_28 = _o_1[4];
    _v_29 = _o_1[5];
    _v_30 = _o_1[6];
    _v_31 = _o_1[7];
    _v_32 = _o_1[8];
    _v_33 = _o_1[9];
    _v_34 = _o_1[10];
    _v_35 = _o_1[11];
    _v_36 = _o_1[12];
    _v_37 = _o_1[13];
    _v_38 = _o_1[14];
    _v_39 = _o_1[15];
    _v_40 = _o_1[16];
    _v_41 = _o_1[17];
    _v_42 = _o_1[18];
    _v_43 = _o_1[19];
    _v_44 = _o_1[20];
    _v_45 = _o_1[21];
    _v_46 = _o_1[22];
    _v_47 = _o_1[23];
    r0 = _v_24;
    r1 = _v_25;
    r2 = _v_26;
    r3 = _v_27;
    r4 = _v_28;
    r5 = _v_29;
    r6 = _v_30;
    r7 = _v_31;
    r8 = _v_32;
    r9 = _v_33;
    r10 = _v_34;
    r11 = _v_35;
    r12 = _v_36;
    r13 = _v_37;
    r14 = _v_38;
    r15 = _v_39;
    r16 = _v_40;
    r17 = _v_41;
    r18 = _v_42;
    r19 = _v_43;
    r20 = _v_44;
    r21 = _v_45;
    r22 = _v_46;
    r23 = _v_47;
    WL_RETN(24);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DISPATCH)
  {
    u32 _owners_0 = r0;
    u32 _owners_1 = r1;
    Term _owners_2 = r2;
    Term _owners_3 = r3;
    u32 _owners_4 = r4;
    u32 _owners_5 = r5;
    u32 _owners_6 = r6;
    Term _owners_7 = r7;
    Term _owners_8 = r8;
    u32 _owners_9 = r9;
    u32 _world_0 = r10;
    u32 _world_1 = r11;
    u32 _world_2 = r12;
    Term _world_3 = r13;
    u32 _world_4 = r14;
    Term _world_5 = r15;
    u32 _world_6 = r16;
    Term _world_7 = r17;
    Term _world_8 = r18;
    Term _world_9 = r19;
    u32 _world_10 = r20;
    u32 _world_11 = r21;
    u32 _id_0 = r22;
    WL_OPEN
    if (_id_0 == 1) {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _owners_5;
        STK(1) = _owners_6;
        STK(2) = _owners_7;
        STK(3) = _owners_8;
        STK(4) = _owners_9;
        STK(5) = FID_DISPATCH_K130;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_DISPATCH_K130, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _owners_5;
        e.mem[_t_0 + 1] = _owners_6;
        e.mem[_t_0 + 2] = _owners_7;
        e.mem[_t_0 + 3] = _owners_8;
        e.mem[_t_0 + 4] = _owners_9;
        WL_CONT = term_tsk(FID_DISPATCH_K130, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SYSTEM_RUN_0)) {
        u64 _t_1 = task_node(e, FID_______SRC_ECS_SYSTEM_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owners_0;
        e.mem[_t_1 + 1] = _owners_1;
        e.mem[_t_1 + 2] = _owners_2;
        e.mem[_t_1 + 3] = _owners_3;
        e.mem[_t_1 + 4] = _owners_4;
        e.mem[_t_1 + 5] = _world_0;
        e.mem[_t_1 + 6] = _world_1;
        e.mem[_t_1 + 7] = _world_2;
        e.mem[_t_1 + 8] = _world_3;
        e.mem[_t_1 + 9] = _world_4;
        e.mem[_t_1 + 10] = _world_5;
        e.mem[_t_1 + 11] = _world_6;
        e.mem[_t_1 + 12] = _world_7;
        e.mem[_t_1 + 13] = _world_8;
        e.mem[_t_1 + 14] = _world_9;
        e.mem[_t_1 + 15] = _world_10;
        e.mem[_t_1 + 16] = _world_11;
        e.mem[_t_1 + 17] = 8ull;
        return term_tsk(FID_______SRC_ECS_SYSTEM_RUN_0, _t_1);
      }
      r0 = _owners_0;
      r1 = _owners_1;
      r2 = _owners_2;
      r3 = _owners_3;
      r4 = _owners_4;
      r5 = _world_0;
      r6 = _world_1;
      r7 = _world_2;
      r8 = _world_3;
      r9 = _world_4;
      r10 = _world_5;
      r11 = _world_6;
      r12 = _world_7;
      r13 = _world_8;
      r14 = _world_9;
      r15 = _world_10;
      r16 = _world_11;
      r17 = 8ull;
      WL_JMP(FID_______SRC_ECS_SYSTEM_RUN_0);
    } else if ((_id_0 & 1) == 1) {
      u32 _48_0 = ((_id_0 >> 1) & 1);
      u32 _49_0 = ((_id_0 >> 2) & 1);
      u32 _49_1 = ((_id_0 >> 3) & 1);
      u32 _49_2 = ((_id_0 >> 4) & 1);
      u32 _49_3 = ((_id_0 >> 5) & 1);
      u32 _49_4 = ((_id_0 >> 6) & 1);
      u32 _49_5 = ((_id_0 >> 7) & 1);
      u32 _49_6 = ((_id_0 >> 8) & 1);
      u32 _49_7 = ((_id_0 >> 9) & 1);
      u32 _49_8 = ((_id_0 >> 10) & 1);
      u32 _49_9 = ((_id_0 >> 11) & 1);
      u32 _49_10 = ((_id_0 >> 12) & 1);
      u32 _49_11 = ((_id_0 >> 13) & 1);
      u32 _49_12 = ((_id_0 >> 14) & 1);
      u32 _49_13 = ((_id_0 >> 15) & 1);
      u32 _49_14 = ((_id_0 >> 16) & 1);
      u32 _49_15 = ((_id_0 >> 17) & 1);
      u32 _49_16 = ((_id_0 >> 18) & 1);
      u32 _49_17 = ((_id_0 >> 19) & 1);
      u32 _49_18 = ((_id_0 >> 20) & 1);
      u32 _49_19 = ((_id_0 >> 21) & 1);
      u32 _49_20 = ((_id_0 >> 22) & 1);
      u32 _49_21 = ((_id_0 >> 23) & 1);
      u32 _49_22 = ((_id_0 >> 24) & 1);
      u32 _49_23 = ((_id_0 >> 25) & 1);
      u32 _49_24 = ((_id_0 >> 26) & 1);
      u32 _49_25 = ((_id_0 >> 27) & 1);
      u32 _49_26 = ((_id_0 >> 28) & 1);
      u32 _49_27 = ((_id_0 >> 29) & 1);
      u32 _49_28 = ((_id_0 >> 30) & 1);
      u32 _49_29 = ((_id_0 >> 31) & 1);
      r0 = _owners_0;
      r1 = _owners_1;
      r2 = _owners_2;
      r3 = _owners_3;
      r4 = _owners_4;
      r5 = _owners_5;
      r6 = _owners_6;
      r7 = _owners_7;
      r8 = _owners_8;
      r9 = _owners_9;
      r10 = 1;
      r11 = _world_0;
      r12 = _world_1;
      r13 = _world_2;
      r14 = _world_3;
      r15 = _world_4;
      r16 = _world_5;
      r17 = _world_6;
      r18 = _world_7;
      r19 = _world_8;
      r20 = _world_9;
      r21 = _world_10;
      r22 = _world_11;
      r23 = term_ctr(CID_SCON, STAT_OFF + 50);
      WL_RETN(24);
    } else if (_id_0 == 2) {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _owners_0;
        STK(1) = _owners_1;
        STK(2) = _owners_2;
        STK(3) = _owners_3;
        STK(4) = _owners_4;
        STK(5) = FID_DISPATCH_K131;
        WL_PUSHN(6);
      } else {
        u64 _t_2 = task_node(e, FID_DISPATCH_K131, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _owners_0;
        e.mem[_t_2 + 1] = _owners_1;
        e.mem[_t_2 + 2] = _owners_2;
        e.mem[_t_2 + 3] = _owners_3;
        e.mem[_t_2 + 4] = _owners_4;
        WL_CONT = term_tsk(FID_DISPATCH_K131, _t_2);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SYSTEM_RUN_0)) {
        u64 _t_3 = task_node(e, FID_______SRC_ECS_SYSTEM_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _owners_5;
        e.mem[_t_3 + 1] = _owners_6;
        e.mem[_t_3 + 2] = _owners_7;
        e.mem[_t_3 + 3] = _owners_8;
        e.mem[_t_3 + 4] = _owners_9;
        e.mem[_t_3 + 5] = _world_0;
        e.mem[_t_3 + 6] = _world_1;
        e.mem[_t_3 + 7] = _world_2;
        e.mem[_t_3 + 8] = _world_3;
        e.mem[_t_3 + 9] = _world_4;
        e.mem[_t_3 + 10] = _world_5;
        e.mem[_t_3 + 11] = _world_6;
        e.mem[_t_3 + 12] = _world_7;
        e.mem[_t_3 + 13] = _world_8;
        e.mem[_t_3 + 14] = _world_9;
        e.mem[_t_3 + 15] = _world_10;
        e.mem[_t_3 + 16] = _world_11;
        e.mem[_t_3 + 17] = 2ull;
        return term_tsk(FID_______SRC_ECS_SYSTEM_RUN_0, _t_3);
      }
      r0 = _owners_5;
      r1 = _owners_6;
      r2 = _owners_7;
      r3 = _owners_8;
      r4 = _owners_9;
      r5 = _world_0;
      r6 = _world_1;
      r7 = _world_2;
      r8 = _world_3;
      r9 = _world_4;
      r10 = _world_5;
      r11 = _world_6;
      r12 = _world_7;
      r13 = _world_8;
      r14 = _world_9;
      r15 = _world_10;
      r16 = _world_11;
      r17 = 2ull;
      WL_JMP(FID_______SRC_ECS_SYSTEM_RUN_0);
    } else {
      u32 _110_0 = ((_id_0 >> 1) & 1);
      u32 _111_0 = ((_id_0 >> 2) & 1);
      u32 _111_1 = ((_id_0 >> 3) & 1);
      u32 _111_2 = ((_id_0 >> 4) & 1);
      u32 _111_3 = ((_id_0 >> 5) & 1);
      u32 _111_4 = ((_id_0 >> 6) & 1);
      u32 _111_5 = ((_id_0 >> 7) & 1);
      u32 _111_6 = ((_id_0 >> 8) & 1);
      u32 _111_7 = ((_id_0 >> 9) & 1);
      u32 _111_8 = ((_id_0 >> 10) & 1);
      u32 _111_9 = ((_id_0 >> 11) & 1);
      u32 _111_10 = ((_id_0 >> 12) & 1);
      u32 _111_11 = ((_id_0 >> 13) & 1);
      u32 _111_12 = ((_id_0 >> 14) & 1);
      u32 _111_13 = ((_id_0 >> 15) & 1);
      u32 _111_14 = ((_id_0 >> 16) & 1);
      u32 _111_15 = ((_id_0 >> 17) & 1);
      u32 _111_16 = ((_id_0 >> 18) & 1);
      u32 _111_17 = ((_id_0 >> 19) & 1);
      u32 _111_18 = ((_id_0 >> 20) & 1);
      u32 _111_19 = ((_id_0 >> 21) & 1);
      u32 _111_20 = ((_id_0 >> 22) & 1);
      u32 _111_21 = ((_id_0 >> 23) & 1);
      u32 _111_22 = ((_id_0 >> 24) & 1);
      u32 _111_23 = ((_id_0 >> 25) & 1);
      u32 _111_24 = ((_id_0 >> 26) & 1);
      u32 _111_25 = ((_id_0 >> 27) & 1);
      u32 _111_26 = ((_id_0 >> 28) & 1);
      u32 _111_27 = ((_id_0 >> 29) & 1);
      u32 _111_28 = ((_id_0 >> 30) & 1);
      u32 _111_29 = ((_id_0 >> 31) & 1);
      r0 = _owners_0;
      r1 = _owners_1;
      r2 = _owners_2;
      r3 = _owners_3;
      r4 = _owners_4;
      r5 = _owners_5;
      r6 = _owners_6;
      r7 = _owners_7;
      r8 = _owners_8;
      r9 = _owners_9;
      r10 = 1;
      r11 = _world_0;
      r12 = _world_1;
      r13 = _world_2;
      r14 = _world_3;
      r15 = _world_4;
      r16 = _world_5;
      r17 = _world_6;
      r18 = _world_7;
      r19 = _world_8;
      r20 = _world_9;
      r21 = _world_10;
      r22 = _world_11;
      r23 = term_ctr(CID_SCON, STAT_OFF + 50);
      WL_RETN(24);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DISPATCH_K130)
  {
    WL_POPN(5);
    u32 _owners_10 = STK(0);
    u32 _owners_11 = STK(1);
    Term _owners_12 = STK(2);
    Term _owners_13 = STK(3);
    u32 _owners_14 = STK(4);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    Term _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _o_0[24];
    if (spin_50(e, _o_0, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, _h_19, blk_loc(e.mem, _h_19), _owners_10, _owners_11, _owners_12, blk_loc(e.mem, _owners_12), _owners_13, blk_loc(e.mem, _owners_13), _owners_14) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    _v_19 = _o_0[19];
    _v_20 = _o_0[20];
    _v_21 = _o_0[21];
    _v_22 = _o_0[22];
    _v_23 = _o_0[23];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    WL_RETN(24);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_DISPATCH_K131)
  {
    WL_POPN(5);
    u32 _owners_15 = STK(0);
    u32 _owners_16 = STK(1);
    Term _owners_17 = STK(2);
    Term _owners_18 = STK(3);
    u32 _owners_19 = STK(4);
    u32 _h_20 = r0;
    u32 _h_21 = r1;
    u32 _h_22 = r2;
    Term _h_23 = r3;
    Term _h_24 = r4;
    u32 _h_25 = r5;
    u32 _h_26 = r6;
    u32 _h_27 = r7;
    u32 _h_28 = r8;
    Term _h_29 = r9;
    Term _h_30 = r10;
    Term _h_31 = r11;
    Term _h_32 = r12;
    Term _h_33 = r13;
    Term _h_34 = r14;
    Term _h_35 = r15;
    Term _h_36 = r16;
    u32 _h_37 = r17;
    u32 _h_38 = r18;
    Term _h_39 = r19;
    WL_OPEN
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _o_1[24];
    if (spin_51(e, _o_1, _h_20, _h_21, _h_22, _h_23, blk_loc(e.mem, _h_23), _h_24, blk_loc(e.mem, _h_24), _h_25, _h_26, _h_27, _h_28, _h_29, blk_loc(e.mem, _h_29), _h_30, blk_loc(e.mem, _h_30), _h_31, _h_32, _h_33, blk_loc(e.mem, _h_33), _h_34, blk_loc(e.mem, _h_34), _h_35, blk_loc(e.mem, _h_35), _h_36, blk_loc(e.mem, _h_36), _h_37, _h_38, _h_39, blk_loc(e.mem, _h_39), _owners_15, _owners_16, _owners_17, blk_loc(e.mem, _owners_17), _owners_18, blk_loc(e.mem, _owners_18), _owners_19) == 0) {
      return 0;
    }
    _v_24 = _o_1[0];
    _v_25 = _o_1[1];
    _v_26 = _o_1[2];
    _v_27 = _o_1[3];
    _v_28 = _o_1[4];
    _v_29 = _o_1[5];
    _v_30 = _o_1[6];
    _v_31 = _o_1[7];
    _v_32 = _o_1[8];
    _v_33 = _o_1[9];
    _v_34 = _o_1[10];
    _v_35 = _o_1[11];
    _v_36 = _o_1[12];
    _v_37 = _o_1[13];
    _v_38 = _o_1[14];
    _v_39 = _o_1[15];
    _v_40 = _o_1[16];
    _v_41 = _o_1[17];
    _v_42 = _o_1[18];
    _v_43 = _o_1[19];
    _v_44 = _o_1[20];
    _v_45 = _o_1[21];
    _v_46 = _o_1[22];
    _v_47 = _o_1[23];
    r0 = _v_24;
    r1 = _v_25;
    r2 = _v_26;
    r3 = _v_27;
    r4 = _v_28;
    r5 = _v_29;
    r6 = _v_30;
    r7 = _v_31;
    r8 = _v_32;
    r9 = _v_33;
    r10 = _v_34;
    r11 = _v_35;
    r12 = _v_36;
    r13 = _v_37;
    r14 = _v_38;
    r15 = _v_39;
    r16 = _v_40;
    r17 = _v_41;
    r18 = _v_42;
    r19 = _v_43;
    r20 = _v_44;
    r21 = _v_45;
    r22 = _v_46;
    r23 = _v_47;
    WL_RETN(24);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0)
  {
    Term _next_0 = r0;
    u32 _result_0 = r1;
    u32 _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    u32 _result_4 = r5;
    u32 _result_5 = r6;
    u32 _result_6 = r7;
    Term _result_7 = r8;
    Term _result_8 = r9;
    u32 _result_9 = r10;
    u32 _result_10 = r11;
    u32 _result_11 = r12;
    u32 _result_12 = r13;
    u32 _result_13 = r14;
    Term _result_14 = r15;
    u32 _result_15 = r16;
    Term _result_16 = r17;
    u32 _result_17 = r18;
    Term _result_18 = r19;
    Term _result_19 = r20;
    Term _result_20 = r21;
    u32 _result_21 = r22;
    u32 _result_22 = r23;
    Term _result_23 = r24;
    u32 _namespace_0 = r25;
    Term _name_0 = r26;
    Term _all_0 = r27;
    Term _observations_0 = r28;
    u32 _id_0 = r29;
    WL_OPEN
    if (_result_10 == 1) {
      term_sink(e, _next_0);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, term_pak(CID_______SRC_ECS_SCHEDULE_RAN, _id_0));
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      if (seq) {
        WL_ROOM(27);
        STK(0) = _result_11;
        STK(1) = _result_12;
        STK(2) = _result_13;
        STK(3) = _result_14;
        STK(4) = _result_15;
        STK(5) = _result_16;
        STK(6) = _result_17;
        STK(7) = _result_18;
        STK(8) = _result_19;
        STK(9) = _result_20;
        STK(10) = _result_21;
        STK(11) = _result_22;
        STK(12) = _result_23;
        STK(13) = _result_0;
        STK(14) = _result_1;
        STK(15) = _result_2;
        STK(16) = _result_3;
        STK(17) = _result_4;
        STK(18) = _result_5;
        STK(19) = _result_6;
        STK(20) = _result_7;
        STK(21) = _result_8;
        STK(22) = _result_9;
        STK(23) = _namespace_0;
        STK(24) = _name_0;
        STK(25) = _all_0;
        STK(26) = FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K133;
        WL_PUSHN(27);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K133, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_11;
        e.mem[_t_0 + 1] = _result_12;
        e.mem[_t_0 + 2] = _result_13;
        e.mem[_t_0 + 3] = _result_14;
        e.mem[_t_0 + 4] = _result_15;
        e.mem[_t_0 + 5] = _result_16;
        e.mem[_t_0 + 6] = _result_17;
        e.mem[_t_0 + 7] = _result_18;
        e.mem[_t_0 + 8] = _result_19;
        e.mem[_t_0 + 9] = _result_20;
        e.mem[_t_0 + 10] = _result_21;
        e.mem[_t_0 + 11] = _result_22;
        e.mem[_t_0 + 12] = _result_23;
        e.mem[_t_0 + 13] = _result_0;
        e.mem[_t_0 + 14] = _result_1;
        e.mem[_t_0 + 15] = _result_2;
        e.mem[_t_0 + 16] = _result_3;
        e.mem[_t_0 + 17] = _result_4;
        e.mem[_t_0 + 18] = _result_5;
        e.mem[_t_0 + 19] = _result_6;
        e.mem[_t_0 + 20] = _result_7;
        e.mem[_t_0 + 21] = _result_8;
        e.mem[_t_0 + 22] = _result_9;
        e.mem[_t_0 + 23] = _namespace_0;
        e.mem[_t_0 + 24] = _name_0;
        e.mem[_t_0 + 25] = _all_0;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K133, _t_0);
        WL_IDX = 26;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
        u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _observations_0;
        e.mem[_t_1 + 1] = term_ctr(CID_CON, _nd_0);
        return term_tsk(FID_LIST_APPEND, _t_1);
      }
      r0 = _observations_0;
      r1 = term_ctr(CID_CON, _nd_0);
      WL_JMP(FID_LIST_APPEND);
    } else {
      term_sink(e, _name_0);
      term_sink(e, _all_0);
      u64 _nd_1 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_1);
      e.mem[_nd_1 + 2] = rfc_seal(e, _result_2);
      e.mem[_nd_1 + 3] = rfc_seal(e, _result_3);
      e.mem[_nd_1 + 4] = rfc_seal(e, _result_4);
      e.mem[_nd_1 + 5] = rfc_seal(e, _result_5);
      e.mem[_nd_1 + 6] = rfc_seal(e, _result_6);
      e.mem[_nd_1 + 7] = rfc_seal(e, _result_7);
      e.mem[_nd_1 + 8] = rfc_seal(e, _result_8);
      e.mem[_nd_1 + 9] = rfc_seal(e, _result_9);
      if (seq) {
        WL_ROOM(15);
        STK(0) = _result_11;
        STK(1) = _result_12;
        STK(2) = _result_13;
        STK(3) = _result_14;
        STK(4) = _result_15;
        STK(5) = _result_16;
        STK(6) = _result_17;
        STK(7) = _result_18;
        STK(8) = _result_19;
        STK(9) = _result_20;
        STK(10) = _result_21;
        STK(11) = _result_22;
        STK(12) = _observations_0;
        STK(13) = _id_0;
        STK(14) = FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K134;
        WL_PUSHN(15);
      } else {
        u64 _t_2 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K134, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _result_11;
        e.mem[_t_2 + 1] = _result_12;
        e.mem[_t_2 + 2] = _result_13;
        e.mem[_t_2 + 3] = _result_14;
        e.mem[_t_2 + 4] = _result_15;
        e.mem[_t_2 + 5] = _result_16;
        e.mem[_t_2 + 6] = _result_17;
        e.mem[_t_2 + 7] = _result_18;
        e.mem[_t_2 + 8] = _result_19;
        e.mem[_t_2 + 9] = _result_20;
        e.mem[_t_2 + 10] = _result_21;
        e.mem[_t_2 + 11] = _result_22;
        e.mem[_t_2 + 12] = _observations_0;
        e.mem[_t_2 + 13] = _id_0;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K134, _t_2);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _next_0;
        e.mem[_t_3 + 1] = term_ctr(CID_OWNERS, _nd_1);
        return term_tsk(FID_CLO_APPLY, _t_3);
      }
      r0 = _next_0;
      r1 = term_ctr(CID_OWNERS, _nd_1);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K133)
  {
    WL_POPN(26);
    u32 _result_24 = STK(0);
    u32 _result_25 = STK(1);
    u32 _result_26 = STK(2);
    Term _result_27 = STK(3);
    u32 _result_28 = STK(4);
    Term _result_29 = STK(5);
    u32 _result_30 = STK(6);
    Term _result_31 = STK(7);
    Term _result_32 = STK(8);
    Term _result_33 = STK(9);
    u32 _result_34 = STK(10);
    u32 _result_35 = STK(11);
    Term _result_36 = STK(12);
    u32 _result_37 = STK(13);
    u32 _result_38 = STK(14);
    Term _result_39 = STK(15);
    Term _result_40 = STK(16);
    u32 _result_41 = STK(17);
    u32 _result_42 = STK(18);
    u32 _result_43 = STK(19);
    Term _result_44 = STK(20);
    Term _result_45 = STK(21);
    u32 _result_46 = STK(22);
    u32 _namespace_1 = STK(23);
    Term _name_1 = STK(24);
    Term _all_1 = STK(25);
    Term _h_0 = r0;
    WL_OPEN
    r0 = 1;
    r1 = _namespace_1;
    r2 = _name_1;
    r3 = _all_1;
    r4 = _result_37;
    r5 = _result_38;
    r6 = _result_39;
    r7 = _result_40;
    r8 = _result_41;
    r9 = _result_42;
    r10 = _result_43;
    r11 = _result_44;
    r12 = _result_45;
    r13 = _result_46;
    r14 = _result_24;
    r15 = _result_25;
    r16 = _result_26;
    r17 = _result_27;
    r18 = _result_28;
    r19 = _result_29;
    r20 = _result_30;
    r21 = _result_31;
    r22 = _result_32;
    r23 = _result_33;
    r24 = _result_34;
    r25 = _result_35;
    r26 = _result_36;
    r27 = _h_0;
    WL_RETN(28);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K134)
  {
    WL_POPN(14);
    u32 _result_47 = STK(0);
    u32 _result_48 = STK(1);
    u32 _result_49 = STK(2);
    Term _result_50 = STK(3);
    u32 _result_51 = STK(4);
    Term _result_52 = STK(5);
    u32 _result_53 = STK(6);
    Term _result_54 = STK(7);
    Term _result_55 = STK(8);
    Term _result_56 = STK(9);
    u32 _result_57 = STK(10);
    u32 _result_58 = STK(11);
    Term _observations_1 = STK(12);
    u32 _id_1 = STK(13);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = rfc_seal(e, _result_47);
    e.mem[_nd_2 + 1] = rfc_seal(e, _result_48);
    e.mem[_nd_2 + 2] = rfc_seal(e, _result_49);
    e.mem[_nd_2 + 3] = rfc_seal(e, _result_50);
    e.mem[_nd_2 + 4] = rfc_seal(e, _result_51);
    e.mem[_nd_2 + 5] = rfc_seal(e, _result_52);
    e.mem[_nd_2 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_2 + 7] = rfc_seal(e, _result_53);
    e.mem[_nd_2 + 8] = rfc_seal(e, _result_54);
    e.mem[_nd_2 + 9] = rfc_seal(e, _result_55);
    e.mem[_nd_2 + 10] = rfc_seal(e, _result_56);
    e.mem[_nd_2 + 11] = rfc_seal(e, _result_57);
    e.mem[_nd_2 + 12] = rfc_seal(e, _result_58);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _observations_1;
      STK(1) = _id_1;
      STK(2) = FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K135;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K135, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _observations_1;
      e.mem[_t_4 + 1] = _id_1;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K135, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_1;
      e.mem[_t_5 + 1] = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_5);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K135)
  {
    WL_POPN(2);
    Term _observations_2 = STK(0);
    u32 _id_2 = STK(1);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_______SRC_ECS_SCHEDULE_RAN, _id_2));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K136;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K136, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_2;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K136, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_7 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _observations_2;
      e.mem[_t_7 + 1] = term_ctr(CID_CON, _nd_3);
      return term_tsk(FID_LIST_APPEND, _t_7);
    }
    r0 = _observations_2;
    r1 = term_ctr(CID_CON, _nd_3);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K136)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K137;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K137, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K137, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_9 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_4;
      e.mem[_t_9 + 1] = _h_3;
      return term_tsk(FID_CLO_APPLY, _t_9);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0_K137)
  {
    Term _r_0 = r0;
    WL_OPEN
    u32 _o_0 = 0;
    u32 _o_1 = 0;
    Term _o_2 = 0;
    Term _o_3 = 0;
    u32 _o_4 = 0;
    u32 _o_5 = 0;
    Term _o_6 = 0;
    Term _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    Term _o_11 = 0;
    Term _o_12 = 0;
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    Term _o_17 = 0;
    u32 _o_18 = 0;
    Term _o_19 = 0;
    u32 _o_20 = 0;
    Term _o_21 = 0;
    Term _o_22 = 0;
    Term _o_23 = 0;
    u32 _o_24 = 0;
    u32 _o_25 = 0;
    Term _o_26 = 0;
    Term _o_27 = 0;
    if (term_aux(_r_0) == CID_______SRC_ECS_SCHEDULE_FINISHED) {
      _o_0 = 0;
      Term _fb_0[18];
      u64 _sp_0 = ctr_take(e, _r_0, 18, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _f_2 = _fb_0[2];
      Term _f_3 = _fb_0[3];
      u32 _f_4 = _fb_0[4];
      u32 _f_5 = _fb_0[5];
      u32 _f_6 = _fb_0[6];
      Term _f_7 = _fb_0[7];
      u32 _f_8 = _fb_0[8];
      Term _f_9 = _fb_0[9];
      Term _f_10 = _fb_0[10];
      Term _f_11 = _fb_0[11];
      Term _f_12 = _fb_0[12];
      Term _f_13 = _fb_0[13];
      Term _f_14 = _fb_0[14];
      u32 _f_15 = _fb_0[15];
      u32 _f_16 = _fb_0[16];
      Term _f_17 = _fb_0[17];
      spare_free(e, cls_fit(18), _sp_0);
      Term _fb_1[10];
      u64 _sp_1 = ctr_take(e, _f_3, 10, _fb_1);
      u32 _f_18 = _fb_1[0];
      u32 _f_19 = _fb_1[1];
      Term _f_20 = _fb_1[2];
      Term _f_21 = _fb_1[3];
      u32 _f_22 = _fb_1[4];
      u32 _f_23 = _fb_1[5];
      u32 _f_24 = _fb_1[6];
      Term _f_25 = _fb_1[7];
      Term _f_26 = _fb_1[8];
      u32 _f_27 = _fb_1[9];
      spare_free(e, cls_fit(10), _sp_1);
      _o_1 = _f_0;
      _o_2 = _f_1;
      _o_3 = _f_2;
      _o_4 = _f_18;
      _o_5 = _f_19;
      _o_6 = _f_20;
      _o_7 = _f_21;
      _o_8 = _f_22;
      _o_9 = _f_23;
      _o_10 = _f_24;
      _o_11 = _f_25;
      _o_12 = _f_26;
      _o_13 = _f_27;
      _o_14 = _f_4;
      _o_15 = _f_5;
      _o_16 = _f_6;
      _o_17 = _f_7;
      _o_18 = _f_8;
      _o_19 = _f_9;
      _o_20 = _f_11;
      _o_21 = _f_12;
      _o_22 = _f_13;
      _o_23 = _f_14;
      _o_24 = _f_15;
      _o_25 = _f_16;
      _o_26 = _f_17;
    } else if (term_aux(_r_0) == CID_______SRC_ECS_SCHEDULE_FAILED) {
      _o_0 = 1;
      Term _fb_2[19];
      u64 _sp_2 = ctr_take(e, _r_0, 19, _fb_2);
      u32 _f_28 = _fb_2[0];
      Term _f_29 = _fb_2[1];
      Term _f_30 = _fb_2[2];
      Term _f_31 = _fb_2[3];
      u32 _f_32 = _fb_2[4];
      u32 _f_33 = _fb_2[5];
      u32 _f_34 = _fb_2[6];
      Term _f_35 = _fb_2[7];
      u32 _f_36 = _fb_2[8];
      Term _f_37 = _fb_2[9];
      Term _f_38 = _fb_2[10];
      Term _f_39 = _fb_2[11];
      Term _f_40 = _fb_2[12];
      Term _f_41 = _fb_2[13];
      Term _f_42 = _fb_2[14];
      u32 _f_43 = _fb_2[15];
      u32 _f_44 = _fb_2[16];
      Term _f_45 = _fb_2[17];
      Term _f_46 = _fb_2[18];
      spare_free(e, cls_fit(19), _sp_2);
      Term _fb_3[10];
      u64 _sp_3 = ctr_take(e, _f_31, 10, _fb_3);
      u32 _f_47 = _fb_3[0];
      u32 _f_48 = _fb_3[1];
      Term _f_49 = _fb_3[2];
      Term _f_50 = _fb_3[3];
      u32 _f_51 = _fb_3[4];
      u32 _f_52 = _fb_3[5];
      u32 _f_53 = _fb_3[6];
      Term _f_54 = _fb_3[7];
      Term _f_55 = _fb_3[8];
      u32 _f_56 = _fb_3[9];
      spare_free(e, cls_fit(10), _sp_3);
      _o_1 = _f_28;
      _o_2 = _f_29;
      _o_3 = _f_30;
      _o_4 = _f_47;
      _o_5 = _f_48;
      _o_6 = _f_49;
      _o_7 = _f_50;
      _o_8 = _f_51;
      _o_9 = _f_52;
      _o_10 = _f_53;
      _o_11 = _f_54;
      _o_12 = _f_55;
      _o_13 = _f_56;
      _o_14 = _f_32;
      _o_15 = _f_33;
      _o_16 = _f_34;
      _o_17 = _f_35;
      _o_18 = _f_36;
      _o_19 = _f_37;
      _o_20 = _f_39;
      _o_21 = _f_40;
      _o_22 = _f_41;
      _o_23 = _f_42;
      _o_24 = _f_43;
      _o_25 = _f_44;
      _o_26 = _f_45;
      _o_27 = _f_46;
    } else {
      _o_0 = 2;
      Term _fb_4[17];
      u64 _sp_4 = ctr_take(e, _r_0, 17, _fb_4);
      u32 _f_57 = _fb_4[0];
      Term _f_58 = _fb_4[1];
      Term _f_59 = _fb_4[2];
      Term _f_60 = _fb_4[3];
      u32 _f_61 = _fb_4[4];
      u32 _f_62 = _fb_4[5];
      u32 _f_63 = _fb_4[6];
      Term _f_64 = _fb_4[7];
      u32 _f_65 = _fb_4[8];
      Term _f_66 = _fb_4[9];
      Term _f_67 = _fb_4[10];
      Term _f_68 = _fb_4[11];
      Term _f_69 = _fb_4[12];
      Term _f_70 = _fb_4[13];
      Term _f_71 = _fb_4[14];
      u32 _f_72 = _fb_4[15];
      u32 _f_73 = _fb_4[16];
      spare_free(e, cls_fit(17), _sp_4);
      Term _fb_5[10];
      u64 _sp_5 = ctr_take(e, _f_60, 10, _fb_5);
      u32 _f_74 = _fb_5[0];
      u32 _f_75 = _fb_5[1];
      Term _f_76 = _fb_5[2];
      Term _f_77 = _fb_5[3];
      u32 _f_78 = _fb_5[4];
      u32 _f_79 = _fb_5[5];
      u32 _f_80 = _fb_5[6];
      Term _f_81 = _fb_5[7];
      Term _f_82 = _fb_5[8];
      u32 _f_83 = _fb_5[9];
      spare_free(e, cls_fit(10), _sp_5);
      _o_1 = _f_57;
      _o_2 = _f_58;
      _o_3 = _f_59;
      _o_4 = _f_74;
      _o_5 = _f_75;
      _o_6 = _f_76;
      _o_7 = _f_77;
      _o_8 = _f_78;
      _o_9 = _f_79;
      _o_10 = _f_80;
      _o_11 = _f_81;
      _o_12 = _f_82;
      _o_13 = _f_83;
      _o_14 = _f_61;
      _o_15 = _f_62;
      _o_16 = _f_63;
      _o_17 = _f_64;
      _o_18 = _f_65;
      _o_19 = _f_66;
      _o_20 = _f_68;
      _o_21 = _f_69;
      _o_22 = _f_70;
      _o_23 = _f_71;
      _o_24 = _f_72;
      _o_25 = _f_73;
    }
    r0 = _o_0;
    r1 = _o_1;
    r2 = _o_2;
    r3 = _o_3;
    r4 = _o_4;
    r5 = _o_5;
    r6 = _o_6;
    r7 = _o_7;
    r8 = _o_8;
    r9 = _o_9;
    r10 = _o_10;
    r11 = _o_11;
    r12 = _o_12;
    r13 = _o_13;
    r14 = _o_14;
    r15 = _o_15;
    r16 = _o_16;
    r17 = _o_17;
    r18 = _o_18;
    r19 = _o_19;
    r20 = _o_20;
    r21 = _o_21;
    r22 = _o_22;
    r23 = _o_23;
    r24 = _o_24;
    r25 = _o_25;
    r26 = _o_26;
    r27 = _o_27;
    WL_RETN(28);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GAMEPLAY_READ_0)
  {
    u32 _ctx_0 = r0;
    u32 _ctx_1 = r1;
    u32 _ctx_2 = r2;
    Term _ctx_3 = r3;
    u32 _ctx_4 = r4;
    Term _ctx_5 = r5;
    u32 _ctx_6 = r6;
    Term _ctx_7 = r7;
    Term _ctx_8 = r8;
    Term _ctx_9 = r9;
    u32 _ctx_10 = r10;
    u32 _ctx_11 = r11;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_14 = 0;
    Term _o_1[1];
    Term _a_0 = term_clo(FID_GAMEPLAY_READ_0_C145, 0);
    if (spin_54(e, _o_1, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_14 = _o_1[0];
    _v_0 = _v_14;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = rfc_seal(e, _ctx_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _ctx_1);
    e.mem[_nd_2 + 2] = rfc_seal(e, _ctx_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _ctx_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _ctx_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, _ctx_5);
    e.mem[_nd_2 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_2 + 7] = rfc_seal(e, _ctx_6);
    e.mem[_nd_2 + 8] = rfc_seal(e, _ctx_7);
    e.mem[_nd_2 + 9] = rfc_seal(e, _ctx_8);
    e.mem[_nd_2 + 10] = rfc_seal(e, _ctx_9);
    e.mem[_nd_2 + 11] = rfc_seal(e, _ctx_10);
    e.mem[_nd_2 + 12] = rfc_seal(e, _ctx_11);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_GAMEPLAY_READ_0_K146;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_GAMEPLAY_READ_0_K146, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_GAMEPLAY_READ_0_K146, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _v_0;
    r1 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GAMEPLAY_READ_0_C145)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_0[13];
    if (spin_53(e, _o_0, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_7, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_2 = _o_0[1];
    _v_3 = _o_0[2];
    _v_4 = _o_0[3];
    _v_5 = _o_0[4];
    _v_6 = _o_0[5];
    _v_7 = _o_0[6];
    _v_8 = _o_0[7];
    _v_9 = _o_0[8];
    _v_10 = _o_0[9];
    _v_11 = _o_0[10];
    _v_12 = _o_0[11];
    _v_13 = _o_0[12];
    u64 _nd_0 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_2);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_3);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_4);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_5);
    e.mem[_nd_0 + 5] = rfc_seal(e, _v_6);
    e.mem[_nd_0 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 7] = rfc_seal(e, _v_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, _v_8);
    e.mem[_nd_0 + 9] = rfc_seal(e, _v_9);
    e.mem[_nd_0 + 10] = rfc_seal(e, _v_10);
    e.mem[_nd_0 + 11] = rfc_seal(e, _v_11);
    e.mem[_nd_0 + 12] = rfc_seal(e, _v_12);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_13);
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_GAMEPLAY_READ_0_K146)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _r_0, 2, _fb_1);
    Term _f_13 = _fb_1[0];
    Term _f_14 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    Term _fb_2[13];
    u64 _sp_2 = ctr_take(e, _f_13, 13, _fb_2);
    u32 _f_15 = _fb_2[0];
    u32 _f_16 = _fb_2[1];
    u32 _f_17 = _fb_2[2];
    Term _f_18 = _fb_2[3];
    u32 _f_19 = _fb_2[4];
    Term _f_20 = _fb_2[5];
    Term _f_21 = _fb_2[6];
    Term _f_22 = _fb_2[7];
    Term _f_23 = _fb_2[8];
    Term _f_24 = _fb_2[9];
    Term _f_25 = _fb_2[10];
    u32 _f_26 = _fb_2[11];
    u32 _f_27 = _fb_2[12];
    spare_free(e, cls_fit(13), _sp_2);
    r0 = _f_15;
    r1 = _f_16;
    r2 = _f_17;
    r3 = _f_18;
    r4 = _f_19;
    r5 = _f_20;
    r6 = _f_22;
    r7 = _f_23;
    r8 = _f_24;
    r9 = _f_25;
    r10 = _f_26;
    r11 = _f_27;
    r12 = _f_14;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONDITION)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    u32 _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _slot_0 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _slot_0;
      STK(1) = FID_CONDITION_K161;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONDITION_K161, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _slot_0;
      WL_CONT = term_tsk(FID_CONDITION_K161, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_GAMEPLAY_READ_0)) {
      u64 _t_1 = task_node(e, FID_GAMEPLAY_READ_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      return term_tsk(FID_GAMEPLAY_READ_0, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    WL_JMP(FID_GAMEPLAY_READ_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONDITION_K161)
  {
    WL_POPN(1);
    u32 _slot_1 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _o_2[13];
    if (spin_55(e, _o_2, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, _h_5, _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), _h_10, _h_11, _h_12, _slot_1) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    _v_7 = _o_2[7];
    _v_8 = _o_2[8];
    _v_9 = _o_2[9];
    _v_10 = _o_2[10];
    _v_11 = _o_2[11];
    _v_12 = _o_2[12];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0)
  {
    Term _commands_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    u32 _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    u32 _world_10 = r11;
    u32 _world_11 = r12;
    WL_OPEN
    WL_SPIN
    if (term_aux(_commands_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      WL_RETN(12);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K171;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K171, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K171, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _world_2;
      r4 = _world_3;
      r5 = _world_4;
      r6 = _world_5;
      r7 = _world_6;
      r8 = _world_7;
      r9 = _world_8;
      r10 = _world_9;
      r11 = _world_10;
      r12 = _world_11;
      _commands_0 = r0;
      _world_0 = r1;
      _world_1 = r2;
      _world_2 = r3;
      _world_3 = r4;
      _world_4 = r5;
      _world_5 = r6;
      _world_6 = r7;
      _world_7 = r8;
      _world_8 = r9;
      _world_9 = r10;
      _world_10 = r11;
      _world_11 = r12;
      WL_AGAIN(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K171)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 7] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 8] = rfc_seal(e, _h_7);
    e.mem[_nd_0 + 9] = rfc_seal(e, _h_8);
    e.mem[_nd_0 + 10] = rfc_seal(e, _h_9);
    e.mem[_nd_0 + 11] = rfc_seal(e, _h_10);
    e.mem[_nd_0 + 12] = rfc_seal(e, _h_11);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K172;
      WL_PUSHN(1);
    } else {
      u64 _t_1 = task_node(e, FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K172, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K172, _t_1);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _f_2;
    r1 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0_K172)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_1[13];
    u64 _sp_1 = ctr_take(e, _r_0, 13, _fb_1);
    u32 _f_3 = _fb_1[0];
    u32 _f_4 = _fb_1[1];
    u32 _f_5 = _fb_1[2];
    Term _f_6 = _fb_1[3];
    u32 _f_7 = _fb_1[4];
    Term _f_8 = _fb_1[5];
    Term _f_9 = _fb_1[6];
    Term _f_10 = _fb_1[7];
    Term _f_11 = _fb_1[8];
    Term _f_12 = _fb_1[9];
    Term _f_13 = _fb_1[10];
    u32 _f_14 = _fb_1[11];
    u32 _f_15 = _fb_1[12];
    spare_free(e, cls_fit(13), _sp_1);
    r0 = _f_3;
    r1 = _f_4;
    r2 = _f_5;
    r3 = _f_6;
    r4 = _f_7;
    r5 = _f_8;
    r6 = _f_10;
    r7 = _f_11;
    r8 = _f_12;
    r9 = _f_13;
    r10 = _f_14;
    r11 = _f_15;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_LINES)
  {
    Term _lines_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_lines_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _lines_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_SHOW_LINES_K174;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_SHOW_LINES_K174, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_SHOW_LINES_K174, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _lines_0 = r0;
      WL_AGAIN(FID_SHOW_LINES);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_LINES_K174)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_2;
      STK(1) = FID_SHOW_LINES_K175;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_SHOW_LINES_K175, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _f_2;
      WL_CONT = term_tsk(FID_SHOW_LINES_K175, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 52);
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 52);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_LINES_K175)
  {
    WL_POPN(1);
    Term _f_3 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_3;
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _f_3;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1)
  {
    Term _steps_0 = r0;
    u32 _owners_0 = r1;
    u32 _owners_1 = r2;
    Term _owners_2 = r3;
    Term _owners_3 = r4;
    u32 _owners_4 = r5;
    u32 _owners_5 = r6;
    u32 _owners_6 = r7;
    Term _owners_7 = r8;
    Term _owners_8 = r9;
    u32 _owners_9 = r10;
    u32 _world_0 = r11;
    u32 _world_1 = r12;
    u32 _world_2 = r13;
    Term _world_3 = r14;
    u32 _world_4 = r15;
    Term _world_5 = r16;
    u32 _world_6 = r17;
    Term _world_7 = r18;
    Term _world_8 = r19;
    Term _world_9 = r20;
    u32 _world_10 = r21;
    u32 _world_11 = r22;
    u32 _namespace_0 = r23;
    Term _name_0 = r24;
    Term _all_0 = r25;
    Term _observations_0 = r26;
    WL_OPEN
    if (term_aux(_steps_0) == CID_NIL) {
      r0 = 0;
      r1 = _namespace_0;
      r2 = _name_0;
      r3 = _all_0;
      r4 = _owners_0;
      r5 = _owners_1;
      r6 = _owners_2;
      r7 = _owners_3;
      r8 = _owners_4;
      r9 = _owners_5;
      r10 = _owners_6;
      r11 = _owners_7;
      r12 = _owners_8;
      r13 = _owners_9;
      r14 = _world_0;
      r15 = _world_1;
      r16 = _world_2;
      r17 = _world_3;
      r18 = _world_4;
      r19 = _world_5;
      r20 = _world_6;
      r21 = _world_7;
      r22 = _world_8;
      r23 = _world_9;
      r24 = _world_10;
      r25 = _world_11;
      r26 = _observations_0;
      r27 = 0;
      WL_RETN(28);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_SYSTEM) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_PHASE) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else {
        _o_0 = 2;
      }
      if (_o_0 == 1) {
        u64 _nd_0 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_0 + 0] = rfc_seal(e, _o_1);
        u64 _nd_1 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_______SRC_ECS_SCHEDULE_ENTERED, _nd_0));
        e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        if (seq) {
          WL_ROOM(27);
          STK(0) = _f_1;
          STK(1) = _owners_0;
          STK(2) = _owners_1;
          STK(3) = _owners_2;
          STK(4) = _owners_3;
          STK(5) = _owners_4;
          STK(6) = _owners_5;
          STK(7) = _owners_6;
          STK(8) = _owners_7;
          STK(9) = _owners_8;
          STK(10) = _owners_9;
          STK(11) = _world_0;
          STK(12) = _world_1;
          STK(13) = _world_2;
          STK(14) = _world_3;
          STK(15) = _world_4;
          STK(16) = _world_5;
          STK(17) = _world_6;
          STK(18) = _world_7;
          STK(19) = _world_8;
          STK(20) = _world_9;
          STK(21) = _world_10;
          STK(22) = _world_11;
          STK(23) = _namespace_0;
          STK(24) = _name_0;
          STK(25) = _all_0;
          STK(26) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K177;
          WL_PUSHN(27);
        } else {
          u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K177, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _owners_0;
          e.mem[_t_0 + 2] = _owners_1;
          e.mem[_t_0 + 3] = _owners_2;
          e.mem[_t_0 + 4] = _owners_3;
          e.mem[_t_0 + 5] = _owners_4;
          e.mem[_t_0 + 6] = _owners_5;
          e.mem[_t_0 + 7] = _owners_6;
          e.mem[_t_0 + 8] = _owners_7;
          e.mem[_t_0 + 9] = _owners_8;
          e.mem[_t_0 + 10] = _owners_9;
          e.mem[_t_0 + 11] = _world_0;
          e.mem[_t_0 + 12] = _world_1;
          e.mem[_t_0 + 13] = _world_2;
          e.mem[_t_0 + 14] = _world_3;
          e.mem[_t_0 + 15] = _world_4;
          e.mem[_t_0 + 16] = _world_5;
          e.mem[_t_0 + 17] = _world_6;
          e.mem[_t_0 + 18] = _world_7;
          e.mem[_t_0 + 19] = _world_8;
          e.mem[_t_0 + 20] = _world_9;
          e.mem[_t_0 + 21] = _world_10;
          e.mem[_t_0 + 22] = _world_11;
          e.mem[_t_0 + 23] = _namespace_0;
          e.mem[_t_0 + 24] = _name_0;
          e.mem[_t_0 + 25] = _all_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K177, _t_0);
          WL_IDX = 26;
        }
        if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
          u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _observations_0;
          e.mem[_t_1 + 1] = term_ctr(CID_CON, _nd_1);
          return term_tsk(FID_LIST_APPEND, _t_1);
        }
        r0 = _observations_0;
        r1 = term_ctr(CID_CON, _nd_1);
        WL_JMP(FID_LIST_APPEND);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(16);
          STK(0) = _f_1;
          STK(1) = _owners_0;
          STK(2) = _owners_1;
          STK(3) = _owners_2;
          STK(4) = _owners_3;
          STK(5) = _owners_4;
          STK(6) = _owners_5;
          STK(7) = _owners_6;
          STK(8) = _owners_7;
          STK(9) = _owners_8;
          STK(10) = _owners_9;
          STK(11) = _namespace_0;
          STK(12) = _name_0;
          STK(13) = _all_0;
          STK(14) = _observations_0;
          STK(15) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K178;
          WL_PUSHN(16);
        } else {
          u64 _t_3 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K178, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_1;
          e.mem[_t_3 + 1] = _owners_0;
          e.mem[_t_3 + 2] = _owners_1;
          e.mem[_t_3 + 3] = _owners_2;
          e.mem[_t_3 + 4] = _owners_3;
          e.mem[_t_3 + 5] = _owners_4;
          e.mem[_t_3 + 6] = _owners_5;
          e.mem[_t_3 + 7] = _owners_6;
          e.mem[_t_3 + 8] = _owners_7;
          e.mem[_t_3 + 9] = _owners_8;
          e.mem[_t_3 + 10] = _owners_9;
          e.mem[_t_3 + 11] = _namespace_0;
          e.mem[_t_3 + 12] = _name_0;
          e.mem[_t_3 + 13] = _all_0;
          e.mem[_t_3 + 14] = _observations_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K178, _t_3);
          WL_IDX = 15;
        }
        if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_BARRIER_0)) {
          u64 _t_4 = task_node(e, FID_______SRC_ECS_WORLD_BARRIER_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _world_0;
          e.mem[_t_4 + 1] = _world_1;
          e.mem[_t_4 + 2] = _world_2;
          e.mem[_t_4 + 3] = _world_3;
          e.mem[_t_4 + 4] = _world_4;
          e.mem[_t_4 + 5] = _world_5;
          e.mem[_t_4 + 6] = _world_6;
          e.mem[_t_4 + 7] = _world_7;
          e.mem[_t_4 + 8] = _world_8;
          e.mem[_t_4 + 9] = _world_9;
          e.mem[_t_4 + 10] = _world_10;
          e.mem[_t_4 + 11] = _world_11;
          return term_tsk(FID_______SRC_ECS_WORLD_BARRIER_0, _t_4);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        WL_JMP(FID_______SRC_ECS_WORLD_BARRIER_0);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(17);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _owners_0;
          STK(3) = _owners_1;
          STK(4) = _owners_2;
          STK(5) = _owners_3;
          STK(6) = _owners_4;
          STK(7) = _owners_5;
          STK(8) = _owners_6;
          STK(9) = _owners_7;
          STK(10) = _owners_8;
          STK(11) = _owners_9;
          STK(12) = _namespace_0;
          STK(13) = _name_0;
          STK(14) = _all_0;
          STK(15) = _observations_0;
          STK(16) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K180;
          WL_PUSHN(17);
        } else {
          u64 _t_8 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K180, WL_CONT, WL_IDX, 1);
          e.mem[_t_8 + 0] = _o_1;
          e.mem[_t_8 + 1] = _f_1;
          e.mem[_t_8 + 2] = _owners_0;
          e.mem[_t_8 + 3] = _owners_1;
          e.mem[_t_8 + 4] = _owners_2;
          e.mem[_t_8 + 5] = _owners_3;
          e.mem[_t_8 + 6] = _owners_4;
          e.mem[_t_8 + 7] = _owners_5;
          e.mem[_t_8 + 8] = _owners_6;
          e.mem[_t_8 + 9] = _owners_7;
          e.mem[_t_8 + 10] = _owners_8;
          e.mem[_t_8 + 11] = _owners_9;
          e.mem[_t_8 + 12] = _namespace_0;
          e.mem[_t_8 + 13] = _name_0;
          e.mem[_t_8 + 14] = _all_0;
          e.mem[_t_8 + 15] = _observations_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K180, _t_8);
          WL_IDX = 16;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CONDITION)) {
          u64 _t_9 = task_node(e, FID_CONDITION, WL_CONT, WL_IDX, 0);
          e.mem[_t_9 + 0] = _world_0;
          e.mem[_t_9 + 1] = _world_1;
          e.mem[_t_9 + 2] = _world_2;
          e.mem[_t_9 + 3] = _world_3;
          e.mem[_t_9 + 4] = _world_4;
          e.mem[_t_9 + 5] = _world_5;
          e.mem[_t_9 + 6] = _world_6;
          e.mem[_t_9 + 7] = _world_7;
          e.mem[_t_9 + 8] = _world_8;
          e.mem[_t_9 + 9] = _world_9;
          e.mem[_t_9 + 10] = _world_10;
          e.mem[_t_9 + 11] = _world_11;
          e.mem[_t_9 + 12] = _o_2;
          return term_tsk(FID_CONDITION, _t_9);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _o_2;
        WL_JMP(FID_CONDITION);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K177)
  {
    WL_POPN(26);
    Term _f_5 = STK(0);
    u32 _owners_10 = STK(1);
    u32 _owners_11 = STK(2);
    Term _owners_12 = STK(3);
    Term _owners_13 = STK(4);
    u32 _owners_14 = STK(5);
    u32 _owners_15 = STK(6);
    u32 _owners_16 = STK(7);
    Term _owners_17 = STK(8);
    Term _owners_18 = STK(9);
    u32 _owners_19 = STK(10);
    u32 _world_12 = STK(11);
    u32 _world_13 = STK(12);
    u32 _world_14 = STK(13);
    Term _world_15 = STK(14);
    u32 _world_16 = STK(15);
    Term _world_17 = STK(16);
    u32 _world_18 = STK(17);
    Term _world_19 = STK(18);
    Term _world_20 = STK(19);
    Term _world_21 = STK(20);
    u32 _world_22 = STK(21);
    u32 _world_23 = STK(22);
    u32 _namespace_1 = STK(23);
    Term _name_1 = STK(24);
    Term _all_1 = STK(25);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1)) {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _owners_10;
      e.mem[_t_2 + 2] = _owners_11;
      e.mem[_t_2 + 3] = _owners_12;
      e.mem[_t_2 + 4] = _owners_13;
      e.mem[_t_2 + 5] = _owners_14;
      e.mem[_t_2 + 6] = _owners_15;
      e.mem[_t_2 + 7] = _owners_16;
      e.mem[_t_2 + 8] = _owners_17;
      e.mem[_t_2 + 9] = _owners_18;
      e.mem[_t_2 + 10] = _owners_19;
      e.mem[_t_2 + 11] = _world_12;
      e.mem[_t_2 + 12] = _world_13;
      e.mem[_t_2 + 13] = _world_14;
      e.mem[_t_2 + 14] = _world_15;
      e.mem[_t_2 + 15] = _world_16;
      e.mem[_t_2 + 16] = _world_17;
      e.mem[_t_2 + 17] = _world_18;
      e.mem[_t_2 + 18] = _world_19;
      e.mem[_t_2 + 19] = _world_20;
      e.mem[_t_2 + 20] = _world_21;
      e.mem[_t_2 + 21] = _world_22;
      e.mem[_t_2 + 22] = _world_23;
      e.mem[_t_2 + 23] = _namespace_1;
      e.mem[_t_2 + 24] = _name_1;
      e.mem[_t_2 + 25] = _all_1;
      e.mem[_t_2 + 26] = _h_0;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1, _t_2);
    }
    r0 = _f_5;
    r1 = _owners_10;
    r2 = _owners_11;
    r3 = _owners_12;
    r4 = _owners_13;
    r5 = _owners_14;
    r6 = _owners_15;
    r7 = _owners_16;
    r8 = _owners_17;
    r9 = _owners_18;
    r10 = _owners_19;
    r11 = _world_12;
    r12 = _world_13;
    r13 = _world_14;
    r14 = _world_15;
    r15 = _world_16;
    r16 = _world_17;
    r17 = _world_18;
    r18 = _world_19;
    r19 = _world_20;
    r20 = _world_21;
    r21 = _world_22;
    r22 = _world_23;
    r23 = _namespace_1;
    r24 = _name_1;
    r25 = _all_1;
    r26 = _h_0;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K178)
  {
    WL_POPN(15);
    Term _f_6 = STK(0);
    u32 _owners_20 = STK(1);
    u32 _owners_21 = STK(2);
    Term _owners_22 = STK(3);
    Term _owners_23 = STK(4);
    u32 _owners_24 = STK(5);
    u32 _owners_25 = STK(6);
    u32 _owners_26 = STK(7);
    Term _owners_27 = STK(8);
    Term _owners_28 = STK(9);
    u32 _owners_29 = STK(10);
    u32 _namespace_2 = STK(11);
    Term _name_2 = STK(12);
    Term _all_2 = STK(13);
    Term _observations_1 = STK(14);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    u32 _h_3 = r2;
    Term _h_4 = r3;
    u32 _h_5 = r4;
    Term _h_6 = r5;
    u32 _h_7 = r6;
    Term _h_8 = r7;
    Term _h_9 = r8;
    Term _h_10 = r9;
    u32 _h_11 = r10;
    u32 _h_12 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _f_6;
      STK(1) = _owners_20;
      STK(2) = _owners_21;
      STK(3) = _owners_22;
      STK(4) = _owners_23;
      STK(5) = _owners_24;
      STK(6) = _owners_25;
      STK(7) = _owners_26;
      STK(8) = _owners_27;
      STK(9) = _owners_28;
      STK(10) = _owners_29;
      STK(11) = _namespace_2;
      STK(12) = _name_2;
      STK(13) = _all_2;
      STK(14) = _h_1;
      STK(15) = _h_2;
      STK(16) = _h_3;
      STK(17) = _h_4;
      STK(18) = _h_5;
      STK(19) = _h_6;
      STK(20) = _h_7;
      STK(21) = _h_8;
      STK(22) = _h_9;
      STK(23) = _h_10;
      STK(24) = _h_11;
      STK(25) = _h_12;
      STK(26) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K179;
      WL_PUSHN(27);
    } else {
      u64 _t_5 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K179, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = _owners_20;
      e.mem[_t_5 + 2] = _owners_21;
      e.mem[_t_5 + 3] = _owners_22;
      e.mem[_t_5 + 4] = _owners_23;
      e.mem[_t_5 + 5] = _owners_24;
      e.mem[_t_5 + 6] = _owners_25;
      e.mem[_t_5 + 7] = _owners_26;
      e.mem[_t_5 + 8] = _owners_27;
      e.mem[_t_5 + 9] = _owners_28;
      e.mem[_t_5 + 10] = _owners_29;
      e.mem[_t_5 + 11] = _namespace_2;
      e.mem[_t_5 + 12] = _name_2;
      e.mem[_t_5 + 13] = _all_2;
      e.mem[_t_5 + 14] = _h_1;
      e.mem[_t_5 + 15] = _h_2;
      e.mem[_t_5 + 16] = _h_3;
      e.mem[_t_5 + 17] = _h_4;
      e.mem[_t_5 + 18] = _h_5;
      e.mem[_t_5 + 19] = _h_6;
      e.mem[_t_5 + 20] = _h_7;
      e.mem[_t_5 + 21] = _h_8;
      e.mem[_t_5 + 22] = _h_9;
      e.mem[_t_5 + 23] = _h_10;
      e.mem[_t_5 + 24] = _h_11;
      e.mem[_t_5 + 25] = _h_12;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K179, _t_5);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_6 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _observations_1;
      e.mem[_t_6 + 1] = term_ctr(CID_CON, STAT_OFF + 54);
      return term_tsk(FID_LIST_APPEND, _t_6);
    }
    r0 = _observations_1;
    r1 = term_ctr(CID_CON, STAT_OFF + 54);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K179)
  {
    WL_POPN(26);
    Term _f_7 = STK(0);
    u32 _owners_30 = STK(1);
    u32 _owners_31 = STK(2);
    Term _owners_32 = STK(3);
    Term _owners_33 = STK(4);
    u32 _owners_34 = STK(5);
    u32 _owners_35 = STK(6);
    u32 _owners_36 = STK(7);
    Term _owners_37 = STK(8);
    Term _owners_38 = STK(9);
    u32 _owners_39 = STK(10);
    u32 _namespace_3 = STK(11);
    Term _name_3 = STK(12);
    Term _all_3 = STK(13);
    u32 _h_14 = STK(14);
    u32 _h_15 = STK(15);
    u32 _h_16 = STK(16);
    Term _h_17 = STK(17);
    u32 _h_18 = STK(18);
    Term _h_19 = STK(19);
    u32 _h_20 = STK(20);
    Term _h_21 = STK(21);
    Term _h_22 = STK(22);
    Term _h_23 = STK(23);
    u32 _h_24 = STK(24);
    u32 _h_25 = STK(25);
    Term _h_13 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1)) {
      u64 _t_7 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_7;
      e.mem[_t_7 + 1] = _owners_30;
      e.mem[_t_7 + 2] = _owners_31;
      e.mem[_t_7 + 3] = _owners_32;
      e.mem[_t_7 + 4] = _owners_33;
      e.mem[_t_7 + 5] = _owners_34;
      e.mem[_t_7 + 6] = _owners_35;
      e.mem[_t_7 + 7] = _owners_36;
      e.mem[_t_7 + 8] = _owners_37;
      e.mem[_t_7 + 9] = _owners_38;
      e.mem[_t_7 + 10] = _owners_39;
      e.mem[_t_7 + 11] = _h_14;
      e.mem[_t_7 + 12] = _h_15;
      e.mem[_t_7 + 13] = _h_16;
      e.mem[_t_7 + 14] = _h_17;
      e.mem[_t_7 + 15] = _h_18;
      e.mem[_t_7 + 16] = _h_19;
      e.mem[_t_7 + 17] = _h_20;
      e.mem[_t_7 + 18] = _h_21;
      e.mem[_t_7 + 19] = _h_22;
      e.mem[_t_7 + 20] = _h_23;
      e.mem[_t_7 + 21] = _h_24;
      e.mem[_t_7 + 22] = _h_25;
      e.mem[_t_7 + 23] = _namespace_3;
      e.mem[_t_7 + 24] = _name_3;
      e.mem[_t_7 + 25] = _all_3;
      e.mem[_t_7 + 26] = _h_13;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1, _t_7);
    }
    r0 = _f_7;
    r1 = _owners_30;
    r2 = _owners_31;
    r3 = _owners_32;
    r4 = _owners_33;
    r5 = _owners_34;
    r6 = _owners_35;
    r7 = _owners_36;
    r8 = _owners_37;
    r9 = _owners_38;
    r10 = _owners_39;
    r11 = _h_14;
    r12 = _h_15;
    r13 = _h_16;
    r14 = _h_17;
    r15 = _h_18;
    r16 = _h_19;
    r17 = _h_20;
    r18 = _h_21;
    r19 = _h_22;
    r20 = _h_23;
    r21 = _h_24;
    r22 = _h_25;
    r23 = _namespace_3;
    r24 = _name_3;
    r25 = _all_3;
    r26 = _h_13;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K180)
  {
    WL_POPN(16);
    u32 _o_3 = STK(0);
    Term _f_8 = STK(1);
    u32 _owners_40 = STK(2);
    u32 _owners_41 = STK(3);
    Term _owners_42 = STK(4);
    Term _owners_43 = STK(5);
    u32 _owners_44 = STK(6);
    u32 _owners_45 = STK(7);
    u32 _owners_46 = STK(8);
    Term _owners_47 = STK(9);
    Term _owners_48 = STK(10);
    u32 _owners_49 = STK(11);
    u32 _namespace_4 = STK(12);
    Term _name_4 = STK(13);
    Term _all_4 = STK(14);
    Term _observations_2 = STK(15);
    u32 _h_26 = r0;
    u32 _h_27 = r1;
    u32 _h_28 = r2;
    Term _h_29 = r3;
    u32 _h_30 = r4;
    Term _h_31 = r5;
    u32 _h_32 = r6;
    Term _h_33 = r7;
    Term _h_34 = r8;
    Term _h_35 = r9;
    u32 _h_36 = r10;
    u32 _h_37 = r11;
    u32 _h_38 = r12;
    WL_OPEN
    _name_4 = term_keep(e, _name_4, 1);
    _all_4 = term_keep(e, _all_4, 1);
    u64 _nd_2 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_2 + 0] = _f_8;
    e.mem[_nd_2 + 1] = _namespace_4;
    e.mem[_nd_2 + 2] = _name_4;
    e.mem[_nd_2 + 3] = _all_4;
    Term _next_0 = term_clo(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C181, _nd_2);
    if (_h_38 == 0) {
      term_sink(e, _name_4);
      term_sink(e, _all_4);
      u64 _nd_11 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_11 + 0] = rfc_seal(e, _owners_40);
      e.mem[_nd_11 + 1] = rfc_seal(e, _owners_41);
      e.mem[_nd_11 + 2] = rfc_seal(e, _owners_42);
      e.mem[_nd_11 + 3] = rfc_seal(e, _owners_43);
      e.mem[_nd_11 + 4] = rfc_seal(e, _owners_44);
      e.mem[_nd_11 + 5] = rfc_seal(e, _owners_45);
      e.mem[_nd_11 + 6] = rfc_seal(e, _owners_46);
      e.mem[_nd_11 + 7] = rfc_seal(e, _owners_47);
      e.mem[_nd_11 + 8] = rfc_seal(e, _owners_48);
      e.mem[_nd_11 + 9] = rfc_seal(e, _owners_49);
      if (seq) {
        WL_ROOM(15);
        STK(0) = _h_26;
        STK(1) = _h_27;
        STK(2) = _h_28;
        STK(3) = _h_29;
        STK(4) = _h_30;
        STK(5) = _h_31;
        STK(6) = _h_32;
        STK(7) = _h_33;
        STK(8) = _h_34;
        STK(9) = _h_35;
        STK(10) = _h_36;
        STK(11) = _h_37;
        STK(12) = _observations_2;
        STK(13) = _o_3;
        STK(14) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K185;
        WL_PUSHN(15);
      } else {
        u64 _t_12 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K185, WL_CONT, WL_IDX, 1);
        e.mem[_t_12 + 0] = _h_26;
        e.mem[_t_12 + 1] = _h_27;
        e.mem[_t_12 + 2] = _h_28;
        e.mem[_t_12 + 3] = _h_29;
        e.mem[_t_12 + 4] = _h_30;
        e.mem[_t_12 + 5] = _h_31;
        e.mem[_t_12 + 6] = _h_32;
        e.mem[_t_12 + 7] = _h_33;
        e.mem[_t_12 + 8] = _h_34;
        e.mem[_t_12 + 9] = _h_35;
        e.mem[_t_12 + 10] = _h_36;
        e.mem[_t_12 + 11] = _h_37;
        e.mem[_t_12 + 12] = _observations_2;
        e.mem[_t_12 + 13] = _o_3;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K185, _t_12);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_13 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _next_0;
        e.mem[_t_13 + 1] = term_ctr(CID_OWNERS, _nd_11);
        return term_tsk(FID_CLO_APPLY, _t_13);
      }
      r0 = _next_0;
      r1 = term_ctr(CID_OWNERS, _nd_11);
      WL_JMP(FID_CLO_APPLY);
    } else {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _next_0;
        STK(1) = _namespace_4;
        STK(2) = _name_4;
        STK(3) = _all_4;
        STK(4) = _observations_2;
        STK(5) = _o_3;
        STK(6) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K189;
        WL_PUSHN(7);
      } else {
        u64 _t_20 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K189, WL_CONT, WL_IDX, 1);
        e.mem[_t_20 + 0] = _next_0;
        e.mem[_t_20 + 1] = _namespace_4;
        e.mem[_t_20 + 2] = _name_4;
        e.mem[_t_20 + 3] = _all_4;
        e.mem[_t_20 + 4] = _observations_2;
        e.mem[_t_20 + 5] = _o_3;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K189, _t_20);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_DISPATCH_FAIL)) {
        u64 _t_21 = task_node(e, FID_DISPATCH_FAIL, WL_CONT, WL_IDX, 0);
        e.mem[_t_21 + 0] = _owners_40;
        e.mem[_t_21 + 1] = _owners_41;
        e.mem[_t_21 + 2] = _owners_42;
        e.mem[_t_21 + 3] = _owners_43;
        e.mem[_t_21 + 4] = _owners_44;
        e.mem[_t_21 + 5] = _owners_45;
        e.mem[_t_21 + 6] = _owners_46;
        e.mem[_t_21 + 7] = _owners_47;
        e.mem[_t_21 + 8] = _owners_48;
        e.mem[_t_21 + 9] = _owners_49;
        e.mem[_t_21 + 10] = _h_26;
        e.mem[_t_21 + 11] = _h_27;
        e.mem[_t_21 + 12] = _h_28;
        e.mem[_t_21 + 13] = _h_29;
        e.mem[_t_21 + 14] = _h_30;
        e.mem[_t_21 + 15] = _h_31;
        e.mem[_t_21 + 16] = _h_32;
        e.mem[_t_21 + 17] = _h_33;
        e.mem[_t_21 + 18] = _h_34;
        e.mem[_t_21 + 19] = _h_35;
        e.mem[_t_21 + 20] = _h_36;
        e.mem[_t_21 + 21] = _h_37;
        e.mem[_t_21 + 22] = _o_3;
        return term_tsk(FID_DISPATCH_FAIL, _t_21);
      }
      r0 = _owners_40;
      r1 = _owners_41;
      r2 = _owners_42;
      r3 = _owners_43;
      r4 = _owners_44;
      r5 = _owners_45;
      r6 = _owners_46;
      r7 = _owners_47;
      r8 = _owners_48;
      r9 = _owners_49;
      r10 = _h_26;
      r11 = _h_27;
      r12 = _h_28;
      r13 = _h_29;
      r14 = _h_30;
      r15 = _h_31;
      r16 = _h_32;
      r17 = _h_33;
      r18 = _h_34;
      r19 = _h_35;
      r20 = _h_36;
      r21 = _h_37;
      r22 = _o_3;
      WL_JMP(FID_DISPATCH_FAIL);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C181)
  {
    Term _f_9 = r0;
    u32 _namespace_5 = r1;
    Term _name_5 = r2;
    Term _all_5 = r3;
    Term _x_0 = r4;
    WL_OPEN
    Term _fb_3[10];
    u64 _sp_3 = ctr_take(e, _x_0, 10, _fb_3);
    u32 _f_10 = _fb_3[0];
    u32 _f_11 = _fb_3[1];
    Term _f_12 = _fb_3[2];
    Term _f_13 = _fb_3[3];
    u32 _f_14 = _fb_3[4];
    u32 _f_15 = _fb_3[5];
    u32 _f_16 = _fb_3[6];
    Term _f_17 = _fb_3[7];
    Term _f_18 = _fb_3[8];
    u32 _f_19 = _fb_3[9];
    spare_free(e, cls_fit(10), _sp_3);
    u64 _nd_3 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_3 + 0] = _f_9;
    e.mem[_nd_3 + 1] = _namespace_5;
    e.mem[_nd_3 + 2] = _name_5;
    e.mem[_nd_3 + 3] = _all_5;
    e.mem[_nd_3 + 4] = _f_10;
    e.mem[_nd_3 + 5] = _f_11;
    e.mem[_nd_3 + 6] = _f_12;
    e.mem[_nd_3 + 7] = _f_13;
    e.mem[_nd_3 + 8] = _f_14;
    e.mem[_nd_3 + 9] = _f_15;
    e.mem[_nd_3 + 10] = _f_16;
    e.mem[_nd_3 + 11] = _f_17;
    e.mem[_nd_3 + 12] = _f_18;
    e.mem[_nd_3 + 13] = _f_19;
    r0 = term_clo(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C182, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C182)
  {
    Term _f_20 = r0;
    u32 _namespace_6 = r1;
    Term _name_6 = r2;
    Term _all_6 = r3;
    u32 _f_21 = r4;
    u32 _f_22 = r5;
    Term _f_23 = r6;
    Term _f_24 = r7;
    u32 _f_25 = r8;
    u32 _f_26 = r9;
    u32 _f_27 = r10;
    Term _f_28 = r11;
    Term _f_29 = r12;
    u32 _f_30 = r13;
    Term _x_1 = r14;
    WL_OPEN
    Term _fb_4[13];
    u64 _sp_4 = ctr_take(e, _x_1, 13, _fb_4);
    u32 _f_31 = _fb_4[0];
    u32 _f_32 = _fb_4[1];
    u32 _f_33 = _fb_4[2];
    Term _f_34 = _fb_4[3];
    u32 _f_35 = _fb_4[4];
    Term _f_36 = _fb_4[5];
    Term _f_37 = _fb_4[6];
    Term _f_38 = _fb_4[7];
    Term _f_39 = _fb_4[8];
    Term _f_40 = _fb_4[9];
    Term _f_41 = _fb_4[10];
    u32 _f_42 = _fb_4[11];
    u32 _f_43 = _fb_4[12];
    spare_free(e, cls_fit(13), _sp_4);
    u64 _nd_4 = heap_alloc(e, cls_fit(26));
    e.mem[_nd_4 + 0] = _f_20;
    e.mem[_nd_4 + 1] = _namespace_6;
    e.mem[_nd_4 + 2] = _name_6;
    e.mem[_nd_4 + 3] = _all_6;
    e.mem[_nd_4 + 4] = _f_21;
    e.mem[_nd_4 + 5] = _f_22;
    e.mem[_nd_4 + 6] = _f_23;
    e.mem[_nd_4 + 7] = _f_24;
    e.mem[_nd_4 + 8] = _f_25;
    e.mem[_nd_4 + 9] = _f_26;
    e.mem[_nd_4 + 10] = _f_27;
    e.mem[_nd_4 + 11] = _f_28;
    e.mem[_nd_4 + 12] = _f_29;
    e.mem[_nd_4 + 13] = _f_30;
    e.mem[_nd_4 + 14] = _f_31;
    e.mem[_nd_4 + 15] = _f_32;
    e.mem[_nd_4 + 16] = _f_33;
    e.mem[_nd_4 + 17] = _f_34;
    e.mem[_nd_4 + 18] = _f_35;
    e.mem[_nd_4 + 19] = _f_36;
    e.mem[_nd_4 + 20] = _f_38;
    e.mem[_nd_4 + 21] = _f_39;
    e.mem[_nd_4 + 22] = _f_40;
    e.mem[_nd_4 + 23] = _f_41;
    e.mem[_nd_4 + 24] = _f_42;
    e.mem[_nd_4 + 25] = _f_43;
    r0 = term_clo(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C183, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_C183)
  {
    Term _f_44 = r0;
    u32 _namespace_7 = r1;
    Term _name_7 = r2;
    Term _all_7 = r3;
    u32 _f_45 = r4;
    u32 _f_46 = r5;
    Term _f_47 = r6;
    Term _f_48 = r7;
    u32 _f_49 = r8;
    u32 _f_50 = r9;
    u32 _f_51 = r10;
    Term _f_52 = r11;
    Term _f_53 = r12;
    u32 _f_54 = r13;
    u32 _f_55 = r14;
    u32 _f_56 = r15;
    u32 _f_57 = r16;
    Term _f_58 = r17;
    u32 _f_59 = r18;
    Term _f_60 = r19;
    u32 _f_61 = r20;
    Term _f_62 = r21;
    Term _f_63 = r22;
    Term _f_64 = r23;
    u32 _f_65 = r24;
    u32 _f_66 = r25;
    Term _x_2 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K184;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K184, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K184, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1)) {
      u64 _t_11 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _f_44;
      e.mem[_t_11 + 1] = _f_45;
      e.mem[_t_11 + 2] = _f_46;
      e.mem[_t_11 + 3] = _f_47;
      e.mem[_t_11 + 4] = _f_48;
      e.mem[_t_11 + 5] = _f_49;
      e.mem[_t_11 + 6] = _f_50;
      e.mem[_t_11 + 7] = _f_51;
      e.mem[_t_11 + 8] = _f_52;
      e.mem[_t_11 + 9] = _f_53;
      e.mem[_t_11 + 10] = _f_54;
      e.mem[_t_11 + 11] = _f_55;
      e.mem[_t_11 + 12] = _f_56;
      e.mem[_t_11 + 13] = _f_57;
      e.mem[_t_11 + 14] = _f_58;
      e.mem[_t_11 + 15] = _f_59;
      e.mem[_t_11 + 16] = _f_60;
      e.mem[_t_11 + 17] = _f_61;
      e.mem[_t_11 + 18] = _f_62;
      e.mem[_t_11 + 19] = _f_63;
      e.mem[_t_11 + 20] = _f_64;
      e.mem[_t_11 + 21] = _f_65;
      e.mem[_t_11 + 22] = _f_66;
      e.mem[_t_11 + 23] = _namespace_7;
      e.mem[_t_11 + 24] = _name_7;
      e.mem[_t_11 + 25] = _all_7;
      e.mem[_t_11 + 26] = _x_2;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1, _t_11);
    }
    r0 = _f_44;
    r1 = _f_45;
    r2 = _f_46;
    r3 = _f_47;
    r4 = _f_48;
    r5 = _f_49;
    r6 = _f_50;
    r7 = _f_51;
    r8 = _f_52;
    r9 = _f_53;
    r10 = _f_54;
    r11 = _f_55;
    r12 = _f_56;
    r13 = _f_57;
    r14 = _f_58;
    r15 = _f_59;
    r16 = _f_60;
    r17 = _f_61;
    r18 = _f_62;
    r19 = _f_63;
    r20 = _f_64;
    r21 = _f_65;
    r22 = _f_66;
    r23 = _namespace_7;
    r24 = _name_7;
    r25 = _all_7;
    r26 = _x_2;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K184)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    u32 _r_4 = r4;
    u32 _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    u32 _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    u32 _r_14 = r14;
    u32 _r_15 = r15;
    u32 _r_16 = r16;
    Term _r_17 = r17;
    u32 _r_18 = r18;
    Term _r_19 = r19;
    u32 _r_20 = r20;
    Term _r_21 = r21;
    Term _r_22 = r22;
    Term _r_23 = r23;
    u32 _r_24 = r24;
    u32 _r_25 = r25;
    Term _r_26 = r26;
    Term _r_27 = r27;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      u64 _nd_5 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_5 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_5 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_5 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_5 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_5 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_5 + 5] = rfc_seal(e, _r_9);
      e.mem[_nd_5 + 6] = rfc_seal(e, _r_10);
      e.mem[_nd_5 + 7] = rfc_seal(e, _r_11);
      e.mem[_nd_5 + 8] = rfc_seal(e, _r_12);
      e.mem[_nd_5 + 9] = rfc_seal(e, _r_13);
      u64 _nd_6 = heap_alloc(e, cls_fit(18));
      e.mem[_nd_6 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_6 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_6 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_6 + 3] = rfc_seal(e, term_ctr(CID_OWNERS, _nd_5));
      e.mem[_nd_6 + 4] = rfc_seal(e, _r_14);
      e.mem[_nd_6 + 5] = rfc_seal(e, _r_15);
      e.mem[_nd_6 + 6] = rfc_seal(e, _r_16);
      e.mem[_nd_6 + 7] = rfc_seal(e, _r_17);
      e.mem[_nd_6 + 8] = rfc_seal(e, _r_18);
      e.mem[_nd_6 + 9] = rfc_seal(e, _r_19);
      e.mem[_nd_6 + 10] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_6 + 11] = rfc_seal(e, _r_20);
      e.mem[_nd_6 + 12] = rfc_seal(e, _r_21);
      e.mem[_nd_6 + 13] = rfc_seal(e, _r_22);
      e.mem[_nd_6 + 14] = rfc_seal(e, _r_23);
      e.mem[_nd_6 + 15] = rfc_seal(e, _r_24);
      e.mem[_nd_6 + 16] = rfc_seal(e, _r_25);
      e.mem[_nd_6 + 17] = rfc_seal(e, _r_26);
      _b_0 = term_ctr(CID_______SRC_ECS_SCHEDULE_FINISHED, _nd_6);
    } else if (_r_0 == 1) {
      u64 _nd_7 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_7 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_7 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_7 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_7 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_7 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_7 + 5] = rfc_seal(e, _r_9);
      e.mem[_nd_7 + 6] = rfc_seal(e, _r_10);
      e.mem[_nd_7 + 7] = rfc_seal(e, _r_11);
      e.mem[_nd_7 + 8] = rfc_seal(e, _r_12);
      e.mem[_nd_7 + 9] = rfc_seal(e, _r_13);
      u64 _nd_8 = heap_alloc(e, cls_fit(19));
      e.mem[_nd_8 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_8 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_8 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_8 + 3] = rfc_seal(e, term_ctr(CID_OWNERS, _nd_7));
      e.mem[_nd_8 + 4] = rfc_seal(e, _r_14);
      e.mem[_nd_8 + 5] = rfc_seal(e, _r_15);
      e.mem[_nd_8 + 6] = rfc_seal(e, _r_16);
      e.mem[_nd_8 + 7] = rfc_seal(e, _r_17);
      e.mem[_nd_8 + 8] = rfc_seal(e, _r_18);
      e.mem[_nd_8 + 9] = rfc_seal(e, _r_19);
      e.mem[_nd_8 + 10] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_8 + 11] = rfc_seal(e, _r_20);
      e.mem[_nd_8 + 12] = rfc_seal(e, _r_21);
      e.mem[_nd_8 + 13] = rfc_seal(e, _r_22);
      e.mem[_nd_8 + 14] = rfc_seal(e, _r_23);
      e.mem[_nd_8 + 15] = rfc_seal(e, _r_24);
      e.mem[_nd_8 + 16] = rfc_seal(e, _r_25);
      e.mem[_nd_8 + 17] = rfc_seal(e, _r_26);
      e.mem[_nd_8 + 18] = rfc_seal(e, _r_27);
      _b_0 = term_ctr(CID_______SRC_ECS_SCHEDULE_FAILED, _nd_8);
    } else {
      u64 _nd_9 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_9 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_9 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_9 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_9 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_9 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_9 + 5] = rfc_seal(e, _r_9);
      e.mem[_nd_9 + 6] = rfc_seal(e, _r_10);
      e.mem[_nd_9 + 7] = rfc_seal(e, _r_11);
      e.mem[_nd_9 + 8] = rfc_seal(e, _r_12);
      e.mem[_nd_9 + 9] = rfc_seal(e, _r_13);
      u64 _nd_10 = heap_alloc(e, cls_fit(17));
      e.mem[_nd_10 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_10 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_10 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_10 + 3] = rfc_seal(e, term_ctr(CID_OWNERS, _nd_9));
      e.mem[_nd_10 + 4] = rfc_seal(e, _r_14);
      e.mem[_nd_10 + 5] = rfc_seal(e, _r_15);
      e.mem[_nd_10 + 6] = rfc_seal(e, _r_16);
      e.mem[_nd_10 + 7] = rfc_seal(e, _r_17);
      e.mem[_nd_10 + 8] = rfc_seal(e, _r_18);
      e.mem[_nd_10 + 9] = rfc_seal(e, _r_19);
      e.mem[_nd_10 + 10] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_10 + 11] = rfc_seal(e, _r_20);
      e.mem[_nd_10 + 12] = rfc_seal(e, _r_21);
      e.mem[_nd_10 + 13] = rfc_seal(e, _r_22);
      e.mem[_nd_10 + 14] = rfc_seal(e, _r_23);
      e.mem[_nd_10 + 15] = rfc_seal(e, _r_24);
      e.mem[_nd_10 + 16] = rfc_seal(e, _r_25);
      _b_0 = term_ctr(CID_______SRC_ECS_SCHEDULE_REJECTED, _nd_10);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K185)
  {
    WL_POPN(14);
    u32 _h_40 = STK(0);
    u32 _h_41 = STK(1);
    u32 _h_42 = STK(2);
    Term _h_43 = STK(3);
    u32 _h_44 = STK(4);
    Term _h_45 = STK(5);
    u32 _h_46 = STK(6);
    Term _h_47 = STK(7);
    Term _h_48 = STK(8);
    Term _h_49 = STK(9);
    u32 _h_50 = STK(10);
    u32 _h_51 = STK(11);
    Term _observations_3 = STK(12);
    u32 _o_4 = STK(13);
    Term _h_39 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_12 + 0] = rfc_seal(e, _h_40);
    e.mem[_nd_12 + 1] = rfc_seal(e, _h_41);
    e.mem[_nd_12 + 2] = rfc_seal(e, _h_42);
    e.mem[_nd_12 + 3] = rfc_seal(e, _h_43);
    e.mem[_nd_12 + 4] = rfc_seal(e, _h_44);
    e.mem[_nd_12 + 5] = rfc_seal(e, _h_45);
    e.mem[_nd_12 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_12 + 7] = rfc_seal(e, _h_46);
    e.mem[_nd_12 + 8] = rfc_seal(e, _h_47);
    e.mem[_nd_12 + 9] = rfc_seal(e, _h_48);
    e.mem[_nd_12 + 10] = rfc_seal(e, _h_49);
    e.mem[_nd_12 + 11] = rfc_seal(e, _h_50);
    e.mem[_nd_12 + 12] = rfc_seal(e, _h_51);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _observations_3;
      STK(1) = _o_4;
      STK(2) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K186;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _observations_3;
      e.mem[_t_14 + 1] = _o_4;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K186, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_15 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_39;
      e.mem[_t_15 + 1] = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_12);
      return term_tsk(FID_CLO_APPLY, _t_15);
    }
    r0 = _h_39;
    r1 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_12);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K186)
  {
    WL_POPN(2);
    Term _observations_4 = STK(0);
    u32 _o_5 = STK(1);
    Term _h_52 = r0;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_______SRC_ECS_SCHEDULE_SKIPPED, _o_5));
    e.mem[_nd_13 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_52;
      STK(1) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K187;
      WL_PUSHN(2);
    } else {
      u64 _t_16 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_52;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K187, _t_16);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_17 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _observations_4;
      e.mem[_t_17 + 1] = term_ctr(CID_CON, _nd_13);
      return term_tsk(FID_LIST_APPEND, _t_17);
    }
    r0 = _observations_4;
    r1 = term_ctr(CID_CON, _nd_13);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K187)
  {
    WL_POPN(1);
    Term _h_54 = STK(0);
    Term _h_53 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K188;
      WL_PUSHN(1);
    } else {
      u64 _t_18 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K188, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K188, _t_18);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_19 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_54;
      e.mem[_t_19 + 1] = _h_53;
      return term_tsk(FID_CLO_APPLY, _t_19);
    }
    r0 = _h_54;
    r1 = _h_53;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K188)
  {
    Term _r_28 = r0;
    WL_OPEN
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    Term _o_17 = 0;
    Term _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    Term _o_23 = 0;
    u32 _o_24 = 0;
    Term _o_25 = 0;
    u32 _o_26 = 0;
    Term _o_27 = 0;
    Term _o_28 = 0;
    Term _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    Term _o_32 = 0;
    Term _o_33 = 0;
    if (term_aux(_r_28) == CID_______SRC_ECS_SCHEDULE_FINISHED) {
      _o_6 = 0;
      Term _fb_5[18];
      u64 _sp_5 = ctr_take(e, _r_28, 18, _fb_5);
      u32 _f_67 = _fb_5[0];
      Term _f_68 = _fb_5[1];
      Term _f_69 = _fb_5[2];
      Term _f_70 = _fb_5[3];
      u32 _f_71 = _fb_5[4];
      u32 _f_72 = _fb_5[5];
      u32 _f_73 = _fb_5[6];
      Term _f_74 = _fb_5[7];
      u32 _f_75 = _fb_5[8];
      Term _f_76 = _fb_5[9];
      Term _f_77 = _fb_5[10];
      Term _f_78 = _fb_5[11];
      Term _f_79 = _fb_5[12];
      Term _f_80 = _fb_5[13];
      Term _f_81 = _fb_5[14];
      u32 _f_82 = _fb_5[15];
      u32 _f_83 = _fb_5[16];
      Term _f_84 = _fb_5[17];
      spare_free(e, cls_fit(18), _sp_5);
      Term _fb_6[10];
      u64 _sp_6 = ctr_take(e, _f_70, 10, _fb_6);
      u32 _f_85 = _fb_6[0];
      u32 _f_86 = _fb_6[1];
      Term _f_87 = _fb_6[2];
      Term _f_88 = _fb_6[3];
      u32 _f_89 = _fb_6[4];
      u32 _f_90 = _fb_6[5];
      u32 _f_91 = _fb_6[6];
      Term _f_92 = _fb_6[7];
      Term _f_93 = _fb_6[8];
      u32 _f_94 = _fb_6[9];
      spare_free(e, cls_fit(10), _sp_6);
      _o_7 = _f_67;
      _o_8 = _f_68;
      _o_9 = _f_69;
      _o_10 = _f_85;
      _o_11 = _f_86;
      _o_12 = _f_87;
      _o_13 = _f_88;
      _o_14 = _f_89;
      _o_15 = _f_90;
      _o_16 = _f_91;
      _o_17 = _f_92;
      _o_18 = _f_93;
      _o_19 = _f_94;
      _o_20 = _f_71;
      _o_21 = _f_72;
      _o_22 = _f_73;
      _o_23 = _f_74;
      _o_24 = _f_75;
      _o_25 = _f_76;
      _o_26 = _f_78;
      _o_27 = _f_79;
      _o_28 = _f_80;
      _o_29 = _f_81;
      _o_30 = _f_82;
      _o_31 = _f_83;
      _o_32 = _f_84;
    } else if (term_aux(_r_28) == CID_______SRC_ECS_SCHEDULE_FAILED) {
      _o_6 = 1;
      Term _fb_7[19];
      u64 _sp_7 = ctr_take(e, _r_28, 19, _fb_7);
      u32 _f_95 = _fb_7[0];
      Term _f_96 = _fb_7[1];
      Term _f_97 = _fb_7[2];
      Term _f_98 = _fb_7[3];
      u32 _f_99 = _fb_7[4];
      u32 _f_100 = _fb_7[5];
      u32 _f_101 = _fb_7[6];
      Term _f_102 = _fb_7[7];
      u32 _f_103 = _fb_7[8];
      Term _f_104 = _fb_7[9];
      Term _f_105 = _fb_7[10];
      Term _f_106 = _fb_7[11];
      Term _f_107 = _fb_7[12];
      Term _f_108 = _fb_7[13];
      Term _f_109 = _fb_7[14];
      u32 _f_110 = _fb_7[15];
      u32 _f_111 = _fb_7[16];
      Term _f_112 = _fb_7[17];
      Term _f_113 = _fb_7[18];
      spare_free(e, cls_fit(19), _sp_7);
      Term _fb_8[10];
      u64 _sp_8 = ctr_take(e, _f_98, 10, _fb_8);
      u32 _f_114 = _fb_8[0];
      u32 _f_115 = _fb_8[1];
      Term _f_116 = _fb_8[2];
      Term _f_117 = _fb_8[3];
      u32 _f_118 = _fb_8[4];
      u32 _f_119 = _fb_8[5];
      u32 _f_120 = _fb_8[6];
      Term _f_121 = _fb_8[7];
      Term _f_122 = _fb_8[8];
      u32 _f_123 = _fb_8[9];
      spare_free(e, cls_fit(10), _sp_8);
      _o_7 = _f_95;
      _o_8 = _f_96;
      _o_9 = _f_97;
      _o_10 = _f_114;
      _o_11 = _f_115;
      _o_12 = _f_116;
      _o_13 = _f_117;
      _o_14 = _f_118;
      _o_15 = _f_119;
      _o_16 = _f_120;
      _o_17 = _f_121;
      _o_18 = _f_122;
      _o_19 = _f_123;
      _o_20 = _f_99;
      _o_21 = _f_100;
      _o_22 = _f_101;
      _o_23 = _f_102;
      _o_24 = _f_103;
      _o_25 = _f_104;
      _o_26 = _f_106;
      _o_27 = _f_107;
      _o_28 = _f_108;
      _o_29 = _f_109;
      _o_30 = _f_110;
      _o_31 = _f_111;
      _o_32 = _f_112;
      _o_33 = _f_113;
    } else {
      _o_6 = 2;
      Term _fb_9[17];
      u64 _sp_9 = ctr_take(e, _r_28, 17, _fb_9);
      u32 _f_124 = _fb_9[0];
      Term _f_125 = _fb_9[1];
      Term _f_126 = _fb_9[2];
      Term _f_127 = _fb_9[3];
      u32 _f_128 = _fb_9[4];
      u32 _f_129 = _fb_9[5];
      u32 _f_130 = _fb_9[6];
      Term _f_131 = _fb_9[7];
      u32 _f_132 = _fb_9[8];
      Term _f_133 = _fb_9[9];
      Term _f_134 = _fb_9[10];
      Term _f_135 = _fb_9[11];
      Term _f_136 = _fb_9[12];
      Term _f_137 = _fb_9[13];
      Term _f_138 = _fb_9[14];
      u32 _f_139 = _fb_9[15];
      u32 _f_140 = _fb_9[16];
      spare_free(e, cls_fit(17), _sp_9);
      Term _fb_10[10];
      u64 _sp_10 = ctr_take(e, _f_127, 10, _fb_10);
      u32 _f_141 = _fb_10[0];
      u32 _f_142 = _fb_10[1];
      Term _f_143 = _fb_10[2];
      Term _f_144 = _fb_10[3];
      u32 _f_145 = _fb_10[4];
      u32 _f_146 = _fb_10[5];
      u32 _f_147 = _fb_10[6];
      Term _f_148 = _fb_10[7];
      Term _f_149 = _fb_10[8];
      u32 _f_150 = _fb_10[9];
      spare_free(e, cls_fit(10), _sp_10);
      _o_7 = _f_124;
      _o_8 = _f_125;
      _o_9 = _f_126;
      _o_10 = _f_141;
      _o_11 = _f_142;
      _o_12 = _f_143;
      _o_13 = _f_144;
      _o_14 = _f_145;
      _o_15 = _f_146;
      _o_16 = _f_147;
      _o_17 = _f_148;
      _o_18 = _f_149;
      _o_19 = _f_150;
      _o_20 = _f_128;
      _o_21 = _f_129;
      _o_22 = _f_130;
      _o_23 = _f_131;
      _o_24 = _f_132;
      _o_25 = _f_133;
      _o_26 = _f_135;
      _o_27 = _f_136;
      _o_28 = _f_137;
      _o_29 = _f_138;
      _o_30 = _f_139;
      _o_31 = _f_140;
    }
    r0 = _o_6;
    r1 = _o_7;
    r2 = _o_8;
    r3 = _o_9;
    r4 = _o_10;
    r5 = _o_11;
    r6 = _o_12;
    r7 = _o_13;
    r8 = _o_14;
    r9 = _o_15;
    r10 = _o_16;
    r11 = _o_17;
    r12 = _o_18;
    r13 = _o_19;
    r14 = _o_20;
    r15 = _o_21;
    r16 = _o_22;
    r17 = _o_23;
    r18 = _o_24;
    r19 = _o_25;
    r20 = _o_26;
    r21 = _o_27;
    r22 = _o_28;
    r23 = _o_29;
    r24 = _o_30;
    r25 = _o_31;
    r26 = _o_32;
    r27 = _o_33;
    WL_RETN(28);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_1_K189)
  {
    WL_POPN(6);
    Term _next_1 = STK(0);
    u32 _namespace_8 = STK(1);
    Term _name_8 = STK(2);
    Term _all_8 = STK(3);
    Term _observations_5 = STK(4);
    u32 _o_34 = STK(5);
    u32 _h_55 = r0;
    u32 _h_56 = r1;
    Term _h_57 = r2;
    Term _h_58 = r3;
    u32 _h_59 = r4;
    u32 _h_60 = r5;
    u32 _h_61 = r6;
    Term _h_62 = r7;
    Term _h_63 = r8;
    u32 _h_64 = r9;
    u32 _h_65 = r10;
    u32 _h_66 = r11;
    u32 _h_67 = r12;
    u32 _h_68 = r13;
    Term _h_69 = r14;
    u32 _h_70 = r15;
    Term _h_71 = r16;
    u32 _h_72 = r17;
    Term _h_73 = r18;
    Term _h_74 = r19;
    Term _h_75 = r20;
    u32 _h_76 = r21;
    u32 _h_77 = r22;
    Term _h_78 = r23;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0)) {
      u64 _t_22 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _next_1;
      e.mem[_t_22 + 1] = _h_55;
      e.mem[_t_22 + 2] = _h_56;
      e.mem[_t_22 + 3] = _h_57;
      e.mem[_t_22 + 4] = _h_58;
      e.mem[_t_22 + 5] = _h_59;
      e.mem[_t_22 + 6] = _h_60;
      e.mem[_t_22 + 7] = _h_61;
      e.mem[_t_22 + 8] = _h_62;
      e.mem[_t_22 + 9] = _h_63;
      e.mem[_t_22 + 10] = _h_64;
      e.mem[_t_22 + 11] = _h_65;
      e.mem[_t_22 + 12] = _h_66;
      e.mem[_t_22 + 13] = _h_67;
      e.mem[_t_22 + 14] = _h_68;
      e.mem[_t_22 + 15] = _h_69;
      e.mem[_t_22 + 16] = _h_70;
      e.mem[_t_22 + 17] = _h_71;
      e.mem[_t_22 + 18] = _h_72;
      e.mem[_t_22 + 19] = _h_73;
      e.mem[_t_22 + 20] = _h_74;
      e.mem[_t_22 + 21] = _h_75;
      e.mem[_t_22 + 22] = _h_76;
      e.mem[_t_22 + 23] = _h_77;
      e.mem[_t_22 + 24] = _h_78;
      e.mem[_t_22 + 25] = _namespace_8;
      e.mem[_t_22 + 26] = _name_8;
      e.mem[_t_22 + 27] = _all_8;
      e.mem[_t_22 + 28] = _observations_5;
      e.mem[_t_22 + 29] = _o_34;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0, _t_22);
    }
    r0 = _next_1;
    r1 = _h_55;
    r2 = _h_56;
    r3 = _h_57;
    r4 = _h_58;
    r5 = _h_59;
    r6 = _h_60;
    r7 = _h_61;
    r8 = _h_62;
    r9 = _h_63;
    r10 = _h_64;
    r11 = _h_65;
    r12 = _h_66;
    r13 = _h_67;
    r14 = _h_68;
    r15 = _h_69;
    r16 = _h_70;
    r17 = _h_71;
    r18 = _h_72;
    r19 = _h_73;
    r20 = _h_74;
    r21 = _h_75;
    r22 = _h_76;
    r23 = _h_77;
    r24 = _h_78;
    r25 = _namespace_8;
    r26 = _name_8;
    r27 = _all_8;
    r28 = _observations_5;
    r29 = _o_34;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0)
  {
    Term _steps_0 = r0;
    u32 _owners_0 = r1;
    u32 _owners_1 = r2;
    Term _owners_2 = r3;
    Term _owners_3 = r4;
    u32 _owners_4 = r5;
    u32 _owners_5 = r6;
    u32 _owners_6 = r7;
    Term _owners_7 = r8;
    Term _owners_8 = r9;
    u32 _owners_9 = r10;
    u32 _world_0 = r11;
    u32 _world_1 = r12;
    u32 _world_2 = r13;
    Term _world_3 = r14;
    u32 _world_4 = r15;
    Term _world_5 = r16;
    u32 _world_6 = r17;
    Term _world_7 = r18;
    Term _world_8 = r19;
    Term _world_9 = r20;
    u32 _world_10 = r21;
    u32 _world_11 = r22;
    u32 _namespace_0 = r23;
    Term _name_0 = r24;
    Term _all_0 = r25;
    Term _observations_0 = r26;
    WL_OPEN
    if (term_aux(_steps_0) == CID_NIL) {
      r0 = 0;
      r1 = _namespace_0;
      r2 = _name_0;
      r3 = _all_0;
      r4 = _owners_0;
      r5 = _owners_1;
      r6 = _owners_2;
      r7 = _owners_3;
      r8 = _owners_4;
      r9 = _owners_5;
      r10 = _owners_6;
      r11 = _owners_7;
      r12 = _owners_8;
      r13 = _owners_9;
      r14 = _world_0;
      r15 = _world_1;
      r16 = _world_2;
      r17 = _world_3;
      r18 = _world_4;
      r19 = _world_5;
      r20 = _world_6;
      r21 = _world_7;
      r22 = _world_8;
      r23 = _world_9;
      r24 = _world_10;
      r25 = _world_11;
      r26 = _observations_0;
      r27 = 0;
      WL_RETN(28);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_SYSTEM) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_PHASE) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else {
        _o_0 = 2;
      }
      if (_o_0 == 1) {
        u64 _nd_0 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_0 + 0] = rfc_seal(e, _o_1);
        u64 _nd_1 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_______SRC_ECS_SCHEDULE_ENTERED, _nd_0));
        e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        if (seq) {
          WL_ROOM(27);
          STK(0) = _f_1;
          STK(1) = _owners_0;
          STK(2) = _owners_1;
          STK(3) = _owners_2;
          STK(4) = _owners_3;
          STK(5) = _owners_4;
          STK(6) = _owners_5;
          STK(7) = _owners_6;
          STK(8) = _owners_7;
          STK(9) = _owners_8;
          STK(10) = _owners_9;
          STK(11) = _world_0;
          STK(12) = _world_1;
          STK(13) = _world_2;
          STK(14) = _world_3;
          STK(15) = _world_4;
          STK(16) = _world_5;
          STK(17) = _world_6;
          STK(18) = _world_7;
          STK(19) = _world_8;
          STK(20) = _world_9;
          STK(21) = _world_10;
          STK(22) = _world_11;
          STK(23) = _namespace_0;
          STK(24) = _name_0;
          STK(25) = _all_0;
          STK(26) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K191;
          WL_PUSHN(27);
        } else {
          u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K191, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _owners_0;
          e.mem[_t_0 + 2] = _owners_1;
          e.mem[_t_0 + 3] = _owners_2;
          e.mem[_t_0 + 4] = _owners_3;
          e.mem[_t_0 + 5] = _owners_4;
          e.mem[_t_0 + 6] = _owners_5;
          e.mem[_t_0 + 7] = _owners_6;
          e.mem[_t_0 + 8] = _owners_7;
          e.mem[_t_0 + 9] = _owners_8;
          e.mem[_t_0 + 10] = _owners_9;
          e.mem[_t_0 + 11] = _world_0;
          e.mem[_t_0 + 12] = _world_1;
          e.mem[_t_0 + 13] = _world_2;
          e.mem[_t_0 + 14] = _world_3;
          e.mem[_t_0 + 15] = _world_4;
          e.mem[_t_0 + 16] = _world_5;
          e.mem[_t_0 + 17] = _world_6;
          e.mem[_t_0 + 18] = _world_7;
          e.mem[_t_0 + 19] = _world_8;
          e.mem[_t_0 + 20] = _world_9;
          e.mem[_t_0 + 21] = _world_10;
          e.mem[_t_0 + 22] = _world_11;
          e.mem[_t_0 + 23] = _namespace_0;
          e.mem[_t_0 + 24] = _name_0;
          e.mem[_t_0 + 25] = _all_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K191, _t_0);
          WL_IDX = 26;
        }
        if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
          u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _observations_0;
          e.mem[_t_1 + 1] = term_ctr(CID_CON, _nd_1);
          return term_tsk(FID_LIST_APPEND, _t_1);
        }
        r0 = _observations_0;
        r1 = term_ctr(CID_CON, _nd_1);
        WL_JMP(FID_LIST_APPEND);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(16);
          STK(0) = _f_1;
          STK(1) = _owners_0;
          STK(2) = _owners_1;
          STK(3) = _owners_2;
          STK(4) = _owners_3;
          STK(5) = _owners_4;
          STK(6) = _owners_5;
          STK(7) = _owners_6;
          STK(8) = _owners_7;
          STK(9) = _owners_8;
          STK(10) = _owners_9;
          STK(11) = _namespace_0;
          STK(12) = _name_0;
          STK(13) = _all_0;
          STK(14) = _observations_0;
          STK(15) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K192;
          WL_PUSHN(16);
        } else {
          u64 _t_3 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K192, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_1;
          e.mem[_t_3 + 1] = _owners_0;
          e.mem[_t_3 + 2] = _owners_1;
          e.mem[_t_3 + 3] = _owners_2;
          e.mem[_t_3 + 4] = _owners_3;
          e.mem[_t_3 + 5] = _owners_4;
          e.mem[_t_3 + 6] = _owners_5;
          e.mem[_t_3 + 7] = _owners_6;
          e.mem[_t_3 + 8] = _owners_7;
          e.mem[_t_3 + 9] = _owners_8;
          e.mem[_t_3 + 10] = _owners_9;
          e.mem[_t_3 + 11] = _namespace_0;
          e.mem[_t_3 + 12] = _name_0;
          e.mem[_t_3 + 13] = _all_0;
          e.mem[_t_3 + 14] = _observations_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K192, _t_3);
          WL_IDX = 15;
        }
        if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_BARRIER_0)) {
          u64 _t_4 = task_node(e, FID_______SRC_ECS_WORLD_BARRIER_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _world_0;
          e.mem[_t_4 + 1] = _world_1;
          e.mem[_t_4 + 2] = _world_2;
          e.mem[_t_4 + 3] = _world_3;
          e.mem[_t_4 + 4] = _world_4;
          e.mem[_t_4 + 5] = _world_5;
          e.mem[_t_4 + 6] = _world_6;
          e.mem[_t_4 + 7] = _world_7;
          e.mem[_t_4 + 8] = _world_8;
          e.mem[_t_4 + 9] = _world_9;
          e.mem[_t_4 + 10] = _world_10;
          e.mem[_t_4 + 11] = _world_11;
          return term_tsk(FID_______SRC_ECS_WORLD_BARRIER_0, _t_4);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        WL_JMP(FID_______SRC_ECS_WORLD_BARRIER_0);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(17);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _owners_0;
          STK(3) = _owners_1;
          STK(4) = _owners_2;
          STK(5) = _owners_3;
          STK(6) = _owners_4;
          STK(7) = _owners_5;
          STK(8) = _owners_6;
          STK(9) = _owners_7;
          STK(10) = _owners_8;
          STK(11) = _owners_9;
          STK(12) = _namespace_0;
          STK(13) = _name_0;
          STK(14) = _all_0;
          STK(15) = _observations_0;
          STK(16) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K194;
          WL_PUSHN(17);
        } else {
          u64 _t_8 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K194, WL_CONT, WL_IDX, 1);
          e.mem[_t_8 + 0] = _o_1;
          e.mem[_t_8 + 1] = _f_1;
          e.mem[_t_8 + 2] = _owners_0;
          e.mem[_t_8 + 3] = _owners_1;
          e.mem[_t_8 + 4] = _owners_2;
          e.mem[_t_8 + 5] = _owners_3;
          e.mem[_t_8 + 6] = _owners_4;
          e.mem[_t_8 + 7] = _owners_5;
          e.mem[_t_8 + 8] = _owners_6;
          e.mem[_t_8 + 9] = _owners_7;
          e.mem[_t_8 + 10] = _owners_8;
          e.mem[_t_8 + 11] = _owners_9;
          e.mem[_t_8 + 12] = _namespace_0;
          e.mem[_t_8 + 13] = _name_0;
          e.mem[_t_8 + 14] = _all_0;
          e.mem[_t_8 + 15] = _observations_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K194, _t_8);
          WL_IDX = 16;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CONDITION)) {
          u64 _t_9 = task_node(e, FID_CONDITION, WL_CONT, WL_IDX, 0);
          e.mem[_t_9 + 0] = _world_0;
          e.mem[_t_9 + 1] = _world_1;
          e.mem[_t_9 + 2] = _world_2;
          e.mem[_t_9 + 3] = _world_3;
          e.mem[_t_9 + 4] = _world_4;
          e.mem[_t_9 + 5] = _world_5;
          e.mem[_t_9 + 6] = _world_6;
          e.mem[_t_9 + 7] = _world_7;
          e.mem[_t_9 + 8] = _world_8;
          e.mem[_t_9 + 9] = _world_9;
          e.mem[_t_9 + 10] = _world_10;
          e.mem[_t_9 + 11] = _world_11;
          e.mem[_t_9 + 12] = _o_2;
          return term_tsk(FID_CONDITION, _t_9);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _o_2;
        WL_JMP(FID_CONDITION);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K191)
  {
    WL_POPN(26);
    Term _f_5 = STK(0);
    u32 _owners_10 = STK(1);
    u32 _owners_11 = STK(2);
    Term _owners_12 = STK(3);
    Term _owners_13 = STK(4);
    u32 _owners_14 = STK(5);
    u32 _owners_15 = STK(6);
    u32 _owners_16 = STK(7);
    Term _owners_17 = STK(8);
    Term _owners_18 = STK(9);
    u32 _owners_19 = STK(10);
    u32 _world_12 = STK(11);
    u32 _world_13 = STK(12);
    u32 _world_14 = STK(13);
    Term _world_15 = STK(14);
    u32 _world_16 = STK(15);
    Term _world_17 = STK(16);
    u32 _world_18 = STK(17);
    Term _world_19 = STK(18);
    Term _world_20 = STK(19);
    Term _world_21 = STK(20);
    u32 _world_22 = STK(21);
    u32 _world_23 = STK(22);
    u32 _namespace_1 = STK(23);
    Term _name_1 = STK(24);
    Term _all_1 = STK(25);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0)) {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _owners_10;
      e.mem[_t_2 + 2] = _owners_11;
      e.mem[_t_2 + 3] = _owners_12;
      e.mem[_t_2 + 4] = _owners_13;
      e.mem[_t_2 + 5] = _owners_14;
      e.mem[_t_2 + 6] = _owners_15;
      e.mem[_t_2 + 7] = _owners_16;
      e.mem[_t_2 + 8] = _owners_17;
      e.mem[_t_2 + 9] = _owners_18;
      e.mem[_t_2 + 10] = _owners_19;
      e.mem[_t_2 + 11] = _world_12;
      e.mem[_t_2 + 12] = _world_13;
      e.mem[_t_2 + 13] = _world_14;
      e.mem[_t_2 + 14] = _world_15;
      e.mem[_t_2 + 15] = _world_16;
      e.mem[_t_2 + 16] = _world_17;
      e.mem[_t_2 + 17] = _world_18;
      e.mem[_t_2 + 18] = _world_19;
      e.mem[_t_2 + 19] = _world_20;
      e.mem[_t_2 + 20] = _world_21;
      e.mem[_t_2 + 21] = _world_22;
      e.mem[_t_2 + 22] = _world_23;
      e.mem[_t_2 + 23] = _namespace_1;
      e.mem[_t_2 + 24] = _name_1;
      e.mem[_t_2 + 25] = _all_1;
      e.mem[_t_2 + 26] = _h_0;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0, _t_2);
    }
    r0 = _f_5;
    r1 = _owners_10;
    r2 = _owners_11;
    r3 = _owners_12;
    r4 = _owners_13;
    r5 = _owners_14;
    r6 = _owners_15;
    r7 = _owners_16;
    r8 = _owners_17;
    r9 = _owners_18;
    r10 = _owners_19;
    r11 = _world_12;
    r12 = _world_13;
    r13 = _world_14;
    r14 = _world_15;
    r15 = _world_16;
    r16 = _world_17;
    r17 = _world_18;
    r18 = _world_19;
    r19 = _world_20;
    r20 = _world_21;
    r21 = _world_22;
    r22 = _world_23;
    r23 = _namespace_1;
    r24 = _name_1;
    r25 = _all_1;
    r26 = _h_0;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K192)
  {
    WL_POPN(15);
    Term _f_6 = STK(0);
    u32 _owners_20 = STK(1);
    u32 _owners_21 = STK(2);
    Term _owners_22 = STK(3);
    Term _owners_23 = STK(4);
    u32 _owners_24 = STK(5);
    u32 _owners_25 = STK(6);
    u32 _owners_26 = STK(7);
    Term _owners_27 = STK(8);
    Term _owners_28 = STK(9);
    u32 _owners_29 = STK(10);
    u32 _namespace_2 = STK(11);
    Term _name_2 = STK(12);
    Term _all_2 = STK(13);
    Term _observations_1 = STK(14);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    u32 _h_3 = r2;
    Term _h_4 = r3;
    u32 _h_5 = r4;
    Term _h_6 = r5;
    u32 _h_7 = r6;
    Term _h_8 = r7;
    Term _h_9 = r8;
    Term _h_10 = r9;
    u32 _h_11 = r10;
    u32 _h_12 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _f_6;
      STK(1) = _owners_20;
      STK(2) = _owners_21;
      STK(3) = _owners_22;
      STK(4) = _owners_23;
      STK(5) = _owners_24;
      STK(6) = _owners_25;
      STK(7) = _owners_26;
      STK(8) = _owners_27;
      STK(9) = _owners_28;
      STK(10) = _owners_29;
      STK(11) = _namespace_2;
      STK(12) = _name_2;
      STK(13) = _all_2;
      STK(14) = _h_1;
      STK(15) = _h_2;
      STK(16) = _h_3;
      STK(17) = _h_4;
      STK(18) = _h_5;
      STK(19) = _h_6;
      STK(20) = _h_7;
      STK(21) = _h_8;
      STK(22) = _h_9;
      STK(23) = _h_10;
      STK(24) = _h_11;
      STK(25) = _h_12;
      STK(26) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K193;
      WL_PUSHN(27);
    } else {
      u64 _t_5 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = _owners_20;
      e.mem[_t_5 + 2] = _owners_21;
      e.mem[_t_5 + 3] = _owners_22;
      e.mem[_t_5 + 4] = _owners_23;
      e.mem[_t_5 + 5] = _owners_24;
      e.mem[_t_5 + 6] = _owners_25;
      e.mem[_t_5 + 7] = _owners_26;
      e.mem[_t_5 + 8] = _owners_27;
      e.mem[_t_5 + 9] = _owners_28;
      e.mem[_t_5 + 10] = _owners_29;
      e.mem[_t_5 + 11] = _namespace_2;
      e.mem[_t_5 + 12] = _name_2;
      e.mem[_t_5 + 13] = _all_2;
      e.mem[_t_5 + 14] = _h_1;
      e.mem[_t_5 + 15] = _h_2;
      e.mem[_t_5 + 16] = _h_3;
      e.mem[_t_5 + 17] = _h_4;
      e.mem[_t_5 + 18] = _h_5;
      e.mem[_t_5 + 19] = _h_6;
      e.mem[_t_5 + 20] = _h_7;
      e.mem[_t_5 + 21] = _h_8;
      e.mem[_t_5 + 22] = _h_9;
      e.mem[_t_5 + 23] = _h_10;
      e.mem[_t_5 + 24] = _h_11;
      e.mem[_t_5 + 25] = _h_12;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K193, _t_5);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_6 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _observations_1;
      e.mem[_t_6 + 1] = term_ctr(CID_CON, STAT_OFF + 54);
      return term_tsk(FID_LIST_APPEND, _t_6);
    }
    r0 = _observations_1;
    r1 = term_ctr(CID_CON, STAT_OFF + 54);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K193)
  {
    WL_POPN(26);
    Term _f_7 = STK(0);
    u32 _owners_30 = STK(1);
    u32 _owners_31 = STK(2);
    Term _owners_32 = STK(3);
    Term _owners_33 = STK(4);
    u32 _owners_34 = STK(5);
    u32 _owners_35 = STK(6);
    u32 _owners_36 = STK(7);
    Term _owners_37 = STK(8);
    Term _owners_38 = STK(9);
    u32 _owners_39 = STK(10);
    u32 _namespace_3 = STK(11);
    Term _name_3 = STK(12);
    Term _all_3 = STK(13);
    u32 _h_14 = STK(14);
    u32 _h_15 = STK(15);
    u32 _h_16 = STK(16);
    Term _h_17 = STK(17);
    u32 _h_18 = STK(18);
    Term _h_19 = STK(19);
    u32 _h_20 = STK(20);
    Term _h_21 = STK(21);
    Term _h_22 = STK(22);
    Term _h_23 = STK(23);
    u32 _h_24 = STK(24);
    u32 _h_25 = STK(25);
    Term _h_13 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0)) {
      u64 _t_7 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_7;
      e.mem[_t_7 + 1] = _owners_30;
      e.mem[_t_7 + 2] = _owners_31;
      e.mem[_t_7 + 3] = _owners_32;
      e.mem[_t_7 + 4] = _owners_33;
      e.mem[_t_7 + 5] = _owners_34;
      e.mem[_t_7 + 6] = _owners_35;
      e.mem[_t_7 + 7] = _owners_36;
      e.mem[_t_7 + 8] = _owners_37;
      e.mem[_t_7 + 9] = _owners_38;
      e.mem[_t_7 + 10] = _owners_39;
      e.mem[_t_7 + 11] = _h_14;
      e.mem[_t_7 + 12] = _h_15;
      e.mem[_t_7 + 13] = _h_16;
      e.mem[_t_7 + 14] = _h_17;
      e.mem[_t_7 + 15] = _h_18;
      e.mem[_t_7 + 16] = _h_19;
      e.mem[_t_7 + 17] = _h_20;
      e.mem[_t_7 + 18] = _h_21;
      e.mem[_t_7 + 19] = _h_22;
      e.mem[_t_7 + 20] = _h_23;
      e.mem[_t_7 + 21] = _h_24;
      e.mem[_t_7 + 22] = _h_25;
      e.mem[_t_7 + 23] = _namespace_3;
      e.mem[_t_7 + 24] = _name_3;
      e.mem[_t_7 + 25] = _all_3;
      e.mem[_t_7 + 26] = _h_13;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0, _t_7);
    }
    r0 = _f_7;
    r1 = _owners_30;
    r2 = _owners_31;
    r3 = _owners_32;
    r4 = _owners_33;
    r5 = _owners_34;
    r6 = _owners_35;
    r7 = _owners_36;
    r8 = _owners_37;
    r9 = _owners_38;
    r10 = _owners_39;
    r11 = _h_14;
    r12 = _h_15;
    r13 = _h_16;
    r14 = _h_17;
    r15 = _h_18;
    r16 = _h_19;
    r17 = _h_20;
    r18 = _h_21;
    r19 = _h_22;
    r20 = _h_23;
    r21 = _h_24;
    r22 = _h_25;
    r23 = _namespace_3;
    r24 = _name_3;
    r25 = _all_3;
    r26 = _h_13;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K194)
  {
    WL_POPN(16);
    u32 _o_3 = STK(0);
    Term _f_8 = STK(1);
    u32 _owners_40 = STK(2);
    u32 _owners_41 = STK(3);
    Term _owners_42 = STK(4);
    Term _owners_43 = STK(5);
    u32 _owners_44 = STK(6);
    u32 _owners_45 = STK(7);
    u32 _owners_46 = STK(8);
    Term _owners_47 = STK(9);
    Term _owners_48 = STK(10);
    u32 _owners_49 = STK(11);
    u32 _namespace_4 = STK(12);
    Term _name_4 = STK(13);
    Term _all_4 = STK(14);
    Term _observations_2 = STK(15);
    u32 _h_26 = r0;
    u32 _h_27 = r1;
    u32 _h_28 = r2;
    Term _h_29 = r3;
    u32 _h_30 = r4;
    Term _h_31 = r5;
    u32 _h_32 = r6;
    Term _h_33 = r7;
    Term _h_34 = r8;
    Term _h_35 = r9;
    u32 _h_36 = r10;
    u32 _h_37 = r11;
    u32 _h_38 = r12;
    WL_OPEN
    _name_4 = term_keep(e, _name_4, 1);
    _all_4 = term_keep(e, _all_4, 1);
    u64 _nd_2 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_2 + 0] = _f_8;
    e.mem[_nd_2 + 1] = _namespace_4;
    e.mem[_nd_2 + 2] = _name_4;
    e.mem[_nd_2 + 3] = _all_4;
    Term _next_0 = term_clo(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C195, _nd_2);
    if (_h_38 == 0) {
      term_sink(e, _name_4);
      term_sink(e, _all_4);
      u64 _nd_11 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_11 + 0] = rfc_seal(e, _owners_40);
      e.mem[_nd_11 + 1] = rfc_seal(e, _owners_41);
      e.mem[_nd_11 + 2] = rfc_seal(e, _owners_42);
      e.mem[_nd_11 + 3] = rfc_seal(e, _owners_43);
      e.mem[_nd_11 + 4] = rfc_seal(e, _owners_44);
      e.mem[_nd_11 + 5] = rfc_seal(e, _owners_45);
      e.mem[_nd_11 + 6] = rfc_seal(e, _owners_46);
      e.mem[_nd_11 + 7] = rfc_seal(e, _owners_47);
      e.mem[_nd_11 + 8] = rfc_seal(e, _owners_48);
      e.mem[_nd_11 + 9] = rfc_seal(e, _owners_49);
      if (seq) {
        WL_ROOM(15);
        STK(0) = _h_26;
        STK(1) = _h_27;
        STK(2) = _h_28;
        STK(3) = _h_29;
        STK(4) = _h_30;
        STK(5) = _h_31;
        STK(6) = _h_32;
        STK(7) = _h_33;
        STK(8) = _h_34;
        STK(9) = _h_35;
        STK(10) = _h_36;
        STK(11) = _h_37;
        STK(12) = _observations_2;
        STK(13) = _o_3;
        STK(14) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K199;
        WL_PUSHN(15);
      } else {
        u64 _t_12 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K199, WL_CONT, WL_IDX, 1);
        e.mem[_t_12 + 0] = _h_26;
        e.mem[_t_12 + 1] = _h_27;
        e.mem[_t_12 + 2] = _h_28;
        e.mem[_t_12 + 3] = _h_29;
        e.mem[_t_12 + 4] = _h_30;
        e.mem[_t_12 + 5] = _h_31;
        e.mem[_t_12 + 6] = _h_32;
        e.mem[_t_12 + 7] = _h_33;
        e.mem[_t_12 + 8] = _h_34;
        e.mem[_t_12 + 9] = _h_35;
        e.mem[_t_12 + 10] = _h_36;
        e.mem[_t_12 + 11] = _h_37;
        e.mem[_t_12 + 12] = _observations_2;
        e.mem[_t_12 + 13] = _o_3;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K199, _t_12);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_13 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _next_0;
        e.mem[_t_13 + 1] = term_ctr(CID_OWNERS, _nd_11);
        return term_tsk(FID_CLO_APPLY, _t_13);
      }
      r0 = _next_0;
      r1 = term_ctr(CID_OWNERS, _nd_11);
      WL_JMP(FID_CLO_APPLY);
    } else {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _next_0;
        STK(1) = _namespace_4;
        STK(2) = _name_4;
        STK(3) = _all_4;
        STK(4) = _observations_2;
        STK(5) = _o_3;
        STK(6) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K203;
        WL_PUSHN(7);
      } else {
        u64 _t_20 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K203, WL_CONT, WL_IDX, 1);
        e.mem[_t_20 + 0] = _next_0;
        e.mem[_t_20 + 1] = _namespace_4;
        e.mem[_t_20 + 2] = _name_4;
        e.mem[_t_20 + 3] = _all_4;
        e.mem[_t_20 + 4] = _observations_2;
        e.mem[_t_20 + 5] = _o_3;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K203, _t_20);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_DISPATCH)) {
        u64 _t_21 = task_node(e, FID_DISPATCH, WL_CONT, WL_IDX, 0);
        e.mem[_t_21 + 0] = _owners_40;
        e.mem[_t_21 + 1] = _owners_41;
        e.mem[_t_21 + 2] = _owners_42;
        e.mem[_t_21 + 3] = _owners_43;
        e.mem[_t_21 + 4] = _owners_44;
        e.mem[_t_21 + 5] = _owners_45;
        e.mem[_t_21 + 6] = _owners_46;
        e.mem[_t_21 + 7] = _owners_47;
        e.mem[_t_21 + 8] = _owners_48;
        e.mem[_t_21 + 9] = _owners_49;
        e.mem[_t_21 + 10] = _h_26;
        e.mem[_t_21 + 11] = _h_27;
        e.mem[_t_21 + 12] = _h_28;
        e.mem[_t_21 + 13] = _h_29;
        e.mem[_t_21 + 14] = _h_30;
        e.mem[_t_21 + 15] = _h_31;
        e.mem[_t_21 + 16] = _h_32;
        e.mem[_t_21 + 17] = _h_33;
        e.mem[_t_21 + 18] = _h_34;
        e.mem[_t_21 + 19] = _h_35;
        e.mem[_t_21 + 20] = _h_36;
        e.mem[_t_21 + 21] = _h_37;
        e.mem[_t_21 + 22] = _o_3;
        return term_tsk(FID_DISPATCH, _t_21);
      }
      r0 = _owners_40;
      r1 = _owners_41;
      r2 = _owners_42;
      r3 = _owners_43;
      r4 = _owners_44;
      r5 = _owners_45;
      r6 = _owners_46;
      r7 = _owners_47;
      r8 = _owners_48;
      r9 = _owners_49;
      r10 = _h_26;
      r11 = _h_27;
      r12 = _h_28;
      r13 = _h_29;
      r14 = _h_30;
      r15 = _h_31;
      r16 = _h_32;
      r17 = _h_33;
      r18 = _h_34;
      r19 = _h_35;
      r20 = _h_36;
      r21 = _h_37;
      r22 = _o_3;
      WL_JMP(FID_DISPATCH);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C195)
  {
    Term _f_9 = r0;
    u32 _namespace_5 = r1;
    Term _name_5 = r2;
    Term _all_5 = r3;
    Term _x_0 = r4;
    WL_OPEN
    Term _fb_3[10];
    u64 _sp_3 = ctr_take(e, _x_0, 10, _fb_3);
    u32 _f_10 = _fb_3[0];
    u32 _f_11 = _fb_3[1];
    Term _f_12 = _fb_3[2];
    Term _f_13 = _fb_3[3];
    u32 _f_14 = _fb_3[4];
    u32 _f_15 = _fb_3[5];
    u32 _f_16 = _fb_3[6];
    Term _f_17 = _fb_3[7];
    Term _f_18 = _fb_3[8];
    u32 _f_19 = _fb_3[9];
    spare_free(e, cls_fit(10), _sp_3);
    u64 _nd_3 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_3 + 0] = _f_9;
    e.mem[_nd_3 + 1] = _namespace_5;
    e.mem[_nd_3 + 2] = _name_5;
    e.mem[_nd_3 + 3] = _all_5;
    e.mem[_nd_3 + 4] = _f_10;
    e.mem[_nd_3 + 5] = _f_11;
    e.mem[_nd_3 + 6] = _f_12;
    e.mem[_nd_3 + 7] = _f_13;
    e.mem[_nd_3 + 8] = _f_14;
    e.mem[_nd_3 + 9] = _f_15;
    e.mem[_nd_3 + 10] = _f_16;
    e.mem[_nd_3 + 11] = _f_17;
    e.mem[_nd_3 + 12] = _f_18;
    e.mem[_nd_3 + 13] = _f_19;
    r0 = term_clo(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C196, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C196)
  {
    Term _f_20 = r0;
    u32 _namespace_6 = r1;
    Term _name_6 = r2;
    Term _all_6 = r3;
    u32 _f_21 = r4;
    u32 _f_22 = r5;
    Term _f_23 = r6;
    Term _f_24 = r7;
    u32 _f_25 = r8;
    u32 _f_26 = r9;
    u32 _f_27 = r10;
    Term _f_28 = r11;
    Term _f_29 = r12;
    u32 _f_30 = r13;
    Term _x_1 = r14;
    WL_OPEN
    Term _fb_4[13];
    u64 _sp_4 = ctr_take(e, _x_1, 13, _fb_4);
    u32 _f_31 = _fb_4[0];
    u32 _f_32 = _fb_4[1];
    u32 _f_33 = _fb_4[2];
    Term _f_34 = _fb_4[3];
    u32 _f_35 = _fb_4[4];
    Term _f_36 = _fb_4[5];
    Term _f_37 = _fb_4[6];
    Term _f_38 = _fb_4[7];
    Term _f_39 = _fb_4[8];
    Term _f_40 = _fb_4[9];
    Term _f_41 = _fb_4[10];
    u32 _f_42 = _fb_4[11];
    u32 _f_43 = _fb_4[12];
    spare_free(e, cls_fit(13), _sp_4);
    u64 _nd_4 = heap_alloc(e, cls_fit(26));
    e.mem[_nd_4 + 0] = _f_20;
    e.mem[_nd_4 + 1] = _namespace_6;
    e.mem[_nd_4 + 2] = _name_6;
    e.mem[_nd_4 + 3] = _all_6;
    e.mem[_nd_4 + 4] = _f_21;
    e.mem[_nd_4 + 5] = _f_22;
    e.mem[_nd_4 + 6] = _f_23;
    e.mem[_nd_4 + 7] = _f_24;
    e.mem[_nd_4 + 8] = _f_25;
    e.mem[_nd_4 + 9] = _f_26;
    e.mem[_nd_4 + 10] = _f_27;
    e.mem[_nd_4 + 11] = _f_28;
    e.mem[_nd_4 + 12] = _f_29;
    e.mem[_nd_4 + 13] = _f_30;
    e.mem[_nd_4 + 14] = _f_31;
    e.mem[_nd_4 + 15] = _f_32;
    e.mem[_nd_4 + 16] = _f_33;
    e.mem[_nd_4 + 17] = _f_34;
    e.mem[_nd_4 + 18] = _f_35;
    e.mem[_nd_4 + 19] = _f_36;
    e.mem[_nd_4 + 20] = _f_38;
    e.mem[_nd_4 + 21] = _f_39;
    e.mem[_nd_4 + 22] = _f_40;
    e.mem[_nd_4 + 23] = _f_41;
    e.mem[_nd_4 + 24] = _f_42;
    e.mem[_nd_4 + 25] = _f_43;
    r0 = term_clo(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C197, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_C197)
  {
    Term _f_44 = r0;
    u32 _namespace_7 = r1;
    Term _name_7 = r2;
    Term _all_7 = r3;
    u32 _f_45 = r4;
    u32 _f_46 = r5;
    Term _f_47 = r6;
    Term _f_48 = r7;
    u32 _f_49 = r8;
    u32 _f_50 = r9;
    u32 _f_51 = r10;
    Term _f_52 = r11;
    Term _f_53 = r12;
    u32 _f_54 = r13;
    u32 _f_55 = r14;
    u32 _f_56 = r15;
    u32 _f_57 = r16;
    Term _f_58 = r17;
    u32 _f_59 = r18;
    Term _f_60 = r19;
    u32 _f_61 = r20;
    Term _f_62 = r21;
    Term _f_63 = r22;
    Term _f_64 = r23;
    u32 _f_65 = r24;
    u32 _f_66 = r25;
    Term _x_2 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K198;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K198, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K198, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0)) {
      u64 _t_11 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _f_44;
      e.mem[_t_11 + 1] = _f_45;
      e.mem[_t_11 + 2] = _f_46;
      e.mem[_t_11 + 3] = _f_47;
      e.mem[_t_11 + 4] = _f_48;
      e.mem[_t_11 + 5] = _f_49;
      e.mem[_t_11 + 6] = _f_50;
      e.mem[_t_11 + 7] = _f_51;
      e.mem[_t_11 + 8] = _f_52;
      e.mem[_t_11 + 9] = _f_53;
      e.mem[_t_11 + 10] = _f_54;
      e.mem[_t_11 + 11] = _f_55;
      e.mem[_t_11 + 12] = _f_56;
      e.mem[_t_11 + 13] = _f_57;
      e.mem[_t_11 + 14] = _f_58;
      e.mem[_t_11 + 15] = _f_59;
      e.mem[_t_11 + 16] = _f_60;
      e.mem[_t_11 + 17] = _f_61;
      e.mem[_t_11 + 18] = _f_62;
      e.mem[_t_11 + 19] = _f_63;
      e.mem[_t_11 + 20] = _f_64;
      e.mem[_t_11 + 21] = _f_65;
      e.mem[_t_11 + 22] = _f_66;
      e.mem[_t_11 + 23] = _namespace_7;
      e.mem[_t_11 + 24] = _name_7;
      e.mem[_t_11 + 25] = _all_7;
      e.mem[_t_11 + 26] = _x_2;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0, _t_11);
    }
    r0 = _f_44;
    r1 = _f_45;
    r2 = _f_46;
    r3 = _f_47;
    r4 = _f_48;
    r5 = _f_49;
    r6 = _f_50;
    r7 = _f_51;
    r8 = _f_52;
    r9 = _f_53;
    r10 = _f_54;
    r11 = _f_55;
    r12 = _f_56;
    r13 = _f_57;
    r14 = _f_58;
    r15 = _f_59;
    r16 = _f_60;
    r17 = _f_61;
    r18 = _f_62;
    r19 = _f_63;
    r20 = _f_64;
    r21 = _f_65;
    r22 = _f_66;
    r23 = _namespace_7;
    r24 = _name_7;
    r25 = _all_7;
    r26 = _x_2;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K198)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    u32 _r_4 = r4;
    u32 _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    u32 _r_9 = r9;
    u32 _r_10 = r10;
    Term _r_11 = r11;
    Term _r_12 = r12;
    u32 _r_13 = r13;
    u32 _r_14 = r14;
    u32 _r_15 = r15;
    u32 _r_16 = r16;
    Term _r_17 = r17;
    u32 _r_18 = r18;
    Term _r_19 = r19;
    u32 _r_20 = r20;
    Term _r_21 = r21;
    Term _r_22 = r22;
    Term _r_23 = r23;
    u32 _r_24 = r24;
    u32 _r_25 = r25;
    Term _r_26 = r26;
    Term _r_27 = r27;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      u64 _nd_5 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_5 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_5 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_5 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_5 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_5 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_5 + 5] = rfc_seal(e, _r_9);
      e.mem[_nd_5 + 6] = rfc_seal(e, _r_10);
      e.mem[_nd_5 + 7] = rfc_seal(e, _r_11);
      e.mem[_nd_5 + 8] = rfc_seal(e, _r_12);
      e.mem[_nd_5 + 9] = rfc_seal(e, _r_13);
      u64 _nd_6 = heap_alloc(e, cls_fit(18));
      e.mem[_nd_6 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_6 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_6 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_6 + 3] = rfc_seal(e, term_ctr(CID_OWNERS, _nd_5));
      e.mem[_nd_6 + 4] = rfc_seal(e, _r_14);
      e.mem[_nd_6 + 5] = rfc_seal(e, _r_15);
      e.mem[_nd_6 + 6] = rfc_seal(e, _r_16);
      e.mem[_nd_6 + 7] = rfc_seal(e, _r_17);
      e.mem[_nd_6 + 8] = rfc_seal(e, _r_18);
      e.mem[_nd_6 + 9] = rfc_seal(e, _r_19);
      e.mem[_nd_6 + 10] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_6 + 11] = rfc_seal(e, _r_20);
      e.mem[_nd_6 + 12] = rfc_seal(e, _r_21);
      e.mem[_nd_6 + 13] = rfc_seal(e, _r_22);
      e.mem[_nd_6 + 14] = rfc_seal(e, _r_23);
      e.mem[_nd_6 + 15] = rfc_seal(e, _r_24);
      e.mem[_nd_6 + 16] = rfc_seal(e, _r_25);
      e.mem[_nd_6 + 17] = rfc_seal(e, _r_26);
      _b_0 = term_ctr(CID_______SRC_ECS_SCHEDULE_FINISHED, _nd_6);
    } else if (_r_0 == 1) {
      u64 _nd_7 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_7 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_7 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_7 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_7 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_7 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_7 + 5] = rfc_seal(e, _r_9);
      e.mem[_nd_7 + 6] = rfc_seal(e, _r_10);
      e.mem[_nd_7 + 7] = rfc_seal(e, _r_11);
      e.mem[_nd_7 + 8] = rfc_seal(e, _r_12);
      e.mem[_nd_7 + 9] = rfc_seal(e, _r_13);
      u64 _nd_8 = heap_alloc(e, cls_fit(19));
      e.mem[_nd_8 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_8 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_8 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_8 + 3] = rfc_seal(e, term_ctr(CID_OWNERS, _nd_7));
      e.mem[_nd_8 + 4] = rfc_seal(e, _r_14);
      e.mem[_nd_8 + 5] = rfc_seal(e, _r_15);
      e.mem[_nd_8 + 6] = rfc_seal(e, _r_16);
      e.mem[_nd_8 + 7] = rfc_seal(e, _r_17);
      e.mem[_nd_8 + 8] = rfc_seal(e, _r_18);
      e.mem[_nd_8 + 9] = rfc_seal(e, _r_19);
      e.mem[_nd_8 + 10] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_8 + 11] = rfc_seal(e, _r_20);
      e.mem[_nd_8 + 12] = rfc_seal(e, _r_21);
      e.mem[_nd_8 + 13] = rfc_seal(e, _r_22);
      e.mem[_nd_8 + 14] = rfc_seal(e, _r_23);
      e.mem[_nd_8 + 15] = rfc_seal(e, _r_24);
      e.mem[_nd_8 + 16] = rfc_seal(e, _r_25);
      e.mem[_nd_8 + 17] = rfc_seal(e, _r_26);
      e.mem[_nd_8 + 18] = rfc_seal(e, _r_27);
      _b_0 = term_ctr(CID_______SRC_ECS_SCHEDULE_FAILED, _nd_8);
    } else {
      u64 _nd_9 = heap_alloc(e, cls_fit(10));
      e.mem[_nd_9 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_9 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_9 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_9 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_9 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_9 + 5] = rfc_seal(e, _r_9);
      e.mem[_nd_9 + 6] = rfc_seal(e, _r_10);
      e.mem[_nd_9 + 7] = rfc_seal(e, _r_11);
      e.mem[_nd_9 + 8] = rfc_seal(e, _r_12);
      e.mem[_nd_9 + 9] = rfc_seal(e, _r_13);
      u64 _nd_10 = heap_alloc(e, cls_fit(17));
      e.mem[_nd_10 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_10 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_10 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_10 + 3] = rfc_seal(e, term_ctr(CID_OWNERS, _nd_9));
      e.mem[_nd_10 + 4] = rfc_seal(e, _r_14);
      e.mem[_nd_10 + 5] = rfc_seal(e, _r_15);
      e.mem[_nd_10 + 6] = rfc_seal(e, _r_16);
      e.mem[_nd_10 + 7] = rfc_seal(e, _r_17);
      e.mem[_nd_10 + 8] = rfc_seal(e, _r_18);
      e.mem[_nd_10 + 9] = rfc_seal(e, _r_19);
      e.mem[_nd_10 + 10] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_10 + 11] = rfc_seal(e, _r_20);
      e.mem[_nd_10 + 12] = rfc_seal(e, _r_21);
      e.mem[_nd_10 + 13] = rfc_seal(e, _r_22);
      e.mem[_nd_10 + 14] = rfc_seal(e, _r_23);
      e.mem[_nd_10 + 15] = rfc_seal(e, _r_24);
      e.mem[_nd_10 + 16] = rfc_seal(e, _r_25);
      _b_0 = term_ctr(CID_______SRC_ECS_SCHEDULE_REJECTED, _nd_10);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K199)
  {
    WL_POPN(14);
    u32 _h_40 = STK(0);
    u32 _h_41 = STK(1);
    u32 _h_42 = STK(2);
    Term _h_43 = STK(3);
    u32 _h_44 = STK(4);
    Term _h_45 = STK(5);
    u32 _h_46 = STK(6);
    Term _h_47 = STK(7);
    Term _h_48 = STK(8);
    Term _h_49 = STK(9);
    u32 _h_50 = STK(10);
    u32 _h_51 = STK(11);
    Term _observations_3 = STK(12);
    u32 _o_4 = STK(13);
    Term _h_39 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_12 + 0] = rfc_seal(e, _h_40);
    e.mem[_nd_12 + 1] = rfc_seal(e, _h_41);
    e.mem[_nd_12 + 2] = rfc_seal(e, _h_42);
    e.mem[_nd_12 + 3] = rfc_seal(e, _h_43);
    e.mem[_nd_12 + 4] = rfc_seal(e, _h_44);
    e.mem[_nd_12 + 5] = rfc_seal(e, _h_45);
    e.mem[_nd_12 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_12 + 7] = rfc_seal(e, _h_46);
    e.mem[_nd_12 + 8] = rfc_seal(e, _h_47);
    e.mem[_nd_12 + 9] = rfc_seal(e, _h_48);
    e.mem[_nd_12 + 10] = rfc_seal(e, _h_49);
    e.mem[_nd_12 + 11] = rfc_seal(e, _h_50);
    e.mem[_nd_12 + 12] = rfc_seal(e, _h_51);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _observations_3;
      STK(1) = _o_4;
      STK(2) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K200;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K200, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _observations_3;
      e.mem[_t_14 + 1] = _o_4;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K200, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_15 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_39;
      e.mem[_t_15 + 1] = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_12);
      return term_tsk(FID_CLO_APPLY, _t_15);
    }
    r0 = _h_39;
    r1 = term_ctr(CID_______SRC_ECS_WORLD_WORLD, _nd_12);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K200)
  {
    WL_POPN(2);
    Term _observations_4 = STK(0);
    u32 _o_5 = STK(1);
    Term _h_52 = r0;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_______SRC_ECS_SCHEDULE_SKIPPED, _o_5));
    e.mem[_nd_13 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_52;
      STK(1) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K201;
      WL_PUSHN(2);
    } else {
      u64 _t_16 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_52;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K201, _t_16);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_17 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _observations_4;
      e.mem[_t_17 + 1] = term_ctr(CID_CON, _nd_13);
      return term_tsk(FID_LIST_APPEND, _t_17);
    }
    r0 = _observations_4;
    r1 = term_ctr(CID_CON, _nd_13);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K201)
  {
    WL_POPN(1);
    Term _h_54 = STK(0);
    Term _h_53 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K202;
      WL_PUSHN(1);
    } else {
      u64 _t_18 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K202, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K202, _t_18);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_19 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_54;
      e.mem[_t_19 + 1] = _h_53;
      return term_tsk(FID_CLO_APPLY, _t_19);
    }
    r0 = _h_54;
    r1 = _h_53;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K202)
  {
    Term _r_28 = r0;
    WL_OPEN
    u32 _o_6 = 0;
    u32 _o_7 = 0;
    Term _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    Term _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    Term _o_17 = 0;
    Term _o_18 = 0;
    u32 _o_19 = 0;
    u32 _o_20 = 0;
    u32 _o_21 = 0;
    u32 _o_22 = 0;
    Term _o_23 = 0;
    u32 _o_24 = 0;
    Term _o_25 = 0;
    u32 _o_26 = 0;
    Term _o_27 = 0;
    Term _o_28 = 0;
    Term _o_29 = 0;
    u32 _o_30 = 0;
    u32 _o_31 = 0;
    Term _o_32 = 0;
    Term _o_33 = 0;
    if (term_aux(_r_28) == CID_______SRC_ECS_SCHEDULE_FINISHED) {
      _o_6 = 0;
      Term _fb_5[18];
      u64 _sp_5 = ctr_take(e, _r_28, 18, _fb_5);
      u32 _f_67 = _fb_5[0];
      Term _f_68 = _fb_5[1];
      Term _f_69 = _fb_5[2];
      Term _f_70 = _fb_5[3];
      u32 _f_71 = _fb_5[4];
      u32 _f_72 = _fb_5[5];
      u32 _f_73 = _fb_5[6];
      Term _f_74 = _fb_5[7];
      u32 _f_75 = _fb_5[8];
      Term _f_76 = _fb_5[9];
      Term _f_77 = _fb_5[10];
      Term _f_78 = _fb_5[11];
      Term _f_79 = _fb_5[12];
      Term _f_80 = _fb_5[13];
      Term _f_81 = _fb_5[14];
      u32 _f_82 = _fb_5[15];
      u32 _f_83 = _fb_5[16];
      Term _f_84 = _fb_5[17];
      spare_free(e, cls_fit(18), _sp_5);
      Term _fb_6[10];
      u64 _sp_6 = ctr_take(e, _f_70, 10, _fb_6);
      u32 _f_85 = _fb_6[0];
      u32 _f_86 = _fb_6[1];
      Term _f_87 = _fb_6[2];
      Term _f_88 = _fb_6[3];
      u32 _f_89 = _fb_6[4];
      u32 _f_90 = _fb_6[5];
      u32 _f_91 = _fb_6[6];
      Term _f_92 = _fb_6[7];
      Term _f_93 = _fb_6[8];
      u32 _f_94 = _fb_6[9];
      spare_free(e, cls_fit(10), _sp_6);
      _o_7 = _f_67;
      _o_8 = _f_68;
      _o_9 = _f_69;
      _o_10 = _f_85;
      _o_11 = _f_86;
      _o_12 = _f_87;
      _o_13 = _f_88;
      _o_14 = _f_89;
      _o_15 = _f_90;
      _o_16 = _f_91;
      _o_17 = _f_92;
      _o_18 = _f_93;
      _o_19 = _f_94;
      _o_20 = _f_71;
      _o_21 = _f_72;
      _o_22 = _f_73;
      _o_23 = _f_74;
      _o_24 = _f_75;
      _o_25 = _f_76;
      _o_26 = _f_78;
      _o_27 = _f_79;
      _o_28 = _f_80;
      _o_29 = _f_81;
      _o_30 = _f_82;
      _o_31 = _f_83;
      _o_32 = _f_84;
    } else if (term_aux(_r_28) == CID_______SRC_ECS_SCHEDULE_FAILED) {
      _o_6 = 1;
      Term _fb_7[19];
      u64 _sp_7 = ctr_take(e, _r_28, 19, _fb_7);
      u32 _f_95 = _fb_7[0];
      Term _f_96 = _fb_7[1];
      Term _f_97 = _fb_7[2];
      Term _f_98 = _fb_7[3];
      u32 _f_99 = _fb_7[4];
      u32 _f_100 = _fb_7[5];
      u32 _f_101 = _fb_7[6];
      Term _f_102 = _fb_7[7];
      u32 _f_103 = _fb_7[8];
      Term _f_104 = _fb_7[9];
      Term _f_105 = _fb_7[10];
      Term _f_106 = _fb_7[11];
      Term _f_107 = _fb_7[12];
      Term _f_108 = _fb_7[13];
      Term _f_109 = _fb_7[14];
      u32 _f_110 = _fb_7[15];
      u32 _f_111 = _fb_7[16];
      Term _f_112 = _fb_7[17];
      Term _f_113 = _fb_7[18];
      spare_free(e, cls_fit(19), _sp_7);
      Term _fb_8[10];
      u64 _sp_8 = ctr_take(e, _f_98, 10, _fb_8);
      u32 _f_114 = _fb_8[0];
      u32 _f_115 = _fb_8[1];
      Term _f_116 = _fb_8[2];
      Term _f_117 = _fb_8[3];
      u32 _f_118 = _fb_8[4];
      u32 _f_119 = _fb_8[5];
      u32 _f_120 = _fb_8[6];
      Term _f_121 = _fb_8[7];
      Term _f_122 = _fb_8[8];
      u32 _f_123 = _fb_8[9];
      spare_free(e, cls_fit(10), _sp_8);
      _o_7 = _f_95;
      _o_8 = _f_96;
      _o_9 = _f_97;
      _o_10 = _f_114;
      _o_11 = _f_115;
      _o_12 = _f_116;
      _o_13 = _f_117;
      _o_14 = _f_118;
      _o_15 = _f_119;
      _o_16 = _f_120;
      _o_17 = _f_121;
      _o_18 = _f_122;
      _o_19 = _f_123;
      _o_20 = _f_99;
      _o_21 = _f_100;
      _o_22 = _f_101;
      _o_23 = _f_102;
      _o_24 = _f_103;
      _o_25 = _f_104;
      _o_26 = _f_106;
      _o_27 = _f_107;
      _o_28 = _f_108;
      _o_29 = _f_109;
      _o_30 = _f_110;
      _o_31 = _f_111;
      _o_32 = _f_112;
      _o_33 = _f_113;
    } else {
      _o_6 = 2;
      Term _fb_9[17];
      u64 _sp_9 = ctr_take(e, _r_28, 17, _fb_9);
      u32 _f_124 = _fb_9[0];
      Term _f_125 = _fb_9[1];
      Term _f_126 = _fb_9[2];
      Term _f_127 = _fb_9[3];
      u32 _f_128 = _fb_9[4];
      u32 _f_129 = _fb_9[5];
      u32 _f_130 = _fb_9[6];
      Term _f_131 = _fb_9[7];
      u32 _f_132 = _fb_9[8];
      Term _f_133 = _fb_9[9];
      Term _f_134 = _fb_9[10];
      Term _f_135 = _fb_9[11];
      Term _f_136 = _fb_9[12];
      Term _f_137 = _fb_9[13];
      Term _f_138 = _fb_9[14];
      u32 _f_139 = _fb_9[15];
      u32 _f_140 = _fb_9[16];
      spare_free(e, cls_fit(17), _sp_9);
      Term _fb_10[10];
      u64 _sp_10 = ctr_take(e, _f_127, 10, _fb_10);
      u32 _f_141 = _fb_10[0];
      u32 _f_142 = _fb_10[1];
      Term _f_143 = _fb_10[2];
      Term _f_144 = _fb_10[3];
      u32 _f_145 = _fb_10[4];
      u32 _f_146 = _fb_10[5];
      u32 _f_147 = _fb_10[6];
      Term _f_148 = _fb_10[7];
      Term _f_149 = _fb_10[8];
      u32 _f_150 = _fb_10[9];
      spare_free(e, cls_fit(10), _sp_10);
      _o_7 = _f_124;
      _o_8 = _f_125;
      _o_9 = _f_126;
      _o_10 = _f_141;
      _o_11 = _f_142;
      _o_12 = _f_143;
      _o_13 = _f_144;
      _o_14 = _f_145;
      _o_15 = _f_146;
      _o_16 = _f_147;
      _o_17 = _f_148;
      _o_18 = _f_149;
      _o_19 = _f_150;
      _o_20 = _f_128;
      _o_21 = _f_129;
      _o_22 = _f_130;
      _o_23 = _f_131;
      _o_24 = _f_132;
      _o_25 = _f_133;
      _o_26 = _f_135;
      _o_27 = _f_136;
      _o_28 = _f_137;
      _o_29 = _f_138;
      _o_30 = _f_139;
      _o_31 = _f_140;
    }
    r0 = _o_6;
    r1 = _o_7;
    r2 = _o_8;
    r3 = _o_9;
    r4 = _o_10;
    r5 = _o_11;
    r6 = _o_12;
    r7 = _o_13;
    r8 = _o_14;
    r9 = _o_15;
    r10 = _o_16;
    r11 = _o_17;
    r12 = _o_18;
    r13 = _o_19;
    r14 = _o_20;
    r15 = _o_21;
    r16 = _o_22;
    r17 = _o_23;
    r18 = _o_24;
    r19 = _o_25;
    r20 = _o_26;
    r21 = _o_27;
    r22 = _o_28;
    r23 = _o_29;
    r24 = _o_30;
    r25 = _o_31;
    r26 = _o_32;
    r27 = _o_33;
    WL_RETN(28);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_EXECUTE_0_K203)
  {
    WL_POPN(6);
    Term _next_1 = STK(0);
    u32 _namespace_8 = STK(1);
    Term _name_8 = STK(2);
    Term _all_8 = STK(3);
    Term _observations_5 = STK(4);
    u32 _o_34 = STK(5);
    u32 _h_55 = r0;
    u32 _h_56 = r1;
    Term _h_57 = r2;
    Term _h_58 = r3;
    u32 _h_59 = r4;
    u32 _h_60 = r5;
    u32 _h_61 = r6;
    Term _h_62 = r7;
    Term _h_63 = r8;
    u32 _h_64 = r9;
    u32 _h_65 = r10;
    u32 _h_66 = r11;
    u32 _h_67 = r12;
    u32 _h_68 = r13;
    Term _h_69 = r14;
    u32 _h_70 = r15;
    Term _h_71 = r16;
    u32 _h_72 = r17;
    Term _h_73 = r18;
    Term _h_74 = r19;
    Term _h_75 = r20;
    u32 _h_76 = r21;
    u32 _h_77 = r22;
    Term _h_78 = r23;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0)) {
      u64 _t_22 = task_node(e, FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _next_1;
      e.mem[_t_22 + 1] = _h_55;
      e.mem[_t_22 + 2] = _h_56;
      e.mem[_t_22 + 3] = _h_57;
      e.mem[_t_22 + 4] = _h_58;
      e.mem[_t_22 + 5] = _h_59;
      e.mem[_t_22 + 6] = _h_60;
      e.mem[_t_22 + 7] = _h_61;
      e.mem[_t_22 + 8] = _h_62;
      e.mem[_t_22 + 9] = _h_63;
      e.mem[_t_22 + 10] = _h_64;
      e.mem[_t_22 + 11] = _h_65;
      e.mem[_t_22 + 12] = _h_66;
      e.mem[_t_22 + 13] = _h_67;
      e.mem[_t_22 + 14] = _h_68;
      e.mem[_t_22 + 15] = _h_69;
      e.mem[_t_22 + 16] = _h_70;
      e.mem[_t_22 + 17] = _h_71;
      e.mem[_t_22 + 18] = _h_72;
      e.mem[_t_22 + 19] = _h_73;
      e.mem[_t_22 + 20] = _h_74;
      e.mem[_t_22 + 21] = _h_75;
      e.mem[_t_22 + 22] = _h_76;
      e.mem[_t_22 + 23] = _h_77;
      e.mem[_t_22 + 24] = _h_78;
      e.mem[_t_22 + 25] = _namespace_8;
      e.mem[_t_22 + 26] = _name_8;
      e.mem[_t_22 + 27] = _all_8;
      e.mem[_t_22 + 28] = _observations_5;
      e.mem[_t_22 + 29] = _o_34;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0, _t_22);
    }
    r0 = _next_1;
    r1 = _h_55;
    r2 = _h_56;
    r3 = _h_57;
    r4 = _h_58;
    r5 = _h_59;
    r6 = _h_60;
    r7 = _h_61;
    r8 = _h_62;
    r9 = _h_63;
    r10 = _h_64;
    r11 = _h_65;
    r12 = _h_66;
    r13 = _h_67;
    r14 = _h_68;
    r15 = _h_69;
    r16 = _h_70;
    r17 = _h_71;
    r18 = _h_72;
    r19 = _h_73;
    r20 = _h_74;
    r21 = _h_75;
    r22 = _h_76;
    r23 = _h_77;
    r24 = _h_78;
    r25 = _namespace_8;
    r26 = _name_8;
    r27 = _all_8;
    r28 = _observations_5;
    r29 = _o_34;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_AFTER_DISPATCH_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_WORLD_BARRIER_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    u32 _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0)) {
      u64 _t_0 = task_node(e, FID_______SRC_ECS_WORLD_DRAIN_FIFO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _world_8;
      e.mem[_t_0 + 1] = _world_0;
      e.mem[_t_0 + 2] = _world_1;
      e.mem[_t_0 + 3] = _world_2;
      e.mem[_t_0 + 4] = _world_3;
      e.mem[_t_0 + 5] = _world_4;
      e.mem[_t_0 + 6] = _world_5;
      e.mem[_t_0 + 7] = _world_6;
      e.mem[_t_0 + 8] = _world_7;
      e.mem[_t_0 + 9] = term_pak(CID_NIL, 0);
      e.mem[_t_0 + 10] = _world_9;
      e.mem[_t_0 + 11] = _world_10;
      e.mem[_t_0 + 12] = _world_11;
      return term_tsk(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0, _t_0);
    }
    r0 = _world_8;
    r1 = _world_0;
    r2 = _world_1;
    r3 = _world_2;
    r4 = _world_3;
    r5 = _world_4;
    r6 = _world_5;
    r7 = _world_6;
    r8 = _world_7;
    r9 = term_pak(CID_NIL, 0);
    r10 = _world_9;
    r11 = _world_10;
    r12 = _world_11;
    WL_JMP(FID_______SRC_ECS_WORLD_DRAIN_FIFO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDS)
  {
    Term _handles_0 = r0;
    WL_OPEN
    if (term_aux(_handles_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _handles_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_IDS_K217;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_IDS_K217, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_IDS_K217, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_3;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_3;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDS_K217)
  {
    WL_POPN(1);
    Term _f_4 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_IDS_K218;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_IDS_K218, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_IDS_K218, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_IDS)) {
      u64 _t_3 = task_node(e, FID_IDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_4;
      return term_tsk(FID_IDS, _t_3);
    }
    r0 = _f_4;
    WL_JMP(FID_IDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDS_K218)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_IDS_K219;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_IDS_K219, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_IDS_K219, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 70);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 70);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IDS_K219)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_NUMBERS_K229;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_NUMBERS_K229, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_NUMBERS_K229, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K229)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_NUMBERS_K230;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_NUMBERS_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_NUMBERS_K230, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NUMBERS)) {
      u64 _t_3 = task_node(e, FID_NUMBERS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_NUMBERS, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_NUMBERS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K230)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_NUMBERS_K231;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_NUMBERS_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_NUMBERS_K231, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 70);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 70);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K231)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 68);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FINAL)
  {
    u32 _result_0 = r0;
    Term _result_1 = r1;
    Term _result_2 = r2;
    u32 _result_3 = r3;
    u32 _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    u32 _result_7 = r7;
    u32 _result_8 = r8;
    u32 _result_9 = r9;
    Term _result_10 = r10;
    Term _result_11 = r11;
    u32 _result_12 = r12;
    u32 _result_13 = r13;
    u32 _result_14 = r14;
    u32 _result_15 = r15;
    Term _result_16 = r16;
    u32 _result_17 = r17;
    Term _result_18 = r18;
    u32 _result_19 = r19;
    Term _result_20 = r20;
    Term _result_21 = r21;
    Term _result_22 = r22;
    u32 _result_23 = r23;
    u32 _result_24 = r24;
    Term _result_25 = r25;
    WL_OPEN
    term_sink(e, _result_1);
    term_sink(e, _result_2);
    term_sink(e, _result_5);
    term_sink(e, _result_6);
    term_sink(e, _result_10);
    term_sink(e, _result_11);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _result_25;
      STK(1) = FID_FINAL_K239;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_FINAL_K239, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _result_25;
      WL_CONT = term_tsk(FID_FINAL_K239, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_WORLD_BARRIER_0)) {
      u64 _t_1 = task_node(e, FID_______SRC_ECS_WORLD_BARRIER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _result_13;
      e.mem[_t_1 + 1] = _result_14;
      e.mem[_t_1 + 2] = _result_15;
      e.mem[_t_1 + 3] = _result_16;
      e.mem[_t_1 + 4] = _result_17;
      e.mem[_t_1 + 5] = _result_18;
      e.mem[_t_1 + 6] = _result_19;
      e.mem[_t_1 + 7] = _result_20;
      e.mem[_t_1 + 8] = _result_21;
      e.mem[_t_1 + 9] = _result_22;
      e.mem[_t_1 + 10] = _result_23;
      e.mem[_t_1 + 11] = _result_24;
      return term_tsk(FID_______SRC_ECS_WORLD_BARRIER_0, _t_1);
    }
    r0 = _result_13;
    r1 = _result_14;
    r2 = _result_15;
    r3 = _result_16;
    r4 = _result_17;
    r5 = _result_18;
    r6 = _result_19;
    r7 = _result_20;
    r8 = _result_21;
    r9 = _result_22;
    r10 = _result_23;
    r11 = _result_24;
    WL_JMP(FID_______SRC_ECS_WORLD_BARRIER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FINAL_K239)
  {
    WL_POPN(1);
    Term _result_26 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _result_26;
      STK(1) = FID_FINAL_K240;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_FINAL_K240, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _result_26;
      WL_CONT = term_tsk(FID_FINAL_K240, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CAPTURE)) {
      u64 _t_3 = task_node(e, FID_CAPTURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      return term_tsk(FID_CAPTURE, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    WL_JMP(FID_CAPTURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FINAL_K240)
  {
    WL_POPN(1);
    Term _result_27 = STK(0);
    u32 _h_12 = r0;
    u32 _h_13 = r1;
    u32 _h_14 = r2;
    Term _h_15 = r3;
    u32 _h_16 = r4;
    Term _h_17 = r5;
    u32 _h_18 = r6;
    Term _h_19 = r7;
    Term _h_20 = r8;
    Term _h_21 = r9;
    u32 _h_22 = r10;
    u32 _h_23 = r11;
    Term _h_24 = r12;
    WL_OPEN
    term_sink(e, _h_15);
    term_sink(e, _h_19);
    term_sink(e, _h_20);
    term_sink(e, _h_21);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_24;
      STK(1) = FID_FINAL_K241;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_FINAL_K241, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_24;
      WL_CONT = term_tsk(FID_FINAL_K241, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SHOW_LINES)) {
      u64 _t_5 = task_node(e, FID_SHOW_LINES, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _result_27;
      return term_tsk(FID_SHOW_LINES, _t_5);
    }
    r0 = _result_27;
    WL_JMP(FID_SHOW_LINES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FINAL_K241)
  {
    WL_POPN(1);
    Term _h_26 = STK(0);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_25;
      STK(1) = FID_FINAL_K242;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_FINAL_K242, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_25;
      WL_CONT = term_tsk(FID_FINAL_K242, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_26;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 52);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_26;
    r1 = term_ctr(CID_SCON, STAT_OFF + 52);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FINAL_K242)
  {
    WL_POPN(1);
    Term _h_28 = STK(0);
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_28;
      STK(1) = FID_FINAL_K243;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_FINAL_K243, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_28;
      WL_CONT = term_tsk(FID_FINAL_K243, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 66);
      e.mem[_t_9 + 1] = _h_27;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 66);
    r1 = _h_27;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FINAL_K243)
  {
    WL_POPN(1);
    Term _h_30 = STK(0);
    Term _h_29 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_30;
      e.mem[_t_10 + 1] = _h_29;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_30;
    r1 = _h_29;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_CONTAINS)
  {
    Term _ids_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_ids_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _ids_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _id_0;
        STK(2) = FID_______SRC_ECS_SCHEDULE_CONTAINS_K250;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_CONTAINS_K250, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_CONTAINS_K250, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _id_0;
      _ids_0 = r0;
      _id_0 = r1;
      WL_AGAIN(FID_______SRC_ECS_SCHEDULE_CONTAINS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_CONTAINS_K250)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _id_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_f_2, ==, _id_1)) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS)
  {
    Term _steps_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_steps_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_ENTERED) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_RAN) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_SKIPPED) {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 3;
      }
      if (_o_0 == 0) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _o_1;
          STK(1) = FID_SHOW_STEPS_K254;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID_SHOW_STEPS_K254, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          WL_CONT = term_tsk(FID_SHOW_STEPS_K254, _t_0);
          WL_IDX = 1;
        }
        r0 = _f_1;
        _steps_0 = r0;
        WL_AGAIN(FID_SHOW_STEPS);
      } else if (_o_0 == 1) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_SHOW_STEPS_K257;
          WL_PUSHN(2);
        } else {
          u64 _t_6 = task_node(e, FID_SHOW_STEPS_K257, WL_CONT, WL_IDX, 1);
          e.mem[_t_6 + 0] = _f_1;
          WL_CONT = term_tsk(FID_SHOW_STEPS_K257, _t_6);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
          u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
          e.mem[_t_7 + 0] = _o_1;
          return term_tsk(FID_U32_SHOW, _t_7);
        }
        r0 = _o_1;
        WL_JMP(FID_U32_SHOW);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID_SHOW_STEPS_K261;
          WL_PUSHN(2);
        } else {
          u64 _t_15 = task_node(e, FID_SHOW_STEPS_K261, WL_CONT, WL_IDX, 1);
          e.mem[_t_15 + 0] = _f_1;
          WL_CONT = term_tsk(FID_SHOW_STEPS_K261, _t_15);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
          u64 _t_16 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
          e.mem[_t_16 + 0] = _o_1;
          return term_tsk(FID_U32_SHOW, _t_16);
        }
        r0 = _o_1;
        WL_JMP(FID_U32_SHOW);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_SHOW_STEPS_K265;
          WL_PUSHN(1);
        } else {
          u64 _t_24 = task_node(e, FID_SHOW_STEPS_K265, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_SHOW_STEPS_K265, _t_24);
          WL_IDX = 0;
        }
        r0 = _f_1;
        _steps_0 = r0;
        WL_AGAIN(FID_SHOW_STEPS);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K254)
  {
    WL_POPN(1);
    Term _o_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _o_2;
      STK(1) = FID_SHOW_STEPS_K255;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_SHOW_STEPS_K255, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _o_2;
      WL_CONT = term_tsk(FID_SHOW_STEPS_K255, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 72);
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 72);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K255)
  {
    WL_POPN(1);
    Term _o_3 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SHOW_STEPS_K256;
      WL_PUSHN(1);
    } else {
      u64 _t_3 = task_node(e, FID_SHOW_STEPS_K256, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SHOW_STEPS_K256, _t_3);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _o_3;
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = _o_3;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K256)
  {
    Term _h_2 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 82);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 82);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K257)
  {
    WL_POPN(1);
    Term _f_3 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_SHOW_STEPS_K258;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_SHOW_STEPS_K258, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_3;
      WL_CONT = term_tsk(FID_SHOW_STEPS_K258, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SHOW_STEPS)) {
      u64 _t_9 = task_node(e, FID_SHOW_STEPS, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _f_3;
      return term_tsk(FID_SHOW_STEPS, _t_9);
    }
    r0 = _f_3;
    WL_JMP(FID_SHOW_STEPS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K258)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_5;
      STK(1) = FID_SHOW_STEPS_K259;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_SHOW_STEPS_K259, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_5;
      WL_CONT = term_tsk(FID_SHOW_STEPS_K259, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 72);
      e.mem[_t_11 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 72);
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K259)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SHOW_STEPS_K260;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_SHOW_STEPS_K260, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SHOW_STEPS_K260, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_7;
      e.mem[_t_13 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_7;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K260)
  {
    Term _h_8 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 88);
      e.mem[_t_14 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 88);
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K261)
  {
    WL_POPN(1);
    Term _f_4 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_9;
      STK(1) = FID_SHOW_STEPS_K262;
      WL_PUSHN(2);
    } else {
      u64 _t_17 = task_node(e, FID_SHOW_STEPS_K262, WL_CONT, WL_IDX, 1);
      e.mem[_t_17 + 0] = _h_9;
      WL_CONT = term_tsk(FID_SHOW_STEPS_K262, _t_17);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SHOW_STEPS)) {
      u64 _t_18 = task_node(e, FID_SHOW_STEPS, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _f_4;
      return term_tsk(FID_SHOW_STEPS, _t_18);
    }
    r0 = _f_4;
    WL_JMP(FID_SHOW_STEPS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K262)
  {
    WL_POPN(1);
    Term _h_11 = STK(0);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_11;
      STK(1) = FID_SHOW_STEPS_K263;
      WL_PUSHN(2);
    } else {
      u64 _t_19 = task_node(e, FID_SHOW_STEPS_K263, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _h_11;
      WL_CONT = term_tsk(FID_SHOW_STEPS_K263, _t_19);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_20 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = term_ctr(CID_SCON, STAT_OFF + 72);
      e.mem[_t_20 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_20);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 72);
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K263)
  {
    WL_POPN(1);
    Term _h_13 = STK(0);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SHOW_STEPS_K264;
      WL_PUSHN(1);
    } else {
      u64 _t_21 = task_node(e, FID_SHOW_STEPS_K264, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SHOW_STEPS_K264, _t_21);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_22 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _h_13;
      e.mem[_t_22 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_22);
    }
    r0 = _h_13;
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K264)
  {
    Term _h_14 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 96);
      e.mem[_t_23 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 96);
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SHOW_STEPS_K265)
  {
    Term _h_15 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 110);
      e.mem[_t_25 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 110);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K267;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K267, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K267, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K267)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    u32 _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _world_11;
      STK(12) = FID_CAPTURE_K269;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID_CAPTURE_K269, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      WL_CONT = term_tsk(FID_CAPTURE_K269, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_6;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _world_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K269)
  {
    WL_POPN(12);
    u32 _world_12 = STK(0);
    u32 _world_13 = STK(1);
    u32 _world_14 = STK(2);
    Term _world_15 = STK(3);
    u32 _world_16 = STK(4);
    Term _world_17 = STK(5);
    u32 _world_18 = STK(6);
    Term _world_19 = STK(7);
    Term _world_20 = STK(8);
    Term _world_21 = STK(9);
    u32 _world_22 = STK(10);
    u32 _world_23 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    _world_19 = term_keep(e, _world_19, 1);
    if (seq) {
      WL_ROOM(14);
      STK(0) = _world_12;
      STK(1) = _world_13;
      STK(2) = _world_14;
      STK(3) = _world_15;
      STK(4) = _world_16;
      STK(5) = _world_17;
      STK(6) = _world_18;
      STK(7) = _world_19;
      STK(8) = _world_20;
      STK(9) = _world_21;
      STK(10) = _world_22;
      STK(11) = _world_23;
      STK(12) = _h_0;
      STK(13) = FID_CAPTURE_K270;
      WL_PUSHN(14);
    } else {
      u64 _t_2 = task_node(e, FID_CAPTURE_K270, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _world_12;
      e.mem[_t_2 + 1] = _world_13;
      e.mem[_t_2 + 2] = _world_14;
      e.mem[_t_2 + 3] = _world_15;
      e.mem[_t_2 + 4] = _world_16;
      e.mem[_t_2 + 5] = _world_17;
      e.mem[_t_2 + 6] = _world_18;
      e.mem[_t_2 + 7] = _world_19;
      e.mem[_t_2 + 8] = _world_20;
      e.mem[_t_2 + 9] = _world_21;
      e.mem[_t_2 + 10] = _world_22;
      e.mem[_t_2 + 11] = _world_23;
      e.mem[_t_2 + 12] = _h_0;
      WL_CONT = term_tsk(FID_CAPTURE_K270, _t_2);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NUMBERS)) {
      u64 _t_3 = task_node(e, FID_NUMBERS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _world_19;
      return term_tsk(FID_NUMBERS, _t_3);
    }
    r0 = _world_19;
    WL_JMP(FID_NUMBERS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K270)
  {
    WL_POPN(13);
    u32 _world_24 = STK(0);
    u32 _world_25 = STK(1);
    u32 _world_26 = STK(2);
    Term _world_27 = STK(3);
    u32 _world_28 = STK(4);
    Term _world_29 = STK(5);
    u32 _world_30 = STK(6);
    Term _world_31 = STK(7);
    Term _world_32 = STK(8);
    Term _world_33 = STK(9);
    u32 _world_34 = STK(10);
    u32 _world_35 = STK(11);
    Term _h_2 = STK(12);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _world_24;
      STK(1) = _world_25;
      STK(2) = _world_26;
      STK(3) = _world_27;
      STK(4) = _world_28;
      STK(5) = _world_29;
      STK(6) = _world_30;
      STK(7) = _world_31;
      STK(8) = _world_32;
      STK(9) = _world_33;
      STK(10) = _world_34;
      STK(11) = _world_35;
      STK(12) = _h_2;
      STK(13) = FID_CAPTURE_K271;
      WL_PUSHN(14);
    } else {
      u64 _t_4 = task_node(e, FID_CAPTURE_K271, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _world_24;
      e.mem[_t_4 + 1] = _world_25;
      e.mem[_t_4 + 2] = _world_26;
      e.mem[_t_4 + 3] = _world_27;
      e.mem[_t_4 + 4] = _world_28;
      e.mem[_t_4 + 5] = _world_29;
      e.mem[_t_4 + 6] = _world_30;
      e.mem[_t_4 + 7] = _world_31;
      e.mem[_t_4 + 8] = _world_32;
      e.mem[_t_4 + 9] = _world_33;
      e.mem[_t_4 + 10] = _world_34;
      e.mem[_t_4 + 11] = _world_35;
      e.mem[_t_4 + 12] = _h_2;
      WL_CONT = term_tsk(FID_CAPTURE_K271, _t_4);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 56);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 56);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K271)
  {
    WL_POPN(13);
    u32 _world_36 = STK(0);
    u32 _world_37 = STK(1);
    u32 _world_38 = STK(2);
    Term _world_39 = STK(3);
    u32 _world_40 = STK(4);
    Term _world_41 = STK(5);
    u32 _world_42 = STK(6);
    Term _world_43 = STK(7);
    Term _world_44 = STK(8);
    Term _world_45 = STK(9);
    u32 _world_46 = STK(10);
    u32 _world_47 = STK(11);
    Term _h_4 = STK(12);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_36;
      STK(1) = _world_37;
      STK(2) = _world_38;
      STK(3) = _world_39;
      STK(4) = _world_40;
      STK(5) = _world_41;
      STK(6) = _world_42;
      STK(7) = _world_43;
      STK(8) = _world_44;
      STK(9) = _world_45;
      STK(10) = _world_46;
      STK(11) = _world_47;
      STK(12) = FID_CAPTURE_K272;
      WL_PUSHN(13);
    } else {
      u64 _t_6 = task_node(e, FID_CAPTURE_K272, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _world_36;
      e.mem[_t_6 + 1] = _world_37;
      e.mem[_t_6 + 2] = _world_38;
      e.mem[_t_6 + 3] = _world_39;
      e.mem[_t_6 + 4] = _world_40;
      e.mem[_t_6 + 5] = _world_41;
      e.mem[_t_6 + 6] = _world_42;
      e.mem[_t_6 + 7] = _world_43;
      e.mem[_t_6 + 8] = _world_44;
      e.mem[_t_6 + 9] = _world_45;
      e.mem[_t_6 + 10] = _world_46;
      e.mem[_t_6 + 11] = _world_47;
      WL_CONT = term_tsk(FID_CAPTURE_K272, _t_6);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K272)
  {
    WL_POPN(12);
    u32 _world_48 = STK(0);
    u32 _world_49 = STK(1);
    u32 _world_50 = STK(2);
    Term _world_51 = STK(3);
    u32 _world_52 = STK(4);
    Term _world_53 = STK(5);
    u32 _world_54 = STK(6);
    Term _world_55 = STK(7);
    Term _world_56 = STK(8);
    Term _world_57 = STK(9);
    u32 _world_58 = STK(10);
    u32 _world_59 = STK(11);
    Term _h_5 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _o_0[13];
    if (spin_39(e, _o_0, _world_48, _world_49, _world_50, _world_51, blk_loc(e.mem, _world_51), _world_52, _world_53, _world_54, _world_55, blk_loc(e.mem, _world_55), _world_56, blk_loc(e.mem, _world_56), _world_57, blk_loc(e.mem, _world_57), _world_58, _world_59) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_14 = _o_0[1];
    _v_15 = _o_0[2];
    _v_16 = _o_0[3];
    _v_17 = _o_0[4];
    _v_18 = _o_0[5];
    _v_19 = _o_0[6];
    _v_20 = _o_0[7];
    _v_21 = _o_0[8];
    _v_22 = _o_0[9];
    _v_23 = _o_0[10];
    _v_24 = _o_0[11];
    _v_25 = _o_0[12];
    _v_0 = _v_13;
    _v_1 = _v_14;
    _v_2 = _v_15;
    _v_3 = _v_16;
    _v_4 = _v_17;
    _v_5 = _v_18;
    _v_6 = _v_19;
    _v_7 = _v_20;
    _v_8 = _v_21;
    _v_9 = _v_22;
    _v_10 = _v_23;
    _v_11 = _v_24;
    _v_12 = _v_25;
    if (seq) {
      WL_ROOM(14);
      STK(0) = _v_0;
      STK(1) = _v_1;
      STK(2) = _v_2;
      STK(3) = _v_3;
      STK(4) = _v_4;
      STK(5) = _v_5;
      STK(6) = _v_6;
      STK(7) = _v_7;
      STK(8) = _v_8;
      STK(9) = _v_9;
      STK(10) = _v_10;
      STK(11) = _v_11;
      STK(12) = _h_5;
      STK(13) = FID_CAPTURE_K273;
      WL_PUSHN(14);
    } else {
      u64 _t_8 = task_node(e, FID_CAPTURE_K273, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _v_0;
      e.mem[_t_8 + 1] = _v_1;
      e.mem[_t_8 + 2] = _v_2;
      e.mem[_t_8 + 3] = _v_3;
      e.mem[_t_8 + 4] = _v_4;
      e.mem[_t_8 + 5] = _v_5;
      e.mem[_t_8 + 6] = _v_6;
      e.mem[_t_8 + 7] = _v_7;
      e.mem[_t_8 + 8] = _v_8;
      e.mem[_t_8 + 9] = _v_9;
      e.mem[_t_8 + 10] = _v_10;
      e.mem[_t_8 + 11] = _v_11;
      e.mem[_t_8 + 12] = _h_5;
      WL_CONT = term_tsk(FID_CAPTURE_K273, _t_8);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_IDS)) {
      u64 _t_9 = task_node(e, FID_IDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _v_12;
      return term_tsk(FID_IDS, _t_9);
    }
    r0 = _v_12;
    WL_JMP(FID_IDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K273)
  {
    WL_POPN(13);
    u32 _v_26 = STK(0);
    u32 _v_27 = STK(1);
    u32 _v_28 = STK(2);
    Term _v_29 = STK(3);
    u32 _v_30 = STK(4);
    Term _v_31 = STK(5);
    u32 _v_32 = STK(6);
    Term _v_33 = STK(7);
    Term _v_34 = STK(8);
    Term _v_35 = STK(9);
    u32 _v_36 = STK(10);
    u32 _v_37 = STK(11);
    Term _h_7 = STK(12);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _v_26;
      STK(1) = _v_27;
      STK(2) = _v_28;
      STK(3) = _v_29;
      STK(4) = _v_30;
      STK(5) = _v_31;
      STK(6) = _v_32;
      STK(7) = _v_33;
      STK(8) = _v_34;
      STK(9) = _v_35;
      STK(10) = _v_36;
      STK(11) = _v_37;
      STK(12) = _h_7;
      STK(13) = FID_CAPTURE_K274;
      WL_PUSHN(14);
    } else {
      u64 _t_10 = task_node(e, FID_CAPTURE_K274, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _v_26;
      e.mem[_t_10 + 1] = _v_27;
      e.mem[_t_10 + 2] = _v_28;
      e.mem[_t_10 + 3] = _v_29;
      e.mem[_t_10 + 4] = _v_30;
      e.mem[_t_10 + 5] = _v_31;
      e.mem[_t_10 + 6] = _v_32;
      e.mem[_t_10 + 7] = _v_33;
      e.mem[_t_10 + 8] = _v_34;
      e.mem[_t_10 + 9] = _v_35;
      e.mem[_t_10 + 10] = _v_36;
      e.mem[_t_10 + 11] = _v_37;
      e.mem[_t_10 + 12] = _h_7;
      WL_CONT = term_tsk(FID_CAPTURE_K274, _t_10);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 56);
      e.mem[_t_11 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 56);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K274)
  {
    WL_POPN(13);
    u32 _v_38 = STK(0);
    u32 _v_39 = STK(1);
    u32 _v_40 = STK(2);
    Term _v_41 = STK(3);
    u32 _v_42 = STK(4);
    Term _v_43 = STK(5);
    u32 _v_44 = STK(6);
    Term _v_45 = STK(7);
    Term _v_46 = STK(8);
    Term _v_47 = STK(9);
    u32 _v_48 = STK(10);
    u32 _v_49 = STK(11);
    Term _h_9 = STK(12);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _v_38;
      STK(1) = _v_39;
      STK(2) = _v_40;
      STK(3) = _v_41;
      STK(4) = _v_42;
      STK(5) = _v_43;
      STK(6) = _v_44;
      STK(7) = _v_45;
      STK(8) = _v_46;
      STK(9) = _v_47;
      STK(10) = _v_48;
      STK(11) = _v_49;
      STK(12) = FID_CAPTURE_K275;
      WL_PUSHN(13);
    } else {
      u64 _t_12 = task_node(e, FID_CAPTURE_K275, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _v_38;
      e.mem[_t_12 + 1] = _v_39;
      e.mem[_t_12 + 2] = _v_40;
      e.mem[_t_12 + 3] = _v_41;
      e.mem[_t_12 + 4] = _v_42;
      e.mem[_t_12 + 5] = _v_43;
      e.mem[_t_12 + 6] = _v_44;
      e.mem[_t_12 + 7] = _v_45;
      e.mem[_t_12 + 8] = _v_46;
      e.mem[_t_12 + 9] = _v_47;
      e.mem[_t_12 + 10] = _v_48;
      e.mem[_t_12 + 11] = _v_49;
      WL_CONT = term_tsk(FID_CAPTURE_K275, _t_12);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_9;
      e.mem[_t_13 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_9;
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CAPTURE_K275)
  {
    WL_POPN(12);
    u32 _v_50 = STK(0);
    u32 _v_51 = STK(1);
    u32 _v_52 = STK(2);
    Term _v_53 = STK(3);
    u32 _v_54 = STK(4);
    Term _v_55 = STK(5);
    u32 _v_56 = STK(6);
    Term _v_57 = STK(7);
    Term _v_58 = STK(8);
    Term _v_59 = STK(9);
    u32 _v_60 = STK(10);
    u32 _v_61 = STK(11);
    Term _h_10 = r0;
    WL_OPEN
    r0 = _v_50;
    r1 = _v_51;
    r2 = _v_52;
    r3 = _v_53;
    r4 = _v_54;
    r5 = _v_55;
    r6 = _v_56;
    r7 = _v_57;
    r8 = _v_58;
    r9 = _v_59;
    r10 = _v_60;
    r11 = _v_61;
    r12 = _h_10;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_CAPTURE)
  {
    u32 _schedule_0 = r0;
    Term _schedule_1 = r1;
    Term _schedule_2 = r2;
    u32 _schedule_3 = r3;
    u32 _schedule_4 = r4;
    Term _schedule_5 = r5;
    Term _schedule_6 = r6;
    u32 _schedule_7 = r7;
    u32 _schedule_8 = r8;
    u32 _schedule_9 = r9;
    Term _schedule_10 = r10;
    Term _schedule_11 = r11;
    u32 _schedule_12 = r12;
    u32 _captured_0 = r13;
    u32 _captured_1 = r14;
    u32 _captured_2 = r15;
    Term _captured_3 = r16;
    u32 _captured_4 = r17;
    Term _captured_5 = r18;
    u32 _captured_6 = r19;
    Term _captured_7 = r20;
    Term _captured_8 = r21;
    Term _captured_9 = r22;
    u32 _captured_10 = r23;
    u32 _captured_11 = r24;
    Term _captured_12 = r25;
    Term _lines_0 = r26;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _captured_12);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(26);
      STK(0) = _schedule_0;
      STK(1) = _schedule_1;
      STK(2) = _schedule_2;
      STK(3) = _schedule_3;
      STK(4) = _schedule_4;
      STK(5) = _schedule_5;
      STK(6) = _schedule_6;
      STK(7) = _schedule_7;
      STK(8) = _schedule_8;
      STK(9) = _schedule_9;
      STK(10) = _schedule_10;
      STK(11) = _schedule_11;
      STK(12) = _schedule_12;
      STK(13) = _captured_0;
      STK(14) = _captured_1;
      STK(15) = _captured_2;
      STK(16) = _captured_3;
      STK(17) = _captured_4;
      STK(18) = _captured_5;
      STK(19) = _captured_6;
      STK(20) = _captured_7;
      STK(21) = _captured_8;
      STK(22) = _captured_9;
      STK(23) = _captured_10;
      STK(24) = _captured_11;
      STK(25) = FID_RECORD_CAPTURE_K277;
      WL_PUSHN(26);
    } else {
      u64 _t_0 = task_node(e, FID_RECORD_CAPTURE_K277, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _schedule_0;
      e.mem[_t_0 + 1] = _schedule_1;
      e.mem[_t_0 + 2] = _schedule_2;
      e.mem[_t_0 + 3] = _schedule_3;
      e.mem[_t_0 + 4] = _schedule_4;
      e.mem[_t_0 + 5] = _schedule_5;
      e.mem[_t_0 + 6] = _schedule_6;
      e.mem[_t_0 + 7] = _schedule_7;
      e.mem[_t_0 + 8] = _schedule_8;
      e.mem[_t_0 + 9] = _schedule_9;
      e.mem[_t_0 + 10] = _schedule_10;
      e.mem[_t_0 + 11] = _schedule_11;
      e.mem[_t_0 + 12] = _schedule_12;
      e.mem[_t_0 + 13] = _captured_0;
      e.mem[_t_0 + 14] = _captured_1;
      e.mem[_t_0 + 15] = _captured_2;
      e.mem[_t_0 + 16] = _captured_3;
      e.mem[_t_0 + 17] = _captured_4;
      e.mem[_t_0 + 18] = _captured_5;
      e.mem[_t_0 + 19] = _captured_6;
      e.mem[_t_0 + 20] = _captured_7;
      e.mem[_t_0 + 21] = _captured_8;
      e.mem[_t_0 + 22] = _captured_9;
      e.mem[_t_0 + 23] = _captured_10;
      e.mem[_t_0 + 24] = _captured_11;
      WL_CONT = term_tsk(FID_RECORD_CAPTURE_K277, _t_0);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _lines_0;
      e.mem[_t_1 + 1] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID_LIST_APPEND, _t_1);
    }
    r0 = _lines_0;
    r1 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_CAPTURE_K277)
  {
    WL_POPN(25);
    u32 _schedule_13 = STK(0);
    Term _schedule_14 = STK(1);
    Term _schedule_15 = STK(2);
    u32 _schedule_16 = STK(3);
    u32 _schedule_17 = STK(4);
    Term _schedule_18 = STK(5);
    Term _schedule_19 = STK(6);
    u32 _schedule_20 = STK(7);
    u32 _schedule_21 = STK(8);
    u32 _schedule_22 = STK(9);
    Term _schedule_23 = STK(10);
    Term _schedule_24 = STK(11);
    u32 _schedule_25 = STK(12);
    u32 _captured_13 = STK(13);
    u32 _captured_14 = STK(14);
    u32 _captured_15 = STK(15);
    Term _captured_16 = STK(16);
    u32 _captured_17 = STK(17);
    Term _captured_18 = STK(18);
    u32 _captured_19 = STK(19);
    Term _captured_20 = STK(20);
    Term _captured_21 = STK(21);
    Term _captured_22 = STK(22);
    u32 _captured_23 = STK(23);
    u32 _captured_24 = STK(24);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _schedule_13;
    r1 = _schedule_14;
    r2 = _schedule_15;
    r3 = _schedule_16;
    r4 = _schedule_17;
    r5 = _schedule_18;
    r6 = _schedule_19;
    r7 = _schedule_20;
    r8 = _schedule_21;
    r9 = _schedule_22;
    r10 = _schedule_23;
    r11 = _schedule_24;
    r12 = _schedule_25;
    r13 = _captured_13;
    r14 = _captured_14;
    r15 = _captured_15;
    r16 = _captured_16;
    r17 = _captured_17;
    r18 = _captured_18;
    r19 = _captured_19;
    r20 = _captured_20;
    r21 = _captured_21;
    r22 = _captured_22;
    r23 = _captured_23;
    r24 = _captured_24;
    r25 = _h_0;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_RUN_1)
  {
    u32 _schedule_0 = r0;
    Term _schedule_1 = r1;
    Term _schedule_2 = r2;
    u32 _schedule_3 = r3;
    u32 _schedule_4 = r4;
    Term _schedule_5 = r5;
    Term _schedule_6 = r6;
    u32 _schedule_7 = r7;
    u32 _schedule_8 = r8;
    u32 _schedule_9 = r9;
    Term _schedule_10 = r10;
    Term _schedule_11 = r11;
    u32 _schedule_12 = r12;
    u32 _world_0 = r13;
    u32 _world_1 = r14;
    u32 _world_2 = r15;
    Term _world_3 = r16;
    u32 _world_4 = r17;
    Term _world_5 = r18;
    u32 _world_6 = r19;
    Term _world_7 = r20;
    Term _world_8 = r21;
    Term _world_9 = r22;
    u32 _world_10 = r23;
    u32 _world_11 = r24;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _o_0[13];
    if (spin_49(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_14 = _o_0[1];
    _v_15 = _o_0[2];
    _v_16 = _o_0[3];
    _v_17 = _o_0[4];
    _v_18 = _o_0[5];
    _v_19 = _o_0[6];
    _v_20 = _o_0[7];
    _v_21 = _o_0[8];
    _v_22 = _o_0[9];
    _v_23 = _o_0[10];
    _v_24 = _o_0[11];
    _v_25 = _o_0[12];
    _v_0 = _v_13;
    _v_1 = _v_14;
    _v_2 = _v_15;
    _v_3 = _v_16;
    _v_4 = _v_17;
    _v_5 = _v_18;
    _v_6 = _v_19;
    _v_7 = _v_20;
    _v_8 = _v_21;
    _v_9 = _v_22;
    _v_10 = _v_23;
    _v_11 = _v_24;
    _v_12 = _v_25;
    u32 _s_0 = U32_BIN(_schedule_0, ==, _v_12);
    if (_s_0 == 0) {
      r0 = 2;
      r1 = _schedule_0;
      r2 = _schedule_1;
      r3 = _schedule_2;
      r4 = _schedule_3;
      r5 = _schedule_4;
      r6 = _schedule_5;
      r7 = _schedule_6;
      r8 = _schedule_7;
      r9 = _schedule_8;
      r10 = _schedule_9;
      r11 = _schedule_10;
      r12 = _schedule_11;
      r13 = _schedule_12;
      r14 = _v_0;
      r15 = _v_1;
      r16 = _v_2;
      r17 = _v_3;
      r18 = _v_4;
      r19 = _v_5;
      r20 = _v_6;
      r21 = _v_7;
      r22 = _v_8;
      r23 = _v_9;
      r24 = _v_10;
      r25 = _v_11;
      r26 = 0;
      r27 = 0;
      WL_RETN(28);
    } else {
      _schedule_2 = term_keep(e, _schedule_2, 1);
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1)) {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_1, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _schedule_2;
        e.mem[_t_0 + 1] = _schedule_3;
        e.mem[_t_0 + 2] = _schedule_4;
        e.mem[_t_0 + 3] = _schedule_5;
        e.mem[_t_0 + 4] = _schedule_6;
        e.mem[_t_0 + 5] = _schedule_7;
        e.mem[_t_0 + 6] = _schedule_8;
        e.mem[_t_0 + 7] = _schedule_9;
        e.mem[_t_0 + 8] = _schedule_10;
        e.mem[_t_0 + 9] = _schedule_11;
        e.mem[_t_0 + 10] = _schedule_12;
        e.mem[_t_0 + 11] = _v_0;
        e.mem[_t_0 + 12] = _v_1;
        e.mem[_t_0 + 13] = _v_2;
        e.mem[_t_0 + 14] = _v_3;
        e.mem[_t_0 + 15] = _v_4;
        e.mem[_t_0 + 16] = _v_5;
        e.mem[_t_0 + 17] = _v_6;
        e.mem[_t_0 + 18] = _v_7;
        e.mem[_t_0 + 19] = _v_8;
        e.mem[_t_0 + 20] = _v_9;
        e.mem[_t_0 + 21] = _v_10;
        e.mem[_t_0 + 22] = _v_11;
        e.mem[_t_0 + 23] = _schedule_0;
        e.mem[_t_0 + 24] = _schedule_1;
        e.mem[_t_0 + 25] = _schedule_2;
        e.mem[_t_0 + 26] = term_pak(CID_NIL, 0);
        return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_1, _t_0);
      }
      r0 = _schedule_2;
      r1 = _schedule_3;
      r2 = _schedule_4;
      r3 = _schedule_5;
      r4 = _schedule_6;
      r5 = _schedule_7;
      r6 = _schedule_8;
      r7 = _schedule_9;
      r8 = _schedule_10;
      r9 = _schedule_11;
      r10 = _schedule_12;
      r11 = _v_0;
      r12 = _v_1;
      r13 = _v_2;
      r14 = _v_3;
      r15 = _v_4;
      r16 = _v_5;
      r17 = _v_6;
      r18 = _v_7;
      r19 = _v_8;
      r20 = _v_9;
      r21 = _v_10;
      r22 = _v_11;
      r23 = _schedule_0;
      r24 = _schedule_1;
      r25 = _schedule_2;
      r26 = term_pak(CID_NIL, 0);
      WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_VALID)
  {
    Term _steps_0 = r0;
    Term _catalog_0 = r1;
    Term _seen_0 = r2;
    WL_OPEN
    WL_SPIN
    if (term_aux(_steps_0) == CID_NIL) {
      term_sink(e, _catalog_0);
      term_sink(e, _seen_0);
      r0 = 1;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_SYSTEM) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID_______SRC_ECS_SCHEDULE_PHASE) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else {
        _o_0 = 2;
      }
      if (_o_0 == 1) {
        term_sink(e, _o_1);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_1;
        r1 = _catalog_0;
        r2 = _seen_0;
        _steps_0 = r0;
        _catalog_0 = r1;
        _seen_0 = r2;
        WL_AGAIN(FID_______SRC_ECS_SCHEDULE_VALID);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_1;
        r1 = _catalog_0;
        r2 = _seen_0;
        _steps_0 = r0;
        _catalog_0 = r1;
        _seen_0 = r2;
        WL_AGAIN(FID_______SRC_ECS_SCHEDULE_VALID);
      } else {
        _catalog_0 = term_keep(e, _catalog_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(5);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _catalog_0;
          STK(3) = _seen_0;
          STK(4) = FID_______SRC_ECS_SCHEDULE_VALID_K288;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_VALID_K288, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _f_1;
          e.mem[_t_0 + 2] = _catalog_0;
          e.mem[_t_0 + 3] = _seen_0;
          WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_VALID_K288, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_CONTAINS)) {
          u64 _t_1 = task_node(e, FID_______SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _catalog_0;
          e.mem[_t_1 + 1] = _o_1;
          return term_tsk(FID_______SRC_ECS_SCHEDULE_CONTAINS, _t_1);
        }
        r0 = _catalog_0;
        r1 = _o_1;
        WL_JMP(FID_______SRC_ECS_SCHEDULE_CONTAINS);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_VALID_K288)
  {
    WL_POPN(4);
    u32 _o_3 = STK(0);
    Term _f_5 = STK(1);
    Term _catalog_1 = STK(2);
    Term _seen_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    _seen_1 = term_keep(e, _seen_1, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _o_3;
      STK(1) = _f_5;
      STK(2) = _catalog_1;
      STK(3) = _seen_1;
      STK(4) = _h_0;
      STK(5) = FID_______SRC_ECS_SCHEDULE_VALID_K289;
      WL_PUSHN(6);
    } else {
      u64 _t_2 = task_node(e, FID_______SRC_ECS_SCHEDULE_VALID_K289, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_3;
      e.mem[_t_2 + 1] = _f_5;
      e.mem[_t_2 + 2] = _catalog_1;
      e.mem[_t_2 + 3] = _seen_1;
      e.mem[_t_2 + 4] = _h_0;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_VALID_K289, _t_2);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_CONTAINS)) {
      u64 _t_3 = task_node(e, FID_______SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _seen_1;
      e.mem[_t_3 + 1] = _o_3;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_CONTAINS, _t_3);
    }
    r0 = _seen_1;
    r1 = _o_3;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_CONTAINS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_VALID_K289)
  {
    WL_POPN(5);
    u32 _o_4 = STK(0);
    Term _f_6 = STK(1);
    Term _catalog_2 = STK(2);
    Term _seen_2 = STK(3);
    u32 _h_2 = STK(4);
    u32 _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _o_4);
    e.mem[_nd_0 + 1] = rfc_seal(e, _seen_2);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_______SRC_ECS_SCHEDULE_VALID_K290;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_______SRC_ECS_SCHEDULE_VALID_K290, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_VALID_K290, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_VALID)) {
      u64 _t_5 = task_node(e, FID_______SRC_ECS_SCHEDULE_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = _catalog_2;
      e.mem[_t_5 + 2] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID_______SRC_ECS_SCHEDULE_VALID, _t_5);
    }
    r0 = _f_6;
    r1 = _catalog_2;
    r2 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID_______SRC_ECS_SCHEDULE_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_VALID_K290)
  {
    WL_POPN(2);
    u32 _h_4 = STK(0);
    u32 _h_5 = STK(1);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _o_5[1];
    if (spin_20(e, _o_5, _h_5) == 0) {
      return 0;
    }
    _v_2 = _o_5[0];
    _v_1 = _v_2;
    u32 _v_3 = 0;
    Term _o_6[1];
    if (spin_2(e, _o_6, _v_1, _h_3) == 0) {
      return 0;
    }
    _v_3 = _o_6[0];
    _v_0 = _v_3;
    u32 _v_4 = 0;
    Term _o_7[1];
    if (spin_2(e, _o_7, _h_4, _v_0) == 0) {
      return 0;
    }
    _v_4 = _o_7[0];
    r0 = _v_4;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_RUN_0)
  {
    u32 _schedule_0 = r0;
    Term _schedule_1 = r1;
    Term _schedule_2 = r2;
    u32 _schedule_3 = r3;
    u32 _schedule_4 = r4;
    Term _schedule_5 = r5;
    Term _schedule_6 = r6;
    u32 _schedule_7 = r7;
    u32 _schedule_8 = r8;
    u32 _schedule_9 = r9;
    Term _schedule_10 = r10;
    Term _schedule_11 = r11;
    u32 _schedule_12 = r12;
    u32 _world_0 = r13;
    u32 _world_1 = r14;
    u32 _world_2 = r15;
    Term _world_3 = r16;
    u32 _world_4 = r17;
    Term _world_5 = r18;
    u32 _world_6 = r19;
    Term _world_7 = r20;
    Term _world_8 = r21;
    Term _world_9 = r22;
    u32 _world_10 = r23;
    u32 _world_11 = r24;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _o_0[13];
    if (spin_49(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, _world_11) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_14 = _o_0[1];
    _v_15 = _o_0[2];
    _v_16 = _o_0[3];
    _v_17 = _o_0[4];
    _v_18 = _o_0[5];
    _v_19 = _o_0[6];
    _v_20 = _o_0[7];
    _v_21 = _o_0[8];
    _v_22 = _o_0[9];
    _v_23 = _o_0[10];
    _v_24 = _o_0[11];
    _v_25 = _o_0[12];
    _v_0 = _v_13;
    _v_1 = _v_14;
    _v_2 = _v_15;
    _v_3 = _v_16;
    _v_4 = _v_17;
    _v_5 = _v_18;
    _v_6 = _v_19;
    _v_7 = _v_20;
    _v_8 = _v_21;
    _v_9 = _v_22;
    _v_10 = _v_23;
    _v_11 = _v_24;
    _v_12 = _v_25;
    u32 _s_0 = U32_BIN(_schedule_0, ==, _v_12);
    if (_s_0 == 0) {
      r0 = 2;
      r1 = _schedule_0;
      r2 = _schedule_1;
      r3 = _schedule_2;
      r4 = _schedule_3;
      r5 = _schedule_4;
      r6 = _schedule_5;
      r7 = _schedule_6;
      r8 = _schedule_7;
      r9 = _schedule_8;
      r10 = _schedule_9;
      r11 = _schedule_10;
      r12 = _schedule_11;
      r13 = _schedule_12;
      r14 = _v_0;
      r15 = _v_1;
      r16 = _v_2;
      r17 = _v_3;
      r18 = _v_4;
      r19 = _v_5;
      r20 = _v_6;
      r21 = _v_7;
      r22 = _v_8;
      r23 = _v_9;
      r24 = _v_10;
      r25 = _v_11;
      r26 = 0;
      r27 = 0;
      WL_RETN(28);
    } else {
      _schedule_2 = term_keep(e, _schedule_2, 1);
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0)) {
        u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_EXECUTE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _schedule_2;
        e.mem[_t_0 + 1] = _schedule_3;
        e.mem[_t_0 + 2] = _schedule_4;
        e.mem[_t_0 + 3] = _schedule_5;
        e.mem[_t_0 + 4] = _schedule_6;
        e.mem[_t_0 + 5] = _schedule_7;
        e.mem[_t_0 + 6] = _schedule_8;
        e.mem[_t_0 + 7] = _schedule_9;
        e.mem[_t_0 + 8] = _schedule_10;
        e.mem[_t_0 + 9] = _schedule_11;
        e.mem[_t_0 + 10] = _schedule_12;
        e.mem[_t_0 + 11] = _v_0;
        e.mem[_t_0 + 12] = _v_1;
        e.mem[_t_0 + 13] = _v_2;
        e.mem[_t_0 + 14] = _v_3;
        e.mem[_t_0 + 15] = _v_4;
        e.mem[_t_0 + 16] = _v_5;
        e.mem[_t_0 + 17] = _v_6;
        e.mem[_t_0 + 18] = _v_7;
        e.mem[_t_0 + 19] = _v_8;
        e.mem[_t_0 + 20] = _v_9;
        e.mem[_t_0 + 21] = _v_10;
        e.mem[_t_0 + 22] = _v_11;
        e.mem[_t_0 + 23] = _schedule_0;
        e.mem[_t_0 + 24] = _schedule_1;
        e.mem[_t_0 + 25] = _schedule_2;
        e.mem[_t_0 + 26] = term_pak(CID_NIL, 0);
        return term_tsk(FID_______SRC_ECS_SCHEDULE_EXECUTE_0, _t_0);
      }
      r0 = _schedule_2;
      r1 = _schedule_3;
      r2 = _schedule_4;
      r3 = _schedule_5;
      r4 = _schedule_6;
      r5 = _schedule_7;
      r6 = _schedule_8;
      r7 = _schedule_9;
      r8 = _schedule_10;
      r9 = _schedule_11;
      r10 = _schedule_12;
      r11 = _v_0;
      r12 = _v_1;
      r13 = _v_2;
      r14 = _v_3;
      r15 = _v_4;
      r16 = _v_5;
      r17 = _v_6;
      r18 = _v_7;
      r19 = _v_8;
      r20 = _v_9;
      r21 = _v_10;
      r22 = _v_11;
      r23 = _schedule_0;
      r24 = _schedule_1;
      r25 = _schedule_2;
      r26 = term_pak(CID_NIL, 0);
      WL_JMP(FID_______SRC_ECS_SCHEDULE_EXECUTE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    Term _result_2 = r2;
    Term _result_3 = r3;
    u32 _result_4 = r4;
    u32 _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    u32 _result_8 = r8;
    u32 _result_9 = r9;
    u32 _result_10 = r10;
    Term _result_11 = r11;
    Term _result_12 = r12;
    u32 _result_13 = r13;
    u32 _result_14 = r14;
    u32 _result_15 = r15;
    u32 _result_16 = r16;
    Term _result_17 = r17;
    u32 _result_18 = r18;
    Term _result_19 = r19;
    u32 _result_20 = r20;
    Term _result_21 = r21;
    Term _result_22 = r22;
    Term _result_23 = r23;
    u32 _result_24 = r24;
    u32 _result_25 = r25;
    Term _result_26 = r26;
    Term _result_27 = r27;
    Term _lines_0 = r28;
    WL_OPEN
    if (_result_0 == 0) {
      if (seq) {
        WL_ROOM(16);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = _result_26;
        STK(14) = _lines_0;
        STK(15) = FID_RECORD_RUN_K294;
        WL_PUSHN(16);
      } else {
        u64 _t_0 = task_node(e, FID_RECORD_RUN_K294, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_1;
        e.mem[_t_0 + 1] = _result_2;
        e.mem[_t_0 + 2] = _result_3;
        e.mem[_t_0 + 3] = _result_4;
        e.mem[_t_0 + 4] = _result_5;
        e.mem[_t_0 + 5] = _result_6;
        e.mem[_t_0 + 6] = _result_7;
        e.mem[_t_0 + 7] = _result_8;
        e.mem[_t_0 + 8] = _result_9;
        e.mem[_t_0 + 9] = _result_10;
        e.mem[_t_0 + 10] = _result_11;
        e.mem[_t_0 + 11] = _result_12;
        e.mem[_t_0 + 12] = _result_13;
        e.mem[_t_0 + 13] = _result_26;
        e.mem[_t_0 + 14] = _lines_0;
        WL_CONT = term_tsk(FID_RECORD_RUN_K294, _t_0);
        WL_IDX = 15;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CAPTURE)) {
        u64 _t_1 = task_node(e, FID_CAPTURE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _result_14;
        e.mem[_t_1 + 1] = _result_15;
        e.mem[_t_1 + 2] = _result_16;
        e.mem[_t_1 + 3] = _result_17;
        e.mem[_t_1 + 4] = _result_18;
        e.mem[_t_1 + 5] = _result_19;
        e.mem[_t_1 + 6] = _result_20;
        e.mem[_t_1 + 7] = _result_21;
        e.mem[_t_1 + 8] = _result_22;
        e.mem[_t_1 + 9] = _result_23;
        e.mem[_t_1 + 10] = _result_24;
        e.mem[_t_1 + 11] = _result_25;
        return term_tsk(FID_CAPTURE, _t_1);
      }
      r0 = _result_14;
      r1 = _result_15;
      r2 = _result_16;
      r3 = _result_17;
      r4 = _result_18;
      r5 = _result_19;
      r6 = _result_20;
      r7 = _result_21;
      r8 = _result_22;
      r9 = _result_23;
      r10 = _result_24;
      r11 = _result_25;
      WL_JMP(FID_CAPTURE);
    } else if (_result_0 == 1) {
      if (seq) {
        WL_ROOM(17);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = _result_26;
        STK(14) = _result_27;
        STK(15) = _lines_0;
        STK(16) = FID_RECORD_RUN_K298;
        WL_PUSHN(17);
      } else {
        u64 _t_9 = task_node(e, FID_RECORD_RUN_K298, WL_CONT, WL_IDX, 1);
        e.mem[_t_9 + 0] = _result_1;
        e.mem[_t_9 + 1] = _result_2;
        e.mem[_t_9 + 2] = _result_3;
        e.mem[_t_9 + 3] = _result_4;
        e.mem[_t_9 + 4] = _result_5;
        e.mem[_t_9 + 5] = _result_6;
        e.mem[_t_9 + 6] = _result_7;
        e.mem[_t_9 + 7] = _result_8;
        e.mem[_t_9 + 8] = _result_9;
        e.mem[_t_9 + 9] = _result_10;
        e.mem[_t_9 + 10] = _result_11;
        e.mem[_t_9 + 11] = _result_12;
        e.mem[_t_9 + 12] = _result_13;
        e.mem[_t_9 + 13] = _result_26;
        e.mem[_t_9 + 14] = _result_27;
        e.mem[_t_9 + 15] = _lines_0;
        WL_CONT = term_tsk(FID_RECORD_RUN_K298, _t_9);
        WL_IDX = 16;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CAPTURE)) {
        u64 _t_10 = task_node(e, FID_CAPTURE, WL_CONT, WL_IDX, 0);
        e.mem[_t_10 + 0] = _result_14;
        e.mem[_t_10 + 1] = _result_15;
        e.mem[_t_10 + 2] = _result_16;
        e.mem[_t_10 + 3] = _result_17;
        e.mem[_t_10 + 4] = _result_18;
        e.mem[_t_10 + 5] = _result_19;
        e.mem[_t_10 + 6] = _result_20;
        e.mem[_t_10 + 7] = _result_21;
        e.mem[_t_10 + 8] = _result_22;
        e.mem[_t_10 + 9] = _result_23;
        e.mem[_t_10 + 10] = _result_24;
        e.mem[_t_10 + 11] = _result_25;
        return term_tsk(FID_CAPTURE, _t_10);
      }
      r0 = _result_14;
      r1 = _result_15;
      r2 = _result_16;
      r3 = _result_17;
      r4 = _result_18;
      r5 = _result_19;
      r6 = _result_20;
      r7 = _result_21;
      r8 = _result_22;
      r9 = _result_23;
      r10 = _result_24;
      r11 = _result_25;
      WL_JMP(FID_CAPTURE);
    } else {
      if (seq) {
        WL_ROOM(15);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = _result_10;
        STK(10) = _result_11;
        STK(11) = _result_12;
        STK(12) = _result_13;
        STK(13) = _lines_0;
        STK(14) = FID_RECORD_RUN_K304;
        WL_PUSHN(15);
      } else {
        u64 _t_22 = task_node(e, FID_RECORD_RUN_K304, WL_CONT, WL_IDX, 1);
        e.mem[_t_22 + 0] = _result_1;
        e.mem[_t_22 + 1] = _result_2;
        e.mem[_t_22 + 2] = _result_3;
        e.mem[_t_22 + 3] = _result_4;
        e.mem[_t_22 + 4] = _result_5;
        e.mem[_t_22 + 5] = _result_6;
        e.mem[_t_22 + 6] = _result_7;
        e.mem[_t_22 + 7] = _result_8;
        e.mem[_t_22 + 8] = _result_9;
        e.mem[_t_22 + 9] = _result_10;
        e.mem[_t_22 + 10] = _result_11;
        e.mem[_t_22 + 11] = _result_12;
        e.mem[_t_22 + 12] = _result_13;
        e.mem[_t_22 + 13] = _lines_0;
        WL_CONT = term_tsk(FID_RECORD_RUN_K304, _t_22);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CAPTURE)) {
        u64 _t_23 = task_node(e, FID_CAPTURE, WL_CONT, WL_IDX, 0);
        e.mem[_t_23 + 0] = _result_14;
        e.mem[_t_23 + 1] = _result_15;
        e.mem[_t_23 + 2] = _result_16;
        e.mem[_t_23 + 3] = _result_17;
        e.mem[_t_23 + 4] = _result_18;
        e.mem[_t_23 + 5] = _result_19;
        e.mem[_t_23 + 6] = _result_20;
        e.mem[_t_23 + 7] = _result_21;
        e.mem[_t_23 + 8] = _result_22;
        e.mem[_t_23 + 9] = _result_23;
        e.mem[_t_23 + 10] = _result_24;
        e.mem[_t_23 + 11] = _result_25;
        return term_tsk(FID_CAPTURE, _t_23);
      }
      r0 = _result_14;
      r1 = _result_15;
      r2 = _result_16;
      r3 = _result_17;
      r4 = _result_18;
      r5 = _result_19;
      r6 = _result_20;
      r7 = _result_21;
      r8 = _result_22;
      r9 = _result_23;
      r10 = _result_24;
      r11 = _result_25;
      WL_JMP(FID_CAPTURE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K294)
  {
    WL_POPN(15);
    u32 _result_28 = STK(0);
    Term _result_29 = STK(1);
    Term _result_30 = STK(2);
    u32 _result_31 = STK(3);
    u32 _result_32 = STK(4);
    Term _result_33 = STK(5);
    Term _result_34 = STK(6);
    u32 _result_35 = STK(7);
    u32 _result_36 = STK(8);
    u32 _result_37 = STK(9);
    Term _result_38 = STK(10);
    Term _result_39 = STK(11);
    u32 _result_40 = STK(12);
    Term _result_41 = STK(13);
    Term _lines_1 = STK(14);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _result_28;
      STK(1) = _result_29;
      STK(2) = _result_30;
      STK(3) = _result_31;
      STK(4) = _result_32;
      STK(5) = _result_33;
      STK(6) = _result_34;
      STK(7) = _result_35;
      STK(8) = _result_36;
      STK(9) = _result_37;
      STK(10) = _result_38;
      STK(11) = _result_39;
      STK(12) = _result_40;
      STK(13) = _lines_1;
      STK(14) = _h_0;
      STK(15) = _h_1;
      STK(16) = _h_2;
      STK(17) = _h_3;
      STK(18) = _h_4;
      STK(19) = _h_5;
      STK(20) = _h_6;
      STK(21) = _h_7;
      STK(22) = _h_8;
      STK(23) = _h_9;
      STK(24) = _h_10;
      STK(25) = _h_11;
      STK(26) = _h_12;
      STK(27) = FID_RECORD_RUN_K295;
      WL_PUSHN(28);
    } else {
      u64 _t_2 = task_node(e, FID_RECORD_RUN_K295, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _result_28;
      e.mem[_t_2 + 1] = _result_29;
      e.mem[_t_2 + 2] = _result_30;
      e.mem[_t_2 + 3] = _result_31;
      e.mem[_t_2 + 4] = _result_32;
      e.mem[_t_2 + 5] = _result_33;
      e.mem[_t_2 + 6] = _result_34;
      e.mem[_t_2 + 7] = _result_35;
      e.mem[_t_2 + 8] = _result_36;
      e.mem[_t_2 + 9] = _result_37;
      e.mem[_t_2 + 10] = _result_38;
      e.mem[_t_2 + 11] = _result_39;
      e.mem[_t_2 + 12] = _result_40;
      e.mem[_t_2 + 13] = _lines_1;
      e.mem[_t_2 + 14] = _h_0;
      e.mem[_t_2 + 15] = _h_1;
      e.mem[_t_2 + 16] = _h_2;
      e.mem[_t_2 + 17] = _h_3;
      e.mem[_t_2 + 18] = _h_4;
      e.mem[_t_2 + 19] = _h_5;
      e.mem[_t_2 + 20] = _h_6;
      e.mem[_t_2 + 21] = _h_7;
      e.mem[_t_2 + 22] = _h_8;
      e.mem[_t_2 + 23] = _h_9;
      e.mem[_t_2 + 24] = _h_10;
      e.mem[_t_2 + 25] = _h_11;
      e.mem[_t_2 + 26] = _h_12;
      WL_CONT = term_tsk(FID_RECORD_RUN_K295, _t_2);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SHOW_STEPS)) {
      u64 _t_3 = task_node(e, FID_SHOW_STEPS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _result_41;
      return term_tsk(FID_SHOW_STEPS, _t_3);
    }
    r0 = _result_41;
    WL_JMP(FID_SHOW_STEPS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K295)
  {
    WL_POPN(27);
    u32 _result_42 = STK(0);
    Term _result_43 = STK(1);
    Term _result_44 = STK(2);
    u32 _result_45 = STK(3);
    u32 _result_46 = STK(4);
    Term _result_47 = STK(5);
    Term _result_48 = STK(6);
    u32 _result_49 = STK(7);
    u32 _result_50 = STK(8);
    u32 _result_51 = STK(9);
    Term _result_52 = STK(10);
    Term _result_53 = STK(11);
    u32 _result_54 = STK(12);
    Term _lines_2 = STK(13);
    u32 _h_14 = STK(14);
    u32 _h_15 = STK(15);
    u32 _h_16 = STK(16);
    Term _h_17 = STK(17);
    u32 _h_18 = STK(18);
    Term _h_19 = STK(19);
    u32 _h_20 = STK(20);
    Term _h_21 = STK(21);
    Term _h_22 = STK(22);
    Term _h_23 = STK(23);
    u32 _h_24 = STK(24);
    u32 _h_25 = STK(25);
    Term _h_26 = STK(26);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _result_42;
      STK(1) = _result_43;
      STK(2) = _result_44;
      STK(3) = _result_45;
      STK(4) = _result_46;
      STK(5) = _result_47;
      STK(6) = _result_48;
      STK(7) = _result_49;
      STK(8) = _result_50;
      STK(9) = _result_51;
      STK(10) = _result_52;
      STK(11) = _result_53;
      STK(12) = _result_54;
      STK(13) = _lines_2;
      STK(14) = _h_14;
      STK(15) = _h_15;
      STK(16) = _h_16;
      STK(17) = _h_17;
      STK(18) = _h_18;
      STK(19) = _h_19;
      STK(20) = _h_20;
      STK(21) = _h_21;
      STK(22) = _h_22;
      STK(23) = _h_23;
      STK(24) = _h_24;
      STK(25) = _h_25;
      STK(26) = _h_26;
      STK(27) = FID_RECORD_RUN_K296;
      WL_PUSHN(28);
    } else {
      u64 _t_4 = task_node(e, FID_RECORD_RUN_K296, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _result_42;
      e.mem[_t_4 + 1] = _result_43;
      e.mem[_t_4 + 2] = _result_44;
      e.mem[_t_4 + 3] = _result_45;
      e.mem[_t_4 + 4] = _result_46;
      e.mem[_t_4 + 5] = _result_47;
      e.mem[_t_4 + 6] = _result_48;
      e.mem[_t_4 + 7] = _result_49;
      e.mem[_t_4 + 8] = _result_50;
      e.mem[_t_4 + 9] = _result_51;
      e.mem[_t_4 + 10] = _result_52;
      e.mem[_t_4 + 11] = _result_53;
      e.mem[_t_4 + 12] = _result_54;
      e.mem[_t_4 + 13] = _lines_2;
      e.mem[_t_4 + 14] = _h_14;
      e.mem[_t_4 + 15] = _h_15;
      e.mem[_t_4 + 16] = _h_16;
      e.mem[_t_4 + 17] = _h_17;
      e.mem[_t_4 + 18] = _h_18;
      e.mem[_t_4 + 19] = _h_19;
      e.mem[_t_4 + 20] = _h_20;
      e.mem[_t_4 + 21] = _h_21;
      e.mem[_t_4 + 22] = _h_22;
      e.mem[_t_4 + 23] = _h_23;
      e.mem[_t_4 + 24] = _h_24;
      e.mem[_t_4 + 25] = _h_25;
      e.mem[_t_4 + 26] = _h_26;
      WL_CONT = term_tsk(FID_RECORD_RUN_K296, _t_4);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 114);
      e.mem[_t_5 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 114);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K296)
  {
    WL_POPN(27);
    u32 _result_55 = STK(0);
    Term _result_56 = STK(1);
    Term _result_57 = STK(2);
    u32 _result_58 = STK(3);
    u32 _result_59 = STK(4);
    Term _result_60 = STK(5);
    Term _result_61 = STK(6);
    u32 _result_62 = STK(7);
    u32 _result_63 = STK(8);
    u32 _result_64 = STK(9);
    Term _result_65 = STK(10);
    Term _result_66 = STK(11);
    u32 _result_67 = STK(12);
    Term _lines_3 = STK(13);
    u32 _h_28 = STK(14);
    u32 _h_29 = STK(15);
    u32 _h_30 = STK(16);
    Term _h_31 = STK(17);
    u32 _h_32 = STK(18);
    Term _h_33 = STK(19);
    u32 _h_34 = STK(20);
    Term _h_35 = STK(21);
    Term _h_36 = STK(22);
    Term _h_37 = STK(23);
    u32 _h_38 = STK(24);
    u32 _h_39 = STK(25);
    Term _h_40 = STK(26);
    Term _h_27 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_27);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(27);
      STK(0) = _result_55;
      STK(1) = _result_56;
      STK(2) = _result_57;
      STK(3) = _result_58;
      STK(4) = _result_59;
      STK(5) = _result_60;
      STK(6) = _result_61;
      STK(7) = _result_62;
      STK(8) = _result_63;
      STK(9) = _result_64;
      STK(10) = _result_65;
      STK(11) = _result_66;
      STK(12) = _result_67;
      STK(13) = _h_28;
      STK(14) = _h_29;
      STK(15) = _h_30;
      STK(16) = _h_31;
      STK(17) = _h_32;
      STK(18) = _h_33;
      STK(19) = _h_34;
      STK(20) = _h_35;
      STK(21) = _h_36;
      STK(22) = _h_37;
      STK(23) = _h_38;
      STK(24) = _h_39;
      STK(25) = _h_40;
      STK(26) = FID_RECORD_RUN_K297;
      WL_PUSHN(27);
    } else {
      u64 _t_6 = task_node(e, FID_RECORD_RUN_K297, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _result_55;
      e.mem[_t_6 + 1] = _result_56;
      e.mem[_t_6 + 2] = _result_57;
      e.mem[_t_6 + 3] = _result_58;
      e.mem[_t_6 + 4] = _result_59;
      e.mem[_t_6 + 5] = _result_60;
      e.mem[_t_6 + 6] = _result_61;
      e.mem[_t_6 + 7] = _result_62;
      e.mem[_t_6 + 8] = _result_63;
      e.mem[_t_6 + 9] = _result_64;
      e.mem[_t_6 + 10] = _result_65;
      e.mem[_t_6 + 11] = _result_66;
      e.mem[_t_6 + 12] = _result_67;
      e.mem[_t_6 + 13] = _h_28;
      e.mem[_t_6 + 14] = _h_29;
      e.mem[_t_6 + 15] = _h_30;
      e.mem[_t_6 + 16] = _h_31;
      e.mem[_t_6 + 17] = _h_32;
      e.mem[_t_6 + 18] = _h_33;
      e.mem[_t_6 + 19] = _h_34;
      e.mem[_t_6 + 20] = _h_35;
      e.mem[_t_6 + 21] = _h_36;
      e.mem[_t_6 + 22] = _h_37;
      e.mem[_t_6 + 23] = _h_38;
      e.mem[_t_6 + 24] = _h_39;
      e.mem[_t_6 + 25] = _h_40;
      WL_CONT = term_tsk(FID_RECORD_RUN_K297, _t_6);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_7 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _lines_3;
      e.mem[_t_7 + 1] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID_LIST_APPEND, _t_7);
    }
    r0 = _lines_3;
    r1 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K297)
  {
    WL_POPN(26);
    u32 _result_68 = STK(0);
    Term _result_69 = STK(1);
    Term _result_70 = STK(2);
    u32 _result_71 = STK(3);
    u32 _result_72 = STK(4);
    Term _result_73 = STK(5);
    Term _result_74 = STK(6);
    u32 _result_75 = STK(7);
    u32 _result_76 = STK(8);
    u32 _result_77 = STK(9);
    Term _result_78 = STK(10);
    Term _result_79 = STK(11);
    u32 _result_80 = STK(12);
    u32 _h_42 = STK(13);
    u32 _h_43 = STK(14);
    u32 _h_44 = STK(15);
    Term _h_45 = STK(16);
    u32 _h_46 = STK(17);
    Term _h_47 = STK(18);
    u32 _h_48 = STK(19);
    Term _h_49 = STK(20);
    Term _h_50 = STK(21);
    Term _h_51 = STK(22);
    u32 _h_52 = STK(23);
    u32 _h_53 = STK(24);
    Term _h_54 = STK(25);
    Term _h_41 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_CAPTURE)) {
      u64 _t_8 = task_node(e, FID_RECORD_CAPTURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _result_68;
      e.mem[_t_8 + 1] = _result_69;
      e.mem[_t_8 + 2] = _result_70;
      e.mem[_t_8 + 3] = _result_71;
      e.mem[_t_8 + 4] = _result_72;
      e.mem[_t_8 + 5] = _result_73;
      e.mem[_t_8 + 6] = _result_74;
      e.mem[_t_8 + 7] = _result_75;
      e.mem[_t_8 + 8] = _result_76;
      e.mem[_t_8 + 9] = _result_77;
      e.mem[_t_8 + 10] = _result_78;
      e.mem[_t_8 + 11] = _result_79;
      e.mem[_t_8 + 12] = _result_80;
      e.mem[_t_8 + 13] = _h_42;
      e.mem[_t_8 + 14] = _h_43;
      e.mem[_t_8 + 15] = _h_44;
      e.mem[_t_8 + 16] = _h_45;
      e.mem[_t_8 + 17] = _h_46;
      e.mem[_t_8 + 18] = _h_47;
      e.mem[_t_8 + 19] = _h_48;
      e.mem[_t_8 + 20] = _h_49;
      e.mem[_t_8 + 21] = _h_50;
      e.mem[_t_8 + 22] = _h_51;
      e.mem[_t_8 + 23] = _h_52;
      e.mem[_t_8 + 24] = _h_53;
      e.mem[_t_8 + 25] = _h_54;
      e.mem[_t_8 + 26] = _h_41;
      return term_tsk(FID_RECORD_CAPTURE, _t_8);
    }
    r0 = _result_68;
    r1 = _result_69;
    r2 = _result_70;
    r3 = _result_71;
    r4 = _result_72;
    r5 = _result_73;
    r6 = _result_74;
    r7 = _result_75;
    r8 = _result_76;
    r9 = _result_77;
    r10 = _result_78;
    r11 = _result_79;
    r12 = _result_80;
    r13 = _h_42;
    r14 = _h_43;
    r15 = _h_44;
    r16 = _h_45;
    r17 = _h_46;
    r18 = _h_47;
    r19 = _h_48;
    r20 = _h_49;
    r21 = _h_50;
    r22 = _h_51;
    r23 = _h_52;
    r24 = _h_53;
    r25 = _h_54;
    r26 = _h_41;
    WL_JMP(FID_RECORD_CAPTURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K298)
  {
    WL_POPN(16);
    u32 _result_81 = STK(0);
    Term _result_82 = STK(1);
    Term _result_83 = STK(2);
    u32 _result_84 = STK(3);
    u32 _result_85 = STK(4);
    Term _result_86 = STK(5);
    Term _result_87 = STK(6);
    u32 _result_88 = STK(7);
    u32 _result_89 = STK(8);
    u32 _result_90 = STK(9);
    Term _result_91 = STK(10);
    Term _result_92 = STK(11);
    u32 _result_93 = STK(12);
    Term _result_94 = STK(13);
    Term _result_95 = STK(14);
    Term _lines_4 = STK(15);
    u32 _h_55 = r0;
    u32 _h_56 = r1;
    u32 _h_57 = r2;
    Term _h_58 = r3;
    u32 _h_59 = r4;
    Term _h_60 = r5;
    u32 _h_61 = r6;
    Term _h_62 = r7;
    Term _h_63 = r8;
    Term _h_64 = r9;
    u32 _h_65 = r10;
    u32 _h_66 = r11;
    Term _h_67 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _result_81;
      STK(1) = _result_82;
      STK(2) = _result_83;
      STK(3) = _result_84;
      STK(4) = _result_85;
      STK(5) = _result_86;
      STK(6) = _result_87;
      STK(7) = _result_88;
      STK(8) = _result_89;
      STK(9) = _result_90;
      STK(10) = _result_91;
      STK(11) = _result_92;
      STK(12) = _result_93;
      STK(13) = _result_94;
      STK(14) = _lines_4;
      STK(15) = _h_55;
      STK(16) = _h_56;
      STK(17) = _h_57;
      STK(18) = _h_58;
      STK(19) = _h_59;
      STK(20) = _h_60;
      STK(21) = _h_61;
      STK(22) = _h_62;
      STK(23) = _h_63;
      STK(24) = _h_64;
      STK(25) = _h_65;
      STK(26) = _h_66;
      STK(27) = _h_67;
      STK(28) = FID_RECORD_RUN_K299;
      WL_PUSHN(29);
    } else {
      u64 _t_11 = task_node(e, FID_RECORD_RUN_K299, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _result_81;
      e.mem[_t_11 + 1] = _result_82;
      e.mem[_t_11 + 2] = _result_83;
      e.mem[_t_11 + 3] = _result_84;
      e.mem[_t_11 + 4] = _result_85;
      e.mem[_t_11 + 5] = _result_86;
      e.mem[_t_11 + 6] = _result_87;
      e.mem[_t_11 + 7] = _result_88;
      e.mem[_t_11 + 8] = _result_89;
      e.mem[_t_11 + 9] = _result_90;
      e.mem[_t_11 + 10] = _result_91;
      e.mem[_t_11 + 11] = _result_92;
      e.mem[_t_11 + 12] = _result_93;
      e.mem[_t_11 + 13] = _result_94;
      e.mem[_t_11 + 14] = _lines_4;
      e.mem[_t_11 + 15] = _h_55;
      e.mem[_t_11 + 16] = _h_56;
      e.mem[_t_11 + 17] = _h_57;
      e.mem[_t_11 + 18] = _h_58;
      e.mem[_t_11 + 19] = _h_59;
      e.mem[_t_11 + 20] = _h_60;
      e.mem[_t_11 + 21] = _h_61;
      e.mem[_t_11 + 22] = _h_62;
      e.mem[_t_11 + 23] = _h_63;
      e.mem[_t_11 + 24] = _h_64;
      e.mem[_t_11 + 25] = _h_65;
      e.mem[_t_11 + 26] = _h_66;
      e.mem[_t_11 + 27] = _h_67;
      WL_CONT = term_tsk(FID_RECORD_RUN_K299, _t_11);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SHOW_STEPS)) {
      u64 _t_12 = task_node(e, FID_SHOW_STEPS, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _result_95;
      return term_tsk(FID_SHOW_STEPS, _t_12);
    }
    r0 = _result_95;
    WL_JMP(FID_SHOW_STEPS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K299)
  {
    WL_POPN(28);
    u32 _result_96 = STK(0);
    Term _result_97 = STK(1);
    Term _result_98 = STK(2);
    u32 _result_99 = STK(3);
    u32 _result_100 = STK(4);
    Term _result_101 = STK(5);
    Term _result_102 = STK(6);
    u32 _result_103 = STK(7);
    u32 _result_104 = STK(8);
    u32 _result_105 = STK(9);
    Term _result_106 = STK(10);
    Term _result_107 = STK(11);
    u32 _result_108 = STK(12);
    Term _result_109 = STK(13);
    Term _lines_5 = STK(14);
    u32 _h_69 = STK(15);
    u32 _h_70 = STK(16);
    u32 _h_71 = STK(17);
    Term _h_72 = STK(18);
    u32 _h_73 = STK(19);
    Term _h_74 = STK(20);
    u32 _h_75 = STK(21);
    Term _h_76 = STK(22);
    Term _h_77 = STK(23);
    Term _h_78 = STK(24);
    u32 _h_79 = STK(25);
    u32 _h_80 = STK(26);
    Term _h_81 = STK(27);
    Term _h_68 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _result_96;
      STK(1) = _result_97;
      STK(2) = _result_98;
      STK(3) = _result_99;
      STK(4) = _result_100;
      STK(5) = _result_101;
      STK(6) = _result_102;
      STK(7) = _result_103;
      STK(8) = _result_104;
      STK(9) = _result_105;
      STK(10) = _result_106;
      STK(11) = _result_107;
      STK(12) = _result_108;
      STK(13) = _result_109;
      STK(14) = _lines_5;
      STK(15) = _h_69;
      STK(16) = _h_70;
      STK(17) = _h_71;
      STK(18) = _h_72;
      STK(19) = _h_73;
      STK(20) = _h_74;
      STK(21) = _h_75;
      STK(22) = _h_76;
      STK(23) = _h_77;
      STK(24) = _h_78;
      STK(25) = _h_79;
      STK(26) = _h_80;
      STK(27) = _h_81;
      STK(28) = FID_RECORD_RUN_K300;
      WL_PUSHN(29);
    } else {
      u64 _t_13 = task_node(e, FID_RECORD_RUN_K300, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _result_96;
      e.mem[_t_13 + 1] = _result_97;
      e.mem[_t_13 + 2] = _result_98;
      e.mem[_t_13 + 3] = _result_99;
      e.mem[_t_13 + 4] = _result_100;
      e.mem[_t_13 + 5] = _result_101;
      e.mem[_t_13 + 6] = _result_102;
      e.mem[_t_13 + 7] = _result_103;
      e.mem[_t_13 + 8] = _result_104;
      e.mem[_t_13 + 9] = _result_105;
      e.mem[_t_13 + 10] = _result_106;
      e.mem[_t_13 + 11] = _result_107;
      e.mem[_t_13 + 12] = _result_108;
      e.mem[_t_13 + 13] = _result_109;
      e.mem[_t_13 + 14] = _lines_5;
      e.mem[_t_13 + 15] = _h_69;
      e.mem[_t_13 + 16] = _h_70;
      e.mem[_t_13 + 17] = _h_71;
      e.mem[_t_13 + 18] = _h_72;
      e.mem[_t_13 + 19] = _h_73;
      e.mem[_t_13 + 20] = _h_74;
      e.mem[_t_13 + 21] = _h_75;
      e.mem[_t_13 + 22] = _h_76;
      e.mem[_t_13 + 23] = _h_77;
      e.mem[_t_13 + 24] = _h_78;
      e.mem[_t_13 + 25] = _h_79;
      e.mem[_t_13 + 26] = _h_80;
      e.mem[_t_13 + 27] = _h_81;
      WL_CONT = term_tsk(FID_RECORD_RUN_K300, _t_13);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 56);
      e.mem[_t_14 + 1] = _h_68;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 56);
    r1 = _h_68;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K300)
  {
    WL_POPN(28);
    u32 _result_110 = STK(0);
    Term _result_111 = STK(1);
    Term _result_112 = STK(2);
    u32 _result_113 = STK(3);
    u32 _result_114 = STK(4);
    Term _result_115 = STK(5);
    Term _result_116 = STK(6);
    u32 _result_117 = STK(7);
    u32 _result_118 = STK(8);
    u32 _result_119 = STK(9);
    Term _result_120 = STK(10);
    Term _result_121 = STK(11);
    u32 _result_122 = STK(12);
    Term _result_123 = STK(13);
    Term _lines_6 = STK(14);
    u32 _h_83 = STK(15);
    u32 _h_84 = STK(16);
    u32 _h_85 = STK(17);
    Term _h_86 = STK(18);
    u32 _h_87 = STK(19);
    Term _h_88 = STK(20);
    u32 _h_89 = STK(21);
    Term _h_90 = STK(22);
    Term _h_91 = STK(23);
    Term _h_92 = STK(24);
    u32 _h_93 = STK(25);
    u32 _h_94 = STK(26);
    Term _h_95 = STK(27);
    Term _h_82 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _result_110;
      STK(1) = _result_111;
      STK(2) = _result_112;
      STK(3) = _result_113;
      STK(4) = _result_114;
      STK(5) = _result_115;
      STK(6) = _result_116;
      STK(7) = _result_117;
      STK(8) = _result_118;
      STK(9) = _result_119;
      STK(10) = _result_120;
      STK(11) = _result_121;
      STK(12) = _result_122;
      STK(13) = _lines_6;
      STK(14) = _h_83;
      STK(15) = _h_84;
      STK(16) = _h_85;
      STK(17) = _h_86;
      STK(18) = _h_87;
      STK(19) = _h_88;
      STK(20) = _h_89;
      STK(21) = _h_90;
      STK(22) = _h_91;
      STK(23) = _h_92;
      STK(24) = _h_93;
      STK(25) = _h_94;
      STK(26) = _h_95;
      STK(27) = FID_RECORD_RUN_K301;
      WL_PUSHN(28);
    } else {
      u64 _t_15 = task_node(e, FID_RECORD_RUN_K301, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _result_110;
      e.mem[_t_15 + 1] = _result_111;
      e.mem[_t_15 + 2] = _result_112;
      e.mem[_t_15 + 3] = _result_113;
      e.mem[_t_15 + 4] = _result_114;
      e.mem[_t_15 + 5] = _result_115;
      e.mem[_t_15 + 6] = _result_116;
      e.mem[_t_15 + 7] = _result_117;
      e.mem[_t_15 + 8] = _result_118;
      e.mem[_t_15 + 9] = _result_119;
      e.mem[_t_15 + 10] = _result_120;
      e.mem[_t_15 + 11] = _result_121;
      e.mem[_t_15 + 12] = _result_122;
      e.mem[_t_15 + 13] = _lines_6;
      e.mem[_t_15 + 14] = _h_83;
      e.mem[_t_15 + 15] = _h_84;
      e.mem[_t_15 + 16] = _h_85;
      e.mem[_t_15 + 17] = _h_86;
      e.mem[_t_15 + 18] = _h_87;
      e.mem[_t_15 + 19] = _h_88;
      e.mem[_t_15 + 20] = _h_89;
      e.mem[_t_15 + 21] = _h_90;
      e.mem[_t_15 + 22] = _h_91;
      e.mem[_t_15 + 23] = _h_92;
      e.mem[_t_15 + 24] = _h_93;
      e.mem[_t_15 + 25] = _h_94;
      e.mem[_t_15 + 26] = _h_95;
      WL_CONT = term_tsk(FID_RECORD_RUN_K301, _t_15);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = _result_123;
      e.mem[_t_16 + 1] = _h_82;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = _result_123;
    r1 = _h_82;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K301)
  {
    WL_POPN(27);
    u32 _result_124 = STK(0);
    Term _result_125 = STK(1);
    Term _result_126 = STK(2);
    u32 _result_127 = STK(3);
    u32 _result_128 = STK(4);
    Term _result_129 = STK(5);
    Term _result_130 = STK(6);
    u32 _result_131 = STK(7);
    u32 _result_132 = STK(8);
    u32 _result_133 = STK(9);
    Term _result_134 = STK(10);
    Term _result_135 = STK(11);
    u32 _result_136 = STK(12);
    Term _lines_7 = STK(13);
    u32 _h_97 = STK(14);
    u32 _h_98 = STK(15);
    u32 _h_99 = STK(16);
    Term _h_100 = STK(17);
    u32 _h_101 = STK(18);
    Term _h_102 = STK(19);
    u32 _h_103 = STK(20);
    Term _h_104 = STK(21);
    Term _h_105 = STK(22);
    Term _h_106 = STK(23);
    u32 _h_107 = STK(24);
    u32 _h_108 = STK(25);
    Term _h_109 = STK(26);
    Term _h_96 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _result_124;
      STK(1) = _result_125;
      STK(2) = _result_126;
      STK(3) = _result_127;
      STK(4) = _result_128;
      STK(5) = _result_129;
      STK(6) = _result_130;
      STK(7) = _result_131;
      STK(8) = _result_132;
      STK(9) = _result_133;
      STK(10) = _result_134;
      STK(11) = _result_135;
      STK(12) = _result_136;
      STK(13) = _lines_7;
      STK(14) = _h_97;
      STK(15) = _h_98;
      STK(16) = _h_99;
      STK(17) = _h_100;
      STK(18) = _h_101;
      STK(19) = _h_102;
      STK(20) = _h_103;
      STK(21) = _h_104;
      STK(22) = _h_105;
      STK(23) = _h_106;
      STK(24) = _h_107;
      STK(25) = _h_108;
      STK(26) = _h_109;
      STK(27) = FID_RECORD_RUN_K302;
      WL_PUSHN(28);
    } else {
      u64 _t_17 = task_node(e, FID_RECORD_RUN_K302, WL_CONT, WL_IDX, 1);
      e.mem[_t_17 + 0] = _result_124;
      e.mem[_t_17 + 1] = _result_125;
      e.mem[_t_17 + 2] = _result_126;
      e.mem[_t_17 + 3] = _result_127;
      e.mem[_t_17 + 4] = _result_128;
      e.mem[_t_17 + 5] = _result_129;
      e.mem[_t_17 + 6] = _result_130;
      e.mem[_t_17 + 7] = _result_131;
      e.mem[_t_17 + 8] = _result_132;
      e.mem[_t_17 + 9] = _result_133;
      e.mem[_t_17 + 10] = _result_134;
      e.mem[_t_17 + 11] = _result_135;
      e.mem[_t_17 + 12] = _result_136;
      e.mem[_t_17 + 13] = _lines_7;
      e.mem[_t_17 + 14] = _h_97;
      e.mem[_t_17 + 15] = _h_98;
      e.mem[_t_17 + 16] = _h_99;
      e.mem[_t_17 + 17] = _h_100;
      e.mem[_t_17 + 18] = _h_101;
      e.mem[_t_17 + 19] = _h_102;
      e.mem[_t_17 + 20] = _h_103;
      e.mem[_t_17 + 21] = _h_104;
      e.mem[_t_17 + 22] = _h_105;
      e.mem[_t_17 + 23] = _h_106;
      e.mem[_t_17 + 24] = _h_107;
      e.mem[_t_17 + 25] = _h_108;
      e.mem[_t_17 + 26] = _h_109;
      WL_CONT = term_tsk(FID_RECORD_RUN_K302, _t_17);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_18 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = term_ctr(CID_SCON, STAT_OFF + 122);
      e.mem[_t_18 + 1] = _h_96;
      return term_tsk(FID_STRING_APPEND, _t_18);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 122);
    r1 = _h_96;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K302)
  {
    WL_POPN(27);
    u32 _result_137 = STK(0);
    Term _result_138 = STK(1);
    Term _result_139 = STK(2);
    u32 _result_140 = STK(3);
    u32 _result_141 = STK(4);
    Term _result_142 = STK(5);
    Term _result_143 = STK(6);
    u32 _result_144 = STK(7);
    u32 _result_145 = STK(8);
    u32 _result_146 = STK(9);
    Term _result_147 = STK(10);
    Term _result_148 = STK(11);
    u32 _result_149 = STK(12);
    Term _lines_8 = STK(13);
    u32 _h_111 = STK(14);
    u32 _h_112 = STK(15);
    u32 _h_113 = STK(16);
    Term _h_114 = STK(17);
    u32 _h_115 = STK(18);
    Term _h_116 = STK(19);
    u32 _h_117 = STK(20);
    Term _h_118 = STK(21);
    Term _h_119 = STK(22);
    Term _h_120 = STK(23);
    u32 _h_121 = STK(24);
    u32 _h_122 = STK(25);
    Term _h_123 = STK(26);
    Term _h_110 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _h_110);
    e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(27);
      STK(0) = _result_137;
      STK(1) = _result_138;
      STK(2) = _result_139;
      STK(3) = _result_140;
      STK(4) = _result_141;
      STK(5) = _result_142;
      STK(6) = _result_143;
      STK(7) = _result_144;
      STK(8) = _result_145;
      STK(9) = _result_146;
      STK(10) = _result_147;
      STK(11) = _result_148;
      STK(12) = _result_149;
      STK(13) = _h_111;
      STK(14) = _h_112;
      STK(15) = _h_113;
      STK(16) = _h_114;
      STK(17) = _h_115;
      STK(18) = _h_116;
      STK(19) = _h_117;
      STK(20) = _h_118;
      STK(21) = _h_119;
      STK(22) = _h_120;
      STK(23) = _h_121;
      STK(24) = _h_122;
      STK(25) = _h_123;
      STK(26) = FID_RECORD_RUN_K303;
      WL_PUSHN(27);
    } else {
      u64 _t_19 = task_node(e, FID_RECORD_RUN_K303, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _result_137;
      e.mem[_t_19 + 1] = _result_138;
      e.mem[_t_19 + 2] = _result_139;
      e.mem[_t_19 + 3] = _result_140;
      e.mem[_t_19 + 4] = _result_141;
      e.mem[_t_19 + 5] = _result_142;
      e.mem[_t_19 + 6] = _result_143;
      e.mem[_t_19 + 7] = _result_144;
      e.mem[_t_19 + 8] = _result_145;
      e.mem[_t_19 + 9] = _result_146;
      e.mem[_t_19 + 10] = _result_147;
      e.mem[_t_19 + 11] = _result_148;
      e.mem[_t_19 + 12] = _result_149;
      e.mem[_t_19 + 13] = _h_111;
      e.mem[_t_19 + 14] = _h_112;
      e.mem[_t_19 + 15] = _h_113;
      e.mem[_t_19 + 16] = _h_114;
      e.mem[_t_19 + 17] = _h_115;
      e.mem[_t_19 + 18] = _h_116;
      e.mem[_t_19 + 19] = _h_117;
      e.mem[_t_19 + 20] = _h_118;
      e.mem[_t_19 + 21] = _h_119;
      e.mem[_t_19 + 22] = _h_120;
      e.mem[_t_19 + 23] = _h_121;
      e.mem[_t_19 + 24] = _h_122;
      e.mem[_t_19 + 25] = _h_123;
      WL_CONT = term_tsk(FID_RECORD_RUN_K303, _t_19);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_20 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = _lines_8;
      e.mem[_t_20 + 1] = term_ctr(CID_CON, _nd_1);
      return term_tsk(FID_LIST_APPEND, _t_20);
    }
    r0 = _lines_8;
    r1 = term_ctr(CID_CON, _nd_1);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K303)
  {
    WL_POPN(26);
    u32 _result_150 = STK(0);
    Term _result_151 = STK(1);
    Term _result_152 = STK(2);
    u32 _result_153 = STK(3);
    u32 _result_154 = STK(4);
    Term _result_155 = STK(5);
    Term _result_156 = STK(6);
    u32 _result_157 = STK(7);
    u32 _result_158 = STK(8);
    u32 _result_159 = STK(9);
    Term _result_160 = STK(10);
    Term _result_161 = STK(11);
    u32 _result_162 = STK(12);
    u32 _h_125 = STK(13);
    u32 _h_126 = STK(14);
    u32 _h_127 = STK(15);
    Term _h_128 = STK(16);
    u32 _h_129 = STK(17);
    Term _h_130 = STK(18);
    u32 _h_131 = STK(19);
    Term _h_132 = STK(20);
    Term _h_133 = STK(21);
    Term _h_134 = STK(22);
    u32 _h_135 = STK(23);
    u32 _h_136 = STK(24);
    Term _h_137 = STK(25);
    Term _h_124 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_CAPTURE)) {
      u64 _t_21 = task_node(e, FID_RECORD_CAPTURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _result_150;
      e.mem[_t_21 + 1] = _result_151;
      e.mem[_t_21 + 2] = _result_152;
      e.mem[_t_21 + 3] = _result_153;
      e.mem[_t_21 + 4] = _result_154;
      e.mem[_t_21 + 5] = _result_155;
      e.mem[_t_21 + 6] = _result_156;
      e.mem[_t_21 + 7] = _result_157;
      e.mem[_t_21 + 8] = _result_158;
      e.mem[_t_21 + 9] = _result_159;
      e.mem[_t_21 + 10] = _result_160;
      e.mem[_t_21 + 11] = _result_161;
      e.mem[_t_21 + 12] = _result_162;
      e.mem[_t_21 + 13] = _h_125;
      e.mem[_t_21 + 14] = _h_126;
      e.mem[_t_21 + 15] = _h_127;
      e.mem[_t_21 + 16] = _h_128;
      e.mem[_t_21 + 17] = _h_129;
      e.mem[_t_21 + 18] = _h_130;
      e.mem[_t_21 + 19] = _h_131;
      e.mem[_t_21 + 20] = _h_132;
      e.mem[_t_21 + 21] = _h_133;
      e.mem[_t_21 + 22] = _h_134;
      e.mem[_t_21 + 23] = _h_135;
      e.mem[_t_21 + 24] = _h_136;
      e.mem[_t_21 + 25] = _h_137;
      e.mem[_t_21 + 26] = _h_124;
      return term_tsk(FID_RECORD_CAPTURE, _t_21);
    }
    r0 = _result_150;
    r1 = _result_151;
    r2 = _result_152;
    r3 = _result_153;
    r4 = _result_154;
    r5 = _result_155;
    r6 = _result_156;
    r7 = _result_157;
    r8 = _result_158;
    r9 = _result_159;
    r10 = _result_160;
    r11 = _result_161;
    r12 = _result_162;
    r13 = _h_125;
    r14 = _h_126;
    r15 = _h_127;
    r16 = _h_128;
    r17 = _h_129;
    r18 = _h_130;
    r19 = _h_131;
    r20 = _h_132;
    r21 = _h_133;
    r22 = _h_134;
    r23 = _h_135;
    r24 = _h_136;
    r25 = _h_137;
    r26 = _h_124;
    WL_JMP(FID_RECORD_CAPTURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K304)
  {
    WL_POPN(14);
    u32 _result_163 = STK(0);
    Term _result_164 = STK(1);
    Term _result_165 = STK(2);
    u32 _result_166 = STK(3);
    u32 _result_167 = STK(4);
    Term _result_168 = STK(5);
    Term _result_169 = STK(6);
    u32 _result_170 = STK(7);
    u32 _result_171 = STK(8);
    u32 _result_172 = STK(9);
    Term _result_173 = STK(10);
    Term _result_174 = STK(11);
    u32 _result_175 = STK(12);
    Term _lines_9 = STK(13);
    u32 _h_138 = r0;
    u32 _h_139 = r1;
    u32 _h_140 = r2;
    Term _h_141 = r3;
    u32 _h_142 = r4;
    Term _h_143 = r5;
    u32 _h_144 = r6;
    Term _h_145 = r7;
    Term _h_146 = r8;
    Term _h_147 = r9;
    u32 _h_148 = r10;
    u32 _h_149 = r11;
    Term _h_150 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _result_163;
      STK(1) = _result_164;
      STK(2) = _result_165;
      STK(3) = _result_166;
      STK(4) = _result_167;
      STK(5) = _result_168;
      STK(6) = _result_169;
      STK(7) = _result_170;
      STK(8) = _result_171;
      STK(9) = _result_172;
      STK(10) = _result_173;
      STK(11) = _result_174;
      STK(12) = _result_175;
      STK(13) = _h_138;
      STK(14) = _h_139;
      STK(15) = _h_140;
      STK(16) = _h_141;
      STK(17) = _h_142;
      STK(18) = _h_143;
      STK(19) = _h_144;
      STK(20) = _h_145;
      STK(21) = _h_146;
      STK(22) = _h_147;
      STK(23) = _h_148;
      STK(24) = _h_149;
      STK(25) = _h_150;
      STK(26) = FID_RECORD_RUN_K305;
      WL_PUSHN(27);
    } else {
      u64 _t_24 = task_node(e, FID_RECORD_RUN_K305, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _result_163;
      e.mem[_t_24 + 1] = _result_164;
      e.mem[_t_24 + 2] = _result_165;
      e.mem[_t_24 + 3] = _result_166;
      e.mem[_t_24 + 4] = _result_167;
      e.mem[_t_24 + 5] = _result_168;
      e.mem[_t_24 + 6] = _result_169;
      e.mem[_t_24 + 7] = _result_170;
      e.mem[_t_24 + 8] = _result_171;
      e.mem[_t_24 + 9] = _result_172;
      e.mem[_t_24 + 10] = _result_173;
      e.mem[_t_24 + 11] = _result_174;
      e.mem[_t_24 + 12] = _result_175;
      e.mem[_t_24 + 13] = _h_138;
      e.mem[_t_24 + 14] = _h_139;
      e.mem[_t_24 + 15] = _h_140;
      e.mem[_t_24 + 16] = _h_141;
      e.mem[_t_24 + 17] = _h_142;
      e.mem[_t_24 + 18] = _h_143;
      e.mem[_t_24 + 19] = _h_144;
      e.mem[_t_24 + 20] = _h_145;
      e.mem[_t_24 + 21] = _h_146;
      e.mem[_t_24 + 22] = _h_147;
      e.mem[_t_24 + 23] = _h_148;
      e.mem[_t_24 + 24] = _h_149;
      e.mem[_t_24 + 25] = _h_150;
      WL_CONT = term_tsk(FID_RECORD_RUN_K305, _t_24);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_25 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _lines_9;
      e.mem[_t_25 + 1] = term_ctr(CID_CON, STAT_OFF + 136);
      return term_tsk(FID_LIST_APPEND, _t_25);
    }
    r0 = _lines_9;
    r1 = term_ctr(CID_CON, STAT_OFF + 136);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RECORD_RUN_K305)
  {
    WL_POPN(26);
    u32 _result_176 = STK(0);
    Term _result_177 = STK(1);
    Term _result_178 = STK(2);
    u32 _result_179 = STK(3);
    u32 _result_180 = STK(4);
    Term _result_181 = STK(5);
    Term _result_182 = STK(6);
    u32 _result_183 = STK(7);
    u32 _result_184 = STK(8);
    u32 _result_185 = STK(9);
    Term _result_186 = STK(10);
    Term _result_187 = STK(11);
    u32 _result_188 = STK(12);
    u32 _h_152 = STK(13);
    u32 _h_153 = STK(14);
    u32 _h_154 = STK(15);
    Term _h_155 = STK(16);
    u32 _h_156 = STK(17);
    Term _h_157 = STK(18);
    u32 _h_158 = STK(19);
    Term _h_159 = STK(20);
    Term _h_160 = STK(21);
    Term _h_161 = STK(22);
    u32 _h_162 = STK(23);
    u32 _h_163 = STK(24);
    Term _h_164 = STK(25);
    Term _h_151 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_CAPTURE)) {
      u64 _t_26 = task_node(e, FID_RECORD_CAPTURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_26 + 0] = _result_176;
      e.mem[_t_26 + 1] = _result_177;
      e.mem[_t_26 + 2] = _result_178;
      e.mem[_t_26 + 3] = _result_179;
      e.mem[_t_26 + 4] = _result_180;
      e.mem[_t_26 + 5] = _result_181;
      e.mem[_t_26 + 6] = _result_182;
      e.mem[_t_26 + 7] = _result_183;
      e.mem[_t_26 + 8] = _result_184;
      e.mem[_t_26 + 9] = _result_185;
      e.mem[_t_26 + 10] = _result_186;
      e.mem[_t_26 + 11] = _result_187;
      e.mem[_t_26 + 12] = _result_188;
      e.mem[_t_26 + 13] = _h_152;
      e.mem[_t_26 + 14] = _h_153;
      e.mem[_t_26 + 15] = _h_154;
      e.mem[_t_26 + 16] = _h_155;
      e.mem[_t_26 + 17] = _h_156;
      e.mem[_t_26 + 18] = _h_157;
      e.mem[_t_26 + 19] = _h_158;
      e.mem[_t_26 + 20] = _h_159;
      e.mem[_t_26 + 21] = _h_160;
      e.mem[_t_26 + 22] = _h_161;
      e.mem[_t_26 + 23] = _h_162;
      e.mem[_t_26 + 24] = _h_163;
      e.mem[_t_26 + 25] = _h_164;
      e.mem[_t_26 + 26] = _h_151;
      return term_tsk(FID_RECORD_CAPTURE, _t_26);
    }
    r0 = _result_176;
    r1 = _result_177;
    r2 = _result_178;
    r3 = _result_179;
    r4 = _result_180;
    r5 = _result_181;
    r6 = _result_182;
    r7 = _result_183;
    r8 = _result_184;
    r9 = _result_185;
    r10 = _result_186;
    r11 = _result_187;
    r12 = _result_188;
    r13 = _h_152;
    r14 = _h_153;
    r15 = _h_154;
    r16 = _h_155;
    r17 = _h_156;
    r18 = _h_157;
    r19 = _h_158;
    r20 = _h_159;
    r21 = _h_160;
    r22 = _h_161;
    r23 = _h_162;
    r24 = _h_163;
    r25 = _h_164;
    r26 = _h_151;
    WL_JMP(FID_RECORD_CAPTURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_BUILD_0)
  {
    u32 _namespace_0 = r0;
    Term _name_0 = r1;
    Term _steps_0 = r2;
    Term _catalog_0 = r3;
    u32 _owners_0 = r4;
    u32 _owners_1 = r5;
    Term _owners_2 = r6;
    Term _owners_3 = r7;
    u32 _owners_4 = r8;
    u32 _owners_5 = r9;
    u32 _owners_6 = r10;
    Term _owners_7 = r11;
    Term _owners_8 = r12;
    u32 _owners_9 = r13;
    WL_OPEN
    _steps_0 = term_keep(e, _steps_0, 1);
    if (seq) {
      WL_ROOM(14);
      STK(0) = _namespace_0;
      STK(1) = _name_0;
      STK(2) = _steps_0;
      STK(3) = _owners_0;
      STK(4) = _owners_1;
      STK(5) = _owners_2;
      STK(6) = _owners_3;
      STK(7) = _owners_4;
      STK(8) = _owners_5;
      STK(9) = _owners_6;
      STK(10) = _owners_7;
      STK(11) = _owners_8;
      STK(12) = _owners_9;
      STK(13) = FID_______SRC_ECS_SCHEDULE_BUILD_0_K317;
      WL_PUSHN(14);
    } else {
      u64 _t_0 = task_node(e, FID_______SRC_ECS_SCHEDULE_BUILD_0_K317, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      e.mem[_t_0 + 1] = _name_0;
      e.mem[_t_0 + 2] = _steps_0;
      e.mem[_t_0 + 3] = _owners_0;
      e.mem[_t_0 + 4] = _owners_1;
      e.mem[_t_0 + 5] = _owners_2;
      e.mem[_t_0 + 6] = _owners_3;
      e.mem[_t_0 + 7] = _owners_4;
      e.mem[_t_0 + 8] = _owners_5;
      e.mem[_t_0 + 9] = _owners_6;
      e.mem[_t_0 + 10] = _owners_7;
      e.mem[_t_0 + 11] = _owners_8;
      e.mem[_t_0 + 12] = _owners_9;
      WL_CONT = term_tsk(FID_______SRC_ECS_SCHEDULE_BUILD_0_K317, _t_0);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_VALID)) {
      u64 _t_1 = task_node(e, FID_______SRC_ECS_SCHEDULE_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _steps_0;
      e.mem[_t_1 + 1] = _catalog_0;
      e.mem[_t_1 + 2] = term_pak(CID_NIL, 0);
      return term_tsk(FID_______SRC_ECS_SCHEDULE_VALID, _t_1);
    }
    r0 = _steps_0;
    r1 = _catalog_0;
    r2 = term_pak(CID_NIL, 0);
    WL_JMP(FID_______SRC_ECS_SCHEDULE_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_______SRC_ECS_SCHEDULE_BUILD_0_K317)
  {
    WL_POPN(13);
    u32 _namespace_1 = STK(0);
    Term _name_1 = STK(1);
    Term _steps_1 = STK(2);
    u32 _owners_10 = STK(3);
    u32 _owners_11 = STK(4);
    Term _owners_12 = STK(5);
    Term _owners_13 = STK(6);
    u32 _owners_14 = STK(7);
    u32 _owners_15 = STK(8);
    u32 _owners_16 = STK(9);
    Term _owners_17 = STK(10);
    Term _owners_18 = STK(11);
    u32 _owners_19 = STK(12);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_0[14];
    if (spin_58(e, _o_0, _h_0, _namespace_1, _name_1, blk_loc(e.mem, _name_1), _steps_1, blk_loc(e.mem, _steps_1), _owners_10, _owners_11, _owners_12, blk_loc(e.mem, _owners_12), _owners_13, blk_loc(e.mem, _owners_13), _owners_14, _owners_15, _owners_16, _owners_17, blk_loc(e.mem, _owners_17), _owners_18, blk_loc(e.mem, _owners_18), _owners_19) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_1)
  {
    Term _steps_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[14];
    if (spin_63(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull, 0ull) == 0) {
      return 0;
    }
    _v_14 = _o_0[0];
    _v_15 = _o_0[1];
    _v_16 = _o_0[2];
    _v_17 = _o_0[3];
    _v_18 = _o_0[4];
    _v_19 = _o_0[5];
    _v_20 = _o_0[6];
    _v_21 = _o_0[7];
    _v_22 = _o_0[8];
    _v_23 = _o_0[9];
    _v_24 = _o_0[10];
    _v_25 = _o_0[11];
    _v_26 = _o_0[12];
    _v_27 = _o_0[13];
    _v_0 = _v_14;
    _v_1 = _v_15;
    _v_2 = _v_16;
    _v_3 = _v_17;
    _v_4 = _v_18;
    _v_5 = _v_19;
    _v_6 = _v_20;
    _v_7 = _v_21;
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    if (_v_0 == 1) {
      term_sink(e, _steps_0);
      r0 = term_ctr(CID_SCON, STAT_OFF + 268);
      WL_RETN(1);
    } else {
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      u32 _v_30 = 0;
      u32 _v_31 = 0;
      Term _v_32 = 0;
      u32 _v_33 = 0;
      Term _v_34 = 0;
      u32 _v_35 = 0;
      Term _v_36 = 0;
      Term _v_37 = 0;
      Term _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      u32 _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      u32 _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      Term _v_50 = 0;
      u32 _v_51 = 0;
      Term _v_52 = 0;
      u32 _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      Term _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _o_1[18];
      Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 270);
      Term _a_1 = term_ctr(CID_CON, STAT_OFF + 302);
      if (spin_61(e, _o_1, _v_2, _v_3, _v_4, _v_5, blk_loc(e.mem, _v_5), _v_6, _v_7, _v_8, _v_9, blk_loc(e.mem, _v_9), _v_10, blk_loc(e.mem, _v_10), _v_11, blk_loc(e.mem, _v_11), _v_12, _v_13, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1)) == 0) {
        return 0;
      }
      _v_46 = _o_1[0];
      _v_47 = _o_1[1];
      _v_48 = _o_1[2];
      _v_49 = _o_1[3];
      _v_50 = _o_1[4];
      _v_51 = _o_1[5];
      _v_52 = _o_1[6];
      _v_53 = _o_1[7];
      _v_54 = _o_1[8];
      _v_55 = _o_1[9];
      _v_56 = _o_1[10];
      _v_57 = _o_1[11];
      _v_58 = _o_1[12];
      _v_59 = _o_1[13];
      _v_60 = _o_1[14];
      _v_61 = _o_1[15];
      _v_62 = _o_1[16];
      _v_63 = _o_1[17];
      _v_28 = _v_46;
      _v_29 = _v_47;
      _v_30 = _v_48;
      _v_31 = _v_49;
      _v_32 = _v_50;
      _v_33 = _v_51;
      _v_34 = _v_52;
      _v_35 = _v_53;
      _v_36 = _v_54;
      _v_37 = _v_55;
      _v_38 = _v_56;
      _v_39 = _v_57;
      _v_40 = _v_58;
      _v_41 = _v_59;
      _v_42 = _v_60;
      _v_43 = _v_61;
      _v_44 = _v_62;
      _v_45 = _v_63;
      if (_v_28 == 1) {
        term_sink(e, _v_32);
        term_sink(e, _v_36);
        term_sink(e, _v_37);
        term_sink(e, _v_38);
        term_sink(e, _steps_0);
        r0 = term_ctr(CID_SCON, STAT_OFF + 184);
        WL_RETN(1);
      } else {
        u32 _v_64 = 0;
        u32 _v_65 = 0;
        u32 _v_66 = 0;
        u32 _v_67 = 0;
        Term _v_68 = 0;
        u32 _v_69 = 0;
        Term _v_70 = 0;
        u32 _v_71 = 0;
        Term _v_72 = 0;
        Term _v_73 = 0;
        Term _v_74 = 0;
        u32 _v_75 = 0;
        u32 _v_76 = 0;
        u32 _v_77 = 0;
        u32 _v_78 = 0;
        Term _v_79 = 0;
        Term _v_80 = 0;
        u32 _v_81 = 0;
        u32 _v_82 = 0;
        u32 _v_83 = 0;
        u32 _v_84 = 0;
        u32 _v_85 = 0;
        Term _v_86 = 0;
        u32 _v_87 = 0;
        Term _v_88 = 0;
        u32 _v_89 = 0;
        Term _v_90 = 0;
        Term _v_91 = 0;
        Term _v_92 = 0;
        u32 _v_93 = 0;
        u32 _v_94 = 0;
        u32 _v_95 = 0;
        u32 _v_96 = 0;
        Term _v_97 = 0;
        Term _v_98 = 0;
        u32 _v_99 = 0;
        Term _o_2[18];
        Term _a_2 = term_ctr(CID_SCON, STAT_OFF + 196);
        Term _a_3 = term_ctr(CID_CON, STAT_OFF + 256);
        if (spin_61(e, _o_2, _v_29, _v_30, _v_31, _v_32, blk_loc(e.mem, _v_32), _v_33, _v_34, _v_35, _v_36, blk_loc(e.mem, _v_36), _v_37, blk_loc(e.mem, _v_37), _v_38, blk_loc(e.mem, _v_38), _v_39, _v_40, _a_2, blk_loc(e.mem, _a_2), _a_3, blk_loc(e.mem, _a_3)) == 0) {
          return 0;
        }
        _v_82 = _o_2[0];
        _v_83 = _o_2[1];
        _v_84 = _o_2[2];
        _v_85 = _o_2[3];
        _v_86 = _o_2[4];
        _v_87 = _o_2[5];
        _v_88 = _o_2[6];
        _v_89 = _o_2[7];
        _v_90 = _o_2[8];
        _v_91 = _o_2[9];
        _v_92 = _o_2[10];
        _v_93 = _o_2[11];
        _v_94 = _o_2[12];
        _v_95 = _o_2[13];
        _v_96 = _o_2[14];
        _v_97 = _o_2[15];
        _v_98 = _o_2[16];
        _v_99 = _o_2[17];
        _v_64 = _v_82;
        _v_65 = _v_83;
        _v_66 = _v_84;
        _v_67 = _v_85;
        _v_68 = _v_86;
        _v_69 = _v_87;
        _v_70 = _v_88;
        _v_71 = _v_89;
        _v_72 = _v_90;
        _v_73 = _v_91;
        _v_74 = _v_92;
        _v_75 = _v_93;
        _v_76 = _v_94;
        _v_77 = _v_95;
        _v_78 = _v_96;
        _v_79 = _v_97;
        _v_80 = _v_98;
        _v_81 = _v_99;
        if (_v_64 == 1) {
          term_sink(e, _v_68);
          term_sink(e, _v_72);
          term_sink(e, _v_73);
          term_sink(e, _v_74);
          term_sink(e, _v_43);
          term_sink(e, _v_44);
          term_sink(e, _steps_0);
          r0 = term_ctr(CID_SCON, STAT_OFF + 184);
          WL_RETN(1);
        } else {
          if (seq) {
            WL_ROOM(13);
            STK(0) = _v_65;
            STK(1) = _v_66;
            STK(2) = _v_67;
            STK(3) = _v_68;
            STK(4) = _v_69;
            STK(5) = _v_70;
            STK(6) = _v_71;
            STK(7) = _v_72;
            STK(8) = _v_73;
            STK(9) = _v_74;
            STK(10) = _v_75;
            STK(11) = _v_76;
            STK(12) = FID_SCENARIO_1_K367;
            WL_PUSHN(13);
          } else {
            u64 _t_0 = task_node(e, FID_SCENARIO_1_K367, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_65;
            e.mem[_t_0 + 1] = _v_66;
            e.mem[_t_0 + 2] = _v_67;
            e.mem[_t_0 + 3] = _v_68;
            e.mem[_t_0 + 4] = _v_69;
            e.mem[_t_0 + 5] = _v_70;
            e.mem[_t_0 + 6] = _v_71;
            e.mem[_t_0 + 7] = _v_72;
            e.mem[_t_0 + 8] = _v_73;
            e.mem[_t_0 + 9] = _v_74;
            e.mem[_t_0 + 10] = _v_75;
            e.mem[_t_0 + 11] = _v_76;
            WL_CONT = term_tsk(FID_SCENARIO_1_K367, _t_0);
            WL_IDX = 12;
          }
          if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_BUILD_0)) {
            u64 _t_1 = task_node(e, FID_______SRC_ECS_SCHEDULE_BUILD_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_1 + 0] = 1ull;
            e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 192);
            e.mem[_t_1 + 2] = _steps_0;
            e.mem[_t_1 + 3] = term_ctr(CID_CON, STAT_OFF + 194);
            e.mem[_t_1 + 4] = _v_41;
            e.mem[_t_1 + 5] = _v_42;
            e.mem[_t_1 + 6] = _v_43;
            e.mem[_t_1 + 7] = _v_44;
            e.mem[_t_1 + 8] = _v_45;
            e.mem[_t_1 + 9] = _v_77;
            e.mem[_t_1 + 10] = _v_78;
            e.mem[_t_1 + 11] = _v_79;
            e.mem[_t_1 + 12] = _v_80;
            e.mem[_t_1 + 13] = _v_81;
            return term_tsk(FID_______SRC_ECS_SCHEDULE_BUILD_0, _t_1);
          }
          r0 = 1ull;
          r1 = term_ctr(CID_SCON, STAT_OFF + 192);
          r2 = _steps_0;
          r3 = term_ctr(CID_CON, STAT_OFF + 194);
          r4 = _v_41;
          r5 = _v_42;
          r6 = _v_43;
          r7 = _v_44;
          r8 = _v_45;
          r9 = _v_77;
          r10 = _v_78;
          r11 = _v_79;
          r12 = _v_80;
          r13 = _v_81;
          WL_JMP(FID_______SRC_ECS_SCHEDULE_BUILD_0);
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_1_K367)
  {
    WL_POPN(12);
    u32 _v_100 = STK(0);
    u32 _v_101 = STK(1);
    u32 _v_102 = STK(2);
    Term _v_103 = STK(3);
    u32 _v_104 = STK(4);
    Term _v_105 = STK(5);
    u32 _v_106 = STK(6);
    Term _v_107 = STK(7);
    Term _v_108 = STK(8);
    Term _v_109 = STK(9);
    u32 _v_110 = STK(10);
    u32 _v_111 = STK(11);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    WL_OPEN
    if (_h_0 == 1) {
      term_sink(e, _h_3);
      term_sink(e, _h_4);
      term_sink(e, _h_8);
      term_sink(e, _h_9);
      term_sink(e, _v_103);
      term_sink(e, _v_107);
      term_sink(e, _v_108);
      term_sink(e, _v_109);
      r0 = term_ctr(CID_SCON, STAT_OFF + 150);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_SCENARIO_1_K368;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID_SCENARIO_1_K368, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_SCENARIO_1_K368, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_RUN_1)) {
        u64 _t_3 = task_node(e, FID_______SRC_ECS_SCHEDULE_RUN_1, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_1;
        e.mem[_t_3 + 1] = _h_2;
        e.mem[_t_3 + 2] = _h_3;
        e.mem[_t_3 + 3] = _h_4;
        e.mem[_t_3 + 4] = _h_5;
        e.mem[_t_3 + 5] = _h_6;
        e.mem[_t_3 + 6] = _h_7;
        e.mem[_t_3 + 7] = _h_8;
        e.mem[_t_3 + 8] = _h_9;
        e.mem[_t_3 + 9] = _h_10;
        e.mem[_t_3 + 10] = _h_11;
        e.mem[_t_3 + 11] = _h_12;
        e.mem[_t_3 + 12] = _h_13;
        e.mem[_t_3 + 13] = _v_100;
        e.mem[_t_3 + 14] = _v_101;
        e.mem[_t_3 + 15] = _v_102;
        e.mem[_t_3 + 16] = _v_103;
        e.mem[_t_3 + 17] = _v_104;
        e.mem[_t_3 + 18] = _v_105;
        e.mem[_t_3 + 19] = _v_106;
        e.mem[_t_3 + 20] = _v_107;
        e.mem[_t_3 + 21] = _v_108;
        e.mem[_t_3 + 22] = _v_109;
        e.mem[_t_3 + 23] = _v_110;
        e.mem[_t_3 + 24] = _v_111;
        return term_tsk(FID_______SRC_ECS_SCHEDULE_RUN_1, _t_3);
      }
      r0 = _h_1;
      r1 = _h_2;
      r2 = _h_3;
      r3 = _h_4;
      r4 = _h_5;
      r5 = _h_6;
      r6 = _h_7;
      r7 = _h_8;
      r8 = _h_9;
      r9 = _h_10;
      r10 = _h_11;
      r11 = _h_12;
      r12 = _h_13;
      r13 = _v_100;
      r14 = _v_101;
      r15 = _v_102;
      r16 = _v_103;
      r17 = _v_104;
      r18 = _v_105;
      r19 = _v_106;
      r20 = _v_107;
      r21 = _v_108;
      r22 = _v_109;
      r23 = _v_110;
      r24 = _v_111;
      WL_JMP(FID_______SRC_ECS_SCHEDULE_RUN_1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_1_K368)
  {
    u32 _h_14 = r0;
    u32 _h_15 = r1;
    Term _h_16 = r2;
    Term _h_17 = r3;
    u32 _h_18 = r4;
    u32 _h_19 = r5;
    Term _h_20 = r6;
    Term _h_21 = r7;
    u32 _h_22 = r8;
    u32 _h_23 = r9;
    u32 _h_24 = r10;
    Term _h_25 = r11;
    Term _h_26 = r12;
    u32 _h_27 = r13;
    u32 _h_28 = r14;
    u32 _h_29 = r15;
    u32 _h_30 = r16;
    Term _h_31 = r17;
    u32 _h_32 = r18;
    Term _h_33 = r19;
    u32 _h_34 = r20;
    Term _h_35 = r21;
    Term _h_36 = r22;
    Term _h_37 = r23;
    u32 _h_38 = r24;
    u32 _h_39 = r25;
    Term _h_40 = r26;
    Term _h_41 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCENARIO_1_K369;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_SCENARIO_1_K369, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCENARIO_1_K369, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_RUN)) {
      u64 _t_5 = task_node(e, FID_RECORD_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_14;
      e.mem[_t_5 + 1] = _h_15;
      e.mem[_t_5 + 2] = _h_16;
      e.mem[_t_5 + 3] = _h_17;
      e.mem[_t_5 + 4] = _h_18;
      e.mem[_t_5 + 5] = _h_19;
      e.mem[_t_5 + 6] = _h_20;
      e.mem[_t_5 + 7] = _h_21;
      e.mem[_t_5 + 8] = _h_22;
      e.mem[_t_5 + 9] = _h_23;
      e.mem[_t_5 + 10] = _h_24;
      e.mem[_t_5 + 11] = _h_25;
      e.mem[_t_5 + 12] = _h_26;
      e.mem[_t_5 + 13] = _h_27;
      e.mem[_t_5 + 14] = _h_28;
      e.mem[_t_5 + 15] = _h_29;
      e.mem[_t_5 + 16] = _h_30;
      e.mem[_t_5 + 17] = _h_31;
      e.mem[_t_5 + 18] = _h_32;
      e.mem[_t_5 + 19] = _h_33;
      e.mem[_t_5 + 20] = _h_34;
      e.mem[_t_5 + 21] = _h_35;
      e.mem[_t_5 + 22] = _h_36;
      e.mem[_t_5 + 23] = _h_37;
      e.mem[_t_5 + 24] = _h_38;
      e.mem[_t_5 + 25] = _h_39;
      e.mem[_t_5 + 26] = _h_40;
      e.mem[_t_5 + 27] = _h_41;
      e.mem[_t_5 + 28] = term_pak(CID_NIL, 0);
      return term_tsk(FID_RECORD_RUN, _t_5);
    }
    r0 = _h_14;
    r1 = _h_15;
    r2 = _h_16;
    r3 = _h_17;
    r4 = _h_18;
    r5 = _h_19;
    r6 = _h_20;
    r7 = _h_21;
    r8 = _h_22;
    r9 = _h_23;
    r10 = _h_24;
    r11 = _h_25;
    r12 = _h_26;
    r13 = _h_27;
    r14 = _h_28;
    r15 = _h_29;
    r16 = _h_30;
    r17 = _h_31;
    r18 = _h_32;
    r19 = _h_33;
    r20 = _h_34;
    r21 = _h_35;
    r22 = _h_36;
    r23 = _h_37;
    r24 = _h_38;
    r25 = _h_39;
    r26 = _h_40;
    r27 = _h_41;
    r28 = term_pak(CID_NIL, 0);
    WL_JMP(FID_RECORD_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_1_K369)
  {
    u32 _h_42 = r0;
    Term _h_43 = r1;
    Term _h_44 = r2;
    u32 _h_45 = r3;
    u32 _h_46 = r4;
    Term _h_47 = r5;
    Term _h_48 = r6;
    u32 _h_49 = r7;
    u32 _h_50 = r8;
    u32 _h_51 = r9;
    Term _h_52 = r10;
    Term _h_53 = r11;
    u32 _h_54 = r12;
    u32 _h_55 = r13;
    u32 _h_56 = r14;
    u32 _h_57 = r15;
    Term _h_58 = r16;
    u32 _h_59 = r17;
    Term _h_60 = r18;
    u32 _h_61 = r19;
    Term _h_62 = r20;
    Term _h_63 = r21;
    Term _h_64 = r22;
    u32 _h_65 = r23;
    u32 _h_66 = r24;
    Term _h_67 = r25;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_67;
      STK(1) = FID_SCENARIO_1_K370;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_SCENARIO_1_K370, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_67;
      WL_CONT = term_tsk(FID_SCENARIO_1_K370, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_RUN_1)) {
      u64 _t_7 = task_node(e, FID_______SRC_ECS_SCHEDULE_RUN_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_42;
      e.mem[_t_7 + 1] = _h_43;
      e.mem[_t_7 + 2] = _h_44;
      e.mem[_t_7 + 3] = _h_45;
      e.mem[_t_7 + 4] = _h_46;
      e.mem[_t_7 + 5] = _h_47;
      e.mem[_t_7 + 6] = _h_48;
      e.mem[_t_7 + 7] = _h_49;
      e.mem[_t_7 + 8] = _h_50;
      e.mem[_t_7 + 9] = _h_51;
      e.mem[_t_7 + 10] = _h_52;
      e.mem[_t_7 + 11] = _h_53;
      e.mem[_t_7 + 12] = _h_54;
      e.mem[_t_7 + 13] = _h_55;
      e.mem[_t_7 + 14] = _h_56;
      e.mem[_t_7 + 15] = _h_57;
      e.mem[_t_7 + 16] = _h_58;
      e.mem[_t_7 + 17] = _h_59;
      e.mem[_t_7 + 18] = _h_60;
      e.mem[_t_7 + 19] = _h_61;
      e.mem[_t_7 + 20] = _h_62;
      e.mem[_t_7 + 21] = _h_63;
      e.mem[_t_7 + 22] = _h_64;
      e.mem[_t_7 + 23] = _h_65;
      e.mem[_t_7 + 24] = _h_66;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_RUN_1, _t_7);
    }
    r0 = _h_42;
    r1 = _h_43;
    r2 = _h_44;
    r3 = _h_45;
    r4 = _h_46;
    r5 = _h_47;
    r6 = _h_48;
    r7 = _h_49;
    r8 = _h_50;
    r9 = _h_51;
    r10 = _h_52;
    r11 = _h_53;
    r12 = _h_54;
    r13 = _h_55;
    r14 = _h_56;
    r15 = _h_57;
    r16 = _h_58;
    r17 = _h_59;
    r18 = _h_60;
    r19 = _h_61;
    r20 = _h_62;
    r21 = _h_63;
    r22 = _h_64;
    r23 = _h_65;
    r24 = _h_66;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_RUN_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_1_K370)
  {
    WL_POPN(1);
    Term _h_96 = STK(0);
    u32 _h_68 = r0;
    u32 _h_69 = r1;
    Term _h_70 = r2;
    Term _h_71 = r3;
    u32 _h_72 = r4;
    u32 _h_73 = r5;
    Term _h_74 = r6;
    Term _h_75 = r7;
    u32 _h_76 = r8;
    u32 _h_77 = r9;
    u32 _h_78 = r10;
    Term _h_79 = r11;
    Term _h_80 = r12;
    u32 _h_81 = r13;
    u32 _h_82 = r14;
    u32 _h_83 = r15;
    u32 _h_84 = r16;
    Term _h_85 = r17;
    u32 _h_86 = r18;
    Term _h_87 = r19;
    u32 _h_88 = r20;
    Term _h_89 = r21;
    Term _h_90 = r22;
    Term _h_91 = r23;
    u32 _h_92 = r24;
    u32 _h_93 = r25;
    Term _h_94 = r26;
    Term _h_95 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCENARIO_1_K371;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_SCENARIO_1_K371, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCENARIO_1_K371, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_RUN)) {
      u64 _t_9 = task_node(e, FID_RECORD_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_68;
      e.mem[_t_9 + 1] = _h_69;
      e.mem[_t_9 + 2] = _h_70;
      e.mem[_t_9 + 3] = _h_71;
      e.mem[_t_9 + 4] = _h_72;
      e.mem[_t_9 + 5] = _h_73;
      e.mem[_t_9 + 6] = _h_74;
      e.mem[_t_9 + 7] = _h_75;
      e.mem[_t_9 + 8] = _h_76;
      e.mem[_t_9 + 9] = _h_77;
      e.mem[_t_9 + 10] = _h_78;
      e.mem[_t_9 + 11] = _h_79;
      e.mem[_t_9 + 12] = _h_80;
      e.mem[_t_9 + 13] = _h_81;
      e.mem[_t_9 + 14] = _h_82;
      e.mem[_t_9 + 15] = _h_83;
      e.mem[_t_9 + 16] = _h_84;
      e.mem[_t_9 + 17] = _h_85;
      e.mem[_t_9 + 18] = _h_86;
      e.mem[_t_9 + 19] = _h_87;
      e.mem[_t_9 + 20] = _h_88;
      e.mem[_t_9 + 21] = _h_89;
      e.mem[_t_9 + 22] = _h_90;
      e.mem[_t_9 + 23] = _h_91;
      e.mem[_t_9 + 24] = _h_92;
      e.mem[_t_9 + 25] = _h_93;
      e.mem[_t_9 + 26] = _h_94;
      e.mem[_t_9 + 27] = _h_95;
      e.mem[_t_9 + 28] = _h_96;
      return term_tsk(FID_RECORD_RUN, _t_9);
    }
    r0 = _h_68;
    r1 = _h_69;
    r2 = _h_70;
    r3 = _h_71;
    r4 = _h_72;
    r5 = _h_73;
    r6 = _h_74;
    r7 = _h_75;
    r8 = _h_76;
    r9 = _h_77;
    r10 = _h_78;
    r11 = _h_79;
    r12 = _h_80;
    r13 = _h_81;
    r14 = _h_82;
    r15 = _h_83;
    r16 = _h_84;
    r17 = _h_85;
    r18 = _h_86;
    r19 = _h_87;
    r20 = _h_88;
    r21 = _h_89;
    r22 = _h_90;
    r23 = _h_91;
    r24 = _h_92;
    r25 = _h_93;
    r26 = _h_94;
    r27 = _h_95;
    r28 = _h_96;
    WL_JMP(FID_RECORD_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_1_K371)
  {
    u32 _h_97 = r0;
    Term _h_98 = r1;
    Term _h_99 = r2;
    u32 _h_100 = r3;
    u32 _h_101 = r4;
    Term _h_102 = r5;
    Term _h_103 = r6;
    u32 _h_104 = r7;
    u32 _h_105 = r8;
    u32 _h_106 = r9;
    Term _h_107 = r10;
    Term _h_108 = r11;
    u32 _h_109 = r12;
    u32 _h_110 = r13;
    u32 _h_111 = r14;
    u32 _h_112 = r15;
    Term _h_113 = r16;
    u32 _h_114 = r17;
    Term _h_115 = r18;
    u32 _h_116 = r19;
    Term _h_117 = r20;
    Term _h_118 = r21;
    Term _h_119 = r22;
    u32 _h_120 = r23;
    u32 _h_121 = r24;
    Term _h_122 = r25;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_FINAL)) {
      u64 _t_10 = task_node(e, FID_FINAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_97;
      e.mem[_t_10 + 1] = _h_98;
      e.mem[_t_10 + 2] = _h_99;
      e.mem[_t_10 + 3] = _h_100;
      e.mem[_t_10 + 4] = _h_101;
      e.mem[_t_10 + 5] = _h_102;
      e.mem[_t_10 + 6] = _h_103;
      e.mem[_t_10 + 7] = _h_104;
      e.mem[_t_10 + 8] = _h_105;
      e.mem[_t_10 + 9] = _h_106;
      e.mem[_t_10 + 10] = _h_107;
      e.mem[_t_10 + 11] = _h_108;
      e.mem[_t_10 + 12] = _h_109;
      e.mem[_t_10 + 13] = _h_110;
      e.mem[_t_10 + 14] = _h_111;
      e.mem[_t_10 + 15] = _h_112;
      e.mem[_t_10 + 16] = _h_113;
      e.mem[_t_10 + 17] = _h_114;
      e.mem[_t_10 + 18] = _h_115;
      e.mem[_t_10 + 19] = _h_116;
      e.mem[_t_10 + 20] = _h_117;
      e.mem[_t_10 + 21] = _h_118;
      e.mem[_t_10 + 22] = _h_119;
      e.mem[_t_10 + 23] = _h_120;
      e.mem[_t_10 + 24] = _h_121;
      e.mem[_t_10 + 25] = _h_122;
      return term_tsk(FID_FINAL, _t_10);
    }
    r0 = _h_97;
    r1 = _h_98;
    r2 = _h_99;
    r3 = _h_100;
    r4 = _h_101;
    r5 = _h_102;
    r6 = _h_103;
    r7 = _h_104;
    r8 = _h_105;
    r9 = _h_106;
    r10 = _h_107;
    r11 = _h_108;
    r12 = _h_109;
    r13 = _h_110;
    r14 = _h_111;
    r15 = _h_112;
    r16 = _h_113;
    r17 = _h_114;
    r18 = _h_115;
    r19 = _h_116;
    r20 = _h_117;
    r21 = _h_118;
    r22 = _h_119;
    r23 = _h_120;
    r24 = _h_121;
    r25 = _h_122;
    WL_JMP(FID_FINAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0)
  {
    Term _steps_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[14];
    if (spin_63(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull, 0ull) == 0) {
      return 0;
    }
    _v_14 = _o_0[0];
    _v_15 = _o_0[1];
    _v_16 = _o_0[2];
    _v_17 = _o_0[3];
    _v_18 = _o_0[4];
    _v_19 = _o_0[5];
    _v_20 = _o_0[6];
    _v_21 = _o_0[7];
    _v_22 = _o_0[8];
    _v_23 = _o_0[9];
    _v_24 = _o_0[10];
    _v_25 = _o_0[11];
    _v_26 = _o_0[12];
    _v_27 = _o_0[13];
    _v_0 = _v_14;
    _v_1 = _v_15;
    _v_2 = _v_16;
    _v_3 = _v_17;
    _v_4 = _v_18;
    _v_5 = _v_19;
    _v_6 = _v_20;
    _v_7 = _v_21;
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    if (_v_0 == 1) {
      term_sink(e, _steps_0);
      r0 = term_ctr(CID_SCON, STAT_OFF + 268);
      WL_RETN(1);
    } else {
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      u32 _v_30 = 0;
      u32 _v_31 = 0;
      Term _v_32 = 0;
      u32 _v_33 = 0;
      Term _v_34 = 0;
      u32 _v_35 = 0;
      Term _v_36 = 0;
      Term _v_37 = 0;
      Term _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      u32 _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      u32 _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      Term _v_50 = 0;
      u32 _v_51 = 0;
      Term _v_52 = 0;
      u32 _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      Term _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _o_1[18];
      Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 270);
      Term _a_1 = term_ctr(CID_CON, STAT_OFF + 302);
      if (spin_61(e, _o_1, _v_2, _v_3, _v_4, _v_5, blk_loc(e.mem, _v_5), _v_6, _v_7, _v_8, _v_9, blk_loc(e.mem, _v_9), _v_10, blk_loc(e.mem, _v_10), _v_11, blk_loc(e.mem, _v_11), _v_12, _v_13, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1)) == 0) {
        return 0;
      }
      _v_46 = _o_1[0];
      _v_47 = _o_1[1];
      _v_48 = _o_1[2];
      _v_49 = _o_1[3];
      _v_50 = _o_1[4];
      _v_51 = _o_1[5];
      _v_52 = _o_1[6];
      _v_53 = _o_1[7];
      _v_54 = _o_1[8];
      _v_55 = _o_1[9];
      _v_56 = _o_1[10];
      _v_57 = _o_1[11];
      _v_58 = _o_1[12];
      _v_59 = _o_1[13];
      _v_60 = _o_1[14];
      _v_61 = _o_1[15];
      _v_62 = _o_1[16];
      _v_63 = _o_1[17];
      _v_28 = _v_46;
      _v_29 = _v_47;
      _v_30 = _v_48;
      _v_31 = _v_49;
      _v_32 = _v_50;
      _v_33 = _v_51;
      _v_34 = _v_52;
      _v_35 = _v_53;
      _v_36 = _v_54;
      _v_37 = _v_55;
      _v_38 = _v_56;
      _v_39 = _v_57;
      _v_40 = _v_58;
      _v_41 = _v_59;
      _v_42 = _v_60;
      _v_43 = _v_61;
      _v_44 = _v_62;
      _v_45 = _v_63;
      if (_v_28 == 1) {
        term_sink(e, _v_32);
        term_sink(e, _v_36);
        term_sink(e, _v_37);
        term_sink(e, _v_38);
        term_sink(e, _steps_0);
        r0 = term_ctr(CID_SCON, STAT_OFF + 184);
        WL_RETN(1);
      } else {
        u32 _v_64 = 0;
        u32 _v_65 = 0;
        u32 _v_66 = 0;
        u32 _v_67 = 0;
        Term _v_68 = 0;
        u32 _v_69 = 0;
        Term _v_70 = 0;
        u32 _v_71 = 0;
        Term _v_72 = 0;
        Term _v_73 = 0;
        Term _v_74 = 0;
        u32 _v_75 = 0;
        u32 _v_76 = 0;
        u32 _v_77 = 0;
        u32 _v_78 = 0;
        Term _v_79 = 0;
        Term _v_80 = 0;
        u32 _v_81 = 0;
        u32 _v_82 = 0;
        u32 _v_83 = 0;
        u32 _v_84 = 0;
        u32 _v_85 = 0;
        Term _v_86 = 0;
        u32 _v_87 = 0;
        Term _v_88 = 0;
        u32 _v_89 = 0;
        Term _v_90 = 0;
        Term _v_91 = 0;
        Term _v_92 = 0;
        u32 _v_93 = 0;
        u32 _v_94 = 0;
        u32 _v_95 = 0;
        u32 _v_96 = 0;
        Term _v_97 = 0;
        Term _v_98 = 0;
        u32 _v_99 = 0;
        Term _o_2[18];
        Term _a_2 = term_ctr(CID_SCON, STAT_OFF + 196);
        Term _a_3 = term_ctr(CID_CON, STAT_OFF + 256);
        if (spin_61(e, _o_2, _v_29, _v_30, _v_31, _v_32, blk_loc(e.mem, _v_32), _v_33, _v_34, _v_35, _v_36, blk_loc(e.mem, _v_36), _v_37, blk_loc(e.mem, _v_37), _v_38, blk_loc(e.mem, _v_38), _v_39, _v_40, _a_2, blk_loc(e.mem, _a_2), _a_3, blk_loc(e.mem, _a_3)) == 0) {
          return 0;
        }
        _v_82 = _o_2[0];
        _v_83 = _o_2[1];
        _v_84 = _o_2[2];
        _v_85 = _o_2[3];
        _v_86 = _o_2[4];
        _v_87 = _o_2[5];
        _v_88 = _o_2[6];
        _v_89 = _o_2[7];
        _v_90 = _o_2[8];
        _v_91 = _o_2[9];
        _v_92 = _o_2[10];
        _v_93 = _o_2[11];
        _v_94 = _o_2[12];
        _v_95 = _o_2[13];
        _v_96 = _o_2[14];
        _v_97 = _o_2[15];
        _v_98 = _o_2[16];
        _v_99 = _o_2[17];
        _v_64 = _v_82;
        _v_65 = _v_83;
        _v_66 = _v_84;
        _v_67 = _v_85;
        _v_68 = _v_86;
        _v_69 = _v_87;
        _v_70 = _v_88;
        _v_71 = _v_89;
        _v_72 = _v_90;
        _v_73 = _v_91;
        _v_74 = _v_92;
        _v_75 = _v_93;
        _v_76 = _v_94;
        _v_77 = _v_95;
        _v_78 = _v_96;
        _v_79 = _v_97;
        _v_80 = _v_98;
        _v_81 = _v_99;
        if (_v_64 == 1) {
          term_sink(e, _v_68);
          term_sink(e, _v_72);
          term_sink(e, _v_73);
          term_sink(e, _v_74);
          term_sink(e, _v_43);
          term_sink(e, _v_44);
          term_sink(e, _steps_0);
          r0 = term_ctr(CID_SCON, STAT_OFF + 184);
          WL_RETN(1);
        } else {
          if (seq) {
            WL_ROOM(13);
            STK(0) = _v_65;
            STK(1) = _v_66;
            STK(2) = _v_67;
            STK(3) = _v_68;
            STK(4) = _v_69;
            STK(5) = _v_70;
            STK(6) = _v_71;
            STK(7) = _v_72;
            STK(8) = _v_73;
            STK(9) = _v_74;
            STK(10) = _v_75;
            STK(11) = _v_76;
            STK(12) = FID_SCENARIO_0_K373;
            WL_PUSHN(13);
          } else {
            u64 _t_0 = task_node(e, FID_SCENARIO_0_K373, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_65;
            e.mem[_t_0 + 1] = _v_66;
            e.mem[_t_0 + 2] = _v_67;
            e.mem[_t_0 + 3] = _v_68;
            e.mem[_t_0 + 4] = _v_69;
            e.mem[_t_0 + 5] = _v_70;
            e.mem[_t_0 + 6] = _v_71;
            e.mem[_t_0 + 7] = _v_72;
            e.mem[_t_0 + 8] = _v_73;
            e.mem[_t_0 + 9] = _v_74;
            e.mem[_t_0 + 10] = _v_75;
            e.mem[_t_0 + 11] = _v_76;
            WL_CONT = term_tsk(FID_SCENARIO_0_K373, _t_0);
            WL_IDX = 12;
          }
          if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_BUILD_0)) {
            u64 _t_1 = task_node(e, FID_______SRC_ECS_SCHEDULE_BUILD_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_1 + 0] = 1ull;
            e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 192);
            e.mem[_t_1 + 2] = _steps_0;
            e.mem[_t_1 + 3] = term_ctr(CID_CON, STAT_OFF + 194);
            e.mem[_t_1 + 4] = _v_41;
            e.mem[_t_1 + 5] = _v_42;
            e.mem[_t_1 + 6] = _v_43;
            e.mem[_t_1 + 7] = _v_44;
            e.mem[_t_1 + 8] = _v_45;
            e.mem[_t_1 + 9] = _v_77;
            e.mem[_t_1 + 10] = _v_78;
            e.mem[_t_1 + 11] = _v_79;
            e.mem[_t_1 + 12] = _v_80;
            e.mem[_t_1 + 13] = _v_81;
            return term_tsk(FID_______SRC_ECS_SCHEDULE_BUILD_0, _t_1);
          }
          r0 = 1ull;
          r1 = term_ctr(CID_SCON, STAT_OFF + 192);
          r2 = _steps_0;
          r3 = term_ctr(CID_CON, STAT_OFF + 194);
          r4 = _v_41;
          r5 = _v_42;
          r6 = _v_43;
          r7 = _v_44;
          r8 = _v_45;
          r9 = _v_77;
          r10 = _v_78;
          r11 = _v_79;
          r12 = _v_80;
          r13 = _v_81;
          WL_JMP(FID_______SRC_ECS_SCHEDULE_BUILD_0);
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K373)
  {
    WL_POPN(12);
    u32 _v_100 = STK(0);
    u32 _v_101 = STK(1);
    u32 _v_102 = STK(2);
    Term _v_103 = STK(3);
    u32 _v_104 = STK(4);
    Term _v_105 = STK(5);
    u32 _v_106 = STK(6);
    Term _v_107 = STK(7);
    Term _v_108 = STK(8);
    Term _v_109 = STK(9);
    u32 _v_110 = STK(10);
    u32 _v_111 = STK(11);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    WL_OPEN
    if (_h_0 == 1) {
      term_sink(e, _h_3);
      term_sink(e, _h_4);
      term_sink(e, _h_8);
      term_sink(e, _h_9);
      term_sink(e, _v_103);
      term_sink(e, _v_107);
      term_sink(e, _v_108);
      term_sink(e, _v_109);
      r0 = term_ctr(CID_SCON, STAT_OFF + 150);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_SCENARIO_0_K374;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID_SCENARIO_0_K374, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_SCENARIO_0_K374, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_RUN_0)) {
        u64 _t_3 = task_node(e, FID_______SRC_ECS_SCHEDULE_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_1;
        e.mem[_t_3 + 1] = _h_2;
        e.mem[_t_3 + 2] = _h_3;
        e.mem[_t_3 + 3] = _h_4;
        e.mem[_t_3 + 4] = _h_5;
        e.mem[_t_3 + 5] = _h_6;
        e.mem[_t_3 + 6] = _h_7;
        e.mem[_t_3 + 7] = _h_8;
        e.mem[_t_3 + 8] = _h_9;
        e.mem[_t_3 + 9] = _h_10;
        e.mem[_t_3 + 10] = _h_11;
        e.mem[_t_3 + 11] = _h_12;
        e.mem[_t_3 + 12] = _h_13;
        e.mem[_t_3 + 13] = _v_100;
        e.mem[_t_3 + 14] = _v_101;
        e.mem[_t_3 + 15] = _v_102;
        e.mem[_t_3 + 16] = _v_103;
        e.mem[_t_3 + 17] = _v_104;
        e.mem[_t_3 + 18] = _v_105;
        e.mem[_t_3 + 19] = _v_106;
        e.mem[_t_3 + 20] = _v_107;
        e.mem[_t_3 + 21] = _v_108;
        e.mem[_t_3 + 22] = _v_109;
        e.mem[_t_3 + 23] = _v_110;
        e.mem[_t_3 + 24] = _v_111;
        return term_tsk(FID_______SRC_ECS_SCHEDULE_RUN_0, _t_3);
      }
      r0 = _h_1;
      r1 = _h_2;
      r2 = _h_3;
      r3 = _h_4;
      r4 = _h_5;
      r5 = _h_6;
      r6 = _h_7;
      r7 = _h_8;
      r8 = _h_9;
      r9 = _h_10;
      r10 = _h_11;
      r11 = _h_12;
      r12 = _h_13;
      r13 = _v_100;
      r14 = _v_101;
      r15 = _v_102;
      r16 = _v_103;
      r17 = _v_104;
      r18 = _v_105;
      r19 = _v_106;
      r20 = _v_107;
      r21 = _v_108;
      r22 = _v_109;
      r23 = _v_110;
      r24 = _v_111;
      WL_JMP(FID_______SRC_ECS_SCHEDULE_RUN_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K374)
  {
    u32 _h_14 = r0;
    u32 _h_15 = r1;
    Term _h_16 = r2;
    Term _h_17 = r3;
    u32 _h_18 = r4;
    u32 _h_19 = r5;
    Term _h_20 = r6;
    Term _h_21 = r7;
    u32 _h_22 = r8;
    u32 _h_23 = r9;
    u32 _h_24 = r10;
    Term _h_25 = r11;
    Term _h_26 = r12;
    u32 _h_27 = r13;
    u32 _h_28 = r14;
    u32 _h_29 = r15;
    u32 _h_30 = r16;
    Term _h_31 = r17;
    u32 _h_32 = r18;
    Term _h_33 = r19;
    u32 _h_34 = r20;
    Term _h_35 = r21;
    Term _h_36 = r22;
    Term _h_37 = r23;
    u32 _h_38 = r24;
    u32 _h_39 = r25;
    Term _h_40 = r26;
    Term _h_41 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCENARIO_0_K375;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_SCENARIO_0_K375, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCENARIO_0_K375, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_RUN)) {
      u64 _t_5 = task_node(e, FID_RECORD_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_14;
      e.mem[_t_5 + 1] = _h_15;
      e.mem[_t_5 + 2] = _h_16;
      e.mem[_t_5 + 3] = _h_17;
      e.mem[_t_5 + 4] = _h_18;
      e.mem[_t_5 + 5] = _h_19;
      e.mem[_t_5 + 6] = _h_20;
      e.mem[_t_5 + 7] = _h_21;
      e.mem[_t_5 + 8] = _h_22;
      e.mem[_t_5 + 9] = _h_23;
      e.mem[_t_5 + 10] = _h_24;
      e.mem[_t_5 + 11] = _h_25;
      e.mem[_t_5 + 12] = _h_26;
      e.mem[_t_5 + 13] = _h_27;
      e.mem[_t_5 + 14] = _h_28;
      e.mem[_t_5 + 15] = _h_29;
      e.mem[_t_5 + 16] = _h_30;
      e.mem[_t_5 + 17] = _h_31;
      e.mem[_t_5 + 18] = _h_32;
      e.mem[_t_5 + 19] = _h_33;
      e.mem[_t_5 + 20] = _h_34;
      e.mem[_t_5 + 21] = _h_35;
      e.mem[_t_5 + 22] = _h_36;
      e.mem[_t_5 + 23] = _h_37;
      e.mem[_t_5 + 24] = _h_38;
      e.mem[_t_5 + 25] = _h_39;
      e.mem[_t_5 + 26] = _h_40;
      e.mem[_t_5 + 27] = _h_41;
      e.mem[_t_5 + 28] = term_pak(CID_NIL, 0);
      return term_tsk(FID_RECORD_RUN, _t_5);
    }
    r0 = _h_14;
    r1 = _h_15;
    r2 = _h_16;
    r3 = _h_17;
    r4 = _h_18;
    r5 = _h_19;
    r6 = _h_20;
    r7 = _h_21;
    r8 = _h_22;
    r9 = _h_23;
    r10 = _h_24;
    r11 = _h_25;
    r12 = _h_26;
    r13 = _h_27;
    r14 = _h_28;
    r15 = _h_29;
    r16 = _h_30;
    r17 = _h_31;
    r18 = _h_32;
    r19 = _h_33;
    r20 = _h_34;
    r21 = _h_35;
    r22 = _h_36;
    r23 = _h_37;
    r24 = _h_38;
    r25 = _h_39;
    r26 = _h_40;
    r27 = _h_41;
    r28 = term_pak(CID_NIL, 0);
    WL_JMP(FID_RECORD_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K375)
  {
    u32 _h_42 = r0;
    Term _h_43 = r1;
    Term _h_44 = r2;
    u32 _h_45 = r3;
    u32 _h_46 = r4;
    Term _h_47 = r5;
    Term _h_48 = r6;
    u32 _h_49 = r7;
    u32 _h_50 = r8;
    u32 _h_51 = r9;
    Term _h_52 = r10;
    Term _h_53 = r11;
    u32 _h_54 = r12;
    u32 _h_55 = r13;
    u32 _h_56 = r14;
    u32 _h_57 = r15;
    Term _h_58 = r16;
    u32 _h_59 = r17;
    Term _h_60 = r18;
    u32 _h_61 = r19;
    Term _h_62 = r20;
    Term _h_63 = r21;
    Term _h_64 = r22;
    u32 _h_65 = r23;
    u32 _h_66 = r24;
    Term _h_67 = r25;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_67;
      STK(1) = FID_SCENARIO_0_K376;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_SCENARIO_0_K376, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_67;
      WL_CONT = term_tsk(FID_SCENARIO_0_K376, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_______SRC_ECS_SCHEDULE_RUN_0)) {
      u64 _t_7 = task_node(e, FID_______SRC_ECS_SCHEDULE_RUN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_42;
      e.mem[_t_7 + 1] = _h_43;
      e.mem[_t_7 + 2] = _h_44;
      e.mem[_t_7 + 3] = _h_45;
      e.mem[_t_7 + 4] = _h_46;
      e.mem[_t_7 + 5] = _h_47;
      e.mem[_t_7 + 6] = _h_48;
      e.mem[_t_7 + 7] = _h_49;
      e.mem[_t_7 + 8] = _h_50;
      e.mem[_t_7 + 9] = _h_51;
      e.mem[_t_7 + 10] = _h_52;
      e.mem[_t_7 + 11] = _h_53;
      e.mem[_t_7 + 12] = _h_54;
      e.mem[_t_7 + 13] = _h_55;
      e.mem[_t_7 + 14] = _h_56;
      e.mem[_t_7 + 15] = _h_57;
      e.mem[_t_7 + 16] = _h_58;
      e.mem[_t_7 + 17] = _h_59;
      e.mem[_t_7 + 18] = _h_60;
      e.mem[_t_7 + 19] = _h_61;
      e.mem[_t_7 + 20] = _h_62;
      e.mem[_t_7 + 21] = _h_63;
      e.mem[_t_7 + 22] = _h_64;
      e.mem[_t_7 + 23] = _h_65;
      e.mem[_t_7 + 24] = _h_66;
      return term_tsk(FID_______SRC_ECS_SCHEDULE_RUN_0, _t_7);
    }
    r0 = _h_42;
    r1 = _h_43;
    r2 = _h_44;
    r3 = _h_45;
    r4 = _h_46;
    r5 = _h_47;
    r6 = _h_48;
    r7 = _h_49;
    r8 = _h_50;
    r9 = _h_51;
    r10 = _h_52;
    r11 = _h_53;
    r12 = _h_54;
    r13 = _h_55;
    r14 = _h_56;
    r15 = _h_57;
    r16 = _h_58;
    r17 = _h_59;
    r18 = _h_60;
    r19 = _h_61;
    r20 = _h_62;
    r21 = _h_63;
    r22 = _h_64;
    r23 = _h_65;
    r24 = _h_66;
    WL_JMP(FID_______SRC_ECS_SCHEDULE_RUN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K376)
  {
    WL_POPN(1);
    Term _h_96 = STK(0);
    u32 _h_68 = r0;
    u32 _h_69 = r1;
    Term _h_70 = r2;
    Term _h_71 = r3;
    u32 _h_72 = r4;
    u32 _h_73 = r5;
    Term _h_74 = r6;
    Term _h_75 = r7;
    u32 _h_76 = r8;
    u32 _h_77 = r9;
    u32 _h_78 = r10;
    Term _h_79 = r11;
    Term _h_80 = r12;
    u32 _h_81 = r13;
    u32 _h_82 = r14;
    u32 _h_83 = r15;
    u32 _h_84 = r16;
    Term _h_85 = r17;
    u32 _h_86 = r18;
    Term _h_87 = r19;
    u32 _h_88 = r20;
    Term _h_89 = r21;
    Term _h_90 = r22;
    Term _h_91 = r23;
    u32 _h_92 = r24;
    u32 _h_93 = r25;
    Term _h_94 = r26;
    Term _h_95 = r27;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCENARIO_0_K377;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_SCENARIO_0_K377, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCENARIO_0_K377, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RECORD_RUN)) {
      u64 _t_9 = task_node(e, FID_RECORD_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_68;
      e.mem[_t_9 + 1] = _h_69;
      e.mem[_t_9 + 2] = _h_70;
      e.mem[_t_9 + 3] = _h_71;
      e.mem[_t_9 + 4] = _h_72;
      e.mem[_t_9 + 5] = _h_73;
      e.mem[_t_9 + 6] = _h_74;
      e.mem[_t_9 + 7] = _h_75;
      e.mem[_t_9 + 8] = _h_76;
      e.mem[_t_9 + 9] = _h_77;
      e.mem[_t_9 + 10] = _h_78;
      e.mem[_t_9 + 11] = _h_79;
      e.mem[_t_9 + 12] = _h_80;
      e.mem[_t_9 + 13] = _h_81;
      e.mem[_t_9 + 14] = _h_82;
      e.mem[_t_9 + 15] = _h_83;
      e.mem[_t_9 + 16] = _h_84;
      e.mem[_t_9 + 17] = _h_85;
      e.mem[_t_9 + 18] = _h_86;
      e.mem[_t_9 + 19] = _h_87;
      e.mem[_t_9 + 20] = _h_88;
      e.mem[_t_9 + 21] = _h_89;
      e.mem[_t_9 + 22] = _h_90;
      e.mem[_t_9 + 23] = _h_91;
      e.mem[_t_9 + 24] = _h_92;
      e.mem[_t_9 + 25] = _h_93;
      e.mem[_t_9 + 26] = _h_94;
      e.mem[_t_9 + 27] = _h_95;
      e.mem[_t_9 + 28] = _h_96;
      return term_tsk(FID_RECORD_RUN, _t_9);
    }
    r0 = _h_68;
    r1 = _h_69;
    r2 = _h_70;
    r3 = _h_71;
    r4 = _h_72;
    r5 = _h_73;
    r6 = _h_74;
    r7 = _h_75;
    r8 = _h_76;
    r9 = _h_77;
    r10 = _h_78;
    r11 = _h_79;
    r12 = _h_80;
    r13 = _h_81;
    r14 = _h_82;
    r15 = _h_83;
    r16 = _h_84;
    r17 = _h_85;
    r18 = _h_86;
    r19 = _h_87;
    r20 = _h_88;
    r21 = _h_89;
    r22 = _h_90;
    r23 = _h_91;
    r24 = _h_92;
    r25 = _h_93;
    r26 = _h_94;
    r27 = _h_95;
    r28 = _h_96;
    WL_JMP(FID_RECORD_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K377)
  {
    u32 _h_97 = r0;
    Term _h_98 = r1;
    Term _h_99 = r2;
    u32 _h_100 = r3;
    u32 _h_101 = r4;
    Term _h_102 = r5;
    Term _h_103 = r6;
    u32 _h_104 = r7;
    u32 _h_105 = r8;
    u32 _h_106 = r9;
    Term _h_107 = r10;
    Term _h_108 = r11;
    u32 _h_109 = r12;
    u32 _h_110 = r13;
    u32 _h_111 = r14;
    u32 _h_112 = r15;
    Term _h_113 = r16;
    u32 _h_114 = r17;
    Term _h_115 = r18;
    u32 _h_116 = r19;
    Term _h_117 = r20;
    Term _h_118 = r21;
    Term _h_119 = r22;
    u32 _h_120 = r23;
    u32 _h_121 = r24;
    Term _h_122 = r25;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_FINAL)) {
      u64 _t_10 = task_node(e, FID_FINAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_97;
      e.mem[_t_10 + 1] = _h_98;
      e.mem[_t_10 + 2] = _h_99;
      e.mem[_t_10 + 3] = _h_100;
      e.mem[_t_10 + 4] = _h_101;
      e.mem[_t_10 + 5] = _h_102;
      e.mem[_t_10 + 6] = _h_103;
      e.mem[_t_10 + 7] = _h_104;
      e.mem[_t_10 + 8] = _h_105;
      e.mem[_t_10 + 9] = _h_106;
      e.mem[_t_10 + 10] = _h_107;
      e.mem[_t_10 + 11] = _h_108;
      e.mem[_t_10 + 12] = _h_109;
      e.mem[_t_10 + 13] = _h_110;
      e.mem[_t_10 + 14] = _h_111;
      e.mem[_t_10 + 15] = _h_112;
      e.mem[_t_10 + 16] = _h_113;
      e.mem[_t_10 + 17] = _h_114;
      e.mem[_t_10 + 18] = _h_115;
      e.mem[_t_10 + 19] = _h_116;
      e.mem[_t_10 + 20] = _h_117;
      e.mem[_t_10 + 21] = _h_118;
      e.mem[_t_10 + 22] = _h_119;
      e.mem[_t_10 + 23] = _h_120;
      e.mem[_t_10 + 24] = _h_121;
      e.mem[_t_10 + 25] = _h_122;
      return term_tsk(FID_FINAL, _t_10);
    }
    r0 = _h_97;
    r1 = _h_98;
    r2 = _h_99;
    r3 = _h_100;
    r4 = _h_101;
    r5 = _h_102;
    r6 = _h_103;
    r7 = _h_104;
    r8 = _h_105;
    r9 = _h_106;
    r10 = _h_107;
    r11 = _h_108;
    r12 = _h_109;
    r13 = _h_110;
    r14 = _h_111;
    r15 = _h_112;
    r16 = _h_113;
    r17 = _h_114;
    r18 = _h_115;
    r19 = _h_116;
    r20 = _h_117;
    r21 = _h_118;
    r22 = _h_119;
    r23 = _h_120;
    r24 = _h_121;
    r25 = _h_122;
    WL_JMP(FID_FINAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K379;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K379, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K379, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K379)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K381;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K381, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K381, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_1 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_ctr(CID_CON, STAT_OFF + 336);
      return term_tsk(FID_SCENARIO_0, _t_1);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 336);
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K381)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_MAIN_K382;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K382, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_MAIN_K382, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_3 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_CON, STAT_OFF + 342);
      return term_tsk(FID_SCENARIO_0, _t_3);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 342);
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K382)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_MAIN_K383;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K383, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_MAIN_K383, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_5 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_CON, STAT_OFF + 350);
      return term_tsk(FID_SCENARIO_0, _t_5);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 350);
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K383)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_MAIN_K384;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K384, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_MAIN_K384, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_7 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_CON, STAT_OFF + 356);
      return term_tsk(FID_SCENARIO_0, _t_7);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 356);
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K384)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = _h_9;
      STK(3) = _h_6;
      STK(4) = FID_MAIN_K385;
      WL_PUSHN(5);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K385, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      e.mem[_t_8 + 1] = _h_8;
      e.mem[_t_8 + 2] = _h_9;
      e.mem[_t_8 + 3] = _h_6;
      WL_CONT = term_tsk(FID_MAIN_K385, _t_8);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_9 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_CON, STAT_OFF + 360);
      return term_tsk(FID_SCENARIO_0, _t_9);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 360);
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K385)
  {
    WL_POPN(4);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = _h_14;
      STK(4) = _h_10;
      STK(5) = FID_MAIN_K386;
      WL_PUSHN(6);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K386, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_11;
      e.mem[_t_10 + 1] = _h_12;
      e.mem[_t_10 + 2] = _h_13;
      e.mem[_t_10 + 3] = _h_14;
      e.mem[_t_10 + 4] = _h_10;
      WL_CONT = term_tsk(FID_MAIN_K386, _t_10);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_1)) {
      u64 _t_11 = task_node(e, FID_SCENARIO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_CON, STAT_OFF + 377);
      return term_tsk(FID_SCENARIO_1, _t_11);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 377);
    WL_JMP(FID_SCENARIO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K386)
  {
    WL_POPN(5);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_19 = STK(3);
    Term _h_20 = STK(4);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_16;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = _h_19;
      STK(4) = FID_MAIN_K387;
      WL_PUSHN(5);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K387, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_16;
      e.mem[_t_12 + 1] = _h_17;
      e.mem[_t_12 + 2] = _h_18;
      e.mem[_t_12 + 3] = _h_19;
      WL_CONT = term_tsk(FID_MAIN_K387, _t_12);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_20;
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K387)
  {
    WL_POPN(4);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    Term _h_24 = STK(2);
    Term _h_25 = STK(3);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_22;
      STK(1) = _h_23;
      STK(2) = _h_24;
      STK(3) = FID_MAIN_K388;
      WL_PUSHN(4);
    } else {
      u64 _t_14 = task_node(e, FID_MAIN_K388, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_22;
      e.mem[_t_14 + 1] = _h_23;
      e.mem[_t_14 + 2] = _h_24;
      WL_CONT = term_tsk(FID_MAIN_K388, _t_14);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_25;
      e.mem[_t_15 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_25;
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K388)
  {
    WL_POPN(3);
    Term _h_27 = STK(0);
    Term _h_28 = STK(1);
    Term _h_29 = STK(2);
    Term _h_26 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_27;
      STK(1) = _h_28;
      STK(2) = FID_MAIN_K389;
      WL_PUSHN(3);
    } else {
      u64 _t_16 = task_node(e, FID_MAIN_K389, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_27;
      e.mem[_t_16 + 1] = _h_28;
      WL_CONT = term_tsk(FID_MAIN_K389, _t_16);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_29;
      e.mem[_t_17 + 1] = _h_26;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = _h_29;
    r1 = _h_26;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K389)
  {
    WL_POPN(2);
    Term _h_31 = STK(0);
    Term _h_32 = STK(1);
    Term _h_30 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_31;
      STK(1) = FID_MAIN_K390;
      WL_PUSHN(2);
    } else {
      u64 _t_18 = task_node(e, FID_MAIN_K390, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_31;
      WL_CONT = term_tsk(FID_MAIN_K390, _t_18);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_32;
      e.mem[_t_19 + 1] = _h_30;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_32;
    r1 = _h_30;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K390)
  {
    WL_POPN(1);
    Term _h_34 = STK(0);
    Term _h_33 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K391;
      WL_PUSHN(1);
    } else {
      u64 _t_20 = task_node(e, FID_MAIN_K391, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K391, _t_20);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_34;
      e.mem[_t_21 + 1] = _h_33;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_34;
    r1 = _h_33;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K391)
  {
    Term _h_35 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_35;
    r0 = term_clo(FID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_7 = r0;
    Term _k_7 = r1;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = _text_7;
    e.mem[_nd_7 + 1] = _k_7;
    r0 = term_ctr(CID_IO_PRINT, _nd_7);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
