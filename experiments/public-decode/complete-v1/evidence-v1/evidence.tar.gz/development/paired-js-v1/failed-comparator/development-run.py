#!/usr/bin/env python3
"""Direct paired application development checks; no delivery/performance gate."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/formal-proofs/bendvy')
sys.path.insert(0,str(ROOT/'scripts'))
import task_runner
from evidence_boundary import ReceiptBoundary, GuardBoundary


def load(name,path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


LOGS = load('decode_logs', ROOT/'scripts/receipt-logs.py')
COMPARE = load('decode_compare', HERE/'check-observation.py')


def main(out):
    out.mkdir()
    raw = out/'raw'
    raw.mkdir()
    generated = out/'generated'
    generated.mkdir()
    env = {**os.environ,'BEND_NO_TELEMETRY':'1'}
    private = out/'private-environment.json'
    private.write_text(json.dumps(env,sort_keys=True)+'\n')
    private.chmod(0o600)
    tools = {n:Path(shutil.which(n)).resolve() for n in ('bend','node','taskset')}
    inputs = {Path(__file__).resolve(),Path(COMPARE.__file__),COMPARE.PARSER,Path(task_runner.__file__),ROOT/'scripts/evidence_boundary.py',ROOT/'scripts/receipt-logs.py',private,*tools.values()}
    entries = [HERE/'controls.bend',HERE/'bounded-controls.bend']
    def visit(path):
        if path in inputs:
            return
        inputs.add(path)
        for target in re.findall(r'^import\s+(\S+)',path.read_text(),re.MULTILINE):
            if target == 'Base':
                visit(Path('/home/node/.bend/bend2/base.bend'))
            else:
                visit((path.parent/target).resolve())
    for path in entries:
        visit(path)
    oracles = [HERE/'oracle-v1/expected-complete.json',HERE/'oracle-v1/expected-bounded.json']
    assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in oracles] == ['13607718be581d8b76de1db1cc0e6439e0c60a7f5641a9dfd1eb4f7578cc83c2','c1d52b58395c8d3a6d5f08180695f690a9fe1a90dd557b2b47fee27df6b8b0ad']
    inputs.update(oracles)
    frozen = task_runner.Inputs(files=inputs,directories=['/home/node/.bend/bend2'])
    commands = []
    for kind,entry in zip(('complete','bounded'),entries):
        artifact = generated/(kind+'.js')
        prefix = [str(tools['taskset']),'-c','5']
        commands += [{'label':kind+'-emit','argv':prefix+[str(tools['bend']),str(entry),'-o',str(artifact)],'capSeconds':30,'artifact':str(artifact)},
                     {'label':kind+'-run','argv':prefix+[str(tools['node']),str(artifact)],'capSeconds':5}]
    plan = {'scope':__doc__,'commands':commands,'inputs':frozen.expected}
    plan_path = out/'plan.json'
    plan_path.write_text(json.dumps(plan,indent=2)+'\n')
    frozen = task_runner.Inputs(files=(*inputs,plan_path),directories=['/home/node/.bend/bend2'])
    logs = LOGS.CommandLogs(raw,[c['label'] for c in commands])
    record = {'status':'INCOMPLETE','scope':__doc__,'commands':[],'generated':{},'logs':{}}
    def guard():
        frozen.guard()
        logs.guard()
        record['logs'] = dict(logs.hashes)
        assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in generated.iterdir() if p.is_file()} == record['generated']
        assert not any(p.is_symlink() or not p.is_file() for p in generated.iterdir())
    with ReceiptBoundary(record,out/'receipt.json',[('source/tools/environment/raw/generated',guard)]):
        for command in commands:
            row = dict(command)
            record['commands'].append(row)
            def capture_generated():
                if 'artifact' in command:
                    p = Path(command['artifact'])
                    if p.is_file() and not p.is_symlink():
                        record['generated'][str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
            guard()
            with GuardBoundary([('generated result capture',capture_generated),('source/tools/environment/raw/generated',guard)]):
                with open('/tmp/bendvy-parity-heavy.lock','a') as lock:
                    fcntl.flock(lock,fcntl.LOCK_EX)
                    guard()
                    current = task_runner.Inputs(files=(*inputs,plan_path,*record['generated']),directories=['/home/node/.bend/bend2'])
                    assert current.expected == {**frozen.expected,**record['generated']}
                    runner = task_runner.Runner(logs,inputs=current,env=env,cwd=HERE)
                    try:
                        result = runner.run(command['label'],command['argv'],command['capSeconds'])
                    except BaseException as error:
                        row['error'] = f'{type(error).__name__}: {error}'
                        failed = getattr(error,'result',None)
                        if isinstance(failed,dict):row.update({k:v for k,v in failed.items() if not isinstance(v,bytes)})
                        raise
                    row.update({k:v for k,v in result.items() if not isinstance(v,bytes)})
        for kind,entry,oracle in zip(('complete','bounded'),entries,oracles):
            actual = COMPARE.compare(raw/(kind+'-run.stdout'),oracle,entry)
            (out/(kind+'-actual.json')).write_text(json.dumps(actual,indent=2)+'\n')
        record['status'] = 'DEVELOPMENT_PASS'
    print(json.dumps({'receipt':str(out/'receipt.json'),'status':record['status']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=HERE/'development'/str(time.time_ns()))
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    main(args.output.resolve())
